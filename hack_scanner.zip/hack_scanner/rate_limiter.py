#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全局速率限制器 — 防止 DoS 级别的请求风暴
============================================
所有扫描器的 HTTP 请求必须经过此限速器。
支持 per-domain 限速、burst、并发控制、安全警告。
"""

import time
import threading
from collections import defaultdict
from typing import Dict, Optional


def domain_of(url: str) -> str:
    """从 URL 提取 domain（netloc），解析失败返回 'unknown'"""
    try:
        from urllib.parse import urlparse
        return urlparse(url).netloc or 'localhost'
    except Exception:
        return 'unknown'


def _load_quota_from_config() -> int:
    """从 config.json 读取 safety.max_requests_per_domain（0 = 不限制；读取失败返回 0）"""
    try:
        import json, os
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        return int(cfg.get('safety', {}).get('max_requests_per_domain', 0) or 0)
    except Exception:
        return 0


class RequestQuotaExceeded(Exception):
    """per-domain 请求配额（config safety.max_requests_per_domain）已耗尽"""

    def __init__(self, domain: str, limit: int):
        self.domain = domain
        self.limit = limit
        super().__init__(f'per-domain 请求配额已耗尽: {domain} (上限 {limit})')


class RateLimiter:
    """全局速率限制器（单例模式）"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        # per-domain 配置: {domain: {'last_time': float, 'lock': Lock}}
        self._domain_locks: Dict[str, threading.Lock] = {}
        self._domain_last_call: Dict[str, float] = {}
        self._lock = threading.Lock()

        # 当前限速参数（可动态修改）
        self.min_interval = 1.0       # 默认：同一域名最少 1 秒间隔
        self.global_min_interval = 0.5  # 全局最小请求间隔
        self._global_last_call = 0.0

        # per-domain 请求配额（config safety.max_requests_per_domain；0 = 不限）
        self.max_per_domain = 0
        self._quota_set = False  # 配额是否已确定（显式 set_quota 或惰性读 config）
        self._domain_counts: Dict[str, int] = {}
        self._quota_warned = set()

        # 统计信息
        self.stats = defaultdict(int)  # requests_sent, domains_hit, throttled_count
        self._throttle_count = 0

    def _get_domain_lock(self, domain: str) -> threading.Lock:
        """获取或创建 per-domain 锁"""
        if domain not in self._domain_locks:
            with self._lock:
                if domain not in self._domain_locks:
                    self._domain_locks[domain] = threading.Lock()
        return self._domain_locks[domain]

    def set_quota(self, max_per_domain: int) -> None:
        """显式设置 per-domain 请求配额（0 = 不限制）。显式设置后不再惰性读 config"""
        self.max_per_domain = max(0, int(max_per_domain))
        self._quota_set = True

    def _ensure_quota(self) -> None:
        """配额自包含接线：未显式设置时，首次使用前从 config.json 惰性读取。

        这样无论哪个入口（CLI / MCP / 直接使用扫描器模块）都不依赖
        "恰好 import 过 url_scanner" 这一隐式前置条件。
        """
        if self._quota_set:
            return
        with self._lock:
            if not self._quota_set:
                self._quota_set = True
                if self.max_per_domain == 0:
                    self.max_per_domain = _load_quota_from_config()

    def quota_exceeded(self, url: str) -> bool:
        """该 domain 是否已用完配额"""
        self._ensure_quota()
        if not self.max_per_domain:
            return False
        return self._domain_counts.get(domain_of(url), 0) >= self.max_per_domain

    def try_wait(self, url: str, interval: Optional[float] = None) -> bool:
        """
        限速等待 + per-domain 配额检查。

        Returns:
            True  = 可以继续发送请求
            False = 配额已耗尽，调用方不应再向该 domain 发请求
        """
        self._ensure_quota()
        if not url:
            return True
        if self.quota_exceeded(url):
            domain = domain_of(url)
            if domain not in self._quota_warned:
                self._quota_warned.add(domain)
                import logging
                logging.getLogger('rate_limiter').warning(
                    'per-domain 请求配额已耗尽: %s (上限 %s)，后续对该域名的请求将被拒绝',
                    domain, self.max_per_domain)
            return False
        self.wait(url, interval)
        return True

    def wait(self, url: str, interval: Optional[float] = None):
        """
        发送请求前必须调用此方法等待（纯限速，不含配额检查；配额请用 try_wait）。

        Args:
            url: 目标 URL（从中提取 domain）
            interval: 可选，覆盖默认间隔
        """
        if not url:
            return

        domain = domain_of(url)
        min_int = interval if interval is not None else self.min_interval

        # 全局限速
        with self._lock:
            now = time.time()
            elapsed = now - self._global_last_call
            global_min = max(min_int, self.global_min_interval)
            if elapsed < global_min:
                time.sleep(global_min - elapsed)
            self._global_last_call = time.time()

        # per-domain 限速（加锁保护）
        lock = self._get_domain_lock(domain)
        with lock:
            now = time.time()
            last = self._domain_last_call.get(domain, 0)
            elapsed = now - last
            if elapsed < min_int:
                wait_time = min_int - elapsed
                time.sleep(wait_time)
                self._throttle_count += 1
            self._domain_last_call[domain] = time.time()

        self.stats['requests_sent'] += 1
        self.stats['domains_hit'] = len(self._domain_last_call)
        self._domain_counts[domain] = self._domain_counts.get(domain, 0) + 1

    def set_config(self, per_domain: float = 1.0, global_min: float = 0.5):
        """设置限速参数"""
        self.min_interval = max(0.5, per_domain)
        self.global_min_interval = max(0.3, global_min)

    def reset_stats(self):
        """重置统计信息"""
        self._throttle_count = 0
        self.stats.clear()


# 全局单例
_limiter: Optional[RateLimiter] = None


def get_rate_limiter() -> RateLimiter:
    """获取全局限速器单例"""
    global _limiter
    if _limiter is None:
        _limiter = RateLimiter()
    return _limiter


def safe_request(func, *args, **kwargs):
    """
    装饰器：自动在请求前加入速率限制。

    Usage:
        @safe_request
        def fetch(url):
            return requests.get(url)

        safe_request(requests.get, url)
    """
    limiter = get_rate_limiter()
    if not args and 'url' in kwargs:
        target = kwargs['url']
    elif args:
        target = args[0] if isinstance(args[0], str) else 'unknown'
    else:
        target = 'unknown'

    limiter.wait(target)
    return func(*args, **kwargs)


def check_safe_to_scan(url: str, max_rps: float = 1.0) -> tuple:
    """
    检查是否可以安全地扫描目标。

    Returns:
        (safe: bool, reason: str, suggested_delay: float)
    """
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or 'localhost'
    except Exception:
        domain = 'unknown'

    limiter = get_rate_limiter()

    # per-domain 配额检查
    if limiter.quota_exceeded(url):
        return (False, f'per-domain 请求配额已耗尽 (上限 {limiter.max_per_domain})，建议停止对该域名的扫描', 5.0)

    # localhost / 127.0.0.1 / IP - 永远安全
    if domain in ('localhost', '127.0.0.1', '::1', '127.0.0.0'):
        return (True, '本地地址，始终安全', 0)

    # 检查历史记录
    hit_count = limiter.stats.get('requests_sent', 0)
    domains = limiter.stats.get('domains_hit', 0)

    if hit_count > 50:
        return (False, f'已发送 {hit_count} 个请求，建议暂停扫描', max(limiter.min_interval * 2, 5.0))

    if domains > 10:
        return (True, f'正在扫描多个域名，已自动限速', limiter.min_interval)

    return (True, '可以安全扫描', limiter.min_interval)


def make_guarded_session():
    """创建自带「限速等待 + per-domain 配额检查」的 requests.Session。

    供使用 Session 型 API 的扫描器使用（session.get/post 不经过
    全局 requests 包裹器，必须自带守卫）：

        session = make_guarded_session()
        resp = session.get(url)  # 自动限速；配额耗尽抛 RequestQuotaExceeded
    """
    import requests as _requests
    s = _requests.Session()

    def _guarded(url):
        if not url:
            return
        limiter = get_rate_limiter()
        if not limiter.try_wait(url):
            raise RequestQuotaExceeded(domain_of(url), limiter.max_per_domain)

    def _make(name, real_fn):
        if name == 'request':
            def _wrapped(method, url=None, *a, **kw):
                _guarded(url)
                return real_fn(method, url, *a, **kw)
        else:
            def _wrapped(url=None, *a, **kw):
                _guarded(url)
                return real_fn(url, *a, **kw)
        return _wrapped

    for name in ('get', 'post', 'put', 'delete', 'head', 'patch', 'options', 'request'):
        real_fn = getattr(s, name)
        setattr(s, name, _make(name, real_fn))
    return s


def scan_safety_report() -> Dict:
    """生成当前扫描安全状态报告"""
    limiter = get_rate_limiter()
    limiter._ensure_quota()  # 报告中显示的是生效配额（惰性接线后）
    domains = dict(limiter._domain_last_call) if hasattr(limiter, '_domain_last_call') else {}

    return {
        'total_requests_sent': limiter.stats.get('requests_sent', 0),
        'unique_domains_hit': len(domains),
        'throttled_count': limiter._throttle_count,
        'max_requests_per_domain': limiter.max_per_domain,
        'requests_per_domain': dict(list(limiter._domain_counts.items())[-20:]),
        'current_interval': f"{limiter.min_interval:.1f}s (per-domain) / {limiter.global_min_interval:.1f}s (global)",
        'domains_detail': dict(list(domains.items())[-20:]),  # 最近20个域名
    }
