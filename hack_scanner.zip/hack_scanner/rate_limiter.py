#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全局速率限制器 — 防止 DoS 级别的请求风暴
============================================
所有扫描器的 HTTP 请求必须经过此限速器。
支持 per-domain 限速、burst、并发控制、安全警告。
"""

import time
import threading
from collections import defaultdict
from typing import Dict, Optional


class RateLimiter:
    """全局速率限制器（单例模式）"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True

        # per-domain 配置: {domain: {'last_time': float, 'lock': Lock}}
        self._domain_locks: Dict[str, threading.Lock] = {}
        self._domain_last_call: Dict[str, float] = {}
        self._lock = threading.Lock()

        # 当前限速参数（可动态修改）
        self.min_interval = 1.0       # 默认：同一域名最少 1 秒间隔
        self.global_min_interval = 0.5  # 全局最小请求间隔
        self._global_last_call = 0.0

        # 统计信息
        self.stats = defaultdict(int)  # requests_sent, domains_hit, throttled_count
        self._throttle_count = 0

    def _get_domain_lock(self, domain: str) -> threading.Lock:
        """获取或创建 per-domain 锁"""
        if domain not in self._domain_locks:
            with self._lock:
                if domain not in self._domain_locks:
                    self._domain_locks[domain] = threading.Lock()
        return self._domain_locks[domain]

    def wait(self, url: str, interval: Optional[float] = None):
        """
        发送请求前必须调用此方法等待。

        Args:
            url: 目标 URL（从中提取 domain）
            interval: 可选，覆盖默认间隔
        """
        if not url:
            return

        # 提取 domain
        try:
            from urllib.parse import urlparse
            domain = urlparse(url).netloc or 'localhost'
        except Exception:
            domain = 'unknown'

        min_int = interval if interval is not None else self.min_interval

        # 全局限速
        with self._lock:
            now = time.time()
            elapsed = now - self._global_last_call
            global_min = max(min_int, self.global_min_interval)
            if elapsed < global_min:
                time.sleep(global_min - elapsed)
            self._global_last_call = time.time()

        # per-domain 限速（加锁保护）
        lock = self._get_domain_lock(domain)
        with lock:
            now = time.time()
            last = self._domain_last_call.get(domain, 0)
            elapsed = now - last
            if elapsed < min_int:
                wait_time = min_int - elapsed
                time.sleep(wait_time)
                self._throttle_count += 1
            self._domain_last_call[domain] = time.time()

        self.stats['requests_sent'] += 1
        self.stats['domains_hit'] = len(self._domain_last_call)

    def set_config(self, per_domain: float = 1.0, global_min: float = 0.5):
        """设置限速参数"""
        self.min_interval = max(0.5, per_domain)
        self.global_min_interval = max(0.3, global_min)

    def reset_stats(self):
        """重置统计信息"""
        self._throttle_count = 0
        self.stats.clear()


# 全局单例
_limiter: Optional[RateLimiter] = None


def get_rate_limiter() -> RateLimiter:
    """获取全局限速器单例"""
    global _limiter
    if _limiter is None:
        _limiter = RateLimiter()
    return _limiter


def safe_request(func, *args, **kwargs):
    """
    装饰器：自动在请求前加入速率限制。

    Usage:
        @safe_request
        def fetch(url):
            return requests.get(url)

        safe_request(requests.get, url)
    """
    limiter = get_rate_limiter()
    if not args and 'url' in kwargs:
        target = kwargs['url']
    elif args:
        target = args[0] if isinstance(args[0], str) else 'unknown'
    else:
        target = 'unknown'

    limiter.wait(target)
    return func(*args, **kwargs)


def check_safe_to_scan(url: str, max_rps: float = 1.0) -> tuple:
    """
    检查是否可以安全地扫描目标。

    Returns:
        (safe: bool, reason: str, suggested_delay: float)
    """
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc or 'localhost'
    except Exception:
        domain = 'unknown'

    limiter = get_rate_limiter()

    # localhost / 127.0.0.1 / IP - 永远安全
    if domain in ('localhost', '127.0.0.1', '::1', '127.0.0.0'):
        return (True, '本地地址，始终安全', 0)

    # 检查历史记录
    hit_count = limiter.stats.get('requests_sent', 0)
    domains = limiter.stats.get('domains_hit', 0)

    if hit_count > 50:
        return (False, f'已发送 {hit_count} 个请求，建议暂停扫描', max(limiter.min_interval * 2, 5.0))

    if domains > 10:
        return (True, f'正在扫描多个域名，已自动限速', limiter.min_interval)

    return (True, '可以安全扫描', limiter.min_interval)


def scan_safety_report() -> Dict:
    """生成当前扫描安全状态报告"""
    limiter = get_rate_limiter()
    domains = dict(limiter._domain_last_call) if hasattr(limiter, '_domain_last_call') else {}

    return {
        'total_requests_sent': limiter.stats.get('requests_sent', 0),
        'unique_domains_hit': len(domains),
        'throttled_count': limiter._throttle_count,
        'current_interval': f"{limiter.min_interval:.1f}s (per-domain) / {limiter.global_min_interval:.1f}s (global)",
        'domains_detail': dict(list(domains.items())[-20:]),  # 最近20个域名
    }
