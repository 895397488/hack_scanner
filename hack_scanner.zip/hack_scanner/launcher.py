#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Hack Scanner 引导界面 - 所有交互在此完成"""

import os, sys, json, subprocess, time

# 清屏命令白名单
def cls_clear():
    """清屏命令，不在安全扫描中报告"""
    os.system("cls" if os.name == "nt" else "clear")


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, 'config.json')
HACK_REPORT = os.path.join(SCRIPT_DIR, 'hack_report')

MODELS = [
    ("1", "qwen",     "Qwen (通义千问)"),
    ("2", "glm",      "GLM (智谱)"),
    ("3", "moonshot", "Kimi (月之暗面)"),
    ("4", "deepseek", "DeepSeek (深度求索)"),
    ("5", "siliconflow","SiliconFlow (硅基流动)"),
    ("6", "gemini",   "Gemini (Google)"),
    ("7", "openai",   "GPT (OpenAI)"),
    ("8", "claude",   "Claude (Anthropic)"),
    ("9", "ollama",   "Ollama (本地部署，无需API Key)"),
    ("10", "vllm",    "vLLM (本地推理，无需API Key)"),
    ("11", "lmdeploy","LMDeploy (本地推理，无需API Key)"),
    ("12", "lmstudio","LM Studio (本地推理，无需API Key)"),
]

ENV_MAP = {
    'qwen': 'DASHSCOPE_API_KEY', 'glm': 'ZHIPUAI_API_KEY',
    'moonshot': 'MOONSHOT_API_KEY', 'deepseek': 'DEEPSEEK_API_KEY',
    'siliconflow': 'SILICONFLOW_API_KEY', 'gemini': 'GEMINI_API_KEY',
    'openai': 'OPENAI_API_KEY', 'claude': 'ANTHROPIC_API_KEY',
}

MODEL_MAP = {
    'qwen': 'qwen-max', 'glm': 'glm-4-flash', 'moonshot': 'moonshot-v1-8k',
    'deepseek': 'deepseek-chat', 'siliconflow': 'Qwen/Qwen2.5-7B-Instruct',
    'gemini': 'gemini-2.0-flash', 'openai': 'gpt-4.1-mini',
    'claude': 'claude-sonnet-4-20250514', 'ollama': '',
    'vllm': 'Qwen/Qwen2.5-7B-Instruct', 'lmdeploy': 'Qwen/Qwen2.5-7B-Instruct',
    'lmstudio': '',  # 用 LM Studio 中已加载的模型
}

def ensure_dirs():
    os.makedirs(HACK_REPORT, exist_ok=True)

def print_menu(title):
    print("\n" + "=" * 40)
    print(f"   {title}")
    print("=" * 40)

def get_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    # 重新初始化 config.json
    cfg = init_config()
    save_config(cfg)
    return cfg

def init_config():
    """生成默认配置并写入文件"""
    default_cfg = {
        "scanner": {
            "timeout": 30, "max_depth": 3, "max_pages": 100,
            "concurrent": 5, "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) HackScanner/1.0",
            "proxy": {"enabled": False, "http": "", "https": ""}
        },
        "ai": {
            "enabled": False, "provider": "ollama", "model": "",
            "base_url": "", "api_key": "", "temperature": 0.2, "max_tokens": 4096
        },
        "urls": {
            "check_ssl": True, "check_headers": True, "check_cors": True,
            "check_sqli": True, "check_xss": True, "check_ssrf": True,
            "check_rce": True, "check_lfi": True, "check_xxe": True,
            "check_sensitive_data": True, "enum_subdomains": True,
            "dir_busting": {"enabled": True, "wordlist": ["common.txt", "directory-list-2.3-small.txt"], "status_codes": [200, 301, 302, 403, 401, 500]}
        },
        "files": {"check_secrets": True, "check_permissions": True, "check_dependencies": True, "deepsec_matchers": False, "deepsec_noise_tiers": ["precise", "normal"], "vuln_db": "cve-db.json"},
        "report": {"format": ["html", "json"], "output_dir": ".",
                   "severity_colors": {"critical": "#dc3545", "high": "#fd7e14", "medium": "#ffc107", "low": "#17a2b8", "info": "#6c757d"}},
        "tools": {"sqlmap_path": "", "nmap_path": "", "nikto_path": "", "dirb_path": ""}
    }
    save_config(default_cfg)
    return default_cfg

def save_config(cfg):
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

def enable_ai():
    print_menu("=== 可选的AI模型 ===")
    for num, key, name in MODELS:
        env_key = ENV_MAP.get(key)
        if env_key:
            val = os.environ.get(env_key, '')
            suffix = f" [已配置:{val[:4]}...]" if val else ""
            print(f"  [{num}] {name}{suffix}")
        else:
            print(f"  [{num}] {name} (无需API Key)")

    while True:
        choice = input("\n请选择模型编号 [1-12]: ").strip()
        matched = [m for m in MODELS if m[0] == choice]
        if matched:
            break
        print("无效选择，请输入 1-12")

    num, key, name = matched[0]
    
    api_key = ""
    env_key = ENV_MAP.get(key)
    if env_key:
        existing = os.environ.get(env_key, '')
        if existing:
            masked = '***' + existing[-4:]
            print(f"\n检测到 {env_key}: {masked}")
            use_env = input("使用环境变量? (y/n) [y]: ").strip().lower()
            if use_env != 'n':
                api_key = existing
            else:
                api_key = input(f"请输入 {env_key}: ").strip()
        else:
            api_key = input(f"请输入 {env_key}: ").strip()

    cfg = get_config()
    cfg['ai'] = {
        'enabled': True, 'provider': key,
        'model': MODEL_MAP.get(key, ''),
        'base_url': '', 'api_key': api_key,
        'temperature': 0.2, 'max_tokens': 4096
    }
    save_config(cfg)
    if key == 'ollama':
        note = "（未预设模型，运行时自动识别本机已装模型）"
    elif key == 'lmstudio':
        note = "（未预设模型，使用 LM Studio 中已加载的模型）"
    else:
        note = ""
    print(f"\n已选择: {name}{note}")

def disable_ai():
    cfg = get_config()
    cfg.setdefault('ai', {})['enabled'] = False
    save_config(cfg)
    print("AI分析已禁用")

def tool_self_check():
    """工具自检：自动识别本机外部工具安装状态，可把发现的路径写回 config.json"""
    try:
        from scanners.tool_detector import detect_tools, auto_update_config, format_report
    except Exception as e:
        print(f"\n加载 tool_detector 失败: {e}")
        input("按 Enter 继续...")
        return

    print_menu("=== 外部工具自检 ===")
    results = detect_tools(CONFIG_PATH)
    print(format_report(results, CONFIG_PATH))

    found = [r for r in results if r["status"] == "found"]
    if found:
        ans = input(f"\n发现 {len(found)} 个工具已安装但 config 未配置/路径失效，写入 config.json? (y/n) [y]: ").strip().lower()
        if ans != 'n':
            report = auto_update_config(CONFIG_PATH)
            print(f"\n已更新 config.json：{report['changed']} 项")

    missing = [r for r in results if r["status"] == "missing"]
    if missing:
        print(f"\n另有 {len(missing)} 个工具未安装（不影响运行，wrapper 会优雅降级）：")
        for r in missing:
            print(f"  - {r['tool']}: {r['hint']}")

    input("\n按 Enter 返回主菜单...")


def detection_console():
    """攻防一体检测：YARA 规则引擎（webshell/后门/恶意特征）+ IOC 威胁情报检测。"""
    print_menu("=== 攻防一体检测（蓝队侧）===")
    print("\n  [1] YARA 检测 — 扫描文件/目录中的 webshell/后门/恶意样本特征")
    print("  [2] IOC 检测 — 对照威胁情报判断 IP/域名/URL/哈希 是否恶意")
    print("  [3] 刷新 IOC 威胁情报源（URLhaus/Spamhaus-DROP/MDL）")
    print("  [0] 返回主菜单")

    choice = input("\n请选择 [0/1/2/3]: ").strip()

    if choice == "1":
        target = input("\n请输入要扫描的文件或目录路径: ").strip()
        if not target:
            print("路径不能为空。")
            input("按 Enter 返回...")
            return
        rules_path = input("自定义规则文件/目录（留空用内置规则包）: ").strip()
        inc = input("附带命中的字符串证据? (y/n) [n]: ").strip().lower() == "y"
        try:
            from scanners.yara_wrapper import yara_scan
        except Exception as e:
            print(f"\n加载 yara_wrapper 失败: {e}")
            input("按 Enter 返回...")
            return
        print("\n正在用 YARA 扫描 ...")
        result = yara_scan(target, rules_path=rules_path, include_strings=inc)
        if not result.get("ok"):
            print(f"\n[!] {result.get('error')}")
        else:
            print(f"\n规则目录: {result.get('rules_dir')}（{result.get('rules_loaded')} 个规则文件）")
            print(f"命中 {result.get('total_matches')} 条，涉及 {result.get('total_files')} 个文件：")
            for m in result.get("matches", [])[:50]:
                print(f"  - [{m['rule']}] {m['file']}")
                if m.get("evidence"):
                    print(f"      证据: {m['evidence']}")
            if not result.get("matches"):
                print("  （未命中任何规则）")
        input("\n按 Enter 返回主菜单...")
        return

    if choice == "2":
        values = input("\n请输入 IOC（IP/域名/URL/哈希，英文逗号分隔多个）: ").strip()
        if not values:
            print("输入不能为空。")
            input("按 Enter 返回...")
            return
        try:
            from scanners.ioc_detector import check_ioc, check_iocs
        except Exception as e:
            print(f"\n加载 ioc_detector 失败: {e}")
            input("按 Enter 返回...")
            return
        vals = [v.strip() for v in values.split(",") if v.strip()]
        print("\n正在对照威胁情报检测 ...")
        result = check_ioc(vals[0]) if len(vals) == 1 else check_iocs(vals)
        if not result.get("ok"):
            print(f"\n[!] {result.get('error')}")
        elif len(vals) == 1:
            flag = "⚠ 恶意" if result.get("malicious") else "✓ 未见威胁情报命中"
            print(f"\n{result.get('value')}  [{result.get('type')}]  →  {flag}")
            if result.get("matched_in"):
                print(f"  命中来源: {result.get('matched_in')}")
        else:
            print(f"\n共 {result.get('total')} 个，命中 {result.get('malicious')} 个恶意：")
            for r in result.get("results", []):
                flag = "⚠ 恶意" if r.get("malicious") else "  未见"
                print(f"  {r.get('value')}  [{r.get('type')}]  →  {flag}")
                if r.get("matched_in"):
                    print(f"      命中来源: {r.get('matched_in')}")
        input("\n按 Enter 返回主菜单...")
        return

    if choice == "3":
        force = input("强制重新下载（忽略24h缓存）? (y/n) [n]: ").strip().lower() == "y"
        try:
            from scanners.ioc_detector import refresh_feeds
        except Exception as e:
            print(f"\n加载 ioc_detector 失败: {e}")
            input("按 Enter 返回...")
            return
        print("\n正在刷新情报源 ...")
        result = refresh_feeds(force=force)
        if not result.get("ok"):
            print(f"\n[!] {result.get('error')}")
        else:
            print(f"\n缓存目录: {result.get('cache_dir')}")
            for f in result.get("feeds", []):
                name, note = f["name"], f.get("note", "")
                if f.get("skipped"):
                    # 用户主动关闭的源：单独标注，别显示成"0 条"误导
                    print(f"  ⊘ {name}: 已跳过（config.ioc.disable_feeds 关闭）")
                elif not f.get("ok"):
                    print(f"  ✗ {name}: 刷新失败")
                    if f.get("error"):
                        print(f"      错误: {f['error']}")
                else:
                    if note == "cached":
                        tag = "（缓存内）"
                    elif note == "stale-cache":
                        tag = "（下载失败，用旧缓存）"
                    else:
                        tag = "（已更新）"
                    ts = f.get("fetched_at")
                    ts_s = (time.strftime("%m-%d %H:%M", time.localtime(ts))
                            if isinstance(ts, (int, float)) else "")
                    print(f"  ✓ {name}: {f.get('entries',0)} 条 / "
                          f"{f.get('bytes',0)} 字节 {tag} {ts_s}")
        input("\n按 Enter 返回主菜单...")
        return

    # choice == "0" 或无效
    if choice not in ("0",):
        print("无效选择。")
        input("按 Enter 返回主菜单...")


def _ownership_takeover_flow(target=None):
    """[4-1] 所有权接管 + 授权：takeown + icacls（可选终止锁定进程）。"""
    try:
        from scanners.ownership_take import (
            take_ownership, get_owner, check_admin,
            find_locking_processes, kill_locking_processes,
        )
    except Exception as e:
        print(f"\n加载 ownership_take 模块失败: {e}")
        input("按 Enter 继续...")
        return

    if os.name != 'nt':
        print("\n[!] 仅支持 Windows（takeown/icacls 为系统内置工具）。")
        input("按 Enter 返回所有权管理菜单...")
        return

    if not target:
        target = input("\n请输入目标文件/目录路径: ").strip()
        while not target:
            print("错误: 路径不能为空，请重试。")
            target = input("请输入目标文件/目录路径: ").strip()

    is_dir = os.path.isdir(target)
    recursive = True
    if is_dir:
        ans = input("目录递归接管? (y/n) [y]: ").strip().lower()
        recursive = ans != 'n'
    else:
        print("(目标是单文件，递归选项自动忽略)")

    admin = check_admin()
    if admin:
        print("\n[√] 当前进程已以管理员身份运行")
    else:
        print("\n[!] 当前进程未以管理员身份运行，接管他人拥有的文件会失败。")
        print("    如失败，请右键 → 以管理员身份运行终端后重试。")

    grant = True
    ans = input("同时授权 Everyone + Administrators 完整控制? (y/n) [y]: ").strip().lower()
    grant = ans != 'n'

    # ── 预检：是否有进程锁定目标 ──
    kill_mode = False
    try:
        pre = find_locking_processes(target)
        if pre.get('locked'):
            print("\n[!] 该文件/目录正被以下进程锁定:")
            for l in pre['lockers']:
                print(f"    - {l['name']} (pid {l['pid']}, {l['handles']} 个句柄)")
            print("    （实测：锁通常不阻挡接管本身；但独占锁会挡住后续读/写/复制/删除，")
            print("      如还要操作文件内容，建议终止或关闭锁定进程）")
            ans = input("终止锁定进程? (y/n) [n]: ").strip().lower()
            kill_mode = ans == 'y'
    except Exception:
        pass

    confirm = input(f"\n确认接管 {target}? (y/n) [y]: ").strip().lower()
    if confirm == 'n':
        print("已取消。")
        input("按 Enter 返回所有权管理菜单...")
        return

    # 接管前所有者
    before = get_owner(target)
    if before.get('ok'):
        print(f"\n当前所有者: {before['owner_name']} ({before['owner_sid']})")

    # 预检阶段选了"终止锁定进程"：先终止（接管本身通常不被锁阻挡，
    # 但后续读/写/复制/删除需要锁定者已退出）
    if kill_mode:
        kr = kill_locking_processes(target)
        for l in kr.get('killed', []):
            print(f"  [已终止] {l['name']} (pid {l['pid']})")
        for l in kr.get('failed', []):
            print(f"  [终止失败] {l['name']} (pid {l['pid']}): {l.get('reason', '')}")
        time.sleep(0.5)  # 等待句柄释放

    result = take_ownership(target, recursive=recursive, grant_full_control=grant,
                            on_lock='kill' if kill_mode else 'report')

    # 失败且检测到锁定、预检阶段又没选 kill → 再给一次机会
    if not result['ok'] and result.get('locked') and not kill_mode:
        names = ', '.join(f"{l['name']} (pid {l['pid']})" for l in result.get('lockers', []))
        ans = input(f"\n  目标正被进程锁定: {names}\n  终止锁定进程并自动重试? (y/N) [n]: ").strip().lower()
        if ans == 'y':
            result = take_ownership(target, recursive=recursive, grant_full_control=grant,
                                    on_lock='kill')

    print("\n" + "=" * 40)
    if result['ok']:
        print("  [成功] 接管完成")
        after = result.get('owner_after') or {}
        if after.get('ok'):
            print(f"  新所有者:   {after['owner_name']} ({after['owner_sid']})")
        if result.get('icacls_rc') is not None:
            print(f"  icacls 授权: rc={result['icacls_rc']}")
        for l in result.get('kill_result', {}).get('killed', []):
            print(f"  已终止锁定进程: {l['name']} (pid {l['pid']})")
    else:
        print("  [失败] 接管未完成")
        for err in result.get('errors', []):
            print(f"  - {err}")
    print("=" * 40)
    print("  提示: 文件若仍'正在使用/无法删除'，请选 [2] 识别并强杀文件相关程序进程树，")
    print("        再回来重试接管/删除（Edge/WebView2 等程序以映像方式占用文件，")
    print("        句柄枚举杀不到，[2] 走进程映像/加载模块/打开句柄三通道）。")

    input("\n按 Enter 返回所有权管理菜单...")


def _kill_process_tree_flow():
    """[4-2] 识别文件相关程序并强杀其进程树（2026-09-13 新增）。

    场景：目录里的文件"被写入保护"（进程以映像方式占用，如 Edge/WebView2），
    句柄枚举杀不干净/杀不到时，按三通道（进程映像/加载模块/打开句柄）定位
    相关程序，连整棵进程树一起强杀（taskkill /F /T → psutil → 停服务重试）。
    """
    try:
        from scanners.process_tree_kill import find_related_processes, kill_process_tree
    except Exception as e:
        print(f"\n加载 process_tree_kill 模块失败: {e}")
        input("按 Enter 继续...")
        return
    try:
        from scanners.ownership_take import check_admin
    except Exception:
        def check_admin():
            return False

    target = input("\n请输入目标文件/目录路径: ").strip()
    while not target:
        print("错误: 路径不能为空，请重试。")
        target = input("请输入目标文件/目录路径: ").strip()

    if not os.path.exists(target):
        print(f"\n[!] 路径不存在: {target}")
        input("按 Enter 返回所有权管理菜单...")
        return

    if check_admin():
        print("\n[√] 当前进程已以管理员身份运行（查看受保护进程模块/停止服务需要管理员）")
    else:
        print("\n[!] 当前进程未以管理员身份运行：看不到受保护进程的模块，部分服务无法停止。")

    print("\n正在识别与目标路径相关的进程（三通道: 进程映像/加载模块/打开句柄，可能需 10-60 秒）...")
    rel = find_related_processes(target)
    if not rel.get('ok'):
        print(f"\n[!] 识别失败: {rel.get('error')}")
        input("按 Enter 返回所有权管理菜单...")
        return
    if rel.get('partial'):
        print("  [!] 警告: 个别通道枚举被中断（受保护进程崩溃），列表可能不完整")

    related = rel.get('related', [])
    if not related:
        print("\n[√] 未发现与目标路径相关的进程（程序可能未运行）")
        print("    提示: Edge 浏览器 = Edge\\Application\\<版本>，")
        print("          WebView2 运行时 = EdgeWebView\\Application\\<版本>（两个是独立目录）。")
        input("按 Enter 返回所有权管理菜单...")
        return

    print(f"\n与目标路径相关的进程（{len(related)} 个）:")
    for r in related:
        print(f"  - {r['name']} (pid {r['pid']})  命中通道: {', '.join(r.get('via', []))}")
        if r.get('exe'):
            print(f"      映像: {r['exe']}")

    tree = rel.get('tree', [])
    protected = [t for t in tree if t.get('protected')]
    killable = [t for t in tree if not t.get('protected')]
    print(f"\n进程树（共 {len(tree)} 个: 将终止 {len(killable)} 个，受保护跳过 {len(protected)} 个）:")
    for t in tree:
        mark = "  [受保护-跳过]" if t.get('protected') else ""
        print(f"  - {t['name']} (pid {t['pid']}, 父 pid {t['ppid']}){mark}")
    if protected:
        reasons = sorted({t.get('reason', '受保护') for t in protected})
        for reason in reasons:
            print(f"      跳过原因: {reason}")

    if not killable:
        print("\n[!] 目标相关进程全部属于受保护进程，无可终止对象。")
        input("按 Enter 返回所有权管理菜单...")
        return

    print("\n" + "!" * 40)
    print(f"  [警告] 即将强杀 {len(killable)} 个进程（含其全部子进程，破坏性操作）！")
    print("         这些程序中未保存的工作将丢失！")
    print("!" * 40)
    ans = input("\n确认强杀? (y/N) [n]: ").strip().lower()
    if ans != 'y':
        print("已取消。")
        input("按 Enter 返回所有权管理菜单...")
        return

    kr = kill_process_tree(target)
    print("\n" + "=" * 40)
    for s in kr.get('services_stopped', []):
        print(f"  [服务已停止] {s['name']} {s.get('display', '')}")
    for s in kr.get('services_failed', []):
        print(f"  [服务停止失败] {s['name']}: {s.get('detail') or s.get('error') or ''}")
    for l in kr.get('killed', []):
        print(f"  [已终止] {l['name']} (pid {l['pid']})  途径 {l.get('method', '')}")
    for l in kr.get('failed', []):
        print(f"  [终止失败] {l['name']} (pid {l['pid']}): {l.get('reason', '')}")
    for l in kr.get('skipped', []):
        print(f"  [已跳过] {l['name']} (pid {l['pid']}): {l.get('reason', '')}")
    if kr.get('note'):
        print(f"  备注: {kr['note']}")
    print("=" * 40)

    if kr.get('killed'):
        ans = input("\n已终止相关进程。继续对该目标执行所有权接管 + 授权? (y/n) [n]: ").strip().lower()
        if ans == 'y':
            _ownership_takeover_flow(target)
    input("\n按 Enter 返回所有权管理菜单...")


def _vss_read_flow():
    """[4-3] VSS 卷影读出被锁文件内容（单文件，不杀进程）。"""
    try:
        from scanners.ownership_take import read_via_vss
    except Exception as e:
        print(f"\n加载 ownership_take 模块失败: {e}")
        input("按 Enter 继续...")
        return

    target = input("\n请输入目标文件路径（单文件）: ").strip()
    while not target:
        print("错误: 路径不能为空，请重试。")
        target = input("请输入目标文件路径（单文件）: ").strip()
    if not os.path.isfile(target):
        print(f"\n[!] 不是文件: {target}")
        input("按 Enter 返回所有权管理菜单...")
        return
    dv = input("输出路径 (留空=原路径+.vss 后缀): ").strip()
    rv = read_via_vss(target, dest=(dv or None))
    print("\n" + "=" * 40)
    if rv.get('ok'):
        print(f"  [成功] VSS 读出: {rv['dest']}")
        print(f"  大小: {rv.get('size')} 字节 | 校验: {'一致' if rv.get('verified') else '未知'}")
    else:
        print(f"  [失败] VSS 读出 (stage={rv.get('stage')})")
        print(f"  - {rv.get('error')}")
        if rv.get('stage') == 'create_shadow':
            print("  （提示：当前环境 VSS 不可用或被目标主动保护；"
                  "可改用安全模式 / WinPE 离线启动后读取）")
    print("=" * 40)
    input("\n按 Enter 返回所有权管理菜单...")


def ownership_manage():
    """文件所有权管理子菜单：接管+授权 / 文件相关进程树强杀 / VSS 读出。"""
    if os.name != 'nt':
        print("\n[!] 仅支持 Windows（takeown/icacls 为系统内置工具）。")
        input("按 Enter 返回主菜单...")
        return

    while True:
        print_menu("=== 文件所有权管理 ===")
        print("  [1] 所有权接管 + 授权 (takeown + icacls)")
        print("  [2] 识别并强杀文件相关程序进程树 (Edge/WebView2/被占用目录)")
        print("  [3] VSS 卷影读出被锁文件内容 (单文件, 不杀进程)")
        print("  [0] 返回主菜单")

        choice = input("\n请选择 [0/1/2/3]: ").strip()
        if choice == '1':
            _ownership_takeover_flow()
        elif choice == '2':
            _kill_process_tree_flow()
        elif choice == '3':
            _vss_read_flow()
        elif choice == '0':
            return
        else:
            print("无效选择。")
            input("按 Enter 继续...")


def run_scan(target, scan_type, use_ai, deepsec_enabled=False):
    ensure_dirs()
    if scan_type == 'url':
        cmd = [sys.executable, 'hack_scanner.py', '-u', target]
    elif scan_type == 'file':
        cmd = [sys.executable, 'hack_scanner.py', '-f', target]
    else:
        cmd = [sys.executable, 'hack_scanner.py']

    if use_ai:
        cmd.append('--ai')
    if deepsec_enabled:
        cmd.append('--deepsec-matchers')
    print(f"\n正在执行: {' '.join(cmd)}")
    subprocess.run(cmd)

def ensure_ai_for_adaptive():
    """菜单6 的模型选择步骤（与菜单1/2 的 AI 步骤对齐，选择逻辑复用 enable_ai）。

    自适应模式完全由 LLM 驱动，必须启用 AI：
      - AI 已启用 → 显示当前 provider/模型，可选"沿用 / 重新选择"
      - AI 未启用 → 必须现在选模型，或返回主菜单
    返回 True = 可继续执行；False = 返回主菜单。
    """
    cfg = get_config()
    ai = cfg.get('ai', {})
    name_map = {key: name for _, key, name in MODELS}

    print_menu("=== AI 模型选择（自适应模式需要 LLM）===")
    if ai.get('enabled'):
        provider = ai.get('provider', 'ollama')
        model = ai.get('model', '') or '(未预设，运行时自动识别本机已装模型)'
        print(f"  当前: {name_map.get(provider, provider)} / {model}")
        print("\n  [1] 沿用当前配置")
        print("  [2] 重新选择模型 (Qwen/GLM/Kimi/DeepSeek/…/Ollama)")
        choice = input("\n请选择 [1/2]: ").strip()
        if choice != '2':
            return True
    else:
        print("  当前 AI 未启用（自适应模式必须有模型，不能跳过）")
        print("\n  [1] 现在选择模型")
        print("  [2] 返回主菜单")
        choice = input("\n请选择 [1/2]: ").strip()
        if choice != '1':
            return False

    enable_ai()
    return True


def adaptive_flow():
    """AI 自适应渗透测试（实验）— 复用 run_adaptive 入口函数，不复制逻辑。"""
    if not ensure_ai_for_adaptive():
        input("\n按 Enter 返回主菜单...")
        return
    print_menu("=== AI 自适应渗透测试（实验）===")
    print("  LLM 自主驱动: 侦察 → 自定义请求探测 → 分类评分 → 报告")
    print("  默认 exploit dry-run；仅可用于自己拥有或已获书面授权的目标。")
    target = input("\n请输入目标URL: ").strip()
    while not target:
        print("错误: URL不能为空，请重试。")
        target = input("请输入目标URL: ").strip()
    objective = input("测试目标 (留空=发现所有漏洞): ").strip() or "find all vulnerabilities"
    mode_choice = input("模式 [1] full (默认) / [2] shallow: ").strip()
    mode = "shallow" if mode_choice == "2" else "full"
    iter_input = input("最大迭代轮数 (留空=无上限): ").strip()
    try:
        max_iter = int(iter_input) if iter_input else None
    except ValueError:
        max_iter = None
    exploit = input("启用 LIVE 命令执行? (默认 dry-run) (y/n) [n]: ").strip().lower() == "y"
    if exploit:
        exploit = input("⚠️ LIVE 模式将真实执行命令。再输入 yes 确认: ").strip() == "yes"

    from run_adaptive import run_adaptive
    run_adaptive(
        target=target,
        objective=objective,
        mode=mode,
        max_iterations=max_iter,
        exploit_live=exploit,
        interactive=True,
    )
    input("\n按 Enter 返回主菜单...")


def main():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print_menu("Hack Scanner - 自动化漏洞扫描器 v8.0")

        # === 第一步：选择扫描类型 ===
        print("\n=== 请选择扫描类型 ===")
        print("  [1] URL 黑盒扫描（网站漏洞检测）")
        print("  [2] 文件白盒分析（本地项目源码审计）")
        print("  [3] 工具自检（自动识别外部工具并更新 config.json）")
        print("  [4] 文件所有权管理 (接管+授权/强杀文件相关进程树/VSS读出, 需管理员)")
        print("  [5] 攻防一体检测（YARA webshell/后门 + IOC 威胁情报）")
        print("  [6] AI 自适应渗透测试（实验）— LLM 自主探测+分析")

        scan_choice = input("\n请选择 [1/2/3/4/5/6]: ").strip()
        if scan_choice == '6':
            adaptive_flow()
            continue

        if scan_choice == '5':
            detection_console()
            continue
        elif scan_choice == '4':
            ownership_manage()
            continue
        elif scan_choice == '3':
            tool_self_check()
            continue
        elif scan_choice == '1':
            # URL 扫描
            target = input("\n请输入目标URL: ").strip()
            while not target:
                print("错误: URL不能为空，请重试。")
                target = input("请输入目标URL: ").strip()
        elif scan_choice == '2':
            # 文件扫描
            target = input("\n请输入本地项目路径 (文件或目录): ").strip()
            while not target:
                print("错误: 路径不能为空，请重试。")
                target = input("请输入本地项目路径: ").strip()
        else:
            print("无效选择，请重新运行。")
            input("按 Enter 继续...")
            continue

        # === deepsec matchers 选项（仅文件扫描时可用）===
        deepsec_enabled = False
        if scan_choice == '2':
            print_menu("DeepSec Matcher 引擎")
            print("\n  [1] 不启用")
            print("  [2] 启用 (precise + normal, 推荐)")
            print("  [3] 全部层级 (包含 noisy, 更全面但更慢)")
            ds_choice = input("\n请选择 [1/2/3]: ").strip()
            if ds_choice == '2':
                deepsec_enabled = True
                cfg = get_config()
                cfg.setdefault('files', {})['deepsec_matchers'] = True
                cfg.setdefault('files', {})['deepsec_noise_tiers'] = ['precise', 'normal']
                save_config(cfg)
            elif ds_choice == '3':
                deepsec_enabled = True
                cfg = get_config()
                cfg.setdefault('files', {})['deepsec_matchers'] = True
                cfg.setdefault('files', {})['deepsec_noise_tiers'] = ['precise', 'normal', 'noisy']
                save_config(cfg)

        # === deepsec INFO.md Project Context（仅文件扫描时可用）===
        if scan_choice == '2':
            print_menu("DeepSec Project Context")
            print("\n  [1] 不加载项目上下文")
            print("  [2] 加载模板 (deepsec-info-template.md)")
            ds_info_choice = input("\n请选择 [1/2]: ").strip()
            if ds_info_choice == '2':
                cfg = get_config()
                cfg.setdefault('files', {})['deepsec_info_path'] = 'deepsec-info-template.md'
                save_config(cfg)

        # === 第二步：选择 AI 模式 ===
        print_menu("请选择分析模式")
        print("\n  [1] 仅扫描 (不做AI分析)")
        print("  [2] 启用AI分析 + 自动解读结果")

        mode = input("\n请选择 [1/2]: ").strip()

        use_ai = False
        if mode == "2":
            enable_ai()
            use_ai = True
        else:
            disable_ai()

        confirm = input(f"\n确认扫描此{'URL' if scan_choice == '1' else '文件'}? (y/n) [y]: ").strip().lower()
        if confirm != 'n':
            run_scan(target, 'url' if scan_choice == '1' else 'file', use_ai, deepsec_enabled=deepsec_enabled)
        
        cont = input("\n是否继续? (y/n) [y]: ").strip().lower()
        if cont == 'n':
            print("\n再见！")
            break

if __name__ == '__main__':
    main()
