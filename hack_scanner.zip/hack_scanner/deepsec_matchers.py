#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Deepsec Matcher Engine - 从 deepsec 提取的 ~110 regex matchers Python 版

核心能力：
- GENERIC_MATCHERS: 始终运行的跨语言漏洞模式 (~15 categories)
- FRAMEWORK_MATCHERS: 框架门控检测 (~20 frameworks)
- IAC_MATCHERS: IaC 安全 (Dockerfile/Terraform/GitHub Actions)
- ORM_MATCHERS: ORM raw SQL 注入
- TECH_DETECTION: sentinel file 框架识别
- CUSTOM MATCHERS: 加载用户自定义规则 (deepsec-custom.json)
- INFO.md CONTEXT: 从项目上下文文件中提取关键模式

灵感来源：deepsec (vercel-labs/deepsec) v2.1.2
"""

import os
import re
import json
import logging
from typing import List, Dict, Any, Optional, Tuple

logging.getLogger().setLevel(logging.WARNING)


# ==================== Noise Tier ====================
# precise: 模式无歧义，高信号/低误报率
# normal: 更宽泛的模式，由后续 AI 分析消歧
# noisy: 故意宽范围捕获，用于入口点覆盖
NOISE_TIER_LABEL = {
    'precise': 'high',
    'normal': 'medium',
    'noisy': 'low',
}

# === INFO.md context patterns (injected at runtime via set_project_context) ===
PROJECT_CONTEXT_PATTERS: List[Dict[str, Any]] = []
PROJECT_AUTH_PRIMITIVES: List[str] = []  # auth function/helper names to flag missing auth on
PROJECT_THREAT_HIGHLIGHTS: List[str] = []  # threat model highlights

# === Custom matcher loading ===
CUSTOM_MATCHERS_PATH = 'deepsec-custom.json'


def load_custom_matchers(project_root: str) -> List[Dict[str, Any]]:
    """Load custom matchers from deepsec-custom.json in project root or parent."""
    for candidate in [
        os.path.join(project_root, CUSTOM_MATCHERS_PATH),
        os.path.join(os.path.dirname(project_root), CUSTOM_MATCHERS_PATH),
    ]:
        if os.path.isfile(candidate):
            try:
                with open(candidate, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                matchers = data.get('custom_matchers', []) if isinstance(data, dict) else data
                return [m for m in matchers if 'slug' in m and 'patterns' in m]
            except (json.JSONDecodeError, IOError):
                pass
    return []


def set_project_context(info_path: str = None) -> None:
    """Load INFO.md project context to enhance matcher accuracy."""
    global PROJECT_CONTEXT_PATTERS, PROJECT_AUTH_PRIMITIVES, PROJECT_THREAT_HIGHLIGHTS

    if not info_path:
        # Auto-discover INFO.md in project data dir or root
        candidates = [
            'deepsec-info.md',
            'project-info.md',
            '.deepsec-info.md',
        ]
        for name in candidates:
            if os.path.isfile(name):
                info_path = name
                break

    if not info_path or not os.path.isfile(info_path):
        return

    try:
        with open(info_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Extract auth primitives (patterns like `withAuth`, `requireLogin`, etc.)
        for line in content.split('\n'):
            line = line.strip().strip('-*`).').strip()
            if re.search(r'^(?:auth|verify|require|check|guard|authorize|permit)\w*\(', line, re.IGNORECASE):
                m = re.search(r'(\w+(?:\.\w+)*)', line)
                if m:
                    PROJECT_AUTH_PRIMITIVES.append(m.group(1))

        # Extract project-specific threat patterns (lines like "Flag X in file Y")
        for line in content.split('\n'):
            m = re.search(r'(?:flag|warn|check)\s+[\-:"\'](.{5,80})[\-:"\']', line, re.IGNORECASE)
            if m:
                PROJECT_THREAT_HIGHLIGHTS.append(m.group(1))

        # Extract any custom regex patterns embedded as comments (//deepsec:pattern ...)
        for line in content.split('\n'):
            m = re.search(r'//deepsec:pattern\s*\(\s*["\'](.+?)["\'],\s*["\'](.+?)["\']\s*\)', line)
            if m:
                slug, pattern = m.group(1), m.group(2)
                PROJECT_CONTEXT_PATTERS.append({
                    'slug': f'custom:{slug}',
                    'noise_tier': 'precise',
                    'description': f'[PROJECT CONTEXT] {slug}',
                    'patterns': [(pattern, re.IGNORECASE)],
                })

    except IOError:
        pass


def get_project_context_summary() -> Dict[str, Any]:
    """Return loaded context info for reporting."""
    return {
        'auth_primitives': PROJECT_AUTH_PRIMITIVES[:10],
        'threat_highlights': PROJECT_THREAT_HIGHLIGHTS[:5],
        'custom_patterns_count': len(PROJECT_CONTEXT_PATTERS),
    }

# ==================== Tech Detection (sentinel files) ====================
# Mapping from sentinel file content -> tech tags
TECH_DETECTION_RULES: List[Tuple[str, str, Optional[re.Pattern]]] = [
    # Node.js / TypeScript
    ('package.json', 'nextjs', re.compile(r'"next"\s*:', re.IGNORECASE)),
    ('package.json', 'react', re.compile(r'"react"|"react-dom"', re.IGNORECASE)),
    ('package.json', 'express', re.compile(r'"express"', re.IGNORECASE)),
    ('package.json', 'fastify', re.compile(r'"fastify"', re.IGNORECASE)),
    ('package.json', 'nestjs', re.compile(r'"@nestjs/', re.IGNORECASE)),
    ('package.json', 'hono', re.compile(r'"hono"', re.IGNORECASE)),
    ('package.json', 'koa', re.compile(r'"koa"', re.IGNORECASE)),
    ('package.json', 'sveltekit', re.compile(r'"@sveltejs/kit"', re.IGNORECASE)),
    ('package.json', 'nuxt', re.compile(r'"nuxt"', re.IGNORECASE)),
    ('package.json', 'remix', re.compile(r'"@remix-run/', re.IGNORECASE)),
    ('package.json', 'trpc', re.compile(r'"@trpc/', re.IGNORECASE)),
    ('package.json', 'prisma', re.compile(r'"@prisma/client"', re.IGNORECASE)),
    ('package.json', 'drizzle', re.compile(r'"drizzle-orm"', re.IGNORECASE)),
    ('package.json', 'graphql', re.compile(r'"@apollo/server"|"graphql"', re.IGNORECASE)),
    ('package.json', 'socketio', re.compile(r'"socket\.io"', re.IGNORECASE)),
    ('package.json', 'bun', re.compile(r'"bun"', re.IGNORECASE)),
    # Python
    ('manage.py', 'django', None),
    ('requirements.txt', 'django', re.compile(r'^django\b', re.MULTILINE | re.IGNORECASE)),
    ('requirements.txt', 'flask', re.compile(r'^flask\b', re.MULTILINE | re.IGNORECASE)),
    ('requirements.txt', 'fastapi', re.compile(r'^fastapi\b', re.MULTILINE | re.IGNORECASE)),
    ('requirements.txt', 'starlette', re.compile(r'^starlette\b', re.MULTILINE | re.IGNORECASE)),
    ('requirements.txt', 'aiohttp', re.compile(r'^aiohttp\b', re.MULTILINE | re.IGNORECASE)),
    ('requirements.txt', 'tornado', re.compile(r'^tornado\b', re.MULTILINE | re.IGNORECASE)),
    ('pyproject.toml', 'django', re.compile(r'django', re.IGNORECASE)),
    ('pyproject.toml', 'flask', re.compile(r'flask', re.IGNORECASE)),
    ('pyproject.toml', 'fastapi', re.compile(r'fastapi', re.IGNORECASE)),
    # PHP
    ('composer.json', 'laravel', re.compile(r'"laravel/framework|"laravel/"', re.IGNORECASE)),
    ('composer.json', 'symfony', re.compile(r'"symfony/', re.IGNORECASE)),
    ('artisan', 'laravel', None),
    # Ruby
    ('Gemfile', 'rails', re.compile(r'["\']rails["\']|gem ["\']rails["\']', re.IGNORECASE)),
    ('config/routes.rb', 'rails', None),
    # Go
    ('go.mod', 'gin', re.compile(r'github\.com/gin-gonic/gin', re.IGNORECASE)),
    ('go.mod', 'echo', re.compile(r'github\.com/labstack/echo', re.IGNORECASE)),
    ('go.mod', 'fiber', re.compile(r'github\.com/gofiber/fiber', re.IGNORECASE)),
    ('go.mod', 'chi', re.compile(r'github\.com/go-chi/chi', re.IGNORECASE)),
    # Rust
    ('Cargo.toml', 'actix', re.compile(r'actix-web', re.IGNORECASE)),
    ('Cargo.toml', 'axum', re.compile(r'axum', re.IGNORECASE)),
    ('Cargo.toml', 'rocket', re.compile(r'rocket', re.IGNORECASE)),
    # JVM
    ('build.gradle', 'spring', re.compile(r'spring|Spring', re.IGNORECASE)),
    ('pom.xml', 'spring', re.compile(r'spring|Spring', re.IGNORECASE)),
    # .NET
    ('*.csproj', 'dotnet', None),  # checked by name match
    # IaC
    ('Dockerfile*', 'docker', None),
    ('*.tf', 'terraform', None),
    ('.github/workflows/*.yml', 'github-actions', None),
    ('.github/workflows/*.yaml', 'github-actions', None),
]

# Sentinel file name check for specific patterns
SENTINEL_NAME_CHECKS = [
    ('next.config.js', 'nextjs'),
    ('next.config.mjs', 'nextjs'),
    ('next.config.ts', 'nextjs'),
    ('app.json', 'expo'),
]


def detect_technologies(project_root: str) -> Dict[str, bool]:
    """Detect frameworks/technologies by sentinel files.

    Returns a dict of {tech_tag: True} for all detected technologies.
    """
    tags = {}
    root = project_root if os.path.isdir(project_root) else os.path.dirname(project_root)

    # Check sentinel file name patterns
    for pattern, tech in SENTINEL_NAME_CHECKS:
        import fnmatch
        for fname in os.listdir(root):
            if fnmatch.fnmatch(fname, pattern):
                tags[tech] = True

    # Check content-based sentinels
    for filename, tech, regex in TECH_DETECTION_RULES:
        # Handle glob patterns
        if '*' in filename:
            continue
        for fname in os.listdir(root):
            if fname == filename:
                filepath = os.path.join(root, fname)
                if not os.path.isfile(filepath):
                    continue
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except (IOError, PermissionError):
                    continue
                if regex is None or regex.search(content):
                    tags[tech] = True

    # Check Go module files for generic go tag
    for fname in ['go.mod', 'go.sum']:
        filepath = os.path.join(root, fname)
        if os.path.isfile(filepath):
            tags['go'] = True

    return tags


def tech_to_framework_tag(tech: str) -> Optional[str]:
    """Map detected tech tag to framework category for matcher gating."""
    fw_map = {
        # Node.js
        'express': 'js-express', 'fastify': 'js-fastify', 'nestjs': 'js-nestjs',
        'hono': 'js-hono', 'koa': 'js-koa', 'sveltekit': 'js-sveltekit',
        'nuxt': 'js-nuxt', 'remix': 'js-remix', 'nextjs': 'js-nextjs',
        # Python
        'django': 'py-django', 'flask': 'py-flask', 'fastapi': 'py-fastapi',
        'starlette': 'py-starlette', 'aiohttp': 'py-aiohttp', 'tornado': 'py-tornado',
        # PHP
        'laravel': 'php-laravel', 'symfony': 'php-symfony',
        # Ruby
        'rails': 'rb-rails',
        # Go
        'gin': 'go-gin', 'echo': 'go-echo', 'fiber': 'go-fiber', 'chi': 'go-chi',
    }
    return fw_map.get(tech)


# ==================== Generic Matchers (always-on, language-agnostic patterns) ====================

GENERIC_MATCHERS: List[Dict[str, Any]] = [
    # --- SQL Injection ---
    {
        'slug': 'sql-injection-generic',
        'noise_tier': 'precise',
        'description': 'Raw SQL string concatenation/interpolation (language-agnostic)',
        'patterns': [
            (r'\b(SELECT|INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM)\b.*\+', re.IGNORECASE),   # string concat
            (r"\b(SELECT|INSERT|UPDATE|DELETE)\b.*\\'", re.IGNORECASE),  # escaped quote in SQL
            (r'\bx?\?rawUnsafe|\.\x?raw\b', 0),        # prisma/raw APIs
            (r'(?:executeQuery|queryRaw|sql\.raw|DB::raw)\s*\(', re.IGNORECASE),  # raw query methods
            (r'[uf]str\(.*?\b(SELECT|INSERT|UPDATE|DELETE)\b', re.IGNORECASE),   # f-string SQL
            (r'"[^"]*(?:SELECT|INSERT|UPDATE|DELETE)[^"]*"\s*\+\s*\w+', re.IGNORECASE),  # "SQL" + var
        ],
    },
    # --- SSRF ---
    {
        'slug': 'ssrf-generic',
        'noise_tier': 'normal',
        'description': 'User-controlled URL construction (SSRF)',
        'patterns': [
            (r'(?:requests\.get|requests\.post|fetch|curl_exec|file_get_contents)\s*\(\s*(?:\$|\w+\+|req|param|url|uri)', re.IGNORECASE),
            (r'(?:URL|Http(?:Client|Request)|WebClient)\b.*\+\s*(?:user|input|req|param|query|arg)', re.IGNORECASE),
            (r'\brequests\.(get|post|put|delete)\s*\([^)]*url\s*[=:]\s*[^"\']', re.IGNORECASE),
            # gopher/dict/ldap file protocols for SSRF
            (r'file:///|gopher://|dict://|ldap://', re.IGNORECASE),
        ],
    },
    # --- Path Traversal ---
    {
        'slug': 'path-traversal-generic',
        'noise_tier': 'normal',
        'description': 'Path traversal via user input',
        'patterns': [
            (r'(?:__dirname|baseDir|rootDir)\s*\+\s*.*(?:req|param|query|input|user)', re.IGNORECASE),
            (r'path\.(?:join|resolve)\s*\(.*\$.*\.', re.IGNORECASE),  # JS path.join with template literal
            (r'(?:open|readFile|writeFile|fopen)\s*\([^)]*\.\.', re.IGNORECASE),
            # Classic traversal patterns (already in file_analyzer, but included for completeness)
            (r'\.\./{1,3}|\.\.\\{1,3}', 0),
        ],
    },
    # --- XSS ---
    {
        'slug': 'xss-generic',
        'noise_tier': 'normal',
        'description': 'Potential XSS output sinks',
        'patterns': [
            (r'\.innerHTML\s*=', 0),
            (r'dangerouslySetInnerHTML', 0),
            (r'\.outerHTML\s*=', 0),
            (r'document\.write\s*\(', re.IGNORECASE),
            (r'setTimeout\s*\(\s*(?:function|"|\')', 0),   # setTimeout(string) = eval
            (r'eval\s*\(', 0),  # catch-all for eval (covered by DANGEROUS_PATTERNS too)
            (r'render_template_string|mark_safe|html_safe', re.IGNORECASE),  # template injection / XSS helpers
            (r'\{\{.*\}\}', re.IGNORECASE),   # Mustache/EJS templating output
        ],
    },
    # --- Command Injection ---
    {
        'slug': 'rce-generic',
        'noise_tier': 'normal',
        'description': 'Command execution with potential user input',
        'patterns': [
            (r'(?:system|popen|exec\(|passthru|proc_open|shell_exec)\s*\([^)]*[^\\]', re.IGNORECASE),
            # Backtick command substitution
            (r'`[^`]*\$\(.*?\)[^`]*`', re.IGNORECASE),
            # PHP eval/exec
            (r'\beval\s*\(\s*\$|\bexec\s*\(\s*\$', re.IGNORECASE),
        ],
    },
    # --- Unsafe Deserialization ---
    {
        'slug': 'unsafe-deserialization-generic',
        'noise_tier': 'precise',
        'description': 'Unsafe deserialization (RCE via serialized data)',
        'patterns': [
            (r'\bpickle\.(?:load|loads)\s*\(', 0),
            (r'\bunserialize\s*\(\s*\$|\bunserialize\s*\(.*(?:req|param|input)', re.IGNORECASE),
            (r'ObjectInputStream\s*\(', 0),
            (r'yaml\.unsafe_load|yaml\.safe_load', re.IGNORECASE),
            (r'serialVersionUID\s*(?:=)?\s*\d+', 0),   # Java serialization
        ],
    },
    # --- Open Redirect ---
    {
        'slug': 'open-redirect-generic',
        'noise_tier': 'normal',
        'description': 'Open redirect via user-controlled URLs',
        'patterns': [
            (r'(?:redirect|resp\.redirect|response\.redirect)\s*\(\s*(?:\$|\w+\+|req|param|url)', re.IGNORECASE),
            (r'location\.(?:assign|replace|href)\s*=\s*(?:\$|\.\.|request|params)', re.IGNORECASE),
            (r'\.redirect\s*\(\s*["\']?\s*\.', re.IGNORECASE),   # Express res.redirect with var
        ],
    },
    # --- CORS Wildcard ---
    {
        'slug': 'cors-wildcard-generic',
        'noise_tier': 'normal',
        'description': 'CORS misconfiguration (wildcard origin)',
        'patterns': [
            (r'"*Origin"\s*[=:]\s*["\']?\*', re.IGNORECASE),
            (r'Access-Control-Allow-Origin\s*:\s*\*', 0),
            (r'\.origin\s*===\s*(?:req|request)\.header', re.IGNORECASE),   # Reflecting Origin header
            (r'respond_with\(\{.*allow_origin.*\*\}', re.IGNORECASE),
        ],
    },
    # --- Secret Exposure in Code/Logs/Fallback ---
    {
        'slug': 'secret-env-var-generic',
        'noise_tier': 'normal',
        'description': 'Secrets exposed via env var access or logging',
        'patterns': [
            (r'process\.env\.(?:PASSWORD|SECRET|API_KEY|TOKEN|AUTH)', re.IGNORECASE),
            (r'os\.environ\s*\[\s*["\'](?:PASS|SECRET|KEY|TOKEN)', re.IGNORECASE),
            (r'\.getenv\s*\(\s*["\'](?:PASS|SECRET|KEY|TOKEN)', re.IGNORECASE),
            (r'ENV\[["\']?(?:PASSWORD|SECRET_KEY|API_KEY)', re.IGNORECASE),  # Ruby/envy
            (r'(?:console\.log|logger\.info|logging\.)\s*(?:.*password|.*secret|.*token)', re.IGNORECASE),
        ],
    },
    # --- Security Behind Flag / Feature Toggle ---
    {
        'slug': 'security-behind-flag-generic',
        'noise_tier': 'normal',
        'description': 'Security controls gated by environment flags or feature toggles',
        'patterns': [
            (r'(?:NODE_ENV|DEBUG|ENABLE_DEBUG)\s*(!==?|===?)\s*["\'](?:production|prod)', re.IGNORECASE),
            (r'disabled?\s*\(\s*(?:process\.env|config|env)\b.*(?:security|auth|csrf|cors)', re.IGNORECASE),
            (r'# TODO.*fix.*(security|auth|csrf|csp|cors)', re.IGNORECASE),
            (r'// FIXME.*security', re.IGNORECASE),
        ],
    },
    # --- Missing Auth / Public Endpoint ---
    {
        'slug': 'missing-auth-generic',
        'noise_tier': 'normal',
        'description': 'Endpoints/routes potentially missing authentication',
        'patterns': [
            (r'@(?:csrf_exempt|anonymous|permit_any|public)', re.IGNORECASE),  # Django/Flask/FastAPI
            (r'skip_before_action|skip_before_filter', re.IGNORECASE),   # Rails
            (r'WithoutFilter\s*\(\s*(?:VerifyAuth|RequireLogin|IsAuthenticated)', re.IGNORECASE),  # Laravel
            (r'\.allow_anonymous|\.AllowAnonymous\b', re.IGNORECASE),    # ASP.NET
            (r'@Public\(\)|#[^\n]*public.*access', re.IGNORECASE),   # NestJS/GraphQL
        ],
    },
    # --- Insecure Crypto ---
    {
        'slug': 'insecure-crypto-generic',
        'noise_tier': 'precise',
        'description': 'Insecure cryptographic usage',
        'patterns': [
            (r'(?:md5|sha1)\s*\(', re.IGNORECASE),   # MD5/SHA1 usage
            (r'"(?:md5|sha1|DES|RC4|AES-CBC)"', re.IGNORECASE),  # weak algorithm names
            (r'createHash\s*\(\s*["\']md5["\']|createHash\s*\(\s*["\']sha1["\']', re.IGNORECASE),  # Node crypto
            (r'md5\(.*password|hashlib\.md5\(', re.IGNORECASE),
            (r'random\.Random|Math\.random|rand\(\)', re.IGNORECASE),   # Non-crypto RNG for security
            (r'iv\s*=\s*(?:null|None|0x00|"|"")', re.IGNORECASE),   # Zero/nill IV
        ],
    },
    # --- Unverified Lookup / Prototype Pollution ---
    {
        'slug': 'unverified-lookup-generic',
        'noise_tier': 'normal',
        'description': 'Untrusted property access (prototype pollution)',
        'patterns': [
            (r'\.extend\s*\(\s*(?:req|body|params|query)\b', re.IGNORECASE),  # lodash extend with user input
            (r'\.merge\s*\([^)]*\|\|\s*(?:req|body)', re.IGNORECASE),
            (r'Object\.assign\s*\([^,]+,\s*(?:req|params|query|body)', re.IGNORECASE),
            (r'\[["\']?(?:__proto__|constructor|prototype)["\']?\]', re.IGNORECASE),
        ],
    },
    # --- Unsafe HTML / dangerous innerHTML ---
    {
        'slug': 'dangerous-html-generic',
        'noise_tier': 'normal',
        'description': 'Dangerous HTML output sink',
        'patterns': [
            (r'document\.writeln\s*\(', re.IGNORECASE),
            (r'\.insertAdjacentHTML\s*\(', 0),
            (r'<[^>]*\{.*\}', 0),   # JSX with potentially unescaped content
            (r'v-html\s*=', re.IGNORECASE),   # Vue v-html directive
        ],
    },
    # --- Session Cookie Misconfiguration ---
    {
        'slug': 'session-cookie-config-generic',
        'noise_tier': 'precise',
        'description': 'Insecure session cookie configuration',
        'patterns': [
            (r'cookie\s*\(\s*[^)]*\bsecure\s*:\s*false\b', re.IGNORECASE),
            (r'session_cookie_samesite\s*=\s*(?:None|""|\')', re.IGNORECASE),
            (r'secure\s*=\s*False\s*,.*httponly\s*=\s*False', re.IGNORECASE),
        ],
    },
    # --- Error/Message Leak ---
    {
        'slug': 'error-message-leak-generic',
        'noise_tier': 'normal',
        'description': 'Error details exposed to client',
        'patterns': [
            (r'response\.send\s*\(\s*err|response\.json\s*\(\s*err', re.IGNORECASE),
            (r'send\(\s*(?:error|err)\.message\s*\)', re.IGNORECASE),
            (r'try\s*\{[^}]*except\s+.*:\s*raise\s+\1|print\(error', re.IGNORECASE),
        ],
    },
]

# ==================== Framework-specific Matchers ====================

FRAMEWORK_MATCHERS: List[Dict[str, Any]] = [
    # --- Express/Fastify/NestJS ---
    {
        'slug': 'js-express-route',
        'noise_tier': 'normal',
        'requires_tech': ['express'],
        'description': 'Express route handler with potential unvalidated input',
        'patterns': [
            (r'\b(app|router)\.(get|post|put|delete|patch)\s*\([^)]*req\b', re.IGNORECASE),
            (r'response\.(?:get|post|put|delete)\s*\(.*\b(req|params|body|query)\b', re.IGNORECASE),
        ],
    },
    {
        'slug': 'js-fastify-route',
        'noise_tier': 'normal',
        'requires_tech': ['fastify'],
        'description': 'Fastify route handler without preHandler auth',
        'patterns': [
            (r'\.route\s*\([^)]*method\s*:\s*(?:GET|POST|PUT|DELETE)', re.IGNORECASE),
            (r'fastify\.get\s*\(|fastify\.post\s*\(', re.IGNORECASE),
        ],
    },
    {
        'slug': 'js-nestjs-controller',
        'noise_tier': 'normal',
        'requires_tech': ['nestjs'],
        'description': 'NestJS controller method without @UseGuards',
        'patterns': [
            (r'@(?:Get|Post|Put|Delete|Patch)\s*\(', re.IGNORECASE),
            (r'@Body\s*\(\)', 0),
            # Controller without guards check
            (r'class\s+\w+Controller', re.IGNORECASE),
        ],
    },
    {
        'slug': 'js-hono-route',
        'noise_tier': 'normal',
        'requires_tech': ['hono'],
        'description': 'Hono route without middleware auth',
        'patterns': [
            (r'\.get\s*\(|\.post\s*\(', re.IGNORECASE),  # Hono-style routes
            (r'hono\s*:\s*.*new\s+Hono', re.IGNORECASE),
        ],
    },
    # --- Next.js ---
    {
        'slug': 'nextjs-middleware-auth',
        'noise_tier': 'normal',
        'requires_tech': ['nextjs'],
        'description': 'Next.js middleware/auth boundary issues',
        'patterns': [
            (r'export\s+default\s+middleware|export\s+function\s+middleware\b', re.IGNORECASE),
            (r'middleware\(\s*(req|request)\s*\)', re.IGNORECASE),
            (r'"use\s*server"\s*;', re.IGNORECASE),  # Server action boundary
        ],
    },
    {
        'slug': 'nextjs-server-action',
        'noise_tier': 'normal',
        'requires_tech': ['nextjs'],
        'description': 'Next.js Server Action without auth check',
        'patterns': [
            (r'"use\s*server"\s*\n[\s\S]*?export\s+(async\s+)?function\s+', re.IGNORECASE),
            (r'serverActions\.enable\(\)', re.IGNORECASE),
        ],
    },
    {
        'slug': 'nextjs-edge-sandbox',
        'noise_tier': 'precise',
        'requires_tech': ['nextjs'],
        'description': 'Next.js Edge Runtime sandbox boundary trust issue',
        'patterns': [
            (r'runtime\s*:\s*["\']edge["\']', re.IGNORECASE),
        ],
    },
    # --- Django / DRF ---
    {
        'slug': 'py-django-view',
        'noise_tier': 'normal',
        'requires_tech': ['django'],
        'description': 'Django view with CSRF exemption or raw SQL',
        'patterns': [
            (r'@csrf_exempt|@csrf_protect\s*\(\s*False', re.IGNORECASE),
            (r'ModelForm\s*\(\)', 0),   # mass assignment via ModelForm
            (r'\.raw\s*\(|\.extra\s*\(', re.IGNORECASE),  # Django raw SQL
            (r'DEBUG\s*=\s*True', re.IGNORECASE),  # Django debug mode
            (r'ALLOWED_HOSTS\s*=\s*\[\s*\]', re.IGNORECASE),  # Empty allowed hosts
        ],
    },
    {
        'slug': 'py-drf-permission-gap',
        'noise_tier': 'normal',
        'requires_tech': ['djangorestframework'],
        'description': 'DRF viewset with permission_classes gap or wildcard',
        'patterns': [
            (r'permission_classes\s*=\s*\[\s*(AllowAny|IsAuthenticatedOrReadOnly)', re.IGNORECASE),
            (r'@api_view\s*\([^)]*\]', re.IGNORECASE),  #@api_view decorator without permissions
        ],
    },
    # --- Flask ---
    {
        'slug': 'py-flask-route',
        'noise_tier': 'normal',
        'requires_tech': ['flask'],
        'description': 'Flask route with SSTI or raw SQL risk',
        'patterns': [
            (r'@app\.route\s*\([^)]*\)', re.IGNORECASE),
            (r'render_template_string\s*\(', re.IGNORECASE),  # Jinja2 SSTI
            (r'secret_key\s*=\s*["\']?\w+', re.IGNORECASE),   # hardcoded secret_key
        ],
    },
    # --- FastAPI ---
    {
        'slug': 'py-fastapi-route',
        'noise_tier': 'normal',
        'requires_tech': ['fastapi'],
        'description': 'FastAPI route without Depends auth dependency',
        'patterns': [
            (r'@router\.(?:get|post|put|delete|patch)\s*\(', re.IGNORECASE),
            (r'def\s+\w+\s*\(.*req\b|async def\s+\w+\s*\(.*request\b', re.IGNORECASE),
        ],
    },
    # --- Laravel ---
    {
        'slug': 'php-laravel-route',
        'noise_tier': 'normal',
        'requires_tech': ['laravel'],
        'description': 'Laravel controller with mass assignment or raw SQL risk',
        'patterns': [
            (r'\$request\s*->\s*all\s*\(\s*\)', re.IGNORECASE),  # mass assignment
            (r'DB::(?:raw|whereRaw)\s*\(', re.IGNORECASE),   # raw SQL in Laravel
            (r'@csrf_exempt|VerifyCsrfToken.*except', re.IGNORECASE),
            (r'\{!!\s*.*!!\}', 0),   # Blade XSS
        ],
    },
    # --- Rails ---
    {
        'slug': 'rb-rails-controller',
        'noise_tier': 'normal',
        'requires_tech': ['rails'],
        'description': 'Rails controller with skipped auth or unsafe HTML',
        'patterns': [
            (r'skip_before_action\s*:authenticate_user!', re.IGNORECASE),
            (r'strong_parameters|permit\s*\(.*all\s*\)', re.IGNORECASE),
            (r'\.html_safe\b', 0),
            (r'raw\s*\(', re.IGNORECASE),
        ],
    },
    # --- Go frameworks ---
    {
        'slug': 'go-gin-route',
        'noise_tier': 'normal',
        'requires_tech': ['gin'],
        'description': 'Gin route handler with middleware ordering risk',
        'patterns': [
            (r'\.(?:GET|POST|PUT|DELETE|PATCH)\s*\(\s*["\']/', re.IGNORECASE),
            (r'c\.Query\s*\(|c\.Param\s*\(', re.IGNORECASE),  # Trust query params without validation
        ],
    },
    {
        'slug': 'go-echo-route',
        'noise_tier': 'normal',
        'requires_tech': ['echo'],
        'description': 'Echo route handler binding risk',
        'patterns': [
            (r'e\.(?:GET|POST|PUT|DELETE)\s*\(\s*["\']/', re.IGNORECASE),
            (r'c\.Bind\s*\(', 0),   # c.Bind trust without validation
        ],
    },
    {
        'slug': 'go-fiber-route',
        'noise_tier': 'normal',
        'requires_tech': ['fiber'],
        'description': 'Fiber route handler with fasthttp body lifetime issue',
        'patterns': [
            (r'app\.(?:Get|Post|Put|Delete)\s*\(\s*["\']/', re.IGNORECASE),
        ],
    },
]

# ==================== IaC Matchers ====================

IAC_MATCHERS: List[Dict[str, Any]] = [
    # --- Dockerfile ---
    {
        'slug': 'dockerfile-mutable-tag',
        'noise_tier': 'precise',
        'description': 'Docker image using mutable tag (latest/unpinned)',
        'patterns': [
            (r'FROM\s+(?:[\w\-\./]+:)?(latest|unstable|dev|nightly)\b', re.IGNORECASE),
            (r'FROM\s+[\w\-/]+\s*\n(?!\s*AS)\s+', 0),   # No tag specified after FROM
        ],
    },
    {
        'slug': 'dockerfile-run-as-root',
        'noise_tier': 'precise',
        'description': 'Docker container running as root user',
        'patterns': [
            (r'USER\s+root\b', 0),
            (r'USER\s+0\b', 0),
            # Missing USER directive entirely in final stage (detected separately)
        ],
    },
    {
        'slug': 'dockerfile-curl-pipe',
        'noise_tier': 'normal',
        'description': 'Unverified script piped from curl/wget',
        'patterns': [
            (r'curl.*\|\s*(?:bash|sh)\b', re.IGNORECASE),
            (r'wget.*-O\s*-\s*\|\s*(?:bash|sh)', re.IGNORECASE),
        ],
    },
    # --- Terraform ---
    {
        'slug': 'tf-iam-wildcard',
        'noise_tier': 'precise',
        'description': 'Terraform IAM policy with wildcard permissions',
        'patterns': [
            (r'"Action"\s*:\s*\*|"Action"\s*:\s*\["\*"|"action"\s*:\s*\*', re.IGNORECASE),
            (r'"Resource"\s*:\s*\*|"resource"\s*:\s*\["\*"', re.IGNORECASE),
        ],
    },
    {
        'slug': 'tf-secret-in-data',
        'noise_tier': 'precise',
        'description': 'Secret stored in Terraform data source (not state-protected)',
        'patterns': [
            (r'type\s*=\s*"aws_db_instance"|data\s*"db_instance"', re.IGNORECASE),
            (r'data\s*\(\s*"vault_(?:static|generic)_secret"\s*\)', re.IGNORECASE),
        ],
    },
    {
        'slug': 'tf-encryption-missing',
        'noise_tier': 'normal',
        'description': 'Terraform resource without encryption enabled',
        'patterns': [
            (r'type\s*=\s*"aws_s3_bucket"|type\s*=\s*"aws_rds"\|"ebs"', re.IGNORECASE),
            # Check for missing kms_key / server_side_encryption in the same block
        ],
    },
    {
        'slug': 'tf-public-ingress',
        'noise_tier': 'precise',
        'description': 'Terraform security group allowing public ingress on sensitive ports',
        'patterns': [
            (r'cidr_blocks\s*=\s*\[\s*"0\.0\.0\.0/0"\s*\].*?:\s*\b(22|3389)\b', re.IGNORECASE),
            (r'to\s*=\s*(?:22|3389).+cidr.*0\.0\.0\.0', re.IGNORECASE),
        ],
    },
    # --- GitHub Actions ---
    {
        'slug': 'github-workflow-injection',
        'noise_tier': 'normal',
        'description': 'GitHub Action workflow with potential injection vector',
        'patterns': [
            (r'\$\{\{.*(?:github\.event\.(?:head_commit|comment|pull_request)', re.IGNORECASE),
            (r'contents:\s*write\b|actions:\s*write\b', re.IGNORECASE),
            (r'allow_forking\s*:\s*(?:true|"true")', re.IGNORECASE),
        ],
    },
]

# ==================== ORM-specific Matchers ====================

ORM_MATCHERS: List[Dict[str, Any]] = [
    {
        'slug': 'orm-prisma-raw-sql',
        'noise_tier': 'precise',
        'description': 'Prisma $queryRawUnsafe or raw SQL bypass',
        'patterns': [
            (r'\$queryRawUnsafe\s*\(', re.IGNORECASE),
            (r'\$executeRawUnsafe\s*\(', re.IGNORECASE),
        ],
    },
    {
        'slug': 'orm-drizzle-raw-sql',
        'noise_tier': 'precise',
        'description': 'Drizzle raw SQL injection risk',
        'patterns': [
            (r'drizzle.*sql\`|sql\s*`\s*(?:SELECT|INSERT|UPDATE|DELETE)', re.IGNORECASE),
        ],
    },
    {
        'slug': 'orm-sqlalchemy-raw',
        'noise_tier': 'normal',
        'description': 'SQLAlchemy text() or exec with user input',
        'patterns': [
            (r'text\s*\(\s*(?:f["\']|%)', re.IGNORECASE),
            (r'\.execute\s*\(.*text\s*\(', re.IGNORECASE),
        ],
    },
    {
        'slug': 'orm-django-raw-sql',
        'noise_tier': 'normal',
        'description': 'Django extra()/raw() with unvalidated input',
        'patterns': [
            (r'\.extra\s*\(.*\b(SELECT|WHERE|FROM)\b', re.IGNORECASE),
            (r'\.raw\s*\(.*f["\']', re.IGNORECASE),
        ],
    },
    {
        'slug': 'orm-laravel-raw-sql',
        'noise_tier': 'normal',
        'description': 'Laravel DB::raw/whereRaw with unvalidated input',
        'patterns': [
            (r'DB::\w*Raw\s*\(\s*(?:\$|f["\'])', re.IGNORECASE),
            (r'whereRaw\s*\(\s*(?:\$|f["\'])', re.IGNORECASE),
        ],
    },
    # --- NoSQL injection ---
    {
        'slug': 'nosql-injection-generic',
        'noise_tier': 'normal',
        'description': 'NoSQL injection via direct object merging',
        'patterns': [
            (r'\.find\s*\(\s*(?:req|body|params|query)\b', re.IGNORECASE),
            (r'MongoClient.*\.insertOne\s*\(.*\+\s*', re.IGNORECASE),
            (r'ObjectIds?\s*\(\s*\$(?:gt|ne|eq)', re.IGNORECASE),  # $gt/$ne injection
        ],
    },
]


# ==================== DeepsecMatcherEngine ====================

class DeepsecMatcherEngine:
    """Wrapper around all deepsec matcher categories with deduplication and scoring."""

    def __init__(self, project_root: str):
        self.project_root = os.path.abspath(project_root)
        self._tech_tags: Dict[str, bool] = {}
        self._custom_matchers: List[Dict[str, Any]] = []

    def detect_technologies(self) -> Dict[str, bool]:
        """Detect technologies/frameworks in the project."""
        self._tech_tags = detect_technologies(self.project_root)
        # Also load custom matchers when tech detection runs
        self._custom_matchers = load_custom_matchers(self.project_root)
        return self._tech_tags

    @property
    def tech_tags(self) -> Dict[str, bool]:
        if not self._tech_tags:
            self.detect_technologies()
        return self._tech_tags

    def scan(
        self,
        noise_tiers: Optional[List[str]] = None,
        dedup: bool = True,
    ) -> List[Dict[str, Any]]:
        """Run all matchers and return findings.

        Args:
            noise_tiers: Which tiers to run. Defaults to ['precise', 'normal'].
                        Use ['precise', 'normal', 'noisy'] for full scan.
            dedup: Deduplicate findings by (slug, file_path, line_number). Default True.
        """
        if noise_tiers is None:
            noise_tiers = ['precise', 'normal']

        all_findings = []

        # Run generic matchers (always-on)
        for matcher in GENERIC_MATCHERS:
            if matcher['noise_tier'] not in noise_tiers:
                continue
            results = self._match_patterns(matcher, None)
            all_findings.extend(results)

        # Run framework-specific matchers (gate by tech detection)
        for matcher in FRAMEWORK_MATCHERS:
            if matcher['noise_tier'] not in noise_tiers:
                continue
            requires = matcher.get('requires_tech', [])
            # Check if any required tech is detected
            if requires and not any(self.tech_tags.get(t, False) for t in requires):
                continue
            results = self._match_patterns(matcher, None)
            all_findings.extend(results)

        # Run IaC matchers (only if IaC files exist)
        has_iac = any(
            self.tech_tags.get(t, False) for t in ['docker', 'terraform', 'github-actions']
        ) or self._check_iac_files()
        if has_iac:
            for matcher in IAC_MATCHERS:
                if matcher['noise_tier'] not in noise_tiers:
                    continue
                results = self._match_patterns(matcher, None)
                all_findings.extend(results)

        # Run ORM matchers (only if relevant tech detected)
        orm_techs = {'prisma', 'drizzle', 'django', 'flask', 'fastapi'}
        has_orm = any(self.tech_tags.get(t, False) for t in orm_techs)
        if has_orm or self._has_python_files() or self._has_js_files():
            for matcher in ORM_MATCHERS:
                if matcher['noise_tier'] not in noise_tiers:
                    continue
                results = self._match_patterns(matcher, None)
                all_findings.extend(results)

        # Run custom matchers (loaded from deepsec-custom.json)
        if self._custom_matchers:
            for matcher in self._custom_matchers:
                if matcher.get('noise_tier', 'normal') not in noise_tiers:
                    continue
                results = self._match_patterns(matcher, None)
                all_findings.extend(results)

        # Run INFO.md context patterns
        if PROJECT_CONTEXT_PATTERS:
            for matcher in PROJECT_CONTEXT_PATTERS:
                results = self._match_patterns(matcher, None)
                all_findings.extend(results)

        # Deduplicate by (vuln_slug, file_path, line_number), keeping highest severity
        if dedup and all_findings:
            seen = {}
            for f in all_findings:
                key = (f['vuln_slug'], f['file_path'], f['line_number'])
                sev_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
                if key not in seen or sev_order.get(f['severity'], 5) < sev_order.get(seen[key]['severity'], 5):
                    seen[key] = f
            all_findings = list(seen.values())

        # Score each finding: +1 for each additional matcher that flags it (confidence boost)
        if dedup and all_findings:
            slug_files = {}
            for f in all_findings:
                k = (f['vuln_slug'], f['file_path'])
                slug_files.setdefault(k, []).append(f)
            # Find multi-slug hits (same file+line by different matchers — keep those, they're higher confidence)
            self._multi_hit_boost(all_findings)

        return all_findings

    @staticmethod
    def _sev_priority(sev: str) -> int:
        """Lower = more severe."""
        return {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}.get(sev, 5)

    def _multi_hit_boost(self, findings: List[Dict[str, Any]]) -> None:
        """Boost severity for findings flagged by multiple distinct matcher categories."""
        loc_matchers: Dict[tuple, set] = {}
        for f in findings:
            key = (f['file_path'], f['line_number'])
            loc_matchers.setdefault(key, set()).add(f['vuln_slug'])

        for f in findings:
            key = (f['file_path'], f['line_number'])
            n_slugs = len(loc_matchers.get(key, set()))
            if n_slugs >= 3 and self._sev_priority('high') < self._sev_priority(f['severity']):
                f['severity'] = 'high'
                f.setdefault('_boosted', False)
            elif n_slugs >= 2 and self._sev_priority('medium') < self._sev_priority(f['severity']):
                f['severity'] = 'medium'
                f.setdefault('_boosted', False)

    def _check_iac_files(self) -> bool:
        """Check for IaC files at project root."""
        root = self.project_root
        if not os.path.isdir(root):
            return False
        iac_names = ['Dockerfile', 'docker-compose.yml', 'docker-compose.yaml']
        tf_dirs = ['terraform']
        for name in iac_names:
            if any(os.path.isfile(os.path.join(root, f)) for f in [name] +
                   [f'{name}.{ext}' for ext in ['example', 'dev', 'prod', 'staging', 'test']]):
                return True
        for d in tf_dirs:
            dpath = os.path.join(root, d)
            if os.path.isdir(dpath):
                for _, _, files in os.walk(dpath):
                    if any(f.endswith('.tf') for f in files):
                        return True
        # GitHub Actions
        gh_path = os.path.join(root, '.github', 'workflows')
        if os.path.isdir(gh_path):
            for fname in os.listdir(gh_path):
                if fname.endswith(('.yml', '.yaml')):
                    return True
        return False

    def _has_python_files(self) -> bool:
        root = self.project_root
        if not os.path.isdir(root):
            return False
        for _, _, files in os.walk(root):
            for f in files:
                if f.endswith(('.py', '.pyx')):
                    return True
        return False

    def _has_js_files(self) -> bool:
        root = self.project_root
        if not os.path.isdir(root):
            return False
        for _, _, files in os.walk(root):
            for f in files:
                if f.endswith(('.js', '.ts', '.jsx', '.tsx')):
                    return True
        return False

    def _match_patterns(self, matcher: Dict, content_cache: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """Match patterns against all files in project."""
        findings = []
        matched_files = set()  # dedup across patterns

        for root, dirs, files in os.walk(self.project_root):
            skip_dirs = ['.git', 'node_modules', '__pycache__', '.venv', 'venv', 'hack_report']
            dirs[:] = [d for d in dirs if d not in skip_dirs]

            for fname in files:
                fpath = os.path.join(root, fname)

                # Skip binary/large files
                try:
                    if os.path.getsize(fpath) > 2_000_000:
                        continue
                except OSError:
                    continue

                # Check if file is a rule/definition file for this project
                rel_path = os.path.relpath(fpath, self.project_root)

                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except (IOError, PermissionError):
                    continue

                lines = content.split('\n')

                for pattern, flags in matcher['patterns']:
                    try:
                        compiled = re.compile(pattern, flags) if isinstance(flags, int) else re.compile(pattern)
                    except re.error:
                        continue

                    for i, line in enumerate(lines, 1):
                        if compiled.search(line):
                            key = (fpath, i, pattern)
                            if key not in matched_files:
                                matched_files.add(key)
                                findings.append({
                                    'vuln_slug': matcher['slug'],
                                    'description': matcher['description'],
                                    'file_path': fpath,
                                    'line_number': i,
                                    'evidence': line.strip()[:200],
                                    'noise_tier': matcher['noise_tier'],
                                    'severity': self._tier_to_severity(matcher['noise_tier']),
                                })

        return findings

    @staticmethod
    def _tier_to_severity(tier: str) -> str:
        mapping = {
            'precise': 'high',
            'normal': 'medium',
            'noisy': 'low',
        }
        return mapping.get(tier, 'medium')
