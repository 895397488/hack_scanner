#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI 自适应渗透测试入口（实验）
=====================================================================

用真实 LLM 驱动 swarm_orchestrator 的 ReAct 循环，LLM 自主决定
"下一步探测哪个端点、发什么请求"，观察响应后再决策。

    python run_adaptive.py --target https://example.com \
        [--objective "find auth logic flaws"] [--mode full|shallow] \
        [--max-iterations N] [--no-strategy] [--exploit-live]

安全策略:
    - 默认 exploit dry-run；--exploit-live 需交互式输入 yes 二次确认
    - 非本机/非内网目标需授权确认（无 TTY 时拒绝远程目标）
    - scope 白名单 / 限速 / 迭代上限 / 响应截断由 swarm_tool_binders 执行

授权边界: 本框架仅可用于自己拥有或已获书面授权的目标。
"""

import argparse
import ipaddress
import json
import logging
import os
import re
import socket
import sys
from typing import Callable, Optional
from urllib.parse import urlparse

_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from scanners.llm_client import build_llm_invoke, load_ai_config
from scanners.swarm_orchestrator import SwarmOrchestrator
from scanners import swarm_tool_binders as binders

# 无上限迭代（默认）：orchestrator 用 range() 跑循环且要求 >0，
# 给一个足够大的哨兵值即可（Python 3 range 是惰性的，10**9 无副作用）。
UNLIMITED_ITERATIONS = 10 ** 9

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
# 工具层日志降级，避免刷屏；LLM 链路错误保留
logging.getLogger('swarm_tool_binders').setLevel(logging.WARNING)

# ---------------------------------------------------------------------------
# 事件流打印
# ---------------------------------------------------------------------------
_EVENT_ICONS = {
    "thought": "🧠",
    "tool_call": "🔧",
    "tool_result": "📄",
    "milestone": "✅",
    "loop_guard": "⛔",
    "error": "❌",
    "state_change": "🔄",
}


def _safe_print(text: str) -> None:
    """打印兜底：管道/GBK 控制台编码 emoji 失败时降级，不崩。"""
    try:
        print(text, flush=True)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        print(text.encode(enc, "replace").decode(enc, "replace"), flush=True)


def _make_event_sink(collector: list):
    def sink(e: dict) -> None:
        collector.append(e)
        icon = _EVENT_ICONS.get(e.get("event_type"), "•")
        detail = str(e.get("detail") or "").replace("\n", " ")
        if len(detail) > 400:
            detail = detail[:400] + "…"
        _safe_print(f" {icon} [{e.get('event_type')}] {detail}")
    return sink


# ---------------------------------------------------------------------------
# 授权 / 安全门
# ---------------------------------------------------------------------------
def _is_local_target(url: str) -> bool:
    """loopback / 私网 / 链路本地 / 无公网可达性 视为本地目标。"""
    try:
        p = urlparse(url if "//" in url else f"//{url}")
        host = (p.netloc or "").split("@")[-1].split(":")[0].lower()
        if not host:
            return True
        if host in ("localhost", "::1", "0.0.0.0"):
            return True
        if host.endswith((".local", ".internal", ".lan", ".test")):
            return True
        try:
            ip = ipaddress.ip_address(host)
            return (ip.is_loopback or ip.is_private or ip.is_link_local
                    or ip.is_reserved or ip.is_unspecified)
        except ValueError:
            pass
        # 域名：解析后按 IP 判定；解析失败按本地处理（不可达 ≠ 远程攻击）
        try:
            infos = socket.getaddrinfo(host, None)
            ips = {i[4][0] for i in infos}
            return all(
                ipaddress.ip_address(x).is_loopback or ipaddress.ip_address(x).is_private
                or ipaddress.ip_address(x).is_link_local
                for x in ips
            )
        except Exception:
            return True
    except Exception:
        return True


def _require_confirm(prompt: str, expected: str = "yes", interactive: bool = True) -> bool:
    if not interactive:
        return False
    try:
        ans = input(prompt).strip()
    except EOFError:
        return False
    return ans == expected


# ---------------------------------------------------------------------------
# 结果提取
# ---------------------------------------------------------------------------
def install_result_recorder(orch, tool_log: list) -> None:
    """包装每个工具的 execute，把【完整】结果记入 tool_log。

    （orchestrator 只把 result[:200] 存进 state.tool_results，
    完整结果仅存在于消息历史 — 入口层自己记录一份供摘要提取。）
    """
    for name, tool in orch.tools.items():
        orig = tool.execute
        def wrap(args, _orig=orig, _name=name):
            res, err = _orig(args)
            tool_log.append({
                "tool": _name,
                "result": res if isinstance(res, str) else str(res),
                "error": err,
            })
            return res, err
        tool.execute = wrap


def install_strategy_coach(llm_invoke, enabled: bool = True):
    """包装 llm_invoke：【首轮调用前】把零日导向策略块 + few-shot 场景前置进 messages。

    背景（2026-09-14 vuln-sentinel 复盘）: 20 轮全烧在 http_probe×14 的浅探测上，
    产出全是 info/low 垃圾漏洞——根因是系统提示只有生命周期纪律、模型手里
    没有任何攻击先验，27b 级模型拿"find all vulnerabilities"就退化成通用扫描。
    M11 已证明：埋在长 objective 里的提示 27b 直接无视，而【独立醒目消息】
    能被执行（budget warning 就是这么修好的）。策略注入沿用同一机制。

    注入内容（scanners/swarm_strategy.build_injection）:
        [user: 策略块(深度优先/差分探测/高价值链)] [assistant: 确认]
        [user: IDOR 场景] [assistant: 场景A]
        [user: JWT 场景]  [assistant: 场景A]
    结构合法（role 交替），前置到 campaign 启动消息之前。

    orchestrator 零改动：只改传给 llm_invoke 的 messages 副本，
    且仅首轮生效（之后每轮重新注入会污染历史/重复占位）。
    """
    if not enabled:
        return llm_invoke

    try:
        from scanners.swarm_strategy import build_injection
        injection = build_injection()
    except Exception:
        injection = []  # 策略模块异常 → 静默降级为无注入（核心循环不受影响）
    if not injection:
        return llm_invoke

    state = {"used": False}

    def wrapped(*args, **kwargs):
        if not state["used"]:
            state["used"] = True
            if "messages" in kwargs:
                kwargs["messages"] = list(injection) + list(kwargs["messages"] or [])
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = list(injection) + list(new_args[1] or [])
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._injected = state  # 测试用
    return wrapped


def install_budget_guard(llm_invoke, max_iterations: int, warn_remaining: int = 3):
    """包装 llm_invoke：剩余额度 ≤ warn_remaining 时，每轮注入一条强预算警告。

    M7 的 objective 提示太弱（埋在长 objective 里，27b 级模型直接无视，
    把全部迭代烧在探测上）。这里在预算耗尽前每轮追加一条 user 消息，
    强制收敛到 classify → generate_report → finish_scan 生命周期。

    orchestrator 零改动：只改传给 llm_invoke 的 messages 副本，
    注入内容不会污染 orchestrator 的消息历史（每轮重新注入）。
    """
    counter = {"n": 0}

    def wrapped(*args, **kwargs):
        counter["n"] += 1
        remaining = max_iterations - counter["n"] + 1  # 本次调用计入
        if 0 < remaining <= warn_remaining:
            warn = (
                f"⚠️ BUDGET WARNING: only {remaining} iteration(s) remain (including this one). "
                "STOP starting new probes/detectors/exploits. Immediately finish the lifecycle: "
                "1) call classify with your candidate findings; "
                "2) call generate_report; "
                "3) call finish_scan."
            )
            msg = {"role": "user", "content": warn}
            if "messages" in kwargs:
                kwargs["messages"] = list(kwargs["messages"] or []) + [msg]
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = list(new_args[1] or []) + [msg]
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 M1 闭包挂的 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._call_count = counter  # 测试用
    return wrapped


def _salvage_findings(text: str) -> list:
    """救援解析：classify JSON 损坏（被截断/非标准序列化）时按条提取。

    发现以 ``{"title": ..., ...}`` 依序出现；按 "title" 定位条目边界，
    在段内取 severity / cvss_score / confidence。即使最后一条被截断，
    前面的条目仍可恢复——优于整体返回 0 条。
    """
    out = []
    titles = list(re.finditer(r'"title"\s*:\s*"((?:[^"\\]|\\.)*)"', text))
    for i, m in enumerate(titles):
        seg_end = titles[i + 1].start() if i + 1 < len(titles) else min(len(text), m.end() + 2000)
        seg = text[m.end():seg_end]
        sev = re.search(r'"severity"\s*:\s*"([A-Za-z_]+)"', seg)
        cvss = re.search(r'"cvss_score"\s*:\s*([\d.]+)', seg)
        conf = re.search(r'"confidence"\s*:\s*"([A-Za-z_]+)"', seg)
        out.append({
            "title": m.group(1),
            "severity": sev.group(1) if sev else "?",
            "cvss_score": float(cvss.group(1)) if cvss else 0.0,
            "confidence": conf.group(1) if conf else "?",
        })
    return out[:50]


def _extract_findings(tool_log):
    """从最后一次 classify 工具结果提取发现列表。

    返回 ``(findings, status)``：
      ok           JSON 解析成功
      parse_failed classify 被调用但结果无法完整解析（已尽力救援）
      not_called   从未成功调用 classify
    """
    for r in reversed(tool_log or []):
        if r.get("tool") != "classify" or r.get("error"):
            continue
        text = r.get("result", "") or ""
        try:
            data = json.loads(text)
            fs = data.get("findings") or []
            return [f for f in fs if isinstance(f, dict)][:50], "ok"
        except (json.JSONDecodeError, TypeError, ValueError):
            return _salvage_findings(text), "parse_failed"
    return [], "not_called"


def _json_unescape(s: str) -> str:
    """解转义 JSON 字符串值（正则从 JSON 文本抓到的 Windows 路径反斜杠是双写态，还原为单写）。"""
    try:
        return json.loads(f'"{s}"')
    except (json.JSONDecodeError, ValueError):
        return s


def _extract_report_path(tool_log) -> str:
    for r in reversed(tool_log or []):
        if r.get("tool") == "generate_report" and not r.get("error"):
            m = re.search(r'"report_path":\s*"([^"]+)"', r.get("result", ""))
            if m:
                return _json_unescape(m.group(1))
    return ""


def _fallback_report(ctx, findings) -> str:
    """兜底：LLM 未在迭代上限内完成报告阶段时，入口层用 classify 发现补生成报告。

    复用 generate_report binder 的同一代码路径（富报告聚合/落盘/命名），
    避免复制逻辑。返回报告路径（主 HTML），失败返回 ""。
    """
    try:
        tool = binders._make_report(ctx)
        res, err = tool.execute(json.dumps({"findings": findings}, ensure_ascii=False, default=str))
        if err or not res:
            return ""
        m = re.search(r'"report_path":\s*"([^"]+)"', res)
        return _json_unescape(m.group(1)) if m else ""
    except Exception as exc:
        _safe_print(f"⚠️  兜底报告生成失败: {type(exc).__name__}: {str(exc)[:120]}")
        return ""


def _salvage_transcript(tool_log, max_chars: int = 12000) -> str:
    """把工具日志压成紧凑 transcript（每条 ≤400 字符），供收尾提取用。"""
    lines = []
    for r in tool_log or []:
        res = (r.get("result") or "").replace("\n", " ")[:400]
        if r.get("error"):
            res += f" [ERROR: {str(r['error'])[:100]}]"
        lines.append(f"[{r.get('tool')}] {res}")
    return "\n".join(lines)[:max_chars]


def _extract_salvage_findings(llm_invoke, target: str, tool_log) -> list:
    """收尾 salvage：classify 从未被调用时，用一次预算外的 LLM 调用从工具日志提取发现。

    模型自己的分析（不是启发式猜）：把 transcript 喂回去，要求只回 JSON 数组。
    任何失败都返回 []——不阻塞、不崩，主摘要照常打印。
    """
    transcript = _salvage_transcript(tool_log)
    if not transcript.strip():
        return []
    system = (
        "You are a security report extractor. From the scan transcript below, extract "
        "CONFIRMED security findings (information disclosure, publicly exposed sensitive "
        "endpoints, weak security controls, confirmed misconfigurations). "
        "Respond with ONLY a JSON array, no prose. Each element: "
        '{"title": str, "severity": "info|low|medium|high|critical", '
        '"description": str, "evidence": str}. '
        "Return [] if there are no confirmed findings."
    )
    user = (f"Target: {target}\n\nTranscript (truncated):\n{transcript}\n\n"
            "Return the JSON array now.")
    try:
        resp = llm_invoke(system, [{"role": "user", "content": user}], [],
                          max_tokens=2048, temperature=0.0)
    except Exception:
        return []
    if not resp:
        return []
    text = (resp.get("content") or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return [f for f in data if isinstance(f, dict) and f.get("title")][:50]
    except (json.JSONDecodeError, ValueError):
        pass
    # 救援：按 title 边界逐条提取（整体 JSON 损坏时前面条目仍可恢复）
    return _salvage_findings(text)


def _print_summary(state, client, tool_log, report_path: str = "", fallback_used: bool = False,
                   findings_override: list = None, findings_source: str = "classify",
                   salvage_attempted: bool = False) -> None:
    _safe_print("\n" + "=" * 62)
    _safe_print("=== Campaign 结束 ===")
    tool_seq = [r["tool"] for r in tool_log or []]
    _safe_print(f"  工具调用序列: {' → '.join(tool_seq) if tool_seq else '(无)'}")
    _safe_print(f"  状态: {'完成 (finish_scan)' if state.is_complete else '迭代上限/异常终止'}")

    if findings_override is not None:
        findings, fstatus = findings_override, "ok"
    else:
        findings, fstatus = _extract_findings(tool_log)
    src_label = {"classify": "classify 输出", "salvage": "入口层 salvage 提取"}.get(
        findings_source, findings_source)
    _safe_print(f"\n  发现列表（{src_label}，共 {len(findings)} 条）:")
    if findings:
        for f in findings:
            _safe_print(f"    - [{f.get('severity', '?')}] {f.get('title', '?')} "
                        f"(CVSS {f.get('cvss_score', 0)} | {f.get('confidence', '?')})")
    elif fstatus == "ok":
        _safe_print("    (无 — classify 输出 0 条：全部被 FP 过滤或确认真干净)")
    elif fstatus == "not_called":
        if salvage_attempted:
            _safe_print("    (无 — classify 未被调用，收尾 salvage 提取后确认无发现)")
        else:
            _safe_print("    (无 — LLM 未调用 classify 或全部被 FP 过滤)")
    else:
        _safe_print("    (classify 已调用但结果无法解析 — 完整发现以上方报告文件为准)")

    if not report_path:
        report_path = _extract_report_path(tool_log)
    label = "报告（入口层兜底补生成）" if fallback_used else "报告"
    _safe_print(f"\n  {label}: {report_path if report_path else '(未生成)'}")

    if client is not None:
        u = client.usage
        _safe_print(f"  Token 用量: {u.get('calls', 0)} 次调用, "
                    f"prompt={u.get('prompt_tokens', 0)}, "
                    f"completion={u.get('completion_tokens', 0)}")
    _safe_print("=" * 62)


# ---------------------------------------------------------------------------
# 主入口（launcher 复用此函数）
# ---------------------------------------------------------------------------
def run_adaptive(
    target: str,
    objective: str = "find all vulnerabilities",
    mode: str = "full",
    max_iterations: Optional[int] = None,
    exploit_live: bool = False,
    interactive: bool = True,
    llm_invoke_factory: Optional[Callable] = None,
    strategy: bool = True,
) -> int:
    """组装并执行一次自适应 campaign。返回进程退出码（0 正常）。

    max_iterations: 迭代上限；None = 无上限（默认，Ctrl+C 随时可停）。
    llm_invoke_factory: 测试注入点（传假 LLM 工厂，不碰真实 API）。
    strategy: 是否注入零日导向策略块 + few-shot 场景（M12，--no-strategy 关闭）。
    """
    # --- 0. AI 配置检查 ---
    cfg = load_ai_config()
    if not cfg.get("enabled"):
        _safe_print("❌ AI 未启用（config.json ai.enabled != true）。请先运行 init_ai.py 配置模型。")
        return 1
    cap_label = f"{max_iterations}" if max_iterations else "无上限"
    _safe_print(f"🤖 LLM: {cfg.get('provider')} / {cfg.get('model') or '(auto)'} "
                f"| 迭代上限: {cap_label} | 策略: {'零日导向(深度优先+差分探测)' if strategy else 'off'} "
                f"| exploit: {'LIVE' if exploit_live else 'dry-run'}")

    # --- 1. 授权门 ---
    if not _is_local_target(target):
        _safe_print(f"\n⚠️  目标 {target} 疑似公网/非内网地址。")
        _safe_print("   本框架仅可用于【自己拥有或已获书面授权】的目标。")
        if not _require_confirm("\n   确认已获授权？输入 yes 继续: ", "yes", interactive):
            _safe_print("❌ 已取消（未确认授权）。")
            return 1

    # --- 2. exploit-live 二次确认 ---
    if exploit_live and not _require_confirm(
            "\n⚠️  LIVE 模式将真实执行命令（仍受 safe-mode/scope 门控）。输入 yes 确认: ",
            "yes", interactive):
        _safe_print("❌ 已取消（未确认 LIVE 模式）。")
        return 1

    # --- 3. 组装 ---
    llm_invoke = (llm_invoke_factory or build_llm_invoke)()
    client = getattr(llm_invoke, "client", None)
    events: list = []
    tool_log: list = []
    # 策略教练（M12）：首轮前置注入零日导向策略块 + few-shot 场景（入口层包装，orchestrator 零改动）
    llm_coached = install_strategy_coach(llm_invoke, enabled=strategy)
    # 预算守卫：末 warn_remaining 轮每轮注入强警告；轮数按预算比例缩放（20→3、40→4）
    # 无上限时不装——没有预算就没有预算警告（重复动作兜底靠 orchestrator 的 loop_guard）
    if max_iterations:
        warn_remaining = max(3, max_iterations // 10)
        llm_guarded = install_budget_guard(llm_coached, max_iterations, warn_remaining)
    else:
        llm_guarded = llm_coached
    orch = SwarmOrchestrator(
        llm_invoke=llm_guarded,
        max_iterations=max_iterations or UNLIMITED_ITERATIONS,
        event_sink=_make_event_sink(events),
    )
    ctx = binders.register_campaign_tools(orch, target, objective, dry_run=not exploit_live)
    # M14: 富报告数据源 — 指向 recorder 的同一 tool_log（只读消费，零复制）+ 模型信息
    ctx.tool_log = tool_log
    ctx.model_info = f"{cfg.get('provider')}/{cfg.get('model') or '(auto)'}"
    install_result_recorder(orch, tool_log)

    # --- 4. 执行 ---
    # 预算纪律提示：objective 会注入首轮 user 消息（swarm_orchestrator.py:289），
    # 防止小模型把迭代全耗在探测上、没走完 report → finish_scan 生命周期
    campaign_objective = (
        f"{objective}. "
        "IMPORTANT: reserve at least the final 2-3 iterations to call generate_report "
        "and then finish_scan; do not spend the entire iteration budget on probing."
    )
    _safe_print(f"\n🚀 Campaign 开始 | target={target} | objective={objective}\n")
    try:
        state = orch.run_campaign([target], campaign_objective, mode)
    except KeyboardInterrupt:
        _safe_print("\n⛔ 用户中断。")
        state = None

    if state is None:
        return 1
    if any(e.get("event_type") == "error" and "LLM call returned None" in str(e.get("detail", ""))
           for e in events):
        _safe_print("\n❌ LLM 链路失败（详见上方日志）。请检查 Ollama/API 配置。")
        return 1

    # --- 5. 收尾兜底（两层）---
    report_path = _extract_report_path(tool_log)
    fallback_used = False
    findings, fstatus = _extract_findings(tool_log)
    findings_source = "classify"
    salvage_attempted = False

    # 5a. salvage：classify 从未被调用（迭代预算全烧在探测上，vuln-sentinel 2026-09-14 实例）
    #     → 一次预算外的 LLM 调用，从工具日志里提取发现。
    #     注意：classify 被调过但 0 条（FP 过滤/确认真干净）时【不】salvage——尊重分类器裁决。
    if not report_path and fstatus == "not_called":
        _safe_print("\n⚠️  classify 未在迭代预算内完成 — 入口层正在做收尾 salvage 提取（额外 1 次 LLM 调用）…")
        salvage_attempted = True
        salvaged = _extract_salvage_findings(llm_guarded, target, tool_log)
        if salvaged:
            findings = salvaged
            fstatus = "ok"
            findings_source = "salvage"

    # 5b. 兜底报告：有发现但报告缺失（LLM 撞迭代上限没走完生命周期）→ 入口层补生成
    if not report_path and findings:
        _safe_print("⚠️  LLM 未在迭代上限内完成报告阶段，入口层正用发现补生成报告…")
        report_path = _fallback_report(ctx, findings)
        fallback_used = bool(report_path)

    _print_summary(state, client, tool_log, report_path, fallback_used,
                   findings_override=findings, findings_source=findings_source,
                   salvage_attempted=salvage_attempted)
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="AI 自适应渗透测试（实验）— LLM 自主驱动 recon → probe → classify → report")
    parser.add_argument("--target", required=True, help="目标 URL/域名")
    parser.add_argument("--objective", default="find all vulnerabilities", help="测试目标描述")
    parser.add_argument("--mode", choices=["full", "shallow"], default="full")
    parser.add_argument("--max-iterations", type=int, default=None,
                        help="迭代上限（默认无上限，Ctrl+C 可停；如 40）")
    parser.add_argument("--no-strategy", action="store_true",
                        help="不注入零日导向策略块/few-shot 场景（回退到旧行为）")
    parser.add_argument("--exploit-live", action="store_true",
                        help="允许 exploit 工具真实执行（默认 dry-run）")
    args = parser.parse_args(argv)

    interactive = sys.stdin is not None and hasattr(sys.stdin, "isatty") and sys.stdin.isatty()
    try:
        return run_adaptive(
            target=args.target,
            objective=args.objective,
            mode=args.mode,
            max_iterations=args.max_iterations,
            exploit_live=args.exploit_live,
            interactive=interactive,
            strategy=not args.no_strategy,
        )
    except KeyboardInterrupt:
        _safe_print("\n⛔ 用户中断。")
        return 130


if __name__ == "__main__":
    sys.exit(main())
