#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI 自适应渗透测试入口（实验）
=====================================================================

用真实 LLM 驱动 swarm_orchestrator 的 ReAct 循环，LLM 自主决定
"下一步探测哪个端点、发什么请求"，观察响应后再决策。

    python run_adaptive.py --target https://example.com \
        [--objective "find auth logic flaws"] [--mode full|shallow] \
        [--max-iterations N] [--no-strategy] [--exploit-live]

安全策略:
    - 默认 exploit dry-run；--exploit-live 需交互式输入 yes 二次确认
    - 非本机/非内网目标需授权确认（无 TTY 时拒绝远程目标）
    - scope 白名单 / 限速 / 迭代上限 / 响应截断由 swarm_tool_binders 执行

授权边界: 本框架仅可用于自己拥有或已获书面授权的目标。
"""

import argparse
import ipaddress
import json
import logging
import os
import re
import socket
import sys
from datetime import datetime, timezone
from typing import Callable, Optional
from urllib.parse import urlparse

_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from scanners.llm_client import build_llm_invoke, load_ai_config
from scanners.swarm_orchestrator import SwarmOrchestrator
from scanners import swarm_tool_binders as binders

# 无上限迭代（默认）：orchestrator 用 range() 跑循环且要求 >0，
# 给一个足够大的哨兵值即可（Python 3 range 是惰性的，10**9 无副作用）。
UNLIMITED_ITERATIONS = 10 ** 9

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
# 工具层日志降级，避免刷屏；LLM 链路错误保留
logging.getLogger('swarm_tool_binders').setLevel(logging.WARNING)

# ---------------------------------------------------------------------------
# 事件流打印
# ---------------------------------------------------------------------------
_EVENT_ICONS = {
    "thought": "🧠",
    "tool_call": "🔧",
    "tool_result": "📄",
    "milestone": "✅",
    "loop_guard": "⛔",
    "error": "❌",
    "state_change": "🔄",
}


def _safe_print(text: str) -> None:
    """打印兜底：管道/GBK 控制台编码 emoji 失败时降级，不崩。"""
    try:
        print(text, flush=True)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        print(text.encode(enc, "replace").decode(enc, "replace"), flush=True)


def _make_event_sink(collector: list):
    def sink(e: dict) -> None:
        collector.append(e)
        icon = _EVENT_ICONS.get(e.get("event_type"), "•")
        detail = str(e.get("detail") or "").replace("\n", " ")
        if len(detail) > 400:
            detail = detail[:400] + "…"
        _safe_print(f" {icon} [{e.get('event_type')}] {detail}")
    return sink


# ---------------------------------------------------------------------------
# 授权 / 安全门
# ---------------------------------------------------------------------------
def _is_local_target(url: str) -> bool:
    """loopback / 私网 / 链路本地 / 无公网可达性 视为本地目标。"""
    try:
        p = urlparse(url if "//" in url else f"//{url}")
        host = (p.netloc or "").split("@")[-1].split(":")[0].lower()
        if not host:
            return True
        if host in ("localhost", "::1", "0.0.0.0"):
            return True
        if host.endswith((".local", ".internal", ".lan", ".test")):
            return True
        try:
            ip = ipaddress.ip_address(host)
            return (ip.is_loopback or ip.is_private or ip.is_link_local
                    or ip.is_reserved or ip.is_unspecified)
        except ValueError:
            pass
        # 域名：解析后按 IP 判定；解析失败按本地处理（不可达 ≠ 远程攻击）
        try:
            infos = socket.getaddrinfo(host, None)
            ips = {i[4][0] for i in infos}
            return all(
                ipaddress.ip_address(x).is_loopback or ipaddress.ip_address(x).is_private
                or ipaddress.ip_address(x).is_link_local
                for x in ips
            )
        except Exception:
            return True
    except Exception:
        return True


def _require_confirm(prompt: str, expected: str = "yes", interactive: bool = True) -> bool:
    if not interactive:
        return False
    try:
        ans = input(prompt).strip()
    except EOFError:
        return False
    return ans == expected


# ---------------------------------------------------------------------------
# 结果提取
# ---------------------------------------------------------------------------
def install_result_recorder(orch, tool_log: list) -> None:
    """包装每个工具的 execute，把【完整】结果记入 tool_log。

    （orchestrator 只把 result[:200] 存进 state.tool_results，
    完整结果仅存在于消息历史 — 入口层自己记录一份供摘要提取。）
    """
    for name, tool in orch.tools.items():
        orig = tool.execute
        def wrap(args, _orig=orig, _name=name):
            res, err = _orig(args)
            tool_log.append({
                "tool": _name,
                "result": res if isinstance(res, str) else str(res),
                "error": err,
            })
            return res, err
        tool.execute = wrap


def install_strategy_coach(llm_invoke, enabled: bool = True):
    """包装 llm_invoke：【首轮调用前】把零日导向策略块 + few-shot 场景前置进 messages。

    背景（2026-09-14 vuln-sentinel 复盘）: 20 轮全烧在 http_probe×14 的浅探测上，
    产出全是 info/low 垃圾漏洞——根因是系统提示只有生命周期纪律、模型手里
    没有任何攻击先验，27b 级模型拿"find all vulnerabilities"就退化成通用扫描。
    M11 已证明：埋在长 objective 里的提示 27b 直接无视，而【独立醒目消息】
    能被执行（budget warning 就是这么修好的）。策略注入沿用同一机制。

    注入内容（scanners/swarm_strategy.build_injection）:
        [user: 策略块(深度优先/差分探测/高价值链)] [assistant: 确认]
        [user: IDOR 场景] [assistant: 场景A]
        [user: JWT 场景]  [assistant: 场景A]
    结构合法（role 交替），前置到 campaign 启动消息之前。

    orchestrator 零改动：只改传给 llm_invoke 的 messages 副本，
    且仅首轮生效（之后每轮重新注入会污染历史/重复占位）。
    """
    if not enabled:
        return llm_invoke

    try:
        from scanners.swarm_strategy import build_injection
        injection = build_injection()
    except Exception:
        injection = []  # 策略模块异常 → 静默降级为无注入（核心循环不受影响）
    if not injection:
        return llm_invoke

    state = {"used": False}

    def wrapped(*args, **kwargs):
        if not state["used"]:
            state["used"] = True
            if "messages" in kwargs:
                kwargs["messages"] = list(injection) + list(kwargs["messages"] or [])
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = list(injection) + list(new_args[1] or [])
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._injected = state  # 测试用
    return wrapped


def install_budget_guard(llm_invoke, max_iterations: int, warn_remaining: int = 3):
    """包装 llm_invoke：剩余额度 ≤ warn_remaining 时，每轮注入一条强预算警告。

    M7 的 objective 提示太弱（埋在长 objective 里，27b 级模型直接无视，
    把全部迭代烧在探测上）。这里在预算耗尽前每轮追加一条 user 消息，
    强制收敛到 classify → generate_report → finish_scan 生命周期。

    orchestrator 零改动：只改传给 llm_invoke 的 messages 副本，
    注入内容不会污染 orchestrator 的消息历史（每轮重新注入）。
    """
    counter = {"n": 0}

    def wrapped(*args, **kwargs):
        counter["n"] += 1
        remaining = max_iterations - counter["n"] + 1  # 本次调用计入
        if 0 < remaining <= warn_remaining:
            warn = (
                f"⚠️ BUDGET WARNING: only {remaining} iteration(s) remain (including this one). "
                "STOP starting new probes/detectors/exploits. Immediately finish the lifecycle: "
                "1) call classify with your candidate findings; "
                "2) call generate_report; "
                "3) call finish_scan."
            )
            msg = {"role": "user", "content": warn}
            if "messages" in kwargs:
                kwargs["messages"] = list(kwargs["messages"] or []) + [msg]
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = list(new_args[1] or []) + [msg]
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 M1 闭包挂的 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._call_count = counter  # 测试用
    return wrapped


# ---------------------------------------------------------------------------
# 第2轮 vulnclaw 整合辅助（A-H 八大模块接线；--no-advanced 全关）
# ---------------------------------------------------------------------------
def _adv_cfg() -> dict:
    """读 config.json 的 advanced 配置节（缺失/损坏 → {}，各模块用自身默认值）。"""
    try:
        with open(os.path.join(_PROJECT_ROOT, "config.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
        adv = data.get("advanced")
        return adv if isinstance(adv, dict) else {}
    except Exception:
        return {}


def _make_run_id(target: str) -> str:
    """run_id：UTC 时间戳 + 目标 slug（匹配 run_journal._RUN_ID_PATTERN）。"""
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    try:
        host = (urlparse(target if "//" in target else f"//{target}").netloc or "")
        host = host.split("@")[-1].split(":")[0].lower()
    except Exception:
        host = ""
    slug = re.sub(r"[^A-Za-z0-9_.-]", "-", host)[:40].strip("-") or "local"
    return f"{ts}_{slug}"


def install_resume_seed(llm_invoke, resume_state):
    """D 断点续扫：首轮调用前把上次 run 的消息历史前置进 messages（orchestrator 零改动）。

    快照历史（run_state.json 的 messages 字段）置于新 campaign 启动消息之前，
    时间序自然；边界角色交替用一条 assistant 确认补全（同 install_strategy_coach 机制）。
    """
    history = [dict(m) for m in (getattr(resume_state, "messages", None) or [])
               if isinstance(m, dict) and m.get("role")]
    if not history:
        return llm_invoke
    if history[-1].get("role") != "assistant":
        history.append({
            "role": "assistant",
            "content": ("Understood. Resuming the interrupted campaign — "
                        "continuing from the last recorded state (see history above)."),
        })
    state = {"used": False}

    def wrapped(*args, **kwargs):
        if not state["used"]:
            state["used"] = True
            if "messages" in kwargs:
                kwargs["messages"] = history + list(kwargs["messages"] or [])
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = history + list(new_args[1] or [])
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._seed = state  # 测试用
    return wrapped


def _make_parallel_probe_tool(target_url: str, pp_cfg: dict):
    """E 有界并行攻击面：注册为 orchestrator 工具，LLM 在 recon 后自主决定调用。

    内置限速（min_interval/max_total/per_surface_requests 全来自 config），
    探测结果走 merge_findings 与 classify 输出同形，不引入新发现格式。
    """
    from scanners import parallel_probe as pp
    from scanners.swarm_orchestrator import ToolDefinition

    def execute(args_string: str) -> tuple:
        try:
            payload = json.loads(args_string) if isinstance(args_string, str) else dict(args_string or {})
        except (ValueError, TypeError):
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        recon_text = str(payload.get("recon_text") or "")
        if not recon_text.strip():
            return (json.dumps({"error": "recon_text is required — paste the reconnaissance output"}),
                    "recon_text missing")
        target = str(payload.get("target_url") or target_url)
        try:
            surfaces = pp.extract_surfaces(
                recon_text, target,
                max_endpoints_per_host=int(pp_cfg.get("max_endpoints_per_host", 5)))
            if not surfaces:
                return json.dumps({"surfaces": 0, "findings": []}), None
            results = pp.probe_wave(
                surfaces,
                max_concurrent=int(pp_cfg.get("max_concurrent", 3)),
                max_total=int(pp_cfg.get("max_total", 10)),
                per_surface_requests=int(pp_cfg.get("per_surface_requests", 4)),
                request_timeout=float(pp_cfg.get("request_timeout", 10.0)),
                min_interval=float(pp_cfg.get("min_interval", 0.2)),
            )
            findings = pp.merge_findings(results)
            return json.dumps({
                "surfaces": len(surfaces),
                "probed": sum(1 for r in results if r.status == "ok"),
                "skipped": sum(1 for r in results if r.status == "skipped"),
                "findings": findings[:20],
            }, ensure_ascii=False, default=str), None
        except Exception as exc:
            return (json.dumps({"error": f"{type(exc).__name__}: {str(exc)[:200]}"}),
                    f"{type(exc).__name__}: {str(exc)[:300]}")

    return ToolDefinition(
        name="parallel_probe",
        description=("Bounded parallel shallow-probe of multiple discovered endpoints "
                     "(root/OPTIONS/high-value paths; rate-limited and scope-clamped). "
                     "Call after reconnaissance with recon_text = the recon output "
                     "(URLs/hosts/endpoints) to probe many surfaces at once."),
        parameters={
            "type": "object",
            "properties": {
                "recon_text": {"type": "string",
                               "description": "Reconnaissance output (URLs/hosts/endpoints list)"},
                "target_url": {"type": "string",
                               "description": "Primary target (scope baseline); defaults to campaign target"},
            },
            "required": ["recon_text"],
        },
        execute=execute,
    )


def _make_check_scope_tool(scope):
    """H 程序范围判定工具：让 LLM 对任意候选主机先问 scope 再动（HackerOne 计划范围）。"""
    from scanners.swarm_orchestrator import ToolDefinition

    def execute(args_string: str) -> tuple:
        try:
            payload = json.loads(args_string) if isinstance(args_string, str) else dict(args_string or {})
        except (ValueError, TypeError):
            payload = {}
        host = str((payload or {}).get("host") or "").strip().lower()
        if not host:
            return json.dumps({"error": "host is required"}), "host missing"
        try:
            from scanners import h1_scope as h1
            in_scope, reason = h1.host_in_scope(host, scope)
            return json.dumps({"host": host, "in_scope": in_scope, "reason": reason},
                              ensure_ascii=False), None
        except Exception as exc:
            return (json.dumps({"error": f"{type(exc).__name__}: {str(exc)[:200]}"}),
                    f"{type(exc).__name__}: {str(exc)[:300]}")

    return ToolDefinition(
        name="check_scope",
        description=("Check whether a host/domain is inside the authorized program scope "
                     "before probing it. Returns in_scope + reason."),
        parameters={
            "type": "object",
            "properties": {"host": {"type": "string", "description": "Host or domain to check"}},
            "required": ["host"],
        },
        execute=execute,
    )


def _close_journal(journal, status: str) -> None:
    """收尾 journal（幂等 + 静默；journal 为 None 时是 no-op）。"""
    if journal is None:
        return
    try:
        if not journal.closed:
            journal.close(status)
    except Exception:
        pass


def _salvage_findings(text: str) -> list:
    """救援解析：classify JSON 损坏（被截断/非标准序列化）时按条提取。

    发现以 ``{"title": ..., ...}`` 依序出现；按 "title" 定位条目边界，
    在段内取 severity / cvss_score / confidence。即使最后一条被截断，
    前面的条目仍可恢复——优于整体返回 0 条。
    """
    out = []
    titles = list(re.finditer(r'"title"\s*:\s*"((?:[^"\\]|\\.)*)"', text))
    for i, m in enumerate(titles):
        seg_end = titles[i + 1].start() if i + 1 < len(titles) else min(len(text), m.end() + 2000)
        seg = text[m.end():seg_end]
        sev = re.search(r'"severity"\s*:\s*"([A-Za-z_]+)"', seg)
        cvss = re.search(r'"cvss_score"\s*:\s*([\d.]+)', seg)
        conf = re.search(r'"confidence"\s*:\s*"([A-Za-z_]+)"', seg)
        out.append({
            "title": m.group(1),
            "severity": sev.group(1) if sev else "?",
            "cvss_score": float(cvss.group(1)) if cvss else 0.0,
            "confidence": conf.group(1) if conf else "?",
        })
    return out[:50]


def _unwrap_untrusted_boundary(text):
    """解包 prompt_safety（#1）的 nonce 边界（若有），返回边界内正文。

    记录器记到的是"模型所见"——工具结果已被包上不可信边界；
    入口层簿记解析（findings 提取/报告路径提取）必须解析边界内正文，
    否则 classify 结果 JSON 解析失败 → 退化为残缺 salvage（丢 target/url 等字段）。
    导入失败 / 未包装 / 任何异常 → 原样返回（静默降级）。
    """
    if not isinstance(text, str) or not text:
        return text
    try:
        from scanners.prompt_safety import unwrap_untrusted
        return unwrap_untrusted(text)
    except Exception:
        return text


def _extract_findings(tool_log):
    """从最后一次 classify 工具结果提取发现列表。

    返回 ``(findings, status)``：
      ok           JSON 解析成功
      parse_failed classify 被调用但结果无法完整解析（已尽力救援）
      not_called   从未成功调用 classify
    """
    for r in reversed(tool_log or []):
        if r.get("tool") != "classify" or r.get("error"):
            continue
        text = _unwrap_untrusted_boundary(r.get("result", "") or "")
        try:
            data = json.loads(text)
            fs = data.get("findings") or []
            return [f for f in fs if isinstance(f, dict)][:50], "ok"
        except (json.JSONDecodeError, TypeError, ValueError):
            return _salvage_findings(text), "parse_failed"
    return [], "not_called"


def _json_unescape(s: str) -> str:
    """解转义 JSON 字符串值（正则从 JSON 文本抓到的 Windows 路径反斜杠是双写态，还原为单写）。"""
    try:
        return json.loads(f'"{s}"')
    except (json.JSONDecodeError, ValueError):
        return s


def _extract_report_path(tool_log) -> str:
    for r in reversed(tool_log or []):
        if r.get("tool") == "generate_report" and not r.get("error"):
            m = re.search(r'"report_path":\s*"([^"]+)"', r.get("result", ""))
            if m:
                return _json_unescape(m.group(1))
    return ""


def _fallback_report(ctx, findings) -> str:
    """兜底：LLM 未在迭代上限内完成报告阶段时，入口层用 classify 发现补生成报告。

    复用 generate_report binder 的同一代码路径（富报告聚合/落盘/命名），
    避免复制逻辑。返回报告路径（主 HTML），失败返回 ""。
    """
    try:
        tool = binders._make_report(ctx)
        res, err = tool.execute(json.dumps({"findings": findings}, ensure_ascii=False, default=str))
        if err or not res:
            return ""
        m = re.search(r'"report_path":\s*"([^"]+)"', res)
        return _json_unescape(m.group(1)) if m else ""
    except Exception as exc:
        _safe_print(f"⚠️  兜底报告生成失败: {type(exc).__name__}: {str(exc)[:120]}")
        return ""


def _append_section_to_report(report_path: str, marker: str, body: str) -> bool:
    """把一段内容追加进报告文件（幂等：marker 已存在则跳过；非阻塞，失败返回 False）。

    HTML 报告插到 </html> 之前（<pre> 包裹保格式）；其他格式直接追加到文件尾。
    """
    try:
        if not report_path or not os.path.isfile(report_path):
            return False
        with open(report_path, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
        if marker in text or not body.strip():
            return False
        if "</html>" in text.lower():
            import html as _html
            block = f"\n{marker}\n<section style=\"font-family:monospace;white-space:pre-wrap;\">{_html.escape(body)}</section>\n"
            idx = text.lower().rfind("</html>")
            text = text[:idx] + block + text[idx:]
        else:
            text += f"\n\n{marker}\n{body}\n"
        with open(report_path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return True
    except OSError:
        return False


def _salvage_transcript(tool_log, max_chars: int = 12000) -> str:
    """把工具日志压成紧凑 transcript（每条 ≤400 字符），供收尾提取用。"""
    lines = []
    for r in tool_log or []:
        res = (r.get("result") or "").replace("\n", " ")[:400]
        if r.get("error"):
            res += f" [ERROR: {str(r['error'])[:100]}]"
        lines.append(f"[{r.get('tool')}] {res}")
    return "\n".join(lines)[:max_chars]


def _extract_salvage_findings(llm_invoke, target: str, tool_log) -> list:
    """收尾 salvage：classify 从未被调用时，用一次预算外的 LLM 调用从工具日志提取发现。

    模型自己的分析（不是启发式猜）：把 transcript 喂回去，要求只回 JSON 数组。
    任何失败都返回 []——不阻塞、不崩，主摘要照常打印。
    """
    transcript = _salvage_transcript(tool_log)
    if not transcript.strip():
        return []
    system = (
        "You are a security report extractor. From the scan transcript below, extract "
        "CONFIRMED security findings (information disclosure, publicly exposed sensitive "
        "endpoints, weak security controls, confirmed misconfigurations). "
        "Respond with ONLY a JSON array, no prose. Each element: "
        '{"title": str, "severity": "info|low|medium|high|critical", '
        '"description": str, "evidence": str}. '
        "Return [] if there are no confirmed findings."
    )
    user = (f"Target: {target}\n\nTranscript (truncated):\n{transcript}\n\n"
            "Return the JSON array now.")
    try:
        resp = llm_invoke(system, [{"role": "user", "content": user}], [],
                          max_tokens=2048, temperature=0.0)
    except Exception:
        return []
    if not resp:
        return []
    text = (resp.get("content") or "").strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return [f for f in data if isinstance(f, dict) and f.get("title")][:50]
    except (json.JSONDecodeError, ValueError):
        pass
    # 救援：按 title 边界逐条提取（整体 JSON 损坏时前面条目仍可恢复）
    return _salvage_findings(text)


def _print_summary(state, client, tool_log, report_path: str = "", fallback_used: bool = False,
                   findings_override: list = None, findings_source: str = "classify",
                   salvage_attempted: bool = False, verify_lines: list = None,
                   learning_lines: list = None, advanced_lines: list = None) -> None:
    _safe_print("\n" + "=" * 62)
    _safe_print("=== Campaign 结束 ===")
    tool_seq = [r["tool"] for r in tool_log or []]
    _safe_print(f"  工具调用序列: {' → '.join(tool_seq) if tool_seq else '(无)'}")
    _safe_print(f"  状态: {'完成 (finish_scan)' if state.is_complete else '迭代上限/异常终止'}")

    if findings_override is not None:
        findings, fstatus = findings_override, "ok"
    else:
        findings, fstatus = _extract_findings(tool_log)
    src_label = {"classify": "classify 输出", "salvage": "入口层 salvage 提取"}.get(
        findings_source, findings_source)
    _safe_print(f"\n  发现列表（{src_label}，共 {len(findings)} 条）:")
    if findings:
        for f in findings:
            _safe_print(f"    - [{f.get('severity', '?')}] {f.get('title', '?')} "
                        f"(CVSS {f.get('cvss_score', 0)} | {f.get('confidence', '?')})")
    elif fstatus == "ok":
        _safe_print("    (无 — classify 输出 0 条：全部被 FP 过滤或确认真干净)")
    elif fstatus == "not_called":
        if salvage_attempted:
            _safe_print("    (无 — classify 未被调用，收尾 salvage 提取后确认无发现)")
        else:
            _safe_print("    (无 — LLM 未调用 classify 或全部被 FP 过滤)")
    else:
        _safe_print("    (classify 已调用但结果无法解析 — 完整发现以上方报告文件为准)")

    if not report_path:
        report_path = _extract_report_path(tool_log)
    label = "报告（入口层兜底补生成）" if fallback_used else "报告"
    _safe_print(f"\n  {label}: {report_path if report_path else '(未生成)'}")

    if client is not None:
        u = client.usage
        _safe_print(f"  Token 用量: {u.get('calls', 0)} 次调用, "
                    f"prompt={u.get('prompt_tokens', 0)}, "
                    f"completion={u.get('completion_tokens', 0)}")

    # vulnclaw 整合收尾行：报告自检（⑥）+ 自学习（①⑤ 经验蒸馏/KB 参考）
    if verify_lines:
        _safe_print("")
        for ln in verify_lines:
            _safe_print(f"  {ln.strip()}")
    if learning_lines:
        _safe_print("")
        for ln in learning_lines:
            _safe_print(f"  {ln.strip()}")
    if advanced_lines:
        _safe_print("")
        for ln in advanced_lines:
            _safe_print(f"  {ln.strip()}")
    _safe_print("=" * 62)


# ---------------------------------------------------------------------------
# 主入口（launcher 复用此函数）
# ---------------------------------------------------------------------------
def run_adaptive(
    target: str,
    objective: str = "find all vulnerabilities",
    mode: str = "full",
    max_iterations: Optional[int] = None,
    exploit_live: bool = False,
    interactive: bool = True,
    llm_invoke_factory: Optional[Callable] = None,
    strategy: bool = True,
    learning: bool = True,
    advanced: bool = True,
    resume_run_id: Optional[str] = None,
) -> int:
    """组装并执行一次自适应 campaign。返回进程退出码（0 正常）。

    max_iterations: 迭代上限；None = 无上限（默认，Ctrl+C 随时可停）。
    llm_invoke_factory: 测试注入点（传假 LLM 工厂，不碰真实 API）。
    strategy: 是否注入零日导向策略块 + few-shot 场景（M12，--no-strategy 关闭）。
    learning: 是否启用 vulnclaw 整合的自学习闭环（--no-learning 全关，
        行为与整合前完全一致）：经验注入/反思升级/反循环/token 预算/KB 工具/
        报告自检/收尾蒸馏。
    advanced: 是否启用 vulnclaw 第2轮整合（--no-advanced 全关，行为与第2轮前一致）：
        A ATT&CK映射 / B 修复建议 / C 危险操作审批门 / D 断点续扫(run journal) /
        E 有界并行探测 / F 自纠正信号 / G PoC脚本生成 / H HackerOne 计划范围。
        各子模块可再经 config.json 的 advanced 节单独开关/调参。
    resume_run_id: D 断点续扫 — runs/ 下既有 run 的 ID；非空时从该 run 的
        快照恢复消息历史与工具日志继续扫描（新扫描留空）。
    """
    # --- 0. AI 配置检查 ---
    cfg = load_ai_config()
    if not cfg.get("enabled"):
        _safe_print("❌ AI 未启用（config.json ai.enabled != true）。请先运行 init_ai.py 配置模型。")
        return 1
    cap_label = f"{max_iterations}" if max_iterations else "无上限"
    _safe_print(f"🤖 LLM: {cfg.get('provider')} / {cfg.get('model') or '(auto)'} "
                f"| 迭代上限: {cap_label} | 策略: {'零日导向(深度优先+差分探测)' if strategy else 'off'} "
                f"| 自学习: {'on(经验+反思+反循环+KB+自检)' if learning else 'off'} "
                f"| 第2轮增强: {'on(ATT&CK+修复建议+审批门+续扫+并行+自纠正+PoC+scope)' if advanced else 'off'} "
                f"| exploit: {'LIVE' if exploit_live else 'dry-run'}")

    # --- 1. 授权门 ---
    if not _is_local_target(target):
        _safe_print(f"\n⚠️  目标 {target} 疑似公网/非内网地址。")
        _safe_print("   本框架仅可用于【自己拥有或已获书面授权】的目标。")
        if not _require_confirm("\n   确认已获授权？输入 yes 继续: ", "yes", interactive):
            _safe_print("❌ 已取消（未确认授权）。")
            return 1

    # --- 2. exploit-live 二次确认 ---
    if exploit_live and not _require_confirm(
            "\n⚠️  LIVE 模式将真实执行命令（仍受 safe-mode/scope 门控）。输入 yes 确认: ",
            "yes", interactive):
        _safe_print("❌ 已取消（未确认 LIVE 模式）。")
        return 1

    # --- 3. 组装 ---
    llm_invoke = (llm_invoke_factory or build_llm_invoke)()
    client = getattr(llm_invoke, "client", None)
    events: list = []
    tool_log: list = []

    # --- 3-pre. 第2轮（advanced）：D 断点续扫重建（在策略教练前定案——续扫时跳过策略注入）---
    adv = _adv_cfg() if advanced else {}
    resume_state = None
    if advanced and resume_run_id:
        try:
            from scanners import run_journal as rj
            run_dir = os.path.join(_PROJECT_ROOT, "runs", str(resume_run_id))
            if not os.path.isdir(run_dir):
                _safe_print(f"❌ 续扫失败：runs 目录不存在: {run_dir}")
                return 1
            reconciled = rj.reconcile_interrupted(run_dir)
            if reconciled:
                _safe_print(f"🔁 已对账 {len(reconciled)} 条上次未收尾事件（标记 interrupted）")
            resume_state = rj.build_resume(run_dir)
            _safe_print(f"🔁 断点续扫: 已完成迭代={resume_state.iterations_done} "
                        f"| 工具调用={len(resume_state.tool_log)} "
                        f"| 已知发现={len(resume_state.findings)}")
            # 历史工具日志预填入口层 tool_log（与 recorder 同形），
            # 收尾的 _extract_findings / salvage / 蒸馏都看得到上次 classify 输出
            for entry in resume_state.tool_log or []:
                if isinstance(entry, dict) and entry.get("tool"):
                    tool_log.append({
                        "tool": entry.get("tool", ""),
                        "result": entry.get("result") or "",
                        "error": entry.get("error") or None,
                    })
        except Exception as exc:
            _safe_print(f"⚠️ 断点重建失败（降级为新扫描）: {type(exc).__name__}: {str(exc)[:120]}")
            resume_state = None
            resume_run_id = None

    # --- 3a. 自学习闭环（vulnclaw 整合；--no-learning 全部跳过，行为与整合前一致）---
    # 包装顺序（由里向外）：token 预算 → 策略 → 经验注入 → 反思教练 →
    #   自纠正 → 续扫种子 → 任务清单 → 预算守卫 → 预算护栏。
    # BUG_REPORT [6]：token 预算裁剪装在【最里层】（最先安装）——请求路径上
    # 所有教练的注入块（策略/经验/反思/自纠正/续扫/任务清单）都先于它进入
    # 裁剪视图，全部计入窗口预算。旧代码把预算装在经验/反思之后：这两块
    # 注入发生在裁剪【之后】、不计预算，可能小幅溢出 LLM 窗口；注释也
    # 与实际顺序不符（注释称"自纠正→续扫种子→token 预算"）。
    # 每个包装器自身异常 → 原样透传降级，绝不阻断核心循环。
    experience_store = None
    reflexion_engine = None
    llm_coached = llm_invoke  # learning=False 时的基线（策略教练等后续包装都基于它）
    if learning:
        try:
            from scanners.context_budget import install_context_budget, load_window_tokens
            llm_coached = install_context_budget(llm_coached, window_tokens=load_window_tokens())
        except Exception:
            pass  # token 预算包装异常 → 原样透传
        try:
            from scanners.experience import make_store, install_experience_coach
            from scanners.reflexion import ReflexionEngine, install_reflexion_coach
            experience_store = make_store()
            reflexion_engine = ReflexionEngine()
            llm_coached = install_experience_coach(llm_coached, store=experience_store, target=target)
            llm_coached = install_reflexion_coach(llm_coached, engine=reflexion_engine)
        except Exception as exc:
            _safe_print(f"⚠️  经验/反思教练不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")
            experience_store = None
            reflexion_engine = None

    # 策略教练（M12）：首轮前置注入零日导向策略块 + few-shot 场景（入口层包装，orchestrator 零改动）
    # 续扫时跳过：旧上下文已含策略（重注入既冗余又会破坏角色交替序）
    llm_coached = install_strategy_coach(llm_coached, enabled=strategy and resume_state is None)

    # --- 3a2. F 自纠正教练 + D 续扫种子 ---
    # 自纠正/续扫种子装在 token 预算【之外】（后安装）→ 请求路径上它们的
    # 注入先于裁剪发生，计入窗口预算（BUG_REPORT [6]；规范顺序见 3a 段注释）。
    correction_observer = None
    if advanced and (adv.get("correction") or {}).get("enabled", True):
        try:
            from scanners.correction import CorrectionObserver, install_correction_coach
            correction_observer = CorrectionObserver(
                max_facts=int((adv.get("correction") or {}).get("max_facts", 40)))
            llm_coached = install_correction_coach(llm_coached, observer=correction_observer, enabled=True)
        except Exception:
            correction_observer = None  # 自纠正异常 → 原样透传（不阻断核心循环）
    if resume_state is not None:
        # 快照有消息历史才注入（事件流兜底重建时 messages 为空 → 仅靠 tool_log 预填）
        if getattr(resume_state, "messages", None):
            llm_coached = install_resume_seed(llm_coached, resume_state)
        else:
            _safe_print("⚠️ 上次快照无消息历史，续扫将以新上下文 + 历史工具日志继续")

    # --- 3a4. TodoWrite 任务清单（4 项目升级清单 #8，todo_coach）— llm 链：自纠正之后、预算守卫之前
    # store 先建（3c 工具注册 / 5e 报告段共用）；续扫时从 runs/<id>/todo.json 恢复上次清单。
    # 教练每轮把清单（≤1200 字符）挂到 system_prompt：不动 messages，40 条摘要压缩
    # 与 context_budget 的 token 裁剪都不影响它在场（升级清单 #8 的 token 交互纪律）。
    todo_store = None
    if advanced and (adv.get("todo") or {}).get("enabled", True):
        try:
            from scanners import todo_coach as _tc
            todo_store = _tc.TodoStore(
                max_tasks=int((adv.get("todo") or {}).get("max_tasks", 15)))
            if resume_run_id:
                _todo_p = os.path.join(_PROJECT_ROOT, "runs", str(resume_run_id), "todo.json")
                if os.path.isfile(_todo_p) and todo_store.restore_from_file(_todo_p) > 0:
                    _safe_print(f"🔁 续扫恢复任务清单（{len(todo_store.tasks)} 步）")
            llm_coached = _tc.install_todo_coach(llm_coached, store=todo_store, enabled=True)
        except Exception as exc:
            _safe_print(f"⚠️  todo 教练不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")
            todo_store = None

    # 预算守卫：末 warn_remaining 轮每轮注入强警告；轮数按预算比例缩放（20→3、40→4）
    # 无上限时不装——没有预算就没有预算警告（重复动作兜底靠 orchestrator 的 loop_guard）
    if max_iterations:
        warn_remaining = max(3, max_iterations // 10)
        llm_guarded = install_budget_guard(llm_coached, max_iterations, warn_remaining)
    else:
        llm_guarded = llm_coached

    # --- 3a3. LLM 护栏（4 项目升级清单 #7，llm_guard）—— 包住最外层 llm_guarded，
    # 在任何 coach/预算包装器**之前**短路：预算耗尽/限速/超限 → 返回 None（干净终止），
    # 省得为一次注定被拒的调用白跑上下文裁剪。全上限 0 / enabled:false → 不装（零变化）。
    if advanced:
        try:
            from scanners import llm_guard as _lguard
            _adv_guard_cfg = (adv.get("llm_guard") or {})
            # 成本上限数据源：读进程共享成本账本（仅当配置了 cost_cap 才懒接，避免副作用）
            _cost_src = None
            if float(_adv_guard_cfg.get("cost_cap_usd") or 0.0) > 0:
                try:
                    from scanners import llm_cost as _lc
                    _cost_src = lambda: float(
                        ((_lc.get_default_cost_ledger().to_record().get("totals") or {}).get("cost")) or 0.0)
                except Exception:
                    _cost_src = None
            _lg = _lguard.build_guard_from_advanced(adv, cost_source=_cost_src)
            if _lg is not None:
                llm_guarded = _lguard.install_llm_guard(llm_guarded, _lg)
                st = _lg.status()
                _safe_print(f"🛡️  LLM 护栏已启用 | rate={st['rate_per_min'] or 'off'}/min "
                            f"daily={st['daily_call_cap'] or 'off'} "
                            f"total={st['max_calls'] or 'off'} "
                            f"cost=${st['cost_cap_usd'] or 'off'}")
        except Exception as exc:
            _safe_print(f"⚠️  LLM 护栏不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    orch = SwarmOrchestrator(
        llm_invoke=llm_guarded,
        max_iterations=max_iterations or UNLIMITED_ITERATIONS,
        event_sink=_make_event_sink(events),
    )
    ctx = binders.register_campaign_tools(orch, target, objective, dry_run=not exploit_live)
    # M14: 富报告数据源 — 指向 recorder 的同一 tool_log（只读消费，零复制）+ 模型信息
    ctx.tool_log = tool_log
    ctx.model_info = f"{cfg.get('provider')}/{cfg.get('model') or '(auto)'}"

    # --- 3b. 知识库工具 + 反循环追踪器（execute 包装，装在 recorder 之前）---
    kb = None
    loop_tracker = None
    if learning:
        try:
            from scanners.kb_search import KnowledgeBase, make_consult_kb_tool
            kb = KnowledgeBase()
            orch.register_tool(make_consult_kb_tool(kb))
        except Exception:
            kb = None  # KB 数据缺失 → 无工具（不阻断）
        try:
            from scanners.anti_loop import install_anti_loop_tracker
            # 反循环拦截文案会作为 tool 结果回流消息历史 → reflexion 教练
            # 经消息扫描自然共享同一失败事件源（无需额外回调，避免双计）
            loop_tracker = install_anti_loop_tracker(orch)
        except Exception:
            loop_tracker = None

    # --- 3b1. 攻击面知识图谱 ingest（4 项目升级清单 #9，attack_graph）---
    # 包装链位置：anti_loop 之后、untrusted 边界【之前】（由里向外），看目标原始输出；
    # ingest 纯观测（不改 res/err），异常静默，不阻断核心循环。
    graph = None
    if advanced and (adv.get("attack_graph") or {}).get("enabled", True):
        try:
            from scanners import attack_graph as _ag
            ag_cfg = adv.get("attack_graph") or {}
            ag_dir = str(ag_cfg.get("db_dir") or "data/attack_graph")
            if not os.path.isabs(ag_dir):
                ag_dir = os.path.join(_PROJECT_ROOT, ag_dir)
            ag_db = _ag.default_db_path(ag_dir, target)
            graph = _ag.GraphStore(
                ag_db,
                max_nodes=int(ag_cfg.get("max_nodes", 2000)),
                max_edges=int(ag_cfg.get("max_edges", 8000)))
            n_ing = _ag.install_graph_ingest(orch, graph)
            _safe_print(f"🕸️  attack_graph ingest 已启用（包装 {n_ing} 个工具；"
                        f"SQLite {os.path.relpath(ag_db, _PROJECT_ROOT)}）")
        except Exception as exc:
            _safe_print(f"⚠️  attack_graph 不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")
            graph = None

    # --- 3b1b. E 并行探测 + H scope 工具（必须在 untrusted 边界【之前】注册）---
    # E 的 evidence 内嵌目标响应原始字节（Server/X-Powered-By/Allow 头、robots.txt
    # disallow 行——攻击者可逐字控制），属不可信数据，必须包 nonce 边界后回 LLM
    # （BUG_REPORT [3c]）；放在 3b1 ingest 之后 → 不被图 ingest 吞，但被 3b2 边界包装。

    # E 有界并行攻击面探测（config: advanced.parallel_probe.enabled）
    if advanced and (adv.get("parallel_probe") or {}).get("enabled", False):
        try:
            from scanners.parallel_probe import load_parallel_config
            orch.register_tool(_make_parallel_probe_tool(target, load_parallel_config(adv)))
            _safe_print("🧵 parallel_probe 工具已注册（有界并行探测，config advanced.parallel_probe）")
        except Exception as exc:
            _safe_print(f"⚠️  parallel_probe 不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # H 程序范围判定工具（config: advanced.h1_scope — scope_file 或 program_handle+API key）
    if advanced and (adv.get("h1_scope") or {}).get("enabled", False):
        try:
            from scanners import h1_scope as h1
            h1_cfg = adv.get("h1_scope") or {}
            scope_obj = None
            sf = str(h1_cfg.get("scope_file") or "").strip()
            if sf and not os.path.isabs(sf):
                sf = os.path.join(_PROJECT_ROOT, sf)
            if sf:
                scope_obj = h1.load_scope_file(sf)
            if scope_obj is None and str(h1_cfg.get("program_handle") or "").strip():
                key_env = str(h1_cfg.get("api_key_env") or "HACKERONE_API_KEY")
                api_key = os.environ.get(key_env, "").strip()
                if api_key:
                    scope_obj = h1.fetch_h1_scope(h1_cfg["program_handle"], api_key)
            if scope_obj is not None:
                orch.register_tool(_make_check_scope_tool(scope_obj))
                _safe_print(f"🎯 check_scope 工具已注册（scope: {len(scope_obj.in_scope)} 项 in-scope 资产）")
            else:
                _safe_print("⚠️  h1_scope 已启用但无 scope 来源（scope_file 缺失或 program_handle/KEY 未配）— 跳过注册")
        except Exception as exc:
            _safe_print(f"⚠️  check_scope 不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # --- 3b2. 不可信输出 nonce 边界（4 项目升级清单 #1，prompt_safety）---
    # 包装链由里向外：anti_loop → [E/H 工具] → untrusted 边界 → 审批门 → offload → recorder。
    # 边界装在审批门内侧：拒绝文案是扫描器自己的（受信），不包边界；
    # 目标/工具真实输出（不可信）回流 LLM 前统一包 nonce 边界。
    if advanced and (adv.get("prompt_safety") or {}).get("enabled", True):
        try:
            from scanners.prompt_safety import install_untrusted_guard
            n_wrap = install_untrusted_guard(orch)
            _safe_print(f"🔒 untrusted 边界已启用（包装 {n_wrap} 个工具；目标输出进 LLM 前包 nonce 边界）")
        except Exception as exc:
            _safe_print(f"⚠️  prompt_safety 不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # --- 3c. 第2轮（advanced）：C 审批门 + 其余工具（E/H 已提前到 3b1b 注册）---
    # 顺序约束（包装链由里向外）：
    #   [E/H 工具] → I todo → J 图查询 → 装 C 审批门 → offload → 结果记录器 → D journal
    # 审批门必须在记录器之前装（记录器记到的是"拒绝文案/放行后真实结果"的最终返回）；
    # journal 必须最后装（它包装【已注册的全部工具】，后注册的工具不会被包装）。
    # 每个子模块自身异常 → 静默降级，绝不阻断核心循环。

    # I TodoWrite 工具（config: advanced.todo.enabled）— 与 3a4 教练共享同一 store；
    # 必须在 journal 之前注册（journal 包装【已注册的全部工具】，后注册的漏记）
    if todo_store is not None:
        try:
            from scanners import todo_coach as _tc
            orch.register_tool(_tc.make_todo_tool(todo_store))
            _safe_print("📝 todo 工具已注册（TodoWrite：全量清单每轮随 prompt 携带）")
        except Exception as exc:
            _safe_print(f"⚠️  todo 工具不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # J attack_graph 查询工具（config: advanced.attack_graph.enabled）— 同样须先于 journal
    if graph is not None:
        try:
            from scanners import attack_graph as _ag
            orch.register_tool(_ag.make_attack_graph_tool(graph))
            _safe_print("🔍 attack_graph 工具已注册（图查询: stats/list/neighbors/findings/paths）")
        except Exception as exc:
            _safe_print(f"⚠️  attack_graph 工具不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # C 危险操作审批门（config: advanced.exec_gate；fail-closed，无通道/通道异常一律拒绝）
    exec_gate_obj = None
    if advanced and (adv.get("exec_gate") or {}).get("enabled", True):
        try:
            from scanners.exec_gate import ExecutionGate, install_exec_gate, prompt_sync_hook
            eg_cfg = adv.get("exec_gate") or {}
            gate = ExecutionGate(mode=str(eg_cfg.get("mode") or "ask"))
            if gate.mode != "full_access":
                gate.install_sync_confirm_hook(prompt_sync_hook)  # 非 TTY/EOF → 拒绝（fail-closed）
            # #2 命令三态静态判定（cmd_guard）：deny→拒（不询问）；
            #    allow 且非 ask 模式→放行；review→None→落回人工审批路径。
            #    策略不可用/关闭 → command_policy=None，行为与整合前完全一致。
            cmd_policy = None
            if eg_cfg.get("command_policy", True):
                try:
                    from scanners.cmd_guard import build_policy
                    cmd_policy = build_policy()
                except Exception:
                    cmd_policy = None  # 静默降级到无策略（审批路径兜底）
            install_exec_gate(orch, gate=gate,
                              protected_tools=tuple(eg_cfg.get("protected_tools") or ("exploit",)),
                              command_policy=cmd_policy)
            exec_gate_obj = gate
        except Exception as exc:
            _safe_print(f"⚠️  exec_gate 不可用（降级为无门）: {type(exc).__name__}: {str(exc)[:120]}")

    # 输出 offload（#4）：装在审批门之后、记录器之前 — 记录器记到的
    # 是模型实际看到的 stub（head/tail + 全文路径），而非原始巨输出。
    if advanced and (adv.get("output_offload") or {}).get("enabled", True):
        try:
            from scanners.output_offload import install_output_offload
            oo_cfg = adv.get("output_offload") or {}
            oo_outdir = str(oo_cfg.get("outdir") or "data/tool_outputs")
            if not os.path.isabs(oo_outdir):
                oo_outdir = os.path.join(_PROJECT_ROOT, oo_outdir)
            n_off = install_output_offload(
                orch, oo_outdir,
                always_tools=tuple(oo_cfg.get("always_tools") or ()),
                never_tools=tuple(oo_cfg.get("never_tools") or ()))
            _safe_print(f"📦 output_offload 已启用（包装 {n_off} 个工具；"
                        f"超限输出全文落盘 {oo_outdir}，回 LLM 为 head/tail stub）")
        except Exception as exc:
            _safe_print(f"⚠️  output_offload 不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # 结果记录器（工具链最外层之一 — 记到的是审批门裁决/anti-loop 拦截后的真实返回）
    install_result_recorder(orch, tool_log)

    # --- 3d. D 断点续扫 journal（全部工具注册完毕后包装：turn/工具事件 + 每 turn 快照）---
    journal = None
    run_id = (resume_run_id or "").strip() or _make_run_id(target)
    if advanced and (adv.get("run_journal") or {}).get("enabled", True):
        try:
            from scanners import run_journal as rj
            run_dir = rj.default_run_dir(_PROJECT_ROOT, run_id)
            journal = rj.RunJournal(run_dir)
            rj.install_run_journal(orch, llm_guarded, journal)
            _safe_print(f"📓 run journal: runs/{run_id}"
                        + ("（续扫中，事件续写）" if resume_run_id else "（中断后可 --resume-run-id 续扫）"))
        except Exception as exc:
            journal = None
            _safe_print(f"⚠️  run journal 不可用（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # I' todo 清单落盘改绑：runs/<run_id>/todo.json（每次变更原子写，中断/续扫不丢）
    if todo_store is not None:
        try:
            todo_store.set_persist_path(os.path.join(_PROJECT_ROOT, "runs", run_id, "todo.json"))
        except Exception:
            pass  # 落盘改绑失败 → 清单仍在内存 + prompt 里

    # --- 4. 执行 ---
    # 预算纪律提示：objective 会注入首轮 user 消息（swarm_orchestrator.py:289），
    # 防止小模型把迭代全耗在探测上、没走完 report → finish_scan 生命周期
    campaign_objective = (
        f"{objective}. "
        "IMPORTANT: reserve at least the final 2-3 iterations to call generate_report "
        "and then finish_scan; do not spend the entire iteration budget on probing."
    )
    _safe_print(f"\n🚀 Campaign 开始 | target={target} | objective={objective}\n")
    try:
        state = orch.run_campaign([target], campaign_objective, mode)
    except KeyboardInterrupt:
        _safe_print("\n⛔ 用户中断。")
        state = None

    if state is None:
        _safe_print(f"\n💾 续扫凭据: python run_adaptive.py --target {target} --resume-run-id {run_id}")
        _close_journal(journal, "interrupted")
        return 1
    if any(e.get("event_type") == "error" and "LLM call returned None" in str(e.get("detail", ""))
           for e in events):
        _safe_print("\n❌ LLM 链路失败（详见上方日志）。请检查 Ollama/API 配置。")
        _close_journal(journal, "error")
        return 1

    # --- 5. 收尾兜底（两层）---
    report_path = _extract_report_path(tool_log)
    fallback_used = False
    findings, fstatus = _extract_findings(tool_log)
    findings_source = "classify"
    salvage_attempted = False

    # 5a. salvage：classify 从未被调用（迭代预算全烧在探测上，vuln-sentinel 2026-09-14 实例）
    #     → 一次预算外的 LLM 调用，从工具日志里提取发现。
    #     注意：classify 被调过但 0 条（FP 过滤/确认真干净）时【不】salvage——尊重分类器裁决。
    if not report_path and fstatus == "not_called":
        _safe_print("\n⚠️  classify 未在迭代预算内完成 — 入口层正在做收尾 salvage 提取（额外 1 次 LLM 调用）…")
        salvage_attempted = True
        salvaged = _extract_salvage_findings(llm_guarded, target, tool_log)
        if salvaged:
            findings = salvaged
            fstatus = "ok"
            findings_source = "salvage"

    # 5b. 兜底报告：有发现但报告缺失（LLM 撞迭代上限没走完生命周期）→ 入口层补生成
    if not report_path and findings:
        _safe_print("⚠️  LLM 未在迭代上限内完成报告阶段，入口层正用发现补生成报告…")
        report_path = _fallback_report(ctx, findings)
        fallback_used = bool(report_path)

    # 5c. 报告自检（⑥ 报告验证器）+ PoC 附录 — 非阻塞，任何异常静默跳过
    verify_lines = []
    if learning and (findings or report_path):
        try:
            from scanners.report_verifier import verify_report, append_poc_appendix
            vsum = verify_report(report_path or "", findings)
            if findings and report_path:
                try:
                    append_poc_appendix(report_path, findings)
                except Exception:
                    pass  # 附录失败不影响自检结果
            verify_lines = vsum.to_lines()
            events.append({"event_type": "report_verify",
                           "detail": f"{vsum.verified}/{vsum.total} passed"})
        except Exception:
            verify_lines = []

    # 5e. 第2轮（advanced）报告产物：A ATT&CK映射 / B 修复建议 / G PoC复现脚本
    #     全部非阻塞：任何子模块异常 → 静默降级，主报告与摘要照常。
    advanced_lines = []
    report_dir = (os.path.dirname(os.path.abspath(report_path))
                  if report_path and os.path.isfile(report_path)
                  else os.path.join(_PROJECT_ROOT, "hack_report"))
    if advanced and (findings or report_path):
        # C' 逐类深挖 + 置信度评分（#3 vuln_deepdive）— 报告自检后、ATT&CK 前
        # 有界：最多 deepdive.max_findings 条（默认 5）；LLM 不可用 → findings 原样。
        if findings and (adv.get("deepdive") or {}).get("enabled", True):
            try:
                from scanners.vuln_deepdive import (score_findings, make_llm_chat,
                                                     render_confidence_section)
                dd_cfg = adv.get("deepdive") or {}
                dd_cap = int(dd_cfg.get("max_findings", 5))
                dd_chat = make_llm_chat(llm_guarded)
                findings, dd_stats = score_findings(dd_chat, findings, cap=dd_cap)
                dd_section = render_confidence_section(findings)
                if dd_section and report_path:
                    _append_section_to_report(
                        report_path, "<!-- hack_scanner:confidence -->", dd_section)
                advanced_lines.append(
                    f"置信度评分: {dd_stats.get('scored', 0)}/{dd_stats.get('attempted', 0)} 条深挖成功"
                    + ("，置信度段已追加报告" if dd_section and report_path
                       else "（无 LLM 有效裁决，未追加段）"))
            except Exception as exc:
                _safe_print(f"⚠️  深挖置信度评分失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

        # C'' 发现分诊（4 项目升级清单 #10，finding_triage）— deepdive 之后、ATT&CK 前：
        # 去重 → 可利用性排序（消费 #3 写回的 confidence）→ Top-N + 叙述段。
        # 排序为纯规则（确定性可审计）；LLM 只产叙述、失败降级规则摘要；
        # 去重后的 findings 替换原列表 → 下游 ATT&CK/修复建议消费已合并列表。
        if findings and (adv.get("triage") or {}).get("enabled", True):
            try:
                from scanners import finding_triage as _ft
                from scanners.vuln_deepdive import make_llm_chat as _ft_make_chat
                t_cfg = adv.get("triage") or {}
                t_top = int(t_cfg.get("top_n", 10))
                t_chat = None
                if t_cfg.get("narrative", True):
                    try:
                        t_chat = _ft_make_chat(llm_guarded)
                    except Exception:
                        t_chat = None
                findings, t_stats = _ft.triage_findings(
                    findings, top_n=t_top, llm_chat=t_chat, target=str(target))
                t_section = _ft.render_triage_section(findings, t_stats)
                if t_section and report_path:
                    _append_section_to_report(
                        report_path, "<!-- hack_scanner:triage -->", t_section)
                advanced_lines.append(
                    f"发现分诊: 保留 {t_stats.get('total_out', 0)}/{t_stats.get('total_in', 0)} 条"
                    f"（去重 {t_stats.get('removed', 0)}），Top-{t_stats.get('top_n', 0)}"
                    + ("，排名段已追加报告" if t_section and report_path else ""))
            except Exception as exc:
                _safe_print(f"⚠️  发现分诊失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

        # J' 攻击面图谱收尾（4 项目升级清单 #9）— triage 后：最终 findings 入图 + 报告段
        # 连接在本 run 用完即关（DB 文件保留：跨 run 累积、可人工/后续查询）
        if graph is not None:
            try:
                from scanners import attack_graph as _ag
                n_ing_f = graph.ingest_findings(findings) if findings else 0
                ag_sec = _ag.export_section(graph)
                if ag_sec and report_path:
                    _append_section_to_report(
                        report_path, "<!-- hack_scanner:attack_graph -->", ag_sec)
                st_g = graph.stats()
                advanced_lines.append(
                    f"攻击面图谱: host {st_g['nodes']['host']} / subdomain {st_g['nodes']['subdomain']} "
                    f"/ endpoint {st_g['nodes']['endpoint']} / param {st_g['nodes']['param']} "
                    f"/ 本次并入 findings {n_ing_f}"
                    + ("，图谱段已追加报告" if ag_sec and report_path else ""))
            except Exception as exc:
                _safe_print(f"⚠️  攻击面图谱收尾失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")
            finally:
                try:
                    graph.close()
                except Exception:
                    pass

        # A ATT&CK 映射（落盘 attack_map.md + attack_navigator.json 到报告目录）
        if (adv.get("attack_map") or {}).get("enabled", True):
            try:
                from scanners import attack_map as am
                tool_hist = [{"tool": r.get("tool", "")} for r in tool_log if isinstance(r, dict)]
                a_report = am.map_findings(findings, target=target, tool_history=tool_hist)
                os.makedirs(report_dir, exist_ok=True)
                am.save_attack_artifacts(a_report, report_dir, name=str(target))
                advanced_lines.append(f"ATT&CK 映射: {am.format_summary(a_report).splitlines()[0]}"
                                      f" → {os.path.join(report_dir, 'attack_map.md')}")
            except Exception as exc:
                _safe_print(f"⚠️  ATT&CK 映射失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

        # B 修复建议（追加到报告末尾，幂等）
        if report_path and (adv.get("remediation") or {}).get("enabled", True):
            try:
                from scanners.remediation import RemediationEngine, append_remediation_section
                rem_cfg = adv.get("remediation") or {}
                rules_file = str(rem_cfg.get("rules_file") or "").strip()
                if rules_file and not os.path.isabs(rules_file):
                    rules_file = os.path.join(_PROJECT_ROOT, rules_file)
                engine = RemediationEngine(rules_path=rules_file or None)
                rems = engine.remediate_all(findings)
                if rems:
                    append_remediation_section(report_path, rems)
                    advanced_lines.append(
                        f"修复建议: {len(rems)} 条已追加到报告末尾（规则库 {engine.rule_count} 条规则）")
                else:
                    advanced_lines.append("修复建议: 无命中规则（finding 未匹配规则库）")
            except Exception as exc:
                _safe_print(f"⚠️  修复建议生成失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

        # G PoC 复现脚本（落盘到报告目录 + 报告内追加清单段）
        if findings and (adv.get("poc") or {}).get("enabled", True):
            try:
                from scanners import poc_builder as pb
                poc_cfg = adv.get("poc") or {}
                os.makedirs(report_dir, exist_ok=True)
                poc_paths = pb.write_poc_scripts(report_dir, findings,
                                                 prefix=str(poc_cfg.get("prefix") or "poc"))
                if poc_paths:
                    section = pb.render_poc_section(poc_paths)
                    if report_path:
                        _append_section_to_report(
                            report_path, "<!-- hack_scanner:poc_scripts -->", section)
                    advanced_lines.append(f"PoC 复现脚本: {len(poc_paths)} 个已生成 → {report_dir}/"
                                          f"（默认 DRY-RUN，授权后 --execute）")
            except Exception as exc:
                _safe_print(f"⚠️  PoC 脚本生成失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

        # I'' 任务清单报告段（4 项目升级清单 #8，todo_coach）— 收尾把最终清单状态写进报告（幂等）
        if todo_store is not None:
            try:
                from scanners import todo_coach as _tc
                todo_sec = _tc.render_todo_section(todo_store)
                if todo_sec and report_path:
                    _append_section_to_report(
                        report_path, "<!-- hack_scanner:todo -->", todo_sec)
                if todo_sec:
                    _tc2 = todo_store.counts()
                    advanced_lines.append(
                        f"任务清单: {len(todo_store.tasks)} 步（已完成 {_tc2['completed']} / 进行中 "
                        f"{_tc2['in_progress']} / 待办 {_tc2['pending']} / 失败 {_tc2['failed']}）"
                        + ("，清单段已追加报告" if report_path else ""))
            except Exception as exc:
                _safe_print(f"⚠️  任务清单段失败（降级跳过）: {type(exc).__name__}: {str(exc)[:120]}")

    # 5d. 经验蒸馏（① 自学习闭环）— 恰好 1 次预算外 LLM 调用，全部落 pending
    #     仅在"有真实素材"（发现或失败路径）时调用；空 campaign 不浪费 LLM
    distilled = []
    failed_paths = []
    if reflexion_engine is not None:
        try:
            failed_paths += reflexion_engine.get_failed_paths() or []
        except Exception:
            pass
    if loop_tracker is not None:
        failed_paths += [f"host:{h}" for h in sorted(getattr(loop_tracker, "blocked_targets", set()))]
    if learning and experience_store is not None and (findings or failed_paths):
        _safe_print("\n🧬 收尾蒸馏：把本次 campaign 提炼为可复用经验（额外 1 次 LLM 调用）…")
        try:
            from scanners.experience import (RunArtifacts, persist_distilled_lessons,
                                             default_run_id)
            artifacts = RunArtifacts(
                run_id=default_run_id(),
                target_key=str(target),
                verified_findings=[f for f in findings if isinstance(f, dict)],
                failed_paths=list(dict.fromkeys(failed_paths))[:20],
                reflexion_snapshot=(reflexion_engine.extract_experience() or {})
                                   if reflexion_engine is not None else {},
                transcript=_salvage_transcript(tool_log),
            )
            distilled = persist_distilled_lessons(llm_guarded, artifacts, experience_store)
        except Exception:
            distilled = []  # 蒸馏失败静默跳过（负路径验收项）

    # KB 引用行（⑤ 报告钩子：finding 命中模式卡 → 列 references）
    kb_lines = []
    if learning and kb is not None and findings:
        try:
            for f in findings:
                if not isinstance(f, dict):
                    continue
                vt = str(f.get("vuln_type") or f.get("type") or f.get("type_") or "")
                refs = kb.cards_for_vuln_type(vt)
                for c in refs[:2]:
                    for r in (c.get("references") or [])[:2]:
                        if r not in kb_lines:
                            kb_lines.append(r)
        except Exception:
            kb_lines = []

    learning_lines = []
    if kb_lines:
        learning_lines.append("KB 参考: " + "; ".join(kb_lines[:6]))
    if learning and experience_store is not None and (findings or failed_paths):
        if distilled:
            learning_lines.append(
                f"经验蒸馏: {len(distilled)} 条 pending lesson 已入库 data/experience/（待审核）")
        else:
            learning_lines.append("经验蒸馏: 本次无可沉淀 lesson（或蒸馏调用无产出）")

    _print_summary(state, client, tool_log, report_path, fallback_used,
                   findings_override=findings, findings_source=findings_source,
                   salvage_attempted=salvage_attempted,
                   verify_lines=verify_lines, learning_lines=learning_lines,
                   advanced_lines=advanced_lines)
    _close_journal(journal, "completed")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="AI 自适应渗透测试（实验）— LLM 自主驱动 recon → probe → classify → report")
    parser.add_argument("--target", required=True, help="目标 URL/域名")
    parser.add_argument("--objective", default="find all vulnerabilities", help="测试目标描述")
    parser.add_argument("--mode", choices=["full", "shallow"], default="full")
    parser.add_argument("--max-iterations", type=int, default=None,
                        help="迭代上限（默认无上限，Ctrl+C 可停；如 40）")
    parser.add_argument("--no-strategy", action="store_true",
                        help="不注入零日导向策略块/few-shot 场景（回退到旧行为）")
    parser.add_argument("--no-advanced", action="store_true",
                        help="关闭第2轮增强（ATT&CK映射/修复建议/审批门/断点续扫/并行探测/自纠正/PoC脚本/scope）")
    parser.add_argument("--resume-run-id", default=None,
                        help="断点续扫：runs/ 下既有 run 的 ID（如 20261010T210000Z_target）")
    parser.add_argument("--exploit-live", action="store_true",
                        help="允许 exploit 工具真实执行（默认 dry-run）")
    args = parser.parse_args(argv)

    interactive = sys.stdin is not None and hasattr(sys.stdin, "isatty") and sys.stdin.isatty()
    try:
        return run_adaptive(
            target=args.target,
            objective=args.objective,
            mode=args.mode,
            max_iterations=args.max_iterations,
            exploit_live=args.exploit_live,
            interactive=interactive,
            strategy=not args.no_strategy,
            advanced=not args.no_advanced,
            resume_run_id=args.resume_run_id,
        )
    except KeyboardInterrupt:
        _safe_print("\n⛔ 用户中断。")
        return 130


if __name__ == "__main__":
    sys.exit(main())
