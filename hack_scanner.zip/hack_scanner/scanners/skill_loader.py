#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Skill System — LLM 测试方法论技能库
===================================
借鉴 Strix (usestrix/strix) skills/*.md 的设计，适配 hack_scanner：

- 每个技能 = 一个 SKILL.md：frontmatter (name/description/tags) + 方法论正文
- description 是路由依据：route_skills() 按场景上下文挑选相关技能
- 正文遵循"诚实纪律"：明确标注**什么可测、什么不可测**，
  禁止 AI 谎报"已测试通过"（借鉴 Strix OWASP 技能的覆盖矩阵写法）

目录约定:
    hack_scanner/skills/<skill-name>/SKILL.md

编程接口:
    from scanners.skill_loader import list_skills, load_skill, route_skills, build_prompt_block

    skills = route_skills("OWASP Top10 web 评估 https://x.com")
    prompt_block = build_prompt_block(skills)   # 注入 system prompt 的 markdown 块

命令行自测:
    python scanners/skill_loader.py [场景上下文文本]

仅依赖标准库。
"""

import os
import re
import logging
from typing import Dict, List, Any, Optional, Tuple

logger = logging.getLogger('skill_loader')


# ==================== 路径 ====================

# skill_loader.py 位于 scanners/ 下，技能库在项目根 skills/ 下
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKILLS_DIR = os.path.join(_PROJECT_ROOT, 'skills')


def _skills_dir() -> str:
    """支持环境变量覆盖（便于测试/自定义技能库）"""
    return os.environ.get('HACK_SCANNER_SKILLS_DIR', SKILLS_DIR)


# ==================== Frontmatter 解析（无第三方依赖）====================

def _parse_frontmatter(text: str) -> Tuple[Dict[str, Any], str]:
    """解析简单的 YAML frontmatter。

    支持:
        key: value
        key: [a, b, c]     → list
        key: a, b, c       → 仅当 key 为 tags/keywords 时拆为 list
    不支持: 嵌套结构、多行字符串（技能文件不需要的）
    """
    meta: Dict[str, Any] = {}
    m = re.match(r'^---\s*\n(.*?)\n---\s*\n?', text, re.DOTALL)
    if not m:
        return meta, text

    body = text[m.end():]
    for line in m.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith('#') or ':' not in line:
            continue
        key, _, val = line.partition(':')
        key, val = key.strip(), val.strip()
        if not key:
            continue
        if val.startswith('[') and val.endswith(']'):
            val = [v.strip().strip('"\'') for v in val[1:-1].split(',') if v.strip()]
        elif key.lower() in ('tags', 'keywords') and ',' in val:
            val = [v.strip().strip('"\'') for v in val.split(',') if v.strip()]
        meta[key] = val
    return meta, body


# ==================== 技能加载 ====================

def list_skills() -> List[Dict[str, Any]]:
    """列出技能库中全部技能（按目录名排序）。"""
    skills: List[Dict[str, Any]] = []
    base = _skills_dir()
    if not os.path.isdir(base):
        logger.debug(f"技能目录不存在: {base}")
        return skills

    for entry in sorted(os.listdir(base)):
        p = os.path.join(base, entry, 'SKILL.md')
        if not os.path.isfile(p):
            continue
        try:
            with open(p, 'r', encoding='utf-8') as f:
                text = f.read()
        except OSError as e:
            logger.warning(f"⚠️ 技能文件读取失败 {p}: {e}")
            continue

        meta, body = _parse_frontmatter(text)
        tags = meta.get('tags', [])
        if isinstance(tags, str):
            tags = [tags] if tags else []
        skills.append({
            'name': meta.get('name') or entry,
            'description': str(meta.get('description', '')),
            'tags': tags,
            'body': body.strip(),
            'path': p,
        })
    return skills


def load_skill(name: str) -> Optional[Dict[str, Any]]:
    """按 name（或目录名）加载单个技能；找不到返回 None。"""
    for s in list_skills():
        if s['name'] == name or os.path.basename(os.path.dirname(s['path'])) == name:
            return s
    return None


# ==================== 路由（按场景挑技能）====================

_LATIN_TOKEN_RE = re.compile(r'[a-z0-9]+')
_CJK_RE = re.compile(r'[一-鿿]{2,}')

# 路由权重：name > tags > description
_W_NAME, _W_TAG, _W_DESC = 4, 3, 1
_MIN_LATIN_TOKEN = 3    # 短于 3 的拉丁 token（如 'ai'）噪声大，不参与 name 匹配
_MIN_DESC_TOKEN = 5     # description 里只看长 token，减少误匹配


def _latin_tokens(text: str) -> set:
    return {t for t in _LATIN_TOKEN_RE.findall((text or '').lower()) if len(t) >= _MIN_LATIN_TOKEN}


def _cjk_chunks(text: str) -> set:
    return set(_CJK_RE.findall(text or ''))


def route_skills(context: str, max_skills: int = 3, min_score: int = 3) -> List[Dict[str, Any]]:
    """按场景上下文对技能打分排序，返回前 max_skills 个。

    打分规则（确定性、无随机、无网络）：
      - 技能 name 中的 token 命中上下文   → +4 / 个
      - tags 命中（子串匹配，≥3 字符）    → +3 / 个
      - description 长 token 命中（≥5）   → +1 / 个
      - 中文按 ≥2 字连续片段匹配
    低于 min_score 的技能不返回。
    """
    ctx = context or ''
    ctx_lower = ctx.lower()
    scored: List[Tuple[int, Dict[str, Any]]] = []

    for s in list_skills():
        score = 0
        # name（高权重）
        for t in _latin_tokens(s['name']):
            if t in ctx_lower:
                score += _W_NAME
        for c in _cjk_chunks(s['name']):
            if c in ctx:
                score += _W_NAME
        # tags（中权重）
        for tag in s['tags']:
            tt = str(tag).lower()
            if len(tt) >= 3 and tt in ctx_lower:
                score += _W_TAG
            for c in _cjk_chunks(tag):
                if c in ctx:
                    score += _W_TAG
        # description（低权重）
        for t in _latin_tokens(s['description']):
            if len(t) >= _MIN_DESC_TOKEN and t in ctx_lower:
                score += _W_DESC

        if score >= min_score:
            scored.append((score, s))

    scored.sort(key=lambda x: (-x[0], x[1]['name']))
    return [s for _, s in scored[:max_skills]]


# ==================== Prompt 组装 ====================

def build_prompt_block(skills: List[Dict[str, Any]],
                       max_chars: int = 12000,
                       per_skill_chars: int = 6000) -> str:
    """把选中的技能转成可注入 system prompt 的 markdown 块。

    带两级长度上限：单技能 per_skill_chars、总量 max_chars，
    超出的技能降级为"标题占位"，避免挤占其他上下文。
    """
    if not skills:
        return ''

    parts = ['# 当前启用的测试方法论技能（遵循其诚实纪律：只报告已验证的；'
             '明确列出"未测试/不可测"项，禁止谎报通过）\n']
    used = 0
    for s in skills:
        body = s['body']
        if len(body) > per_skill_chars:
            body = body[:per_skill_chars] + f"\n\n…（技能内容较长已截断，全文见: {s['path']}）"
        chunk = f"## 技能: {s['name']}\n{body}\n\n"
        if used + len(chunk) > max_chars:
            parts.append(f"## 技能: {s['name']}（超出总长度上限，本次未展开）\n")
            continue
        parts.append(chunk)
        used += len(chunk)
    return '\n'.join(parts)


# ==================== 命令行自测 ====================

if __name__ == '__main__':
    import sys
    # Windows GBK 控制台兜底：强制 UTF-8 输出，避免中文/符号崩
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(name)s: %(message)s')

    ctx = ' '.join(sys.argv[1:]).strip() or 'OWASP Top 10 Web 应用安全评估 pentest https://example.com'
    print(f"场景上下文: {ctx}\n")

    picked = route_skills(ctx)
    print('== 路由结果 ==')
    if not picked:
        print('  （无命中技能）')
    for s in picked:
        print(f"  * {s['name']}  (正文 {len(s['body'])} 字符, tags={s['tags']})")

    print('\n== 技能库全量 ==')
    for s in list_skills():
        desc = s['description'][:70] + ('…' if len(s['description']) > 70 else '')
        print(f"  - {s['name']}: {desc}")

    block = build_prompt_block(picked[:1])
    print(f"\n== Prompt 块预览（前 400 字符）==\n{block[:400]}")
