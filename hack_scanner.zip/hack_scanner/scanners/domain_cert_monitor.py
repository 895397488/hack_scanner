#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Certificate Transparency Monitor — 通过 crt.sh API 查询域名的 SSL/TLS 证书历史。

用途：发现目标域名的子域名、过期证书、异常证书（可能被用于钓鱼）。
无需 API key，使用 crt.sh 公开 REST API。

Usage:
    from scanners.domain_cert_monitor import cert_monitor
    result = cert_monitor("example.com")
"""

import json
import logging
from urllib.request import urlopen, Request
from urllib.error import URLError
from typing import Dict, List, Optional

logger = logging.getLogger('cert_monitor')


def _crtsh_api(query: str) -> Optional[list]:
    """查询 crt.sh API"""
    url = f"https://crt.sh/?q={query}&output=json"
    try:
        req = Request(url)
        req.add_header('User-Agent', 'HackScanner/1.0')
        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        logger.warning(f"crt.sh API 请求失败: {e}")
        return None


def cert_monitor(domain: str) -> dict:
    """查询域名及其子域名的 SSL/TLS 证书。

    Args:
        domain: 目标域名

    Returns:
        {
            "ok": True,
            "domain": "...",
            "certificates": [
                {"subject": "*.example.com", "issuer": "Let's Encrypt",
                 "not_before": "2024-01-01", "not_after": "2025-01-01"}
            ],
            "subdomains_found_from_certs": ["api.example.com", ...],
            "expiring_soon": [...],
            "wildcard_count": 3,
            "error": ""
        }
    """
    result = {
        "ok": False,
        "domain": domain,
        "certificates": [],
        "subdomains_found_from_certs": [],
        "expiring_soon": [],
        "wildcard_count": 0,
        "error": "",
    }

    data = _crtsh_api(f"%.{domain}")
    if not data:
        return {**result, "error": "crt.sh API 不可达"}

    seen_names = set()
    certs = []
    subdomains = set()

    for cert in data:
        name = cert.get('common_name', '') or cert.get('name_value', '')
        if not name:
            continue

        # Extract base domain
        parts = name.split('.')
        if len(parts) >= 2 and domain.lower() in '.'.join(parts[-2:]).lower():
            pass  # Keep it
        elif domain.lower() not in name.lower():
            continue  # Skip unrelated certs

        # Collect subdomains from wildcard certificates
        if name.startswith('*.'):
            base = name[2:]
            result["wildcard_count"] += 1
            # Wildcard covers all subdomains, extract potential ones
            result["subdomains_found_from_certs"].append(f"*.{base}")

        if name not in seen_names:
            seen_names.add(name)
            certs.append({
                "subject": name,
                "issuer": cert.get('issuer_name', 'Unknown'),
                "not_before": cert.get('not_before', ''),
                "not_after": cert.get('not_after', ''),
                "serial_number": cert.get('serial_number', ''),
            })

            # Extract subdomains from name_value (comma-separated in crt.sh results)
            for nv in str(cert.get('name_value', '')).split(','):
                subdomain = nv.strip()
                if subdomain and domain.lower() in subdomain.lower() and subdomain != domain:
                    if not subdomain.startswith('*'):
                        subdomains.add(subdomain)

    result["certificates"] = certs[:200]
    result["subdomains_found_from_certs"] = sorted(subdomains)[:500]

    # Check for expiring/invalid certs
    import datetime
    now = datetime.datetime.utcnow()
    for cert in certs:
        try:
            expiry = datetime.datetime.strptime(cert["not_after"], "%Y-%m-%dT%H:%M:%S")
            if expiry - now < datetime.timedelta(days=30):
                result["expiring_soon"].append({
                    "subject": cert["subject"],
                    "expires": cert["not_after"],
                    "days_remaining": max(0, (expiry - now).days),
                })
        except (ValueError, KeyError):
            pass

    result["total_certs"] = len(certs)
    result["ok"] = True

    return result


def subdomains_from_cert(domain: str) -> dict:
    """仅通过证书透明度日志发现子域名。

    这是最精准的被动子域名发现方法之一（来自 cert transparency logs）。"""
    result = cert_monitor(domain)
    return {
        "ok": result.get("ok", False),
        "domain": domain,
        "subdomains": result.get("subdomains_found_from_certs", []),
        "total_subdomains": len(result.get("subdomains_found_from_certs", [])),
        "error": result.get("error", ""),
    }
