#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_journal.py — 持久化断点续扫（run journal + resume）
=====================================================================

用途
----
给 run_adaptive 入口层加一层"崩溃/杀进程可续"的持久化：扫描进行中的
每次 LLM turn、每次工具调用都落到磁盘，进程意外退出后可重建现场继续扫。

两个文件（run_dir 下，run_dir = <项目根>/runs/<run_id>/）:

- events.jsonl   【source of truth】append-only 事件流，每条事件一行 JSON，
                 每次写后 flush + fsync；进程死亡也不丢已落盘事件。
- run_state.json 【快照】每 turn 折叠一次的"最新视图"，
                 tmp + os.replace 原子写（Windows 安全），供快速读回/恢复。

参照实现
--------
vulnclaw run_context.py（site-packages/vulnclaw/run_context.py）：
  - 事件/快照分离        → append_event() vs write_manifest()
  - 状态折叠             → record_checkpoint()
  - 恢复对账             → repair_run_context()
  - 原子写               → atomic_write_text()（tmp + fsync + os.replace + 目录 fsync 尽力）
本模块照搬该思路，API 适配 hack_scanner 的入口层包装器模式；
纯标准库实现，不 import vulnclaw。

零 orchestrator 改动的接线方式
------------------------------
本模块不改 swarm_orchestrator.py 一行。所有挂钩都走入口层包装
（与 run_adaptive.install_result_recorder / install_strategy_coach 同模式）：

    from scanners.run_journal import (
        RunJournal, default_run_dir, install_run_journal,
        build_resume, reconcile_interrupted,
    )

    # 启动（新扫描）
    run_dir = default_run_dir(_PROJECT_ROOT, run_id)   # <root>/runs/<run_id>，自动建目录
    journal = RunJournal(run_dir)
    ...
    orch = SwarmOrchestrator(llm_invoke=llm_guarded, ...)
    binders.register_campaign_tools(orch, target, objective, ...)
    install_run_journal(orch, llm_guarded, journal)   # 包装 llm_invoke + 每个 tool.execute
    # 包装后的 llm 原地写回 orch.llm_invoke；也可经 journal.llm_invoke 取
    # 注意：应在所有工具注册完毕后再装（后注册的工具不会被包装）

    state = orch.run_campaign([target], campaign_objective, mode)
    ...
    journal.close("completed")      # 或 "interrupted"（Ctrl+C 后先 reconcile）/ "error"

    # 恢复（断点续扫）
    reconcile_interrupted(run_dir) # 上次未收尾的 running 事件 → interrupted 收尾（幂等）
    rs = build_resume(run_dir)     # ResumeState：messages/tool_log/findings/迭代数/...

事件词表（本模块写入的 event_type）:
    turn_start (running) → turn_done / turn_error
    tool_call  (running) → tool_done / tool_error
    *_interrupted（恢复对账追加）
    run_close（close() 收尾）

纯标准库（Python 3.14），零第三方依赖，零网络。
"""

from __future__ import annotations

import json
import os
import re
import secrets
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional

__all__ = [
    "RunJournal",
    "ResumeState",
    "default_run_dir",
    "reconcile_interrupted",
    "build_resume",
    "install_run_journal",
    "RUN_STATE_VERSION",
]

RUN_STATE_VERSION = 1
_RUN_ID_PATTERN = re.compile(r"^[A-Za-z0-9_.-]{1,120}$")

_EVENTS_NAME = "events.jsonl"
_STATE_NAME = "run_state.json"

# running 事件的"收尾"判定表（恢复对账用：后续出现任一 → 视为已收尾，不再补 interrupted）
_RESOLVERS = {
    "turn_start": ("turn_done", "turn_error", "turn_start_interrupted"),
    "tool_call": ("tool_done", "tool_error", "tool_call_interrupted"),
}

_SNAP_MSG_CONTENT_LIMIT = 16000   # 快照中单条 message content 上限（截断保护）
_SNAP_TOOLLOG_RESULT_LIMIT = 4000  # 快照中 tool_log 单条 result 上限
_EV_RESULT_LIMIT = 500            # 事件 payload 中 result 摘录上限


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
def _now_iso() -> str:
    """UTC ISO8601（Z 后缀），与 vulnclaw 同一格式。"""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _clip(value: Any, limit: int) -> str:
    """字符串化 + 截断（截断保护：事件 payload / 快照共用）。"""
    if value is None:
        return ""
    s = value if isinstance(value, str) else str(value)
    return s if len(s) <= limit else s[:limit] + "…"


def _fsync_dir(dirpath: str) -> None:
    """目录 fsync（POSIX 下把 rename 元数据落盘；Windows 无 O_DIRECTORY，尽力跳过）。"""
    flags = getattr(os, "O_DIRECTORY", None)
    if flags is None:
        return
    try:
        fd = os.open(dirpath, flags)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _atomic_write_text(path: str, text: str) -> None:
    """原子写：同目录 tmp → flush+fsync → os.replace → 目录 fsync（尽力）。"""
    dirpath = os.path.dirname(os.path.abspath(path))
    os.makedirs(dirpath, exist_ok=True)
    tmp = os.path.join(dirpath, f".{os.path.basename(path)}.{secrets.token_hex(6)}.tmp")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        # replace 失败时清理 tmp，不留下垃圾
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
    _fsync_dir(dirpath)


def _atomic_write_json(path: str, data: Any) -> None:
    _atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2, default=str))


def _count_lines(path: str) -> int:
    """按行计数（seq 基准；容忍损坏行——坏行也占一个编号，seq 永不重复）。"""
    n = 0
    try:
        with open(path, "rb") as f:
            for _ in f:
                n += 1
    except OSError:
        return 0
    return n


def _load_events(run_dir: str) -> list[dict]:
    """读回全部事件；损坏行静默跳过，文件缺失 → []（不抛异常）。"""
    path = os.path.join(run_dir, _EVENTS_NAME)
    out: list[dict] = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ev = json.loads(line)
                except (json.JSONDecodeError, ValueError):
                    continue  # 损坏行静默跳过
                if isinstance(ev, dict):
                    out.append(ev)
    except OSError:
        return []
    return out


def _load_state(run_dir: str) -> Optional[dict]:
    """读回快照；缺失/损坏/非 dict → None（不抛异常）。"""
    path = os.path.join(run_dir, _STATE_NAME)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _resolvers_for(event_type: str) -> tuple:
    """某 running 事件类型对应的"已收尾"事件类型集合。"""
    if event_type in _RESOLVERS:
        return _RESOLVERS[event_type]
    return (f"{event_type}_interrupted", f"{event_type}_done", f"{event_type}_error")


def _unwrap_boundary(result_text: Any) -> Any:
    """解包 prompt_safety 的 nonce 边界（若有），返回边界内正文。

    事件流/快照里记到的 classify 结果是"模型所见"（带不可信边界），
    重建 findings 必须解析正文；未包装/导入失败/异常 → 原样返回。
    本文件可被当脚本直接运行（自测），故相对导入失败时退回平铺导入。
    """
    if not isinstance(result_text, str) or not result_text:
        return result_text
    try:
        try:
            from .prompt_safety import unwrap_untrusted
        except Exception:
            from prompt_safety import unwrap_untrusted  # type: ignore
    except Exception:
        return result_text
    try:
        return unwrap_untrusted(result_text)
    except Exception:
        return result_text


def _extract_findings(result_text: Any) -> list[dict]:
    """从 classify 结果（JSON {"findings": [...]}）提取发现列表；任何失败静默返回 []。

    结果文本可能带 prompt_safety 不可信边界（记录器记的是模型所见），
    先解包再 JSON 解析——否则边界标记会让解析失败、findings 重建为空。
    """
    if not isinstance(result_text, str) or not result_text:
        return []
    try:
        data = json.loads(_unwrap_boundary(result_text))
    except (json.JSONDecodeError, ValueError):
        return []
    if not isinstance(data, dict):
        return []
    fs = data.get("findings")
    if not isinstance(fs, list):
        return []
    return [f for f in fs if isinstance(f, dict)][:50]


def _parse_campaign_meta(messages: Any, scan_limit: int = 12) -> dict:
    """从 campaign 启动消息解析 Target/Objective/Mode。

    orchestrator 的首条消息（swarm_orchestrator.run_campaign）固定形如:
        Campaign started.
        Target: ...
        Objective: ...
        Mode: ...
    策略教练等包装器可能前置注入消息，故向前扫描前若干条找 'Campaign started.'。
    找不到返回 {}（不抛异常）。
    """
    if not isinstance(messages, (list, tuple)):
        return {}
    for m in list(messages)[:scan_limit]:
        if not isinstance(m, dict):
            continue
        content = m.get("content")
        if not isinstance(content, str) or "Campaign started." not in content:
            continue
        meta = {}
        for line in content.splitlines():
            key, sep, val = line.partition(":")
            if not sep:
                continue
            k = key.strip().lower()
            if k in ("target", "objective", "mode"):
                meta[k] = val.strip()
        return meta
    return {}


def _as_msg_list(v: Any) -> list[dict]:
    if not isinstance(v, list):
        return []
    return [m for m in v if isinstance(m, dict)]


def _as_tool_log(v: Any) -> list[dict]:
    if not isinstance(v, list):
        return []
    out = []
    for r in v:
        if not isinstance(r, dict):
            continue
        err = r.get("error")
        out.append({
            "tool": str(r.get("tool") or ""),
            "result": r.get("result") if isinstance(r.get("result"), str) else str(r.get("result") or ""),
            "error": "" if err is None else (err if isinstance(err, str) else str(err)),
        })
    return out


def _as_list(v: Any) -> list:
    return v if isinstance(v, list) else []


def _as_int(v: Any) -> int:
    try:
        return max(0, int(v))
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------
# run_dir 约定
# ---------------------------------------------------------------------------
def default_run_dir(project_root: str, run_id: str) -> str:
    """返回 ``<project_root>/runs/<run_id>`` 并确保目录存在。

    run_id 由接线层传入（形如 ``20261010T210000Z_target-slug``），本模块不生成；
    此处只做合法性校验（防路径穿越），非法抛 ValueError。
    """
    rid = str(run_id or "")
    if not _RUN_ID_PATTERN.fullmatch(rid):
        raise ValueError(f"invalid run_id: {run_id!r} (must match [A-Za-z0-9_.-]{{1,120}})")
    path = os.path.join(os.path.abspath(str(project_root)), "runs", rid)
    os.makedirs(path, exist_ok=True)
    return path


# ---------------------------------------------------------------------------
# ResumeState
# ---------------------------------------------------------------------------
@dataclass
class ResumeState:
    """断点续扫：可重建上次 campaign 现场的数据。

    来自 run_state.json 快照（优先）或 events.jsonl 折叠（兜底）。
    """
    run_id: str = ""
    target: str = ""
    objective: str = ""
    mode: str = ""
    messages: list[dict] = field(default_factory=list)      # 上次 campaign 的消息历史（含 tool 结果）
    tool_log: list[dict] = field(default_factory=list)      # [{"tool","result","error"}, ...]
    findings: list[dict] = field(default_factory=list)      # 已 extract 的发现（若 classify 已完成）
    iterations_done: int = 0
    last_turn_at: str = ""


# ---------------------------------------------------------------------------
# RunJournal
# ---------------------------------------------------------------------------
class RunJournal:
    """单次 run 的事件日志 + 快照写入器。

    - record()    append 一条事件行（append-only，写后 flush+fsync）
    - snapshot()  run_state.json 原子写（每 turn 折叠一次）
    - close()     收尾事件 + 最终快照
    - events()    读回全部事件（损坏行跳过）

    本类不做任何扫描逻辑；install_run_journal() 负责把包装器接上来。
    """

    def __init__(self, run_dir: str):
        if not str(run_dir or "").strip():
            raise ValueError("run_dir is required")
        self._run_dir = os.path.abspath(str(run_dir))
        os.makedirs(self._run_dir, exist_ok=True)
        self._last_state: dict = {}
        self._closed = False
        # install_run_journal 挂包装后 llm（接线层可经此取回包装后的 invoke）
        self.llm_invoke: Optional[Callable] = None

    # ------------------------------------------------------------------
    @property
    def run_dir(self) -> str:
        return self._run_dir

    @property
    def run_id(self) -> str:
        return os.path.basename(self._run_dir.rstrip(os.sep + "/"))

    @property
    def events_path(self) -> str:
        return os.path.join(self._run_dir, _EVENTS_NAME)

    @property
    def state_path(self) -> str:
        return os.path.join(self._run_dir, _STATE_NAME)

    @property
    def closed(self) -> bool:
        return self._closed

    # ------------------------------------------------------------------
    def _record_ev(self, event_type: str, detail: str = "",
                   payload: Optional[dict] = None, status: str = "info") -> dict:
        """内部：append 一条事件并返回事件 dict（含 seq，供 ref_seq 配对）。"""
        if not isinstance(payload, dict):
            payload = {} if payload is None else {"value": str(payload)}
        ev = {
            "ts": _now_iso(),
            "seq": _count_lines(self.events_path) + 1,
            "event_type": str(event_type),
            "status": str(status),
            "detail": str(detail or ""),
            "payload": payload,
        }
        line = json.dumps(ev, ensure_ascii=False, default=str)
        with open(self.events_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
            f.flush()
            os.fsync(f.fileno())
        return ev

    def record(self, event_type: str, detail: str = "",
               payload: Optional[dict] = None, status: str = "info") -> None:
        """append 一行事件到 events.jsonl（source of truth）。

        事件行形状: ``{"ts", "seq", "event_type", "status", "detail", "payload"}``。
        seq 单调递增（按文件当前行数派生，多进程/重入追加亦不重复）。
        """
        self._record_ev(event_type, detail=detail, payload=payload, status=status)

    # ------------------------------------------------------------------
    def snapshot(self, state: dict) -> None:
        """把当前折叠状态原子写入 run_state.json（tmp + os.replace，Windows 安全）。

        快照是"最新视图"（供 build_resume 快速读回）；events.jsonl 仍是 source of truth。
        不修改传入的 state；附加 schema_version / run_id / saved_at 元信息。
        """
        doc = {
            "schema_version": RUN_STATE_VERSION,
            "run_id": self.run_id,
            "saved_at": _now_iso(),
        }
        if isinstance(state, dict):
            doc.update(state)
        else:
            doc["value"] = str(state)
        self._last_state = doc
        _atomic_write_json(self.state_path, doc)

    # ------------------------------------------------------------------
    def close(self, final_status: str) -> None:
        """收尾：append 收尾事件 + 写最终快照（可重复调用，各自独立留痕）。

        final_status: "completed" | "interrupted" | "error"
        最终快照 = 最近一次 snapshot() 状态 + final_status + closed_at。
        """
        final_status = str(final_status or "error")
        self._record_ev(
            "run_close",
            detail=f"final_status={final_status}",
            status=final_status,
            payload={"final_status": final_status},
        )
        state = dict(self._last_state)
        state["final_status"] = final_status
        state["closed_at"] = _now_iso()
        self.snapshot(state)
        self._closed = True

    # ------------------------------------------------------------------
    def events(self) -> list[dict]:
        """读回全部事件（损坏行静默跳过；文件缺失 → []，不抛异常）。"""
        return _load_events(self._run_dir)


# ---------------------------------------------------------------------------
# 恢复对账
# ---------------------------------------------------------------------------
def reconcile_interrupted(run_dir: str) -> list[dict]:
    """恢复对账：上次未收尾的事件（status=="running"）→ 追加对应 interrupted 收尾记录。

    - 对每条仍 dangling 的 running 事件，追加一条 ``<event_type>_interrupted``
      （status="interrupted"，payload.ref_seq 指回原事件 seq）。
    - 幂等：已有收尾（turn_done/turn_error/tool_done/tool_error/*_interrupted）
      的 running 事件跳过；重复调用返回 []、不重复追加。
    - 返回本次被对账的事件列表（原始 running 事件 dict）；无 → []。不抛异常。
    """
    events = _load_events(run_dir)
    journal = RunJournal(run_dir)
    reconciled: list[dict] = []
    for ev in events:
        if ev.get("status") != "running":
            continue
        seq = ev.get("seq")
        et = ev.get("event_type")
        if not isinstance(seq, int) or not isinstance(et, str):
            continue
        resolvers = _resolvers_for(et)
        resolved = any(
            isinstance(later.get("seq"), int)
            and later.get("seq") > seq
            and later.get("event_type") in resolvers
            for later in events
        )
        if resolved:
            continue
        journal._record_ev(
            f"{et}_interrupted",
            detail="interrupted (reconciled on resume)",
            status="interrupted",
            payload={"ref_seq": seq, "event_type": et},
        )
        reconciled.append(ev)
    return reconciled


# ---------------------------------------------------------------------------
# 断点续扫：重建现场
# ---------------------------------------------------------------------------
def _fold_events(events: list[dict]) -> dict:
    """事件流折叠（best-effort，事件流不含消息正文）：

    - target/objective/mode  ← 首个 turn_start 事件的 payload
    - tool_log               ← tool_call(running) × tool_done/tool_error 按 ref_seq 配对
    - findings               ← 最后一次 classify 成功结果中提取
    - iterations_done        ← turn_done 计数（0 时取 turn_start 计数）
    - last_turn_at           ← 最晚 turn_* 事件 ts
    """
    target = objective = mode = ""
    for ev in events:
        if ev.get("event_type") == "turn_start":
            p = ev.get("payload")
            p = p if isinstance(p, dict) else {}
            target = str(p.get("target") or "")
            objective = str(p.get("objective") or "")
            mode = str(p.get("mode") or "")
            break

    # tool_log：running tool_call × tool_done/tool_error 配对
    pending: dict = {}
    for ev in events:
        if ev.get("event_type") == "tool_call" and ev.get("status") == "running" \
                and isinstance(ev.get("seq"), int):
            p = ev.get("payload")
            p = p if isinstance(p, dict) else {}
            pending[ev["seq"]] = {"tool": str(p.get("tool") or ""), "result": "", "error": ""}
    tool_log: list[dict] = []
    for ev in events:
        et = ev.get("event_type")
        if et not in ("tool_done", "tool_error"):
            continue
        p = ev.get("payload")
        p = p if isinstance(p, dict) else {}
        entry = pending.pop(p.get("ref_seq"), None) or {
            "tool": str(p.get("tool") or ""), "result": "", "error": ""}
        entry["result"] = str(p.get("result") or entry["result"] or "")
        if et == "tool_error":
            entry["error"] = str(p.get("error") or p.get("result") or "")
        tool_log.append(entry)

    # findings：最后一次 classify 成功结果
    findings: list[dict] = []
    for ev in events:
        if ev.get("event_type") != "tool_done":
            continue
        p = ev.get("payload")
        p = p if isinstance(p, dict) else {}
        if p.get("tool") != "classify":
            continue
        fs = _extract_findings(p.get("result"))
        if fs:
            findings = fs

    iterations_done = sum(1 for ev in events if ev.get("event_type") == "turn_done")
    if not iterations_done:
        iterations_done = sum(1 for ev in events if ev.get("event_type") == "turn_start")
    turn_ts = [str(ev.get("ts") or "") for ev in events
               if isinstance(ev.get("event_type"), str) and ev.get("event_type").startswith("turn_")]
    last_turn_at = max(turn_ts) if turn_ts else ""

    return {
        "target": target, "objective": objective, "mode": mode,
        "tool_log": tool_log, "findings": findings,
        "iterations_done": iterations_done, "last_turn_at": last_turn_at,
    }


def build_resume(run_dir: str) -> ResumeState:
    """从 run_state.json 快照 + events.jsonl 事件流**合并**重建 ResumeState。

    快照只在 turn_done 时写（其后执行的工具调用只进事件流），且快照的
    tool_log 有界截断；事件流是 append-only 完整账本。故逐字段合并，
    各取更完整的一方，而不是快照整体优先：
      messages          ← 快照（事件流无消息正文；无快照 → 空）
      tool_log          ← 快照 / 事件折叠 取更长者
      findings          ← 快照非空优先，否则事件流最后一次 classify
      target/...        ← 快照非空优先，否则事件流首个 turn_start
      iterations_done   ← 二者取 max
      last_turn_at      ← 二者取较晚（ISO 字符串可比）
    无任何数据 → 空态 ResumeState（run_id 保留，其余空）。不抛异常。
    """
    run_id = os.path.basename(os.path.abspath(str(run_dir)).rstrip(os.sep + "/"))

    snap = _load_state(run_dir)
    folded = _fold_events(_load_events(run_dir))

    if snap is not None:
        s_tool_log = _as_tool_log(snap.get("tool_log"))
        e_tool_log = folded["tool_log"]
        s_findings = _as_list(snap.get("findings"))
        return ResumeState(
            run_id=str(snap.get("run_id") or run_id),
            target=str(snap.get("target") or folded["target"]),
            objective=str(snap.get("objective") or folded["objective"]),
            mode=str(snap.get("mode") or folded["mode"]),
            messages=_as_msg_list(snap.get("messages")),
            tool_log=s_tool_log if len(s_tool_log) >= len(e_tool_log) else e_tool_log,
            findings=s_findings or folded["findings"],
            iterations_done=max(_as_int(snap.get("iterations_done")),
                                folded["iterations_done"]),
            last_turn_at=max(str(snap.get("last_turn_at") or ""),
                             folded["last_turn_at"]),
        )

    return ResumeState(
        run_id=run_id,
        target=folded["target"],
        objective=folded["objective"],
        mode=folded["mode"],
        messages=[],
        tool_log=folded["tool_log"],
        findings=folded["findings"],
        iterations_done=folded["iterations_done"],
        last_turn_at=folded["last_turn_at"],
    )


# ---------------------------------------------------------------------------
# 入口层接线（orchestrator 零改动）
# ---------------------------------------------------------------------------
def install_run_journal(orch, llm_invoke, journal: RunJournal,
                        max_snapshot_msgs: int = 200) -> RunJournal:
    """入口层接线（orchestrator 零改动）：turn/工具调用日志 + 每 turn 快照。

    1) 包装 llm_invoke（每次调用 = 一个 turn）：
         调用前 → record("turn_start", status="running")
         返回后 → record("turn_done") + snapshot
                  （messages 条数 / tool 调用数 / 最近 finding 线索，截断保护）
         异常   → record("turn_error") 后重抛（不吞 LLM 异常）
    2) 包装每个 tool.execute：
         record("tool_call", payload={tool, args前200字}, status="running")
         → 执行 → record("tool_done" / "tool_error")（工具抛异常时同样记录后重抛，
           保持 orchestrator 原有异常语义）
    3) 透传 llm_invoke 的 .client（usage 记账）。

    返回 journal（便于接线层拿引用）；包装后的 llm 同时：
      - 原地写回 ``orch.llm_invoke``（对 SwarmOrchestrator 立即生效）
      - 挂在 ``journal.llm_invoke``（接线层可显式取用）

    注意：应在所有工具注册完毕后再调用（其后注册的工具不会被包装）。
    """
    if journal is None or not isinstance(journal, RunJournal):
        raise TypeError("journal must be a scanners.run_journal.RunJournal instance")
    max_snapshot_msgs = max(2, int(max_snapshot_msgs or 200))

    # 共享可变盒：跨 turn/tool 的折叠状态（单线程扫描，无需加锁）
    box: dict = {
        "target": "", "objective": "", "mode": "",
        "meta_seen": False,
        "turns": 0, "tool_calls": 0,
        "tool_log": [], "findings": [], "last_finding": "",
    }

    # ---------------- 1) 包装每个 tool.execute ----------------
    tools = getattr(orch, "tools", None)
    if isinstance(tools, dict):
        for name, tool in list(tools.items()):
            orig = getattr(tool, "execute", None)
            if orig is None or getattr(orig, "_run_journal_wrapped", False):
                continue  # 无 execute / 已包装 → 跳过（幂等）

            def wrap(args, _orig=orig, _name=name):
                call_ev = journal._record_ev(
                    "tool_call",
                    detail=f"tool={_name}",
                    payload={"tool": _name, "args": _clip(args, 200)},
                    status="running",
                )
                ref_seq = call_ev.get("seq")
                try:
                    res, err = _orig(args)
                except Exception as exc:
                    # 记录后重抛：保持"工具抛异常"的原语义（orchestrator 的 except 统一兜）
                    journal._record_ev(
                        "tool_error",
                        detail=f"tool={_name} raised: {type(exc).__name__}: {str(exc)[:200]}",
                        status="error",
                        payload={"tool": _name, "ref_seq": ref_seq,
                                 "result": "", "error": f"{type(exc).__name__}: {exc}"},
                    )
                    raise
                box["tool_calls"] += 1
                res_s = res if isinstance(res, str) else ("" if res is None else str(res))
                box["tool_log"].append({
                    "tool": _name,
                    "result": res_s,
                    "error": None if err is None else str(err),
                })
                if len(box["tool_log"]) > 500:  # 内存保护：只留最近 500 条
                    del box["tool_log"][: len(box["tool_log"]) - 500]
                # classify 成功 → 折叠发现（供快照/断点续扫的"最近 finding 线索"）
                if _name == "classify" and err is None:
                    fs = _extract_findings(res_s)
                    if fs:
                        box["findings"] = fs
                        box["last_finding"] = _clip(
                            "; ".join(f"{f.get('severity', '?')} {f.get('title', '?')}"
                                      for f in fs[:5]),
                            300,
                        )
                if err is None:
                    journal._record_ev(
                        "tool_done",
                        detail=f"tool={_name} ok",
                        status="done",
                        payload={"tool": _name, "ref_seq": ref_seq,
                                 "result": _clip(res_s, _EV_RESULT_LIMIT)},
                    )
                else:
                    journal._record_ev(
                        "tool_error",
                        detail=f"tool={_name} error={str(err)[:200]}",
                        status="error",
                        payload={"tool": _name, "ref_seq": ref_seq,
                                 "result": _clip(res_s, _EV_RESULT_LIMIT),
                                 "error": str(err)},
                    )
                return res, err

            wrap._run_journal_wrapped = True  # type: ignore[attr-defined]
            tool.execute = wrap

    # ---------------- 2) 包装 llm_invoke（每次调用 = 一个 turn） ----------------
    def _take_messages(args: tuple, kwargs: dict) -> list:
        messages = kwargs.get("messages")
        if messages is None and len(args) >= 2:
            messages = args[1]
        if isinstance(messages, (list, tuple)):
            return list(messages)
        return []

    def wrapped_llm(*args, **kwargs):
        messages = _take_messages(args, kwargs)
        # campaign 元信息（Target/Objective/Mode）：首轮解析一次，供快照/事件折叠
        if not box["meta_seen"]:
            meta = _parse_campaign_meta(messages)
            if meta:
                box["target"] = meta.get("target", "")
                box["objective"] = meta.get("objective", "")
                box["mode"] = meta.get("mode", "")
            else:
                box["meta_seen"] = True  # 未找到则不再扫描（不浪费每轮开销）
        journal.record(
            "turn_start",
            detail=f"turn_start (messages={len(messages)})",
            status="running",
            payload={"message_count": len(messages),
                     "target": box["target"], "objective": box["objective"],
                     "mode": box["mode"]},
        )
        try:
            resp = llm_invoke(*args, **kwargs)
        except Exception as exc:
            # 不吞 LLM 异常：先落盘（turn 失败也有据可查）再原样重抛
            journal.record(
                "turn_error",
                detail=f"LLM call failed: {type(exc).__name__}: {str(exc)[:200]}",
                status="error",
                payload={"exception": type(exc).__name__, "error": _clip(exc, 500)},
            )
            raise

        box["turns"] += 1
        # --- 快照（截断保护）：首条（campaign 启动，带 meta）保留 + 最近保留 ---
        snap_msgs = list(messages)
        if len(snap_msgs) > max_snapshot_msgs:
            if max_snapshot_msgs > 2:
                head, tail = snap_msgs[:1], snap_msgs[-(max_snapshot_msgs - 2):]
                dropped = len(snap_msgs) - len(head) - len(tail)
                snap_msgs = head + [
                    {"role": "system",
                     "content": f"[run_journal snapshot] {dropped} middle messages "
                                f"truncated (events.jsonl holds the full event stream)"},
                ] + tail
            else:
                snap_msgs = snap_msgs[:1] + snap_msgs[-1:]
        snap_msgs = [
            dict(m, content=m["content"][:_SNAP_MSG_CONTENT_LIMIT] + "…")
            if isinstance(m, dict) and isinstance(m.get("content"), str)
            and len(m["content"]) > _SNAP_MSG_CONTENT_LIMIT
            else m
            for m in snap_msgs
        ]

        journal.record(
            "turn_done",
            detail=f"turn_done (turns={box['turns']} tool_calls={box['tool_calls']})",
            status="done",
            payload={"iterations_done": box["turns"], "message_count": len(snap_msgs)},
        )
        journal.snapshot({
            "target": box["target"],
            "objective": box["objective"],
            "mode": box["mode"],
            "status": "running",
            "iterations_done": box["turns"],
            "tool_calls": box["tool_calls"],
            "last_finding": box["last_finding"],
            "findings": list(box["findings"])[:50],
            "tool_log": [
                {"tool": e.get("tool", ""),
                 "result": _clip(e.get("result"), _SNAP_TOOLLOG_RESULT_LIMIT),
                 "error": e.get("error") or ""}
                for e in box["tool_log"][-max_snapshot_msgs:]
            ],
            "last_turn_at": _now_iso(),
            "messages": snap_msgs,
        })
        return resp

    wrapped_llm.client = getattr(llm_invoke, "client", None)  # 透传 .client（usage 记账）
    wrapped_llm._run_journal = journal  # type: ignore[attr-defined]  # 测试/接线钩子
    journal.llm_invoke = wrapped_llm
    if orch is not None:
        try:
            orch.llm_invoke = wrapped_llm  # 原地写回 → orchestrator 下一次调用即生效
        except Exception:
            pass
    return journal
