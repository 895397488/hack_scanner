#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ExifTool Wrapper — exiftool CLI wrapper，文件元数据深度提取。

作为 file_meta.py(exifread Python 库) 的增强备选：
  - exifread → 轻量 Python 库，仅 JPEG/EXIF 核心字段
  - exiftool → 全格式（图片/文档/音视频/可执行/压缩包），字段更全，支持 -j JSON 输出

集成方式：需要安装 exiftool
  - Windows: choco install exiftool  或  https://exiftool.org/  (下载 exiftool(-g.exe).zip)
  - Linux:   apt install libimage-exiftool-perl
本模块只负责 CLI 调用和结果解析。config.json → tools.exiftool_path 可指定路径。

Usage:
    from scanners.exiftool_wrapper import exiftool_extract
    result = exiftool_extract("photo.jpg")
"""

import json
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('exiftool_scanner')


def _find_exiftool() -> Optional[str]:
    """查找 exiftool 可执行文件：先 config.json → tools.exiftool_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("exiftool_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["exiftool", "exiftool.exe", "exiftool-g.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def exiftool_extract(file_path: str, max_time: int = 30) -> dict:
    """提取文件元数据（exiftool -j JSON 输出）。

    Args:
        file_path: 目标文件路径
        max_time:  最大运行时间秒

    Returns:
        {"ok": bool, "metadata": {...}, "field_count": N, "error": ...}
    """
    if not file_path or not os.path.isfile(file_path):
        return {"ok": False, "metadata": {}, "field_count": 0, "error": f"文件不存在: {file_path}"}

    et = _find_exiftool()
    if not et:
        return {"ok": False, "metadata": {}, "field_count": 0,
                "error": "exiftool 未找到，请安装: choco install exiftool (Windows) 或见 https://exiftool.org/"}

    cmd = [et, "-j", "-m", file_path]
    logger.info(f"exiftool extract: {file_path}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = proc.stdout or "{}"
        data = json.loads(raw)
        if isinstance(data, list):
            data = data[0] if data else {}
        # 扁平化：group:Tag → Tag，保留原始值
        flat = {}
        for k, v in data.items():
            if isinstance(v, (str, int, float, bool)):
                flat[k] = v
            elif isinstance(v, list):
                flat[k] = ", ".join(str(x) for x in v[:50])
        return {"ok": True, "metadata": flat, "field_count": len(flat), "error": ""}
    except subprocess.TimeoutExpired:
        return {"ok": False, "metadata": {}, "field_count": 0, "error": "exiftool 超时"}
    except json.JSONDecodeError as e:
        return {"ok": False, "metadata": {}, "field_count": 0, "error": f"exiftool 输出解析失败: {e}"}


def exiftool_compare(file_a: str, file_b: str, max_time: int = 60) -> dict:
    """对比两个文件的元数据差异（用于隐写/篡改检测）。

    Args:
        file_a: 文件 A
        file_b: 文件 B
        max_time: 最大运行时间秒

    Returns:
        {"ok": bool, "only_in_a": {...}, "only_in_b": {...}, "diff": {...}, "error": ...}
    """
    if not file_a or not os.path.isfile(file_a):
        return {"ok": False, "error": f"文件不存在: {file_a}"}
    if not file_b or not os.path.isfile(file_b):
        return {"ok": False, "error": f"文件不存在: {file_b}"}

    ra = exiftool_extract(file_a, max_time=max_time // 2)
    rb = exiftool_extract(file_b, max_time=max_time // 2)
    if not ra["ok"] or not rb["ok"]:
        return {"ok": False, "error": ra.get("error") or rb.get("error")}

    ma, mb = ra["metadata"], rb["metadata"]
    only_a = {k: v for k, v in ma.items() if k not in mb}
    only_b = {k: v for k, v in mb.items() if k not in ma}
    diff = {k: {"a": ma[k], "b": mb[k]} for k in set(ma) & set(mb) if str(ma[k]) != str(mb[k])}

    return {
        "ok": True,
        "only_in_a": only_a,
        "only_in_b": only_b,
        "diff": diff,
        "diff_count": len(diff) + len(only_a) + len(only_b),
        "error": "",
    }
