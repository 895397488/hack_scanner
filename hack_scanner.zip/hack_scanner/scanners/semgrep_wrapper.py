#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Semgrep Wrapper — semgrep CLI wrapper，多语言 SAST 静态分析引擎。

swarm_playbooks.py 的 CI/CD playbook 已点名 semgrep（SAST 步骤），
装上即可被 playbook 调度。支持 30+ 语言，OWASP Top-10 规则开箱即用。

集成方式：需要安装 semgrep
  - pip install semgrep   (推荐，Python 环境直接可用)
  - 或独立二进制: https://semgrep.dev/docs/installation/
本模块只负责 CLI 调用和结果解析。config.json → tools.semgrep_path 可指定路径。

Usage:
    from scanners.semgrep_wrapper import semgrep_scan
    result = semgrep_scan("./src")
"""

import json
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('semgrep_scanner')


def _find_semgrep() -> Optional[str]:
    """查找 semgrep 可执行文件：先 config.json → tools.semgrep_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("semgrep_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["semgrep", "semgrep.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def semgrep_scan(target_path: str, rules: str = "auto", max_time: int = 600) -> dict:
    """运行 semgrep SAST 静态分析。

    Args:
        target_path: 代码目录路径
        rules: 规则集（auto=自动/ p=owasp-top-ten/ 自定义规则文件或规则 ID）
        max_time: 最大运行时间秒

    Returns:
        {"ok": bool, "findings": [...], "findings_count": N, "error": ...}
    """
    if not target_path or not os.path.exists(target_path):
        return {"ok": False, "findings": [], "findings_count": 0, "error": f"路径不存在: {target_path}"}

    sg = _find_semgrep()
    if not sg:
        return {"ok": False, "findings": [], "findings_count": 0,
                "error": "semgrep 未找到，请安装: pip install semgrep"}

    # 规则集映射
    config_map = {
        "auto": "auto",
        "p": "p",
        "owasp": "p/owasp-top-ten",
        "ci": "p/ci",
        "security": "p/security-audit",
    }
    rule_cfg = config_map.get(rules.lower(), rules)

    cmd = [sg, "scan", "--config", rule_cfg, "--json", "--error", target_path]
    logger.info(f"semgrep scan: {target_path} (config={rule_cfg})")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = proc.stdout or "{}"
        # semgrep 的 JSON 可能带日志前缀，定位第一个 {
        brace = raw.find("{")
        if brace >= 0:
            raw = raw[brace:]
        data = json.loads(raw)

        results = data.get("results", []) or []
        findings = []
        for r in results:
            sev_raw = (r.get("extra", {}) or {}).get("severity", "INFO")
            sev = sev_raw.lower()
            if sev in ("error",):
                severity = "high"
            elif sev in ("warning",):
                severity = "medium"
            else:
                severity = "low"
            findings.append({
                "rule_id": r.get("check_id", ""),
                "path": r.get("path", ""),
                "line": (r.get("start", {}) or {}).get("line"),
                "end_line": (r.get("end", {}) or {}).get("line"),
                "message": (r.get("extra", {}) or {}).get("message", ""),
                "severity": severity,
            })

        return {
            "ok": True,
            "target": target_path,
            "findings": findings[:500],
            "findings_count": len(findings),
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "findings": [], "findings_count": 0, "error": "semgrep 超时"}
    except json.JSONDecodeError as e:
        return {"ok": False, "findings": [], "findings_count": 0, "error": f"semgrep 输出解析失败: {e}"}
