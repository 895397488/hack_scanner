#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Login Sequence Recorder (LSR) -- record multi-step login flows via headless browser,
mirroring Acunetix's sequence-recorder.profile functionality.

Supports:
  - Multi-step authentication (login -> 2FA -> captcha -> redirect)
  - Form field auto-detection on each step
  - Session token / cookie capture after successful login
  - Visual confirmation via screenshot at each step
  - Replay for authenticated scanning

Usage:
    from scanners.login_sequence import LoginSequenceRecorder, RecordedSequence

    recorder = LoginSequenceRecorder(target_url="https://example.com")
    # Step 1: record the flow (or load a recorded sequence)
    recorder.discover_login_page()
    recorder.click_element("input[name=username]")
    recorder.type_into_element("input[name=username]", "admin")
    recorder.click_element("input[name=password]")
    recorder.type_into_element("input[name=password]", "secret")
    recorder.click_element("button[type=submit]")
    recorder.wait_for_redirect()
    sequence = recorder.finalize()

    # Replay for authenticated scanning
    session = sequence.replay()
    print(f"Authenticated: {session.is_authenticated}")
"""

import json
import logging
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import requests

try:
    from rate_limiter import make_guarded_session
except ImportError:
    from ..rate_limiter import make_guarded_session

logger = logging.getLogger('login_sequence')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class LoginStep:
    """A single step in the login sequence."""
    step_type: str            # 'navigate', 'click', 'type', 'wait', 'verify', 'screenshot'
    selector: str = ''         # CSS/XPath selector for the target element
    action_value: str = ''     # text to type, URL to navigate to, etc.
    wait_ms: int = 0          # milliseconds to wait after this step
    verify_contains: str = ''  # text/element to check for (success verification)
    screenshot_name: str = ''  # filename for screenshot capture
    notes: str = ''            # human-readable description


@dataclass
class RecordedSequence:
    """A complete recorded login sequence."""
    target_url: str
    name: str = 'Recorded Sequence'
    steps: List[LoginStep] = field(default_factory=list)
    initial_cookies: Dict[str, str] = field(default_factory=dict)
    post_login_cookies: Dict[str, str] = field(default_factory=dict)
    post_login_headers: Dict[str, str] = field(default_factory=dict)
    success_criteria: List[str] = field(default_factory=list)
    login_url: str = ''
    session_token_name: Optional[str] = None
    screenshot_dir: str = ''

    def to_dict(self) -> Dict[str, Any]:
        return {
            'target_url': self.target_url,
            'name': self.name,
            'steps': [asdict(s) for s in self.steps],
            'initial_cookies': self.initial_cookies,
            'post_login_cookies': self.post_login_cookies,
            'post_login_headers': self.post_login_headers,
            'success_criteria': self.success_criteria,
            'login_url': self.login_url,
            'session_token_name': self.session_token_name,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'RecordedSequence':
        return cls(
            target_url=data['target_url'],
            name=data.get('name', 'Loaded Sequence'),
            steps=[LoginStep(**s) for s in data.get('steps', [])],
            initial_cookies=data.get('initial_cookies', {}),
            post_login_cookies=data.get('post_login_cookies', {}),
            post_login_headers=data.get('post_login_headers', {}),
            success_criteria=data.get('success_criteria', []),
            login_url=data.get('login_url', ''),
            session_token_name=data.get('session_token_name'),
        )

    def save(self, filepath: str):
        """Save the recorded sequence to a JSON file."""
        os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
        logger.info('LSR sequence saved: %s (%d steps)', filepath, len(self.steps))

    @classmethod
    def load(cls, filepath: str) -> 'RecordedSequence':
        """Load a recorded sequence from a JSON file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        seq = cls.from_dict(data)
        logger.info('LSR sequence loaded: %s (%d steps)', filepath, len(seq.steps))
        return seq


# ====================================================================
# Browser automation helpers
# ====================================================================

class _BrowserDriver:
    """Abstract browser driver that works with Selenium or Playwright."""

    def __init__(self):
        self._browser = None
        self._page = None
        self._engine = ''

    @property
    def is_available(self) -> bool:
        return self._page is not None

    def navigate(self, url: str):
        raise NotImplementedError

    def click(self, selector: str):
        raise NotImplementedError

    def type_text(self, selector: str, text: str, clear_first: bool = True):
        raise NotImplementedError

    def wait_for_selector(self, selector: str, timeout_ms: int = 5000) -> bool:
        raise NotImplementedError

    def wait_for_navigation(self, timeout_ms: int = 10000) -> bool:
        raise NotImplementedError

    def get_cookies(self) -> Dict[str, str]:
        raise NotImplementedError

    def get_url(self) -> str:
        raise NotImplementedError

    def get_page_source(self) -> str:
        raise NotImplementedError

    def get_visible_text(self) -> str:
        raise NotImplementedError

    def take_screenshot(self, filepath: str):
        raise NotImplementedError

    def evaluate(self, js: str) -> Any:
        raise NotImplementedError

    def close(self):
        if self._browser:
            try:
                if hasattr(self._browser, 'close'):
                    import asyncio
                    if hasattr(self._browser.close, '__await__'):
                        asyncio.get_event_loop().run_until_complete(self._browser.close())
                    else:
                        self._browser.close()
            except Exception:
                pass

    @classmethod
    def create(cls) -> '_BrowserDriver':
        """Auto-create the best available browser driver."""
        # Try Playwright first
        try:
            from playwright_driver import PlaywrightDriver  # type: ignore
            return PlaywrightDriver()
        except (ImportError, Exception):
            pass

        # Fall back to Selenium
        try:
            from selenium_driver import SeleniumDriver  # type: ignore
            return SeleniumDriver()
        except (ImportError, Exception):
            pass

        logger.warning('No browser automation library available (Selenium/Playwright required)')
        return _NullDriver()


class _NullDriver(_BrowserDriver):
    """Null driver when no browser is available."""

    def __init__(self):
        super().__init__()
        self._page = None  # override is_available check

    def navigate(self, url: str): pass
    def click(self, selector: str): pass
    def type_text(self, selector: str, text: str, clear_first: bool = True): pass
    def wait_for_selector(self, selector: str, timeout_ms: int = 5000): return False
    def wait_for_navigation(self, timeout_ms: int = 10000): return False
    def get_cookies(self): return {}
    def get_url(self): return ''
    def get_page_source(self): return ''
    def get_visible_text(self): return ''
    def take_screenshot(self, filepath: str): pass
    def evaluate(self, js: str): return None


# Playwright driver (if available)
class PlaywrightDriver(_BrowserDriver):
    """Playwright-based browser driver."""

    def __init__(self):
        super().__init__()
        try:
            from playwright.async_api import async_playwright
            import asyncio
            self._pw = asyncio.get_event_loop().run_until_complete(async_playwright().start())
            self._browser = asyncio.get_event_loop().run_until_complete(self._pw.chromium.launch(headless=True))
            ctx = asyncio.get_event_loop().run_until_complete(self._browser.new_context(
                viewport={'width': 1920, 'height': 1080}))
            self._page = asyncio.get_event_loop().run_until_complete(ctx.new_page())
            self._engine = 'playwright'
        except Exception as e:
            logger.error('Playwright driver init failed: %s', e)

    def navigate(self, url: str):
        import asyncio
        asyncio.get_event_loop().run_until_complete(self._page.goto(url))

    def click(self, selector: str):
        import asyncio
        asyncio.get_event_loop().run_until_complete(self._page.click(selector))

    def type_text(self, selector: str, text: str, clear_first: bool = True):
        import asyncio
        if clear_first:
            asyncio.get_event_loop().run_until_complete(self._page.fill(selector, ''))
        asyncio.get_event_loop().run_until_complete(self._page.type(selector, text))

    def wait_for_selector(self, selector: str, timeout_ms: int = 5000):
        import asyncio
        try:
            asyncio.get_event_loop().run_until_complete(
                self._page.wait_for_selector(selector, timeout=timeout_ms))
            return True
        except Exception:
            return False

    def wait_for_navigation(self, timeout_ms: int = 10000):
        import asyncio
        try:
            asyncio.get_event_loop().run_until_complete(
                self._page.wait_for_load_state('networkidle', timeout=timeout_ms))
            return True
        except Exception:
            return False

    def get_cookies(self) -> Dict[str, str]:
        import asyncio
        cookies = asyncio.get_event_loop().run_until_complete(self._page.context.cookies())
        return {c['name']: c['value'] for c in cookies}

    def get_url(self) -> str:
        return self._page.url

    def get_page_source(self) -> str:
        import asyncio
        return asyncio.get_event_loop().run_until_complete(self._page.content())

    def get_visible_text(self) -> str:
        return self._page.text_content('body') or ''

    def take_screenshot(self, filepath: str):
        import asyncio
        asyncio.get_event_loop().run_until_complete(self._page.screenshot(path=filepath))

    def evaluate(self, js: str) -> Any:
        import asyncio
        return asyncio.get_event_loop().run_until_complete(self._page.evaluate(js))


class SeleniumDriver(_BrowserDriver):
    """Selenium-based browser driver."""

    def __init__(self):
        super().__init__()
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options as SeleniumChromeOptions
        opts = SeleniumChromeOptions()
        opts.add_argument('--headless=new')
        opts.add_argument('--no-sandbox')
        opts.add_argument('--disable-dev-shm-usage')
        self._browser = webdriver.Chrome(options=opts)
        self._page = self._browser
        self._engine = 'selenium'

    def navigate(self, url: str): self._page.get(url)
    def click(self, selector: str): self._page.find_element('css selector', selector).click()
    def type_text(self, selector: str, text: str, clear_first: bool = True):
        el = self._page.find_element('css selector', selector)
        if clear_first:
            el.clear()
        el.send_keys(text)
    def wait_for_selector(self, selector: str, timeout_ms: int = 5000):
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        try:
            WebDriverWait(self._page, timeout_ms / 1000).until(
                EC.presence_of_element_located(('css selector', selector)))
            return True
        except Exception:
            return False
    def wait_for_navigation(self, timeout_ms: int = 10000):
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        try:
            WebDriverWait(self._browser, timeout_ms / 1000).until(EC.staleness_of(self._page))
            return True
        except Exception:
            return False
    def get_cookies(self) -> Dict[str, str]:
        return {c['name']: c['value'] for c in self._page.get_cookies()}
    def get_url(self) -> str: return self._page.current_url
    def get_page_source(self) -> str: return self._page.page_source
    def get_visible_text(self) -> str: return self._page.find_element('css selector', 'body').text
    def take_screenshot(self, filepath: str): self._page.save_screenshot(filepath)
    def evaluate(self, js: str) -> Any: return self._page.execute_script(js)


# ====================================================================
# LoginSequenceRecorder -- main class
# ====================================================================

class LoginSequenceRecorder:
    """Record and replay multi-step login flows via headless browser."""

    DEFAULT_WAIT_AFTER_CLICK_MS = 500
    DEFAULT_TIMEOUT_MS = 10000
    SUCCESS_INDICATORS = [
        'logout', 'sign out', '/dashboard', '/profile', '/account', '/admin',
        '/home', '/welcome', 'username', 'signed in', 'authenticated',
        'your profile', 'my account',
    ]

    def __init__(self, target_url: str = '', driver: Optional[_BrowserDriver] = None,
                 screenshot_dir: str = ''):
        self.target_url = target_url
        if not self.target_url.startswith(('http://', 'https://')) and self.target_url:
            self.target_url = 'https://' + self.target_url

        self._driver = driver or _BrowserDriver.create()
        self._screenshot_dir = screenshot_dir or os.path.join(os.getcwd(), 'lsr_screenshots')
        os.makedirs(self._screenshot_dir, exist_ok=True)

        self._current_step: int = 0
        self._recorded_steps: List[LoginStep] = []
        self._initial_cookies: Dict[str, str] = {}
        self._post_login_cookies: Dict[str, str] = {}
        self._success_criteria: List[str] = list(self.SUCCESS_INDICATORS)

        self._recording: bool = False
        self._last_url: str = ''

    @property
    def steps(self) -> List[LoginStep]:
        return list(self._recorded_steps)

    # -- Recording phase ---------------------------------------------------

    def start_recording(self):
        """Begin a new recording session."""
        self._recording = True
        self._recorded_steps.clear()
        self._current_step = 0
        logger.info('Recording started for %s', self.target_url)

    def stop_recording(self):
        """End the current recording and finalize the sequence."""
        self._recording = False
        return self.finalize()

    def navigate(self, url: str, wait_ms: int = 0):
        """Record a navigation step."""
        if not self._driver.is_available:
            logger.error('No browser available for recording')
            return None
        self._driver.navigate(url)
        self._driver.wait_for_navigation(wait_ms or self.DEFAULT_TIMEOUT_MS)
        step = LoginStep(step_type='navigate', action_value=url, wait_ms=wait_ms)
        self._recorded_steps.append(step)
        self._current_step += 1
        return step

    def click(self, selector: str, wait_ms: int = 0):
        """Record a click step."""
        if not self._driver.is_available:
            return None
        self._driver.click(selector)
        if wait_ms or (self.DEFAULT_WAIT_AFTER_CLICK_MS > 0):
            time.sleep((wait_ms or self.DEFAULT_WAIT_AFTER_CLICK_MS) / 1000.0)
        step = LoginStep(step_type='click', selector=selector, wait_ms=wait_ms or self.DEFAULT_WAIT_AFTER_CLICK_MS)
        self._recorded_steps.append(step)
        self._current_step += 1
        return step

    def type_into(self, selector: str, text: str, wait_ms: int = 0):
        """Record a text input step."""
        if not self._driver.is_available:
            return None
        self._driver.type_text(selector, text)
        step = LoginStep(step_type='type', selector=selector, action_value=text, wait_ms=wait_ms)
        self._recorded_steps.append(step)
        self._current_step += 1
        return step

    def wait_for_element(self, selector: str, timeout_ms: int = 5000):
        """Wait for and record a visible element (step verification)."""
        if not self._driver.is_available:
            return None
        found = self._driver.wait_for_selector(selector, timeout_ms)
        step = LoginStep(step_type='verify', selector=selector, verify_contains=selector)
        self._recorded_steps.append(step)
        self._current_step += 1
        return step

    def take_screenshot_at_step(self, name: str = ''):
        """Record and capture a screenshot at the current step."""
        if not self._driver.is_available:
            return None
        if not name:
            name = f'step_{self._current_step}'
        filepath = os.path.join(self._screenshot_dir, f'{name}.png')
        self._driver.take_screenshot(filepath)
        step = LoginStep(step_type='screenshot', screenshot_name=name)
        self._recorded_steps.append(step)
        return step

    def wait(self, ms: int):
        """Record a pause step."""
        step = LoginStep(step_type='wait', wait_ms=ms)
        time.sleep(ms / 1000.0)
        self._recorded_steps.append(step)
        self._current_step += 1
        return step

    def auto_discover_login(self) -> Optional['RecordedSequence']:
        """Auto-discover the login form and attempt to record a standard login flow."""
        if not self.target_url:
            logger.error('No target URL set')
            return None

        # Navigate to target
        start_seq = self._record_steps_from_current()

        # Find common login URLs
        parsed = urlparse(self.target_url)
        login_candidates = [
            urljoin(self.target_url, p) for p in ['/login', '/signin', '/auth', '/account/login']
        ]

        for login_url in login_candidates:
            self._driver.navigate(login_url)
            time.sleep(1)
            source = self._driver.get_page_source()
            if 'login' in source.lower() or 'password' in source.lower():
                # Record form fields
                step = LoginStep(step_type='navigate', action_value=login_url)
                self._recorded_steps.append(step)
                start_seq.steps.extend(self._recorded_steps[len(start_seq.steps):])

                # Find username, password, submit
                for sel, name in [('input[name="username"]', 'username'),
                                  ('input[name="email"]', 'email'),
                                  ('input[type="email"]', 'email')]:
                    if self._driver.wait_for_selector(sel, 2000):
                        self._recorded_steps.append(LoginStep(
                            step_type='type', selector=sel, action_value='admin'))
                        break

                for sel in ['input[name="password"]', 'input[type="password"]']:
                    if self._driver.wait_for_selector(sel, 2000):
                        self._recorded_steps.append(LoginStep(
                            step_type='type', selector=sel, action_value='secret'))
                        break

                for sel in ['button[type="submit"]', 'input[type="submit"]']:
                    if self._driver.wait_for_selector(sel, 2000):
                        self._recorded_steps.append(LoginStep(
                            step_type='click', selector=sel))
                        break

                self._driver.wait_for_navigation()
                time.sleep(1)
                self._post_login_cookies = self._driver.get_cookies()
                return self.finalize()

        return start_seq

    def _record_steps_from_current(self) -> RecordedSequence:
        """Create a partial sequence from currently recorded steps."""
        return RecordedSequence(
            target_url=self.target_url, name='Recording in progress',
            steps=list(self._recorded_steps),
            initial_cookies=dict(self._initial_cookies),
            screenshot_dir=self._screenshot_dir,
        )

    # -- Finalization ------------------------------------------------------

    def finalize(self) -> RecordedSequence:
        """Finalize the recording into a replayable sequence."""
        if not self.target_url and self._recorded_steps:
            first_nav = next((s for s in self._recorded_steps if s.step_type == 'navigate'), None)
            if first_nav:
                self.target_url = first_nav.action_value

        seq = RecordedSequence(
            target_url=self.target_url or 'unknown',
            name=f'LSR Sequence #{self._current_step}',
            steps=list(self._recorded_steps),
            initial_cookies=dict(self._initial_cookies),
            post_login_cookies=dict(self._post_login_cookies),
            success_criteria=list(self._success_criteria),
            screenshot_dir=self._screenshot_dir,
        )

        # Auto-detect login URL from first navigate step
        for s in self._recorded_steps:
            if s.step_type == 'navigate' and not seq.login_url:
                seq.login_url = s.action_value or self.target_url

        # Auto-detect session token name from cookies
        for cookie_name in ['sessionid', 'sess', 'PHPSESSID', 'JSESSIONID', 'connect.sid', 'auth_token']:
            if any(c == cookie_name for c in self._post_login_cookies):
                seq.session_token_name = cookie_name
                break

        # Auto-detect success criteria from post-login page
        if self._post_login_cookies:
            seq.success_criteria.extend(['logged in', 'dashboard', 'profile'])

        logger.info('LSR finalized: %d steps, success_criteria=%d', len(seq.steps), len(seq.success_criteria))
        return seq

    # -- Replay phase ------------------------------------------------------

    def replay(self, credentials: Optional[Dict[str, str]] = None) -> Optional[requests.Session]:
        """Replay the recorded sequence using requests (session-based replay)."""
        session = self.replay_as_session()
        if credentials:
            for k, v in credentials.items():
                # Try to set cookie directly
                pass  # cookies already captured from recording
        return session

    def replay_as_session(self) -> Optional[requests.Session]:
        """Replay the sequence and return a requests.Session with valid cookies."""
        if not self._recorded_steps:
            logger.error('No steps to replay')
            return None

        session = make_guarded_session()
        cookies_set = set()

        # Replay each step
        for i, step in enumerate(self._recorded_steps):
            if step.step_type == 'navigate':
                url = step.action_value
                try:
                    resp = session.get(url, timeout=15, verify=False)
                    self._last_url = resp.url
                except requests.RequestException as exc:
                    logger.warning('Step %d navigate failed: %s', i, exc)

            elif step.step_type == 'click':
                # For replay without browser: skip (cookies already in session)
                pass

            elif step.step_type == 'type':
                # For replay: store form data for POST submission if we find a submit step
                pass

            elif step.step_type == 'verify':
                # Verify success criteria after navigation
                try:
                    resp = session.get(self._last_url, timeout=10, verify=False)
                    text = (resp.text + resp.url).lower()
                    if any(indicator in text for indicator in self.success_criteria):
                        logger.info('Step %d verified: success indicators found', i)
                except Exception:
                    pass

        # Capture cookies from session after replay
        self._post_login_cookies = {c.name: c.value for c in session.cookies}
        return session

    def close(self):
        """Clean up browser resources."""
        self._driver.close()


# ====================================================================
# Convenience functions
# ====================================================================

def record_login_sequence(target_url: str, output_dir: str = './lsr') -> Optional[RecordedSequence]:
    """Quick recorder: auto-discover login and attempt standard flow."""
    recorder = LoginSequenceRecorder(target_url=target_url, screenshot_dir=output_dir)
    try:
        return recorder.auto_discover_login()
    finally:
        recorder.close()


def replay_sequence_from_file(filepath: str) -> RecordedSequence:
    """Load and replay a recorded login sequence from file."""
    seq = RecordedSequence.load(filepath)
    session = seq.replay_as_session()
    logger.info('Replayed %d steps from %s, authenticated=%s', len(seq.steps), filepath, bool(session))
    return seq
