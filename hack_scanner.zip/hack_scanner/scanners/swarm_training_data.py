#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Training Data — 训练数据生成与轻量分类器
==================================================
from-source-of: Pentest-Swarm-AI

将 Pentest-Swarm-AI training/ 目录下所有 Python 脚本的核心逻辑
转换为纯 Python 函数式 API，不含外部依赖。

覆盖的训练数据源（来自 Pentest-Swarm-AI）：
  - generate_classifier_data.py → generate_classifier_samples()
  - generate_exploit_data.py    → generate_exploit_samples()
  - generate_recon_data.py      → generate_recon_samples()
  - generate_report_data.py     → generate_report_samples()

以及轻量级分类器训练（train_classifier.py 的纯 Python 等价实现）：
  - train_classifier_model(samples) → dict（基于朴素贝叶斯/决策树的无依赖实现）
"""

import json
import hashlib
import random
import math
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger('swarm_training')

# ===================================================================
# 数据生成：分类器训练样本（来自 generate_classifier_data.py）
# ===================================================================

# 原始 FINDING_TYPES — 与 Pentest-Swarm-AI 的源文件一致
_FINDING_TEMPLATES = [
    {
        'tool': 'nuclei',
        'finding_type': 'sqli',
        'target': 'https://example.com/search?q=test',
        'detail': 'SQL injection detected in search parameter via error-based technique',
    },
    {
        'tool': 'nuclei',
        'finding_type': 'xss',
        'target': 'https://example.com/comments',
        'detail': 'Reflected XSS in comment body parameter, unsanitized output',
    },
    {
        'tool': 'httpx',
        'finding_type': 'misconfig',
        'target': 'https://admin.example.com',
        'detail': 'Admin panel exposed without authentication, default credentials may work',
    },
    {
        'tool': 'nuclei',
        'finding_type': 'ssrf',
        'target': 'https://api.example.com/fetch?url=',
        'detail': 'SSRF via URL parameter, can reach internal network 169.254.169.254',
    },
    {
        'tool': 'gau',
        'finding_type': 'info_disclosure',
        'target': 'https://example.com/.git/config',
        'detail': 'Exposed .git repository with config containing AWS credentials',
    },
    {
        'tool': 'nuclei',
        'finding_type': 'rce',
        'target': 'https://example.com/upload',
        'detail': 'Unrestricted file upload allows PHP webshell execution',
    },
    {
        'tool': 'naabu',
        'finding_type': 'open_port',
        'target': '10.0.0.5:6379',
        'detail': 'Redis exposed on port 6379 without authentication',
    },
    {
        'tool': 'nuclei',
        'finding_type': 'auth_bypass',
        'target': 'https://api.example.com/admin',
        'detail': 'JWT signature not verified, can forge admin tokens',
    },
]

# 各类发现的 CVE/CVSS 映射（模拟知识）
_FINDING_KNOWLEDGE = {
    'sqli': {
        'cves': ['CVE-2024-1234', 'CVE-2023-5678'],
        'cvss_scores': [9.8, 8.6, 7.5],
        'attack_category': 'sqli',
    },
    'xss': {
        'cves': ['CVE-2024-4321'],
        'cvss_scores': [7.1, 6.3, 5.4],
        'attack_category': 'xss',
    },
    'misconfig': {
        'cves': [],
        'cvss_scores': [5.3, 4.0, 3.1],
        'attack_category': 'misconfig',
    },
    'ssrf': {
        'cves': ['CVE-2024-0001'],
        'cvss_scores': [8.6, 7.5, 6.8],
        'attack_category': 'ssrf',
    },
    'info_disclosure': {
        'cves': ['CVE-2023-9999'],
        'cvss_scores': [4.3, 3.7, 2.5],
        'attack_category': 'info_disclosure',
    },
    'rce': {
        'cves': ['CVE-2024-1111'],
        'cvss_scores': [9.8, 9.1, 8.8],
        'attack_category': 'rce',
    },
    'open_port': {
        'cves': [],
        'cvss_scores': [3.0, 2.5, 1.8],
        'attack_category': 'network_exposure',
    },
    'auth_bypass': {
        'cves': ['CVE-2024-2222'],
        'cvss_scores': [9.1, 8.6, 7.5],
        'attack_category': 'auth_bypass',
    },
}

# 随机目标池（用于多样性）
_RANDOM_TARGETS = [
    'https://example.com/search?q=test',
    'https://api.corp.net/graphql',
    'https://shop.store.io/products?id=1',
    'https://portal.bank.com/api/users/{id}',
    'https://cloud.startup.io/upload',
    'https://legacy.enterprise.org/admin/login',
    'http://intranet.local/api/v2/data',
    'https://demo.app.dev/comments?post=5',
]


def _classify_finding(templates: List[Dict]) -> Dict[str, Any]:
    """根据发现模板生成分类结果。

    将 Pentest-Swarm-AI training/generate_classifier_data.py 中的
    ClassifiedFinding 模式转换为纯 Python 等价实现。
    """
    sample_list = []

    for i, tmpl in enumerate(templates):
        tool = tmpl['tool']
        finding_type = tmpl['finding_type']
        target = tmpl.get('target', 'https://example.com')
        detail = tmpl.get('detail', '')

        # 使用知识映射填充 CVE/CVSS
        knowledge = _FINDING_KNOWLEDGE.get(finding_type, {
            'cves': [], 'cvss_scores': [3.0], 'attack_category': finding_type,
        })

        cvss_idx = i % len(knowledge['cvss_scores'])
        cve_list = knowledge['cves'][:2] if knowledge['cves'] else []

        sample = {
            'input': {
                'tool': tool,
                'finding_type': finding_type,
                'target': target,
                'detail': detail,
            },
            'output': {
                'title': f"{'SQLi' if finding_type == 'sqli' else ''}"
                          f"{'XSS' if finding_type == 'xss' else ''}"
                          f"{'SSRF' if finding_type == 'ssrf' else ''}"
                          f"{'RCE' if finding_type == 'rce' else ''}"
                          f"{'Auth Bypass' if finding_type == 'auth_bypass' else ''}"
                          f"{'Misconfiguration' if finding_type == 'misconfig' else ''}"
                          f"{'Info Disclosure' if finding_type == 'info_disclosure' else ''}"
                          f"{'Open Port' if finding_type == 'open_port' else ''}"
                          f"{finding_type.capitalize()[:20]}",
                'description': detail,
                'cve_ids': cve_list,
                'cvss_score': knowledge['cvss_scores'][cvss_idx],
                'severity': (
                    'critical' if knowledge['cvss_scores'][cvss_idx] >= 9.0 else
                    'high' if knowledge['cvss_scores'][cvss_idx] >= 7.0 else
                    'medium' if knowledge['cvss_scores'][cvss_idx] >= 4.0 else
                    'low' if knowledge['cvss_scores'][cvss_idx] >= 1.0 else
                    'informational'
                ),
                'attack_category': knowledge['attack_category'],
                'confidence': random.choice(['high', 'medium', 'low']),
            },
            'metadata': {
                'source_script': 'generate_classifier_data.py',
                'index': i,
                'generated_at': datetime.now().isoformat(),
            },
        }
        sample_list.append(sample)

    return sample_list


def generate_classifier_samples(num_samples: int = 100) -> List[Dict]:
    """生成分类器训练样本。

    对应 Pentest-Swarm-AI training/generate_classifier_data.py。
    目标：30,000 样本；默认返回 100 个用于快速验证。

    Returns:
        List[dict] — 每个 dict 包含 'input'（原始发现）和 'output'（分类结果）。
    """
    # 轮询模板以生成 num_samples 个样本
    templates = []
    for i in range(num_samples):
        tmpl = dict(_FINDING_TEMPLATES[i % len(_FINDING_TEMPLATES)])

        # 添加更大力度的随机扰动以模拟多样性（提高变异率）
        if random.random() < 0.6:  # 从 0.3 提升到 0.6
            tmpl['target'] = random.choice(_RANDOM_TARGETS)
        if random.random() < 0.4:  # 从 0.2 提升到 0.4
            tmpl['detail'] += f' [variant-{i % 5}]'
        # 额外扰动：随机改变工具（模拟不同扫描引擎产生相同发现）
        if random.random() < 0.3:
            alt_tools = ['nuclei', 'burpsuite', 'zap', 'arachni', 'skipfish']
            tmpl['tool'] = random.choice(alt_tools)

        templates.append(tmpl)

    samples = _classify_finding(templates)

    # 合成数据不需要去重 — 每个索引代表一次独立的扫描发现
    logger.info(f"  Classifier samples generated: {len(samples)}")
    return samples


# ===================================================================
# 数据生成：Exploit 训练样本（来自 generate_exploit_data.py）
# ===================================================================

_SCENARIO_TEMPLATES = [
    {
        'target': 'webapp.example.com',
        'objective': 'find all vulnerabilities',
        'findings': 'SQLi in /search, XSS in /comments, exposed .git repo',
    },
    {
        'target': 'api.corp.net',
        'objective': 'achieve RCE',
        'findings': 'SSRF via /fetch endpoint, Redis on 6379 unauthenticated, outdated Tomcat 9.0.30',
    },
    {
        'target': 'portal.bank.com',
        'objective': 'access customer data',
        'findings': 'IDOR on /api/users/{id}, weak JWT validation, misconfigured CORS',
    },
    {
        'target': 'cloud.startup.io',
        'objective': 'escalate privileges',
        'findings': 'AWS metadata accessible via SSRF, S3 bucket with write access, leaked IAM key in .env',
    },
    {
        'target': 'legacy.enterprise.org',
        'objective': 'full system compromise',
        'findings': 'Default admin credentials, path traversal in file upload, unpatched Apache Struts',
    },
]

# MITRE ATT&CK 技术映射（用于生成步骤中的 technique_id）
_MITRE_TECHNIQUES = {
    'sqli': 'T1190',
    'xss': 'T1059.007',
    'ssrf': 'T1068',
    'rce': 'T1059.004',
    'auth_bypass': 'T1078',
    'path_traversal': 'T1083',
    'file_upload': 'T1505.003',
    'credential_access': 'T1110',
    'privilege_escalation': 'T1068',
}


def _generate_exploit_sample(templates: List[Dict]) -> List[Dict]:
    """根据场景模板生成 exploit 训练样本。

    对应 Pentest-Swarm-AI training/generate_exploit_data.py 中的
    AttackPlan 模式 + 链式思考（chain-of-thought）推理输出。
    """
    samples = []

    for i, scenario in enumerate(templates):
        target = scenario['target']
        objective = scenario['objective']
        findings = scenario['findings']

        # 构建链式思考推理（与原文 PROMPT_TEMPLATE 一致）
        reasoning = (
            f"Analyzing target {target} for: {objective}\n"
            f"Available findings: {findings}\n\n"
            f"[{i % 3 + 1}] path chain analysis:\n"
            f"- Path A has the highest success probability based on finding severity.\n"
            f"- Step 1 should leverage the easiest entry point (lowest barrier to exploit).\n"
            f"- Cleanup commands are registered for all state-mutating operations."
        )

        # 生成攻击路径
        paths = [
            {
                'name': f"{findings.split(',')[0].strip()} -> Escalation",
                'description': f"Exploit chain starting from {findings.split(',')[0].strip()}",
                'steps': [
                    {
                        'name': 'Reconnaissance',
                        'technique_id': _MITRE_TECHNIQUES.get('auth_bypass', 'T1592'),
                        'command': f'nmap -sV -p 80,443,{random.choice([8080, 8443, 3000])} {target}',
                        'expected_output_pattern': r'open\s+(http|https|ssh|mysql)',
                        'cleanup_command': '',
                    },
                    {
                        'name': 'Exploitation',
                        'technique_id': _MITRE_TECHNIQUES.get('sqli', 'T1190'),
                        'command': f"sqlmap -u 'https://{target}/search?q=test' --batch --risk=2",
                        'expected_output_pattern': r"(?i)(sql|injection|parameter)",
                        'cleanup_command': '',
                    },
                    {
                        'name': 'Post-Exploitation',
                        'technique_id': _MITRE_TECHNIQUES.get('credential_access', 'T1110'),
                        'command': 'cat /etc/passwd; whoami',
                        'expected_output_pattern': r'[a-z_]+:[x*]:\d+:',
                        'cleanup_command': '',
                    },
                ],
                'estimated_success_probability': round(random.uniform(0.3, 0.95), 2),
                'expected_impact': random.choice(['high', 'critical', 'medium']),
            }
        ]

        sample = {
            'input': {
                'target': target,
                'objective': objective,
                'findings': findings,
            },
            'output': {
                'reasoning': reasoning,
                'paths': paths,
            },
            'metadata': {
                'source_script': 'generate_exploit_data.py',
                'has_think_trace': True,
                'index': i,
                'generated_at': datetime.now().isoformat(),
            },
        }
        samples.append(sample)

    return samples


def generate_exploit_samples(num_samples: int = 100) -> List[Dict]:
    """生成 exploit 训练样本。

    对应 Pentest-Swarm-AI training/generate_exploit_data.py。
    目标：40,000 样本；默认返回 100 个用于快速验证。

    Returns:
        List[dict] — 每个 dict 包含 'input'（场景）和 'output'（AttackPlan）。
    """
    templates = []
    for i in range(num_samples):
        scenario = dict(_SCENARIO_TEMPLATES[i % len(_SCENARIO_TEMPLATES)])

        # 轻微扰动以模拟多样性
        if random.random() < 0.3:
            extra_findings = random.choice([
                'exposed Redis on 6379',
                'leaked .env file with DB credentials',
                'default admin:admin credentials found',
                'directory listing enabled on /uploads',
            ])
            scenario['findings'] += f", {extra_findings}"

        templates.append(scenario)

    samples = _generate_exploit_sample(templates)

    # 验证思考痕迹存在率（与原文一致）
    with_think = sum(1 for s in samples if s['metadata'].get('has_think_trace'))
    logger.info(f"  Exploit samples generated: {len(samples)} ({with_think} with chain-of-thought traces)")

    return samples


# ===================================================================
# 数据生成：Recon 训练样本（来自 generate_recon_data.py）
# ===================================================================

_RECON_PROFILES = [
    {'target': 'example.com', 'subdomain_count': 5, 'ports': '80,443,8080', 'technologies': 'nginx, PHP, MySQL', 'os_type': 'Linux'},
    {'target': 'shop.example.com', 'subdomain_count': 3, 'ports': '80,443,3000', 'technologies': 'Next.js, Node.js, PostgreSQL', 'os_type': 'Linux'},
    {'target': 'api.startup.io', 'subdomain_count': 8, 'ports': '443,8443,9090', 'technologies': 'Go, gRPC, Redis, Kubernetes', 'os_type': 'Linux'},
    {'target': 'legacy.corp.net', 'subdomain_count': 12, 'ports': '80,443,8080,21,22,3389', 'technologies': 'IIS, ASP.NET, MSSQL', 'os_type': 'Windows'},
    {'target': 'cloud.saas.dev', 'subdomain_count': 20, 'ports': '443', 'technologies': 'React, Python, Django, AWS', 'os_type': 'Linux'},
]

# 模拟工具输出模板（nmap / subfinder / httpx 风格）
_TOOL_OUTPUT_TEMPLATES = {
    'nmap': """\
Starting Nmap {version} at {time}
Nmap scan report for {target}
Host is up ({latency}s latency).
Not shown: {closed} closed ports
PORT     STATE SERVICE     VERSION
{ports}
OS details: {os_details}
Nmap done: 1 IP address (1 host up) in {duration}s
""",
    'subfinder': """\
[INF] Current subfinder version=v2.6.6
[sub-fetched] api.{target}
[sub-fetched] admin.{target}
[sub-fetched] dev.{target}
[sub-fetched] staging.{target}
[sub-fetched] internal-{suffix}.{target}
[INF] Total distinct domains: {count}
""",
    'httpx': """\
https://{target}:443 [{status_code}] [{server}] [{duration}s]
http://{target}:80 [{redirect_status}] [Redirected to https]
""",
}


def _generate_recon_sample(templates: List[Dict]) -> List[Dict]:
    """根据目标配置文件生成 recon 训练样本。

    对应 Pentest-Swarm-AI training/generate_recon_data.py 中的
    AttackSurface 结构化输出模式。
    """
    samples = []

    for i, profile in enumerate(templates):
        target = profile['target']
        subdomain_count = profile['subdomain_count'] + (i % 10)
        ports_str = profile['ports']
        technologies = profile['technologies']
        os_type = profile['os_type']

        # 构建模拟工具输出
        port_lines = []
        for p in ports_str.split(','):
            p = p.strip()
            service_map = {
                '80': ('http', 'Apache httpd'),
                '443': ('https', 'nginx'),
                '22': ('ssh', 'OpenSSH'),
                '3306': ('mysql', 'MySQL'),
                '6379': ('redis', 'Redis'),
                '8080': ('http', 'Apache Tomcat'),
                '3000': ('http', 'Node.js dev server'),
                '8443': ('https', 'Node.js HTTPS'),
                '9090': ('http', 'gRPC health check'),
                '21': ('ftp', 'vsftpd'),
                '3389': ('tcp', 'Microsoft Terminal Service'),
            }
            svc, ver = service_map.get(p, (f'service-{p}', 'unknown'))
            port_lines.append(f'{p:<8} open  {svc:<15}{ver}')

        nmap_output = _TOOL_OUTPUT_TEMPLATES['nmap'].format(
            version='7.94', time=datetime.now().isoformat(), target=target,
            latency=round(random.uniform(0.01, 0.5), 3),
            closed=random.randint(990, 998),
            ports='\n'.join(port_lines),
            os_details=f'Linux {random.randint(4, 6)}.{random.randint(0, 20)}',
            duration=round(random.uniform(5, 30), 2),
        )

        # 构建 AttackSurface 结构化数据（对应原文 schema）
        subdomains = []
        for j in range(subdomain_count):
            domain = f"sub{j}.{target}" if j > 0 else target
            source = random.choice(['passive_dns', 'cert_transparency', 'brute_force', 'osint'])
            subdomains.append({
                'domain': domain,
                'ip': f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}",
                'source': source,
            })

        hosts = []
        for j in range(min(subdomain_count, 5)):
            hosts.append({
                'ip': subdomains[j]['ip'] if j < len(subdomains) else f'10.0.{j}.1',
                'hostnames': [subdomains[j]['domain']],
                'open_ports': [{'port': int(p), 'service': p.strip()} for p in ports_str.split(',')],
                'services': [f"{p.strip()}/tcp" for p in ports_str.split(',')],
            })

        endpoints = []
        tech_list = technologies.split(', ')
        technologies_dict = {}
        for tech in tech_list:
            versions = {
                'nginx': '1.24', 'PHP': '8.2', 'MySQL': '8.0',
                'Next.js': '14.0', 'Node.js': '20.x', 'PostgreSQL': '15.4',
                'Go': '1.21', 'gRPC': '1.59', 'Redis': '7.2', 'Kubernetes': '1.28',
                'IIS': '10.0', 'ASP.NET': '4.8', 'MSSQL': '2019',
                'React': '18.2', 'Python': '3.11', 'Django': '4.2', 'AWS': '-',
            }
            technologies_dict[tech.strip()] = versions.get(tech.strip(), 'unknown')

        tech_endpoints = [f"https://{target}/api/v1/{t.lower().replace(' ', '-')}" for t in tech_list[:3]]
        endpoints.extend([
            {'url': f'https://{target}', 'status_code': 200},
            {'url': f'https://admin.{target}', 'status_code': random.choice([401, 403, 500])},
            *tech_endpoints,
        ])

        recon_output = {
            'tool_output': nmap_output.strip(),
            'attack_surface': {
                'target': target,
                'subdomains': subdomains[:5],  # 限制前5个
                'hosts': hosts,
                'endpoints': endpoints,
                'technologies': technologies_dict,
            },
        }

        sample = {
            'input': {**profile, 'index': i},
            'output': recon_output,
            'metadata': {
                'source_script': 'generate_recon_data.py',
                'index': i,
                'generated_at': datetime.now().isoformat(),
            },
        }
        samples.append(sample)

    return samples


def generate_recon_samples(num_samples: int = 100) -> List[Dict]:
    """生成 recon 训练样本。

    对应 Pentest-Swarm-AI training/generate_recon_data.py。
    目标：50,000 样本；默认返回 100 个用于快速验证。

    Returns:
        List[dict] — 每个 dict 包含 'input'（目标配置）和 'output'（AttackSurface + 工具输出）。
    """
    templates = []
    for i in range(num_samples):
        profile = dict(_RECON_PROFILES[i % len(_RECON_PROFILES)])
        # 与原文完全一致：子域名数量随索引递增
        profile['subdomain_count'] = profile['subdomain_count'] + (i % 10)
        templates.append(profile)

    samples = _generate_recon_sample(templates)

    logger.info(f"  Recon samples generated: {len(samples)}")
    return samples


# ===================================================================
# 数据生成：Report 训练样本（来自 generate_report_data.py）
# ===================================================================

_REPORT_EXEC_SCENARIOS = [
    {'target': 'example.com', 'industry': 'E-commerce', 'finding_summary': '2 critical (SQLi, RCE), 3 high, 5 medium', 'risk_level': 'critical'},
    {'target': 'app.fintech.io', 'industry': 'Financial services', 'finding_summary': '1 critical (auth bypass), 2 high, 4 medium', 'risk_level': 'critical'},
    {'target': 'portal.health.org', 'industry': 'Healthcare', 'finding_summary': '0 critical, 2 high, 8 medium', 'risk_level': 'high'},
    {'target': 'api.saas.dev', 'industry': 'SaaS/Technology', 'finding_summary': '3 high (SSRF, IDOR, weak JWT), 6 medium', 'risk_level': 'high'},
]

_REPORT_FINDING_SCENARIOS = [
    {'title': 'SQL Injection in Search', 'severity': 'critical', 'cvss': '9.8', 'category': 'sqli', 'target': 'example.com/search', 'description': 'Error-based SQL injection'},
    {'title': 'Reflected XSS in Comments', 'severity': 'high', 'cvss': '7.1', 'category': 'xss', 'target': 'example.com/comments', 'description': 'Unsanitized user input'},
    {'title': 'SSRF via URL Parameter', 'severity': 'high', 'cvss': '8.6', 'category': 'ssrf', 'target': 'api.example.com/fetch', 'description': 'Server-side request forgery'},
    {'title': 'Exposed Admin Panel', 'severity': 'medium', 'cvss': '5.3', 'category': 'misconfig', 'target': 'admin.example.com', 'description': 'No authentication required'},
]


def generate_report_samples(num_samples: int = 100) -> List[Dict]:
    """生成报告训练样本。

    对应 Pentest-Swarm-AI training/generate_report_data.py。
    生成三类样本：executive_summary / finding_writeup / remediation_plan。

    Returns:
        List[dict] — 混合三类报告章节样本。
    """
    samples = []
    per_type = num_samples // 3

    # --- Executive Summary 类 ---
    for i in range(per_type):
        scenario = _REPORT_EXEC_SCENARIOS[i % len(_REPORT_EXEC_SCENARIOS)]
        sample = {
            'input': {**scenario, 'index': i},
            'output': {
                'section_type': 'executive_summary',
                'content': (
                    f"This penetration test of {scenario['target']} ("
                    f"{scenario['industry']}) identified a total of "
                    f"{scenario['finding_summary']}. The overall risk level is "
                    f"assessed as '{scenario['risk_level']}' with significant "
                    f"implications for business continuity, regulatory compliance, "
                    f"and customer data protection."
                ),
            },
            'metadata': {
                'source_script': 'generate_report_data.py',
                'sample_type': 'executive_summary',
                'index': i,
                'generated_at': datetime.now().isoformat(),
            },
        }
        samples.append(sample)

    # --- Finding Writeup 类 ---
    for i in range(per_type):
        scenario = _REPORT_FINDING_SCENARIOS[i % len(_REPORT_FINDING_SCENARIOS)]
        sample = {
            'input': {**scenario, 'index': i},
            'output': {
                'section_type': 'finding_writeup',
                'content': (
                    f"**{scenario['title']}**\n"
                    f"- Severity: {scenario['severity']} (CVSS {scenario['cvss']})\n"
                    f"- Category: {scenario['category']}\n\n"
                    f"This vulnerability was discovered in {scenario['target']}. "
                    f"{scenario['description'].capitalize()}. "
                    f"The finding represents a {scenario['severity']} severity issue "
                    f"with direct business impact including data exfiltration and "
                    f"unauthorized access. Remediation should be prioritized based on "
                    f" Remediation priority: {'immediate' if float(scenario['cvss']) > 7 else 'within 30 days'}."
                ),
            },
            'metadata': {
                'source_script': 'generate_report_data.py',
                'sample_type': 'finding_writeup',
                'index': i,
                'generated_at': datetime.now().isoformat(),
            },
        }
        samples.append(sample)

    # --- Remediation Plan 类 ---
    for i in range(per_type):
        top_findings = _REPORT_FINDING_SCENARIOS[:3]
        sample = {
            'input': {
                'findings_list': '; '.join(
                    f"{s['title']} ({s['severity']}, CVSS {s['cvss']})" for s in top_findings
                ),
                'index': i,
            },
            'output': {
                'section_type': 'remediation',
                'content': (
                    f"**Prioritized Remediation Plan**\n\n"
                    f"| Priority | Finding | Severity | Recommended Fix |\n"
                    f"|----------|---------|----------|----------------|\n"
                    + '\n'.join(
                        (
                            f"| {j+1} | {s['title']} | {s['severity']} | "
                            f"{'Implement parameterized queries and input validation.' if s['category'] == 'sqli' else ''}"
                            f"{'Add output encoding and CSP headers.' if s['category'] == 'xss' else ''}"
                            f"{'Validate and restrict URLs passed to server-side requests.' if s['category'] == 'ssrf' else ''}"
                            f"{'Require authentication for all admin endpoints.' if s['category'] == 'misconfig' else ''}"
                        ) + '\n'
                        for j, s in enumerate(top_findings)
                    ),
                ),
            },
            'metadata': {
                'source_script': 'generate_report_data.py',
                'sample_type': 'remediation_plan',
                'index': i,
                'generated_at': datetime.now().isoformat(),
            },
        }
        samples.append(sample)

    logger.info(f"  Report samples generated: {len(samples)} (exec={per_type}, writeup={per_type}, remediation={per_type})")
    return samples


# ===================================================================
# 轻量级分类器训练（纯 Python，不依赖 PyTorch/transformers）
# ===================================================================


class NaiveBayesClassifier:
    """轻量级朴素贝叶斯文本分类器。

    对应 Pentest-Swarm-AI training/train_classifier.py 的核心目标：
    CVE 准确率 >85%，CVSS MAE <0.5，FP召回率 >90%。

    这里使用纯 Python 实现多项式朴素贝叶斯（Multinomial Naive Bayes），
    作为大型 LLM 微调的轻量级替代方案。
    """

    def __init__(self, smoothing: float = 1.0):
        self.smoothing = smoothing
        self.classes_: List[str] = []
        self.class_priors_: Dict[str, float] = {}
        self.feature_log_probs_: Dict[str, List[float]] = {}  # class -> {word -> log_prob}

    def _tokenize(self, text: str) -> List[str]:
        """简单分词：小写 + 按非字母数字分割。"""
        return [w.lower() for w in text.lower().replace('-', ' ').replace('/', ' ') if len(w) > 0]

    def fit(self, samples: List[Dict]) -> 'NaiveBayesClassifier':
        """从训练样本拟合分类器。

        Args:
            samples: 包含 'input' 和 'output' 键的字典列表，output 中必须有 severity 字段。

        Returns:
            self（支持链式调用）。
        """
        # 收集所有 severity 类别
        all_labels = set()
        for s in samples:
            sev = str(s.get('output', {}).get('severity', 'unknown'))
            all_labels.add(sev)
        self.classes_ = sorted(all_labels)

        # 按类别分组的特征文档列表
        class_docs: Dict[str, List[List[str]]] = {c: [] for c in self.classes_}

        for s in samples:
            sev = str(s.get('output', {}).get('severity', 'unknown'))
            # 输入字段拼接为文本
            inp = s.get('input', {})
            text = ' '.join([
                str(inp.get('finding_type', '')),
                str(inp.get('tool', '')),
                str(inp.get('detail', '')),
                str(inp.get('target', '')),
            ])
            tokens = self._tokenize(text)
            class_docs[sev].append(tokens)

        n_samples = len(samples)

        for cls in self.classes_:
            # 计算先验概率 P(class)
            class_count = sum(1 for s in samples if str(s.get('output', {}).get('severity', '')) == cls)
            self.class_priors_[cls] = class_count / n_samples

            # 合并该类别的所有词并计算词汇表
            all_tokens: Dict[str, int] = {}
            total_features = 0
            for tokens in class_docs[cls]:
                for t in tokens:
                    all_tokens[t] = all_tokens.get(t, 0) + 1
                    total_features += 1

            # 计算带拉普拉斯平滑的日志似然 log P(feature|class)
            vocab_words = set(all_tokens.keys())
            self.feature_log_probs_[cls] = []
            for w in vocab_words:
                count = all_tokens.get(w, 0) + self.smoothing
                prob = count / (total_features + len(vocab_words) * self.smoothing)
                self.feature_log_probs_[cls].append((w, math.log(prob)))

        return self

    def predict(self, text: str) -> Tuple[str, Dict[str, float]]:
        """预测文本的类别及其置信度。

        Args:
            text: 输入文本（描述原始发现）。

        Returns:
            (predicted_class, confidence_dict) — confidence_dict 包含所有类别的对数概率。
        """
        tokens = self._tokenize(text)
        token_set = set(tokens)

        log_posteriors = {}
        for cls in self.classes_:
            log_prob = math.log(self.class_priors_.get(cls, 1e-10))
            if cls in self.feature_log_probs_:
                for w, lp in self.feature_log_probs_[cls]:
                    if w in token_set:
                        log_prob += lp
            log_posteriors[cls] = log_prob

        best_class = max(log_posteriors, key=log_posteriors.get)
        return best_class, log_posteriors

    def evaluate(self, test_samples: List[Dict]) -> Dict[str, float]:
        """在测试集上评估分类器。

        Args:
            test_samples: 包含 'output.severity' 键的样本列表。

        Returns:
            {'accuracy': float, 'per_class_f1': dict}
        """
        correct = 0
        per_class_tp = {c: 0 for c in self.classes_}
        per_class_fp = {c: 0 for c in self.classes_}
        per_class_fn = {c: 0 for c in self.classes_}

        for s in test_samples:
            true_sev = str(s.get('output', {}).get('severity', 'unknown'))
            inp = s.get('input', {})
            text = ' '.join([str(inp.get('finding_type', '')), str(inp.get('detail', ''))])
            pred, _ = self.predict(text)

            if pred == true_sev:
                correct += 1
                per_class_tp[true_sev] += 1
            else:
                per_class_fp[pred] += 1
                per_class_fn[true_sev] += 1

        accuracy = correct / len(test_samples) if test_samples else 0.0

        f1_scores = {}
        for c in self.classes_:
            tp = per_class_tp.get(c, 0)
            fp = per_class_fp.get(c, 0)
            fn = per_class_fn.get(c, 0)
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
            f1_scores[c] = round(f1, 3)

        return {
            'accuracy': round(accuracy, 4),
            'total_tested': len(test_samples),
            'correct': correct,
            'per_class_f1': f1_scores,
        }


def train_classifier_model(samples: Optional[List[Dict]] = None) -> Dict[str, Any]:
    """训练轻量分类器并返回评估结果。

    对应 Pentest-Swarm-AI training/train_classifier.py。
    这里使用朴素贝叶斯作为纯 Python 实现，替代 Unsloth+QLoRA 的 LLM 微调。

    Args:
        samples: 训练样本列表；若为 None 则自动生成 100 个分类器样本。

    Returns:
        {
            'model': NaiveBayesClassifier,
            'accuracy': float,
            'per_class_f1': dict,
            'classes': list,
            'class_priors': dict,
            'total_samples': int,
        }
    """
    if samples is None:
        logger.info("  No samples provided; generating 200 classifier samples for training...")
        samples = generate_classifier_samples(200)

    # 划分训练集（80%）和测试集（20%）
    split_idx = int(len(samples) * 0.8)
    train_set = samples[:split_idx]
    test_set = samples[split_idx:]

    if not test_set:
        test_set = samples[-20:]
        train_set = samples[:-20]

    logger.info(f"  Training with {len(train_set)} samples, testing with {len(test_set)} samples...")

    # 拟合并评估
    model = NaiveBayesClassifier(smoothing=1.0)
    model.fit(train_set)
    eval_results = model.evaluate(test_set)

    return {
        'model': model,
        'accuracy': eval_results['accuracy'],
        'per_class_f1': eval_results['per_class_f1'],
        'classes': model.classes_,
        'class_priors': dict(model.class_priors_),
        'total_samples': len(samples),
    }


def classify_severity(text: str, classifier_model: Optional[NaiveBayesClassifier] = None) -> Tuple[str, float]:
    """快捷函数：使用训练好的分类器对一段文本进行分类。

    Args:
        text: 原始发现的描述文本。
        classifier_model: 通过 train_classifier_model() 返回的 'model' 字段。

    Returns:
        (severity_str, confidence) — 置信度为最高类的对数概率归一化值。
    """
    if classifier_model is None:
        result = train_classifier_model()
        classifier_model = result['model']

    sev, log_posteriors = classifier_model.predict(text)

    # 转换为 softmax 风格的置信度
    max_lp = max(log_posteriors.values())
    exp_sum = sum(math.exp(lp - max_lp) for lp in log_posteriors.values())
    confidence = math.exp(log_posteriors[sev] - max_lp) / exp_sum if exp_sum > 0 else 0.0

    return sev, round(confidence, 4)


# ===================================================================
# 便捷函数汇总
# ===================================================================


def generate_all_samples(num_per_type: int = 100) -> Dict[str, List[Dict]]:
    """一次性生成所有类型的训练样本。

    Args:
        num_per_type: 每种类型的样本数。

    Returns:
        {'classifier': ..., 'exploit': ..., 'recon': ..., 'report': ...}
    """
    return {
        'classifier': generate_classifier_samples(num_per_type),
        'exploit': generate_exploit_samples(num_per_type),
        'recon': generate_recon_samples(num_per_type),
        'report': generate_report_samples(num_per_type),
    }


def save_samples_to_jsonl(samples: List[Dict], filepath: str) -> int:
    """将样本列表保存为 JSONL 格式文件。

    Args:
        samples: 样本列表。
        filepath: 输出文件路径。

    Returns:
        写入的样本数。
    """
    count = 0
    with open(filepath, 'w', encoding='utf-8') as f:
        for s in samples:
            # 序列化时跳过不可序列化对象（如 dataclass）
            line = json.dumps(s, ensure_ascii=False, default=str)
            f.write(line + '\n')
            count += 1
    logger.info(f"  Saved {count} samples to {filepath}")
    return count


def load_samples_from_jsonl(filepath: str) -> List[Dict]:
    """从 JSONL 文件加载样本。"""
    samples = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                samples.append(json.loads(line))
    logger.info(f"  Loaded {len(samples)} samples from {filepath}")
    return samples


# ===================================================================
# CLI 入口
# ===================================================================


def _main():
    import argparse

    parser = argparse.ArgumentParser(description='Swarm Training Data CLI')
    parser.add_argument('command', choices=['generate', 'train', 'evaluate'], help='子命令')
    parser.add_argument('--type', '-t', choices=['classifier', 'exploit', 'recon', 'report', 'all'],
                        default='classifier', help='数据类型')
    parser.add_argument('--num-samples', '-n', type=int, default=100, help='样本数量')
    parser.add_argument('--output', '-o', help='输出 JSONL 文件路径')

    args = parser.parse_args()

    if args.command == 'generate':
        gen_fn = {
            'classifier': generate_classifier_samples,
            'exploit': generate_exploit_samples,
            'recon': generate_recon_samples,
            'report': generate_report_samples,
        }

        if args.type == 'all':
            all_samples = generate_all_samples(args.num_samples)
            for k, v in all_samples.items():
                print(f"  {k}: {len(v)} samples")
        else:
            samples = gen_fn[args.type](args.num_samples)
            print(f"  Generated {len(samples)} {args.type} samples")

        if args.output:
            save_samples_to_jsonl(samples, args.output)
            print(f"  Saved to {args.output}")

    elif args.command == 'train':
        result = train_classifier_model()
        print(f"\n  Classifier Training Results:")
        print(f"    Accuracy:  {result['accuracy']:.4f}")
        print(f"    Classes:   {result['classes']}")
        print(f"    Prioris:   {result['class_priors']}")
        print(f"    Per-class F1: {json.dumps(result['per_class_f1'], indent=6)}")

    elif args.command == 'evaluate':
        if not args.output:
            print("错误：evaluate 模式需要 --output", file=sys.stderr)
            sys.exit(1)
        samples = load_samples_from_jsonl(args.output)
        result = train_classifier_model(samples)
        print(f"\n  Evaluation Results:")
        print(f"    Accuracy: {result['accuracy']:.4f} ({result['correct']}/{result['total_samples']})")


if __name__ == '__main__':
    _main()
