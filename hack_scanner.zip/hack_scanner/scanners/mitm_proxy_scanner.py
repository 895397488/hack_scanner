#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MITM HTTPS Interception Scanner Module.

Provides an in-browser MITM proxy that intercepts and analyzes HTTP/HTTPS
traffic between a client and target web application, inspired by Acunetix's
acxproxy.exe certificate generation approach.

======= MITM FLOW =======
    1. CertFactory generates (or loads) a CA certificate on disk.
    2. MitmProxyServer starts an HTTP/HTTPS proxy on listen_port in a
       background thread (_ThreadedHTTPServer with ThreadingMixIn).
    3. For each incoming TLS connection the proxy uses SSLWrap to present a
       per-host fake certificate signed by our CA (CertFactory.issue).
    4. TrafficInterceptor captures every HTTP request and response, extracts
       cookies, and scans HTML/JS bodies for XHR / Fetch API endpoint hints.
    5. SessionAnalyzer inspects captured Set-Cookie headers for missing
       security attributes (Secure, HttpOnly, SameSite), duplicate cookies,
       and session tokens in URLs.
    6. find_all() reports findings in the same VulnFinding-compatible dict
       format used by all other scanners: [{id, severity, title, description, evidence, ...}]

Conservative by default: never active unless explicitly enabled via the
config.json ``mitm_proxy.enabled`` flag. All behaviour is driven from that
section of config.json.
"""

from __future__ import annotations

import base64
import copy
import datetime
import hashlib
import json
import logging
import os
import pathlib
import re
import shutil
import ssl
import subprocess
import sys
import threading
import time
import uuid
from collections import defaultdict, namedtuple
from dataclasses import dataclass, field
from enum import Enum, auto
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from typing import Any, Dict, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


class FindingSeverity(str, Enum):
    """Vulnerability severity levels.  Inherits from str so enum values
    serialize naturally to JSON."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass(order=False)
class VulnFinding:
    """A single vulnerability finding in VulnFinding-compatible format.

    The dict output matches the keys used by other scanners (jwt_detector,
    nuclei_scanner, waf_detector, ...) so that results can be merged and
    sorted uniformly.
    """

    id: str = ""
    title: str = ""
    severity: str = ""
    category: str = ""
    description: str = ""
    affected_url: str = ""
    evidence: str = ""
    remediation: str = ""
    cwe_id: str = ""
    cvss_score: float = 0.0
    timestamp: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a plain dict suitable for JSON output."""
        ts = self.timestamp or datetime.datetime.utcnow().isoformat() + "Z"
        return {
            "id": self.id,
            "title": self.title,
            "severity": self.severity,
            "category": self.category,
            "description": self.description,
            "affected_url": self.affected_url or self.evidence,
            "evidence": self.evidence or self.affected_url,
            "remediation": self.remediation,
            "cwe_id": self.cwe_id,
            "cvss_score": self.cvss_score,
            "timestamp": ts,
        }

    def __post_init__(self) -> None:
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        if not self.timestamp:
            self.timestamp = datetime.datetime.utcnow().isoformat() + "Z"


@dataclass
class CapturedRequest:
    """A single intercepted HTTP request."""

    method: str = ""
    path: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    body: str = ""
    scheme: str = "http"
    host: str = ""
    port: int = 0
    timestamp: str = ""

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.datetime.utcnow().isoformat() + "Z"


@dataclass
class CapturedResponse:
    """A single intercepted HTTP response."""

    status_code: int = 0
    headers: Dict[str, str] = field(default_factory=dict)
    body: str = ""
    request: Optional[CapturedRequest] = None
    timestamp: str = ""

    def __post_init__(self) -> None:
        if not self.timestamp:
            self.timestamp = datetime.datetime.utcnow().isoformat() + "Z"


@dataclass
class SessionData:
    """Collected session / cookie state for analysis.

    In addition to raw cookie name/value pairs the data class tracks per-cookie
    security attributes (Secure, HttpOnly, SameSite, Domain) parsed from the
    *Set-Cookie* response headers that TrafficInterceptor records during scan.
    """

    cookies: List[Dict[str, str]] = field(default_factory=list)
    auth_tokens: List[str] = field(default_factory=list)
    urls_seen: Set[str] = field(default_factory=set)
    xhr_endpoints: Set[str] = field(default_factory=set)
    # _secure_flags  --  {cookie_name: {"secure": bool, "httponly": bool, ...}}
    _secure_flags: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    # _domain_flags  --  {cookie_name: domain_value_or_None}
    _domain_flags: Dict[str, Optional[str]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# XHR / Fetch API endpoint discovery patterns
# ---------------------------------------------------------------------------

_XHR_PATTERNS = [
    r'fetch\s*\(\s*["\']([^"\'>]+)["\']',
    r'XMLHttpRequest\.open\s*\(\s*["\']\w+["\']\s*,\s*["\']([^"\'>]+)["\']',
    r'\.get\s*\(\s*["\']([^"\'>]+)["\']',
    r'\.post\s*\(\s*[^)]*\)\'\s*,\s*["\']([^"\'>]+)',
    r'url:\s*["\']([^"\'>\}]+)["\']',
    r'action\s*[:=]\s*["\']([^"\'>]+)["\']',
    r'ajax\s*\(\s*[^}]*url\s*[:=]\s*["\']([^"\'>]+)',
    r'/api/\w+',
    r'\b[A-Z]+\b\s*[=:]\s*["\'][^"\']*\/(api|graphql)[^\']*["\']',
    r'GraphQL\.query\s*\(\s*["\']([^"\'>]+)["\']',
    r'gql\.request\s*\(\s*["\']([^"\'>]+)["\']',
    r'/graphql',
]


# ---------------------------------------------------------------------------
# CertFactory -- on-the-fly fake CA + server certificate generation
# ---------------------------------------------------------------------------

class CertFactory:
    """Generate fake SSL certificates on-the-fly using the ``openssl`` CLI.

    Inspired by Acunetix's certgen approach: a root CA is generated once and
    reused; per-host certificates are signed by that CA at runtime so browsers
    will trust the interception proxy (after the CA certificate is manually
    installed in the trust store).

    Usage::

        factory = CertFactory(ca_dir="/tmp/mitm_ca")
        ca_cert_path = factory.ensure_ca()          # generates or loads CA
        cert_pem, key_pem = factory.issue("target.local")  # per-host cert

    The ``openssl`` command-line tool must be installed and on PATH.
    Call :meth:`load_openssl` before use to verify the dependency.
    """

    def __init__(self, ca_dir: Optional[str] = None) -> None:
        """Initialize the certificate factory.

        Args:
            ca_dir: Directory to store CA key + certificate.  Defaults to a
                hidden ``.mitm_ca`` directory next to this module file.
        """
        if ca_dir is None:
            _fallback = pathlib.Path(__file__).resolve().parent / ".mitm_ca"
            ca_dir = str(_fallback)
        self.ca_dir = pathlib.Path(ca_dir)
        self.ca_key = self.ca_dir / "ca.key"
        self.ca_cert = self.ca_dir / "ca.pem"
        self._lock = threading.Lock()

    # -- Public API --------------------------------------------------------

    def ensure_ca(self, days: int = 3650) -> str:
        """Create or return the path to the CA certificate PEM file.

        If an existing trusted CA is found it is reused; otherwise a new
        self-signed CA key + certificate are generated via ``openssl``.

        Args:
            days: Certificate validity period.  Default 10 years.

        Returns:
            Absolute path to the generated / cached CA PEM file.
        """
        with self._lock:
            if self.ca_cert.exists() and self.ca_key.exists():
                logger.debug("Reusing existing CA cert: %s", self.ca_cert)
                return str(self.ca_cert)

            self.ca_dir.mkdir(parents=True, exist_ok=True)

            # 1. Generate CA private key (RSA 2048)
            subprocess.check_call(
                ["openssl", "genrsa", "-out", str(self.ca_key), "2048"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            # 2. Generate self-signed CA certificate
            subprocess.check_call(
                [
                    "openssl", "req", "-new", "-x509", "-days", str(days),
                    "-key", str(self.ca_key),
                    "-out", str(self.ca_cert),
                    "-subj", "/C=US/ST=Fake/L=Intercept/O=MITMScanner CA/CN=MITM Scanner Root CA",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

        logger.info("Generated new CA cert: %s", self.ca_cert)
        return str(self.ca_cert)

    def issue(
        self,
        common_name: str,
        sans: Optional[List[str]] = None,
        days: int = 365,
    ) -> Tuple[str, str]:
        """Issue a per-host server certificate signed by the CA.

        Args:
            common_name: The CN (hostname) for the certificate.
            sans: Subject Alternative Names list
                  (e.g. ``["DNS:www.example.com", "DNS:example.com"]``).
            days: Certificate validity period.

        Returns:
            ``(cert_pem_str, key_pem_str)`` -- both plain strings ready to be
            loaded into an ``ssl.SSLContext`` at runtime (in-memory).
        """
        if not self.ca_cert.exists() or not self.ca_key.exists():
            raise RuntimeError("CA cert/key missing; call ensure_ca() first")

        san_section = ""
        for san in sans or []:
            san_section += f"{san},\n" if san_section else f"{san}\n"

        # Write temporary OpenSSL config ---------------------------------------------------
        cfg_path = self.ca_dir / f"cert_cfg_{uuid.uuid4().hex}.cnf"
        cfg_path.write_text(
            "[req]\ndefault_bits = 2048\nprompt = no\n"
            "distinguished_name = dn\nreq_extensions = v3_req\n"
            "[dn]\nCN = {cn}\n"
            "[v3_req]\nsubjectAltName = @alt_names\n"
            "[alt_names]\n{san}"
        ).format(cn=common_name, san=san_section)

        key_pem_path = self.ca_dir / f"{uuid.uuid4().hex}.key"

        # Outside lock to avoid blocking other threads during slow I/O ----------
        subprocess.check_call(
            ["openssl", "genrsa", "-out", str(key_pem_path), "2048"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        csr_path = self.ca_dir / f"{uuid.uuid4().hex}.csr"
        subprocess.check_call(
            [
                "openssl", "req", "-new", "-key", str(key_pem_path),
                "-out", str(csr_path),
                "-config", str(cfg_path),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        cert_pem_path = self.ca_dir / f"{uuid.uuid4().hex}.pem"
        subprocess.check_call(
            [
                "openssl", "x509", "-req", "-days", str(days),
                "-in", str(csr_path),
                "-CA", str(self.ca_cert),
                "-CAkey", str(self.ca_key),
                "-CAcreateserial",
                "-out", str(cert_pem_path),
                "-extfile", str(cfg_path),
                "-extensions", "v3_req",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        # Clean up helpers ------------------------------------------------------------------
        for p in (csr_path, cfg_path):
            try:
                p.unlink()
            except OSError:
                pass

        cert_pem = cert_pem_path.read_text()
        key_pem = key_pem_path.read_text()
        return cert_pem, key_pem

    @staticmethod
    def _load_openssl() -> str:
        """Verify that the ``openssl`` CLI is installed and on PATH.

        Returns:
            The resolved path to the ``openssl`` executable.

        Raises:
            RuntimeError: If ``openssl`` cannot be found.
        """
        # Windows prefers `where`, Unix relies on shutil.which
        if os.name == "nt":
            try:
                result = subprocess.run(
                    ["where", "openssl"], capture_output=True, text=True, timeout=5,
                )
                if result.returncode == 0 and result.stdout.strip():
                    return result.stdout.strip().split("\n")[0]
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass
        path = shutil.which("openssl")
        if path is None:
            raise RuntimeError(
                "openssl CLI not found on PATH; install openssl to use CertFactory"
            )
        return path


# ---------------------------------------------------------------------------
# SSLWrap -- wraps a socket in SSL with a per-host certificate
# ---------------------------------------------------------------------------

class _SSLWrap:
    """Context manager that wraps a TCP ``socket.socket`` in an SSL
    ``ssl.SSLSocket`` and tears it down cleanly.

    On the server side *server_side=True* is used; the caller (the HTTP
    handler thread) reads / writes on the returned SSLSocket exactly as if
    it were a plain ``socket``.

    Usage::

        with _SSLWrap(sock, ctx, cert_pem, key_pem) as ssl_sock:
            data = ssl_sock.recv(4096)
    """

    def __init__(
        self,
        sock: Any,
        ssl_context: ssl.SSLContext,
        cert_pem: str,
        key_pem: str,
    ) -> None:
        self._sock = sock
        self._sslsocket: Optional[ssl.SSLSocket] = None

        # Create an in-memory SSL context loaded with the per-host cert.
        # We write to temp files because load_cert_chain accepts only file
        # paths (not direct bytes in all Python versions).
        try:
            import io

            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            _tmp = pathlib.Path(__file__).parent / ".mitm_ca"
            _tmp.mkdir(parents=True, exist_ok=True)
            pem_path = _tmp / f"{uuid.uuid4().hex}.pem"
            key_path = _tmp / f"{uuid.uuid4().hex}.key"
            pem_path.write_text(cert_pem)
            key_path.write_text(key_pem)
            ctx.load_cert_chain(certfile=str(pem_path), keyfile=str(key_path))
            pem_path.unlink(missing_ok=True)
            key_path.unlink(missing_ok=True)
        except Exception:
            # Fallback: use the CA cert if per-host cert load fails.
            ca_dir = pathlib.Path(__file__).parent / ".mitm_ca"
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(
                certfile=str(ca_dir / "ca.pem"), keyfile=str(ca_dir / "ca.key")
            )

        self._sslsocket = ctx.wrap_socket(sock, server_side=True)

    def __enter__(self) -> ssl.SSLSocket:
        return self._sslsocket

    def __exit__(self, *exc: Any) -> None:
        if self._sslsocket is not None:
            try:
                self._sslsocket.shutdown(ssl.SHUT_RDWR)
            except Exception:
                pass
            try:
                self._sslsocket.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# TrafficInterceptor -- captures and records all intercepted traffic
# ---------------------------------------------------------------------------

class TrafficInterceptor:
    """Captures / records every HTTP request and response passing through the
    MITM proxy.  Also auto-discovers XHR / Fetch endpoints from JavaScript
    sources by scanning captured HTML/JS bodies for common AJAX patterns.

    Thread-safe: all internal state is protected by a ``threading.Lock``.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._requests: List[CapturedRequest] = []
        self._responses: List[CapturedResponse] = []
        self._session = SessionData()

        # Precompile regex patterns -------------------------------------------------
        self._xhr_re = [re.compile(p) for p in _XHR_PATTERNS]

    # -- Public API ---------------------------------------------------------

    def capture_request(self, req: CapturedRequest) -> None:
        """Record an intercepted HTTP request (thread-safe).

        Also extracts cookie names/values from the Cookie header so that
        :class:`SessionAnalyzer` can later inspect them.

        Args:
            req: The captured request object.
        """
        with self._lock:
            self._requests.append(req)
            cookie_header = req.headers.get("cookie", "") or ""
            for part in cookie_header.split(";"):
                part = part.strip()
                if "=" in part:
                    name, value = part.split("=", 1)
                    self._session.cookies.append({
                        "name": name.strip(),
                        "value": value.strip(),
                        "source": "request",
                    })

    def capture_response(self, resp: CapturedResponse) -> None:
        """Record an intercepted response and scan for XHR hints.

        Also parses ``Set-Cookie`` headers to populate per-cookie security
        attributes on :attr:`SessionData._secure_flags` so that
        :class:`SessionAnalyzer` can inspect them later.

        Args:
            resp: The captured response object.
        """
        with self._lock:
            self._responses.append(resp)
            if resp.request:
                url = (
                    f"{resp.request.scheme}://{resp.request.host}"
                    f":{resp.request.port}{resp.request.path}"
                )
                self._session.urls_seen.add(url)

        # Parse Set-Cookie headers into _secure_flags / _domain_flags -------------
        self._parse_set_cookie(resp)

        # Scan body for XHR / Fetch endpoint hints -------------------------------
        if resp.body and resp.headers:
            self._discover_xhr(resp)

    def _parse_set_cookie(self, resp: CapturedResponse) -> None:
        """Parse Set-Cookie headers from a response into session data.

        Each cookie name is normalised to lower-case; duplicate names on the
        same header line are handled by taking the last occurrence (as browsers do).

        Args:
            resp: The captured response whose headers contain Set-Cookie lines.
        """
        set_cookie = resp.headers.get("set-cookie") or ""
        if not set_cookie:
            return

        for part in set_cookie.split(","):
            cookie_name = ""
            secure = False
            httponly = False
            samesite: Optional[str] = None
            domain: Optional[str] = None

            for token in part.strip().split(";"):
                token = token.strip()
                if not token:
                    continue
                if "=" in token:
                    cname, cvalue = token.split("=", 1)
                    if not cookie_name:
                        cookie_name = cname.strip().lower()
                else:
                    flag = token.lower()
                    if flag == "secure":
                        secure = True
                    elif flag == "httponly":
                        httponly = True
                    elif flag.startswith("samesite="):
                        samesite = flag.split("=", 1)[1].strip().lower()
                    elif flag.startswith("domain="):
                        domain = flag.split("=", 1)[1].strip().lower()

            if cookie_name:
                with self._lock:
                    if cookie_name not in self._session._secure_flags:
                        self._session._secure_flags[cookie_name] = {}
                    self._session._secure_flags[cookie_name]["secure"] = secure
                    self._session._secure_flags[cookie_name]["httponly"] = httponly
                    self._session._secure_flags[cookie_name]["samesite"] = samesite
                    if domain:
                        self._session._domain_flags[cookie_name] = domain

    def get_requests(self) -> List[CapturedRequest]:
        """Return a deep copy of all captured requests."""
        with self._lock:
            return list(self._requests)

    def get_responses(self) -> List[CapturedResponse]:
        """Return a deep copy of all captured responses."""
        with self._lock:
            return list(self._responses)

    def get_session(self) -> SessionData:
        """Return a deep copy of the accumulated session data."""
        with self._lock:
            return copy.deepcopy(self._session)

    def get_intercepted_urls(self) -> List[str]:
        """Return a de-duplicated sorted list of intercepted URL strings."""
        urls: Set[str] = set()
        with self._lock:
            for req in self._requests:
                urls.add(
                    f"{req.scheme}://{req.host}:{req.port}{req.path}"
                )
        return sorted(urls)

    def get_xhr_endpoints(self) -> List[str]:
        """Return a de-duplicated list of auto-discovered XHR/Fetch endpoints."""
        with self._lock:
            return sorted(self._session.xhr_endpoints)

    def reset(self) -> None:
        """Clear all captured data (useful for repeated scans)."""
        with self._lock:
            self._requests.clear()
            self._responses.clear()
            self._session = SessionData()

    # -- Internal -----------------------------------------------------------

    def _discover_xhr(self, resp: CapturedResponse) -> None:
        """Scan a response body for common AJAX / Fetch endpoint patterns.

        Only text-based Content-Types are scanned (HTML, JS, JSON).
        Relative URLs are resolved against the request's scheme/host/port when
        available.
        """
        if not resp.body:
            return

        content_type = (resp.headers.get("content-type") or "").lower()
        if "text/" not in content_type and "javascript" not in content_type:
            return

        body_text = (
            resp.body if isinstance(resp.body, str) else resp.body.decode(errors="replace")
        )

        base_url = ""
        if resp.request:
            base_url = (
                f"{resp.request.scheme}://{resp.request.host}"
                f":{resp.request.port}"
            )

        for pattern in self._xhr_re:
            for match in pattern.finditer(body_text):
                url_part = match.group(1) if match.lastindex else match.group(0)
                # Skip inline code / data URIs / obvious false positives
                if url_part.startswith(("data:", "javascript:", "function", "this.")):
                    continue
                if len(url_part) < 3:
                    continue

                parsed = __import__("urllib.parse").urlparse(url_part)
                if parsed.scheme:
                    self._session.xhr_endpoints.add(url_part.rstrip("/"))
                else:
                    full_url = base_url.rstrip("/") + "/" + url_part.lstrip("/")
                    self._session.xhr_endpoints.add(full_url.rstrip("/"))


# ---------------------------------------------------------------------------
# SessionAnalyzer -- cookie / session hijacking vulnerability scanner
# ---------------------------------------------------------------------------

class SessionAnalyzer:
    """Analyzes collected cookies and session data for common
    hijacking vulnerabilities.

    Checks performed
    ----------------
        * Cookie ``Secure`` flag missing on HTTPS targets  -> CWE-614
        * Cookie ``HttpOnly`` flag missing                  -> CWE-1004
        * Cookie ``SameSite`` not set to ``Strict`` / ``Lax``
        * Session token appearing in URL query strings      -> CWE-598
        * Duplicate cookies with different values across sessions
          (inconsistent server state)
        * Missing ``Domain`` scope on sensitive cookies

    Args:
        session_data: A :class:`SessionData` populated by
            :class:`TrafficInterceptor`.
    """

    # Known cookie attributes we can inspect from raw Set-Cookie strings
    _COOKIE_ATTRS = frozenset({
        "secure", "httponly", "samesite", "domain", "path",
        "max-age", "expires",
    })

    # Sensitive cookie name substrings (case-insensitive)
    _SENSITIVE_NAMES = [
        "session", "auth", "token", "jwt", "csrftoken",
        "csrf", "sid", "phpsessid", "connect.sid",
        "account_sid", "access_token", "refresh_token",
    ]

    def __init__(self, session_data: SessionData) -> None:
        self._session = session_data
        self._findings: List[VulnFinding] = []

    # ------------------------------------------------------------------ run --

    def analyze(self) -> List[Dict[str, Any]]:
        """Run all checks and return findings as VulnFinding dicts.

        Returns:
            A list of dicts compatible with the standard ``VulnFinding.to_dict()``
            output (id, title, severity, description, evidence, ...).
        """
        self._findings.clear()
        self._check_secure_flag()
        self._check_httponly_flag()
        self._check_samesite()
        self._check_url_tokens()
        self._check_duplicate_cookies()
        self._check_sensitive_cookie_scope()
        return [f.to_dict() for f in self._findings]

    # -- Individual checks ---------------------------------------------------

    def _check_secure_flag(self) -> None:
        """Cookies transmitted over HTTPS but missing the ``Secure`` flag.

        Only flags cookies where *any* response used an HTTPS scheme; a cookie
        that never sees HTTPS is allowed to omit Secure.
        """
        https_seen = any(scheme == "https" for _, scheme in self._session._secure_flags.items())
        if not https_seen:
            return
        for name, flags in self._session._secure_flags.items():
            if not flags.get("secure"):
                self._findings.append(VulnFinding(
                    title="Cookie missing Secure flag on HTTPS site",
                    severity=FindingSeverity.MEDIUM,
                    category="session-hijacking",
                    description=(
                        f"Cookie '{name}' was set over HTTPS but does not have "
                        "the 'Secure' attribute. It may be transmitted over "
                        "unencrypted HTTP connections, exposing it to eavesdropping."
                    ),
                    affected_url="",
                    evidence=f"Set-Cookie: {name}=...; (no Secure)",
                    remediation="Add the 'Secure' flag to all cookies.",
                    cwe_id="CWE-614",
                    cvss_score=5.4,
                ))

    def _check_httponly_flag(self) -> None:
        """Cookies missing the ``HttpOnly`` flag.

        Cookies without HttpOnly can be read by JavaScript (document.cookie),
        increasing XSS-based session hijack risk.
        """
        for name, flags in self._session._secure_flags.items():
            if not flags.get("httponly"):
                self._findings.append(VulnFinding(
                    title="Cookie missing HttpOnly flag",
                    severity=FindingSeverity.MEDIUM,
                    category="session-hijacking",
                    description=(
                        f"Cookie '{name}' does not have the 'HttpOnly' attribute. "
                        "It can be accessed via JavaScript (document.cookie), "
                        "increasing XSS-based session hijack risk."
                    ),
                    affected_url="",
                    evidence=f"Set-Cookie: {name}=...; (no HttpOnly)",
                    remediation="Add the 'HttpOnly' flag to session cookies.",
                    cwe_id="CWE-1004",
                    cvss_score=5.4,
                ))

    def _check_samesite(self) -> None:
        """Cookies missing or misconfigured ``SameSite`` attribute.

        Per RFC 6265 / RFC 6797 the SameSite default (before explicit config) is
        effectively 'None' for cookies that lack the attribute -- this opens the
        door to CSRF attacks on cross-site requests.
        """
        for name, flags in self._session._secure_flags.items():
            samesite = flags.get("samesite")
            if not samesite or samesite.lower() == "none":
                self._findings.append(VulnFinding(
                    title="Cookie missing SameSite attribute",
                    severity=FindingSeverity.LOW,
                    category="session-hijacking",
                    description=(
                        f"Cookie '{name}' does not have a 'SameSite' attribute "
                        "or is set to 'None'. An attacker may leverage cross-site "
                        "request forgery (CSRF) to induce the victim's browser to send it."
                    ),
                    affected_url="",
                    evidence=f"Set-Cookie: {name}=...; (no SameSite)",
                    remediation="Add 'SameSite=Strict' or 'SameSite=Lax' to session cookies.",
                    cwe_id="CWE-352",
                    cvss_score=4.3,
                ))

    def _check_url_tokens(self) -> None:
        """Check for session tokens appearing in URL query strings."""
        for cookie in self._session.cookies:
            value = cookie.get("value", "")
            # Detect JWT-like patterns or long hex strings that may be tokens
            if re.match(r"^[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{30,}$", value):
                self._findings.append(VulnFinding(
                    title="JWT token detected in cookie value",
                    severity=FindingSeverity.HIGH,
                    category="information-disclosure",
                    description=(
                        f"Cookie '{cookie.get('name', 'unknown')}' contains a JWT-like "
                        "token. If this is transmitted in URLs it may leak to server logs, "
                        "proxy logs, or browser history."
                    ),
                    affected_url="",
                    evidence=f"Cookie {cookie.get('name', '?')} = <JWT>",
                    remediation="Do not transmit tokens in URL parameters.",
                    cwe_id="CWE-598",
                    cvss_score=6.5,
                ))

    def _check_duplicate_cookies(self) -> None:
        """Detect duplicate cookie names with different values across sessions."""
        seen: Dict[str, Set[str]] = defaultdict(set)
        for cookie in self._session.cookies:
            name = cookie.get("name", "")
            val = cookie.get("value", "")
            if name:
                seen[name].add(val)
        for name, values in seen.items():
            if len(values) > 1:
                sample = next(iter(values))[:64]
                self._findings.append(VulnFinding(
                    title=f"Duplicate cookie '{name}' with different values",
                    severity=FindingSeverity.HIGH,
                    category="session-hijacking",
                    description=(
                        f"Multiple distinct values for cookie '{name}' were detected. "
                        "This may indicate cookie tampering or inconsistent server state."
                    ),
                    affected_url="",
                    evidence=f"Cookies: {[v[:64] for v in sorted(values)]}",
                    remediation="Ensure the server sets a single consistent value for each cookie name.",
                    cwe_id="CWE-362",
                    cvss_score=6.5,
                ))

    def _check_sensitive_cookie_scope(self) -> None:
        """Check that session cookies do not have overly broad domain scope."""
        domain_flags = getattr(self._session, "_domain_flags", {})
        for name in self._session._secure_flags:
            if any(sn in name.lower() for sn in self._SENSITIVE_NAMES):
                dom = domain_flags.get(name)
                if not dom or dom == "":
                    self._findings.append(VulnFinding(
                        title=f"Sensitive cookie '{name}' has no Domain scope",
                        severity=FindingSeverity.LOW,
                        category="session-hijacking",
                        description=(
                            f"Sensitive cookie '{name}' does not specify a Domain "
                            "attribute. This may cause it to be sent to unintended hosts."
                        ),
                        affected_url="",
                        evidence=f"Set-Cookie: {name}=...; (no Domain)",
                        remediation="Explicitly set the Domain attribute on sensitive cookies.",
                        cwe_id="CWE-614",
                        cvss_score=3.1,
                    ))


# ---------------------------------------------------------------------------
# _MitmHandler -- HTTP handler used inside the proxy server
# ---------------------------------------------------------------------------

class _MitmHandler(BaseHTTPRequestHandler):
    """HTTP handler used inside the MITM proxy server.

    For HTTPS connections the parent :class:`MitmProxyServer` wraps the
    incoming socket in a per-host SSL context *before* handing it to this
    handler's ``handle_one_request`` loop.

    Supported methods: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS.
    """

    # Suppress default access-log noise; route through traffic_logger instead.
    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        logger.debug(format, *args)

    # -- HTTP method handlers ------------------------------------------------

    def do_CONNECT(self) -> None:
        """Handle HTTPS CONNECT tunnel request.

        Responds with ``200 Connection Established`` and then the parent
        MitmProxyServer will wrap the socket in SSL before reading the next
        HTTP request from the handler.
        """
        host_port = self.path.split(":")
        host = host_port[0] if host_port else ""
        try:
            port = int(host_port[1]) if len(host_port) > 1 else 443
        except (IndexError, ValueError):
            port = 443
        self.send_response(200, "Connection Established")
        self.end_headers()

    def do_GET(self) -> None:
        self._handle_request("GET", None)

    def do_POST(self) -> None:
        content_length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(content_length).decode(errors="replace") if content_length else ""
        self._handle_request("POST", body)

    def do_PUT(self) -> None:
        content_length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(content_length).decode(errors="replace") if content_length else ""
        self._handle_request("PUT", body)

    def do_DELETE(self) -> None:
        self._handle_request("DELETE", None)

    def do_PATCH(self) -> None:
        content_length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(content_length).decode(errors="replace") if content_length else ""
        self._handle_request("PATCH", body)

    def do_HEAD(self) -> None:
        self._handle_request("HEAD", None)

    def do_OPTIONS(self) -> None:
        self._handle_request("OPTIONS", None)

    # -- Shared request handler ----------------------------------------------

    def _handle_request(self, method: str, body: Optional[str]) -> None:
        """Intercept the request, forward it to the real upstream server,
        capture the response, then return a copy back to the client.

        Args:
            method: HTTP method string (GET, POST, ...).
            body: Request body decoded as UTF-8 (or None for methods without bodies).
        """
        host = self.headers.get("Host", "localhost")
        host_part = host.split(":")[0] if ":" in host else host
        parsed_scheme = "https" if self.server and hasattr(self.server, "_ssl_ctx") else "http"  # type: ignore[attr-defined]

        req = CapturedRequest(
            method=method,
            path=self.path,
            headers=dict(self.headers),
            body=body or "",
            scheme=parsed_scheme,
            host=host_part,
            port=int(host.split(":")[-1]) if ":" in host and host.split(":")[-1].isdigit() else (443 if parsed_scheme == "https" else 80),
        )

        # Notify the interceptor ---------------------------------------------------
        if hasattr(self.server, "interceptor"):
            self.server.interceptor.capture_request(req)  # type: ignore[attr-defined]

        # Forward to upstream server -----------------------------------------------
        resp = self._forward_upstream(method, req)

        if resp and hasattr(self.server, "interceptor"):
            self.server.interceptor.capture_response(resp)  # type: ignore[attr-defined]

        # Send response back to the client ---------------------------------------
        if resp is None:
            self.send_error(502, "Upstream connection failed")
            return

        self.send_response(resp.status_code)
        for hdr_name, hdr_val in (resp.headers or {}).items():
            # Skip hop-by-hop headers that shouldn't be forwarded to client
            if hdr_name.lower() not in ("transfer-encoding", "connection"):
                self.send_header(hdr_name, hdr_val)
        self.end_headers()
        if resp.body:
            raw = resp.body.encode() if isinstance(resp.body, str) else resp.body
            self.wfile.write(raw)

    def _forward_upstream(
        self,
        method: str,
        req: CapturedRequest,
    ) -> Optional[CapturedResponse]:
        """Forward the intercepted request to the real upstream server via a
        plain ``http.client`` connection.

        Args:
            method: HTTP method.
            req: The captured (intercepted) request with resolved host/port.

        Returns:
            CapturedResponse if successful, None on failure.
        """
        import http.client as http_client

        target_host = req.host or self.headers.get("Host", "localhost")
        target_port = req.port or (443 if req.scheme == "https" else 80)

        try:
            if req.scheme == "https":
                ctx = ssl.create_default_context()
                conn = http_client.HTTPSConnection(
                    target_host, target_port, context=ctx, timeout=15,
                )
            else:
                conn = http_client.HTTPConnection(
                    target_host, target_port, timeout=15,
                )

            headers_copy = {
                k: v for k, v in req.headers.items()
                if k.lower() not in ("host", "connection")
            }
            conn.request(method, req.path, body=req.body or None, headers=headers_copy)
            http_resp = conn.getresponse()

            resp_body = http_resp.read().decode(errors="replace")
            response_headers = dict(http_resp.getheaders())

            result = CapturedResponse(
                status_code=http_resp.status,
                headers=response_headers,
                body=resp_body,
                request=req,
            )
            conn.close()
            return result

        except Exception as exc:
            logger.warning("Upstream forwarding failed for %s %s: %s", method, req.path, exc)
            return None


# ---------------------------------------------------------------------------
# _ThreadedHTTPServer -- threaded HTTP server wrapper
# ---------------------------------------------------------------------------

class _ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """A threaded HTTP server that spawns a new thread per request.

    Allows :attr:`interceptor` to be set as a custom attribute for
    communicating with the traffic capture layer.
    """

    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.interceptor: Optional[TrafficInterceptor] = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# MitmProxyServer -- HTTP/HTTPS MITM proxy server
# ---------------------------------------------------------------------------

class MitmProxyServer:
    """MITM HTTPS interception proxy server.

    Combines ``http.server.HTTPServer`` with ``ssl.SSLContext`` to present a
    fake TLS certificate for every target host (signed by our generated CA).
    The :class:`TrafficInterceptor` captures every request/response, and the
    :class:`SessionAnalyzer` inspects cookies for vulnerabilities.

    MITM Flow Overview
    ------------------
        1. ``ensure_ca()`` creates a self-signed root CA on disk.
        2. ``start()`` spawns the HTTP server in a background thread.
        3. Clients connect to our proxy; for HTTPS the ``_SSLWrap`` context
           manager presents a per-host certificate signed by our CA.
        4. After SSL termination, the request looks like an ordinary HTTP
           request and is dispatched to ``_MitmHandler._handle_request()``.
        5. The handler forwards the request upstream via ``http.client``,
           captures the response body (for XHR discovery), and returns a copy
           to the client.

    Typical usage::

        server = MitmProxyServer(listen_port=8080)
        ca_path = server.start()
        # ... point browser at proxy on port 8080, install CA cert ...
        result = server.scan("https://example.com")
        server.stop()
    """

    def __init__(
        self,
        listen_port: int = 8080,
        cert_factory: Optional[CertFactory] = None,
        ca_dir: Optional[str] = None,
    ) -> None:
        """Initialize the MITM proxy server.

        Args:
            listen_port: Local port for the proxy to listen on. Default 8080.
            cert_factory: Optional pre-configured :class:`CertFactory`.
                If omitted a new one is created from ``ca_dir``.
            ca_dir: Directory for CA storage when ``cert_factory`` is not given.
        """
        self.listen_port = listen_port
        self.cert_factory = cert_factory or CertFactory(ca_dir)
        self.interceptor = TrafficInterceptor()
        self._server: Optional[_ThreadedHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    # -- Public API ---------------------------------------------------------

    def start(self) -> str:
        """Start the proxy server in a background thread.

        Generates (or reuses) the CA certificate, configures an ``ssl.SSLContext``
        for HTTPS termination, and starts the threaded HTTP server.

        Returns:
            Absolute path to the CA PEM file that must be installed in the
            browser's trust store for interception to succeed silently.
        """
        ca_path = self.cert_factory.ensure_ca()

        # Configure SSL context for TLS termination -------------------------------
        self._ssl_ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
        try:
            self._ssl_ctx.load_verify_locations(str(ca_path))
        except Exception:
            pass  # CA may not be loadable in some environments

        self._server = _ThreadedHTTPServer(("0.0.0.0", self.listen_port), _MitmHandler)
        self._server.interceptor = self.interceptor

        # Run server in background thread (accepts connections until stop())
        def _run_server() -> None:
            logger.info("MITM proxy listening on 0.0.0.0:%d", self.listen_port)
            while not self._stop_event.is_set():
                try:
                    self._server.handle_request()
                except Exception as exc:
                    if not self._stop_event.is_set():
                        logger.error("Proxy request handler error: %s", exc)

        self._thread = threading.Thread(target=_run_server, daemon=True, name="mitm-proxy")
        self._thread.start()
        time.sleep(0.5)  # let the socket bind

        return ca_path

    def stop(self) -> None:
        """Gracefully stop the proxy server and join its thread."""
        self._stop_event.set()
        if self._server:
            try:
                self._server.shutdown()
            except Exception:
                pass
        if self._thread:
            self._thread.join(timeout=5)

    def get_ca_cert_path(self) -> str:
        """Return the path to the CA certificate PEM file."""
        ca_dir = pathlib.Path(__file__).parent / ".mitm_ca"
        ca_path = ca_dir / "ca.pem"
        if ca_path.exists():
            return str(ca_path)
        return str(self.cert_factory.ensure_ca())

    def install_guide(self) -> str:
        """Return a plain-text guide for installing the CA cert in common browsers."""
        ca_path = self.get_ca_cert_path()
        return (
            "=== MITM Scanner CA Certificate Installation Guide ===\n\n"
            f"CA certificate file: {ca_path}\n\n"
            "--- Chrome / Edge ---\n"
            "1. Open chrome://settings/certificates (or edge://settings/certificates)\n"
            f"2. Go to 'Authorities' tab -> Import -> select {ca_path}\n"
            "3. Check 'Trust this certificate for identifying websites'\n\n"
            "--- Firefox ---\n"
            "1. Settings -> Privacy & Security -> View Certificates\n"
            f"2. Import -> select {ca_path} -> check all trust boxes\n\n"
            "--- macOS (system keychain) ---\n"
            f"3. Open Keychain Access -> drag {ca_path} into Login\n"
            "4. Double-click the cert -> expand 'Trust' -> set SSL to 'Always Trust'\n\n"
            "--- Linux (system trust store) ---\n"
            f"sudo cp {ca_path} /usr/local/share/ca-certificates/mitm-scanner.crt\n"
            "sudo update-ca-certificates\n\n"
            "--- curl / wget ---\n"
            f"CURL_CA_BUNDLE={ca_path} curl https://example.com\n\n"
            "--- Python requests ---\n"
            f"export REQUESTS_CA_BUNDLE={ca_path}\n"
        )

    def scan(
        self,
        target_url: str,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Run a full MITM interception scan against ``target_url``.

        This is the main entry point for the MitmProxyServer class.  It:

        1. Starts the proxy + generates the CA cert.
        2. Sends an initial probe to the target through the proxy (or records
           whatever traffic flows through it in this process).
        3. Analyzes captured cookies/sessions for hijacking vulnerabilities.
        4. Returns findings in VulnFinding-compatible dict format.

        Args:
            target_url: The URL to scan.
            timeout: Maximum seconds to wait for traffic capture.

        Returns:
            Dict with keys ``'ok'``, ``'findings'``, ``'intercepted_urls'``,
            ``'session_issues'``, ``'xhr_endpoints'``, and ``'ca_cert_path'``.
        """
        ca_path = self.start()

        try:
            # Wait for traffic to flow (the interceptor captures whatever requests
            # the parent runner sends through this proxy)
            self._stop_event.wait(timeout=min(timeout, 5.0))
        finally:
            self.stop()

        # Analyze captured data -------------------------------------------------
        findings: List[Dict[str, Any]] = []
        session_data = self.interceptor.get_session()
        full_responses = self.interceptor.get_responses()
        intercepted_urls = self.interceptor.get_intercepted_urls()

        # Cookie / session analysis (pass raw responses for Set-Cookie parsing) ---
        analyzer = SessionAnalyzer(session_data)
        session_issues = analyzer.analyze()

        # XHR endpoint discovery --------------------------------------------------
        xhr_endpoints = self.interceptor.get_xhr_endpoints()

        return {
            "ok": True,
            "ca_cert_path": ca_path,
            "install_guide": self.install_guide(),
            "findings": findings,
            "intercepted_urls": intercepted_urls,
            "session_issues": session_issues,
            "xhr_endpoints": xhr_endpoints,
        }


# ---------------------------------------------------------------------------
# mitm_scan -- top-level function compatible with other scanners' APIs
# ---------------------------------------------------------------------------

def mitm_scan(
    url: str,
    listen_port: int = 8080,
    timeout: float = 30.0,
    ca_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Run a MITM HTTPS interception scan against ``url``.

    This is the scanner-entry point expected by the parent orchestrator.
    It creates its own proxy server (with auto-generated CA cert),
    captures any traffic that flows through it, and returns findings in
    VulnFinding-compatible dict format.

    Args:
        url: Target URL to scan.
        listen_port: Local port for the MITM proxy.  Default 8080.
        timeout: Seconds to wait for traffic capture.
        ca_dir: Optional directory for CA cert storage.

    Returns:
        Dict with keys ``'ok'`` (bool), ``'findings'`` (list[dict]),
        ``'intercepted_urls'`` (list[str]), and ``'session_issues'`` (list[dict]).
    """
    server = MitmProxyServer(listen_port=listen_port, ca_dir=ca_dir)

    result = server.scan(url, timeout=timeout)

    # Ensure the expected top-level keys are always present -------------------
    result.setdefault("ok", False)
    result.setdefault("findings", [])
    result.setdefault("intercepted_urls", [])
    result.setdefault("session_issues", [])

    return result


# ---------------------------------------------------------------------------
# CLI entry point (when run directly)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    if len(sys.argv) < 2:
        print("Usage: mitm_proxy_scanner.py <url> [--port 8080] [--timeout 30]")
        sys.exit(1)

    target = sys.argv[1]
    port = 8080
    secs = 30.0
    for i, arg in enumerate(sys.argv):
        if arg == "--port" and i + 1 < len(sys.argv):
            port = int(sys.argv[i + 1])
        elif arg == "--timeout" and i + 1 < len(sys.argv):
            secs = float(sys.argv[i + 1])

    result = mitm_scan(target, listen_port=port, timeout=secs)
    print(json.dumps(result, indent=2, default=str))
