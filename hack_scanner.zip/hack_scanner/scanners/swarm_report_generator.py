# from-source-of: Pentest-Swarm-AI (internal/agent/report/)
# 报告生成模块 — 将扫描发现结果转换为专业渗透测试报告
"""
报告生成器，支持 Markdown、SARIF、Bugcrowd、HackerOne 等格式输出。
核心算法源自 Pentest-Swarm-AI 的:
  - report/renderer.go     -> Markdown/HTML/SARIF 渲染
  - report/sarif.go        -> SARIF 2.1.0 JSON 格式
  - report/submission.py   -> Bugcrowd/HackerOne 提交模板
  - report/templates/*     -> 平台专用提交模板
"""

import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


# ---------------------------------------------------------------------------
# 数据类型定义 (对应 pipeline.PentestReport / Pipeline.ReportFinding)
# ---------------------------------------------------------------------------

class ReportFormat(str, Enum):
    """报告输出格式"""
    MARKDOWN = "markdown"       # GitHub-flavored Markdown
    JSON = "json"               # 结构化 JSON
    HTML = "html"               # 自包含 HTML（含暗色主题）
    SARIF = "sarif"             # SARIF 2.1.0 (GitHub Code Scanning)
    BUGBOUNTY = "bugcrowd"      # Bugcrowd 提交模板
    HACKERONE = "hackerone"     # HackerOne 提交模板


@dataclass
class Evidence:
    """单条证据"""
    type: str = ""           # screenshot / http_request / response_header / proof_text
    content: str = ""        # 证据内容
    timestamp: str = ""      # 时间戳
    description: str = ""    # 描述


@dataclass
class ReportFinding:
    """报告中的单条发现"""
    id: str = ""
    title: str = ""
    severity: str = "info"
    cvss_score: float = 0.0
    cvss_vector: str = ""
    description: str = ""
    evidence: List[Evidence] = field(default_factory=list)
    remediation: str = ""
    affected_components: List[str] = field(default_factory=list)
    references: List[str] = field(default_factory=list)
    cve_ids: List[str] = field(default_factory=list)


@dataclass
class RiskSummary:
    """风险统计摘要"""
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    info_count: int = 0

    @property
    def overall_risk(self) -> str:
        if self.critical_count > 0:
            return "critical"
        elif self.high_count > 0:
            return "high"
        elif self.medium_count > 0:
            return "medium"
        else:
            return "low"


@dataclass
class RemediationItem:
    """修复项"""
    priority: int = 0
    finding: str = ""
    action: str = ""
    effort: str = ""
    impact: str = ""


@dataclass
class PentestReport:
    """完整的渗透测试报告（对应 pipeline.PentestReport）"""
    id: str = ""
    campaign_id: str = ""
    target: str = ""
    objective: str = ""
    executive_summary: str = ""
    findings: List[ReportFinding] = field(default_factory=list)
    risk_summary: RiskSummary = field(default_factory=RiskSummary)
    attack_narrative: str = ""
    remediation_plan: List[RemediationItem] = field(default_factory=list)
    generated_at: str = ""
    roi_footer: str = ""


# ---------------------------------------------------------------------------
# 报告生成器 (对应 renderer.go Renderer)
# ---------------------------------------------------------------------------

class ReportGenerator:
    """
    报告生成器 — 将渗透测试发现转换为多种格式的专业报告。

    支持格式：
        - MARKDOWN:   GitHub-flavored Markdown 报告（主报告）
        - SARIF:      SARIF 2.1.0 JSON（集成到 GitHub Code Scanning）
        - BUGBOUNTY:  Bugcrowd 平台提交模板
        - HACKERONE:  HackerOne 平台提交模板
    """

    def __init__(self):
        self._template_cache: dict = {}

    def generate(self, report: PentestReport, fmt: ReportFormat = ReportFormat.MARKDOWN) -> str:
        """
        生成报告字符串。

        Args:
            report: 渗透测试报告对象
            fmt:    输出格式枚举

        Returns:
            格式化后的报告文本/JSON/HTML
        """
        if fmt == ReportFormat.MARKDOWN:
            return self._to_markdown(report)
        elif fmt == ReportFormat.SARIF:
            return self._to_sarif(report)
        elif fmt == ReportFormat.BUGBOUNTY:
            return self._to_bugcrowd(report)
        elif fmt == ReportFormat.HACKERONE:
            return self._to_hackerone(report)
        elif fmt == ReportFormat.JSON:
            return json.dumps(self._report_to_dict(report), indent=2, ensure_ascii=False)
        elif fmt == ReportFormat.HTML:
            md = self._to_markdown(report)
            return self._html_wrap(md, report.target)
        else:
            raise ValueError(f"不支持的报告格式: {fmt}")

    def generate_finding_submission(self, finding: ReportFinding,
                                     classified_info: Optional[dict] = None,
                                     corroborating: List[str] = None,
                                     platform: str = "hackerone") -> str:
        """
        为单个发现生成平台提交模板。

        对应 Go 源码 submission.go:BuildSubmissionView + RenderSubmission。

        Args:
            finding:          单条发现
            classified_info:  分类信息 (cve_ids, attack_category, reproduce)
            corroborating:   交叉验证工具列表
            platform:        "hackerone" | "bugcrowd"

        Returns:
            平台格式的提交文本
        """
        view = self._build_submission_view(finding, classified_info, corroborating or [])

        if platform == "bugcrowd":
            return self._render_bugcrowd_view(view)
        else:  # hackerone / intigriti
            return self._render_hackerone_view(view)

    # ---------------------------------------------------------------
    # Markdown 渲染 (对应 renderer.go ToMarkdown)
    # ---------------------------------------------------------------

    def _to_markdown(self, report: PentestReport) -> str:
        lines = []

        lines.append("# Penetration Test Report\n")
        lines.append(f"**Target:** {report.target}\n")
        lines.append(f"**Objective:** {report.objective}\n")
        lines.append(f"**Date:** {report.generated_at}\n")
        lines.append("---\n")
        lines.append("")

        # 执行摘要
        if report.executive_summary:
            lines.append("## Executive Summary\n")
            lines.append(report.executive_summary)
            lines.append("")

        # 风险摘要表
        lines.append("## Risk Summary\n")
        lines.append("| Severity | Count |")
        lines.append("|---|---|")
        lines.append(f"| Critical | {report.risk_summary.critical_count} |")
        lines.append(f"| High | {report.risk_summary.high_count} |")
        lines.append(f"| Medium | {report.risk_summary.medium_count} |")
        lines.append(f"| Low | {report.risk_summary.low_count} |")
        lines.append(f"| Info | {report.risk_summary.info_count} |")
        lines.append("")

        # 发现列表
        lines.append("## Findings\n")
        for i, f in enumerate(report.findings, 1):
            sev_upper = f.severity.upper()
            lines.append(f"### {i}. [{sev_upper}] {f.title} (CVSS: {f.cvss_score:.1f})\n")
            lines.append(f.description)
            lines.append("")

            if f.evidence:
                lines.append("**Evidence:**\n")
                for e in f.evidence:
                    lines.append(f"```\n{e.content}\n```\n")
                lines.append("")

            if f.remediation:
                lines.append("**Remediation:**\n")
                lines.append(f.remediation)
                lines.append("")

            lines.append("---\n")
            lines.append("")

        # 攻击叙事
        if report.attack_narrative:
            lines.append("## Attack Narrative\n")
            lines.append(report.attack_narrative)
            lines.append("")

        # 修复计划表
        lines.append("## Remediation Plan\n")
        lines.append("| Priority | Finding | Action | Effort | Impact |")
        lines.append("|---|---|---|---|---|")
        for item in report.remediation_plan:
            lines.append(f"| {item.priority} | {item.finding} | {item.action} | {item.effort} | {item.impact} |")

        # ROI footer
        if report.roi_footer:
            lines.append("")
            lines.append("---\n")
            lines.append(report.roi_footer)
            lines.append("")

        return "\n".join(lines)

    # ---------------------------------------------------------------
    # SARIF 2.1.0 渲染 (对应 sarif.go ToSARIF)
    # ---------------------------------------------------------------

    def _to_sarif(self, report: PentestReport) -> str:
        """生成 SARIF 2.1.0 JSON — 对应 sarif.go 的完整实现"""

        rules = []
        results = []
        seen_rule_ids = set()

        for f in report.findings:
            rule_id = self._sanitise_rule_id(f.title)

            if rule_id not in seen_rule_ids:
                rules.append({
                    "id": rule_id,
                    "name": f.title,
                    "shortDescription": {"text": f.title},
                    "fullDescription": {"text": f.description or f.title},
                    "help": {
                        "text": f.remediation or "See advisory for remediation.",
                        "markdown": f.remediation or "See advisory for remediation.",
                    },
                    "helpUri": self._first_reference(f.references),
                    "defaultConfiguration": {
                        "level": self._severity_to_sarif_level(f.severity),
                    },
                    "properties": {
                        "security-severity": f"{f.cvss_score:.1f}",
                        "tags": ["security", f.severity],
                    },
                })
                seen_rule_ids.add(rule_id)

            # SARIF 结果
            msg = f.title
            if f.cvss_score > 0:
                msg += f" (CVSS {f.cvss_score:.1f})"
            if f.description:
                msg += "\n\n" + f.description

            results.append({
                "ruleId": rule_id,
                "level": self._severity_to_sarif_level(f.severity),
                "message": {"text": msg},
                "properties": {
                    "cvss_score": f.cvss_score,
                    "cvss_vector": f.cvss_vector,
                },
                "locations": [{
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": self._affected_uri(f),
                        }
                    }
                }],
            })

        doc = {
            "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "Pentest Swarm AI",
                        "informationUri": "https://github.com/Armur-Ai/Pentest-Swarm-AI",
                        "version": "0.2",
                        "rules": rules,
                    }
                },
                "results": results,
                "automationDetails": {
                    "inferenceId": report.id or "unknown"
                },
            }]
        }

        return json.dumps(doc, indent=2)

    def _sanitise_rule_id(self, title: str) -> str:
        """
        从标题生成稳定的 SARIF rule ID。
        对应 Go sanitiseRuleID(): ASCII-alphanumeric + hyphen, max 50 chars.
        """
        out = []
        prev_hyphen = False

        for ch in title:
            if 'A' <= ch <= 'Z':
                out.append(ch.lower())
                prev_hyphen = False
            elif ('a' <= ch <= 'z') or ('0' <= ch <= '9'):
                out.append(ch)
                prev_hyphen = False
            else:
                if not prev_hyphen and out:
                    out.append('-')
                    prev_hyphen = True

        # 去除尾部连字符
        while out and out[-1] == '-':
            out.pop()

        result = ''.join(out)
        if len(result) > 50:
            result = result[:50]
        if not result:
            return "pentest-finding"

        return f"pentestswarm/{result}"

    @staticmethod
    def _severity_to_sarif_level(severity: str) -> str:
        """严重程度到 SARIF 级别映射"""
        if severity in ("critical", "high"):
            return "error"
        elif severity == "medium":
            return "warning"
        else:
            return "note"

    @staticmethod
    def _first_reference(references: List[str]) -> str:
        for r in references:
            if r:
                return r
        return ""

    @staticmethod
    def _affected_uri(finding: ReportFinding) -> str:
        for comp in finding.affected_components:
            if comp:
                return comp
        return "unknown"

    # ---------------------------------------------------------------
    # Bugcrowd 提交模板 (对应 templates/bugcrowd.md.tmpl)
    # ---------------------------------------------------------------------------

    def _to_bugcrowd(self, report: PentestReport) -> str:
        """生成 Bugcrowd 平台提交的汇总报告"""
        parts = []

        if report.findings:
            for f in report.findings:
                view = self._build_submission_view(f, platform="bugcrowd")
                parts.append(self._render_bugcrowd_view(view))
                parts.append("")
                parts.append("---\n")
                parts.append("")
        return "\n".join(parts)

    # ---------------------------------------------------------------
    # HackerOne 提交模板 (对应 templates/hackerone.md.tmpl)
    # ---------------------------------------------------------------

    def _to_hackerone(self, report: PentestReport) -> str:
        """生成 HackerOne 平台提交的汇总报告"""
        parts = []

        if report.findings:
            for f in report.findings:
                view = self._build_submission_view(f, platform="hackerone")
                parts.append(self._render_hackerone_view(view))
                parts.append("")
                parts.append("---\n")
                parts.append("")
        return "\n".join(parts)

    # ---------------------------------------------------------------
    # 提交视图模型 (对应 submission.go SubmissionView + BuildSubmissionView)
    # ---------------------------------------------------------------

    def _build_submission_view(self, finding: ReportFinding,
                               classified_info: Optional[dict] = None,
                               corroborating: List[str] = None) -> dict:
        """将 ReportFinding 折叠为提交模板需要的视图模型"""
        affected = ""
        for c in finding.affected_components:
            if c:
                affected = c
                break
        if not affected:
            affected = "unknown"

        # 严重性首字母大写
        sev_display = finding.severity.capitalize() if finding.severity else "Informational"

        view = {
            "title": finding.title,
            "target": affected,
            "severity": sev_display,
            "cvss_score": finding.cvss_score,
            "cvss_vector": finding.cvss_vector,
            "cve_ids": finding.cve_ids,
            "evidence": finding.evidence,
            "corroborating_tools": corroborating or [],
        }

        # Summary / Impact / Remediation 带默认回退
        view["summary"] = finding.description or f"Automated scanner detected a vulnerability on {affected}."
        view["impact"] = self._infer_impact(finding.severity)
        view["remediation"] = finding.remediation or (
            "Apply vendor patch / disable affected feature / sanitize input per vendor guidance."
        )

        if classified_info:
            view.setdefault("cve_ids", []).extend(classified_info.get("cve_ids", []))
            view["attack_category"] = classified_info.get("attack_category", "")
            reproduce = classified_info.get("reproduce")
            if reproduce:
                if isinstance(reproduce, dict):
                    view["reproduce_command"] = reproduce.get("command", "")
                    view["reproduce_http_request"] = reproduce.get("http_request", "")
                    view["reproduce_expected_indicator"] = reproduce.get("expected_indicator", "")

        return view

    @staticmethod
    def _infer_impact(severity: str) -> str:
        """根据严重程度推断影响描述（对应 submission.go inferImpact）"""
        mapping = {
            "critical": (
                "Critical. An unauthenticated remote attacker can likely achieve full compromise of the asset."
            ),
            "high": (
                "High. An attacker can likely obtain sensitive data, elevate privileges, or disrupt service."
            ),
            "medium": (
                "Medium. Exploitable, but requires some preconditions (authenticated access, user interaction, "
                "or chained with another finding)."
            ),
            "low": "Low. Minor information disclosure or hardening gap.",
        }
        return mapping.get(severity, "Informational. No direct security impact; included for situational awareness.")

    def _render_hackerone_view(self, view: dict) -> str:
        """渲染 HackerOne 提交模板（对应 templates/hackerone.md.tmpl）"""
        parts = []

        parts.append("## Summary\n")
        parts.append(view["summary"] + "\n")

        # 重现步骤
        parts.append("## Steps to Reproduce\n")
        if view.get("reproduce_command"):
            parts.append("")
            parts.append("```sh")
            parts.append(view["reproduce_command"])
            parts.append("```\n")
        if view.get("reproduce_http_request"):
            parts.append("")
            parts.append("```http")
            parts.append(view["reproduce_http_request"])
            parts.append("```\n")

        indicator = view.get("reproduce_expected_indicator", "")
        if indicator:
            parts.append(f"\nThe response contains `{indicator}`, which confirms the vulnerability.")

        parts.append("")

        # 证据
        evidence = view.get("evidence", [])
        if evidence:
            parts.append("### Evidence\n")
            for ev in evidence:
                ts = ev.timestamp if hasattr(ev, "timestamp") else ""
                desc = ev.description if hasattr(ev, "description") else ""
                parts.append(f"- **{ev.type}** ({ts}){' — ' + desc if desc else ''}")
            parts.append("")

        parts.append("## Impact\n")
        parts.append(view["impact"] + "\n")

        parts.append("## Recommendation\n")
        parts.append(view["remediation"] + "\n")

        parts.append("## Severity\n")
        cvss_str = f"CVSS {view['cvss_score']:.1f}"
        if view.get("cvss_vector"):
            cvss_str += f" (`{view['cvss_vector']}`)"
        parts.append(f"**{view['severity']}**\n")

        # CVE 关联
        cves = view.get("cve_ids", [])
        if cves:
            parts.append("\n## Related CVEs\n")
            for cve in cves:
                parts.append(f"- [{cve}](https://nvd.nist.gov/vuln/detail/{cve})")

        # 交叉验证工具
        tools = view.get("corroborating_tools", [])
        if tools:
            parts.append("\n## Verified by\n")
            for t in tools:
                parts.append(f"- {t}")

        parts.append("\n---\n")
        parts.append(
            "*Filed by Pentest Swarm AI. If this is a false positive, reply with `[FP]` "
            "and the classifier will suppress this pattern in your future scans.*"
        )

        return "\n".join(parts)

    def _render_bugcrowd_view(self, view: dict) -> str:
        """渲染 Bugcrowd 提交模板（对应 templates/bugcrowd.md.tmpl）"""
        parts = []

        parts.append("### Vulnerability Details\n")
        parts.append(f"- **Title:** {view['title']}")
        parts.append(f"- **Severity (VRT):** {view['severity']} · CVSS {view['cvss_score']:.1f}")
        parts.append(f"- **Target:** {view['target']}")
        if view.get("attack_category"):
            parts.append(f"- **Category:** {view['attack_category']}")

        parts.append("")
        parts.append("### Description\n")
        parts.append(view["summary"] + "\n")

        parts.append("### Steps to Reproduce\n")
        if view.get("reproduce_command"):
            parts.append("")
            parts.append("```sh")
            parts.append(view["reproduce_command"])
            parts.append("```\n")
        elif view.get("reproduce_http_request"):
            parts.append("")
            parts.append("```http")
            parts.append(view["reproduce_http_request"])
            parts.append("```\n")
        else:
            parts.append("\n1. See evidence attachments.\n")

        parts.append("\n### Proof of Concept / Impact\n")
        parts.append(view["impact"] + "\n")

        parts.append("\n### Suggested Remediation\n")
        parts.append(view["remediation"] + "\n")

        cves = view.get("cve_ids", [])
        if cves:
            parts.append("\n### References\n")
            for cve in cves:
                parts.append(f"- {cve} — https://nvd.nist.gov/vuln/detail/{cve}")

        # 交叉验证工具
        tools = view.get("corroborating_tools", [])
        if tools:
            parts.append("\n---\n")
            cross_validated = ", ".join(tools)
            parts.append(f"*Generated by Pentest Swarm AI. Cross-validated by: {cross_validated}.*")
        else:
            parts.append("\n---\n")
            parts.append("*Generated by Pentest Swarm AI. Single-tool finding.*")

        return "\n".join(parts)

    # ---------------------------------------------------------------
    # HTML 渲染 (对应 renderer.go ToHTML)
    # ---------------------------------------------------------------

    @staticmethod
    def _html_wrap(md_content: str, target: str) -> str:
        """将 Markdown 包装为暗色主题 HTML"""
        return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pentest Report — {target}</title>
<style>
  body {{ font-family: -apple-system, system-ui, sans-serif; background: #0a0a0f; color: #e0e0e0; max-width: 900px; margin: 0 auto; padding: 2rem; line-height: 1.6; }}
  h1 {{ color: #fff; border-bottom: 2px solid #333; padding-bottom: 0.5rem; }}
  h2 {{ color: #60a5fa; margin-top: 2rem; }}
  h3 {{ color: #f59e0b; }}
  table {{ border-collapse: collapse; width: 100%; margin: 1rem 0; }}
  th, td {{ border: 1px solid #333; padding: 0.5rem 1rem; text-align: left; }}
  th {{ background: #1a1a2e; color: #60a5fa; }}
  code, pre {{ background: #1a1a2e; padding: 0.2rem 0.5rem; border-radius: 4px; font-size: 0.9rem; }}
  pre {{ padding: 1rem; overflow-x: auto; border: 1px solid #333; }}
  hr {{ border: none; border-top: 1px solid #333; margin: 2rem 0; }}
  .severity-critical {{ color: #ef4444; font-weight: bold; }}
  .severity-high {{ color: #f97316; font-weight: bold; }}
  .severity-medium {{ color: #eab308; }}
  .severity-low {{ color: #22c55e; }}
</style>
</head>
<body>
<pre style="white-space: pre-wrap;">{md_content}</pre>
</body>
</html>'''

    @staticmethod
    def _report_to_dict(report: PentestReport) -> dict:
        """将报告序列化为字典（用于 JSON 输出）"""
        findings = []
        for f in report.findings:
            ev_list = []
            for e in f.evidence:
                ev_list.append({
                    "type": e.type,
                    "content": e.content,
                    "timestamp": e.timestamp,
                    "description": e.description,
                })
            findings.append({
                "id": f.id,
                "title": f.title,
                "severity": f.severity,
                "cvss_score": f.cvss_score,
                "cvss_vector": f.cvss_vector,
                "description": f.description,
                "evidence": ev_list,
                "remediation": f.remediation,
                "affected_components": f.affected_components,
                "references": f.references,
                "cve_ids": f.cve_ids,
            })

        remediations = []
        for r in report.remediation_plan:
            remediations.append({
                "priority": r.priority,
                "finding": r.finding,
                "action": r.action,
                "effort": r.effort,
                "impact": r.impact,
            })

        return {
            "id": report.id,
            "campaign_id": report.campaign_id,
            "target": report.target,
            "objective": report.objective,
            "executive_summary": report.executive_summary,
            "risk_summary": {
                "critical": report.risk_summary.critical_count,
                "high": report.risk_summary.high_count,
                "medium": report.risk_summary.medium_count,
                "low": report.risk_summary.low_count,
                "info": report.risk_summary.info_count,
                "overall": report.risk_summary.overall_risk,
            },
            "findings": findings,
            "attack_narrative": report.attack_narrative,
            "remediation_plan": remediations,
            "generated_at": report.generated_at,
        }


# ---------------------------------------------------------------------------
# 便捷函数
# ---------------------------------------------------------------------------

def generate_markdown_report(target: str, objective: str, findings: list,
                             generated_at: str = "") -> str:
    """快速生成 Markdown 报告（便捷入口）"""
    report = PentestReport(
        target=target,
        objective=objective,
        generated_at=generated_at,
    )

    # 风险统计
    rs = RiskSummary()
    for f in findings:
        sev = getattr(f, "severity", "info")
        if isinstance(sev, str):
            if sev == "critical":
                rs.critical_count += 1
            elif sev == "high":
                rs.high_count += 1
            elif sev == "medium":
                rs.medium_count += 1
            elif sev == "low":
                rs.low_count += 1
            else:
                rs.info_count += 1

    report.risk_summary = rs
    report.findings = [ReportFinding(
        title=getattr(f, "title", "Unknown Finding"),
        severity=sev if isinstance(sev, str) else str(sev),
        cvss_score=getattr(f, "cvss_score", 0.0),
        description=getattr(f, "description", ""),
        evidence=getattr(f, "evidence", []),
        remediation=getattr(f, "remediation", ""),
        affected_components=getattr(f, "affected_components", []),
    ) for f in findings]

    gen = ReportGenerator()
    return gen.generate(report, ReportFormat.MARKDOWN)


def generate_sarif_report(target: str, objective: str, findings: list,
                          report_id: str = "") -> str:
    """快速生成 SARIF 报告（便捷入口）"""
    report = PentestReport(
        id=report_id,
        target=target,
        objective=objective,
    )

    rs = RiskSummary()
    for f in findings:
        sev = getattr(f, "severity", "info")
        if isinstance(sev, str):
            if sev == "critical":
                rs.critical_count += 1
            elif sev == "high":
                rs.high_count += 1
            elif sev == "medium":
                rs.medium_count += 1
            elif sev == "low":
                rs.low_count += 1
            else:
                rs.info_count += 1

    report.risk_summary = rs
    report.findings = [ReportFinding(
        id=getattr(f, "id", ""),
        title=getattr(f, "title", "Unknown Finding"),
        severity=sev if isinstance(sev, str) else str(sev),
        cvss_score=getattr(f, "cvss_score", 0.0),
        description=getattr(f, "description", ""),
    ) for f in findings]

    gen = ReportGenerator()
    return gen.generate(report, ReportFormat.SARIF)
