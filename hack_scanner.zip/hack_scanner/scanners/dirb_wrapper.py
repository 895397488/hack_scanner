#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dirb Wrapper — Dirb CLI wrapper，轻量级目录/文件爆破（Perl 实现，无 Go 依赖）。

Dirb 是老牌目录爆破工具，字典内嵌（The Common Wordlist），
适合 gobuster/ffuf 不可用时的备用引擎，或快速基线探测。

集成方式：需要安装 Dirb
  - Windows: 手动下载 https://github.com/Kalilinux/dirb 或 cygwin 环境
  - Linux:   apt install dirb
本模块只负责 CLI 调用和结果解析。config.json → tools.dirb_path 可指定路径。

Usage:
    from scanners.dirb_wrapper import dirb_scan
    result = dirb_scan("https://example.com")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('dirb_scanner')


def _find_dirb() -> Optional[str]:
    """查找 dirb 可执行文件：先 config.json → tools.dirb_path，再 PATH"""
    # 1) config.json tools.dirb_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("dirb_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["dirb", "dirb.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_dirb_output(output: str, base_url: str = "") -> list:
    """解析 dirb 文本输出。

    Dirb 关键行格式:
      http://target/admin (Code: 200, Size: 4567)
      !!! Found Rejected Entry (Code: 200)
      !!! Interesting (Code: 200)
    """
    findings = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue

        # URL 行: http://target/path (Code: 200, Size: 1234)
        m = re.match(r'(https?://\S+)\s+\(Code:\s*(\d+),\s*Size:\s*(\d+)\)', line)
        if m:
            url, code, size = m.group(1), m.group(2), int(m.group(3))
            code_i = int(code)
            if code_i in (200, 301, 302, 403, 500):
                severity = "medium" if code_i in (200, 403) else "info"
            else:
                severity = "info"
            findings.append({
                "url": url,
                "status": code,
                "size": size,
                "severity": severity,
                "interesting": False,
            })
            continue

        # !!! 行: 标记的有趣发现
        if line.startswith("!!!"):
            findings.append({
                "url": base_url,
                "status": "",
                "size": 0,
                "severity": "medium",
                "interesting": True,
                "description": line,
            })

    return findings


def dirb_scan(
    target: str,
    wordlist: str = "",
    threads: int = 10,
    max_time: int = 300,
) -> dict:
    """运行 Dirb 目录爆破。

    Args:
        target: 目标 URL（如 https://example.com/）
        wordlist: 字典文件路径（不传用 dirb 内嵌字典）
        threads: 并发线程数
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "findings": [...], "findings_count": N, "interesting_count": N, "error": ""}
    """
    dirb_path = _find_dirb()
    if not dirb_path:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "findings_count": 0,
            "error": "Dirb 未找到，请安装: apt install dirb (Linux) 或手动下载 https://github.com/Kalilinux/dirb",
        }

    cmd = [
        dirb_path,
        target.rstrip("/"),
        "-N",              # 跳过 404（减少噪声）
        "-t", str(threads),
        "-r",              # 不跟随重定向
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd.extend(["-w", wordlist])

    logger.info(f"dirb scan: {' '.join(cmd[:5])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""
        findings = _parse_dirb_output(output, target)

        interesting = [f for f in findings if f.get("interesting")]
        return {
            "ok": True,
            "target": target,
            "findings": findings[:500],
            "findings_count": len(findings),
            "interesting_count": len(interesting),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target": target, "findings": [], "findings_count": 0, "error": "dirb 超时"}
