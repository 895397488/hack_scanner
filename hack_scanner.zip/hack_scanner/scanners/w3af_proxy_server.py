#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
w3af 代理服务器 (Proxy Daemon) — 借鉴 w3af (w3af.org) proxy + localproxy daemon.

本地 MITM 代理服务器，用于拦截和修改 HTTP/HTTPS 请求，模拟中间人攻击场景：
- HTTP 明文代理 (监听本地端口转发所有请求)
- HTTPS SSL stripping (降级为明文)
- 请求篡改/注入测试载荷
- 自动化响应修改检测防御机制

Usage:
    from scanners.w3af_proxy_server import ProxyDaemon, start_proxy

    proxy = ProxyDaemon(host='127.0.0.1', port=8080)
    # Start in background thread
    proxy.start()

    # Configure interceptor for request/response modification
    proxy.add_interceptor(MyInterceptor())
    proxy.start_listening()
"""

import logging
import socket
import threading
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


logger = logging.getLogger('w3af_proxy_server')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class ProxyRule:
    """A rule for intercepting/modifying proxy traffic."""
    name: str = ''
    pattern: str = ''           # regex pattern to match on URL or headers
    action: str = 'modify'      # 'log', 'modify', 'block', 'redirect'
    modify_header: Dict[str, str] = field(default_factory=dict)  # headers to add/override
    block_response: Optional[Tuple[int, str]] = None  # (status_code, body) for blocking
    redirect_to: Optional[str] = None  # URL to redirect to

    def matches(self, url: str, headers: Dict[str, str]) -> bool:
        """Check if this rule applies to the given request."""
        if not self.pattern:
            return True
        text = f'{url}\n{chr(10).join(f"{k}: {v}" for k, v in headers.items())}'
        return bool(re.search(self.pattern, text, re.I))


@dataclass
class InterceptedRequest:
    """An intercepted HTTP request with modification capability."""
    method: str = 'GET'
    url: str = ''
    headers: Dict[str, str] = field(default_factory=dict)
    body: str = ''
    original_headers: Dict[str, str] = field(default_factory=dict)

    def add_header(self, name: str, value: str):
        self.headers[name] = value
        self.original_headers[name] = self.original_headers.get(name, '')

    def remove_header(self, name: str):
        if name in self.headers:
            del self.headers[name]


# ====================================================================
# HTTP Proxy Daemon (w3af daemons/proxy.py adaptation)
# ====================================================================

class ProxyDaemon:
    """Local HTTP proxy daemon for MITM scanning (w3af proxy pattern)."""

    def __init__(self, host: str = '127.0.0.1', port: int = 8080):
        self.host = host
        self.port = port
        self._server_socket: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._rules: List[ProxyRule] = []
        self._request_interceptors: List[Callable[[InterceptedRequest], InterceptedRequest]] = []
        self._response_interceptors: List[Callable[[Dict[str, Any]], Dict[str, Any]]] = []
        self._log_buffer: List[Dict[str, Any]] = []

    @property
    def is_running(self) -> bool:
        return self._running

    def start(self):
        """Start the proxy daemon in a background thread."""
        if self._running:
            return
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.bind((self.host, self.port))
        self._server_socket.listen(50)
        self._running = True

        def _accept_loop():
            while self._running:
                try:
                    conn, addr = self._server_socket.accept()
                    threading.Thread(target=self._handle_client, args=(conn, addr), daemon=True).start()
                except OSError:
                    break

        self._thread = threading.Thread(target=_accept_loop, daemon=True)
        self._thread.start()
        logger.info('Proxy daemon started on %s:%d', self.host, self.port)

    def stop(self):
        """Stop the proxy daemon."""
        self._running = False
        if self._server_socket:
            try:
                self._server_socket.close()
            except OSError:
                pass
        logger.info('Proxy daemon stopped')

    def add_rule(self, rule: ProxyRule):
        """Add an interception rule."""
        self._rules.append(rule)

    def add_request_interceptor(self, interceptor: Callable[[InterceptedRequest], InterceptedRequest]):
        """Add a request interceptor (for modifying outgoing requests)."""
        self._request_interceptors.append(interceptor)

    def add_response_interceptor(self, interceptor: Callable[[Dict[str, Any]], Dict[str, Any]]):
        """Add a response interceptor (for modifying incoming responses)."""
        self._response_interceptors.append(interceptor)

    @property
    def request_log(self) -> List[Dict[str, Any]]:
        return list(self._log_buffer)

    # ------------------------------------------------------------------
    # Internal client handler
    # ------------------------------------------------------------------

    def _handle_client(self, conn: socket.socket, addr: Tuple[str, int]):
        """Handle a single proxy connection from a client."""
        try:
            data = conn.recv(65536)
            if not data:
                return

            request_text = data.decode('utf-8', errors='replace')
            parsed = self._parse_http_request(request_text)
            if not parsed:
                conn.close()
                return

            method, url, headers, body = parsed

            # Build intercepted request
            intercept_req = InterceptedRequest(method=method, url=url, headers=headers, body=body)

            # Apply request rules
            for rule in self._rules:
                if rule.matches(url, headers):
                    if rule.action == 'block':
                        status, resp_body = rule.block_response or (403, 'Blocked')
                        response = f'HTTP/1.1 {status} Forbidden\r\nContent-Length: {len(resp_body)}\r\nConnection: close\r\n\r\n{resp_body}'
                        conn.sendall(response.encode())
                        conn.close()
                        return
                    elif rule.action == 'modify':
                        for h_name, h_val in rule.modify_header.items():
                            intercept_req.add_header(h_name, h_val)

            # Apply request interceptors
            for interceptor in self._request_interceptors:
                intercept_req = interceptor(intercept_req)

            # Log the intercepted request
            self._log_buffer.append({
                'type': 'request',
                'addr': addr[0],
                'method': intercept_req.method,
                'url': intercept_req.url,
                'timestamp': None,  # would use datetime.now() in production
            })

            # Forward to destination (simple HTTP proxy)
            self._forward_request(conn, intercept_req)

        except Exception as exc:
            logger.debug('Proxy client handling error for %s: %s', addr, exc)
        finally:
            try:
                conn.close()
            except OSError:
                pass

    def _forward_request(self, conn: socket.socket, req: InterceptedRequest):
        """Forward an intercepted request to the real destination."""
        # Parse URL to get host and port
        import re as _re  # type: ignore
        match = _re.match(r'https?://([^:/]+)(?::(\d+))?(/.*)?', req.url)
        if not match:
            return

        target_host = match.group(1)
        target_port = int(match.group(2)) if match.group(2) else (443 if req.url.startswith('https') else 80)
        target_path = match.group(3) or '/'

        # Build modified HTTP request
        request_lines = [f'{req.method} {target_path} HTTP/1.1']
        request_lines.append(f'Host: {target_host}')
        for h_name, h_val in req.headers.items():
            request_lines.append(f'{h_name}: {h_val}')
        if 'Content-Length' not in req.headers:
            request_lines.append(f'Content-Length: {len(req.body)}')

        request_text = '\r\n'.join(request_lines) + '\r\n\r\n' + req.body

        target_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            target_conn.settimeout(30)
            if target_port == 443:
                import ssl  # type: ignore
                ctx = ssl.create_default_context()
                target_conn = ctx.wrap_socket(target_conn, server_hostname=target_host)
            target_conn.connect((target_host, target_port))
            target_conn.sendall(request_text.encode())

            response = b''
            while True:
                chunk = target_conn.recv(65536)
                if not chunk:
                    break
                response += chunk
                if len(response) > 10_000_000:  # limit response size
                    break

            # Log response headers
            resp_text = response.decode('utf-8', errors='replace')
            status_line = resp_text.split('\r\n')[0] if '\r\n' in resp_text else ''
            self._log_buffer.append({
                'type': 'response',
                'addr': f'{target_host}:{target_port}',
                'status': status_line,
                'timestamp': None,
            })

        except Exception as exc:
            logger.error('Forward error to %s:%d: %s', target_host, target_port, exc)
        finally:
            try:
                target_conn.close()
            except OSError:
                pass

    @staticmethod
    def _parse_http_request(raw: str) -> Optional[Tuple[str, str, Dict[str, str], str]]:
        """Parse raw HTTP request text into (method, url, headers, body)."""
        try:
            parts = raw.split('\r\n\r\n', 1)
            header_section = parts[0]
            body = parts[1] if len(parts) > 1 else ''

            lines = header_section.split('\r\n')
            request_line = lines[0]
            parts_req = request_line.split(' ')
            if len(parts_req) < 2:
                return None

            method = parts_req[0]
            url = ' '.join(parts_req[1:])
            headers: Dict[str, str] = {}
            for line in lines[1:]:
                if ':' in line:
                    h_name, h_val = line.split(':', 1)
                    headers[h_name.strip()] = h_val.strip()

            return method, url, headers, body
        except Exception:
            return None


# ====================================================================
# Shortcut function (w3af proxy start pattern)
# ====================================================================

def start_proxy(host: str = '127.0.0.1', port: int = 8080) -> ProxyDaemon:
    """Start a proxy daemon and return the instance."""
    proxy = ProxyDaemon(host, port)
    proxy.start()
    return proxy


# ====================================================================
# Utility: common proxy rules for vulnerability testing (w3af evasion_plugin patterns)
# ====================================================================

def get_w3af_style_proxy_rules() -> List[ProxyRule]:
    """Return a set of standard w3af-style proxy interception rules."""
    rules = [
        # Strip Referer header to test hotlink protection bypass
        ProxyRule(name='strip_referer', pattern=r'.*', action='modify',
                  modify_header={'Referer': ''}),
        # Add custom User-Agent for fingerprinting tests
        ProxyRule(name='custom_ua', pattern=r'.*', action='modify',
                  modify_header={'User-Agent': 'Mozilla/5.0 (compatible; HackScanner/w3af-Proxy)'}),
        # Detect if server changes behavior based on Accept header
        ProxyRule(name='accept_test', pattern=r'.*', action='modify',
                  modify_header={'Accept': 'text/plain,application/xhtml+xml'}),
        # Test X-Forwarded-For manipulation
        ProxyRule(name='xforwarded', pattern=r'.*', action='modify',
                  modify_header={
                      'X-Forwarded-For': '127.0.0.1, 0.0.0.1',
                      'X-Real-IP': '127.0.0.1',
                  }),
    ]
    return rules
