#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Multi-Format Report Export Engine -- export scan results to PDF, CSV, Markdown, RST, DVCS.

Mirrors Acunetix /exports API endpoint that supports multiple output formats.

Supported formats:
  - JSON (preserved from original hack_scanner)
  - HTML (preserved from original hack_scanner)
  - PDF   -- via weasyprint or wkhtmltopdf fallback
  - CSV   -- machine-readable tabular export
  - Markdown (.md) -- human-readable + version-control friendly
  - RST   -- reStructuredText for documentation pipelines
  - DVCS  -- XML-based custom format (DevCraft Vulnerability Scan)

Usage:
    from scanners.export_engine import ExportEngine, generate_all_formats

    engine = ExportEngine(scan_results, target_url="https://example.com")
    engine.export('pdf', output_dir='./reports')
    engine.export('csv', output_dir='./reports')
    # or batch export all formats:
    paths = generate_all_formats(scan_results, "https://example.com", outdir="./reports")
"""

import csv
import io
import json
import logging
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger('export_engine')


# ====================================================================
# Scan result schema (common format consumed by all exporters)
# ====================================================================

@staticmethod
def normalize_scan_results(scan_results: Any, target_url: str = '') -> Dict[str, Any]:
    """Normalize various scan result formats into a common structure."""
    if isinstance(scan_results, dict):
        return {
            'scan_timestamp': datetime.now().isoformat(),
            'target_url': target_url or scan_results.get('summary', {}).get('url_target', scan_results.get('url', '')),
            'summary': scan_results.get('summary', {
                'risk_level': scan_results.get('risk_level', 'UNKNOWN'),
                'risk_score': scan_results.get('risk_score', 0),
                'severity_breakdown': scan_results.get('severity_breakdown', {}),
            }),
            'url_findings': [],
            'file_findings': [],
        }

    # If it's already the normalized format, return as-is
    if 'scan_timestamp' in scan_results and 'summary' in scan_results:
        return scan_results

    # Minimal normalization for raw finding lists
    return {
        'scan_timestamp': datetime.now().isoformat(),
        'target_url': target_url or '',
        'summary': {'risk_level': 'UNKNOWN', 'risk_score': 0, 'severity_breakdown': {}},
        'url_findings': scan_results if isinstance(scan_results, list) else [],
        'file_findings': [],
    }


# ====================================================================
# CSV Exporter
# ====================================================================

class CSVEporter:
    """Export findings to CSV format."""

    # Columns for vulnerability findings
    COLUMNS = [
        'severity', 'category', 'title', 'url', 'parameter', 'payload',
        'description', 'cwe', 'cvss_v2', 'cvss_v3', 'remediation', 'confidence',
    ]

    @staticmethod
    def export(findings: List[Dict[str, Any]], target: str = '', filepath: str = '') -> str:
        """Export findings to CSV and return the file path."""
        if not filepath:
            ts = datetime.now().strftime('%Y%m%d_%H%M%S')
            domain = urlparse(target).hostname or 'scan'
            filepath = f'{domain}_vulnerabilities_{ts}.csv'

        with open(filepath, 'w', newline='', encoding='utf-8-sig') as fh:
            writer = csv.DictWriter(fh, fieldnames=CSVEporter.COLUMNS, extrasaction='ignore')
            writer.writeheader()
            for f in findings:
                row = {col: f.get(col, '') for col in CSVEporter.COLUMNS}
                # Normalize severity to uppercase
                if row['severity']:
                    row['severity'] = str(row['severity']).upper()
                writer.writerow(row)

        logger.info('CSV export: %d findings -> %s', len(findings), filepath)
        return filepath


# ====================================================================
# Markdown Exporter
# ====================================================================

class MarkdownExporter:
    """Export findings to Markdown format with SRC report style."""

    SEVERITY_ICONS = {
        'CRITICAL': '\U0001f534', 'HIGH': '\U0001f7e4',
        'MEDIUM': '\U0001f7e1', 'LOW': '\U0001f7e2', 'INFO': '',
    }

    @staticmethod
    def export(results: Dict[str, Any], filepath: str = '') -> str:
        """Export full scan results to Markdown."""
        if not filepath:
            ts = datetime.now().strftime('%Y%m%d_%H%M%S')
            domain = urlparse(results.get('target_url', 'scan')).hostname or 'scan'
            filepath = f'{domain}_report_{ts}.md'

        summary = results.get('summary', {})
        lines: List[str] = []

        # Header
        risk = summary.get('risk_level', 'UNKNOWN')
        lines.append(f'# Security Scan Report -- {results.get("target_url", "N/A")}')
        lines.append('')
        lines.append(f'**Scan Date:** {results.get("scan_timestamp", datetime.now().isoformat())}')
        lines.append(f'**Risk Level:** {risk} (Score: {summary.get("risk_score", 0)})')
        lines.append('')

        # Summary table
        breakdown = summary.get('severity_breakdown', {})
        lines.append('## Summary')
        lines.append('')
        lines.append('| Severity | Count |')
        lines.append('|----------|-------|')
        for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']:
            count = breakdown.get(sev, 0) or 0
            icon = CSVEporter.COLUMNS  # placeholder -- severity icons will render in viewer
            lines.append(f'| {sev} | {count} |')
        lines.append('')

        # URL findings
        url_findings = results.get('url_findings', [])
        if url_findings:
            lines.append('## URL Findings')
            lines.append('')
            for i, finding in enumerate(url_findings, 1):
                sev = str(finding.get('severity', 'INFO')).upper()
                icon = MarkdownExporter.SEVERITY_ICONS.get(sev, '')
                title = finding.get('title', finding.get('name', f'Finding #{i}'))
                url = finding.get('url', finding.get('endpoint', ''))
                cat = finding.get('category', finding.get('type', 'unknown'))
                cwe = finding.get('cwe', '')
                cvss = finding.get('cvss_v3', finding.get('cvss_v2', ''))
                desc = finding.get('description', finding.get('detail', ''))
                remediation = finding.get('remediation', finding.get('fix', ''))

                lines.append(f'### {icon} #{i}: {title}')
                lines.append('')
                lines.append(f'- **URL:** `{url}`')
                lines.append(f'- **Category:** {cat}')
                if cwe:
                    lines.append(f'- **CWE:** CWE-{cwe}')
                if cvss:
                    lines.append(f'- **CVSS:** {cvss}')
                lines.append('')
                if desc:
                    lines.append(f'**Description:**\n\n{desc}\n\n')
                if remediation:
                    lines.append(f'**Remediation:**\n\n{remediation}\n\n')
                lines.append('---')
                lines.append('')

        # File findings
        file_findings = results.get('file_findings', [])
        if file_findings:
            lines.append('## File Findings')
            lines.append('')
            for i, finding in enumerate(file_findings, 1):
                sev = str(finding.get('severity', 'INFO')).upper()
                icon = MarkdownExporter.SEVERITY_ICONS.get(sev, '')
                path = finding.get('file', finding.get('path', ''))
                title = finding.get('title', finding.get('name', f'File Finding #{i}'))
                lines.append(f'### {icon} #{i}: {title}')
                lines.append('')
                lines.append(f'- **File:** `{path}`')
                desc = finding.get('description', finding.get('detail', ''))
                if desc:
                    lines.append(f'\n{desc}\n')
                remediation = finding.get('remediation', finding.get('fix', ''))
                if remediation:
                    lines.append(f'**Fix:** {remediation}\n')
                lines.append('---')
                lines.append('')

        content = '\n'.join(lines)
        with open(filepath, 'w', encoding='utf-8') as fh:
            fh.write(content)

        logger.info('Markdown export: %s (%d findings)', filepath, len(url_findings) + len(file_findings))
        return filepath


# ====================================================================
# RST Exporter
# ====================================================================

class RstExporter:
    """Export scan results to reStructuredText format."""

    @staticmethod
    def export(results: Dict[str, Any], filepath: str = '') -> str:
        """Export full scan results to RST."""
        if not filepath:
            ts = datetime.now().strftime('%Y%m%d_%H%M%S')
            domain = urlparse(results.get('target_url', 'scan')).hostname or 'scan'
            filepath = f'{domain}_report_{ts}.rst'

        summary = results.get('summary', {})
        lines: List[str] = []

        url_target = results.get('target_url', 'N/A')
        lines.append(f'Security Scan Report')
        lines.append('=' * len(url_target))
        lines.append('')
        lines.append(f'Target: {url_target}')
        lines.append(f'Scan Date: {results.get("scan_timestamp", datetime.now().isoformat())}')
        lines.append(f'Risk Level: {summary.get("risk_level", "UNKNOWN")}')
        lines.append('')

        # Summary section
        lines.append('Summary')
        lines.append('-------')
        lines.append('')
        breakdown = summary.get('severity_breakdown', {})
        for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']:
            count = breakdown.get(sev, 0) or 0
            lines.append(f'- **{sev}**: {count}')
        lines.append('')

        # URL findings
        url_findings = results.get('url_findings', [])
        if url_findings:
            lines.append('URL Findings')
            lines.append('------------')
            lines.append('')
            for i, finding in enumerate(url_findings, 1):
                sev = str(finding.get('severity', 'INFO')).upper()
                title = finding.get('title', finding.get('name', f'Finding #{i}'))
                url = finding.get('url', finding.get('endpoint', ''))
                desc = finding.get('description', finding.get('detail', ''))
                remediation = finding.get('remediation', finding.get('fix', ''))

                lines.append(f'{i}. {title}')
                lines.append(f'   Severity: {sev}')
                lines.append(f'   URL: ``{url}``')
                if desc:
                    lines.append(f'   Description:')
                    lines.append(f'     {desc}')
                if remediation:
                    lines.append(f'   Remediation: {remediation}')
                lines.append('')

        content = '\n'.join(lines)
        with open(filepath, 'w', encoding='utf-8') as fh:
            fh.write(content)

        logger.info('RST export: %s (%d findings)', filepath, len(url_findings))
        return filepath


# ====================================================================
# DVCS Exporter (XML-based DevCraft Vulnerability Scan format)
# ====================================================================

class DvcsExporter:
    """Export to XML-based DevCraft Vulnerability Scan format (compatible with Acunetix DVCS)."""

    SEVERITY_XML = {
        'CRITICAL': '4', 'HIGH': '3', 'MEDIUM': '2', 'LOW': '1', 'INFO': '0',
    }

    @staticmethod
    def export(results: Dict[str, Any], filepath: str = '') -> str:
        """Export to DVCS XML format."""
        if not filepath:
            ts = datetime.now().strftime('%Y%m%d_%H%M%S')
            domain = urlparse(results.get('target_url', 'scan')).hostname or 'scan'
            filepath = f'{domain}_report_{ts}.dvcx'

        summary = results.get('summary', {})
        findings = results.get('url_findings', []) + results.get('file_findings', [])

        xml_lines: List[str] = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<ScanResults>',
            f'  <Target>{results.get("target_url", "")}</Target>',
            f'  <ScanDate>{results.get("scan_timestamp", datetime.now().isoformat())}</ScanDate>',
            f'  <RiskScore>{summary.get("risk_score", 0)}</RiskScore>',
            f'  <RiskLevel>{summary.get("risk_level", "UNKNOWN")}</RiskLevel>',
            '<Findings>',
        ]

        for finding in findings:
            sev = str(finding.get('severity', 'INFO')).upper()
            xml_sev = DvcsExporter.SEVERITY_XML.get(sev, '0')
            title = finding.get('title', finding.get('name', ''))
            url = finding.get('url', finding.get('endpoint', ''))
            cat = finding.get('category', finding.get('type', 'unknown'))
            desc = finding.get('description', '')
            remediation = finding.get('remediation', '')
            cwe = finding.get('cwe', '')

            xml_lines.append(f'    <Finding>')
            xml_lines.append(f'      <Severity>{xml_sev}</Severity>')
            xml_lines.append(f'      <Title>{self._xml_escape(title)}</Title>')
            xml_lines.append(f'      <URL>{self._xml_escape(url)}</URL>')
            xml_lines.append(f'      <Category>{cat}</Category>')
            if cwe:
                xml_lines.append(f'      <CWE>CWE-{cwe}</CWE>')
            xml_lines.append(f'      <Description>{self._xml_escape(desc)}</Description>')
            if remediation:
                xml_lines.append(f'      <Remediation>{self._xml_escape(remediation)}</Remediation>')
            xml_lines.append(f'    </Finding>')

        xml_lines.extend(['  </Findings>', '</ScanResults>'])

        content = '\n'.join(xml_lines)
        with open(filepath, 'w', encoding='utf-8') as fh:
            fh.write(content)

        logger.info('DVCS XML export: %s (%d findings)', filepath, len(findings))
        return filepath

    @staticmethod
    def _xml_escape(text: str) -> str:
        return (text or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


# ====================================================================
# PDF Exporter
# ====================================================================

class PdfExporter:
    """Export findings to PDF format."""

    @staticmethod
    def export(results: Dict[str, Any], filepath: str = '', engine: str = 'weasyprint') -> str:
        """Export scan results to PDF. Falls back to Markdown if no PDF engine available."""
        # Try weasyprint first
        if engine == 'weasyprint':
            try:
                from weasyprint import HTML
                md_content = MarkdownExporter.export(results)
                html_content = MarkdownExporter._md_to_html(md_content)
                pdf_bytes = HTML(string=html_content).write_pdf()
                with open(filepath, 'wb') as fh:
                    fh.write(pdf_bytes)
                logger.info('PDF export (weasyprint): %s', filepath)
                return filepath
            except ImportError:
                logger.warning('weasyprint not available, skipping PDF export')

        # Try wkhtmltopdf fallback
        if engine == 'wkhtmltopdf' or engine == 'auto':
            try:
                import subprocess
                md_content = MarkdownExporter.export(results)
                html_content = MarkdownExporter._md_to_html(md_content)
                proc = subprocess.run(
                    ['wkhtmltopdf', '-', filepath], input=html_content.encode('utf-8'),
                    capture_output=True, timeout=30)
                if proc.returncode == 0:
                    logger.info('PDF export (wkhtmltopdf): %s', filepath)
                    return filepath
            except (FileNotFoundError, subprocess.TimeoutExpired):
                logger.warning('wkhtmltopdf not available')

        # Final fallback: save as Markdown instead
        if not filepath.endswith('.pdf'):
            md_path = filepath.rsplit('.', 1)[0] + '.md' if filepath else None
            return MarkdownExporter.export(results, md_path)

        logger.warning('No PDF engine available -- save as Markdown instead')
        md_path = filepath.rsplit('.', 1)[0] + '.md'
        return MarkdownExporter.export(results, md_path)

    @staticmethod
    def _md_to_html(md_content: str) -> str:
        """Minimal markdown-to-HTML conversion (for PDF generation)."""
        html = '<html><head><meta charset="utf-8"><style>'
        html += 'body{font-family:Arial,sans-serif;margin:40px;line-height:1.6}'
        html += 'h1{color:#c0392b;border-bottom:2px solid #c0392b;padding-bottom:8px}'
        html += 'h2{color:#2980b6;margin-top:24px}'
        html += 'h3{color:#27ae60}'
        html += 'table{border-collapse:collapse;width:100%;margin:12px 0}'
        html += 'th,td{border:1px solid #ddd;padding:8px;text-align:left}'
        html += 'th{background-color:#f2f2f2}'
        html += '.critical{color:#c0392b;font-weight:bold}'
        html += '.high{color:#e67e22;font-weight:bold}'
        html += '.medium{color:#f39c12}'
        html += '.low{color:#27ae60}'
        html += 'pre{background:#f4f4f4;padding:12px;overflow-x:auto}'
        html += '</style></head><body>'

        # Convert markdown headings
        for line in md_content.split('\n'):
            if line.startswith('### '):
                html += f'<h3>{line[4:]}</h3>\n'
            elif line.startswith('## '):
                html += f'<h2>{line[3:]}</h2>\n'
            elif line.startswith('# '):
                html += f'<h1>{line[2:]}</h1>\n'
            elif line.startswith('- **'):
                # List items with bold labels
                html += f'<p><strong>{line.lstrip("- ")}</strong></p>\n'
            elif line.startswith('- '):
                html += f'<li>{line[2:]}</li>\n'
            elif line == '---':
                html += '<hr>'
            elif line and not line.startswith('|'):
                html += f'<p>{line}</p>\n'

        html += '</body></html>'
        return html


# ====================================================================
# Main Export Engine
# ====================================================================

class ExportEngine:
    """Unified export engine that delegates to format-specific exporters."""

    EXPORTERS = {
        'json': None,      # built-in (just use json.dumps)
        'html': None,      # preserved from original hack_scanner ReportGenerator
        'csv': CSVEporter.export,
        'markdown': MarkdownExporter.export,
        'rst': RstExporter.export,
        'dvcs': DvcsExporter.export,
        'pdf': PdfExporter.export,
    }

    def __init__(self, scan_results: Any, target_url: str = '', output_dir: str = './reports'):
        self.results = normalize_scan_results(scan_results, target_url)
        self.target_url = target_url or self.results.get('target_url', '')
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def export(self, format_: str, filepath: str = '', engine: str = 'auto') -> str:
        """Export results in the specified format."""
        exporter = self.EXPORTERS.get(format_.lower())
        if not filepath:
            ext_map = {
                'json': '.json', 'csv': '.csv', 'markdown': '.md',
                'rst': '.rst', 'dvcs': '.dvcx', 'pdf': '.pdf',
            }
            ext = ext_map.get(format_.lower(), f'.{format_.lower()}')
            ts = datetime.now().strftime('%Y%m%d_%H%M%S')
            domain = urlparse(self.target_url).hostname or 'scan'
            filepath = os.path.join(self.output_dir, f'{domain}_{ts}{ext}')

        if format_.lower() == 'json':
            with open(filepath, 'w', encoding='utf-8') as fh:
                json.dump(self.results, fh, indent=2, ensure_ascii=False)
            logger.info('JSON export: %s', filepath)
            return filepath

        if format_.lower() == 'html':
            html_content = self._generate_html_report()
            with open(filepath, 'w', encoding='utf-8') as fh:
                fh.write(html_content)
            logger.info('HTML export: %s', filepath)
            return filepath

        if exporter is None:
            raise ValueError(f'Unknown format: {format_}. Available: {list(self.EXPORTERS.keys())}')

        return exporter(self.results, filepath, engine)

    def export_all(self) -> Dict[str, str]:
        """Export to all supported formats. Returns {format: filepath}."""
        paths: Dict[str, str] = {}
        for fmt in self.EXPORTERS:
            try:
                path = self.export(fmt)
                paths[fmt] = path
            except Exception as exc:
                logger.warning('Export %s failed: %s', fmt, exc)
        return paths

    def _generate_html_report(self) -> str:
        """Generate HTML report (preserved from original hack_scanner)."""
        summary = self.results.get('summary', {})
        breakdown = summary.get('severity_breakdown', {})
        findings = self.results.get('url_findings', []) + self.results.get('file_findings', [])

        html = f'''<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Hack Scanner Report</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
.container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
.summary {{ display: flex; gap: 20px; margin: 20px 0; }}
.card {{ flex: 1; padding: 20px; border-radius: 6px; text-align: center; color: white; }}
.critical {{ background: #c0392b; }} .high {{ background: #e67e22; }}
.medium {{ background: #f39c12; }} .low {{ background: #27ae60; }}
.finding {{ border-left: 4px solid #ddd; padding: 12px 16px; margin: 12px 0; background: #fafafa; }}
.critical-border {{ border-color: #c0392b !important; }}
.high-border {{ border-color: #e67e22 !important; }}
.medium-border {{ border-color: #f39c12 !important; }}
a {{ color: #2980b6; text-decoration: none; }}
</style></head><body>
<div class="container">
<h1>Hack Scanner Report -- {self.target_url}</h1>
<p><strong>Scan Date:</strong> {self.results.get("scan_timestamp", "N/A")}</p>
<div class="summary">
<div class="card critical"><h2>{breakdown.get("CRITICAL", 0)}</h3><p>Critical</p></div>
<div class="card high"><h2>{breakdown.get("HIGH", 0)}</h2><p>High</p></div>
<div class="card medium"><h2>{breakdown.get("MEDIUM", 0)}</h2><p>Medium</p></div>
<div class="card low"><h2>{breakdown.get("LOW", 0)}</h2><p>Low</p></div>
</div>
<h2>Vulnerability Details ({len(findings)} findings)</h2>'''

        for i, finding in enumerate(findings, 1):
            sev = str(finding.get('severity', 'INFO')).upper()
            border_cls = f'{sev.lower()}-border' if sev in ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW') else ''
            title = finding.get('title', finding.get('name', f'Finding #{i}'))
            url = finding.get('url', finding.get('endpoint', finding.get('file', '')))
            desc = finding.get('description', finding.get('detail', ''))
            remediation = finding.get('remediation', finding.get('fix', ''))

            html += f'''<div class="finding {border_cls}">
<h3>#{i}: {title}</h3>
<p><strong>Severity:</strong> {sev} | <strong>URL:</strong> <a href="{url}">{url[:80]}</a></p>
{f'<p>{desc}</p>' if desc else ''}
{f'<p><strong>Fix:</strong> {remediation}</p>' if remediation else ''}
</div>'''

        html += '</div></body></html>'
        return html


# ====================================================================
# Convenience function
# ====================================================================

def generate_all_formats(scan_results: Any, target_url: str = '', outdir: str = './reports') -> Dict[str, str]:
    """Quick export to all supported formats."""
    engine = ExportEngine(scan_results, target_url, outdir)
    return engine.export_all()
