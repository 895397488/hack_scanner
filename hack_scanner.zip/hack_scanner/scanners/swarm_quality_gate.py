# from-source-of: Pentest-Swarm-AI (internal/agent/report/qualitygate/)
# 质量门控模块 — 评估报告提交质量
"""
质量门控系统。
核心算法源自 Pentest-Swarm-AI 的 qualitygate/gate.go：

- 三项评分：clarity / impact / reproducibility（各 0-10）
- overall_score = min(clarity, impact, reproducibility) — 木桶效应
- 阈值 Threshold = 6.0，低于此值阻止提交并给出修改建议
"""

import json
import re
from dataclasses import dataclass, field
from typing import List, Optional


# ---------------------------------------------------------------------------
# 质量门控评分 (对应 qualitygate/Report)
# ---------------------------------------------------------------------------

# 通过阈值（满分 10）
THRESHOLD = 6.0


@dataclass
class QualityGateReport:
    """质量门控评估结果"""
    overall_score: float = 0.0          # 总分 (0-10)
    clarity_score: float = 0.0           # 清晰度评分 (0-10)
    impact_score: float = 0.0            # 影响描述评分 (0-10)
    reproducibility_score: float = 0.0   # 可复现性评分 (0-10)
    suggestions: List[str] = field(default_factory=list)      # 修改建议
    blocking_issue: str = ""             # 阻止提交的原因（如果有）

    def pass_check(self) -> bool:
        """判断是否通过质量门控"""
        return self.overall_score >= THRESHOLD


# ---------------------------------------------------------------------------
# 静态质量检查器 (纯规则引擎，不依赖 LLM)
# 对应 gate.go Grade() 的确定性评估部分
# ---------------------------------------------------------------------------

class QualityGate:
    """
    质量门控系统 — 在提交前评估报告草稿的质量。

    评分维度：
        clarity (0-10):       报告是否清晰、结构完整、格式正确
        impact (0-10):        影响描述是否具体、有业务相关性
        reproducibility (0-10): 步骤是否足够详细，能让其他人复现
    """

    # 最小要求配置
    MIN_FINDINGS = 1          # 最少发现数量
    SEVERITY_COVERAGE_MIN = 2 # 最少覆盖的严重等级数
    MIN_EVIDENCE_ITEMS = 0    # 最少证据项数（可配置）
    MAX_DESCRIPTION_LENGTH = 5   # 描述最小字符数（每条发现）

    def __init__(self, min_findings: int = None, severity_coverage: int = None,
                 evidence_items_required: int = None):
        if min_findings is not None:
            self.MIN_FINDINGS = min_findings
        if severity_coverage is not None:
            self.SEVERITY_COVERAGE_MIN = severity_coverage
        if evidence_items_required is not None:
            self.MIN_EVIDENCE_ITEMS = evidence_items_required

    def pass_check(self, report_content: str) -> bool:
        """
        判断报告是否通过质量门控。

        Args:
            report_content: 报告的文本内容或 JSON 数据

        Returns:
            True 如果通过，False 否则
        """
        result = self.evaluate(report_content)
        return result.pass_check()

    def evaluate(self, report_content: str) -> QualityGateReport:
        """
        全面评估报告质量并返回评分报告。

        Args:
            report_content: 报告的文本内容或 JSON 数据

        Returns:
            QualityGateReport 对象
        """
        # 尝试解析为 JSON（结构化报告）
        is_json = False
        parsed_report = None
        try:
            parsed_report = _json.loads(report_content)
            is_json = True
        except (AttributeError, json.JSONDecodeError):
            pass

        if not report_content.strip():
            return QualityGateReport(
                overall_score=0.0,
                clarity_score=0.0,
                impact_score=0.0,
                reproducibility_score=0.0,
                suggestions=["报告内容为空，无法评估"],
            )

        # 三项评分
        clarity = self._evaluate_clarity(report_content, parsed_report)
        impact = self._evaluate_impact(report_content, parsed_report)
        reproducibility = self._evaluate_reproducibility(report_content, parsed_report)

        # overall = min(三项) — 木桶效应
        overall = min(clarity, impact, reproducibility)

        suggestions = []

        # 基于评分生成建议
        if clarity < THRESHOLD:
            suggestions.extend(self._clarity_suggestions(report_content))
        if impact < THRESHOLD:
            suggestions.append("影响描述需要更具体 — 说明对业务的影响，而不仅仅是技术细节")
        if reproducibility < THRESHOLD:
            suggestions.extend(self._reproducibility_suggestions(report_content))

        # 最小发现数量检查
        finding_count = self._count_findings(parsed_report, report_content)
        if finding_count < self.MIN_FINDINGS:
            suggestions.append(f"报告至少需要 {self.MIN_FINDINGS} 条发现（当前：{finding_count}）")

        blocking = ""
        if overall < THRESHOLD:
            blocking = (
                f"质量评分 {overall:.1f}/10 低于阈值 {THRESHOLD}.0。"
                f"请根据以下建议修改后再提交："
            )

        return QualityGateReport(
            overall_score=overall,
            clarity_score=clarity,
            impact_score=impact,
            reproducibility_score=reproducibility,
            suggestions=suggestions,
            blocking_issue=blocking,
        )

    # ---------------------------------------------------------------
    # 清晰度评估 (clarity)
    # -----------------------------------------------------------

    def _evaluate_clarity(self, content: str, parsed: Optional[dict] = None) -> float:
        """评估报告清晰度和结构完整性 (0-10)"""
        score = 5.0  # 基础分

        text = content if not parsed else json.dumps(parsed) if parsed else content

        # 是否有标题/段落结构
        heading_count = len(re.findall(r'^#{1,3}\s', text, re.MULTILINE))
        if heading_count >= 3:
            score += 1.0
        elif heading_count >= 1:
            score += 0.5

        # 是否有代码块/证据片段
        code_blocks = len(re.findall(r'```', text))
        if code_blocks >= 4:  # 至少两个代码块（开始+结束）
            score += 1.0

        # 是否有表格
        if '|' in text and '\n' in text:
            score += 0.5

        # 发现条目数量（JSON 格式检查）
        findings_count = self._count_findings(parsed, text)
        if findings_count >= 3:
            score += 1.0
        elif findings_count >= 1:
            score += 0.5

        # 长度不足
        word_count = len(text.split())
        if word_count < 50:
            score -= 2.0
        elif word_count < 100:
            score -= 1.0

        return max(0.0, min(10.0, score))

    # ---------------------------------------------------------------
    # 影响描述评估 (impact)
    # ---------------------------------------------------------------------------

    def _evaluate_impact(self, content: str, parsed: Optional[dict] = None) -> float:
        """评估影响描述质量 (0-10)"""
        score = 5.0
        text = content if not parsed else json.dumps(parsed) if parsed else content

        # 检查是否包含影响相关关键词
        impact_keywords = [
            'business', 'data breach', 'unauthorized', 'access',
            'compromise', 'leak', 'steal', 'execute', 'deploy',
            'privilege', 'authentication', 'authorization', 'denial',
            'service', 'customer', 'financial', 'reputation',
            'confidential', 'integrity', 'availability',
        ]
        keyword_count = sum(1 for kw in impact_keywords if kw.lower() in text.lower())
        score += min(3.0, keyword_count * 0.5)

        # 检查是否有具体场景描述（"如果攻击者..."句式）
        scenario_patterns = [
            r'if.*attacker', r'an?\s*\w+\s+can\s+', r'allows?\s+(?:to\s+)?\w+',
            r'results?\s+in\s+', r'could?\s+(?:lead\s+to|enable)',
        ]
        scenario_count = 0
        for pattern in scenario_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            scenario_count += len(matches)
        score += min(2.0, scenario_count * 0.5)

        # CVSS/严重性提及
        if 'cvss' in text.lower() or 'severity' in text.lower():
            score += 0.5
        if re.search(r'\b\d+\.\d+\b', text):
            score += 0.5

        return max(0.0, min(10.0, score))

    # ---------------------------------------------------------------
    # 可复现性评估 (reproducibility)
    # ---------------------------------------------------------------------------

    def _evaluate_reproducibility(self, content: str, parsed: Optional[dict] = None) -> float:
        """评估报告可复现性 (0-10)"""
        score = 5.0
        text = content if not parsed else json.dumps(parsed) if parsed else content

        # 检查重现步骤（有序列表）
        step_patterns = [
            r'^\d+\.\s+',           # 数字序号
            r'step\s*\d+',          # "step N" 句式
            r'first,?\s*',          # "First," / "首先"
            r'then|after|next',     # 时序词
        ]
        step_count = 0
        for pattern in step_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
            step_count += len(matches)
        score += min(2.0, step_count * 0.4)

        # 检查是否有 HTTP 请求（最有力的证据）
        http_patterns = [
            r'HTTP/\d',           # HTTP/1.1
            r'GET\s+/',           # GET /path
            r'POST\s+/',          # POST /path
            r'Content-Type:',     # 请求头
            r'Authorization:',    # Authorization 头
            r'curl\s+',           # curl 命令
            r'\{.*"method".*\}',  # JSON 中的 method 字段
        ]
        http_count = sum(1 for pat in http_patterns if re.search(pat, text, re.IGNORECASE))
        score += min(3.0, http_count * 0.5)

        # 检查是否有具体的 URL/参数
        url_matches = re.findall(r'https?://\S+', text)
        if len(url_matches) >= 2:
            score += 1.0
        elif len(url_matches) >= 1:
            score += 0.5

        # 检查是否有请求体/参数示例
        param_patterns = [
            r'name=.*?value=',    # name=value
            r'"[^"]+"\s*:\s*"',   # JSON key-value
            r'--data\b',          # curl --data
            r'-d\s+',             # -d 短参数
        ]
        param_count = sum(1 for pat in param_patterns if re.search(pat, text))
        score += min(2.0, param_count * 0.5)

        return max(0.0, min(10.0, score))

    # ---------------------------------------------------------------
    # 建议生成
    # ---------------------------------------------------------------

    def _clarity_suggestions(self, content: str) -> List[str]:
        """生成清晰度改进建议"""
        suggestions = []

        if not re.search(r'^#{1,3}\s', content, re.MULTILINE):
            suggestions.append("报告缺少标题结构，请添加清晰的标题层级（## 标题）")

        text_lower = content.lower()
        if 'evidence' not in text_lower and 'proof' not in text_lower:
            suggestions.append("报告中未包含证据部分，请添加验证证据")

        word_count = len(content.split())
        if word_count < 100:
            suggestions.append(f"报告过短（{word_count} 词），需要更详细的描述")

        return suggestions

    def _reproducibility_suggestions(self, content: str) -> List[str]:
        """生成可复现性改进建议"""
        suggestions = []

        http_count = len(re.findall(r'HTTP/\d|GET\s+/|POST\s+/', content, re.IGNORECASE))
        if http_count == 0:
            suggestions.append("请添加具体的 HTTP 请求示例（包含方法、URL、headers、body）")

        curl_count = len(re.findall(r'curl\s+', content))
        if curl_count == 0:
            suggestions.append("建议添加 curl 复现命令，方便其他人直接执行验证")

        step_count = len(re.findall(r'^\d+\.\s+', content, re.MULTILINE))
        if step_count < 2:
            suggestions.append("重现步骤太少（仅 " + str(step_count) + " 步），请提供更详细的分步说明")

        return suggestions

    # ---------------------------------------------------------------
    # 辅助方法
    # ---------------------------------------------------------------------------

    def _count_findings(self, parsed_report: Optional[dict], text: str) -> int:
        """统计报告中的发现数量"""
        if parsed_report and isinstance(parsed_report, dict):
            findings = parsed_report.get('findings', [])
            if isinstance(findings, list):
                return len(findings)

        # 从文本中数发现条目（### 标题或 finding 关键字）
        count = len(re.findall(r'### \d+\.?\s+\[', text))
        if count == 0:
            count = len(re.findall(r'\bfinding\s+\d+', text, re.IGNORECASE))
        return count


# ---------------------------------------------------------------------------
# 快速质量检查入口
# ---------------------------------------------------------------------------

def quick_gate_check(report_content: str, threshold: float = THRESHOLD) -> dict:
    """
    快速质量门控检查（便捷函数）。

    Args:
        report_content: 报告文本内容
        threshold:      通过阈值

    Returns:
        {
            "passed": bool,
            "scores": {"clarity", "impact", "reproducibility", "overall"},
            "suggestions": list,
        }
    """
    gate = QualityGate()
    result = gate.evaluate(report_content)

    return {
        "passed": result.pass_check(),
        "scores": {
            "clarity": round(result.clarity_score, 1),
            "impact": round(result.impact_score, 1),
            "reproducibility": round(result.reproducibility_score, 1),
            "overall": round(result.overall_score, 1),
        },
        "suggestions": result.suggestions,
        "blocking_issue": result.blocking_issue,
    }
