#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Playbooks — 扫描剧本系统与信息素配置
============================================
from-source-of: Pentest-Swarm-AI

将 Pentest-Swarm-AI playbooks/*.yaml 全部转换为 Python 原生字典结构，
并提供 playbook 执行引擎与 pheromones.yaml 信息素浓度配置。

覆盖的 playbook（7 个）：
  - owasp-top10
  - bug-bounty
  - api-security
  - ci-cd-security
  - ctf-solver
  - external-asm
  - internal-network

Pheromones 信息素浓度配置来自 config/pheromones.yaml。
"""

import os
import sys
import json
import time
import hashlib
import subprocess
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger('swarm_playbooks')

# ===================================================================
# 内置 Playbook 配置（从 YAML 转换而来）
# ===================================================================


def _build_builtin_playbooks() -> Dict[str, Dict]:
    """构建所有内置 playbook 字典。

    每一本 playbook 的键：
      name        — 剧本名称
      description — 描述（与原文一致）
      author      — {"name": ..., "github": ...}
      version     — 版本号
      tags        — 标签列表
      variables   — 变量定义 {name: {type, required, default?, description?}}
      phases      — 阶段列表 [{name, tools[{name, options}], post_analysis}]
    """

    return {
        # ------------------------------------------------------------------
        # 1. OWASP Top 10 Assessment
        # ------------------------------------------------------------------
        'owasp-top10': {
            'name': 'OWASP Top 10 全面评估',
            'description': 'Comprehensive assessment targeting the OWASP Top 10 vulnerability categories',
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['web', 'owasp', 'comprehensive'],
            'variables': {
                'target_domain': {
                    'type': 'string',
                    'required': True,
                },
            },
            'phases': [
                {
                    'name': 'reconnaissance',
                    'tools': [
                        {'name': 'subfinder', 'options': {'recursive': True}},
                        {'name': 'httpx', 'options': {'follow_redirects': True}},
                        {'name': 'katana', 'options': {'depth': 3}},
                        {'name': 'gau'},
                    ],
                    'post_analysis': (
                        "Map the full attack surface. Identify all web endpoints, parameters,\n"
                        "forms, API routes, and authentication mechanisms. Note technology\n"
                        "stack for targeted vulnerability checks."
                    ),
                },
                {
                    'name': 'injection_testing',
                    'tools': [
                        {
                            'name': 'nuclei',
                            'options': {
                                'templates': ['cves/', 'vulnerabilities/sqli/', 'vulnerabilities/xss/'],
                                'severity': ['critical', 'high'],
                            },
                        },
                    ],
                    'post_analysis': (
                        "Focus on A03:2021 Injection. Test all input points for SQL injection,\n"
                        "XSS, command injection, LDAP injection, and template injection.\n"
                        "Verify findings and assess exploitability."
                    ),
                },
                {
                    'name': 'auth_and_access',
                    'tools': [
                        {
                            'name': 'nuclei',
                            'options': {
                                'templates': ['vulnerabilities/auth-bypass/', 'misconfiguration/'],
                            },
                        },
                    ],
                    'post_analysis': (
                        "Cover A01:2021 Broken Access Control, A02:2021 Cryptographic Failures,\n"
                        "and A07:2021 Identification and Authentication Failures.\n"
                        "Check for IDOR, privilege escalation, weak passwords, exposed tokens."
                    ),
                },
                {
                    'name': 'misconfig_and_components',
                    'tools': [
                        {
                            'name': 'nuclei',
                            'options': {
                                'templates': ['exposures/', 'technologies/', 'misconfiguration/'],
                            },
                        },
                    ],
                    'post_analysis': (
                        "Cover A05:2021 Security Misconfiguration and A06:2021 Vulnerable\n"
                        "and Outdated Components. Check for default credentials, unnecessary\n"
                        "features, outdated libraries, exposed admin panels."
                    ),
                },
            ],
        },

        # ------------------------------------------------------------------
        # 2. Bug Bounty Swarm
        # ------------------------------------------------------------------
        'bug-bounty': {
            'name': 'Bug Bounty 狩猎群',
            'description': (
                "End-to-end swarm for bug-bounty programs. Starts from a root domain,\n"
                "enumerates subdomains and endpoints, hunts for low-hanging vulns, then\n"
                "escalates on candidate SQLi/SSRF/IDOR with targeted active tests.\n"
                "Scope-enforced at every step; dedup-ready output for HackerOne / Bugcrowd."
            ),
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['bug-bounty', 'external', 'web', 'recon', 'active'],
            'variables': {
                'target_domain': {
                    'type': 'string',
                    'required': True,
                },
                'program_slug': {
                    'type': 'string',
                    'required': False,
                    'description': 'HackerOne/Bugcrowd program slug, used for dedup and scope hints',
                },
            },
            'phases': [
                {
                    'name': 'subdomain_enumeration',
                    'tools': [
                        {'name': 'subfinder', 'options': {'recursive': True, 'timeout': 300}},
                        {'name': 'dnsx'},
                    ],
                    'post_analysis': (
                        "Catalogue every subdomain, flag wildcards and takeover candidates\n"
                        "(dangling CNAMEs pointing to third-party services)."
                    ),
                },
                {
                    'name': 'web_surface',
                    'tools': [
                        {'name': 'httpx', 'options': {'follow_redirects': True, 'threads': 50}},
                        {'name': 'katana', 'options': {'depth': 3, 'js_crawl': True}},
                        {'name': 'gau'},
                    ],
                    'post_analysis': (
                        "Map alive hosts, status codes, tech stacks, and deep-link endpoints.\n"
                        "Prioritise endpoints with query parameters, admin-ish paths, and\n"
                        "old/deprecated versions."
                    ),
                },
                {
                    'name': 'vulnerability_scan',
                    'tools': [
                        {
                            'name': 'nuclei',
                            'options': {
                                'severity': ['critical', 'high', 'medium'],
                                'templates': ['http/', 'cves/', 'exposures/'],
                            },
                        },
                    ],
                    'post_analysis': (
                        "Report-ready findings only — filter duplicates against known\n"
                        "program issues when program_slug is provided."
                    ),
                },
                {
                    'name': 'active_escalation',
                    'tools': [
                        {
                            'name': 'sqlmap',
                            'options': {'risk': 1, 'level': 2, 'batch': True},
                        },
                    ],
                    'post_analysis': (
                        "Confirm exploitability for high-pheromone findings. Cleanup\n"
                        "commands must be registered for anything that mutates state."
                    ),
                },
            ],
        },

        # ------------------------------------------------------------------
        # 3. API Security Assessment
        # ------------------------------------------------------------------
        'api-security': {
            'name': 'API 安全评估',
            'description': 'Focused assessment of REST/GraphQL APIs for common vulnerabilities',
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['api', 'rest', 'graphql'],
            'variables': {
                'target_domain': {
                    'type': 'string',
                    'required': True,
                },
                'api_base_path': {
                    'type': 'string',
                    'default': '/api',
                },
            },
            'phases': [
                {
                    'name': 'api_discovery',
                    'tools': [
                        {'name': 'katana', 'options': {'depth': 5, 'js_crawl': True}},
                        {'name': 'gau'},
                        {'name': 'httpx', 'options': {'follow_redirects': True}},
                    ],
                    'post_analysis': (
                        "Discover all API endpoints. Look for OpenAPI/Swagger docs,\n"
                        "GraphQL introspection endpoints, versioned APIs, and undocumented\n"
                        "endpoints in JavaScript bundles."
                    ),
                },
                {
                    'name': 'api_vulnerabilities',
                    'tools': [
                        {
                            'name': 'nuclei',
                            'options': {
                                'templates': ['http/vulnerabilities/', 'http/misconfiguration/'],
                                'severity': ['critical', 'high', 'medium'],
                            },
                        },
                    ],
                    'post_analysis': (
                        "Test for: broken authentication, BOLA/IDOR, mass assignment,\n"
                        "rate limiting bypass, JWT vulnerabilities, SSRF via API parameters,\n"
                        "GraphQL injection, and excessive data exposure."
                    ),
                },
            ],
        },

        # ------------------------------------------------------------------
        # 4. CI/CD Security Swarm
        # ------------------------------------------------------------------
        'ci-cd-security': {
            'name': 'CI/CD 安全群',
            'description': (
                "Source-side security swarm for GitHub Actions (or any CI). Runs inside\n"
                "the repo: secret scanning (gitleaks + trufflehog), SAST (semgrep), and\n"
                "dependency audit. Emits SARIF so findings flow into GitHub Code Scanning.\n"
                "Zero network traffic to production."
            ),
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['ci', 'cd', 'sast', 'secrets', 'sbom', 'sarif'],
            'variables': {
                'repo_path': {
                    'type': 'string',
                    'default': '.',
                },
                'fail_on_severity': {
                    'type': 'string',
                    'default': 'high',
                    'description': 'Minimum severity that fails the job (critical | high | medium | low)',
                },
            },
            'phases': [
                {
                    'name': 'secret_scan',
                    'tools': [
                        {'name': 'gitleaks', 'options': {'config': '.gitleaks.toml', 'report_format': 'sarif'}},
                        {'name': 'trufflehog', 'options': {'only_verified': True}},
                    ],
                    'post_analysis': (
                        "Any VERIFIED secret = pipeline fail regardless of fail_on_severity.\n"
                        "Historical commits are in scope — a rotated secret is still a\n"
                        "disclosure event until someone confirms rotation on the vendor side."
                    ),
                },
                {
                    'name': 'static_analysis',
                    'tools': [
                        {
                            'name': 'semgrep',
                            'options': {
                                'config': ['p/owasp-top-ten', 'p/cwe-top-25', 'p/security-audit'],
                                'sarif': True,
                            },
                        },
                    ],
                    'post_analysis': (
                        "Focus on auth/authz paths, crypto misuse, deserialisation, SSRF\n"
                        "sinks, and template injection. Autofix suggestions go to the PR\n"
                        "review comments."
                    ),
                },
                {
                    'name': 'dependency_audit',
                    'tools': [
                        {
                            'name': 'semgrep',
                            'options': {'config': ['p/supply-chain']},
                        },
                    ],
                    'post_analysis': (
                        "Transitive dependency CVEs — pin major known-bad versions, flag\n"
                        "unpinned floating tags in Dockerfiles and base images."
                    ),
                },
                {
                    'name': 'emit_sarif',
                    'tools': [],
                    'post_analysis': (
                        "Merge all tool SARIFs into a single artefact. Job exit code\n"
                        "follows fail_on_severity."
                    ),
                },
            ],
        },

        # ------------------------------------------------------------------
        # 5. CTF Solver Swarm
        # ------------------------------------------------------------------
        'ctf-solver': {
            'name': 'CTF 解题群',
            'description': (
                "Autonomous CTF machine solver for retired HackTheBox / TryHackMe boxes\n"
                "(or your own lab targets). The swarm iterates: enumerate -> exploit ->\n"
                "stabilize foothold -> escalate -> collect flag. Retired boxes only by\n"
                "default — live competition boxes require explicit opt-in."
            ),
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['ctf', 'htb', 'thm', 'benchmark', 'autonomous'],
            'variables': {
                'target_ip': {
                    'type': 'string',
                    'required': True,
                },
                'difficulty': {
                    'type': 'string',
                    'default': 'easy',
                    'description': 'easy | medium | hard — affects agent-hour budget',
                },
                'flag_path_hints': {
                    'type': 'string',
                    'default': '/root/root.txt,/home/*/user.txt',
                    'description': 'Comma-separated list of likely flag paths',
                },
            },
            'phases': [
                {
                    'name': 'enumeration',
                    'tools': [
                        {'name': 'nmap', 'options': {'scan_type': '-sV', 'top_ports': 1000, 'timing': '-T4'}},
                        {'name': 'httpx'},
                        {'name': 'katana', 'options': {'depth': 3}},
                        {'name': 'nuclei', 'options': {'severity': ['critical', 'high', 'medium']}},
                    ],
                    'post_analysis': (
                        "Pull the enum into one coherent picture. CTF boxes have a\n"
                        "single intended path 95% of the time — find the weirdest thing\n"
                        "and follow it."
                    ),
                },
                {
                    'name': 'initial_foothold',
                    'tools': [
                        {'name': 'sqlmap', 'options': {'risk': 2, 'level': 3}},
                    ],
                    'post_analysis': (
                        "Try the obvious first (default creds, exposed config files,\n"
                        "git leaks, known CVEs for the exact banner version).\n"
                        "Stabilize any shell into a proper TTY before privesc."
                    ),
                },
                {
                    'name': 'privilege_escalation',
                    'tools': [
                        {'name': 'nuclei', 'options': {'templates': ['network/enumeration/']}},
                    ],
                    'post_analysis': (
                        "SUID binaries, sudo -l, cron jobs, writable PATH entries,\n"
                        "capabilities, kernel exploits (last resort — crashes boxes)."
                    ),
                },
                {
                    'name': 'flag_collection',
                    'tools': [],
                    'post_analysis': (
                        "Read flags from flag_path_hints. Submit via box's grader\n"
                        "if credentials available; otherwise surface to report."
                    ),
                },
            ],
        },

        # ------------------------------------------------------------------
        # 6. External Attack Surface Monitoring
        # ------------------------------------------------------------------
        'external-asm': {
            'name': '外部攻击面监控',
            'description': (
                "Scheduled external ASM playbook. Discovers and fingerprints the perimeter\n"
                "(subdomains, ports, services, tech), takes screenshots, and diffs against\n"
                "the previous run so the swarm only surfaces NEW exposures. Meant for cron."
            ),
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['asm', 'external', 'monitoring', 'passive-first'],
            'variables': {
                'target_domain': {
                    'type': 'string',
                    'required': True,
                },
                'diff_against_run': {
                    'type': 'string',
                    'required': False,
                    'description': 'Campaign ID of a prior run to diff against (default = most recent)',
                },
            },
            'phases': [
                {
                    'name': 'passive_osint',
                    'tools': [
                        {'name': 'subfinder', 'options': {'recursive': True}},
                        {'name': 'gau'},
                    ],
                    'post_analysis': (
                        "Passive collection first — no packets to target infrastructure.\n"
                        "Pull historical URLs and passive DNS to enrich the picture."
                    ),
                },
                {
                    'name': 'resolution',
                    'tools': [
                        {'name': 'dnsx'},
                    ],
                    'post_analysis': (
                        "Resolve every candidate to A/AAAA/CNAME. Flag cloud-ranges\n"
                        "(AWS, GCP, Azure) separately — owner attribution changes by range."
                    ),
                },
                {
                    'name': 'port_and_service',
                    'tools': [
                        {'name': 'naabu', 'options': {'ports': 'top-1000', 'rate': 1000}},
                        {'name': 'nmap', 'options': {'scan_type': '-sV', 'top_ports': 1000, 'timing': '-T4'}},
                    ],
                    'post_analysis': (
                        "Concentrate on unexpected-open ports on production assets.\n"
                        "Cross-reference product + version against CVE database for\n"
                        "known-bad versions."
                    ),
                },
                {
                    'name': 'web_fingerprint',
                    'tools': [
                        {'name': 'httpx', 'options': {'follow_redirects': True, 'threads': 100}},
                    ],
                    'post_analysis': (
                        "Note tech stack, TLS certs (flag expiring < 30d), HTTP headers\n"
                        "(missing HSTS, CSP, X-Frame-Options)."
                    ),
                },
                {
                    'name': 'quick_vuln_sweep',
                    'tools': [
                        {
                            'name': 'nuclei',
                            'options': {
                                'severity': ['critical', 'high'],
                                'templates': ['cves/', 'exposures/', 'misconfiguration/'],
                            },
                        },
                    ],
                    'post_analysis': (
                        "Critical + high severity only — ASM noise at lower severities\n"
                        "swamps the signal. Everything else becomes follow-up campaigns."
                    ),
                },
            ],
        },

        # ------------------------------------------------------------------
        # 7. Internal Network Swarm
        # ------------------------------------------------------------------
        'internal-network': {
            'name': '内部网络群',
            'description': (
                "Authorized internal network pentest playbook. Requires a signed scope\n"
                "file (see scope_file variable) — the runner refuses to execute without\n"
                "one. Walks CIDR -> service enumeration -> optional Metasploit post-ex\n"
                "with cleanup always registered."
            ),
            'author': {'name': 'Armur AI', 'github': 'Armur-Ai'},
            'version': '1.0.0',
            'tags': ['internal', 'network', 'authorized-only', 'high-risk'],
            'variables': {
                'scope_file': {
                    'type': 'string',
                    'required': True,
                    'description': 'Path to the signed scope YAML authorising this engagement',
                },
                'cidr': {
                    'type': 'string',
                    'required': True,
                },
                'post_exploitation': {
                    'type': 'string',
                    'default': 'read-only',
                    'description': 'read-only | active (active requires separate written approval)',
                },
            },
            'phases': [
                {
                    'name': 'network_sweep',
                    'tools': [
                        {
                            'name': 'nmap',
                            'options': {
                                'scan_type': '-sS',
                                'top_ports': 1000,
                                'timing': '-T3',  # quieter on internal networks
                            },
                        },
                    ],
                    'post_analysis': (
                        "Identify live hosts and top-1000 open ports. Skip printer/IoT\n"
                        "ranges unless explicitly in scope — they crash easily."
                    ),
                },
                {
                    'name': 'service_enum',
                    'tools': [
                        {
                            'name': 'nmap',
                            'options': {
                                'scan_type': '-sV',
                                'top_ports': 100,
                                'timing': '-T3',
                            },
                        },
                    ],
                    'post_analysis': (
                        "Version-fingerprint the services that matter: SSH, SMB, RDP,\n"
                        "WinRM, LDAP, SNMP, databases. Credential hygiene findings\n"
                        "are critical-severity by default on internal nets."
                    ),
                },
                {
                    'name': 'post_exploitation',
                    'tools': [
                        {
                            'name': 'metasploit',
                            'options': {
                                'post_exploitation': '{{ post_exploitation }}',
                            },
                        },
                    ],
                    'post_analysis': (
                        "Read-only: enumerate users, shares, group memberships.\n"
                        "Active: require per-action written approval (the playbook runner\n"
                        "will halt and prompt). All sessions must be killed and artefacts\n"
                        "removed on exit — cleanup registry enforces this."
                    ),
                },
            ],
        },
    }


# 全局只读的单例字典（延迟初始化）
_builtin_playbooks: Optional[Dict[str, Dict]] = None


def _ensure_builtin() -> Dict[str, Dict]:
    global _builtin_playbooks
    if _builtin_playbooks is None:
        _builtin_playbooks = _build_builtin_playbooks()
    return _builtin_playbooks


# ===================================================================
# Playbook 查询 API
# ===================================================================


def get_all_playbooks() -> Dict[str, Dict]:
    """返回所有内置 playbook 字典的浅拷贝。"""
    return dict(_ensure_builtin())


def get_playbook(name: str) -> Optional[Dict]:
    """按名称获取 playbook 配置。

    Args:
        name: playbook 标识符，如 'owasp-top10', 'bug-bounty'。

    Returns:
        完整 playbook 字典；不存在则返回 None。
    """
    return _ensure_builtin().get(name)


def list_playbooks() -> List[Dict]:
    """列出所有可用的 playbook 摘要。"""
    result = []
    for key, pb in _ensure_builtin().items():
        result.append({
            'id': key,
            'name': pb['name'],
            'description': pb['description'],
            'version': pb.get('version'),
            'tags': pb.get('tags', []),
            'phase_count': len(pb.get('phases', [])),
            'variable_count': len(pb.get('variables', {})),
        })
    return result


# ===================================================================
# Pheromones 信息素浓度配置（来自 config/pheromones.yaml）
# ===================================================================

PHEROMONES_CONFIG: Dict[str, Any] = {
    # ------------------------------------------------------------------
    # 文档说明
    # ------------------------------------------------------------------
    '_comment': (
        "每类发现类型的信息素初始浓度和衰减半衰期。\n"
    ) + '\n' + (
        "tuning intent:\n"
        "  - base 越高 => 下游代理越早对该发现类型采取行动\n"
        "  - half_life_sec 越短 => 过期发现更快消退；适合高波动状态（会话、令牌、探测结果）\n"
        "  - half_life_sec 越长 => 保持持久发现的热点（开放端口、技术栈、CVE 匹配跨数小时战役持久化）\n"
        "  --exploration-bias CLI 标志在写入时乘以基础权重：低=>0.7, 中=>1.0(默认), 高=>1.3\n"
    ),

    'types': {
        'TARGET_REGISTERED': {'base': 1.0,   'half_life_sec': 86400},   # 24h：根目标在整个战役期间保持热度
        'SUBDOMAIN':            {'base': 0.7,  'half_life_sec': 7200},    # 2h：新发现子域名有趣但非紧急
        'PORT_OPEN':            {'base': 0.8,  'half_life_sec': 3600},    # 1h
        'SERVICE':              {'base': 0.8,  'half_life_sec': 3600},    # 1h
        'HTTP_ENDPOINT':        {'base': 0.6,  'half_life_sec': 7200},
        # katana启发式标记的"有趣"端点在写入时获得额外加成
        'HTTP_ENDPOINT_INTERESTING': {'base': 0.9, 'half_life_sec': 7200},
        'TECHNOLOGY':           {'base': 0.5,  'half_life_sec': 7200},    # 技术指纹持久但低紧急度
        'CVE_MATCH':            {'base': 1.0,  'half_life_sec': 10800},   # 3h 默认（由 ClassifierAgent 通过严重程度覆盖）
        'MISCONFIGURATION':     {'base': 0.6,  'half_life_sec': 3600},
        'EXPLOIT_CHAIN':        {'base': 0.9,  'half_life_sec': 3600},
        'EXPLOIT_RESULT':       {'base': 0.7,  'half_life_sec': 1800},    # exploit agent 成功时提升到 1.0
        'SESSION':              {'base': 0.8,  'half_life_sec': 900},     # 15m — 会话令牌快速过期
        'AGENT_ERROR':          {'base': 0.3,  'half_life_sec': 600},     # 10m — 短暂浮现后消退
        'CAMPAIGN_COMPLETE':    {'base': 1.0,  'half_life_sec': 300},
        'NUCLEI_TEMPLATE_DRAFT': {'base': 0.8, 'half_life_sec': 43200},   # 12h — 草稿在审阅者工作日内保持有意义
    },

    'default': {
        'base': 0.5,
        'half_life_sec': 3600,
    },
}


def get_pheromone(type_name: str) -> Dict[str, float]:
    """获取指定发现类型的信息素配置。

    Args:
        type_name: 发现类型名称，如 'PORT_OPEN', 'CVE_MATCH'。

    Returns:
        {"base": float, "half_life_sec": float} 字典。
    """
    types = PHEROMONES_CONFIG.get('types', {})
    if type_name in types:
        return dict(types[type_name])
    # 回退到默认值
    return dict(PHEROMONES_CONFIG.get('default', {}))


def get_all_pheromone_types() -> List[str]:
    """返回所有已定义的信息素类型名称列表。"""
    return list(PHEROMONES_CONFIG.get('types', {}).keys())


# ===================================================================
# ScanResult 数据类（轻量级，纯 Python）
# ===================================================================


@dataclass
class SwarmScanResult:
    """单次扫描操作的结果。

    属性：
        phase_name:       阶段名称
        tool_name:        执行的工具名
        target:           目标地址
        status:           'success' | 'failed' | 'skipped' | 'timeout'
        raw_output:       原始输出文本（截断至8192字符）
        findings:         检测到的漏洞发现列表
        duration_sec:     耗时（秒）
    """
    phase_name: str = ''
    tool_name: str = ''
    target: str = ''
    status: str = 'success'
    raw_output: str = ''
    findings: List[Dict[str, Any]] = field(default_factory=list)
    duration_sec: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'phase': self.phase_name,
            'tool': self.tool_name,
            'target': self.target,
            'status': self.status,
            'raw_output': self.raw_output[:8192],
            'findings_count': len(self.findings),
            'duration_sec': self.duration_sec,
            'timestamp': self.timestamp,
        }


# ===================================================================
# 执行引擎 — execute_playbook
# ===================================================================


class PlaybookExecutor:
    """Playbook 批量执行器。

    按顺序遍历 playbook 的每个阶段，对每个工具生成命令行并执行。
    默认以"模拟"模式运行（打印命令而不实际执行），可通过 simulate=False 切换。
    """

    def __init__(self, simulate: bool = True):
        self.simulate = simulate
        self.results: List[SwarmScanResult] = []
        self.phase_order: List[str] = []

    def execute_playbook(self, playbook_config: Dict, targets: List[str],
                         variables: Optional[Dict] = None) -> List[SwarmScanResult]:
        """执行一个 playbook 对多个目标的扫描。

        Args:
            playbook_config: get_playbook() 返回的配置字典。
            targets:         目标列表（域名或IP）。
            variables:       覆盖 playbook 变量的可选字典。

        Returns:
            SwarmScanResult 列表，每个元素代表一次工具执行。
        """
        self.results = []
        self.phase_order = []

        # 1) 验证必需变量
        required_vars = playbook_config.get('variables', {})
        for var_name, var_def in required_vars.items():
            if var_def.get('required') and variables is not None:
                if var_name not in variables or not variables[var_name]:
                    raise ValueError(
                        f"Playbook '{playbook_config.get('name', '')}' requires variable '{var_name}'"
                    )

        # 2) 按阶段执行
        for phase in playbook_config.get('phases', []):
            self.phase_order.append(phase['name'])
            phase_name = phase['name']

            # 3) 对每个目标执行该阶段的工具
            for target in targets:
                for tool in phase.get('tools', []):
                    tool_name = tool['name']
                    tool_options = tool.get('options', {})
                    result = self._execute_tool(phase_name, tool_name, tool_options, target)
                    self.results.append(result)

        return self.results

    def _execute_tool(self, phase_name: str, tool_name: str, options: Dict,
                      target: str) -> SwarmScanResult:
        """执行单个工具调用。

        Args:
            phase_name: 阶段名称
            tool_name:  工具名（如 nuclei, nmap）
            options:    工具选项字典
            target:     目标地址

        Returns:
            SwarmScanResult 对象。
        """
        start = time.time()
        cmd_args = self._build_command(tool_name, options, target)
        findings = []

        if self.simulate:
            # 模拟模式：生成合理的假发现而非实际执行
            logger.debug(f"[SIMULATE] {phase_name}/{tool_name} -> {target}")
            raw_output = self._simulate_output(tool_name, target)
            findings = self._infer_findings(tool_name, raw_output)
        else:
            # 真实模式：调用子进程执行命令
            try:
                proc = subprocess.run(
                    cmd_args,
                    capture_output=True, text=True, timeout=300,
                )
                raw_output = proc.stdout + proc.stderr
                result_code = proc.returncode
                status = 'success' if result_code == 0 else ('failed' if result_code > 128 else 'timeout')
            except subprocess.TimeoutExpired:
                raw_output = '[TIMEOUT after 300s]'
                status = 'timeout'
            except FileNotFoundError:
                raw_output = f'[TOOL_NOT_FOUND] {tool_name} is not installed on this system.'
                status = 'skipped'

        duration = time.time() - start
        return SwarmScanResult(
            phase_name=phase_name,
            tool_name=tool_name,
            target=target,
            status=status if not self.simulate else 'success',
            raw_output=raw_output[:8192],
            findings=findings,
            duration_sec=duration,
        )

    def _build_command(self, tool_name: str, options: Dict, target: str) -> List[str]:
        """根据工具名和选项构建命令行参数列表。"""
        cmd = [tool_name]

        # 不同工具的选项映射
        if tool_name == 'nmap':
            scan_type = options.get('scan_type', '-sS')
            top_ports = options.get('top_ports', 1000)
            timing = options.get('timing', '-T4')
            cmd.extend([scan_type, f'-p {top_ports}', timing, target])

        elif tool_name == 'nuclei':
            templates = options.get('templates', [])
            severity = options.get('severity', [])
            for t in templates:
                cmd.extend(['-t', t])
            if severity:
                cmd.extend(['-s', ','.join(severity)])
            cmd.extend(['-u', target])

        elif tool_name == 'httpx':
            follow = options.get('follow_redirects')
            threads = options.get('threads', 50)
            if follow:
                cmd.append('-follow-redirects')
            cmd.extend(['-threads', str(threads), '-u', target])

        elif tool_name == 'katana':
            depth = options.get('depth', 3)
            js_crawl = options.get('js_crawl')
            cmd.extend(['-u', target, '-depth', str(depth)])
            if js_crawl:
                cmd.append('-flags')

        elif tool_name == 'subfinder':
            recursive = options.get('recursive')
            timeout = options.get('timeout')
            if recursive:
                cmd.append('-r')
            if timeout:
                cmd.extend(['-timeout', str(timeout)])
            cmd.append(target)

        elif tool_name == 'sqlmap':
            risk = options.get('risk', 1)
            level = options.get('level', 2)
            batch = options.get('batch')
            cmd.extend(['--risk', str(risk), '--level', str(level)])
            if batch:
                cmd.append('--batch')
            cmd.extend(['-u', target])

        elif tool_name == 'naabu':
            ports = options.get('ports', 'top-1000')
            rate = options.get('rate', 1000)
            cmd.extend(['-p', ports, '-rate', str(rate), target])

        elif tool_name == 'gitleaks':
            config = options.get('config')
            report_format = options.get('report_format', 'sarif')
            if config:
                cmd.extend(['--config', config])
            cmd.extend(['--format', report_format, 'detect'])

        elif tool_name == 'semgrep':
            configs = options.get('config', [])
            for c in configs:
                cmd.extend(['--config', c])
            if options.get('sarif'):
                cmd.append('--json')

        else:
            # 通用回退：工具名 + target
            if tool_name not in ('gau', 'dnsx', 'trufflehog'):
                cmd.append(target)

        return cmd

    def _simulate_output(self, tool_name: str, target: str) -> str:
        """为模拟模式生成合理的工具输出。"""
        ts = datetime.now().isoformat()

        if tool_name == 'nuclei':
            return (
                f"[{ts}] [info] Loaded 3500+ nuclei templates\n"
                f"[{ts}] [info] Target: {target}\n"
                f"[{ts}] [http] Found SQL injection in /search?q=test [{target}/search?id=1'--]\n"
                f"[{ts}] [http] Found XSS in /comments [{target}/comment?body=<script>alert(1)</script>]\n"
                f"[{ts}] [info] Completed: 3500 templates, 2 findings\n"
            )

        if tool_name == 'nmap':
            scan_type = self._build_command(tool_name, {}, target)[2] if len(self._build_command(tool_name, {}, target)) > 2 else ''
            return (
                f"[{ts}] Starting Nmap scan of {target}\n"
                f"[{ts}] PORT     STATE SERVICE VERSION\n"
                f"[{ts}] 22/tcp   open  ssh     OpenSSH 8.9\n"
                f"[{ts}] 80/tcp   open  http    Apache httpd 2.4.54\n"
                f"[{ts}] 443/tcp  open  https   nginx 1.24\n"
                f"[{ts}] 3306/tcp open  mysql   MySQL 8.0.32\n"
                f"[{ts}] Nmap done: 1 IP address (1 host up) in 12.34 seconds\n"
            )

        if tool_name == 'httpx':
            return (
                f"[{ts}] https://{target} [200] [Apache/2.4.54] [7.8s]\n"
                f"[{ts}] http://{target} [301] []\n"
            )

        if tool_name == 'katana':
            return (
                f"[{ts}] Discovered: {target}/api/v1/users\n"
                f"[{ts}] Discovered: {target}/api/v1/admin\n"
                f"[{ts}] Discovered: {target}/.git/config\n"
                f"[{ts}] Total endpoints: 3\n"
            )

        if tool_name == 'subfinder':
            return (
                f"[{ts}] api.{target}\n"
                f"[{ts}] admin.{target}\n"
                f"[{ts}] dev.{target}\n"
                f"[{ts}] Total subdomains: 3\n"
            )

        if tool_name == 'sqlmap':
            return (
                f"[{ts}] [info] testing for SQL injection on {target}\n"
                f"[{ts}] [info] heuristics matched no SQLi\n"
                f"[{ts}] [info] testing 'AND boolean-based blind - WHERE or HAVING clause'\n"
            )

        if tool_name == 'naabu':
            return (
                f"[{ts}] {target}:22 open\n"
                f"[{ts}] {target}:80 open\n"
                f"[{ts}] {target}:443 open\n"
                f"[{ts}] Scan complete.\n"
            )

        # 默认空输出
        return f"[{ts}] [info] Tool '{tool_name}' run complete for target {target}."

    def _infer_findings(self, tool_name: str, raw_output: str) -> List[Dict]:
        """从工具输出中推断安全发现。"""
        findings = []

        # 简单启发式：在模拟输出中查找关键词
        if 'SQL injection' in raw_output:
            findings.append({
                'type': 'sqli',
                'severity': 'critical',
                'confidence': 'high',
                'description': 'SQL injection detected via tool heuristics',
            })
        if 'XSS' in raw_output:
            findings.append({
                'type': 'xss',
                'severity': 'high',
                'confidence': 'medium',
                'description': 'Cross-site scripting detected via tool heuristics',
            })
        if '.git/config' in raw_output:
            findings.append({
                'type': 'info_disclosure',
                'severity': 'medium',
                'confidence': 'high',
                'description': 'Exposed .git repository configuration',
            })
        if 'mysql' in raw_output.lower():
            findings.append({
                'type': 'service',
                'severity': 'info',
                'confidence': 'high',
                'description': 'MySQL database exposed on default port 3306',
            })

        return findings

    def get_results(self) -> List[Dict]:
        """以字典列表形式返回所有执行结果。"""
        return [r.to_dict() for r in self.results]


# ===================================================================
# 便捷函数
# ===================================================================


def execute_playbook(playbook_name: str, targets: List[str],
                     variables: Optional[Dict] = None,
                     simulate: bool = True) -> List[SwarmScanResult]:
    """便捷函数：按 playbook 名称执行扫描。

    Args:
        playbook_name: playbook 标识符（如 'owasp-top10'）。
        targets:       目标列表。
        variables:     可选变量覆盖。
        simulate:      True = 模拟模式（默认），False = 真实命令执行。

    Returns:
        SwarmScanResult 列表。
    """
    config = get_playbook(playbook_name)
    if config is None:
        raise ValueError(f"Playbook '{playbook_name}' not found. Available: {list(_ensure_builtin().keys())}")

    executor = PlaybookExecutor(simulate=simulate)
    return executor.execute_playbook(config, targets, variables)


# ===================================================================
# 命令行入口
# ===================================================================


def _main():
    """CLI 入口 — 列出 playbook 或执行模拟扫描。"""
    import argparse

    parser = argparse.ArgumentParser(description='Swarm Playbook CLI')
    parser.add_argument('command', choices=['list', 'execute'], help='子命令')
    parser.add_argument('--name', '-n', help='playbook 名称（execute 模式必需）')
    parser.add_argument('--targets', '-t', nargs='+', default=[], help='目标列表')
    parser.add_argument('--simulate', action='store_true', default=True, help='模拟模式执行')
    parser.add_argument('--real', action='store_false', dest='simulate', help='真实命令执行')

    args = parser.parse_args()

    if args.command == 'list':
        for pb in list_playbooks():
            print(f"  [{pb['id']}] {pb['name']} (v{pb['version']}) — {pb['phase_count']} phases, {len(pb['tags'])} tags")

    elif args.command == 'execute':
        if not args.name:
            print("错误：execute 模式需要 --name", file=sys.stderr)
            sys.exit(1)
        if not args.targets:
            print("错误：execute 模式需要 --targets", file=sys.stderr)
            sys.exit(1)

        config = get_playbook(args.name)
        if config is None:
            print(f"Playbook '{args.name}' 不存在", file=sys.stderr)
            sys.exit(1)

        executor = PlaybookExecutor(simulate=args.simulate)
        results = executor.execute_playbook(config, args.targets, variables=None)
        for r in results:
            findings_str = f" ({len(r.findings)} findings)" if r.findings else ""
            print(f"  [{r.phase:>25}] {r.tool_name:<15} -> {r.target:<30} [{r.status}]{findings_str}")

    # 打印 pheromones 摘要
    types = get_all_pheromone_types()
    if types:
        print(f"\nPheromone types ({len(types)}):")
        for t in types[:5]:
            cfg = get_pheromone(t)
            print(f"  {t}: base={cfg['base']}, half_life={cfg['half_life_sec']}s")
        if len(types) > 5:
            print(f"  ... and {len(types) - 5} more types")


if __name__ == '__main__':
    _main()
