#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
exec_gate.py — 危险操作审批门（C）
=====================================================================

用途
----
给"真实执行类"工具（exploit / PoC 运行等）加逐请求一次性审批：

- 内容寻址：请求的规范 JSON → SHA-256 作为唯一 key（同 vulnclaw request_hash）
- 一次性授权：approve 只对【该 hash 当次 pending】生效；同一命令再来一次
  会生成新 pending，必须重新审批（无会话级放行，同 vulnclaw"无 session 放行"）
- 模式：ask（逐请求问）/ auto_review（只读命令自动放行，其余仍问）/ full_access（全放行）
- 展示转义：审批弹窗里回显的命令/文本先经 visualize_for_display 转义
  控制字符/零宽/双向字符（防终端注入 + bidi 欺骗）
- 过期：pending 有 expires_at，超时按 deny 处理（expire_all_pending）

参照实现
--------
vulnclaw agent/exec_gate.py（505 行）：
  - visualize_for_display / visualize_single_line_for_display（转义表同款）
  - GateRequest.request_hash()（规范 JSON → sha256）
  - ApprovalView / GateOutcome / TrustedApprovalChannel
  - ExecutionGate（modes + pending_by_hash + resolve + expire_all_pending）
本模块同步化（hack_scanner 无 asyncio）：channel 收敛为 sync confirm hook
（callable(ApprovalView) -> bool，input() 基线实现 prompt_sync_hook），
算法与数据结构照搬，不 import vulnclaw。

零 orchestrator 改动的接线方式
------------------------------
本模块不改 swarm_orchestrator.py 一行。挂钩走入口层包装
（与 install_anti_loop_tracker / install_result_recorder 同模式）：

    from scanners.exec_gate import ExecutionGate, prompt_sync_hook, install_exec_gate

    gate = ExecutionGate(mode="ask", timeout_seconds=300)
    gate.install_sync_confirm_hook(prompt_sync_hook)   # 或测试里用 lambda
    install_exec_gate(orch, gate, protected_tools=("exploit",))

包装顺序：install_exec_gate 装在 install_result_recorder 之前
（recorder 记到的是审批拒绝文案 / 放行后的真实结果，二者都算"真实返回"）。

纯标准库（Python 3.14），零第三方依赖，零网络。
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, Optional, Tuple

__all__ = [
    "GateRequest",
    "ApprovalView",
    "GateOutcome",
    "ExecutionGate",
    "visualize_for_display",
    "visualize_single_line_for_display",
    "prompt_sync_hook",
    "classify_read_only",
    "install_exec_gate",
]

# ── 展示转义（防终端注入 / bidi 欺骗）───────────────────────────────────────
# 零宽与双向控制字符表（vulnclaw 同款区间）
_ZERO_WIDTH = {
    0x200B, 0x200C, 0x200D, 0x200E, 0x200F,   # zero-width space / joins / marks
    0x202A, 0x202B, 0x202C, 0x202D, 0x202E,   # bidi embeds / overrides
    0x2066, 0x2067, 0x2068, 0x2069, 0x206A,   # bidi isolate
    0x2060, 0xFEFF, 0x00AD, 0x034F,
}
_BIDI_RANGES = (
    (0x0590, 0x05FF),   # Hebrew
    (0x0600, 0x06FF),   # Arabic
    (0x0700, 0x074F),   # Syriac
    (0x200F, 0x200F),
)


def visualize_for_display(text: str) -> str:
    """把不可信文本转成可安全回显的字符串。

    保留 \\t / \\n；其余控制字符（含 0x1B、DEL、C1）、零宽、双向字符
    → \\uXXXX 转义。
    """
    if not isinstance(text, str):
        text = str(text)
    out: list[str] = []
    for ch in text:
        code = ord(ch)
        if ch in ("\t", "\n"):
            out.append(ch)
        elif code == 0x1B or code < 0x20 or code == 0x7F or 0x80 <= code <= 0x9F:
            out.append(f"\\u{code:04x}")
        elif code in _ZERO_WIDTH or any(lo <= code <= hi for lo, hi in _BIDI_RANGES):
            out.append(f"\\u{code:04x}")
        else:
            out.append(ch)
    return "".join(out)


def visualize_single_line_for_display(text: str) -> str:
    """单行安全回显（额外把 \\t \\n 也转义，不产生换行）。"""
    return visualize_for_display(text).replace("\t", "\\t").replace("\n", "\\n")


# ── 请求 / 视图 / 结果 ──────────────────────────────────────────────────────
@dataclass(frozen=True)
class GateRequest:
    """一次规范化的、内容寻址的执行请求。

    kind: "shell" | "python" | "poc" | ...
    display: 命令原文 / 源码
    cwd / detail: 展示上下文
    model_risk: 模型自评估（"" | "safe" | "review"）— 单向升级：
        "review" 强制走人工审批（即使只读分类命中）；"safe" 不降级。
    """
    kind: str
    display: str
    cwd: str = ""
    detail: str = ""
    model_risk: str = ""
    model_reason: str = ""

    def request_hash(self) -> str:
        payload = json.dumps(
            {
                "kind": self.kind,
                "display": self.display,
                "cwd": self.cwd,
                "detail": self.detail,
                "model_risk": self.model_risk,
                "model_reason": self.model_reason,
            },
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ApprovalView:
    """面向操作者的待审批描述。"""
    request_hash: str
    kind: str
    display_escaped: str
    cwd: str
    detail: str
    expires_at: str
    expires_in_seconds: int
    risk: str = ""

    def to_event_payload(self) -> dict[str, Any]:
        return {
            "request_hash": self.request_hash,
            "kind": self.kind,
            "question": self.display_escaped,
            "cwd": self.cwd,
            "detail": self.detail,
            "expires_at": self.expires_at,
            "expires_in_seconds": self.expires_in_seconds,
            "risk": self.risk,
        }


@dataclass(frozen=True)
class GateOutcome:
    approved: bool
    status: str      # approved | denied | expired | cancelled | no_channel | channel_error
    message: str = ""

    def refusal_text(self, tool_label: str = "该操作") -> str:
        """拒绝时回流给 LLM 的文案（让模型读到"被拒"语义而非报错语义）。"""
        base = (
            f"[exec-gate] {tool_label} 未获人工审批（status={self.status}），本次已阻止执行。"
            "不要重试同一命令；如需继续，请说明理由等待审批，或改用 dry-run/只读方式。"
        )
        return f"{base} {self.message}".strip()


# ── 只读命令分类（auto_review 模式用）───────────────────────────────────────
_SHELL_META = re.compile(r"[|;&<>`$()\n\r]")
_READ_ONLY_RE = re.compile(
    r"^\s*(ls|ll|cat|head|tail|wc|file|stat|pwd|whoami|id|uname|env|printenv|"
    r"date|which|whereis|dig|host|nslookup|curl\s+(-[A-Za-z]+\s+)*-I)\b"
)


def classify_read_only(command: str) -> Tuple[bool, str]:
    """判断 shell 命令是否"纯只读"（auto_review 自动放行用）。

    保守判定：无 shell 元字符 + 首词命中只读表 + 不超过 3 个参数词。
    任何不确定 → 不放行（fail-closed）。
    """
    if not isinstance(command, str) or not command.strip():
        return False, "empty command"
    if _SHELL_META.search(command):
        return False, "shell metacharacters present"
    # BUG_REPORT [4]：原 `command.strip() != command.strip()` 两边同表达式恒 False，
    # "weird whitespace" 检查从未生效（auto_review 少一层防护）。恢复为有效判定：
    # 含 space 之外的空白控制字符（tab/VT/FF；CR/LF 已被 _SHELL_META 覆盖）→ 不放行。
    if re.search(r"[\t\v\f]", command):
        return False, "weird whitespace"
    m = _READ_ONLY_RE.match(command)
    if not m:
        return False, "verb not in read-only allowlist"
    parts = command.split()
    if len(parts) > 4:
        return False, "too many arguments"
    return True, "read-only pattern"


# ── 同步审批 hook ──────────────────────────────────────────────────────────

def _input_with_timeout(prompt: str, timeout_seconds: Optional[float]) -> Optional[str]:
    """input() 带超时（跨平台——Windows 的 select 不支持 stdin）。

    守护线程跑 input()，主线程 join(timeout)：
      - 按时返回 → 输入值
      - 线程内 EOF/Ctrl+C/OSError → 原样抛出（由上层 fail-closed 处理）
      - 超时 → 返回 None（调用方按"未响应"处理）；线程里迟到的输入被丢弃
        （daemon 线程随进程退出，不泄漏）
    """
    if not timeout_seconds or timeout_seconds <= 0:
        return input(prompt)
    box: list = []
    errs: list = []

    def _ask() -> None:
        try:
            box.append(input(prompt))
        except BaseException as exc:  # noqa: B036 - 跨线程传递，上层按类型处理
            errs.append(exc)

    t = threading.Thread(target=_ask, daemon=True)
    t.start()
    t.join(timeout_seconds)
    if not t.is_alive():
        if errs:
            raise errs[0]
        if box:
            return box[0]
        return None
    return None  # 超时未响应


def prompt_sync_hook(view: ApprovalView) -> bool:
    """input() 基线同步审批 hook（交互式 TTY 场景）。

    回显已转义的命令/详情后询问 yes/no；任何异常（EOF/Ctrl+C/非 TTY）
    → 拒绝（fail-closed）。测试里可直接用 lambda 替换（见 install_exec_gate）。

    BUG_REPORT [5]：原 input() 无超时，expires_at 仅展示——挂起审批会永久阻塞
    campaign（需 Ctrl+C）。现在按 view.expires_in_seconds 限时，超时 = 未响应
    → 拒绝（fail-closed，与模块头"超时按 deny 处理"的契约一致）。
    """
    try:
        print(f"\n⚠️  [exec-gate] {view.kind} 请求待审批（{view.expires_in_seconds}s 内有效）:")
        print(f"    {view.display_escaped}")
        if view.cwd:
            print(f"    cwd: {view.cwd}")
        if view.detail:
            print(f"    详情: {view.detail}")
        ans = _input_with_timeout("    批准执行? (y/n) [n]: ", view.expires_in_seconds)
        if ans is None:
            print("    ⏱ 审批超时（未响应），已拒绝（fail-closed）。")
            return False
        return ans.strip().lower() in ("y", "yes")
    except (EOFError, KeyboardInterrupt, OSError, ValueError):
        return False


# ── 审批门（同步版）───────────────────────────────────────────────────────

class ExecutionGate:
    """危险操作审批门（同步版，算法照搬 vulnclaw ExecutionGate）。

    模式:
      ask          逐请求人工审批（默认）
      auto_review  只读 shell 命令自动放行，其余仍逐请求审批
      full_access  全放行（dry-run 场景/自动化测试用）

    一次性授权: approve 只对【该 hash 当次请求】生效；同一命令再来一次
    必须重新审批（无会话级放行，同 vulnclaw"无 session 放行"语义）。
    通道异常 → 拒绝，绝不自动放行（fail-closed）。
    """

    VALID_MODES = ("ask", "auto_review", "full_access")

    def __init__(self, mode: str = "ask", timeout_seconds: int = 300,
                 trusted_commands: tuple = (),
                 command_policy: Optional[Callable[[str], Optional[Tuple[bool, str]]]] = None,
                 ) -> None:
        if mode not in self.VALID_MODES:
            raise ValueError(f"invalid permission mode: {mode!r}")
        self.mode = mode
        self.timeout_seconds = max(1, int(timeout_seconds))
        self.trusted_commands = tuple(trusted_commands)
        # 静态命令判定策略（4 项目升级清单 #2，cmd_guard.build_policy）:
        #   (command) -> (True, reason)  静态可证只读
        #               -> (False, reason) 静态可证危险（执行/写/删）
        #               -> None          无法静态判定（交后续审批路径）
        # None → 行为与整合前完全一致。
        self.command_policy = command_policy
        self.sync_confirm_hook: Optional[Callable[[ApprovalView], bool]] = None
        self._pending_by_hash: Dict[str, Dict[str, Any]] = {}
        self._inflight_hashes: Set[str] = set()
        self.stats: Dict[str, int] = {
            "requested": 0, "approved": 0, "denied": 0,
            "expired": 0, "cancelled": 0,
        }

    # ── 控制面接线 ────────────────────────────────────────────────────────

    def install_sync_confirm_hook(
            self, hook: Callable[[ApprovalView], bool]) -> None:
        self.sync_confirm_hook = hook

    def has_trusted_channel(self) -> bool:
        return self.sync_confirm_hook is not None

    def set_mode(self, mode: str) -> str:
        """切换模式（仅校验+设置）。非法值 → ValueError。"""
        normalized = str(mode or "").strip().lower()
        if normalized not in self.VALID_MODES:
            raise ValueError(
                f"invalid permission mode {mode!r}; expected one of {', '.join(self.VALID_MODES)}")
        self.mode = normalized
        return self.mode

    # ── 模型面入口 ────────────────────────────────────────────────────────

    def _make_view(self, request: GateRequest, detail_extra: str = "") -> ApprovalView:
        detail = request.detail
        if detail_extra:
            detail = f"{detail} | {detail_extra}" if detail else detail_extra
        return ApprovalView(
            request_hash=request.request_hash(),
            kind=request.kind,
            display_escaped=visualize_for_display(request.display),
            cwd=visualize_single_line_for_display(request.cwd),
            detail=visualize_for_display(detail),
            expires_at=(
                datetime.now(timezone.utc) + timedelta(seconds=self.timeout_seconds)
            ).isoformat(timespec="seconds"),
            expires_in_seconds=self.timeout_seconds,
            risk="Executes with current user privileges; not sandboxed.",
        )

    def authorize(self, request: GateRequest) -> GateOutcome:
        """对一次执行请求做审批裁决。同步、单请求、一次性。

        裁决顺序（同 vulnclaw）:
          1. full_access → 直接放行
          2. auto_review + shell + 只读分类命中（且 model_risk != "review"）→ 放行
          3. 无审批通道 → no_channel（fail-closed）
          4. 同步 hook 裁决 → approved / denied
             hook 抛异常 → channel_error（绝不自动放行）
        """
        self.stats["requested"] += 1
        if not isinstance(request, GateRequest):
            request = GateRequest(kind="shell", display=str(request))

        if self.mode == "full_access":
            self.stats["approved"] += 1
            return GateOutcome(True, "approved")

        # 静态命令策略（cmd_guard）：先于 model 自评与审批通道
        #   deny  → 拒（不询问，静态可证危险）
        #   allow 且非 ask 模式 → 自动放行（auto_review 语义增强）
        #   None  → 无静态结论，落回既有逻辑
        if self.command_policy is not None and request.kind == "shell":
            try:
                verdict = self.command_policy(request.display)
            except Exception:
                verdict = None  # 策略异常 → 不影响既有路径（fail-safe 到审批）
            if verdict is not None:
                allowed, reason = verdict
                if not allowed:
                    self.stats["denied"] += 1
                    return GateOutcome(
                        False, "policy_denied",
                        message=f"静态命令判定拒绝（不询问）: {reason}")
                if self.mode != "ask":
                    self.stats["approved"] += 1
                    return GateOutcome(True, "approved",
                                       message=f"policy allow: {reason}")

        # model 自评估单向升级："review" 强制人工审批；"safe" 不降级
        flagged_review = request.model_risk == "review"
        classifier_reason = ""
        if self.mode == "auto_review" and request.kind == "shell" and not flagged_review:
            ok, reason = classify_read_only(request.display)
            if ok:
                self.stats["approved"] += 1
                return GateOutcome(True, "approved")
            classifier_reason = reason
        if flagged_review:
            note = (request.model_reason or "model self-assessment: needs review")
            classifier_reason = (f"{classifier_reason} | {note}"
                                 if classifier_reason else note)

        hook = self.sync_confirm_hook
        if hook is None:
            return GateOutcome(
                False, "no_channel",
                message=("未安装审批通道。请在交互式环境审批，"
                         "或将 safety.exec_gate_mode 设为 full_access（仅限 dry-run）。"))

        request_hash = request.request_hash()
        if request_hash in self._inflight_hashes:
            return GateOutcome(
                False, "already_pending",
                message=f"相同请求已在等待审批: {request.display[:80]}")
        self._inflight_hashes.add(request_hash)
        try:
            view = self._make_view(request, classifier_reason)
            self._pending_by_hash[request_hash] = {"view": view, "state": "pending"}
            try:
                approved = bool(hook(view))
            except Exception:
                self._settle(request_hash, "cancelled")
                self.stats["cancelled"] += 1
                return GateOutcome(False, "channel_error",
                                   message="审批通道执行异常（禁止自动放行）")
            status = "approved" if approved else "denied"
            self._settle(request_hash, status)
            self.stats[status] = self.stats.get(status, 0) + 1
            if status != "approved":
                return GateOutcome(False, status)
            return GateOutcome(True, "approved")
        finally:
            self._inflight_hashes.discard(request_hash)

    def _settle(self, request_hash: str, state: str) -> None:
        pending = self._pending_by_hash.pop(request_hash, None)
        if pending is not None:
            pending["state"] = state

    def confirm_sync(self, request: GateRequest) -> bool:
        """同步裁决便捷入口（等价 authorize(...).approved）。"""
        return self.authorize(request).approved

    def expire_all_pending(self, reason: str = "expired") -> int:
        """把所有 pending 按 reason 收尾（过期/取消）。返回收尾条数。"""
        count = 0
        for h in list(self._pending_by_hash):
            pending = self._pending_by_hash.pop(h, None)
            if pending is not None and pending.get("state") == "pending":
                pending["state"] = reason
                count += 1
        return count


# ── 入口层接线（orchestrator 零改动）─────────────────────────────────────

def install_exec_gate(orch, gate: Optional[ExecutionGate] = None,
                      protected_tools=("exploit",),
                      command_policy=None) -> ExecutionGate:
    """包装 orch.tools 中危险工具的 execute（同 install_result_recorder 模式）。

    - 未获批 → 不执行原工具，返回 (拒绝文案, None)：
      让 LLM 读到"被拒"语义（refusal_text）而不是报错语义
    - 获批 / full_access → 透传原 execute（工具异常照常抛出，orchestrator 有既有 try/except）
    - gate 自身抛异常 → fail-closed（拒绝，绝不放行）
    - 非 protected_tools 不包装；已包装（_exec_gate_wrapped）跳过（幂等）

    包装顺序：应装在 install_result_recorder 之前
    （recorder 记到的是审批拒绝文案 / 放行后的真实结果，二者都算"真实返回"）。
    """
    gate = gate or ExecutionGate()
    if command_policy is not None:
        gate.command_policy = command_policy
    tools = getattr(orch, "tools", None) or {}
    for name, tool in list(tools.items()):
        if name not in protected_tools:
            continue
        orig = getattr(tool, "execute", None)
        if orig is None or getattr(orig, "_exec_gate_wrapped", False):
            continue

        def wrap(args, _orig=orig, _gate=gate, _name=name):
            # 从工具参数里抽"将被执行的命令/脚本"（尽力而为，抽不到用原文兜底）
            try:
                payload = json.loads(args) if isinstance(args, str) else dict(args or {})
                if not isinstance(payload, dict):
                    payload = {}
            except (ValueError, TypeError):
                payload = {}
            command = ""
            for key in ("command", "cmd", "code", "script", "payload"):
                v = payload.get(key)
                if isinstance(v, str) and v.strip():
                    command = v.strip()
                    break
            if not command:
                command = (args if isinstance(args, str) else str(payload))[:400]
            request = GateRequest(kind="shell", display=command, detail=f"tool={_name}")
            try:
                outcome = _gate.authorize(request)
            except Exception:
                outcome = GateOutcome(False, "channel_error",
                                      message="审批门内部错误（fail-closed）")
            if not outcome.approved:
                return outcome.refusal_text(_name), None
            return _orig(args)

        wrap._exec_gate_wrapped = True  # type: ignore[attr-defined]
        tool.execute = wrap
    return gate


# ── self-test（python scanners/exec_gate.py）──────────────────────────────
if __name__ == "__main__":
    # 1) 展示转义
    assert visualize_for_display("a‮b") == "a\\u202eb", "bidi 控制字符须转义"
    assert visualize_for_display("x\ry") == "x\\u000dy"
    assert visualize_single_line_for_display("a\nb") == "a\\nb"
    # 2) 内容寻址 hash 稳定 + 敏感
    _r1 = GateRequest(kind="shell", display="ls -la")
    assert _r1.request_hash() == GateRequest(kind="shell", display="ls -la").request_hash()
    assert _r1.request_hash() != GateRequest(kind="shell", display="ls -la /").request_hash()
    # 3) full_access 全放行
    _g = ExecutionGate(mode="full_access")
    assert _g.authorize(GateRequest("shell", "rm -rf /tmp/x")).approved
    # 4) auto_review：只读自动放行、危险仍走审批
    _g = ExecutionGate(mode="auto_review")
    _asked: list = []
    _g.install_sync_confirm_hook(lambda v: (_asked.append(v), True)[1])
    assert _g.authorize(GateRequest("shell", "cat /etc/passwd")).approved
    assert not _asked, "只读命令应自动放行不询问"
    _asked.clear()
    assert _g.authorize(GateRequest("shell", "rm -rf /")).approved and _asked, "危险命令须审批"
    # 5) ask：批/拒
    _g = ExecutionGate(mode="ask")
    _g.install_sync_confirm_hook(lambda v: True)
    assert _g.authorize(GateRequest("shell", "whoami")).approved
    _g.install_sync_confirm_hook(lambda v: False)
    _o = _g.authorize(GateRequest("shell", "whoami"))
    assert not _o.approved and _o.status == "denied"
    assert "未获人工审批" in _o.refusal_text()
    # 6) 一次性授权：同一命令再来一次必须重新审批
    _prompts: list = []
    _g.install_sync_confirm_hook(lambda v: (_prompts.append(v), True)[1])
    _g.authorize(GateRequest("shell", "id"))
    _g.authorize(GateRequest("shell", "id"))
    assert len(_prompts) == 2, "无会话级放行：重复命令须重新审批"
    # 7) 无通道 → fail-closed
    _g = ExecutionGate(mode="ask")
    _o = _g.authorize(GateRequest("shell", "id"))
    assert not _o.approved and _o.status == "no_channel"
    # 8) 通道异常 → channel_error，绝不自动放行
    _g = ExecutionGate(mode="ask")
    def _boom(v):
        raise RuntimeError("channel down")
    _g.install_sync_confirm_hook(_boom)
    _o = _g.authorize(GateRequest("shell", "id"))
    assert not _o.approved and _o.status == "channel_error"
    # 9) model_risk=review 强制人工审批（auto_review 下亦然）
    _g = ExecutionGate(mode="auto_review")
    _asked = []
    _g.install_sync_confirm_hook(lambda v: (_asked.append(1), True)[1])
    _g.authorize(GateRequest("shell", "cat /etc/passwd", model_risk="review"))
    assert _asked, "review 标记必须强制人工审批"
    # 10) set_mode 校验
    try:
        _g.set_mode("yolo")
        raise AssertionError("非法模式应 ValueError")
    except ValueError:
        pass
    # 11) install_exec_gate 接线：拒绝不执行 / 批准透传 / 非保护工具不包装
    class _FT:
        def __init__(self):
            self.executed = 0
        def execute(self, args):
            self.executed += 1
            return ("RAN", None)
    class _FO:
        def __init__(self):
            self.tools = {"exploit": _FT(), "http_probe": _FT()}
    _orch = _FO()
    _g = ExecutionGate(mode="ask")
    _g.install_sync_confirm_hook(lambda v: False)
    install_exec_gate(_orch, _g, protected_tools=("exploit",))
    _res, _err = _orch.tools["exploit"].execute('{"command": "id"}')
    assert _err is None and "未获人工审批" in _res, "拒绝文案回流"
    assert _orch.tools["exploit"].executed == 0, "拒绝后不得执行"
    _g.install_sync_confirm_hook(lambda v: True)
    _res, _err = _orch.tools["exploit"].execute('{"command": "id"}')
    assert _orch.tools["exploit"].executed == 1 and _res == "RAN", "批准后透传执行"
    assert _orch.tools["http_probe"].executed == 0, "非保护工具不得被包装执行"
    print("exec_gate self-test OK")
