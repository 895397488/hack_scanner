#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Playbook System — 预定义扫描工作流
===================================
借鉴 Pentest-Swarm-AI playbooks/*.yaml.
将不同扫描场景（OWASP Top10、Bug Bounty、内部评估）打包为可复用的 Playbook。
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger('playbook')


# ==================== 内置 Playbooks（直接嵌入，无需外部文件）====================

BUILTIN_PLAYBOOKS = {
    'owasp-top10': {
        'name': 'OWASP Top 10 全面评估',
        'description': '覆盖 OWASP Top 10 2021 全部类别的 Web 安全扫描流程',
        'version': '1.0.0',
        'tags': ['owasp', 'web', 'comprehensive'],
        'enabled_checks': [
            'check_sqli',           # A03:2021 - Injection
            'check_xss',            # A03:2021 - Injection
            'check_ssrf',           # A03:2021 - Injection
            'check_rce',            # A03:2021 - Injection
            'check_lfi',            # A03:2021 - Injection (file include)
            'check_xxe',            # A03:2021 - Injection
            'check_authorization_bypass',   # A01:2021 - Broken Access Control
            'check_unauthorized_access',    # A01:2021 - Broken Access Control
            'check_csrf',           # A01:2021 - Broken Access Control
            'check_password_reset',         # A07:2021 - Identification & Authentication Failures
            'check_weak_password',          # A07:2021 - Identification & Authentication Failures
            'check_ssl',            # A02:2021 - Cryptographic Failures
            'check_headers',        # A05:2021 - Security Misconfiguration
            'check_extended_headers',       # A05:2021 - Security Misconfiguration
            'check_cors',         # A01:2021 - Broken Access Control
            'check_sensitive_data',       # A02:2021 - Cryptographic Failures
            'check_dvcs_leak',        # A05:2021 - Security Misconfiguration
            'check_openapi',          # A05:2021 - Security Misconfiguration
            'check_cms_fingerprint',  # A05:2021 - Security Misconfiguration
            'check_http_methods',     # A05:2021 - Security Misconfiguration
            'check_business_logic',   # A04:2021 - Insecure Design / A08:2021
            'enum_subdomains',    # Reconnaissance
            'dir_busting',        # A05:2021 - Security Misconfiguration
        ],
    },

    'bug-bounty': {
        'name': 'Bug Bounty 快速狩猎',
        'description': '针对 Bug Bounty 程序的高 ROI 漏洞扫描流程 — 聚焦 IDOR、SSRF、未授权访问等高价值目标',
        'version': '1.0.0',
        'tags': ['bug-bounty', 'external', 'web', 'high-roi'],
        'enabled_checks': [
            'check_sqli',
            'check_xss',
            'check_ssrf',
            'check_rce',
            'check_lfi',
            'check_xxe',
            'check_file_upload',
            'check_deserialization',
            'check_authorization_bypass',   # IDOR - HIGHEST ROI
            'check_unauthorized_access',    # Unauth access - HIGH ROI
            'check_csrf',
            'check_password_reset',
            'check_business_logic',     # Logic bugs - HIGH ROI
            'check_impact_eval',        # Impact assessment
            'check_sensitive_data',
            'check_dvcs_leak',
            'check_openapi',
            'check_weak_password',
            'check_password_reset',
            'enum_subdomains',
            'dir_busting',
        ],
    },

    'internal-network': {
        'name': '内部网络评估',
        'description': '针对内部网络的全面安全评估 — 涵盖端口、服务、未授权访问等',
        'version': '1.0.0',
        'tags': ['internal', 'network', 'comprehensive'],
        'enabled_checks': [
            'check_ssl',
            'check_sqli',
            'check_xss',
            'check_ssrf',
            'check_rce',
            'check_lfi',
            'check_headers',
            'check_extended_headers',
            'check_cors',
            'check_unauthorized_access',
            'check_sensitive_data',
            'check_dvcs_leak',
            'check_openapi',
            'check_http_methods',
            'check_authorization_bypass',
            'enum_subdomains',
            'dir_busting',
        ],
    },

    'ci-cd-security': {
        'name': 'CI/CD 安全检查',
        'description': '检查 CI/CD 相关的敏感文件泄露和配置错误',
        'version': '1.0.0',
        'tags': ['ci-cd', 'security', 'misconfiguration'],
        'enabled_checks': [
            'check_sensitive_data',
            'check_dvcs_leak',
            'check_unauthorized_access',
            'check_headers',
            'check_extended_headers',
            'check_openapi',
            'check_cms_fingerprint',
            'enum_subdomains',
        ],
    },

    'ctf-solver': {
        'name': 'CTF 解题辅助',
        'description': '针对 CTF Web 题的快速扫描 — 自动化常见漏洞检测',
        'version': '1.0.0',
        'tags': ['ctf', 'web', 'competition'],
        'enabled_checks': [
            'check_sqli',
            'check_xss',
            'check_ssrf',
            'check_rce',
            'check_lfi',
            'check_xxe',
            'check_file_upload',
            'check_deserialization',
            'check_sensitive_data',
            'check_dvcs_leak',
        ],
    },
}


class PlaybookRunner:
    """Playbook 执行器"""

    @staticmethod
    def list_playbooks() -> List[Dict]:
        """列出所有可用的 Playbook"""
        result = []
        for name, pb in BUILTIN_PLAYBOOKS.items():
            result.append({
                'name': name,
                'title': pb['name'],
                'description': pb['description'],
                'version': pb['version'],
                'tags': pb['tags'],
                'enabled_check_count': len(pb['enabled_checks']),
            })
        return result

    @staticmethod
    def get_playbook(name: str) -> Optional[Dict]:
        """获取指定 Playbook 配置"""
        return BUILTIN_PLAYBOOKS.get(name)

    @staticmethod
    def load_custom_playbook(path: str) -> Optional[Dict]:
        """从 JSON 文件加载自定义 Playbook"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                pb = json.load(f)
                # Validate required fields
                if 'name' not in pb or 'checks' not in pb:
                    logger.warning(f"  Playbook {path}: missing required 'name' or 'checks' field")
                    return None
                return pb
        except (json.JSONDecodeError, FileNotFoundError) as e:
            logger.error(f"  Playbook load error ({path}): {e}")
            return None

    @staticmethod
    def apply_to_config(playbook: Dict, current_config: Dict) -> Dict:
        """将 Playbook 的配置应用到现有 config.json"""
        new_config = json.loads(json.dumps(current_config))  # Deep copy

        checks = playbook.get('checks', [])
        if not checks:
            logger.warning("  Playbook has no 'checks' defined")
            return new_config

        # Map playbook check names to url_scanner CONFIG keys
        for check in checks:
            check_name = check if isinstance(check, str) else check.get('name', '')
            enabled = check if isinstance(check, bool) else check.get('enabled', True)

            # Apply to urls section
            config_key = check_name.replace('check_', '').replace('-', '_')
            if 'urls' in new_config and config_key in new_config['urls']:
                new_config['urls'][config_key] = enabled
            elif 'urls' not in new_config:
                new_config['urls'] = {config_key: enabled}

        return new_config


class FPFalsePositiveCache:
    """假阳性缓存 — 避免重复报告已知误报
    借鉴 Pentest-Swarm-AI Phase 4.3.4"""

    CACHE_FILE = 'fp_cache.json'

    def __init__(self, cache_dir: str = ''):
        if not cache_dir:
            import os
            cache_dir = os.path.dirname(os.path.abspath(__file__))
        self.cache_path = os.path.join(cache_dir, self.CACHE_FILE)
        self.cache_data = self._load_cache()

    def _load_cache(self) -> Dict:
        """加载 FP 缓存"""
        if os.path.exists(self.cache_path):
            try:
                with open(self.cache_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                return {'suppressed': {}, 'last_updated': 0}
        return {'suppressed': {}, 'last_updated': 0}

    def _save_cache(self):
        """保存 FP 缓存"""
        self.cache_data['last_updated'] = datetime.now().isoformat()
        try:
            with open(self.cache_path, 'w', encoding='utf-8') as f:
                json.dump(self.cache_data, f, ensure_ascii=False, indent=2)
        except IOError:
            pass

    def add_suppression(self, target: str, vuln_id: str, reason: str = '') -> None:
        """添加假阳性到抑制列表"""
        key = f"{target}::{vuln_id}"
        self.cache_data['suppressed'][key] = {
            'reason': reason,
            'added_at': datetime.now().isoformat(),
            'confirmed_fp': True,
        }
        self._save_cache()

    def is_suppressed(self, target: str, vuln_id: str) -> bool:
        """检查是否被标记为假阳性"""
        key = f"{target}::{vuln_id}"
        return key in self.cache_data['suppressed']

    def get_count(self) -> int:
        """获取当前抑制规则数量"""
        return len(self.cache_data['suppressed'])

    def remove_suppression(self, target: str, vuln_id: str) -> bool:
        """移除假阳性抑制"""
        key = f"{target}::{vuln_id}"
        if key in self.cache_data['suppressed']:
            del self.cache_data['suppressed'][key]
            self._save_cache()
            return True
        return False

    def clear_all(self) -> None:
        """清除所有抑制规则"""
        self.cache_data['suppressed'] = {}
        self._save_cache()

    def summarize(self) -> Dict:
        """获取 FP 缓存摘要"""
        return {
            'total_suppressed': len(self.cache_data['suppressed']),
            'targets': list(set(
                k.split('::')[0] for k in self.cache_data['suppressed']
            )),
            'last_updated': self.cache_data.get('last_updated', 'never'),
        }
