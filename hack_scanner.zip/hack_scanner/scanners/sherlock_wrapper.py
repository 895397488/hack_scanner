#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sherlock Wrapper — sherlock CLI wrapper，社交账号用户名枚举。

OSINT 增强：给定用户名，在 300+ 社交平台检测是否存在对应账号，
用于攻击面扩张（发现目标在其他平台的公开身份/关联信息）。

集成方式：需要安装 sherlock
  - pip install sherlock-project   (推荐)
  - 或 git clone https://github.com/sherlock-project/sherlock
本模块只负责 CLI 调用和结果解析。config.json → tools.sherlock_path 可指定路径。

Usage:
    from scanners.sherlock_wrapper import sherlock_enum
    result = sherlock_enum("username")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('sherlock_scanner')


def _find_sherlock() -> Optional[str]:
    """查找 sherlock 可执行文件：先 config.json → tools.sherlock_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("sherlock_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["sherlock", "sherlock.exe", "sherlock.py"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def sherlock_enum(username: str, site_list: str = "", max_time: int = 300) -> dict:
    """运行 sherlock 社交账号枚举。

    Args:
        username:  要枚举的用户名
        site_list: 指定站点（空=全部；如 twitter,github,instagram）
        max_time:  最大运行时间秒

    Returns:
        {"ok": bool, "found": [...], "not_found_count": int, "error": ...}
    """
    if not username:
        return {"ok": False, "found": [], "not_found_count": 0, "error": "缺少用户名参数"}

    sh = _find_sherlock()
    if not sh:
        return {"ok": False, "found": [], "not_found_count": 0,
                "error": "sherlock 未找到，请安装: pip install sherlock-project"}

    # sherlock 0.16: 无 JSON 输出选项（--json 实为"加载数据文件"输入参数，勿用）；
    # 站点用可重复的 --site 指定（位置参数是 username，不是站点名）；
    # --no-txt 避免在 CWD 生成报告文件；--print-all 让"未发现"行也输出（便于计数）。
    # 结果从 stdout 行格式解析。
    cmd = [sh, username, "--no-color", "--no-txt", "--print-all"]
    if site_list:
        for s in site_list.split(","):
            s = s.strip()
            if s:
                cmd.extend(["--site", s])
    logger.info(f"sherlock: {username} (sites={site_list or 'all'})")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = (proc.stdout or "") + "\n" + (proc.stderr or "")
        found, not_found, errors = _parse_sherlock_output(raw)
        return {
            "ok": True,
            "username": username,
            "found": found[:500],
            "found_count": len(found),
            "not_found_count": not_found,
            "errors": errors,
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "found": [], "not_found_count": 0, "errors": 0, "error": "sherlock 超时"}


def _parse_sherlock_output(raw: str):
    """解析 sherlock stdout 行。

    0.16 格式 (notify.py update()):
        [+] <SiteName>: <URL>           发现账号 (CLAIMED)
        [-] <SiteName>: Not Found!      未发现 (AVAILABLE，需 --print-all)
        [-] <SiteName>: Error/Timeout   连接错误 / WAF (UNKNOWN/WAF)
        [*] ...                         进度行，忽略
    旧版本格式兼容: [OK]/[!!]/[xx]
    返回 (found: list, not_found: int, errors: int)。
    """
    found = []
    not_found = 0
    errors = 0
    claimed_re = re.compile(r"\[(\+|OK|!!)\]\s*(.*?)\s*$")
    missed_re = re.compile(r"^\s*\[-\]\s*(.*?)\s*$")
    old_miss_re = re.compile(r"\[(xx|x)\]\s*(.*?)\s*$")  # 旧全量模式 "[xx]" 可能在行中（"admin : [xx]"）
    for line in raw.splitlines():
        m = claimed_re.search(line)
        if m:
            rest = m.group(2)
            # rest 可能是 "SiteName: URL" 或纯 URL（旧全量模式）
            if ": " in rest:
                rest = rest.split(": ", 1)[1]
            host = rest.split("://", 1)[-1].split("/", 1)[0] if "://" in rest else rest
            found.append({"site": host, "url": rest,
                          "status": "ok" if m.group(1) in ("+", "OK") else "possible"})
            continue
        m = missed_re.search(line)
        if m:
            # 0.16 中 [-] 同时表示"未发现"和"站点错误"，靠尾部文本区分
            detail = m.group(1)
            if re.search(r"not found|illegal username", detail, re.I) or detail == "":
                not_found += 1
            else:
                errors += 1
            continue
        if old_miss_re.search(line):
            not_found += 1
    return found, not_found, errors
