#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File Ownership Manager — Windows 文件/文件夹所有权接管 + 授权。

TakeOwnershipPro (v1.6) 功能移植：把目标文件/目录的所有者改为指定账户
（默认 Administrators），并给 Everyone + Administrators 授予完整控制权限，
用于解锁被锁定的文件、清理残留、恢复访问权限（授权渗透测试 / 事件响应场景）。

底层使用 Windows 内置 takeown.exe + icacls.exe（零额外依赖，按退出码判断，
不受系统语言影响）。需要以管理员身份运行才能接管他人拥有的文件。

被进程锁定的文件（Windows 11 实测）：
    - 接管本身不受锁阻挡——即使文件被 Share=NONE 独占打开，takeown/icacls
      仍能成功改所有者/授权（安全描述符操作不受共享冲突限制；实测独占锁
      全程持有时 takeown rc=0、icacls rc=0、owner 成功变更）。
    - 独占锁挡住的是**数据访问**（读/写/复制/删除）。接管完所有者后若要
      操作文件内容，可用 find_locking_processes() 定位锁定进程
      （psutil 枚举，已在 requirements.txt），手动关闭，或
      kill_locking_processes() / on_lock='kill' 终止后重试
      （事件响应/授权渗透场景）。

Usage:
    from scanners.ownership_take import (
        take_ownership, get_owner, check_admin,
        find_locking_processes, kill_locking_processes, read_via_vss,
    )
    result = take_ownership(r"C:\\locked_folder", recursive=True)
    print(result["ok"], result["owner_before"], result["owner_after"])

    # 谁锁着这个文件？
    locks = find_locking_processes(r"C:\\locked_folder\\a.txt")
    # [{"pid": 1234, "name": "svchost.exe", "handles": 2}, ...]

    # 读出被进程锁定文件的内容（VSS 卷影，不杀进程、不重启）
    r = read_via_vss(r"C:\\locked_folder\\malware.exe")
    # {"ok": true, "dest": "C:\\...\\malware.exe.vss", "verified": true, ...}

    # CLI
    python -m scanners.ownership_take "C:\\locked_folder" --recursive
    python -m scanners.ownership_take "C:\\locked_file.txt" --list-locks
    python -m scanners.ownership_take "C:\\locked_file.txt" --kill-lockers
    python -m scanners.ownership_take "C:\\locked_file.txt" --read-vss           # VSS 读出内容
    python -m scanners.ownership_take "C:\\locked_file.txt" --read-vss --dest D:\\out\\sample.bin
"""

import argparse
import json
import locale
import logging
import os
import re
import subprocess
import sys
import time
from typing import Dict, List, Optional

logger = logging.getLogger('ownership_take')


def _decode(b: bytes) -> str:
    """把子进程输出的字节按系统首选编码解码（中文 Windows 为 GBK），失败回退 utf-8/replace。"""
    if not b:
        return ''
    try:
        pref = locale.getpreferredencoding(False) or 'utf-8'
        return b.decode(pref)
    except (UnicodeDecodeError, LookupError):
        pass
    return b.decode('utf-8', errors='replace')

# 已知本地管理员/常用账户 SID 映射（用于把 icacls 输出里的 SID 反解成名字）
_KNOWN_SIDS = {
    'S-1-5-32-544': 'Administrators',
    'S-1-5-32-545': 'Users',
    'S-1-5-32-546': 'Guests',
    'S-1-5-32-548': 'Local Service',
    'S-1-5-32-549': 'Network Service',
    'S-1-5-18': 'SYSTEM',
    'S-1-5-19': 'Anonymous Logon',
    'S-1-5-20': 'NT Authority\\Network',
    'S-1-1-0': 'Everyone',
    'S-1-5-32-573': 'Performance Log Users',
    'S-1-5-32-568': 'Remote Desktop Users',
}

# 安全门控：这些路径禁止直接接管（影响面过大，需指定具体子路径）
_BLOCKED_PATHS = {
    'c:\\', 'c:\\windows', 'c:\\program files', 'c:\\program files (x86)',
    'c:\\programdata', 'c:\\users', 'd:\\', 'e:\\',
}

# SID 提取正则（icacls owner 行格式如 "owner: BUILTIN\Administrators:S-1-5-32-544"）
_SID_RE = re.compile(r'(S-1-\d+(?:-\d+)*)')


def _run(cmd: List[str], timeout: int = 120) -> Dict:
    """执行外部命令，返回 {rc, stdout, stderr, error}。"""
    try:
        proc = subprocess.run(
            cmd, capture_output=True, timeout=timeout, shell=False,
        )
        return {
            'rc': proc.returncode,
            'stdout': _decode(proc.stdout),
            'stderr': _decode(proc.stderr),
            'error': '',
        }
    except subprocess.TimeoutExpired:
        return {'rc': -1, 'stdout': '', 'stderr': '', 'error': f'命令超时 ({timeout}s): {" ".join(cmd)}'}
    except FileNotFoundError:
        return {'rc': -2, 'stdout': '', 'stderr': '', 'error': f'找不到命令: {cmd[0]}'}
    except Exception as e:  # noqa: BLE001
        return {'rc': -3, 'stdout': '', 'stderr': '', 'error': f'执行异常: {e}'}


def _winpath(path: str) -> str:
    """把路径规范化为 Windows 工具可识别的形式（正斜杠 → 反斜杠）。

    实测 takeown 不识别正斜杠路径（报"未找到文件或目录"），而 icacls/PowerShell
    两者都接受 —— 统一转反斜杠最稳妥。normpath 同时规范 UNC（//srv/x → \\srv\\x）。
    """
    if os.name == 'nt' and path:
        return os.path.normpath(path)
    return path


def check_admin() -> bool:
    """检测当前进程是否拥有管理员权限（已提权）。非 Windows 返回 False。"""
    if os.name != 'nt':
        return False
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:  # noqa: BLE001
        return False


def _norm_path_for_match(path: str) -> str:
    """统一路径形式用于比对：转绝对路径、小写、反斜杠、去尾部斜杠。

    必须用 abspath —— psutil 句柄表里是绝对路径，相对路径目标永远匹配不上。
    """
    p = os.path.normpath(os.path.abspath(path)).replace('/', '\\').lower()
    return p[:-1] if len(p) > 1 and p.endswith('\\') else p


def _paths_match(handle_path: str, target: str) -> bool:
    """判断进程打开的句柄路径是否命中目标（文件=精确，目录=其下任意文件）。"""
    hp = _norm_path_for_match(handle_path)
    tp = _norm_path_for_match(target)
    return hp == tp or hp.startswith(tp + '\\')


# 枚举打开文件时会导致 psutil 原生崩溃（访问违例）的进程名，子进程枚举时跳过
_CRASH_SKIP_NAMES = {'wudfhost.exe'}

# 子进程枚举脚本（路径经 argv 传入，不拼进代码）：逐个进程匹配，
# 每命中一个进程立即输出一行 JSON 并 flush —— 子进程中途崩溃时父进程仍可得部分结果
_LOCK_PROBE_CODE = r"""
import json, os, sys
try:
    import psutil
except ImportError:
    sys.exit(0)

def norm(p):
    p = os.path.normpath(os.path.abspath(p)).replace('/', '\\').lower()
    return p[:-1] if len(p) > 1 and p.endswith('\\') else p

target = norm(sys.argv[1])
skip = {'wudfhost.exe'}
for proc in psutil.process_iter():
    try:
        if proc.pid in (0, 4):
            continue
        if proc.name().lower() in skip:
            continue
        n = 0
        for f in proc.open_files():
            hp = norm(f.path)
            if hp == target or hp.startswith(target + '\\'):
                n += 1
        if n:
            print(json.dumps({'pid': proc.pid, 'name': proc.name(), 'handles': n},
                             ensure_ascii=False), flush=True)
    except Exception:
        continue
"""


def _find_lockers_subprocess(path: str):
    """子进程隔离枚举锁定者（防 WUDFHost 等受保护进程引发的原生崩溃）。

    Returns:
        (lockers: [dict], partial: bool)  partial=True 表示子进程异常退出、结果可能不全
    """
    try:
        r = subprocess.run(
            [sys.executable, '-c', _LOCK_PROBE_CODE, path],
            capture_output=True, text=True, timeout=90,
        )
    except subprocess.TimeoutExpired:
        return [], True
    except Exception:  # noqa: BLE001
        return [], True

    lockers: List[Dict] = []
    for line in (r.stdout or '').splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            d = json.loads(line)
        except ValueError:
            continue
        if isinstance(d, dict) and 'pid' in d:
            lockers.append(d)
    return lockers, r.returncode != 0


def find_locking_processes(path: str) -> Dict:
    """找出正持有目标文件/目录句柄的进程（"谁锁着它"）。

    用 psutil 枚举各进程打开的文件并做路径匹配（psutil 在 Windows 内部走
    NtQuerySystemInformation + NtQueryObject，已处理内核细节；psutil 已在
    requirements.txt 中）。枚举在**子进程**中执行以隔离原生崩溃
    （实测 WUDFHost.exe 等受保护进程会使 psutil 触发访问违例、连累宿主进程），
    子进程每命中一个进程即输出一行 JSON，崩溃时父进程仍收取部分结果。
    无 psutil 时优雅降级报错。

    Returns:
        {"ok": bool, "path": str, "locked": bool, "partial": bool,
         "lockers": [{"pid": int, "name": str, "handles": int}, ...],
         "method": str, "error": str}
    """
    result = {
        'ok': False,
        'path': path,
        'locked': False,
        'lockers': [],
        'partial': False,
        'method': 'subprocess(psutil)',
        'error': '',
    }
    if os.name != 'nt':
        result['error'] = '仅支持 Windows'
        return result
    if not os.path.exists(path):
        result['error'] = f'路径不存在: {path}'
        return result
    try:
        import psutil  # noqa: F401  预检：子进程需要同一解释器可用 psutil
    except ImportError:
        result['error'] = '需要 psutil 才能枚举锁定进程（pip install psutil）'
        return result

    lockers, partial = _find_lockers_subprocess(path)
    lockers.sort(key=lambda x: x.get('pid', 0))
    result['lockers'] = lockers
    result['partial'] = partial
    if partial:
        result['note'] = '子进程枚举被中断（某受保护进程使其崩溃），锁定者列表可能不完整'
    result['locked'] = bool(lockers)
    result['ok'] = True
    return result


def kill_locking_processes(path: str) -> Dict:
    """终止持有目标句柄的进程（事件响应 / 授权渗透场景，破坏性操作）。

    保护：绝不终止 PID 0/4（Idle/System）与当前自身进程。
    成功与否按 taskkill 退出码判断，不受系统语言影响。

    Returns:
        {"ok": bool, "path": str,
         "killed": [{pid,name,handles}], "failed": [{..., reason}]}
    """
    result = {'ok': False, 'path': path, 'killed': [], 'failed': []}
    if os.name != 'nt':
        result['error'] = '仅支持 Windows'
        return result
    locks = find_locking_processes(path)
    if not locks.get('lockers'):
        result['ok'] = True
        result['note'] = '未发现锁定进程（可能已释放，或需要管理员权限看到全部句柄）'
        return result

    own_pid = os.getpid()
    for l in locks['lockers']:
        pid = l['pid']
        if pid in (0, 4) or pid == own_pid:
            result['failed'].append(dict(l, reason='受保护：System/Idle/当前进程，拒绝终止'))
            continue
        out = _run(['taskkill', '/F', '/PID', str(pid)], timeout=20)
        if out['rc'] == 0:
            result['killed'].append(l)
        else:
            reason = (out['stderr'] or out['error']).strip() or f"taskkill rc={out['rc']}"
            result['failed'].append(dict(l, reason=reason))
    result['ok'] = not result['failed']
    return result


# ─────────────────────────── VSS 卷影读取（绕过进程锁）───────────────────────────
# 卷影 GUID 形如 {8-4-4-4-12 位十六进制}
_SHADOW_GUID_RE = re.compile(
    r'\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}')


def _vss_create_shadow(drive: str) -> Dict:
    """创建指定卷的卷影快照，返回 {ok, shadow, output, error}。

    drive 形如 'C:'。取输出中最后一个 GUID 作为卷影 ID（vssadmin 先打印
    'shadow copy set: {set}' 再打印 'shadow copy: {shadow}'，后者才是卷影）。
    """
    out = _run(['vssadmin', 'create', 'shadow', '/for=' + drive], timeout=90)
    text = out['stdout'] + '\n' + out['stderr']
    res = {'ok': False, 'shadow': '', 'output': text, 'error': out['error']}
    if out['rc'] != 0:
        res['error'] = res['error'] or f'vssadmin create shadow 失败 (rc={out["rc"]})'
        # 个别精简/沙箱环境 vssadmin 不支持 create shadow（报"无效命令/invalid command"）
        if re.search(r'无效命令|invalid command|unrecognized|not a valid', text, re.I):
            res['error'] = '当前环境 vssadmin 不支持 create shadow（VSS 服务不可用或被禁用）'
        return res
    guids = _SHADOW_GUID_RE.findall(text)
    if not guids:
        res['error'] = res['error'] or '未能从 vssadmin 输出解析卷影 GUID'
        return res
    res['shadow'] = guids[-1]
    res['ok'] = True
    return res


def _vss_install_location(shadow_id: str) -> str:
    """查卷影的 InstallLocation（如 \\?\\GLOBALROOT\\Device\\HarddiskVolumeShadowCopyN）。

    WMI 的 Id 属性是否带花括号随版本而异 —— 两侧都去括号再比较，稳妥。
    """
    sid = shadow_id.replace('{', '').replace('}', '')
    ps = (
        "$id='%s'; "
        "$s = Get-CimInstance Win32_ShadowCopy | "
        "Where-Object { ($_.Id -replace '[{}]') -eq $id } | "
        "Select-Object -ExpandProperty InstallLocation"
    ) % sid
    out = _run(['powershell', '-NoProfile', '-NonInteractive', '-Command', ps], timeout=60)
    text = (out['stdout'] or '').strip()
    if not text:
        return ''
    return text.splitlines()[-1].strip()


def read_via_vss(path: str, dest: Optional[str] = None) -> Dict:
    """通过 VSS 卷影复制读出被进程锁定的文件内容（不终止锁定进程、不重启）。

    原理：对目标文件所在卷创建卷影快照，从快照路径
    （\\?\\GLOBALROOT\\...ShadowCopyN\\<相对路径>）读取文件——快照不经过在线文件
    的共享锁检查，因此即使文件被 Share=NONE 独占锁住也能读出。这是杀软/IR 工具
    分析被锁恶意文件的标准手法。无论成败，结束都会删除本次创建的卷影（不动系统
    还原点/其他卷影）。

    注意：
      - 需要管理员权限，且系统 VSS 服务可用（个别精简/沙箱环境不支持，会优雅降级）。
      - 若目标木马主动保护 VSS（阻止创建/删除快照），本方法会失败；此时应改用
        离线启动（WinPE/安全模式）读取。
      - 读出的是创建快照时刻的文件内容（快照只读）。

    Args:
        path: 被锁定的目标文件
        dest: 读出文件保存位置（默认在原文件旁加 .vss 后缀）

    Returns:
        {
            "ok": bool, "path": str, "dest": str,
            "shadow": str, "snapshot_path": str,
            "size": int, "verified": bool,
            "stage": str, "error": str, "vssadmin_output": str
        }
        stage 标出失败阶段: platform/exists/drive/create_shadow/install_location/
        snapshot_path/copy/verify
    """
    result = {
        'ok': False,
        'path': path,
        'dest': '',
        'shadow': '',
        'snapshot_path': '',
        'size': 0,
        'verified': False,
        'stage': '',
        'error': '',
        'vssadmin_output': '',
    }

    if os.name != 'nt':
        result['stage'] = 'platform'
        result['error'] = '仅支持 Windows（VSS 为系统功能）'
        return result

    if not path or not os.path.isfile(path):
        result['stage'] = 'exists'
        result['error'] = f'目标文件不存在或不是文件: {path}'
        return result

    # 必须绝对化再取盘符：相对路径 splitdrive 拿不到盘符（VSS 需要 /for=<盘符>）
    apath = os.path.normpath(os.path.abspath(path))
    dest_abs = os.path.normpath(os.path.abspath(dest)) if dest else (apath + '.vss')
    result['dest'] = dest_abs

    drive = os.path.splitdrive(apath)[0]  # 'C:'
    if not drive:
        result['stage'] = 'drive'
        result['error'] = '无法确定目标文件所在卷（非本地盘符路径？VSS 仅支持本地卷）'
        return result

    # ── 1) 创建卷影 ──
    c = _vss_create_shadow(drive)
    result['vssadmin_output'] = c['output']
    if not c['ok']:
        result['stage'] = 'create_shadow'
        result['error'] = c['error']
        return result
    result['shadow'] = c['shadow']

    try:
        # ── 2) 取快照安装位置 ──
        loc = _vss_install_location(c['shadow'])
        if not loc:
            result['stage'] = 'install_location'
            result['error'] = '未能查询到卷影的 InstallLocation（WMI/CIM 查询失败）'
            return result

        # ── 3) 拼快照内文件路径 ──
        drive_root = drive + '\\'
        rel = os.path.relpath(apath, drive_root).replace('/', '\\')
        snap_path = loc.replace('/', '\\').rstrip('\\') + '\\' + rel
        result['snapshot_path'] = snap_path
        if not os.path.exists(snap_path):
            result['stage'] = 'snapshot_path'
            result['error'] = f'快照中找不到该文件: {snap_path}'
            return result

        # ── 4) 从快照读出到 dest ──
        result['stage'] = 'copy'
        try:
            import shutil
            shutil.copyfile(snap_path, dest_abs)
        except Exception as e:  # noqa: BLE001
            # 兜底：cmd copy（对 \\?\ 特殊路径更稳）
            out = _run(['cmd', '/c', 'copy', '/y', snap_path, dest_abs], timeout=120)
            if not os.path.exists(dest_abs):
                result['error'] = (f'从快照拷贝失败: {e} | '
                                   f'{(out.get("stderr") or "").strip()[:120]}')
                return result

        # ── 5) 校验（快照源与读出文件同大小且非空）──
        result['stage'] = 'verify'
        if not os.path.exists(dest_abs):
            result['error'] = '读出后目标文件不存在（拷贝未生效）'
            return result
        try:
            snap_size = os.path.getsize(snap_path)
            dest_size = os.path.getsize(dest_abs)
            result['size'] = dest_size
            result['verified'] = (dest_size > 0 and snap_size == dest_size)
        except OSError:
            result['verified'] = False

        result['ok'] = True
        return result
    finally:
        # 无论成败，删除本次创建的卷影（不动系统还原点/其他卷影）
        _run(['vssadmin', 'delete', 'shadow', c['shadow']], timeout=60)


def get_owner(path: str) -> Dict:
    """读取文件/目录的当前所有者（名称 + SID）。

    优先用 PowerShell Get-Acl + NTAccount.Translate（输出稳定、不依赖本地化与管道格式），
    兜底解析 icacls 输出里的 owner 行/SID。

    Returns:
        {"ok": bool, "path": str, "owner_name": str, "owner_sid": str, "error": str}
    """
    result = {
        'ok': False,
        'path': path,
        'owner_name': '',
        'owner_sid': '',
        'error': '',
    }
    if os.name != 'nt':
        result['error'] = '仅支持 Windows'
        return result
    if not os.path.exists(path):
        result['error'] = f'路径不存在: {path}'
        return result

    path = _winpath(path)  # icacls/PowerShell 虽都接受正斜杠，统一反斜杠保持一致

    # ── 首选：PowerShell Get-Acl + NTAccount.Translate（一次拿到 name 和 SID）──
    ps_path = path.replace("'", "''")  # PowerShell 单引号转义
    # 注意：用 replace 而非 str.format，避免吞掉 PowerShell 的 {0}/{1} 占位符
    ps_cmd = (
        "$o=(Get-Acl '__PS_PATH__').Owner; "
        "$nt=[System.Security.Principal.NTAccount]$o; "
        "'{0}|{1}' -f $nt.Value, $nt.Translate([System.Security.Principal.SecurityIdentifier]).Value"
    ).replace('__PS_PATH__', ps_path)
    out = _run(['powershell', '-NoProfile', '-NonInteractive', '-Command', ps_cmd], timeout=60)
    if out['rc'] == 0 and out['stdout'].strip():
        first = out['stdout'].strip().splitlines()[0].strip()
        if '|' in first:
            name, sid = first.split('|', 1)
            result['owner_name'] = name.strip()
            result['owner_sid'] = sid.strip()
            if result['owner_name']:
                result['ok'] = True
                return result
        elif first:
            result['owner_name'] = first
            result['ok'] = True
            return result
    elif out['error']:
        result['error'] = out['error']

    # ── 兜底：icacls owner 行 ──
    out = _run(['icacls', path])
    text = out['stdout'] + '\n' + out['stderr']
    owner_line = ''
    for line in text.splitlines():
        if 'owner' in line.lower() or '所有者' in line:
            owner_line = line
            break
    m = _SID_RE.search(owner_line or text)
    if m:
        sid = m.group(1)
        result['owner_sid'] = sid
        result['owner_name'] = _KNOWN_SIDS.get(sid, sid)
        if owner_line and ':' in owner_line:
            name_part = owner_line.split(':', 1)[-1].strip()
            if name_part and not _SID_RE.match(name_part):
                result['owner_name'] = name_part
        result['ok'] = True
        return result

    if not result['owner_name']:
        result['error'] = result['error'] or '无法获取所有者（PowerShell/icacls 均失败）'
    return result


def _is_blocked(path: str) -> Optional[str]:
    """安全门控：判断路径是否属于禁止直接接管的系统/根目录。"""
    p = os.path.normpath(path).lower()
    if p in _BLOCKED_PATHS:
        return f'路径 {path} 是系统/盘根目录，禁止直接接管。请指定具体子路径。'
    # 形如 "c:" / "c:/" 的裸盘符
    if re.fullmatch(r'[a-z]:\\?/?', p):
        return f'路径 {path} 是盘符根目录，禁止直接接管。请指定具体子路径。'
    return None


def take_ownership(
    path: str,
    recursive: bool = True,
    owner: str = 'Administrators',
    grant_full_control: bool = True,
    on_lock: str = 'report',
) -> Dict:
    """接管文件/文件夹所有权（可选递归），并可授权 Everyone+Administrators 完整控制。

    Args:
        path: 目标文件/目录
        recursive: 目录是否递归接管
        owner: 新所有者（默认 Administrators 组；也可传用户名）
        grant_full_control: 是否额外 icacls 授权 Everyone + Administrators
        on_lock: 接管失败且检测到锁定进程时的动作 —
            'report'（默认）只报告锁定者；'kill' 终止锁定进程后自动重试一次

    Returns:
        {
            "ok": bool, "path": str, "recursive": bool, "owner": str,
            "owner_before": {...}, "owner_after": {...},
            "takeown_rc": int, "icacls_rc": int, "errors": [..], "admin": bool,
            "locked": bool, "lockers": [{pid,name,handles}],
            "kill_result": {...}, "retried_after_kill": bool
        }
    """
    if on_lock not in ('report', 'kill'):
        on_lock = 'report'
    result = {
        'ok': False,
        'path': path,
        'recursive': recursive,
        'owner': owner,
        'on_lock': on_lock,
        'owner_before': {},
        'owner_after': {},
        'takeown_rc': None,
        'icacls_rc': None,
        'errors': [],
        'admin': False,
        'locked': False,
        'lockers': [],
    }

    # ── 平台守卫 ──
    if os.name != 'nt':
        result['errors'].append('仅支持 Windows（takeown/icacls 为系统内置工具）')
        return result

    result['admin'] = check_admin()

    # ── 路径检查 ──
    if not path or not os.path.exists(path):
        result['errors'].append(f'路径不存在: {path}')
        return result

    blocked = _is_blocked(path)
    if blocked:
        result['errors'].append(blocked)
        return result

    # 统一反斜杠：takeown 不识别正斜杠路径（实测）；result['path'] 保留原始入参用于展示
    path = _winpath(path)

    # ── 记录 owner_before ──
    result['owner_before'] = get_owner(path)

    is_dir = os.path.isdir(path)

    # ── takeown ──
    take_cmd = ['takeown', '/f', path]
    if recursive and is_dir:
        take_cmd.append('/r')
        # /d（默认应答）仅允许与 /r 同用；单文件场景带上会报 "/D 只能与 /R 一起指定"
        take_cmd += ['/d', 'y']
    if owner.lower() in ('administrators', 'builtin\\administrators'):
        take_cmd.append('/a')  # 所有者设为 Administrators 组
    else:
        take_cmd += ['/user', owner]

    logger.info(f'takeown: {" ".join(take_cmd)}')
    take_out = _run(take_cmd)
    result['takeown_rc'] = take_out['rc']

    # ── 接管失败：定位锁定进程；on_lock='kill' 时终止锁定者后自动重试一次 ──
    if take_out['rc'] != 0:
        locks = find_locking_processes(path)
        if locks.get('locked'):
            result['locked'] = True
            result['lockers'] = locks['lockers']
            logger.info(f"目标被进程锁定: {locks['lockers']}")
            if on_lock == 'kill':
                kr = kill_locking_processes(path)
                result['kill_result'] = kr
                if kr.get('killed'):
                    time.sleep(1.0)  # 等待句柄释放
                    logger.info('已终止锁定进程，重试 takeown')
                    take_out = _run(take_cmd)
                    result['takeown_rc'] = take_out['rc']
                    result['retried_after_kill'] = True

    if take_out['rc'] != 0:
        msg = take_out['error'] or take_out['stderr'].strip() or f"takeown rc={take_out['rc']}"
        if not result['admin']:
            msg += '（提示：当前进程未提权，请以管理员身份运行）'
        if result['locked']:
            names = ', '.join(f"{l['name']} (pid {l['pid']})" for l in result['lockers'])
            if on_lock == 'kill':
                msg += f'（锁定进程 {names} 已尝试终止但接管仍失败，详见 kill_result；' \
                       '进程可能被服务守护自动拉起）'
            else:
                msg += f'（注意：目标正被进程 {names} 锁定。锁通常不阻挡接管本身，' \
                       '此失败可能与锁定者有关；如还需读写文件内容，' \
                       '可用 --kill-lockers 终止锁定者或手动关闭对应程序）'
        result['errors'].append(msg)
        # takeown 失败仍尝试记录 after（可能部分成功）
        result['owner_after'] = get_owner(path)
        result['ok'] = False
        return result

    # ── icacls 授权（对应原工具 SetEntriesInAcl: Everyone + Administrators）──
    if grant_full_control:
        ica_cmd = ['icacls', path, '/grant', 'Everyone:F', '/grant', 'Administrators:F']
        if recursive and is_dir:
            ica_cmd.append('/t')
        logger.info(f'icacls: {" ".join(ica_cmd)}')
        ica_out = _run(ica_cmd)
        result['icacls_rc'] = ica_out['rc']
        if ica_out['rc'] != 0:
            msg = ica_out['error'] or ica_out['stderr'].strip() or f"icacls rc={ica_out['rc']}"
            if not result['locked']:
                # 诊断线索：锁通常不阻挡授权，但锁定者可能是失败关联因素
                locks = find_locking_processes(path)
                if locks.get('locked'):
                    result['locked'] = True
                    result['lockers'] = locks['lockers']
                    names = ', '.join(f"{l['name']} (pid {l['pid']})" for l in locks['lockers'])
                    msg += f'（注意：目标正被进程 {names} 锁定，关闭对应程序后再重试授权）'
            result['errors'].append(msg)

    # ── 记录 owner_after ──
    result['owner_after'] = get_owner(path)

    result['ok'] = len(result['errors']) == 0
    if not result['admin']:
        # 未提权但操作成功（目标本就属于自己）仍算成功，仅提示
        logger.warning('当前进程未以管理员提权，部分受保护文件可能未被接管')
    return result


def main():
    parser = argparse.ArgumentParser(
        description='Windows 文件/文件夹所有权接管 + 授权 (TakeOwnershipPro 移植)',
    )
    parser.add_argument('path', help='目标文件或目录路径')
    parser.add_argument('--recursive', action='store_true', default=True,
                        help='目录递归接管（默认开启）')
    parser.add_argument('--no-recursive', dest='recursive', action='store_false',
                        help='不递归')
    parser.add_argument('--owner', default='Administrators',
                        help='新所有者（默认 Administrators 组）')
    parser.add_argument('--no-grant', dest='grant_full_control', action='store_false',
                        default=True, help='不额外 icacls 授权')
    parser.add_argument('--list-locks', action='store_true',
                        help='只列出锁定该文件/目录的进程，不执行接管')
    parser.add_argument('--kill-lockers', action='store_true',
                        help='接管失败且被进程锁定时：终止锁定进程后自动重试（破坏性操作，慎用）')
    parser.add_argument('--read-vss', action='store_true',
                        help='通过 VSS 卷影复制读出被锁定文件的内容（不接管、不终止锁定进程；'
                             '需管理员且系统 VSS 可用）')
    parser.add_argument('--dest', default=None,
                        help='--read-vss 的输出路径（默认：原文件路径 + .vss 后缀）')
    args = parser.parse_args()

    if args.read_vss:
        result = read_via_vss(args.path, dest=args.dest)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result['ok'] else 1)

    if args.list_locks:
        result = find_locking_processes(args.path)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(0 if result['ok'] else 1)

    result = take_ownership(
        path=args.path,
        recursive=args.recursive,
        owner=args.owner,
        grant_full_control=args.grant_full_control,
        on_lock='kill' if args.kill_lockers else 'report',
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result['ok'] else 1)


if __name__ == '__main__':
    main()
