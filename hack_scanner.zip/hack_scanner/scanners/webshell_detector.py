#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WebShell Detector — 通过特征匹配检测 Webshell（后门文件）。

适用于：扫描上传目录、备份目录、CMS 安装包的 webshell 检测。

支持的语言/模式：
- PHP (eval/assert/system/passthru/shell_exec + $_POST/$_GET)
- ASP/ASPX (System.Diagnostics + Request.Form)
- JSP (Runtime.exec + request.getParameter)
- Python (os.system + exec/eval)
- Perl (system/exec/backtick)

Usage:
    from scanners.webshell_detector import detect_webshells
    result = detect_webshells("/path/to/upload_dir/")
"""

import json
import logging
import os
import re
from typing import Dict, List, Optional
from dataclasses import dataclass

logger = logging.getLogger('webshell_detector')

# ── Webshell 特征模式 ──
WEB_SHELL_PATTERNS = {
    # PHP webshells
    'PHP - eval + base64': re.compile(r'\beval\s*\(\s*(base64_decode|string_rot13)\s*\(', re.IGNORECASE),
    'PHP - assert + eval': re.compile(r'\bassert\s*\(\s*\$\w+\s*\)', re.IGNORECASE),
    'PHP - system/passthru/shell_exec': re.compile(r'\b(system|passthru|shell_exec|popen|proc_open)\s*\(\s*(\$_(GET|POST|REQUEST|COOKIE)|\$argv|\$args)', re.IGNORECASE),
    'PHP - preg_replace /e modifier': re.compile(r'\bpreg_replace\s*\(\s*["\'].*?/e', re.IGNORECASE),
    'PHP - create_function (deprecated eval)': re.compile(r'\bcreate_function\s*\(', re.IGNORECASE),
    'PHP - extract() + variable variables': re.compile(r'\bextract\s*\(\s*\$_(GET|POST)', re.IGNORECASE),
    'PHP - file_get_contents + POST': re.compile(r'\bfile_get_contents\s*\(\s*["\']php://input', re.IGNORECASE),
    'PHP - fwrite/fputs + POST': re.compile(r'\b(fwrite|fputs)\s*\(\s*(\$?\w+)\s*,\s*\$_(POST|GET)', re.IGNORECASE),

    # ASP/ASPX webshells
    'ASP - eval + request': re.compile(r'<\s*%\s*@.*?eval\s*\(\s*Request', re.IGNORECASE),
    'ASPX - System.Diagnostics': re.compile(r'System\.Diagnostics\.Process\s*\.\s*(Start|CreateProcess)', re.IGNORECASE),
    'ASP - Server.Execute': re.compile(r'Server\s*\.\s*Execute\s*\(', re.IGNORECASE),

    # JSP webshells
    'JSP - Runtime.exec': re.compile(r'Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*exec\s*\(\s*request\.getParameter', re.IGNORECASE),
    'JSP - ProcessBuilder + request': re.compile(r'ProcessBuilder\s*\([^)]*\).*?request\.getParameter', re.IGNORECASE),

    # Python webshells
    'Python - os.system + input': re.compile(r'\bos\s*\.\s*system\s*\(\s*(request|input|\$_)', re.IGNORECASE),
    'Python - exec + eval combination': re.compile(r'\bexec\s*\(\s*eval\s*\(', re.IGNORECASE),

    # Perl webshells
    'Perl - system/backtick': re.compile(r'\b(system|backtick)\s*\(\s*\$ENV|\$\w+\s*\)', re.IGNORECASE),

    # Generic suspicious patterns
    'Generic - base64_decode + eval': re.compile(r'(base64_decode|gzinflate|gzuncompress|str_rot13)\s*.*?\beval\b', re.IGNORECASE),
    'Generic - data:// protocol': re.compile(r'data://\w+/\w+', re.IGNORECASE),
    'Generic - filter/allow_url_include': re.compile(r'(allow_url_include|allow_url_fopen)\s*=\s*true', re.IGNORECASE),
}

# Webshell 文件名特征
WEB_SHELL_FILES = [
    r'\b(c99|r57|b374k|wso|milw0rm|phpspy)_shell\.php\b',
    r'\bwso\d?\.php\b',
    r'\bspY\s*shell.*\.php\b',
    r'\bcmd\.php\b',
    r'\bupload.*\.(php|asp|jsp|aspx)\b',
    r'\badmin.*file.*\.php\b',
    r'\b(?:shell|backdoor|webshell|web\s*shell|rev).*\.(php|asp|jsp|aspx)\b',
]


@dataclass
class ShellFinding:
    file_path: str
    pattern_name: str
    line_number: int
    severity: str
    evidence: str

    def to_dict(self):
        return {
            "file": self.file_path,
            "pattern": self.pattern_name,
            "line": self.line_number,
            "severity": self.severity,
            "evidence": self.evidence[:500],
        }


def scan_file(file_path: str) -> List[ShellFinding]:
    """扫描单个文件中的 webshell 特征。"""
    findings = []

    try:
        with open(file_path, 'r', errors='ignore') as f:
            lines = f.readlines()
    except Exception as e:
        return findings

    if len(lines) > 50000:
        return findings  # Skip very large files

    content_lower = ''.join(lines).lower()

    # Check filenames first
    basename = os.path.basename(file_path).lower()
    for pattern_str in WEB_SHELL_FILES:
        if re.search(pattern_str, basename):
            findings.append(ShellFinding(
                file_path=file_path,
                pattern_name="suspicious_filename",
                line_number=0,
                severity="critical",
                evidence=f"文件名包含 Webshell 特征: {basename}",
            ))

    for i, line in enumerate(lines[:5000], 1):
        for name, pattern in WEB_SHELL_PATTERNS.items():
            match = pattern.search(line)
            if match:
                severity = "critical" if any(kw in name.lower() for kw in ['eval', 'system', 'shell_exec', 'exec']) else "high"
                findings.append(ShellFinding(
                    file_path=file_path,
                    pattern_name=name,
                    line_number=i,
                    severity=severity,
                    evidence=line.strip()[:200],
                ))

    return findings


def detect_webshells(scan_path: str) -> dict:
    """递归扫描目录中的 webshell。

    Args:
        scan_path: 要扫描的文件或目录路径

    Returns:
        {
            "ok": True,
            "total_files_scanned": N,
            "webshells_found": N,
            "findings": [...],
            "error": ""
        }
    """
    all_findings = []
    total_scanned = 0

    if os.path.isfile(scan_path):
        files_to_scan = [scan_path]
    elif os.path.isdir(scan_path):
        # Collect files (focus on code/config files)
        valid_extensions = {'.php', '.asp', '.aspx', '.jsp', '.py', '.pl', '.cgi', '.sh',
                          '.inc', '.config', '.htaccess', '.env', '.xml'}
        files_to_scan = []
        for root, dirs, fnames in os.walk(scan_path):
            # Skip hidden directories and common non-target dirs
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for fname in fnames:
                ext = os.path.splitext(fname)[1].lower()
                if ext in valid_extensions or len(ext) == 0:  # Extensionsless files too
                    full_path = os.path.join(root, fname)
                    try:
                        if os.path.getsize(full_path) < 5 * 1024 * 1024:  # Skip >5MB
                            files_to_scan.append(full_path)
                    except OSError:
                        pass
    else:
        return {"ok": False, "error": f"路径不存在: {scan_path}"}

    for file_path in files_to_scan:
        total_scanned += 1
        findings = scan_file(file_path)
        all_findings.extend(findings)

    critical_count = sum(1 for f in all_findings if f.severity == "critical")
    high_count = sum(1 for f in all_findings if f.severity == "high")

    return {
        "ok": True,
        "total_files_scanned": total_scanned,
        "webshells_found": len(all_findings),
        "critical": critical_count,
        "high": high_count,
        "findings": [f.to_dict() for f in all_findings[:100]],
        "error": "",
    }
