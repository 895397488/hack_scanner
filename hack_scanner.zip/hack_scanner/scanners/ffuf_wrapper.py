#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FFUF Wrapper — ffuf CLI wrapper，目录爆破备选引擎（gobuster 同位，可切换）。

ffuf 由 Go 编写、速度快，相比 gobuster 的额外能力：
- 模糊匹配（-fs length / -fs hash:xx）—— 对 WAF 统一响应码场景更准
- VHost/DNS 模式（virtual host / dns）
- 自定义 header / cookie / 请求体

与 gobuster_wrapper 同位：目标 URL 爆破选 gobuster 或 ffuf 其一即可。

集成方式：需要安装 ffuf
  - Windows: choco install ffuf  或  https://github.com/ffuf/ffuf/releases
  - Linux:   apt install ffuf
本模块只负责 CLI 调用和结果解析。config.json → tools.ffuf_path 可指定路径。

Usage:
    from scanners.ffuf_wrapper import ffuf_dir, ffuf_vhost, ffuf_dns
    result = ffuf_dir("https://example.com", wordlist="common.txt")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('ffuf_scanner')


def _find_ffuf() -> Optional[str]:
    """查找 ffuf 可执行文件：先 config.json → tools.ffuf_path，再 PATH"""
    # 1) config.json tools.ffuf_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("ffuf_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["ffuf", "ffuf.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_ffuf_dir(output: str, base_url: str = "") -> list:
    """解析 ffuf dir 模式输出。

    ffuf 关键行格式:
      admin            [Status: 200, Size: 4567, Words: 10, Lines: 2]
      /admin           [Status: 301, ...]
    （行首是路径，后跟 [Status: N, Size: N, ...]）
    """
    findings = []
    for line in output.splitlines():
        line = line.strip()
        if "Status:" not in line or not line:
            continue
        m = re.match(r'^(\S+)\s+\[Status:\s*(\d+)', line)
        if not m:
            continue
        path = m.group(1)
        status = m.group(2)
        size_m = re.search(r'Size:\s*(\d+)', line)
        size = int(size_m.group(1)) if size_m else 0

        url = path if path.startswith("http") else f"{base_url.rstrip('/')}/{path.lstrip('/')}"
        code = int(status)
        severity = "medium" if code in (200, 201, 403, 401, 500) else "info"

        findings.append({
            "url": url,
            "path": path,
            "status": status,
            "size": size,
            "severity": severity,
        })
    return findings


def ffuf_dir(
    target_url: str,
    wordlist: str = "",
    threads: int = 40,
    extensions: str = "",
    fuzzy_match: str = "",
    max_time: int = 300,
) -> dict:
    """ffuf 目录/文件爆破。

    Args:
        target_url: 目标 URL（如 https://example.com/，{FUZZ} 占位符会自动加）
        wordlist: 字典文件路径
        threads: 并发数
        extensions: 扩展名（如 php,html,jsp）
        fuzzy_match: 模糊匹配（如 "403,512" 按长度/hash 匹配，绕过统一响应码 WAF）
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "findings": [...], "findings_count": N, "error": ""}
    """
    ffuf_path = _find_ffuf()
    if not ffuf_path:
        return {
            "ok": False,
            "target_url": target_url,
            "findings": [],
            "findings_count": 0,
            "error": "ffuf 未找到，请安装: choco install ffuf (Windows) 或 apt install ffuf (Linux)",
        }

    if not wordlist or not os.path.isfile(wordlist):
        return {"ok": False, "target_url": target_url, "findings": [], "findings_count": 0,
                "error": "未找到字典，请指定 wordlist 参数（文件路径）"}

    url = target_url.rstrip("/")
    if "{FUZZ}" not in url:
        url = f"{url}/{{FUZZ}}"

    cmd = [
        ffuf_path,
        "-u", url,
        "-w", wordlist,
        "-t", str(threads),
        "-mc", "200,201,204,301,302,307,401,403,500",  # 匹配的 status code
        "-timeout", "10",
    ]
    if extensions:
        cmd.extend(["-e", extensions])
    if fuzzy_match:
        cmd.extend(["-fs", fuzzy_match])

    logger.info(f"ffuf dir: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""
        findings = _parse_ffuf_dir(output, target_url)

        return {
            "ok": True,
            "target_url": target_url,
            "findings": findings[:500],
            "findings_count": len(findings),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target_url": target_url, "findings": [], "findings_count": 0, "error": "ffuf 超时"}


def ffuf_vhost(
    target_host: str,
    wordlist: str = "",
    threads: int = 40,
    max_time: int = 300,
) -> dict:
    """ffuf VHost 模式 — Virtual Host 虚拟主机发现。

    Args:
        target_host: 目标 IP/域名
        wordlist: 虚拟主机名字典
        threads: 并发数
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "vhosts_found": [...], "error": ""}
    """
    ffuf_path = _find_ffuf()
    if not ffuf_path:
        return {"ok": False, "target_host": target_host, "vhosts_found": [], "error": "ffuf 未找到"}

    if not wordlist or not os.path.isfile(wordlist):
        return {"ok": False, "target_host": target_host, "vhosts_found": [],
                "error": "ffuf vhost 需要 wordlist 参数（虚拟主机名字典）"}

    cmd = [
        ffuf_path,
        "-u", target_host,
        "-H", "Host: {FUZZ}",
        "-w", wordlist,
        "-t", str(threads),
        "-mc", "200,301,302,403",
    ]

    logger.info(f"ffuf vhost: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""

        vhosts = []
        for line in output.splitlines():
            m = re.match(r'^(\S+)\s+\[Status:', line.strip())
            if m:
                vhosts.append(m.group(1))

        return {
            "ok": True,
            "target_host": target_host,
            "vhosts_found": vhosts[:200],
            "total_vhosts": len(vhosts),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target_host": target_host, "vhosts_found": [], "error": "ffuf vhost 超时"}


def ffuf_dns(
    domain: str,
    wordlist: str = "",
    threads: int = 40,
    max_time: int = 300,
) -> dict:
    """ffuf DNS 模式 — DNS 子域名枚举。

    Args:
        domain: 根域名（如 example.com）
        wordlist: DNS 字典
        threads: 并发数
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "subdomains_found": [...], "error": ""}
    """
    ffuf_path = _find_ffuf()
    if not ffuf_path:
        return {"ok": False, "domain": domain, "subdomains_found": [], "error": "ffuf 未找到"}

    if not wordlist or not os.path.isfile(wordlist):
        return {"ok": False, "domain": domain, "subdomains_found": [],
                "error": "ffuf dns 需要 wordlist 参数（DNS 字典）"}

    # ffuf 无原生 DNS 协议探测，这里用子域拼接 + Host 头探测（等价于 vhost 枚举）
    cmd = [
        ffuf_path,
        "-u", f"https://{{FUZZ}}.{domain}",
        "-H", "Host: {FUZZ}",
        "-w", wordlist,
        "-t", str(threads),
        "-mc", "200,301,302,403",
    ]

    logger.info(f"ffuf dns: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""

        subdomains = []
        for line in output.splitlines():
            m = re.match(r'^(\S+)\s+\[Status:', line.strip())
            if m:
                word = m.group(1)
                # 输出是 FUZZ 单词（如 admin），拼回完整子域
                sub = word if "." in word and word.endswith(domain) else f"{word}.{domain}"
                if sub != domain:
                    subdomains.append(sub)

        return {
            "ok": True,
            "domain": domain,
            "subdomains_found": list(set(subdomains))[:500],
            "total_subdomains": len(set(subdomains)),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "domain": domain, "subdomains_found": [], "error": "ffuf dns 超时"}
