#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GraphQL Security Detector
===========================
借鉴 Pentest-Swarm-AI Phase 5.5 (GraphQL introspection, batching, depth attacks).
检测 GraphQL 端点的常见安全漏洞。
"""

import re
import json
import logging
import requests as req
from typing import List, Dict, Optional
from urllib.parse import urlparse


def _cfg():
    """Lazy access to CONFIG from caller's global scope."""
    try:
        import hack_scanner as hs
        if hasattr(hs, 'CONFIG'):
            return hs.CONFIG
    except ImportError:
        pass
    try:
        import url_scanner as us
        if hasattr(us, 'CONFIG'):
            return us.CONFIG
    except ImportError:
        pass
    return None

logger = logging.getLogger('graphql_detector')


class GraphQLSecurityDetector:
    """GraphQL 安全检测器 — introspection / batching / depth / field-suggestion"""

    # Common GraphQL endpoint paths
    GRAPHQL_PATHS = [
        '/graphql', '/graphiql', '/api/graphql', '/gql', '/query',
        '/altair', '/playground', '/apollo', '/synthetics/trigger-graphql',
        '/v1/graphql', '/v2/graphql', '/.well-known/apitraveler',
        'graphql.php', 'graphql.php',
    ]

    # Known introspection fields
    INTROSPECTION_QUERY = '''
        query {
            __schema {
                queryType { name }
                types { name kind fields { name args { name type { name } } } }
            }
        }
    '''

    # Batching attack (alias-based DoS)
    BATCHING_QUERY = '''
        query {
            a: __typename
            b: __typename
            c: __typename
            d: __typename
            e: __typename
            f: __typename
            g: __typename
            h: __typename
            i: __typename
            j: __typename
            k: __typename
            l: __typename
            m: __typename
            n: __typename
            o: __typename
            p: __typename
        }
    '''

    @staticmethod
    def detect(url: str, page_content: str = "") -> List[Dict]:
        """检测 GraphQL 安全漏洞"""
        findings = []
        parsed = urlparse(url)

        # Discover GraphQL endpoints (from URL params and common paths)
        graphql_targets = []

        # Check if URL itself looks like a GraphQL endpoint
        graphql_keywords = ['graphql', 'gql', 'graphiql', 'playground']
        for kw in graphql_keywords:
            if kw in parsed.path.lower():
                graphql_targets.append(url)
                break

        # Check URL params for GraphQL hints
        if parsed.query:
            if any(kw in parsed.query.lower() for kw in ['query=', 'operationName']):
                graphql_targets.append(url)

        # Add common paths to test
        base_url = f"{parsed.scheme}://{parsed.netloc}"
        for path in GraphQLSecurityDetector.GRAPHQL_PATHS:
            candidate = f"{base_url}{path}"
            if candidate not in graphql_targets:
                graphql_targets.append(candidate)

        # Also search page content for GraphQL hints
        if page_content:
            gql_patterns = [
                r'["\'](/graphql)["\']',
                r'["\'](/api/graphql)["\']',
                r'["\'](/gql)["\']',
                r'graphql\s*[:=]\s*["\']',
                r'subscribeToMore\(',
                '__typename',
            ]
            for pattern in gql_patterns:
                if re.search(pattern, page_content):
                    logger.info(f"  GraphQL: Content hints found on {url}")
                    break

        # Test each discovered target
        endpoints_found = set()
        for target_url in graphql_targets:
            result = GraphQLSecurityDetector._test_endpoint(target_url)
            if result and result['endpoint'] not in endpoints_found:
                endpoints_found.add(result['endpoint'])
                findings.append(result)

        return findings

    @staticmethod
    def _test_endpoint(url: str) -> Optional[Dict]:
        """测试单个 GraphQL 端点"""
        import requests as req

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': _cfg()['scanner'].get('user_agent', 'Mozilla/5.0'),
        }

        results = {}

        # 1. Introspection endpoint exposure (A07:2021)
        try:
            resp = req.post(
                url,
                json={'query': GraphQLSecurityDetector.INTROSPECTION_QUERY},
                headers=headers,
                timeout=_cfg()['scanner']['timeout'],
            )

            if resp.status_code == 200 and ('__schema' in resp.text or '__type' in resp.text):
                try:
                    data = resp.json()
                    schema_types = []
                    if 'data' in data and '__schema' in data.get('data', {}):
                        schema = data['data']['__schema']
                        query_type = schema.get('queryType', {})
                        types = schema.get('types', [])
                        schema_types = [t.get('name', '') for t in types[:20] if t.get('name')]
                    results['introspection'] = {
                        'exposed': True,
                        'endpoint': url,
                        'query_count': len(schema_types),
                        'response_sample': resp.text[:1000],
                    }
                except json.JSONDecodeError:
                    results['introspection'] = {'exposed': True, 'endpoint': url}

        except req.RequestException as e:
            logger.debug(f"  GraphQL introspection error on {url}: {e}")

        # 2. Introspection disabled but endpoint exists (still info)
        if not results.get('introspection'):
            try:
                resp = req.post(
                    url,
                    json={'query': '{__schema{queryType{name}}}'},
                    headers=headers,
                    timeout=_cfg()['scanner']['timeout'],
                )
                if resp.status_code == 200:
                    results['introspection'] = {'exposed': False, 'endpoint': url}
            except req.RequestException:
                pass

        # 3. Batching / alias DoS test (A05:2021)
        if results.get('introspection', {}).get('exposed'):
            try:
                resp = req.post(
                    url,
                    json={'query': GraphQLSecurityDetector.BATCHING_QUERY},
                    headers=headers,
                    timeout=_cfg()['scanner']['timeout'],
                )
                if resp.status_code == 200 and '"a"' in resp.text:
                    results['batching'] = {
                        'vulnerable': True,
                        'endpoint': url,
                        'response_time_ms': None,
                    }
            except req.RequestException as e:
                logger.debug(f"  GraphQL batching error on {url}: {e}")

        # Only return findings if we found a working endpoint
        introsp = results.get('introspection', {})
        if not introsp:
            return None

        finding = {
            'id': 'GRAPHQL_INTEGRITY',
            'severity': 'medium' if not introsp.get('exposed') else 'high',
            'title': f"GraphQL 端点安全测试 ({urlparse(url).path})",
            'description': '',
            'url': url,
            'evidence': json.dumps(results, indent=2, ensure_ascii=False)[:2000],
            'recommendation': '',
            'cwe': 'CWE-829',
            'cvss': 7.4 if introsp.get('exposed') else 5.3,
            'graphql_details': results,
        }

        parts = []
        if introsp.get('exposed'):
            parts.append(
                "GraphQL Introspection 已暴露，攻击者可以枚举完整 schema。"
                "可用于发现隐藏字段、未文档化的查询/突变和敏感数据访问点。\n\n"
                "修复: 在 production 环境中禁用 introspection: \n"
                "  SchemaConfig(introspection=False)  # graphql-core\n"
                "  schema.set_introspection_allowed(False)  # Apollo Server"
            )
        else:
            parts.append("GraphQL endpoint exists but introspection appears disabled.")

        batching = results.get('batching', {})
        if batching and batching.get('vulnerable'):
            parts.append(
                "\nBatching Attack 可行: 单个请求可触发16次相同查询。"
                "修复: 实现 query depth limiting 和 alias count limits。"
            )

        finding['description'] = '\n'.join(parts)
        finding['recommendation'] = (
            "1. Production 环境禁用 GraphQL Introspection\n"
            "2. 实施 Query Depth Limit（推荐 max=10）\n"
            "3. 限制 Alias/操作数量（每请求最多 5-10 个）\n"
            "4. 使用 cost-based query analysis (e.g., graphql-cost-analysis)\n"
            "5. 实施 per-user rate limiting\n"
            "6. 移除 GraphQL Playground/Sandbox/GraphiQL 生产环境访问\n"
            "7. 对查询结果字段做权限校验（field-level authorization）\n"
            "8. 防范 field-suggestion 泄露: 禁用 suggestFieldNames on production"
        )

        return finding


class GraphQLEndpointFinder:
    """从 HTML/JS content 中自动发现 GraphQL 端点"""

    @staticmethod
    def find_from_content(url: str, content: str) -> List[str]:
        """从页面内容中提取 GraphQL 端点 URL"""
        found = set()

        # Pattern 1: Direct GraphQL endpoint URLs
        gql_url_patterns = [
            r'["\'](/?graphql[\'\"\s,;])',
            r'["\'](/?api/graphql[\'\"\s,;])',
            r'["\'](/?gql[\'\"\s,;])',
            r'["\'](/?graphiql[\'\"\s,;])',
            r'["\'](/?playground[\'\"\s,;])',
        ]

        for pattern in gql_url_patterns:
            for match in re.finditer(pattern, content):
                endpoint = match.group(0).strip('"\'')
                if endpoint and len(endpoint) > 1:
                    found.add(f"{urlparse(url).scheme}://{urlparse(url).netloc}{endpoint}")

        # Pattern 2: Apollo Client / Relay config
        relay_patterns = [
            r'uri["\']?\s*[:=]\s*["\']([^"\']*graphql[^"\']*)["\']',
            r'endPoint["\']?\s*[:=]\s*["\']([^"\']*graphql[^"\']*)["\']',
        ]

        for pattern in relay_patterns:
            for match in re.finditer(pattern, content):
                endpoint = match.group(1)
                if endpoint.startswith('/'):
                    base = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
                    found.add(base + endpoint)
                elif endpoint.startswith('http'):
                    found.add(endpoint)

        # Pattern 3: Fetch/XHR to GraphQL endpoints
        fetch_patterns = [
            r'[Ff]etch\s*\(\s*["\']([^"\']*graphql[^"\']*)["\']',
            r'[Xx]HR.*?open\s*\([^)]*"POST"[^)]*["\']([^"\']*graphql[^"\']*)["\']',
        ]

        for pattern in fetch_patterns:
            for match in re.finditer(pattern, content):
                endpoint = match.group(1)
                if endpoint.startswith('/'):
                    base = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
                    found.add(base + endpoint)
                elif endpoint.startswith('http'):
                    found.add(endpoint)

        return list(found)
