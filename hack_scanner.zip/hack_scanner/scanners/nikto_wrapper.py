#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nikto Wrapper — Nikto CLI wrapper，Web 服务器基线/配置漏洞扫描。

Nikto 是历史最悠久的 Web 服务器扫描器之一，覆盖：
- 已知危险文件/目录（~root、.htaccess、server-status、phpmyadmin 等）
- 过期软件版本（Apache/nginx/IIS/PHP/Java 等）
- 缺失的安全头 / 信息泄露（Server Header、X-Powered-By）
- 40 余项可配置检查项（-C=all 全量）

集成方式：需要安装 Nikto
  - Windows: choco install nikto  或  https://github.com/sulla/nikto/releases
  - Linux:   apt install nikto
本模块只负责 CLI 调用和结果解析。config.json → tools.nikto_path 可指定路径。

Usage:
    from scanners.nikto_wrapper import nikto_web_scan
    result = nikto_web_scan("https://example.com")
"""

import json
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('nikto_scanner')


def _find_nikto() -> Optional[str]:
    """查找 nikto 可执行文件：先 config.json → tools.nikto_path，再 PATH"""
    # 1) config.json tools.nikto_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("nikto_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["nikto", "nikto.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_nikto_output(output: str) -> list:
    """解析 nikto 文本输出。

    Nikto 关键行格式:
      [-] /test.php: This script may allow remote users to include files...
      [200] /admin/: The admin interface is protected, the content could be revealed.
      [403] /server-status: A special server status page may reveal server information.
      WARNING: No Server Header
    """
    findings = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue

        # WARNING: xxx
        if line.startswith("WARNING:"):
            findings.append({
                "status": "WARN",
                "path": "",
                "description": line[len("WARNING:"):].strip(),
                "severity": "info",
                "type": "warning",
            })
            continue

        # [xxx] /path: description   （xxx = 状态码 或 - 表示已知漏洞）
        if line.startswith("[") and "] " in line:
            bracket_end = line.find("] ")
            status = line[1:bracket_end].strip()
            rest = line[bracket_end + 2:].strip()
            path, _, description = rest.partition(": ")
            path = path.strip()
            description = description.strip()

            # 严重度映射
            if status == "-":
                severity = "high"          # 已知漏洞
            elif status == "200":
                severity = "medium"        # 敏感路径可访问
            else:
                severity = "info"          # 403/301/404 等

            findings.append({
                "status": status,
                "path": path,
                "description": description,
                "severity": severity,
                "type": "vulnerability" if status == "-" else "path",
            })

    return findings


def nikto_web_scan(
    target: str,
    threads: int = 20,
    all_checks: bool = False,
    max_time: int = 600,
) -> dict:
    """运行 Nikto Web 服务器基线扫描。

    Args:
        target: 目标 URL 或 host:port（如 https://example.com 或 192.168.1.1:80）
        threads: 并发线程数
        all_checks: 启用全部 40+ 检查项（含慢速 DoS 类探测，耗时长）
        max_time: 最大运行时间秒

    Returns:
        {
            "ok": True,
            "target": "...",
            "findings": [{"status", "path", "description", "severity", "type"}],
            "findings_count": N,
            "stats": {"high": 0, "medium": 1, "info": 3},
            "error": ""
        }
    """
    nikto_path = _find_nikto()
    if not nikto_path:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "findings_count": 0,
            "error": "Nikto 未找到，请安装: choco install nikto (Windows) 或 apt install nikto (Linux)",
        }

    cmd = [nikto_path, "-h", target, "-t", str(threads)]
    if all_checks:
        cmd.append("-C=all")

    logger.info(f"nikto scan: {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 30)
        output = proc.stdout or proc.stderr or ""
        findings = _parse_nikto_output(output)

        stats = {"high": 0, "medium": 0, "info": 0}
        for f in findings:
            stats[f["severity"]] = stats.get(f["severity"], 0) + 1

        return {
            "ok": True,
            "target": target,
            "findings": findings[:500],
            "findings_count": len(findings),
            "stats": stats,
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "findings_count": 0,
            "error": f"nikto 超时（最大时间 {max_time}s）",
        }
