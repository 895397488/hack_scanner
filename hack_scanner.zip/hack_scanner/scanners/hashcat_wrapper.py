#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hashcat Wrapper — hashcat CLI wrapper，GPU 离线 Hash 破解引擎。

与 hydra(在线爆破) / john(CPU 离线) 互补：
  - hydra  → 在线交互式爆破（SSH/FTP/HTTP）
  - john   → CPU 离线破解（通用）
  - hashcat→ GPU 离线破解（暴力/字典，速度最高）

集成方式：需要安装 hashcat
  - Windows: https://hashcat.net/hashcat/  (含 GPU 支持)
  - Linux:   apt install hashcat
本模块只负责 CLI 调用和结果解析。config.json → tools.hashcat_path 可指定路径。

Usage:
    from scanners.hashcat_wrapper import hashcat_crack, hashcat_status, hashcat_list_rules
    result = hashcat_crack("hashes.txt", wordlist="rockyou.txt", hash_mode=0)
    status = hashcat_status("hashes.txt")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('hashcat_scanner')


def _find_hashcat() -> Optional[str]:
    """查找 hashcat 可执行文件：先 config.json → tools.hashcat_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("hashcat_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["hashcat", "hashcat.exe", "hashcat64.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _run_hashcat(args: list, max_time: int) -> tuple:
    """执行 hashcat 子命令，返回 (returncode, stdout)。"""
    hc = _find_hashcat()
    if not hc:
        return -1, "hashcat 未找到"
    cmd = [hc] + args
    logger.info(f"hashcat: {' '.join(cmd[:8])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        return proc.returncode, (proc.stdout or "") + "\n" + (proc.stderr or "")
    except subprocess.TimeoutExpired:
        return -2, "hashcat 超时"


def hashcat_crack(
    hash_file: str,
    wordlist: str = "",
    hash_mode: int = 0,
    max_time: int = 3600,
) -> dict:
    """运行 hashcat 离线字典破解。

    Args:
        hash_file: hash 文件路径（每行一个 hash）
        wordlist:  字典文件路径
        hash_mode: hashcat 模式（0=MD5, 100=NTLM, 1800=SHA512, 3000=SHA1）
        max_time:  最大运行时间秒

    Returns:
        {"ok": bool, "cracked": [...], "cracked_count": N, "error": ...}
    """
    if not hash_file or not os.path.isfile(hash_file):
        return {"ok": False, "hash_file": hash_file, "cracked": [], "cracked_count": 0,
                "error": f"hash 文件不存在: {hash_file}"}
    if not wordlist or not os.path.isfile(wordlist):
        return {"ok": False, "hash_file": hash_file, "cracked": [], "cracked_count": 0,
                "error": f"字典文件不存在: {wordlist}"}

    rc, out = _run_hashcat(
        ["-m", str(hash_mode), "-a", "0", hash_file, wordlist, "--quiet", "--potfile-path", "hashcat.pot"],
        max_time,
    )
    if rc == -2:
        return {"ok": False, "hash_file": hash_file, "cracked": [], "cracked_count": 0, "error": "hashcat 超时"}
    if rc < 0:
        return {"ok": False, "hash_file": hash_file, "cracked": [], "cracked_count": 0, "error": out or "hashcat 未找到"}

    # 解析破解结果：格式 <hash>:<plain>
    cracked = []
    for line in out.splitlines():
        if ":" in line and not line.strip().startswith("["):
            parts = line.strip().split(":", 1)
            if len(parts) == 2 and parts[1].strip():
                cracked.append({"hash": parts[0].strip(), "plaintext": parts[1].strip()})

    return {
        "ok": True,
        "hash_file": hash_file,
        "hash_mode": hash_mode,
        "cracked": cracked[:500],
        "cracked_count": len(cracked),
        "error": "",
    }


def hashcat_status(hash_file: str) -> dict:
    """查看某 hash 文件已破解的结果（hashcat --show）。

    Args:
        hash_file: hash 文件路径（需与破解时一致）

    Returns:
        {"ok": bool, "results": [...], "result_count": N, "error": ...}
    """
    if not hash_file or not os.path.isfile(hash_file):
        return {"ok": False, "results": [], "result_count": 0, "error": f"hash 文件不存在: {hash_file}"}

    rc, out = _run_hashcat(["--show", "--potfile-path", "hashcat.pot"], 60)
    if rc == -2:
        return {"ok": False, "results": [], "result_count": 0, "error": "hashcat 超时"}
    if rc < 0:
        return {"ok": False, "results": [], "result_count": 0, "error": out or "hashcat 未找到"}

    results = []
    for line in out.splitlines():
        if ":" in line and not line.strip().startswith("["):
            parts = line.strip().split(":", 1)
            if len(parts) == 2:
                results.append({"hash": parts[0].strip(), "plaintext": parts[1].strip()})

    return {"ok": True, "results": results[:500], "result_count": len(results), "error": ""}


def hashcat_list_rules() -> dict:
    """列出 hashcat 支持的 Hash 模式（hashcat -h 输出解析）。

    Returns:
        {"ok": bool, "modes": {mode_id: name, ...}, "mode_count": N, "error": ...}
    """
    rc, out = _run_hashcat(["-h"], 30)
    if rc == -2:
        return {"ok": False, "modes": {}, "mode_count": 0, "error": "hashcat 超时"}
    if rc < 0:
        return {"ok": False, "modes": {}, "mode_count": 0, "error": out or "hashcat 未找到"}

    # 解析形如 "  0   md5 (MD5)" 的行
    modes = {}
    for line in out.splitlines():
        m = re.match(r'\s*(\d{1,5})\s{2,}([A-Za-z0-9_\- ]+?)\s*\(([^)]+)\)', line)
        if m:
            modes[m.group(1)] = m.group(3).strip()
        else:
            m2 = re.match(r'\s*(\d{1,5})\s{2,}([A-Za-z0-9_\-]+)', line)
            if m2:
                modes[m2.group(1)] = m2.group(2).strip()

    return {"ok": True, "modes": modes, "mode_count": len(modes), "error": ""}
