#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Tool Detector — 外部工具自动检测与 config.json 路径自愈。

问题背景：
    config.json 的 tools.*_path 是特定机器上的绝对路径，换一台电脑全部失效。
    本模块在任意机器上按以下顺序探测每个外部工具的实际位置：
      1. config.json 现有值（存在性校验，有效则直接采用）
      2. PATH（shutil.which，Windows 自动匹配 .exe/.bat/.cmd 等 PATHEXT）
      3. 本机常见安装目录（WinGet Links / chocolatey / Python Scripts / go bin / scoop /
         %LOCALAPPDATA%\\hack_scanner\\bin / C:\\tools\\*\\bin 等）

    探测结果三态：
      configured — config 里已有且路径有效
      found      — config 为空或失效，但在本机找到了（可写回）
      missing    — 未找到（附安装提示）

安全约束（auto_update_config）：
    - 只写 found 项（config 空/失效 → 填入新发现的有效路径）
    - 绝不覆盖已有效的现有路径、绝不删除 missing 项
    - 幂等：连续运行第二次 0 变更
    - 原子写（临时文件 + os.replace）

Usage:
    python scanners/tool_detector.py            # 只检测，打印状态报告
    python scanners/tool_detector.py --apply    # 检测 + 写回 config.json
    python scanners/tool_detector.py --config <path> --apply

    from scanners.tool_detector import detect_tools, auto_update_config, format_report
"""

import json
import os
import shutil
import sys
from typing import Dict, List, Optional

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_CONFIG = os.path.join(PROJECT_ROOT, "config.json")

# ─────────────────────────────────────────────────────────────
# 工具规格表：(config.json 键名, 可执行文件名候选, 安装提示)
# 顺序与 config.json → tools 段一致（28 项）
# ─────────────────────────────────────────────────────────────
TOOL_SPECS: List[Dict] = [
    {"key": "nmap_path",         "names": ["nmap"],         "hint": "winget install Insecure.Nmap 或官网安装包"},
    {"key": "masscan_path",      "names": ["masscan"],      "hint": "无官方 Windows 构建，需自行编译（wrapper 已优雅降级）"},
    {"key": "gobuster_path",     "names": ["gobuster"],     "hint": "go install github.com/OJ/gobuster/v3/cmd/gobuster@latest 或 GitHub release"},
    {"key": "hydra_path",        "names": ["hydra", "thc-hydra"], "hint": "thc-hydra-windows 预编译包 + hydra.bat shim"},
    {"key": "nuclei_path",       "names": ["nuclei"],       "hint": "winget install ProjectDiscovery.Nuclei"},
    {"key": "sqlmap_path",       "names": ["sqlmap", "sqlmap.py"], "hint": "pip install sqlmap"},
    {"key": "subfinder_path",    "names": ["subfinder"],    "hint": "winget install ProjectDiscovery.Subfinder"},
    {"key": "katana_path",       "names": ["katana"],       "hint": "winget install ProjectDiscovery.Katana"},
    {"key": "gau_path",          "names": ["gau"],          "hint": "go install github.com/lc/gau/v2/cmd/gau@latest"},
    {"key": "httpx_path",        "names": ["httpx"],        "hint": "go install github.com/projectdiscovery/httpx/cmd/httpx@latest（注意与 Python httpx 库 CLI 重名）"},
    {"key": "nikto_path",        "names": ["nikto"],        "hint": "winget install Nikto.Nikto"},
    {"key": "dirb_path",         "names": ["dirb"],         "hint": "Windows 无官方包，wrapper 可优雅降级"},
    {"key": "john_path",         "names": ["john"],         "hint": "jtr-wrapper 或 john 官方 zip 解压"},
    {"key": "ffuf_path",         "names": ["ffuf"],         "hint": "winget install ffuf.ffuf"},
    {"key": "feroxbuster_path",  "names": ["feroxbuster"],  "hint": "winget install BenMcKee.Feroxbuster"},
    {"key": "dirsearch_path",    "names": ["dirsearch"],    "hint": "pip install dirsearch"},
    {"key": "wpscan_path",       "names": ["wpscan", "wpscan.rb"], "hint": "ruby 环境 + gem install wpscan"},
    {"key": "amass_path",        "names": ["amass"],        "hint": "winget install OWASP.Amass"},
    {"key": "hakrawler_path",    "names": ["hakrawler"],    "hint": "go install github.com/hakankoru/hakrawler@latest"},
    {"key": "hashcat_path",      "names": ["hashcat"],      "hint": "choco install hashcat（需 NVIDIA 驱动）"},
    {"key": "exiftool_path",     "names": ["exiftool"],     "hint": "choco install exiftool 或 cpan Image::ExifTool"},
    {"key": "semgrep_path",      "names": ["semgrep"],      "hint": "pip install semgrep"},
    {"key": "trufflehog_path",   "names": ["trufflehog"],   "hint": "choco install trufflehog 或 GitHub release"},
    {"key": "checkov_path",      "names": ["checkov"],      "hint": "pip install checkov"},
    {"key": "trivy_path",        "names": ["trivy"],        "hint": "winget install Aqua.Security.Trivy"},
    {"key": "theharvester_path", "names": ["theHarvester", "theharvester"], "hint": "pip install theHarvester"},
    {"key": "sherlock_path",     "names": ["sherlock"],     "hint": "pip install sherlock"},
    {"key": "binwalk_path",      "names": ["binwalk"],      "hint": "pip install binwalk（PyPI 版可能残缺，优先官方仓库）"},
    {"key": "yara_path",         "names": ["yara"],         "hint": "choco install -y yara  或  winget install VirusTotal.Yara"},
]

_STATUS_ICONS = {
    "configured": "✅",
    "found":      "🔍",
    "missing":    "❌",
}


def _resolve_config(config_path: Optional[str]) -> str:
    p = config_path or DEFAULT_CONFIG
    return os.path.normpath(os.path.abspath(p))


def _load_config(config_path: str) -> dict:
    if os.path.isfile(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_config(config_path: str, cfg: dict) -> None:
    """原子写入：先写临时文件再 os.replace，避免中途失败留下半截 JSON"""
    d = os.path.dirname(config_path)
    if d:
        os.makedirs(d, exist_ok=True)
    tmp = config_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, config_path)


def _which(name: str) -> Optional[str]:
    """PATH 查找；Windows 上 shutil.which 会按 PATHEXT 自动补 .exe/.bat/.cmd"""
    try:
        return shutil.which(name)
    except Exception:
        return None


def _candidate_dirs() -> List[str]:
    """本机常见工具安装目录（动态生成，随设备变化）"""
    dirs: List[str] = []
    if os.name == "nt":
        local = os.environ.get("LOCALAPPDATA", "")
        progdata = os.environ.get("PROGRAMDATA", r"C:\ProgramData")
        user = os.environ.get("USERPROFILE", "")
        if local:
            dirs.append(os.path.join(local, "hack_scanner", "bin"))
            dirs.append(os.path.join(local, "Microsoft", "WinGet", "Links"))
        if progdata:
            dirs.append(os.path.join(progdata, "chocolatey", "bin"))
        if user:
            dirs.append(os.path.join(user, "go", "bin"))
            dirs.append(os.path.join(user, "scoop", "shims"))
            dirs.append(os.path.join(user, "bin"))
        # 当前 Python 的 Scripts 目录（pip 安装的工具都在这里）
        scripts = os.path.join(os.path.dirname(os.path.abspath(sys.executable)), "Scripts")
        if os.path.isdir(scripts):
            dirs.append(scripts)
        # C:\tools\<pkg>\bin（wpscan 等手动安装的惯例位置）
        tools_root = r"C:\tools"
        if os.path.isdir(tools_root):
            try:
                for sub in os.listdir(tools_root):
                    b = os.path.join(tools_root, sub, "bin")
                    if os.path.isdir(b):
                        dirs.append(b)
            except OSError:
                pass
    else:
        dirs += [
            os.path.expanduser("~/.local/bin"),
            os.path.expanduser("~/go/bin"),
            "/usr/local/bin",
            "/usr/bin",
        ]
    return [d for d in dirs if os.path.isdir(d)]


def detect_tools(config_path: Optional[str] = None) -> List[Dict]:
    """探测全部工具，返回每项 {tool, config_key, status, path, source, hint}"""
    cfg_path = _resolve_config(config_path)
    cfg = _load_config(cfg_path)
    tools_cfg = cfg.get("tools", {}) or {}
    dirs = _candidate_dirs()

    results: List[Dict] = []
    for spec in TOOL_SPECS:
        key = spec["key"]
        names = spec["names"]
        tool = key.replace("_path", "")
        entry: Dict = {"tool": tool, "config_key": key, "hint": spec.get("hint", "")}

        # 1) config 现有值（有效则直接采用，不覆盖）
        current = tools_cfg.get(key, "") or ""
        if current and os.path.isfile(current):
            entry.update(status="configured", path=current, source="config")
            results.append(entry)
            continue

        # 2) PATH
        found, source = None, ""
        for n in names:
            p = _which(n)
            if p:
                found, source = p, "PATH"
                break
        # 3) 常见安装目录
        if not found:
            for d in dirs:
                for n in names:
                    p = os.path.join(d, n)
                    if os.path.isfile(p):
                        found, source = p, d
                        break
                if found:
                    break

        if found:
            entry.update(status="found", path=found, source=source)
        else:
            entry.update(status="missing", path="", source="")
        results.append(entry)
    return results


def auto_update_config(config_path: Optional[str] = None, dry_run: bool = False) -> Dict:
    """把 found 项写回 config.json。

    只补空/失效项，绝不覆盖有效项，幂等。
    返回 {"changed": N, "changes": [...], "results": [...], "dry_run": bool, "config_path": str}
    """
    cfg_path = _resolve_config(config_path)
    cfg = _load_config(cfg_path)
    tools_cfg = cfg.get("tools")
    if tools_cfg is None:
        tools_cfg = {}
        cfg["tools"] = tools_cfg

    results = detect_tools(cfg_path)
    changes: List[Dict] = []
    for r in results:
        if r["status"] != "found":
            continue
        old = tools_cfg.get(r["config_key"], "") or ""
        tools_cfg[r["config_key"]] = r["path"]
        changes.append({
            "tool": r["tool"],
            "config_key": r["config_key"],
            "old": old,
            "new": r["path"],
            "source": r["source"],
        })

    if changes and not dry_run:
        _save_config(cfg_path, cfg)

    return {
        "changed": len(changes),
        "changes": changes,
        "results": results,
        "dry_run": dry_run,
        "config_path": cfg_path,
    }


def format_report(results: Optional[List[Dict]] = None,
                  config_path: Optional[str] = None,
                  changes: Optional[List[Dict]] = None) -> str:
    """生成人类可读的状态报告（纯文本，终端友好）"""
    if results is None:
        results = detect_tools(config_path)
    lines: List[str] = []
    lines.append("")
    lines.append("═" * 74)
    lines.append("  外部工具状态报告")
    lines.append(f"  config: {config_path or DEFAULT_CONFIG}")
    lines.append("═" * 74)

    counts = {"configured": 0, "found": 0, "missing": 0}
    for r in results:
        counts[r["status"]] += 1
        icon = _STATUS_ICONS.get(r["status"], " ")
        if r["status"] == "configured":
            tag = "已配置"
        elif r["status"] == "found":
            tag = "已发现·待写入"
        else:
            tag = "缺失"
        lines.append(f" {icon} {r['tool']:<14} {tag}")
        if r.get("path"):
            lines.append(f"    {r['path']}   (来源: {r['source']})")
        elif r.get("hint"):
            lines.append(f"    安装: {r['hint']}")

    if changes:
        lines.append("")
        lines.append(f"  本次写入 config.json 的 {len(changes)} 项：")
        for c in changes:
            lines.append(f"    - {c['config_key']}: {c['new']}")

    lines.append("─" * 74)
    lines.append(f"  合计: {counts['configured']} 已配置 / {counts['found']} 待写入 / "
                 f"{counts['missing']} 缺失   共 {len(results)} 项")
    lines.append("═" * 74)
    return "\n".join(lines)


def main() -> int:
    # Windows GBK 控制台兼容：状态图标(✅/🔍/❌)在 GBK 下不可编码，
    # 改为替换输出而不是让 print 抛 UnicodeEncodeError
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass

    import argparse
    ap = argparse.ArgumentParser(
        description="hack_scanner 外部工具自动检测与 config.json 路径自愈")
    ap.add_argument("--apply", action="store_true",
                    help="将发现的路径写回 config.json（只补空/失效项，幂等）")
    ap.add_argument("--dry-run", action="store_true",
                    help="只报告将发生的变化，不实际写入")
    ap.add_argument("--config", default=None,
                    help=f"config.json 路径（默认: {DEFAULT_CONFIG}）")
    args = ap.parse_args()

    if args.apply or args.dry_run:
        report = auto_update_config(args.config, dry_run=args.dry_run)
        mode = "dry-run（未写入）" if args.dry_run else "已写入"
        print(f"\n[tool_detector] {mode}: {report['changed']} 项变更")
        print(format_report(report["results"], args.config, report["changes"]))
    else:
        results = detect_tools(args.config)
        print(format_report(results, args.config))
        found = [r for r in results if r["status"] == "found"]
        if found:
            print(f"\n提示: 有 {len(found)} 个工具已安装但 config.json 未配置/路径失效，"
                  f"运行 `python scanners/tool_detector.py --apply` 自动修复。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
