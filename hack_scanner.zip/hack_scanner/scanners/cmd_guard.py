#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cmd_guard.py — shell 命令三态静态判定（4 项目升级清单 #2）
=====================================================================

借鉴 holmes plugins/toolsets/bash/{validation.py, command_arg_rules.py}:
    只读命令的"参数层"漏洞——`find -exec`、`sort -o`、`uniq x out`、
    重定向落盘——把允许名单里的命令变成任意执行/写文件。
    holmes 的三态判定：
        ALLOWED             静态可证只读 → 自动放行
        DENIED              静态可证危险（执行/写/删）→ 拒绝，不询问
        APPROVAL_REQUIRED   其余（含无法解析/复合语句/名单外）→ 人工审批

本模块的三态（对齐 exec_gate 语义）:
        allow   → 只读且无危险参数/重定向（auto_review 模式可自动放行）
        deny    → 命中 argv 危险规则或落盘重定向（任何模式都拒，不询问）
        review  → 无法静态判定（复合语句/名单外/展开变量）→ 必须人工

设计要点（holmes 同款）:
    - 段解析：| && || ; & 逐段独立判定；任一 deny → 整条 deny；
      任一 review → 整条 review；全 allow → allow
    - 前缀 allow 名单只认命令名（basename），argv 规则按 basename 分派
    - GNU 长选项前缀缩写（--out ≈ --output）用"缩写匹配"防绕过
    - 值选项正确识别（sort -to 的 o 是 -t 的值，不是 -o）
    - 无法解析/含复合语句/变量展开 → review（永不自动执行，fail-safe）
    - 纯标准库；只读判定，不执行任何命令

exec_gate 接线:
    gate = ExecutionGate(mode="auto_review")
    gate.command_policy = cmd_guard.build_policy()   # 见 exec_gate.authorize
"""

from __future__ import annotations

import re
import shlex
from dataclasses import dataclass
from typing import List, Optional, Tuple

__all__ = [
    "Verdict",
    "classify_command",
    "classify_segment",
    "build_policy",
    "READ_ONLY_ALLOWLIST",
    "DENY_ALWAYS",
]

# ---------------------------------------------------------------------------
# 名单（holmes default_lists 的只读子集 + 渗透常用只读命令）
# ---------------------------------------------------------------------------
READ_ONLY_ALLOWLIST = frozenset({
    # 文本处理（holmes core allow list 同款）
    "cat", "head", "tail", "wc", "grep", "egrep", "fgrep", "awk", "sed",
    "sort", "uniq", "cut", "tr", "tee", "strings", "od", "xxd", "less", "more",
    "jq", "yq", "base64", "openssl",
    # 文件/目录查看
    "ls", "find", "stat", "file", "du", "df", "tree", "realpath", "basename",
    "dirname", "readlink", "md5sum", "sha1sum", "sha256sum", "cksum", "diff",
    "cmp", "comm", "csplit", "split",
    # 进程/系统只读
    "ps", "top", "uptime", "uname", "hostname", "whoami", "id", "env",
    "printenv", "set", "echo", "date", "cal", "which", "whereis", "type",
    # 网络只读（渗透场景）
    "curl", "wget", "dig", "nslookup", "host", "ping", "traceroute",
    "tracepath", "arping", "nc", "ncat", "netstat", "ss", "ifconfig", "ip",
    "whois", "ssh", "scp", "sftp", "telnet", "ftp",
    # 注意：解释器/包管理器（python/node/pip/npm/go/java...）【不在】名单——
    # 它们可执行任意代码/安装落盘（python3 payload.py、pip install），
    # 静态不可证只读 → 一律 review 交人工，绝不自动放行。
})

# 无条件 deny（任何参数都危险）
DENY_ALWAYS = frozenset({
    "rm", "rmdir", "mkfs", "dd", "fdisk", "mkinitrd", "insmod", "rmmod",
    "modprobe", "sh", "bash", "zsh", "ksh", "dash", "csh", "tcsh",
    "eval", "exec", "source", "mount", "umount", "kill", "killall", "pkill",
    "chmod", "chown", "chgrp", "useradd", "userdel", "usermod", "visudo",
    "iptables", "ip6tables", "nft", "sysctl", "crontab", "at",
    "curl",  # 单独列在 allowlist 会与 deny 冲突——curl 走 argv 规则裁决，不在此列
})
# 修正：curl 允许走 argv 规则（-o 写文件才 deny），从 deny 名单移除
DENY_ALWAYS = DENY_ALWAYS - {"curl"}
# wget 同理（-O 写文件才 deny）
DENY_ALWAYS = DENY_ALWAYS  # wget 保留在 allowlist，靠 argv 规则

# ---------------------------------------------------------------------------
# 段级 argv 危险规则（holmes command_arg_rules 同款结构）
# 规则函数接收段 argv（含命令名），返回 (status, reason)
#   status ∈ {"allow", "deny", "review"}
# ---------------------------------------------------------------------------

# find 的动作原语（升级清单 #2 验收语义）:
#   -exec/-execdir/-ok/-okdir → 看被执行命令：
#     危险命令（DENY_ALWAYS）→ deny；只读/未知命令 → review（执行代码不自动放行）
#   -delete → deny（删文件）；-fprint* → deny（写任意文件）
FIND_EXEC_PRIMITIVES = frozenset({"-exec", "-execdir", "-ok", "-okdir"})
FIND_DENY_PRIMITIVES = frozenset({"-delete", "-fprint", "-fprint0", "-fprintf", "-fls"})

# 值选项（短选项集群解析用）：这些字符选项后面跟值
_SORT_VALUE_SHORT = frozenset("ktSTo")
_SORT_VALUE_LONG = frozenset({
    "--output", "--compress-program", "--buffer-size", "--key",
    "--field-separator", "--temporary-directory", "--batch-size",
    "--files0-from", "--random-source",
})
# sort 危险：--compress-program 执行程序；-o/--output 写文件
_SORT_EXEC_LONG = ("--compress-program",)
_SORT_WRITE_LONG = ("--output",)

# uniq: uniq [OPTS] [INPUT [OUTPUT]] — 第 2 个位置参数是输出文件
_UNIQ_VALUE_SHORT = frozenset("fsw")
_UNIQ_VALUE_LONG = frozenset({"--skip-fields", "--skip-chars", "--check-chars"})

# 落盘重定向目标（这些不算"写真实文件"）
_BENIGN_REDIRECT = frozenset({"/dev/null", "/dev/stdout", "/dev/stderr", "-", "/dev/fd/1", "/dev/fd/2"})


def _find_executed_command(args: List[str], i: int) -> Optional[str]:
    r"""取 find -exec/-ok 原语之后、结束符 `;` 之前的第一个非选项 token（被执行的命令词）。

    shlex 把 `\;` 解析成 token `;`。找不到命令词 → None（调用方转 review，不猜测）。
    """
    for b in args[i + 1:]:
        if b == ";":
            return None
        if not b.startswith("-"):
            return b
    return None


def _abbrev_match(opt: str, candidates: tuple) -> bool:
    """GNU getopt_long 前缀缩写匹配：--out 匹配 --output（唯一前缀即可）。"""
    for c in candidates:
        if c == opt:
            return True
        # 缩写必须唯一：--ou 不应匹配 --output 与 --out-format 两个
        if c.startswith(opt):
            others = [x for x in candidates if x.startswith(opt) and x != c]
            if not others:
                return True
    return False


def _is_benign_target(tok: str) -> bool:
    return tok in _BENIGN_REDIRECT or tok.startswith("/dev/null") or tok.startswith("/dev/tty")


def _has_shell_expansion(argv: List[str]) -> bool:
    """变量展开/命令替换/通配：静态值不可知 → 只能 review（holmes 同款）。"""
    for a in argv:
        if re.search(r"[$`*?[]|\$\{|\$\(", a):
            return True
    return False


def _check_redirections(raw_segment: str) -> Optional[Tuple[str, str]]:
    """检查段内输出重定向是否落真实文件。返回 (status, reason) 或 None。"""
    # 匹配 > 或 >> 后的目标（跳过 2>/dev/null 这类文件描述符+无害目标）
    for m in re.finditer(r"(?<![\d])>{1,2}\s*([^\s|;&<>]+)", raw_segment):
        target = m.group(1).strip("'\"")
        if _is_benign_target(target):
            continue
        return ("deny", f"redirect '{m.group(0).strip()}' writes to a real file")
    return None


def _argv_rule(cmd: str, args: List[str]) -> Tuple[str, str]:
    """按命令 basename 分派 argv 危险规则。返回 (status, reason)。"""
    base = cmd.rsplit("/", 1)[-1]

    if base == "find":
        # find 用词式原语（无 getopt 集群），精确 token 匹配（升级清单 #2 验收语义）:
        #   -delete / -fprint*            → deny（删文件/写任意文件，静态可证危险）
        #   -exec/-execdir/-ok/-okdir CMD → 看被执行的 CMD:
        #     CMD 危险（DENY_ALWAYS）     → deny（如 -exec rm）
        #     CMD 只读/未知               → review（执行代码，不自动放行但非确定危险，如 -exec grep）
        i = 0
        while i < len(args):
            a = args[i]
            if a in FIND_DENY_PRIMITIVES:
                return ("deny", f"'find' argument '{a}' deletes files or writes to arbitrary files")
            if a in FIND_EXEC_PRIMITIVES:
                inner = _find_executed_command(args, i)
                if inner is None:
                    return ("review", f"'find {a}' without a parseable executed command: requires approval")
                inner_base = inner.rsplit("/", 1)[-1]
                if inner_base in DENY_ALWAYS:
                    return ("deny", f"'find {a}' executes dangerous command '{inner_base}'")
                return ("review", f"'find {a}' executes a command ('{inner_base}'): code execution, requires approval")
            i += 1
        return ("allow", "find without action primitives")

    if base == "sort":
        options, _positionals = _parse_argv(args, _SORT_VALUE_SHORT, _SORT_VALUE_LONG)
        # 长选项可挂值（--compress-program=sh）：按【名字】匹配
        #（剥 =value 段），否则 = 形态整体绕过缩写匹配
        long_names = [o.split("=", 1)[0] for o in options if o.startswith("--")]
        if any(_abbrev_match(o, _SORT_EXEC_LONG) for o in long_names):
            return ("deny", "'sort --compress-program' can execute an arbitrary program")
        if any(o == "-o" or o.startswith("-o=") for o in options) \
                or any(_abbrev_match(o, _SORT_WRITE_LONG) for o in long_names):
            return ("deny", "'sort' output option writes to the filesystem")
        return ("allow", "sort without write/exec options")

    if base == "uniq":
        options, positionals = _parse_argv(args, _UNIQ_VALUE_SHORT, _UNIQ_VALUE_LONG)
        if len(positionals) >= 2 and not _is_benign_target(positionals[1]):
            return ("deny", f"'uniq' second positional '{positionals[1]}' is an output file")
        return ("allow", "uniq without output file")

    if base in ("curl", "wget"):
        # curl: -o/--output 写文件；-J/--remote-name 下载即落盘
        # wget: -O 写文件；-P/--directory-prefix 落目录
        # 长选项可缩写/挂值（--out=、--output=x）：按【名字】匹配（剥 =value）
        if base == "curl":
            for a in args:
                if a == "-J" or (a.startswith("--")
                                and _abbrev_match(a.split("=", 1)[0], ("--remote-name",))):
                    return ("deny", "'curl -J' writes downloaded file to disk")
        write_long = ("--output",) if base == "curl" else ("--output-document",)
        dir_long = () if base == "curl" else ("--directory-prefix",)
        for i, a in enumerate(args):
            if a in ("-o", "-O") or a.startswith("-o=") or a.startswith("-O="):
                val = a.split("=", 1)[1] if "=" in a else (args[i + 1] if i + 1 < len(args) else "")
                if val and not _is_benign_target(val.strip("'\"")):
                    return ("deny", f"'{base}' output option writes to '{val}'")
                continue
            if a.startswith("--"):
                nm = a.split("=", 1)[0]
                hit = (any(_abbrev_match(nm, cands) for cands in (write_long, dir_long) if cands))
                if hit:
                    val = a.split("=", 1)[1] if "=" in a else (args[i + 1] if i + 1 < len(args) else "")
                    if val and not _is_benign_target(val.strip("'\"")):
                        return ("deny", f"'{base}' output option writes to '{val}'")
        return ("allow", f"{base} without write options")

    if base in ("tee",):
        # tee 默认写 stdout，但给文件参数就落盘
        for a in args:
            if not a.startswith("-") and not _is_benign_target(a):
                return ("deny", f"'tee' writes to file '{a}'")
        return ("allow", "tee to stdout only")

    if base in ("dd",):
        return ("deny", "'dd' can write raw devices/files")

    if base in ("cp", "mv", "mkdir", "touch", "ln", "install", "rsync",
                "tar", "zip", "unzip", "gunzip", "bzip2", "xz"):
        # cp/mv/mkdir/touch 本质是写操作；tar/zip 解压落盘
        return ("deny", f"'{base}' is a file-writing command")

    # 其余 allowlist 命令：无已知 argv 危险规则 → allow（保守兜底仍由 review 段判定覆盖）
    return ("allow", f"{base}: no argv danger rule matched")


def _parse_argv(args: List[str], value_short: frozenset,
                value_long: frozenset) -> Tuple[List[str], List[str]]:
    """把 argv 拆成 (options, positionals)。

    值选项正确处理：-to 里 o 是 -t 的值（不是 -o）；--key=value 算一个 option。
    """
    options: List[str] = []
    positionals: List[str] = []
    i = 0
    while i < len(args):
        a = args[i]
        if a.startswith("--"):
            options.append(a)
        elif a.startswith("-") and len(a) > 1:
            options.append(a)
            # 短选项集群：若最后一个字符是值选项且无 '='，下一词是它的值
            last = a[-1]
            if last in value_short and "=" not in a:
                i += 1  # 跳过值
        else:
            positionals.append(a)
        i += 1
    return options, positionals


# ---------------------------------------------------------------------------
# 段判定 + 整条判定
# ---------------------------------------------------------------------------

# 复合语句关键字（for/while/if/case/function 等）→ 整段 review
_COMPOUND_RE = re.compile(
    r"^\s*(for|while|until|if|case|function|select)\b"
)
# 子shell/命令替换
_SUBSHELL_RE = re.compile(r"\$\(|`[^`]*`")
# 管道内嵌的 process substitution
_PROC_SUB_RE = re.compile(r"<\(|>\(")


@dataclass
class Verdict:
    status: str   # "allow" | "deny" | "review"
    reason: str
    segments: Optional[List[Tuple[str, str]]] = None

    def as_tuple(self) -> Tuple[str, str]:
        return (self.status, self.reason)


def classify_segment(raw_segment: str) -> Tuple[str, str]:
    """判定单个命令段（不含 | && ; 等分隔符）。"""
    seg = raw_segment.strip()
    if not seg:
        return ("allow", "empty segment")

    # 重定向落盘检查（对整段原文，含命令名后位置）
    redir = _check_redirections(seg)
    if redir is not None:
        return redir

    # 复合语句 / 子shell / 进程替换 → 无法静态展开 → review
    if _COMPOUND_RE.match(seg) or _SUBSHELL_RE.search(seg) or _PROC_SUB_RE.search(seg):
        return ("review", "compound statement / substitution: cannot verify statically")

    # 解析 argv（shlex 失败 → review，不猜测）
    try:
        argv = shlex.split(seg)
    except ValueError:
        return ("review", "unparseable shell syntax: routed to approval")
    if not argv:
        return ("allow", "empty")

    cmd = argv[0]
    base = cmd.rsplit("/", 1)[-1]

    # 无条件 deny
    if base in DENY_ALWAYS:
        return ("deny", f"'{base}' is denied by policy")

    # 变量展开 → 值不可知 → review
    if _has_shell_expansion(argv):
        return ("review", "shell expansion present: runtime value not statically known")

    # 不在只读 allowlist → review（交人工；不 deny，因为可能是合法只读自定义工具）
    if base not in READ_ONLY_ALLOWLIST:
        return ("review", f"'{base}' not in read-only allowlist: requires approval")

    # allowlist 命令走 argv 危险规则
    return _argv_rule(cmd, argv[1:])


def _split_segments(command: str) -> List[str]:
    r"""按 shell 分隔符（| && || ; & 换行）拆段，转义/引号感知。

    裸 re.split(r"[|;&]", ...) 会把 find -exec 的结束符 `\;`（find 的
    参数，不是 shell 分隔符）当分隔符拆开，段尾留下悬空反斜杠 →
    shlex 解析失败 → 误判 review。逐字符扫描：
      - 单引号内：无任何转义/分隔
      - 双引号内：反斜杠仅转义下一字符
      - 裸反斜杠：转义下一字符（\; 不是分隔符）
    未闭合引号 → 整段保留（后续 shlex 失败 → review，fail-safe）。
    """
    segs: List[str] = []
    buf: List[str] = []
    i, n = 0, len(command)
    in_single = in_double = False
    while i < n:
        ch = command[i]
        if in_single:
            buf.append(ch)
            i += 1
            if ch == "'":
                in_single = False
            continue
        if in_double:
            if ch == "\\" and i + 1 < n:
                buf.append(ch)
                buf.append(command[i + 1])
                i += 2
                continue
            buf.append(ch)
            i += 1
            if ch == '"':
                in_double = False
            continue
        if ch == "'":
            in_single = True
            buf.append(ch)
            i += 1
            continue
        if ch == '"':
            in_double = True
            buf.append(ch)
            i += 1
            continue
        if ch == "\\" and i + 1 < n:
            buf.append(ch)
            buf.append(command[i + 1])
            i += 2
            continue
        if ch in "|;&\n":
            segs.append("".join(buf))
            buf = []
            if ch in "|&" and i + 1 < n and command[i + 1] == ch:
                i += 2  # && / ||
            else:
                i += 1
            continue
        buf.append(ch)
        i += 1
    segs.append("".join(buf))
    return [s for s in segs if s.strip()]


def classify_command(command: str) -> Verdict:
    """整条命令判定：段级结果按 任一 deny → deny；任一 review → review；全 allow → allow。"""
    if not isinstance(command, str) or not command.strip():
        return Verdict("review", "empty command")

    # 先拆段（| && || ; & 换行；转义/引号感知——find -exec 的 \; 不是分隔符）
    segs = [s.strip() for s in _split_segments(command)]
    if not segs:
        return Verdict("review", "no segments parsed")

    results = [classify_segment(s) for s in segs]
    if any(r[0] == "deny" for r in results):
        deny_reason = next(r[1] for r in results if r[0] == "deny")
        return Verdict("deny", deny_reason, results)
    if any(r[0] == "review" for r in results):
        review_reason = next(r[1] for r in results if r[0] == "review")
        return Verdict("review", review_reason, results)
    return Verdict("allow", "all segments read-only", results)


# ---------------------------------------------------------------------------
# exec_gate 接线
# ---------------------------------------------------------------------------
def build_policy():
    """返回可传给 ExecutionGate(command_policy=...) 的判定函数。

    签名: (command: str) -> Optional[Tuple[bool, str]]
        (True,  reason)  → allow
        (False, reason)  → deny
        None             → 无静态结论，交给 exec_gate 既有逻辑（审批/放行）
    """
    def policy(command: str):
        try:
            v = classify_command(command)
        except Exception:
            return None
        if v.status == "deny":
            return (False, v.reason)
        if v.status == "allow":
            return (True, v.reason)
        # review → 返回 None（exec_gate 走人工审批路径，reason 由 classify_read_only 附）
        return None
    return policy


# ---------------------------------------------------------------------------
# CLI 自测
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    cases = [
        ("ls -la", "allow"),
        ("ls -la | head", "allow"),
        ("cat /etc/passwd | grep root", "allow"),
        ("curl -s https://x.com", "allow"),
        ("curl -s https://x.com -o /tmp/x", "deny"),
        ("find /tmp -exec rm {} \\;", "deny"),
        ("find x -exec grep \\;", "review"),      # 清单 #2 验收：-exec 只读命令 → review
        ("find . -delete", "deny"),
        ("find /tmp -name x.txt", "allow"),
        ("sort -o /tmp/out file", "deny"),
        ("sort --compress-program=sh file", "deny"),
        ("sort -t, -k2 file", "allow"),
        ("uniq in.txt out.txt", "deny"),
        ("uniq in.txt", "allow"),
        ("rm -rf /", "deny"),
        ("bash -c 'id'", "deny"),
        ("echo $(cat /etc/shadow)", "review"),
        ("for f in *; do echo $f; done", "review"),
        ("some_custom_tool --scan", "review"),
        ("cat file > /tmp/out", "deny"),
        ("cat file 2>/dev/null", "allow"),
        ("wget -q https://x.com/f -O /tmp/f", "deny"),
        ("sort --output=/tmp/out file", "deny"),
        ("curl -s https://x --out=/tmp/z", "deny"),
        ("curl -s https://x -J", "deny"),
        ("curl -s https://x -o /dev/null", "allow"),
        # tar 不在只读允许名单 → review（fail-safe 交人工），非 deny（deny 只给确定危险）
        ("tar xzf app.tgz", "review"),
    ]
    failed = 0
    for cmd, expected in cases:
        v = classify_command(cmd)
        ok = v.status == expected
        if not ok:
            failed += 1
        print(f"[{'OK ' if ok else 'FAIL'}] {expected:6} got={v.status:6} | {cmd}  ({v.reason[:60]})")
    print(f"\n{len(cases) - failed}/{len(cases)} passed")
    sys.exit(1 if failed else 0)
