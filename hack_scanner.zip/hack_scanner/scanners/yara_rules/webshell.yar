/*
 * hack_scanner 内置 YARA 规则 — Webshell / 后门 / 恶意执行特征
 * ============================================================
 * 设计原则：
 *   - 高信号、低误报：每条规则要求"危险函数 + 攻击者可控输入"同时出现，
 *     避免单纯匹配 eval/system 造成对正常代码的误报。
 *   - 覆盖主流 webshell 语言：PHP / ASP / ASPX / JSP / Python。
 *   - meta.severity / family 供报告与分类使用。
 *
 * 手动用法（规则文件是位置参数，YARA CLI 没有"规则目录"选项）：
 *   yara -r -w <本目录>\*.yar <目标文件/目录>
 * 推荐直接用 scanners.yara_wrapper.yara_scan()，它会自动展开规则目录并校验。
 * 扩展：把你自己写的 .yar/.yara 规则丢进本目录即可被 yara_scan 一并加载。
 */

rule php_webshell_eval_decode
{
    meta:
        description = "PHP webshell: eval 解码执行 (base64_decode/gzinflate/gzuncompress/str_rot13)"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "php"
        severity    = "critical"
    strings:
        $s1 = "eval(base64_decode("            nocase
        $s2 = "eval(gzinflate(base64_decode(" nocase
        $s3 = "eval(gzuncompress(base64_decode(" nocase
        $s4 = "eval(str_rot13("               nocase
        $s5 = "assert(base64_decode("         nocase
        $s6 = "create_function("              nocase
    condition:
        filesize < 20MB and any of them
}

rule php_webshell_shell_exec
{
    meta:
        description = "PHP webshell: 命令执行函数 + 攻击者可控输入 (system/passthru/shell_exec/exec/popen + $_*)"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "php"
        severity    = "critical"
    strings:
        $cmd  = /(system|passthru|shell_exec|exec|popen|proc_open)\s*\(\s*\$(_(POST|GET|REQUEST|COOKIE|SERVER)|argv|args|cmd|command)/ nocase
        $eval = /(system|passthru|shell_exec|exec|popen)\s*\(\s*(\$[a-z_]+)\s*\)/ nocase
    condition:
        filesize < 20MB and ($cmd or #eval >= 1)
}

rule php_webshell_preg_replace_e
{
    meta:
        description = "PHP webshell: preg_replace /e 修饰符 (动态代码执行)"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "php"
        severity    = "high"
    strings:
        $s1 = "preg_replace(" nocase
        $s2 = "/e"           nocase
        $s3 = "eval"         nocase
    condition:
        filesize < 20MB and $s1 and ($s2 or $s3)
}

rule asp_webshell
{
    meta:
        description = "ASP/ASPX webshell: 系统诊断执行 / Server.Execute / Eval(Request)"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "asp"
        severity    = "critical"
    strings:
        $s1 = "System.Diagnostics.Process" nocase
        $s2 = "Server.Execute"             nocase
        $s3 = "Eval(Request"               nocase
        $s4 = "Execute(Request"            nocase
        $s5 = "WScript.Shell"              nocase
    condition:
        filesize < 20MB and 2 of them
}

rule jsp_webshell
{
    meta:
        description = "JSP webshell: Runtime.exec / ProcessBuilder + request 参数"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "jsp"
        severity    = "critical"
    strings:
        $s1 = "Runtime.getRuntime().exec("            nocase
        $s2 = "Runtime.getRuntime().exec(request"     nocase
        $s3 = "ProcessBuilder"                        nocase
        $s4 = "request.getParameter"                  nocase
    condition:
        filesize < 20MB and (($s1 or $s2) or ($s3 and $s4))
}

rule py_webshell
{
    meta:
        description = "Python webshell: os.system/subprocess + 请求输入 / exec+eval"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "python"
        severity    = "critical"
    strings:
        $s1 = "os.system(request"     nocase
        $s2 = "os.popen(request"      nocase
        $s3 = "subprocess.call(request" nocase
        $s4 = "exec(eval("           nocase
        $s5 = "os.system("           nocase
        $s6 = "request.args"         nocase
        $s7 = "request.form"         nocase
    condition:
        filesize < 20MB and (($s1 or $s2 or $s3 or $s4) or ($s5 and ($s6 or $s7)))
}

rule generic_webshell_encoded
{
    meta:
        description = "通用 webshell: 编码/解码链 + 动态执行 (跨语言)"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "any"
        severity    = "high"
    strings:
        $decode1 = "base64_decode("   nocase
        $decode2 = "gzinflate("      nocase
        $decode3 = "gzuncompress("   nocase
        $exec1   = "eval("           nocase
        $exec2   = "assert("         nocase
        $exec3   = "exec("           nocase
    condition:
        filesize < 20MB and (any of ($decode*) and any of ($exec*))
}

rule generic_php_input_stream
{
    meta:
        description = "PHP: 从 php://input 读取并执行/写文件 (webshell 常见手法)"
        author      = "hack_scanner"
        family      = "webshell"
        language    = "php"
        severity    = "high"
    strings:
        $in1 = "php://input"          nocase
        $in2 = "file_get_contents"   nocase
        $wr  = "file_put_contents("  nocase
        $ex  = "eval("               nocase
    condition:
        filesize < 20MB and $in1 and (any of ($in2,$wr,$ex))
}

rule known_webshell_filename
{
    meta:
        description = "已知 webshell 命名 (c99/r57/b374k/wso/phpspy 等)"
        author      = "hack_scanner"
        family      = "webshell"
        severity    = "critical"
        note        = "基于文件名特征，需结合内容确认"
    strings:
        $s1 = "c99"      nocase
        $s2 = "r57"      nocase
        $s3 = "b374k"    nocase
        $s4 = "wso"      nocase
        $s5 = "phpspy"   nocase
        $s6 = "milw0rm"  nocase
        $s7 = "china chopper" nocase
        $s8 = "c99 shell"    nocase
    condition:
        filesize < 5MB and 2 of them
}
