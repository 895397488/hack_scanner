#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IDOR/BOLA 真实流量回放 (Real-Traffic Authorization Replay)
==========================================================
借鉴 Strix v1.6.2 "real traffic as the attack surface"
（strix/tools/proxy/caido_api.py + strix/runtime/caido_bootstrap.py）：
不靠爬虫猜端点，直接拿**两个身份的会话真实流量**（带 cookie/token 的请求）
做交叉身份重放，检测 Broken Object Level Authorization (BOLA/IDOR)。

链路（本模块实现"回放 → 换身份 → 比对"这一段）:
    代理/浏览器导出的会话流量
      → normalize_sessions()      归一化两个身份的请求列表
      → extract_object_refs()     从路径/query/body 提取对象引用（?user_id=、/orders/123）
      → swap_identity()           用身份 B 的 cookie/token 重放身份 A 的请求
      → probe() + 比对            2xx 且响应与属主响应相似 → IDOR；无身份也 2xx → BOLA
      → scan_idor()               输出与项目 finding 约定一致的 dict

安全纪律（与 config.json safety 节同精神）:
  - ``scan_idor`` 必须显式 ``authorized=True`` 才放行 —— 交叉重放会向目标
    发出**带其他用户凭据**的请求，只在授权测试范围内合法。
  - 每个身份最多重放 ``max_requests`` 条，避免轰炸。
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

#: 身份凭据头（换身份时整体替换为 donor 的值；其余头保持原样）
IDENTITY_HEADER_NAMES = ("cookie", "authorization", "x-auth-token", "x-api-key")

#: 对象引用候选字段（body/query 里出现这些键且值为 id 形态 → 视为对象引用）
ID_KEY_PATTERNS = (
    "id", "uid", "user_id", "userid", "account_id", "customer_id", "patient_id",
    "order_id", "invoice_id", "ticket_id", "project_id", "document_id", "note_id",
    "file_id", "email", "phone", "username",
)

#: URL 路径段 / query 值形态：纯数字 id、uuid
_NUMERIC_ID = re.compile(r"^\d{1,20}$")
_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)

#: 响应体比对时截断长度（evidence 与相似度计算都不吃全量）
_BODY_CAP = 64 * 1024

DEFAULT_TIMEOUT = 10
DEFAULT_MAX_REQUESTS = 50


# ---------------------------------------------------------------------------
# 输入归一化
# ---------------------------------------------------------------------------

def _norm_headers(headers: Any) -> Dict[str, str]:
    """headers 归一化为 {小写名: 值}。接受 dict / list[(k,v)] / None。"""
    out: Dict[str, str] = {}
    if isinstance(headers, dict):
        for k, v in headers.items():
            if k is not None and v is not None:
                out[str(k).lower()] = str(v)
    elif isinstance(headers, list):
        for pair in headers:
            if isinstance(pair, dict):
                if "name" in pair and "value" in pair:   # HAR 风格 {"name","value"}
                    k, v = pair.get("name"), pair.get("value")
                    if k is not None and v is not None:
                        out[str(k).lower()] = str(v)
                else:                                    # [{"A": "1", "B": "2"}, ...]
                    for k, v in pair.items():
                        if k is not None and v is not None:
                            out[str(k).lower()] = str(v)
                continue
            try:                                          # [name, value] 元组/列表
                k, v = pair[0], pair[1]
            except (TypeError, IndexError, KeyError):
                continue
            if k is not None and v is not None:
                out[str(k).lower()] = str(v)
    return out


def normalize_sessions(sessions: Any) -> Dict[str, List[Dict[str, Any]]]:
    """把会话流量归一化为 ``{身份名: [request, ...]}``。

    每个 request 接受: ``{"method","url","headers","body"}``（HAR 风格
    ``{"request": {...}}`` 也认）。非法条目跳过，不抛。
    """
    norm: Dict[str, List[Dict[str, Any]]] = {}

    def _put(name: str, item: Any) -> None:
        if not isinstance(item, dict):
            return
        if "request" in item and isinstance(item["request"], dict):  # HAR-lite
            item = item["request"]
        method = str(item.get("method") or "GET").upper()
        url = str(item.get("url") or "").strip()
        if not url:
            return
        norm.setdefault(name, []).append({
            "method": method,
            "url": url,
            "headers": _norm_headers(item.get("headers")),
            "body": str(item.get("body") or ""),
        })

    if isinstance(sessions, dict):
        for name, reqs in sessions.items():
            if isinstance(reqs, list):
                for r in reqs:
                    _put(str(name), r)
            else:
                _put(str(name), reqs)
    elif isinstance(sessions, list):
        for i, r in enumerate(sessions):
            _put(f"session-{i}", r)
    return {k: v for k, v in norm.items() if v}


# ---------------------------------------------------------------------------
# 对象引用提取
# ---------------------------------------------------------------------------

def _parse_url_parts(url: str) -> Tuple[str, str, Dict[str, str], List[str]]:
    """返回 (path, query_string, {query_key: value}, [path_segments])。"""
    m = re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://[^/]*(/[^?#]*)?(\?[^#]*)?(#.*)?$", url)
    if not m:
        return url, "", {}, [url]
    path = m.group(1) or ""
    query = m.group(2) or ""
    segments = [s for s in path.split("/") if s]
    qparams: Dict[str, str] = {}
    for pair in query.lstrip("?").split("&"):
        if "=" in pair:
            k, v = pair.split("=", 1)
            qparams[k] = v
    return path, query, qparams, segments


def extract_object_refs(request: Dict[str, Any]) -> Dict[str, List[str]]:
    """从一条请求里提取对象引用 → ``{"path:orders": ["123"], "query:user_id": ["456"], "body:order_id": ["789"]}``。"""
    refs: Dict[str, List[str]] = {}
    url = request.get("url") or ""
    _path, _q, qparams, segments = _parse_url_parts(url)

    # 路径尾段（/orders/123 里的 123）
    for seg in segments[-2:]:
        if _NUMERIC_ID.match(seg) or _UUID.match(seg):
            refs.setdefault("path", []).append(seg)

    # query 参数（id 形态的值）
    for k, v in qparams.items():
        if k.lower().rstrip("s") in ID_KEY_PATTERNS and (_NUMERIC_ID.match(v) or _UUID.match(v)):
            refs.setdefault(f"query:{k}", []).append(v)

    # JSON body 字段
    body = request.get("body") or ""
    if body.lstrip().startswith("{"):
        try:
            data = json.loads(body)
        except (json.JSONDecodeError, ValueError):
            data = None
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(v, (int, str)) and k.lower().rstrip("s") in ID_KEY_PATTERNS:
                    sv = str(v)
                    if _NUMERIC_ID.match(sv) or _UUID.match(sv):
                        refs.setdefault(f"body:{k}", []).append(sv)
    return {k: v for k, v in refs.items() if v}


# ---------------------------------------------------------------------------
# 身份替换 + 重放
# ---------------------------------------------------------------------------

def _identity_headers(headers: Dict[str, str]) -> Dict[str, str]:
    return {k: v for k, v in headers.items() if k in IDENTITY_HEADER_NAMES and v}


def swap_identity(request: Dict[str, Any], donor: Dict[str, Any]) -> Dict[str, Any]:
    """用 donor 的身份头替换 request 的身份头（其余头与 body 保持原样）。

    若 request 本身无身份头，则直接注入 donor 的身份头（模拟"拿 B 的 cookie
    访问 A 的端点"——最常见的 BOLA 场景）。
    """
    headers = dict(request.get("headers") or {})
    donor_id = _identity_headers(donor.get("headers") or {})
    for k in IDENTITY_HEADER_NAMES:
        headers.pop(k, None)
    headers.update(donor_id)
    return {"method": request["method"], "url": request["url"],
            "headers": headers, "body": request.get("body") or ""}


def fingerprint(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8", errors="replace")).hexdigest()


def body_similarity(a: str, b: str) -> float:
    """token-set Jaccard（0.0–1.0）。空 body 双方 → 1.0，一空一非空 → 0.0。"""
    a, b = a or "", b or ""
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    ta = set(re.findall(r"[\w@.:/-]{2,}", a)) or {a}   # 短 body 兜底为整体 token
    tb = set(re.findall(r"[\w@.:/-]{2,}", b)) or {b}
    return len(ta & tb) / len(ta | tb)


def probe(request: Dict[str, Any], timeout: int = DEFAULT_TIMEOUT,
          session: Optional[Any] = None) -> Dict[str, Any]:
    """发一条请求，返回 {ok, status, length, body, fingerprint, error}。永不抛。"""
    out: Dict[str, Any] = {"ok": False, "status": 0, "length": 0, "body": "", "fingerprint": "", "error": ""}
    if requests is None:  # pragma: no cover
        out["error"] = "requests 库不可用"
        return out
    sess = session or requests
    try:
        resp = sess.request(
            request["method"], request["url"],
            headers=request.get("headers") or {},
            data=request.get("body") or None,
            timeout=timeout, allow_redirects=True, verify=False,
        )
        body = resp.text or ""
        out.update(ok=True, status=resp.status_code, length=len(body),
                   body=body[:_BODY_CAP], fingerprint=fingerprint(body[:_BODY_CAP]))
    except Exception as exc:  # noqa: BLE001 — 探测必须吞掉网络异常
        out["error"] = f"{type(exc).__name__}: {exc}"[:300]
    return out


# ---------------------------------------------------------------------------
# 判定
# ---------------------------------------------------------------------------

def _finding(**kw: Any) -> Dict[str, Any]:
    base = {"severity": "high", "category": "broken_access_control",
            "title": "", "description": "", "evidence": "", "recommendation": "",
            "cwe": "", "url": ""}
    base.update(kw)
    return base


def assess(request: Dict[str, Any], owner: Dict[str, Any], cross: Dict[str, Any],
           anon: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """判定一次交叉重放是否构成 IDOR/BOLA。

    owner = 属主身份重放自己的请求（基线）；cross = 对方身份重放；anon = 无身份重放。
    """
    url = request.get("url") or ""
    method = request.get("method") or "GET"
    refs = extract_object_refs(request)

    # 基线：属主自己都打不通 → 不是越权，是别的故障
    if not owner.get("ok") or owner["status"] >= 400:
        return None

    # 对方身份被拒 → 授权正常
    cross_denied = (not cross.get("ok")) or cross["status"] in (400, 401, 403, 404)
    if cross_denied and not (anon.get("ok") and anon["status"] < 400):
        return None

    if anon.get("ok") and anon["status"] < 400:
        # 无凭据就能读到 → BOLA / 缺失认证（比 IDOR 更糟：根本没查身份）
        return _finding(
            severity="high",
            category="bola",
            title=f"BOLA：端点缺失认证 — {method} {url}",
            description=(
                f"无任何会话凭据重放 `{method} {url}` 即返回 {anon['status']}（属主响应 {owner['status']}，"
                f"相似度 {body_similarity(owner.get('body',''), anon.get('body','')):.2f}）。"
                "该对象级端点未校验调用者身份，任何匿名访问者可枚举/读取他人资源。"
            ),
            evidence=f"anon={anon['status']} owner={owner['status']} cross={cross['status']} "
                     f"refs={json.dumps(refs, ensure_ascii=False)[:300]}",
            recommendation="服务端对该端点强制身份认证并校验"
                           "「资源属主 == 调用者」（或显式授权策略），拒绝匿名/跨属主访问。",
            cwe="CWE-284/CWE-306",
            url=url,
        )

    if cross.get("ok") and cross["status"] < 400:
        # IDOR 是对象级问题：要求请求里存在对象引用（/orders/123、?user_id=、body.id）。
        # 无 refs 的端点按身份返回"各自数据"（如 /api/profile 各回各的）不算越权。
        # BOLA（端点级缺认证）不要求 refs —— 端点本身没查身份就是问题。
        if not refs:
            return None
        sim = body_similarity(owner.get("body", ""), cross.get("body", ""))
        if sim >= 0.5:
            return _finding(
                severity="high",
                category="idor",
                title=f"IDOR：跨身份读取他人资源 — {method} {url}",
                description=(
                    f"用身份 B 的凭据重放身份 A 的请求 `{method} {url}` 返回 {cross['status']}，"
                    f"响应与属主响应高度相似（token Jaccard {sim:.2f}）。对象级授权缺失（BOLA/IDOR）。"
                ),
                evidence=f"owner={owner['status']} cross={cross['status']} sim={sim:.3f} "
                         f"refs={json.dumps(refs, ensure_ascii=False)[:300]} "
                         f"cross_body={cross.get('body','')[:200]!r}",
                recommendation="按「资源属主/权限」校验每个对象引用；"
                              "用不可枚举的资源标识（UUID）替代自增 id；返回 403/404 而非数据。",
                cwe="CWE-639",
                url=url,
            )
        # 2xx 但内容差异大：可能是公共数据或仅"可达"。降级提示，避免误报当高危
        if refs:
            return _finding(
                severity="medium",
                category="idor",
                title=f"疑似 IDOR：跨身份可达 — {method} {url}",
                description=(
                    f"身份 B 重放身份 A 的 `{method} {url}` 返回 {cross['status']}（非拒绝），"
                    "但响应与属主内容差异较大；需人工确认是否泄露了属主可访问的受限资源。"
                ),
                evidence=f"owner={owner['status']} cross={cross['status']} sim={sim:.3f} "
                         f"refs={json.dumps(refs, ensure_ascii=False)[:300]}",
                recommendation="人工核对该端点返回内容；若含属主私有数据则按 IDOR 高危处置。",
                cwe="CWE-639",
                url=url,
            )
    return None


# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------

def scan_idor(sessions: Any, *, authorized: bool = False,
              timeout: int = DEFAULT_TIMEOUT,
              max_requests: int = DEFAULT_MAX_REQUESTS,
              session: Optional[Any] = None) -> Dict[str, Any]:
    """对两个（或多个）身份的会话流量做交叉身份重放，输出 IDOR/BOLA findings。

    Args:
        sessions: ``{"A": [req, ...], "B": [req, ...]}``（req 见 normalize_sessions）
        authorized: **必须为 True** —— 交叉重放携带他人凭据，仅限授权范围
        timeout: 单请求超时（秒）
        max_requests: 每个身份最多重放的请求数
        session: 可注入 requests.Session（测试用）

    Returns:
        ``{"ok": bool, "findings": [...], "summary": {...}}``（finding 字段与项目约定一致）
    """
    if not authorized:
        return {"ok": False, "findings": [],
                "error": "安全纪律：交叉身份重放会携带他人会话凭据，仅限授权测试目标。"
                         "确认已获书面授权后传 authorized=True。"}

    norm = normalize_sessions(sessions)
    names = list(norm.keys())
    if len(names) < 2:
        return {"ok": False, "findings": [],
                "error": f"至少需要 2 个身份的会话流量（当前 {len(names)} 个: {names}）"}

    sess = session or (requests if requests is not None else None)
    if sess is None:  # pragma: no cover
        return {"ok": False, "findings": [], "error": "requests 库不可用，无法重放"}

    findings: List[Dict[str, Any]] = []
    seen: set = set()
    tested = denied = errors = 0

    # 每个身份的头模板（取该身份第一条带身份头的请求）
    def _id_template(name: str) -> Dict[str, Any]:
        for r in norm[name]:
            if _identity_headers(r["headers"]):
                return r
        return norm[name][0]

    # 双向：A 的请求用 B 的凭据、B 的请求也用 A 的凭据（两个方向的越权都要查）
    for name_a in names:
        for name_b in names:
            if name_a == name_b:
                continue
            donor = _id_template(name_b)
            for req in norm[name_a][:max_requests]:
                # 跳过纯静态资源，降低噪声
                if re.search(r"\.(png|jpg|jpeg|gif|css|js|svg|ico|woff2?)(\?|$)", req["url"], re.I):
                    continue
                tested += 1
                owner = probe(req, timeout, sess)
                cross = probe(swap_identity(req, donor), timeout, sess)
                anon = probe({**req, "headers": {k: v for k, v in req["headers"].items()
                                                 if k not in IDENTITY_HEADER_NAMES}}, timeout, sess)
                if owner["error"]:
                    errors += 1
                if cross.get("status") in (400, 401, 403, 404):
                    denied += 1
                f = assess(req, owner, cross, anon)
                if f:
                    key = (f["category"], req["method"], re.sub(r"\d+", "N", req["url"]))
                    if key not in seen:
                        seen.add(key)
                        findings.append(f)

    findings.sort(key=lambda f: ({"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}.get(f.get("severity"), 9), f.get("url", "")))
    summary = {
        "sessions": names,
        "requests_tested": tested,
        "cross_denied": denied,
        "transport_errors": errors,
        "idor": sum(1 for f in findings if f["category"] == "idor"),
        "bola": sum(1 for f in findings if f["category"] == "bola"),
        "total": len(findings),
    }
    logger.info("idor_replay: %s", json.dumps(summary, ensure_ascii=False))
    return {"ok": True, "findings": findings, "summary": summary}
