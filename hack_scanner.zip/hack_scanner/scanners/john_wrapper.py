#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
John Wrapper — John the Ripper CLI wrapper，离线 hash 破解。

与 hydra_wrapper（在线爆破）互补：
- hydra:  在线协议爆破（SSH/FTP/HTTP-POST），需要目标存活
- john:   离线 hash 破解（NTLM/MD5/SHA/bcrypt/keccak...），对已捕获的 hash 文件工作
- hashcat: GPU 加速（见 hashcat_wrapper）

支持格式（john 1.9+，--format=auto 自动识别）：
  raw-md5, raw-sha1, raw-sha256, bcrypt, nt, descrypt, openssl-kdf, keccak-256, ...

集成方式：需要安装 John
  - Windows: choco install john  或  https://www.openwall.com/john/（Windows 版 zip）
  - Linux:   apt install john
本模块只负责 CLI 调用和结果解析。config.json → tools.john_path 可指定路径。

Usage:
    from scanners.john_wrapper import john_crack, john_show, john_list_formats
    result = john_crack("hashes.txt", wordlist="rockyou.txt")
    cracked = john_show("hashes.txt")
"""

import json
import logging
import os
import re
import subprocess
import tempfile
from typing import Optional

logger = logging.getLogger('john_scanner')


def _find_john() -> Optional[str]:
    """查找 john 可执行文件：先 config.json → tools.john_path，再 PATH"""
    # 1) config.json tools.john_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("john_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["john", "john.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def john_crack(
    hash_file: str,
    wordlist: str = "",
    format: str = "",
    max_time: int = 3600,
) -> dict:
    """对 hash 文件运行 John 离线破解。

    Args:
        hash_file: hash 文件路径（每行一个 hash）
        wordlist: 字典文件路径（如 rockyou.txt）
        format: 指定 hash 格式（如 raw-md5/bcrypt/nt），空则用 auto 自动识别（john 1.9+）
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "cracked_count": N, "cracked": [{"hash","password"}], "loaded": N, "error": ""}
    """
    john_path = _find_john()
    if not john_path:
        return {
            "ok": False,
            "hash_file": hash_file,
            "cracked_count": 0,
            "error": "John 未找到，请安装: choco install john (Windows) 或 apt install john (Linux)",
        }

    if not os.path.isfile(hash_file):
        return {"ok": False, "hash_file": hash_file, "cracked_count": 0, "error": f"hash 文件不存在: {hash_file}"}

    cmd = [john_path, hash_file]
    if wordlist and os.path.isfile(wordlist):
        cmd.append(f"--wordlist={wordlist}")
    if format:
        cmd.append(f"--format={format}")
    else:
        cmd.append("--format=auto")   # john 1.9+；旧版可能报错，可显式指定 format
    cmd.append("--session=hack_scanner")  # 独立 session，避免污染用户默认 pot

    logger.info(f"john crack: {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        output = (proc.stdout or "") + (proc.stderr or "")

        # 解析 Loaded N password hashes (type)
        loaded = 0
        fmt = ""
        m = re.search(r'Loaded\s+(\d+)\s+password hashes?\s*\(([^)]*)\)', output)
        if m:
            loaded = int(m.group(1))
            fmt = m.group(2).strip()

        # 破解成功后立即 --show 提取 hash:password 对
        cracked = _john_show(john_path, hash_file)

        return {
            "ok": True,
            "hash_file": hash_file,
            "loaded": loaded,
            "format": fmt,
            "cracked_count": len(cracked),
            "cracked": cracked,
            "error": "",
        }

    except subprocess.TimeoutExpired:
        # 超时后仍尝试提取已破解的部分结果
        cracked = _john_show(john_path, hash_file) if _find_john() else []
        return {
            "ok": False,
            "hash_file": hash_file,
            "cracked_count": len(cracked),
            "cracked": cracked,
            "error": f"john 超时（最大时间 {max_time}s），已破解部分结果见 cracked",
        }


def john_show(hash_file: str) -> list:
    """提取 hash_file 中已破解的 hash:password 对。

    Returns:
        [{"hash": "...", "password": "..."}, ...]
    """
    john_path = _find_john()
    if not john_path or not os.path.isfile(hash_file):
        return []
    return _john_show(john_path, hash_file)


def _john_show(john_path: str, hash_file: str) -> list:
    """内部：john --show <file> 并解析 hash:password 行"""
    try:
        proc = subprocess.run(
            [john_path, "--show", "hack_scanner", hash_file],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60,
        )
        cracked = []
        for line in (proc.stdout or "").splitlines():
            line = line.strip()
            if ":" in line and "giving up" not in line.lower() and "best guess" not in line.lower():
                parts = line.split(":", 1)
                if len(parts) == 2 and parts[0] and parts[1]:
                    cracked.append({"hash": parts[0].strip(), "password": parts[1].strip()})
        return cracked
    except Exception as e:
        logger.warning(f"john --show failed: {e}")
        return []


def john_list_formats() -> dict:
    """列出当前 john 支持的 hash 格式。

    Returns:
        {"ok": True, "formats": ["raw-md5", "bcrypt", ...], "error": ""}
    """
    john_path = _find_john()
    if not john_path:
        return {"ok": False, "formats": [], "error": "John 未找到"}

    try:
        proc = subprocess.run([john_path, "--list=formats"], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30)
        formats = []
        for line in (proc.stdout or "").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                # 格式行可能是 "raw-md5 [sha512,avx512]" 或直接 "raw-md5"
                name = line.split()[0]
                if name and "-" in name or name.isalpha():
                    formats.append(name)
        return {"ok": True, "formats": formats}
    except Exception as e:
        return {"ok": False, "formats": [], "error": str(e)}
