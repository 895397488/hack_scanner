#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SSO / MFA / SAML Testing Module -- authenticate protocol detection and vulnerability testing.

Tests for common SSO/MFA misconfigurations and weaknesses:
  - SAML provider detection (Okta, Google, AzureAD, ADFS)
  - SAML signature verification bypass attempts
  - OAuth2 flow probing (implicit, authorization_code, client_credentials)
  - MFA brute-force / TOTP/HOTP testing
  - Client certificate authentication discovery
  - Session fixation detection

Usage:
    from scanners.ssoprobe import SSPROBE

    results = ssoprobe.detect_sso("https://example.com")
    print(f"Detected SSO providers: {results['providers']}")
"""

import base64
import hashlib
import hmac
import json
import logging
import math
import re
import struct
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse, parse_qs, urljoin, unquote

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger('ssoprobe')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class SSOProviderInfo:
    """Detected SSO provider."""
    provider: str               # 'Okta', 'Google', 'AzureAD', 'ADFS', 'Generic'
    discovery_url: str = ''
    metadata_url: str = ''
    client_id: str = ''
    is_configured: bool = False


@dataclass
class MFAResult:
    """MFA test result."""
    type_: str                  # 'totp', 'hotp', 'webauthn', 'sms', 'email_otp'
    is_bypassable: bool = False
    brute_force_possible: bool = False
    digit_count: int = 6
    algorithm: str = 'SHA1'
    vulnerability_description: str = ''


@dataclass
class SAMLInfo:
    """Detected SAML configuration."""
    idp_metadata_url: str = ''
    sso_binding: str = ''       # 'HTTP-Redirect' or 'HTTP-POST'
    signature_algorithm: str = ''
    is_signed: bool = False
    entity_id: str = ''
    login_url: str = ''
    x509_certificate: str = ''


# ====================================================================
# SSO Detection
# ====================================================================

class SSPROBE:
    """SSO / MFA / SAML testing engine (Acunetix SiteLogin SSO integration)."""

    # Common SSO provider indicators
    PROVIDER_INDICATORS = {
        'Okta': [r'okta\.com', r'oktapreview\.com', r'oktacdn\.com', r'/adfs/'],
        'Google': [r'accounts\.google\.com', r'oauth2\.googleapis\.com', r'openid\.google\.com'],
        'AzureAD': [r'login\.microsoftonline\.com', r'sso\.azure\.com', r'\.live\.com/', r'aadcdn\.msftauth\.net'],
        'ADFS': [r'/adfs/', r'adfsservice/', r'metadata/Adfs'],
        'Auth0': [r'auth0\.com', r'.auth0\.com/', r'/.well-known/openid-configuration'],
        'OneLogin': [r'onelogin\.com', r'/onelogin/', r'onepass\.com'],
        'PingFederate': [r'pingfederate', r'pingid', r'pingone'],
        'Keycloak': [r'/auth/realms/', r'/protocol/openid-connect/'],
        'IBM Security': [r'ibm\.com/sso', r'rsasign', r'websphere'],
    }

    # SAML-specific indicators
    SAML_INDICATORS = [
        r'<saml:', r'SAMLRequest', r'SAMLResponse', r'SigAlg',
        r'MetadataEndpoint', r'/SAML2/Metadata',
        r'urn:oasis:names:tc:SAML',
    ]

    # OAuth2 indicators
    OAUTH_INDICATORS = [
        r'/oauth/', r'/authorize', r'token_endpoint',
        r'grant_type=', r'response_type=code',
        r'client_id=', r'redirect_uri=',
    ]

    def __init__(self, timeout: int = 10):
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'Mozilla/5.0 (compatible; HackScanner/8.0 SSPROBE)',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        })

    # ------------------------------------------------------------------
    # SSO Provider Detection
    # ------------------------------------------------------------------

    def detect_sso_providers(self, url: str) -> List[SSOProviderInfo]:
        """Detect SSO providers by scanning the target page and common endpoints."""
        detected: List[SSOProviderInfo] = []

        # Scan HTML for provider indicators
        try:
            resp = self._session.get(url, timeout=self.timeout, allow_redirects=True, verify=False)
            soup = BeautifulSoup(resp.text, 'html.parser')
            page_text = (resp.text + resp.url + str(soup)).lower()

            for provider, indicators in self.PROVIDER_INDICATORS.items():
                matches = [ind for ind in indicators if re.search(ind, page_text)]
                if matches:
                    detected.append(SSOProviderInfo(
                        provider=provider,
                        is_configured=True,
                        discovery_url=url,
                    ))
        except requests.RequestException as exc:
            logger.error('SSO detection error for %s: %s', url, exc)

        # Try common SSO endpoints
        sso_paths = [
            '/.well-known/openid-configuration',
            '/.well-known/saml',
            '/saml/metadata',
            '/metadata',
            '/idp/profile/metaAlias/idp/metadata',
            '/adfs/ls/idpmetadata.xml',
            '/auth/realms/master/.well-known/openid-configuration',
        ]
        base = f'{urlparse(url).scheme}://{urlparse(url).netloc}'

        for path in sso_paths:
            try:
                resp2 = self._session.get(urljoin(base, path), timeout=self.timeout, verify=False)
                if resp2.status_code == 200 and any(
                    kw in resp2.text.lower() for kw in ['saml', 'openid', 'oauth', 'adfs']):
                    provider = self._identify_provider_from_text(resp2.text)
                    if provider:
                        existing = [d for d in detected if d.provider == provider]
                        if not existing:
                            detected.append(SSOProviderInfo(
                                provider=provider,
                                discovery_url=urljoin(base, path),
                                metadata_url=urljoin(base, path),
                                is_configured=True,
                            ))
            except requests.RequestException:
                pass

        return detected

    def _identify_provider_from_text(self, text: str) -> Optional[str]:
        """Identify SSO provider from page content."""
        text_lower = text.lower()
        for provider, patterns in self.PROVIDER_INDICATORS.items():
            for pattern in patterns:
                if re.search(pattern, text_lower):
                    return provider
        # Default to generic SAML/OAuth if indicators found
        if any(re.search(ind, text_lower) for ind in self.SAML_INDICATORS):
            return 'SAML'
        if any(re.search(ind, text_lower) for ind in self.OAUTH_INDICATORS):
            return 'OAuth2'
        return None

    # ------------------------------------------------------------------
    # SAML Testing
    # ------------------------------------------------------------------

    def test_saml_vulnerabilities(self, saml_info: SAMLInfo) -> Dict[str, Any]:
        """Test common SAML vulnerabilities."""
        results: Dict[str, Any] = {
            'vulnerabilities': [],
            'is_signed': saml_info.is_signed,
            'signature_algorithm': saml_info.signature_algorithm,
        }

        # Test 1: Signature verification bypass (SAML签名绕过)
        if not saml_info.is_signed:
            results['vulnerabilities'].append({
                'name': 'saml_unsigned_assertion',
                'severity': 'CRITICAL',
                'description': 'SAML Assertion未签名，攻击者可伪造任意用户身份',
                'mitigation': '确保所有SAML响应均使用X.509证书签名',
            })

        # Test 2: Weak signature algorithm
        if saml_info.signature_algorithm and 'sha1' in saml_info.signature_algorithm.lower():
            results['vulnerabilities'].append({
                'name': 'saml_weak_signature_algorithm',
                'severity': 'HIGH',
                'description': f'SAML使用弱签名算法: {saml_info.signature_algorithm}',
                'mitigation': '升级为sha256WithRSAEncryption或更强的算法',
            })

        # Test 3: Assertion not encrypted
        results['vulnerabilities'].append({
            'name': 'saml_assertion_encrypted',
            'severity': 'MEDIUM',
            'description': f'需要检查SAML Assertion是否加密 (IDP: {saml_info.idp_metadata_url})',
            'mitigation': '启用Assertion加密保护敏感属性',
        })

        # Test 4: Missing NameID format check
        results['vulnerabilities'].append({
            'name': 'saml_nameid_format',
            'severity': 'MEDIUM',
            'description': '需要检查NameID格式验证是否严格',
            'mitigation': '配置IdP元数据以验证EntityID和NameID格式',
        })

        return results

    def test_saml_signature_bypass(self, saml_response_url: str) -> Dict[str, Any]:
        """Attempt common SAML signature bypass attacks."""
        bypass_attempts: List[Dict[str, Any]] = []

        # Attack 1: Remove Signature block entirely
        attempt_1 = {
            'name': 'remove_signature',
            'description': '移除<SignedInfo>块后提交SAML响应',
            'payload_type': 'xml_modification',
        }
        bypass_attempts.append(attempt_1)

        # Attack 2: Change signature algorithm to none
        attempt_2 = {
            'name': 'null_signature',
            'description': '将SignatureAlgorithm改为"none"',
            'payload_type': 'algorithm_manipulation',
        }
        bypass_attempts.append(attempt_2)

        # Attack 3: XML entity expansion (Billion Laughs attack variant)
        attempt_3 = {
            'name': 'xml_entity_expansion',
            'description': '在<Signature>中注入实体展开导致DoS或签名绕过',
            'payload_type': 'xxe_attack',
        }
        bypass_attempts.append(attempt_3)

        return {'attempts': bypass_attempts, 'tested': len(bypass_attempts)}

    # ------------------------------------------------------------------
    # OAuth2 Testing
    # ------------------------------------------------------------------

    def test_oauth2_vulnerabilities(self, authorization_url: str) -> Dict[str, Any]:
        """Test OAuth2 configuration vulnerabilities."""
        results = {
            'vulnerabilities': [],
            'flows_tested': [],
        }

        try:
            resp = self._session.get(authorization_url, timeout=self.timeout, verify=False)
            text = resp.text + resp.url
            params = parse_qs(urlparse(resp.url).query)

            # Check 1: response_type=token (implicit flow - insecure for SPAs)
            if 'token' in text.lower() and 'code' not in text.lower():
                results['vulnerabilities'].append({
                    'name': 'oauth_implicit_flow',
                    'severity': 'HIGH',
                    'description': 'OAuth Implicit Flow (response_type=token) 暴露access_token到URL',
                    'mitigation': '使用Authorization Code + PKCE代替Implicit Flow',
                })

            # Check 2: Missing state parameter validation
            if 'state' not in [p.lower() for p in text.split()] or 'prompt=prompt':
                pass
            else:
                results['vulnerabilities'].append({
                    'name': 'oauth_missing_state',
                    'severity': 'HIGH',
                    'description': 'Authorization endpoint可能未验证state参数（CSRF风险）',
                    'mitigation': '确保所有OAuth请求包含并验证唯一的state参数',
                })

            # Check 3: response_type includes both code and token
            if 'code' in text.lower() and 'token' in text.lower():
                results['vulnerabilities'].append({
                    'name': 'oauth_hybrid_flow_misconfig',
                    'severity': 'MEDIUM',
                    'description': 'Hybrid Flow可能错误地暴露token到客户端',
                    'mitigation': '验证ID Token与code同时返回，并确保ID Token已签名',
                })

            # Check 4: scope validation
            if 'scope' in params:
                scopes = params['scope'][0].split()
                if 'admin' in scopes or 'root' in scopes:
                    results['vulnerabilities'].append({
                        'name': 'oauth_overprivileged_scope',
                        'severity': 'HIGH',
                        'description': f'发现过高权限scope: {scopes}',
                        'mitigation': '最小化授权scope，避免暴露admin/root级别的权限',
                    })

        except requests.RequestException as exc:
            results['error'] = str(exc)

        return results

    def test_oauth2_none_alg(self, token_endpoint: str) -> Dict[str, Any]:
        """Test JWT none-algorithm vulnerability (already in jwt_detector.py)."""
        try:
            from scanners.jwt_detector import detect_jwt_vulnerabilities as _jwt_check
            result = _jwt_check(token_endpoint)
            return {'jwt_none_alg': result.get('vulnerabilities', []), 'tested_by': 'jwt_detector'}
        except Exception as exc:
            return {'error': str(exc), 'tested_by': 'jwt_detector_unavailable'}

    # ------------------------------------------------------------------
    # MFA Testing
    # ------------------------------------------------------------------

    def detect_mfa_type(self, url: str) -> List[str]:
        """Detect MFA type by scanning the authentication page."""
        detected_types: List[str] = []
        try:
            resp = self._session.get(url, timeout=self.timeout, verify=False)
            text = resp.text.lower()

            if any(kw in text for kw in ['totp', 'google authenticator', 'authenticator app',
                                         'two-step verification', 'otp']):
                detected_types.append('totp')
            if any(kw in text for kw in ['sms', 'text message', 'phone number', 'mobile otp']):
                detected_types.append('sms')
            if any(kw in text for kw in ['webauthn', 'fido2', 'security key', 'yubikey']):
                detected_types.append('webauthn')
            if any(kw in text for kw in ['email code', 'email verification', 'otp via email']):
                detected_types.append('email_otp')
            if any(kw in text for kw in ['push notification', 'approve', 'deny push']):
                detected_types.append('push')
        except requests.RequestException:
            pass
        return detected_types

    def test_totp_brute_force(self, secret_length: int = 10) -> Dict[str, Any]:
        """Test if TOTP codes are weak (short secret). Standard TOTP is 20 bytes."""
        # Standard TOTP uses a 20-byte (160-bit) shared secret
        standard_secret_len = 20
        is_weak = secret_length < standard_secret_len

        return {
            'is_weak_secret': is_weak,
            'vulnerability_description': f'TOTP secret length {secret_length} < 标准长度 {standard_secret_len}' if is_weak else '',
            'brute_force_possible': secret_length < 10,
            'recommended_action': '使用至少20字节的随机secret' if is_weak else '',
        }

    def test_otp_brute_force(self, digit_count: int = 6) -> Dict[str, Any]:
        """Test OTP brute-force feasibility."""
        possible_codes = 10 ** digit_count
        # With rate limiting (10 attempts/min): need ~1.67 hours for all codes
        time_needed = (possible_codes / 10) / 60  # hours with rate limiting

        return {
            'digit_count': digit_count,
            'possible_codes': possible_codes,
            'brute_force_time_no_limit_hours': round(possible_codes / 3600 / 24, 2),
            'brute_force_time_with_rate_limit_hours': round(time_needed, 2),
            'is_feasible': possible_codes < 1_000_000,  # < 6 digits is easily brute-forceable
        }

    # ------------------------------------------------------------------
    # Client Certificate Detection
    # ------------------------------------------------------------------

    def detect_client_cert_auth(self, url: str) -> Dict[str, Any]:
        """Detect if the server requires or offers client certificate authentication."""
        result = {'client_cert_required': False, 'server_supported': False}

        try:
            resp = self._session.get(url, timeout=self.timeout, verify=False)
            # Check for certificate request in TLS handshake response
            status = resp.status_code
            headers = resp.headers

            # HTTP 496 = No SSL client certificate presented (server supports it!)
            if status == 496:
                result['client_cert_required'] = True
            elif status == 450:
                result['client_cert_required'] = True

            # Check for X-Client-Cert header in response
            if 'X-Client-Cert' in headers or 'SSL_CLIENT_S_DN' in headers:
                result['server_supported'] = True

            # Check for certificate-related HTTP headers
            cert_headers = [h for h in headers if 'cert' in h.lower() or 'ssl' in h.lower()]
            if cert_headers:
                result['ssl_headers'] = cert_headers

        except requests.RequestException as exc:
            result['error'] = str(exc)

        return result

    # ------------------------------------------------------------------
    # Session Fixation Detection
    # ------------------------------------------------------------------

    def test_session_fixation(self, login_url: str) -> Dict[str, Any]:
        """Test if the server reuses session IDs after login (session fixation vulnerability)."""
        result = {'fixation_possible': False, 'details': ''}

        try:
            # Step 1: Get a session ID before login
            resp_before = self._session.get(login_url, timeout=self.timeout, verify=False)
            pre_login_cookies = dict(self._session.cookies)

            # Step 2: Perform fake login (send credentials without actually authenticating)
            fake_creds = {'username': 'test', 'password': 'test'}
            resp_after = self._session.post(login_url, data=fake_creds, timeout=self.timeout, verify=False)
            post_login_cookies = dict(self._session.cookies)

            # Check if any cookie names persisted
            pre_names = set(pre_login_cookies.keys())
            post_names = set(post_login_cookies.keys())
            shared = pre_names & post_names
            if shared:
                result['fixation_possible'] = True
                result['details'] = f'Session cookies after login share names: {shared}'

            # Check for new session cookie being issued
            new_cookies = post_names - pre_names
            if new_cookies:
                result['new_session_issued'] = list(new_cookies)

        except requests.RequestException as exc:
            result['error'] = str(exc)

        return result


# ====================================================================
# Global instance & convenience functions
# ====================================================================

ssoprobe = SSPROBE()  # default global instance

def detect_sso_providers(url: str) -> List[SSOProviderInfo]:
    return ssoprobe.detect_sso_providers(url)

def test_saml_vulnerabilities(saml_info: SAMLInfo) -> Dict[str, Any]:
    return ssoprobe.test_saml_vulnerabilities(saml_info)

def test_oauth2_vulnerabilities(auth_url: str) -> Dict[str, Any]:
    return ssoprobe.test_oauth2_vulnerabilities(auth_url)

def detect_mfa_type(url: str) -> List[str]:
    return ssoprobe.detect_mfa_type(url)

def test_session_fixation(login_url: str) -> Dict[str, Any]:
    return ssoprobe.test_session_fixation(login_url)
