#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
entrypoint_patterns.py — 框架入口点模式库（4 项目升级清单 #5）
=====================================================================

借鉴 vulnhuntr __main__.py RepoOps 的 20+ 框架 route handler 正则表
（Flask/FastAPI/Django/Tornado/aiohttp/Sanic/Gradio/Starlette/GraphQL/
Lambda/Azure/Google...），并补 JS/PHP/Java/Go 常见路由。

用途：白盒分析时圈定"网络可达"文件/行（vulnhuntr 用它界定
remotely-exploitable 的范围）——shannon_context 桥接后，
ContextAnalyzer 的端点发现覆盖面从 5 框架升到 25+。

接口:
    detect_entrypoints(code) -> List[{framework, pattern, line}]
    scan_files(root, extensions=DEFAULT_EXTENSIONS) -> {relpath: [eps]}
        （含 test/docs/venv/site-packages/node_modules 排除，vulnhuntr 同款）

设计纪律:
    - 纯标准库（re/os/pathlib）、无网络
    - 读文件失败静默跳过；单个文件异常不影响整库
    - 正则全部预编译，跨文件复用
"""

from __future__ import annotations

import os
import re
from typing import Dict, List, Optional, Sequence, Tuple

__all__ = [
    "FRAMEWORK_PATTERNS",
    "DEFAULT_EXTENSIONS",
    "EXCLUDED_DIR_NAMES",
    "EXCLUDED_FILE_PREFIXES",
    "detect_entrypoints",
    "scan_files",
]

# 引号字符类（匹配 ' 或 "）——用模板占位避免正则里直接写引号导致
# Python 字符串定界混乱。@Q@ 在编译前替换为 ["']。
_QCLASS = '["\']'

# ---------------------------------------------------------------------------
# 模式库：(framework, regex_template)
# 顺序即报告顺序；同一行可命中多个框架（如 Flask 与 Starlette 共用 @app.route），
# 全部记录——调用方可自行去重。
# ---------------------------------------------------------------------------
_P = [
    # ---- 通用 async handler（vulnhuntr Async 类）----
    ("generic-async", r"async\s+def\s+\w+\(.*?request"),
    # ---- Gradio ----
    ("gradio", r"gr\.Interface\("),
    ("gradio", r"gr\.Interface\.launch\("),
    # ---- Flask / Quart ----
    ("flask", r"@app\.route\("),
    ("flask", r"@blueprint\.route\("),
    ("flask", r"class\s+\w+\(MethodView\)\s*:"),
    ("flask", r"@(?:app|blueprint)\.add_url_rule\("),
    # ---- FastAPI ----
    ("fastapi", r"@app\.(?:get|post|put|delete|patch|options|head|trace)\("),
    ("fastapi", r"@router\.(?:get|post|put|delete|patch|options|head|trace)\("),
    # ---- Django ----
    ("django", r"\bre_path\("),
    ("django", r"\burl\(\s*[r]?\s*@Q@"),
    ("django", r"@channel_layer\.group_add"),
    ("django", r"@database_sync_to_async"),
    # ---- Pyramid ----
    ("pyramid", r"@view_config\("),
    # ---- Bottle ----
    ("bottle", r"@(?:route|get|post|put|delete|patch)\("),
    # ---- Tornado ----
    ("tornado", r"class\s+\w+\((?:RequestHandler|WebSocketHandler)\)\s*:"),
    ("tornado", r"@tornado\.gen\.coroutine"),
    ("tornado", r"@tornado\.web\.asynchronous"),
    # ---- WebSockets ----
    ("websockets", r"websockets\.serve\("),
    ("websockets", r"@websocket\.(?:route|get|post|put|delete|patch|head|options)\("),
    # ---- aiohttp ----
    ("aiohttp", r"app\.router\.add_(?:get|post|put|delete|patch|head|options)\("),
    ("aiohttp", r"@routes\.(?:get|post|put|delete|patch|head|options)\("),
    # ---- Sanic ----
    ("sanic", r"@app\.(?:route|get|post|put|delete|patch|head|options)\("),
    ("sanic", r"@blueprint\.(?:route|get|post|put|delete|patch|head|options)\("),
    # ---- Falcon ----
    ("falcon", r"app\.add_route\("),
    # ---- CherryPy ----
    ("cherrypy", r"@cherrypy\.expose"),
    # ---- web2py ----
    ("web2py", r"def\s+\w+\(\)\s*:\s*return\s+dict\("),
    # ---- Starlette ----
    ("starlette", r"Route\(\s*@Q@"),
    # ---- Responder ----
    ("responder", r"@api\.route\("),
    # ---- Hug ----
    ("hug", r"@hug\.(?:get|post|put|delete|patch|options|head)\("),
    # ---- Dash ----
    ("dash", r"@app\.callback\("),
    # ---- GraphQL ----
    ("graphql", r"class\s+\w+\(graphene\.ObjectType\)\s*:"),
    ("graphql", r"@strawberry\.type"),
    # ---- 通用路由装饰器 ----
    ("generic-route", r"@route\("),
    ("generic-route", r"@endpoint\("),
    ("generic-route", r"@api\.\w+\("),
    # ---- AWS Lambda ----
    ("aws-lambda", r"def\s+lambda_handler\(event,\s*context\)\s*:"),
    ("aws-lambda", r"def\s+handler\(event,\s*context\)\s*:"),
    # ---- Azure Functions ----
    ("azure-functions", r"def\s+\w+\(req:\s*func\.HttpRequest\)"),
    # ---- Google Cloud Functions ----
    ("gcp-functions", r"def\s+\w+\(request\)\s*:"),
    # ---- Node/JS ----
    ("express", r"\bapp\.(?:get|post|put|delete|patch|all|route)\(\s*@Q@"),
    ("express", r"\brouter\.(?:get|post|put|delete|patch|all|use)\(\s*@Q@"),
    ("koa", r"router\.(?:get|post|put|delete|patch|all)\(\s*@Q@"),
    ("nestjs", r"@(?:Controller|Get|Post|Put|Delete|Patch)\("),
    ("nestjs", r"@(?:Get|Post|Put|Delete|Patch)\(\s*@Q@"),
    ("hapi", r"server\.route\(\{"),
    ("restify", r"server\.(?:get|post|put|del)\(\s*@Q@"),
    # ---- PHP ----
    ("php-superglobals", r"\$\s*_(?:GET|POST|REQUEST|FILES|COOKIE)\s*\["),
    ("laravel", r"\bRoute::(?:get|post|put|delete|patch|any)\(\s*@Q@"),
    ("laravel", r"->(?:get|post|put|delete|patch)\(\s*@Q@"),
    ("symfony", r"\$this->(?:get|post|request)"),
    ("codeigniter", r"\$this->(?:uri|input)"),
    # ---- Java/Spring ----
    ("spring", r"@RequestMapping\("),
    ("spring", r"@(?:Get|Post|Put|Delete|Patch)Mapping\("),
    ("spring", r"@RestController\b"),
    ("spring", r"@Controller\b"),
    ("jaxrs", r"@(?:GET|POST|PUT|DELETE|PATH)\("),
    # ---- Go ----
    ("go-stdlib", r"mux\.Handle(?:Func)?\(\s*@Q@"),
    ("go-stdlib", r"HandleFunc\(\s*@Q@"),
    ("gin", r"\b(?:r|router|engine)\.(?:GET|POST|PUT|DELETE|PATCH|Group)\(\s*@Q@"),
    ("echo", r"\be\.(?:GET|POST|PUT|DELETE|PATCH)\(\s*@Q@"),
    # ---- C# ----
    ("aspnet", r"\[?(?:HttpGet|HttpPost|HttpPut|HttpDelete|Route)\("),
    ("aspnet", r"\[Route\("),
]

FRAMEWORK_PATTERNS: List[Tuple[str, "re.Pattern[str]"]] = [
    (fw, re.compile(tpl.replace("@Q@", _QCLASS))) for fw, tpl in _P
]

# 扫描默认扩展名（白盒入口点常见宿主文件）
DEFAULT_EXTENSIONS = (".py", ".js", ".ts", ".php", ".java", ".go", ".cs")

# 排除目录（vulnhuntr to_exclude 同款 + node_modules）
EXCLUDED_DIR_NAMES = frozenset({
    "test", "tests", "example", "examples", "docs", "doc",
    "site-packages", "node_modules", ".venv", "venv", "virtualenv",
    "dist", "build", ".git", ".hg", ".tox", "__pycache__",
    "vendor", "third_party", "thirdparty", "static", "assets",
    "migrations", "fixtures",
})
# 排除文件名前缀（vulnhuntr file_names_to_exclude 同款）
EXCLUDED_FILE_PREFIXES = ("test_", "conftest", "spec.")
_EXCLUDED_FILE_SUFFIXES = ("_test.py", "_test.js", "_test.ts", ".spec.js", ".spec.ts")


def detect_entrypoints(code: str) -> List[Dict[str, object]]:
    """在一段源码里逐行找框架入口点。

    返回 [{framework, pattern, line}]（line 从 1 起）。
    同一行可命中多个模式（不同框架各自记录）。
    """
    if not code:
        return []
    found: List[Dict[str, object]] = []
    for lineno, line in enumerate(code.splitlines(), start=1):
        if not line.strip():
            continue
        for framework, rx in FRAMEWORK_PATTERNS:
            if rx.search(line):
                found.append({"framework": framework, "pattern": rx.pattern,
                              "line": lineno})
    return found


def _should_skip_dir(name: str) -> bool:
    return name in EXCLUDED_DIR_NAMES or name.startswith(".")


def _should_skip_file(name: str) -> bool:
    low = name.lower()
    for p in EXCLUDED_FILE_PREFIXES:
        if low.startswith(p):
            return True
    for s in _EXCLUDED_FILE_SUFFIXES:
        if low.endswith(s):
            return True
    return False


def scan_files(root: str,
               extensions: Optional[Sequence[str]] = None) -> Dict[str, List[Dict[str, object]]]:
    """递归扫描目录下所有入口点。

    返回 {相对路径: [eps]}（只含有命中的文件）。
    - 排除 EXCLUDED_DIR_NAMES / 测试文件 / 隐藏目录
    - extensions 默认 DEFAULT_EXTENSIONS；大小写不敏感
    - 单文件读取失败静默跳过；整目录不存在 → 空 dict
    """
    if not root or not os.path.isdir(root):
        return {}
    exts = {e.lower() if e.startswith(".") else e.lower() for e in (extensions or DEFAULT_EXTENSIONS)}
    out: Dict[str, List[Dict[str, object]]] = {}
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        # 就地剪枝排除目录（os.walk 不会下钻被删掉的目录）
        dirnames[:] = [d for d in dirnames if not _should_skip_dir(d)]
        rel_dir = os.path.relpath(dirpath, root)
        for fn in filenames:
            base = os.path.basename(fn)
            if _should_skip_file(base):
                continue
            ext = os.path.splitext(base)[1].lower()
            if ext not in exts:
                continue
            fp = fn if rel_dir == "." else os.path.join(rel_dir, base)
            full = os.path.join(dirpath, base)
            try:
                with open(full, "r", encoding="utf-8", errors="ignore") as fh:
                    code = fh.read()
            except OSError:
                continue
            eps = detect_entrypoints(code)
            if eps:
                out[fp] = eps
    return out


# ---------------------------------------------------------------------------
# CLI 自测
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    import tempfile

    sample = '''
from fastapi import FastAPI
app = FastAPI()

@app.get("/users/{uid}")
def user(uid: int):
    ...

from flask import Flask
app = Flask(__name__)

@app.route("/login", methods=["POST"])
def login():
    ...

@app.post("/x")
async def handler(request):
    ...
'''
    eps = detect_entrypoints(sample)
    fws = {e["framework"] for e in eps}
    assert "fastapi" in fws and "flask" in fws, fws
    print(f"[OK ] detect_entrypoints: {len(eps)} hits, frameworks={sorted(fws)}")

    # 目录扫描 + 排除
    with tempfile.TemporaryDirectory() as td:
        os.makedirs(os.path.join(td, "src"), exist_ok=True)
        os.makedirs(os.path.join(td, "tests"), exist_ok=True)
        os.makedirs(os.path.join(td, "venv", "site-packages"), exist_ok=True)
        with open(os.path.join(td, "src", "app.js"), "w", encoding="utf-8") as f:
            f.write('app.get("/a", handler)\n')
        with open(os.path.join(td, "tests", "test_app.js"), "w", encoding="utf-8") as f:
            f.write('app.get("/b", handler)\n')
        with open(os.path.join(td, "venv", "site-packages", "lib.js"), "w", encoding="utf-8") as f:
            f.write('app.get("/c", handler)\n')
        got = scan_files(td, extensions=(".js",))
        expected = os.path.join("src", "app.js")
        assert set(got.keys()) == {expected}, got.keys()
    print("[OK ] scan_files: hit src/app.js, excluded tests/venv dirs")

    # 空输入不抛
    assert detect_entrypoints("") == [] and scan_files("/no/such/dir") == {}
    print("[OK ] boundary inputs safe")
    sys.exit(0)
