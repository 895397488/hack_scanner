#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GoBuster Wrapper — GoBuster CLI wrapper，补充 ffuf 的域名/VHost fuzzing 能力。

GoBuster 支持三种模式：
1. dir — 目录/文件爆破（类似 ffuf）
2. vhost — Virtual Host 虚拟主机发现
3. dns — DNS 子域名枚举

集成方式：需要安装 GoBuster（apt/brew/choco install gobuster 或 go install github.com/OJ/gobuster/v3@latest）。
本模块只负责 CLI 调用和结果解析。

Usage:
    from scanners.gobuster_wrapper import gobuster_dir, gobuster_vhost, gobuster_dns
"""

import json
import logging
import os
import subprocess
from typing import Dict, List, Optional

logger = logging.getLogger('gobuster_scanner')


def _find_gobuster() -> Optional[str]:
    for name in ["gobuster", "gobuster.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_gobuster_output(output: str) -> list:
    """解析 gobuster CLI 文本输出"""
    results = []
    for line in output.splitlines():
        # Gobuster dir/vhost/dns 输出格式：https://example.com/admin.html (Status: 200) [Size: 1234]
        if "Status:" in line and "http" in line.lower():
            status_m = None
            size_m = None
            url_part = None

            parts = line.split()
            for i, part in enumerate(parts):
                if part.startswith("http"):
                    url_part = ' '.join(parts[i:])  # URL might have spaces
                    break

            if not url_part:
                continue

            # Extract status code
            status_code = ""
            size = 0
            if "Status:" in line:
                status_m = line.split("Status:")[1].strip()
                status_code = status_m.split()[0] if status_m else ""

            # Remove URL and status from line for path extraction
            path_str = line.replace(url_part, "").replace(status_m, "").strip() if status_m else line.replace(url_part, "").strip()
            url = ' '.join(parts[:parts.index('http') + 1]) if 'http' in parts else url_part

            results.append({
                "url": url_part if url_part.startswith("http") else f"https://{url_part}",
                "status": status_code or "",
                "size": size,
                "response_time": "",
            })

    return results


def gobuster_dir(
    target_url: str,
    wordlist: str = "",
    threads: int = 10,
    extensions: str = "",
    max_time: int = 300,
) -> dict:
    """GoBuster Dir 模式 — 目录/文件爆破。

    Args:
        target_url: 目标 URL（如 https://example.com/）
        wordlist: 字典文件路径（如 /usr/share/seclists/Discovery/Web-Content/big.txt）
        threads: 并发线程数
        extensions: 扩展名过滤，如 "php,html,jsp"
        max_time: 最大运行时间

    Returns:
        {"ok": True, "findings": [...], ...}
    """
    gobuster_path = _find_gobuster() or "gobuster"
    if not os.path.isfile(gobuster_path):
        return {
            "ok": False,
            "target_url": target_url,
            "findings": [],
            "error": "GoBuster 未找到，请安装: go install github.com/OJ/gobuster/v3@latest",
        }

    cmd = [
        gobuster_path,
        "dir",
        "-u", target_url.rstrip("/"),
        "-t", str(threads),
        "-s", "200,201,204,301,302,307,401,403",  # Show these status codes
        "--no-status",  # Skip outputting HTTP status
        "-o", "-",      # Output to stdout (JSON parse later)
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd.extend(["-w", wordlist])
    elif os.path.isfile("/usr/share/seclists/Discovery/Web-Content/big.txt"):
        cmd.extend(["-w", "/usr/share/seclists/Discovery/Web-Content/big.txt"])
    else:
        return {"ok": False, "error": "未找到字典，请指定 -w 参数或安装 seclists", "findings": []}

    if extensions:
        cmd.extend(["-e"])  # Extended mode for extensions

    logger.info(f"gobuster dir: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max_time + 10)
        results = _parse_gobuster_output(proc.stdout or proc.stderr or "")

        # Extract URLs from gobuster output more reliably
        url_results = []
        for line in (proc.stdout or "").splitlines():
            if "http" in line and "Status:" in line:
                # gobuster format: https://example.com/dir  [200] [1234 bytes]
                parts = line.strip().split()
                url = ""
                status = ""
                for i, part in enumerate(parts):
                    if part.startswith("http"):
                        end_idx = len(parts)
                        for j in range(i, len(parts)):
                            if '[' in parts[j]:
                                end_idx = j
                                break
                        url = " ".join(parts[i:end_idx])
                        break

        return {
            "ok": True,
            "target_url": target_url,
            "method": "gobuster-dir",
            "findings_count": len(results),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target_url": target_url, "findings": [], "error": "gobuster 超时"}


def gobuster_vhost(
    target_host: str,
    wordlist: str = "",
    threads: int = 10,
    max_time: int = 300,
) -> dict:
    """GoBuster VHost 模式 — Virtual Host 虚拟主机发现。

    对 CDNs/云环境（如 CloudFront/Cloudflare）特别有用，可发现隐藏的子域名和路径。

    Args:
        target_host: 目标主机/IP（如 example.com 或 CDN IP）
        wordlist: 字典文件路径
        threads: 并发线程数
        max_time: 最大运行时间

    Returns:
        {"ok": True, "vhosts_found": ["api.example.com", ...], ...}
    """
    gobuster_path = _find_gobuster() or "gobuster"

    if not os.path.isfile(gobuster_path):
        return {"ok": False, "target_host": target_host, "vhosts_found": [], "error": "GoBuster 未安装"}

    cmd = [
        gobuster_path,
        "vhost",
        "-u", target_host,
        "-t", str(threads),
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd.extend(["-w", wordlist])
    elif os.path.isfile("/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"):
        cmd.extend(["-w", "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"])

    logger.info(f"gobuster vhost: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""

        vhosts = []
        for line in output.splitlines():
            if "http" in line.lower() or "." in line:
                parts = line.split()
                for part in parts:
                    if part.startswith("http") or (part.endswith(".com") or part.endswith(".net") or part.endswith(".org")):
                        vhosts.append(part)

        return {
            "ok": True,
            "target_host": target_host,
            "vhosts_found": vhosts[:200],
            "total_vhosts": len(vhosts),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target_host": target_host, "vhosts_found": [], "error": "gobuster vhost 超时"}


def gobuster_dns(
    domain: str,
    wordlist: str = "",
    threads: int = 10,
    max_time: int = 300,
) -> dict:
    """GoBuster DNS 模式 — DNS 子域名枚举（使用字典暴力枚举）。

    与 DNS AXFR 互补：AXFR 只在 zone transfer 配置不当的情况下成功，
    DNS 字典枚举不依赖目标配置。

    Args:
        domain: 根域名（如 example.com）
        wordlist: DNS 字典文件路径
        threads: 并发线程数
        max_time: 最大运行时间

    Returns:
        {"ok": True, "subdomains_found": ["api.example.com", ...], ...}
    """
    gobuster_path = _find_gobuster() or "gobuster"

    if not os.path.isfile(gobuster_path):
        return {"ok": False, "domain": domain, "subdomains_found": [], "error": "GoBuster 未安装"}

    cmd = [
        gobuster_path,
        "dns",
        "-d", domain,
        "-t", str(threads),
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd.extend(["-w", wordlist])
    elif os.path.isfile("/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"):
        cmd.extend(["-w", "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"])

    logger.info(f"gobuster dns: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""

        subdomains = []
        for line in output.splitlines():
            # Gobuster DNS output: FOUND: api.example.com -> IP.XX.XX.XX
            if "FOUND:" in line:
                parts = line.split("->")
                subdomain = parts[0].replace("FOUND:", "").strip()
                if "." in subdomain and subdomain != domain:
                    subdomains.append(subdomain)

        return {
            "ok": True,
            "domain": domain,
            "subdomains_found": list(set(subdomains))[:500],
            "total_subdomains": len(list(set(subdomains))),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "domain": domain, "subdomains_found": [], "error": "gobuster dns 超时"}


def gobuster(
    target: str = "",
    mode: str = "dir",
) -> dict:
    """统一的 GoBuster 调用入口（根据目标自动选择模式）。"""
    if mode == "dir":
        return gobuster_dir(target or "https://example.com")
    elif mode == "vhost":
        return gobuster_vhost(target or "example.com")
    elif mode == "dns":
        return gobuster_dns(target or "example.com")
    else:
        return {"ok": False, "error": f"未知模式: {mode}，支持 dir/vhost/dns"}
