#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WAF Detection — 通过 wafw00f 检测目标是否部署了 Web 应用防火墙。

集成方式：使用 wafw00f 的 Python API（可 pip install wafw00f）+ CLI fallback。

Usage:
    from scanners.waf_detector import detect_waf
    result = detect_waf("https://example.com")
    print(result)  # {"wafs_detected": ["Cloudflare"], "url": "...", "ok": True}
"""

import json
import subprocess
import sys
import logging
from typing import Dict, List, Optional

logger = logging.getLogger('waf_detector')

# ── wafw00f Python API ──
try:
    from wafw00f.main import WAFW00F
    HAS_WAFW00F_API = True
except ImportError:
    HAS_WAFW00F_API = False


def detect_waf(url: str, timeout: int = 15) -> dict:
    """检测 URL 目标的 WAF/IPS/WAF-like 设备。

    Args:
        url: 目标 URL（会做探测请求）
        timeout: 单个请求超时秒数

    Returns:
        {
            "ok": True/False,
            "target": "https://example.com",
            "wafs_detected": ["Cloudflare", ...],
            "generic_detection": True/False,
            "error": "" (如果有)
        }
    """
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url

    # ── 方法1：wafw00f Python API ──
    if HAS_WAFW00F_API:
        try:
            waf = WAFW00F(url, followredirect=True)
            # waf.identwaf() 返回检测到的 WAF 名称列表
            wafs = waf.identwaf()
            return {
                "ok": True,
                "target": url,
                "wafs_detected": wafs or [],
                "generic_detection": False,
                "error": "",
            }
        except Exception as e:
            logger.warning(f"wafw00f API 失败，回退到 CLI: {e}")

    # ── 方法2：CLI fallback ──
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "wafw00f", "--timeout", str(timeout), url],
            capture_output=True, text=True, timeout=timeout + 10,
        )
        wafs = []
        for line in proc.stdout.splitlines():
            line = line.strip()
            if 'Found' in line and ':' in line:
                parts = line.split(':', 1)
                if len(parts) == 2 and parts[1].strip():
                    wafs.append(parts[1].strip())
        return {
            "ok": True,
            "target": url,
            "wafs_detected": wafs,
            "generic_detection": False,
            "error": "",
        }
    except Exception as e:
        logger.error(f"WAF 检测失败: {e}")
        return {
            "ok": False,
            "target": url,
            "wafs_detected": [],
            "generic_detection": False,
            "error": str(e),
        }
