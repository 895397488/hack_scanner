#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hydra Wrapper — Hydra CLI wrapper，针对 CTF/授权渗透测试的认证暴力破解。

Thc-Hydra 是业界最经典的离线/在线密码破解工具，支持：
SSH / FTP / HTTP(S) / RDP / SMB / SMTP / POP3 / MySQL / PostgreSQL / Redis / Telnet 等 50+ 协议。

Usage:
    from scanners.hydra_wrapper import hydra_http_post, hydra_ssh, hydra_ftp
    result = hydra_http_post("example.com", "POST /login.php HTTP/1.1", "-l admin -p pass")
"""

import json
import logging
import os
import subprocess
from typing import Dict, List, Optional

logger = logging.getLogger('hydra_scanner')


def _find_hydra() -> Optional[str]:
    for name in ["hydra", "thc-hydra", "hydra.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def hydra_http_post(
    host: str,
    port: int = 80,
    http_path: str = "/",
    user_file: Optional[str] = None,
    pass_file: Optional[str] = None,
    users: List[str] = None,
    passwords: List[str] = None,
    max_time: int = 600,
) -> dict:
    """针对 HTTP POST 登录表单进行暴力破解测试。

    Args:
        host: 目标主机
        port: HTTP 端口（默认 80）
        http_path: 登录请求路径，如 "/login" 或 "POST /login.php HTTP/1.1:username=^USER^&password=^PASS^&login=submit"
        user_file: 用户名列表文件
        pass_file: 密码字典文件
        users: 内联用户名列表
        passwords: 内联密码列表
        max_time: 最大运行时间

    Returns:
        {"ok": True, "credentials_found": [{"user": "...", "pass": "..."}], ...}
    """
    hydra_path = _find_hydra() or "hydra"
    if not os.path.isfile(hydra_path):
        return {
            "ok": False,
            "host": host,
            "credentials_found": [],
            "error": "Hydra 未找到，请安装: apt install hydra / brew install theharvester",
        }

    cmd = [
        hydra_path,
        "-l", (user_file or (users[0] if users else "")),
        "-L", user_file or (",".join(users[:20]) if users else ""),
        "-p", (pass_file or ("-" + ",".join(passwords[:100]) if passwords else "password")),
    ]

    if pass_file:
        cmd.extend(["-P", pass_file])
    elif passwords:
        cmd.extend(["-P", "/tmp/hydra_pass.tmp"])
        with open("/tmp/hydra_pass.tmp", "w") as f:
            f.write("\n".join(passwords))

    if user_file:
        cmd.extend(["-S"])  # SSL

    cmd.extend([
        "-t", "16",         # parallel tasks
        "-V",               # verbose
        "-f",               # stop on first found
        "-w", "30",         # timeout per connection
        "-s", str(port),    # port
        host,
        "http-post-form",   # protocol
        f"{http_path}:^USER^:^PASS^:S|(200|301|302):H=Set-Cookie:",  # success check
    ])

    logger.info(f"hydra: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=max_time)
        stdout = proc.stdout or ""

        creds = []
        for line in stdout.splitlines():
            if ":" in line and ("[OUT]" in line or "LOGIN" in line):
                parts = line.split(":", 3)
                if len(parts) >= 4:
                    creds.append({
                        "user": parts[1].strip() if len(parts) > 1 else "",
                        "pass": parts[2].strip() if len(parts) > 2 else "",
                    })

        return {
            "ok": True,
            "host": host,
            "protocol": "http-post-form",
            "credentials_found": creds[:10],
            "total_attempts": stdout.count("login:"),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "host": host, "credentials_found": [], "error": f"Hydra 超时（最大 {max_time}s）"}
    finally:
        try:
            os.remove("/tmp/hydra_pass.tmp")
        except OSError:
            pass


def hydra_ssh(
    host: str,
    port: int = 22,
    user_file: Optional[str] = None,
    pass_file: Optional[str] = None,
) -> dict:
    """针对 SSH 服务进行暴力破解测试。"""
    hydra_path = _find_hydra() or "hydra"

    cmd = [hydra_path, "-l", "admin", "-P", pass_file or "/usr/share/wordlists/rockyou.txt",
           "-t", "16", "-V", "-s", str(port), host, "ssh"]

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        return {"ok": True, "host": host, "protocol": "ssh", "output": (proc.stdout or "")[:2000]}
    except Exception as e:
        return {"ok": False, "host": host, "error": str(e)}


def hydra_ftp(
    host: str,
    port: int = 21,
    user_file: Optional[str] = None,
    pass_file: Optional[str] = None,
) -> dict:
    """针对 FTP 服务进行暴力破解测试。"""
    hydra_path = _find_hydra() or "hydra"

    cmd = [hydra_path, "-l", "anonymous", "-P", pass_file or "/usr/share/wordlists/rockyou.txt",
           "-t", "16", "-V", "-s", str(port), host, "ftp"]

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        return {"ok": True, "host": host, "protocol": "ftp", "output": (proc.stdout or "")[:2000]}
    except Exception as e:
        return {"ok": False, "host": host, "error": str(e)}


def hydra(
    target: str = "",
    service: str = "ssh",
) -> dict:
    """通用的 Hydra 调用入口（根据 service 选择协议）。"""
    if not target:
        return {"ok": False, "error": "需要指定 target host"}

    if service == "ssh":
        return hydra_ssh(target)
    elif service == "ftp":
        return hydra_ftp(target)
    elif service == "http-post-form":
        return hydra_http_post(target)
    else:
        return {"ok": False, "error": f"未知服务: {service}，支持 ssh/ftp/http-post-form"}
