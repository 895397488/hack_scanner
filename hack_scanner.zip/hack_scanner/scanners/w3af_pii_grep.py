#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
w3af PII Grep Engine — 借鉴 w3af (w3af.org) grep 插件的敏感数据/PII 检测模式。

在 HTTP 响应内容中扫描并发现敏感的个人信息和凭证：
- 信用卡号 (Visa/MC/Amex/Discover/JCB)
- SSN / National ID numbers
- API Keys / Secrets / Tokens
- Passwords in code/config
- Email addresses & phone numbers
- AWS/GCP/Azure credentials
- MongoDB URLs with passwords
- Git private keys

Usage:
    from scanners.w3af_pii_grep import PIIGrepEngine, detect_pii_in_text

    engine = PIIGrepEngine()
    results = engine.scan("https://example.com", response_text)
    # -> [{'type': 'credit_card', 'value': '4xxx-xxxx...', 'pattern_name': 'visa_masked'}, ...]
"""

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Pattern, Tuple
from urllib.parse import urlparse

logger = logging.getLogger('w3af_pii_grep')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class PIIFinding:
    """A single PII finding."""
    finding_type: str           # 'credit_card', 'ssn', 'api_key', 'password', etc.
    value: str                  # Redacted/masked representation
    raw_value: str = ''         # Original matched text (can be redacted for security)
    pattern_name: str = ''      # Name of the regex pattern that matched
    confidence: float = 0.5     # 0.0 - 1.0
    context: str = ''           # Surrounding text for triage
    category: str = 'pii'       # 'pii', 'credential', 'secret', 'url'

    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': self.finding_type,
            'category': self.category,
            'value': self.value[:80] + ('...' if len(self.value) > 80 else ''),
            'pattern_name': self.pattern_name,
            'confidence': self.confidence,
            'context': self.context[:120],
        }


# ====================================================================
# PII Grep Engine (inspired by w3af grep plugins: credit_cards, passwords, api_keys, etc.)
# ====================================================================

class PIIGrepEngine:
    """Scan HTTP responses for sensitive PII and credentials (w3af-style grep)."""

    # Credit card patterns (Luhn-validating where possible)
    CREDIT_CARD_PATTERNS: List[Tuple[str, Pattern]] = [
        ('visa', re.compile(r'\b4[0-9]{12}(?:[0-9]{3})?\b')),
        ('mastercard', re.compile(r'\b5[1-5][0-9]{14}\b')),
        ('amex', re.compile(r'\b3[47][0-9]{13}\b')),
        ('discover', re.compile(r'\b6(?:011|5[0-9]{2})[0-9]{12}\b')),
        ('jcb', re.compile(r'\b(?:2131|1800|35\d{3})\d{11}\b')),
        ('generic_cc_masked', re.compile(r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b')),
        ('generic_cc_continuous', re.compile(r'\b(?:4|5|3|6)\d{15,18}\b')),
    ]

    # SSN / National ID patterns
    SSN_PATTERNS: List[Tuple[str, Pattern]] = [
        ('ssn_us', re.compile(r'\b\d{3}-\d{2}-\d{4}\b')),
        ('ssn_masked_partial', re.compile(r'(?:SSN|social.?security)[\s:=]+["\']?\d{3}[-\s]?\d{2}[-\s]?\d{4}', re.I)),
    ]

    # API Key / Secret patterns
    SECRET_PATTERNS: List[Tuple[str, Pattern]] = [
        ('aws_access_key', re.compile(r'(?:AKIA|ABIA|ACCA)[0-9A-Z]{16}')),
        ('github_token', re.compile(r'gh[pousr]_[0-9a-zA-Z]{36,}')),
        ('slack_token', re.compile(r'xox[baprs]-[0-9a-zA-Z-]{10,48}')),
        ('generic_api_key', re.compile(r'(?:api[_-]?key|apikey)[\s:=]+["\']?([0-9a-zA-Z\-_]{20,})', re.I)),
        ('generic_secret', re.compile(r'(?:secret|secret[_-]key)[\s:=]+["\']?([0-9a-zA-Z\-_]{16,})', re.I)),
        ('generic_password_config', re.compile(r'(?:password|passwd|pwd)[\s:=]+["\']?([^"\s]{8,})["\']?', re.I)),
        ('jwt_token', re.compile(r'eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_\-]{10,}')),
        ('private_key_pem', re.compile(r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----')),
        ('basic_auth_url', re.compile(r'https://([^:]+):([^@]+)@')),
        ('sendgrid_key', re.compile(r'SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}')),
        ('twilio_sid', re.compile(r'AC[a-f0-9]{32}')),
    ]

    # Password in source code / config patterns (w3af password grep)
    PASSWORD_IN_SOURCE: List[Tuple[str, Pattern]] = [
        ('php_password', re.compile(r'(?:\$password|passwd)\s*=\s*["\']([^"\']{4,})["\']', re.I)),
        ('js_password', re.compile(r'(?:password\s*[:=]\s*)["\']([^"\']{4,})["\']', re.I)),
        ('python_password', re.compile(r"(?:password|passwd)\s*=\s*['\"]([^'\"]{4,})['\"]", re.I)),
        ('mysql_root_pass', re.compile(r'(?:root)[\s:=]+["\']?([a-zA-Z0-9_\-]{8,})["\']?', re.I)),
        ('wp_config_key', re.compile(r"(?:AUTH_KEY|SECURE_AUTH_KEY|LOGGED_IN_KEY)\s*=\s*'([^']{32,})'", re.I)),
        ('connection_string_password', re.compile(r'(?:Password|PWD|pass)=([^;\'\s&]{6,})', re.I)),
    ]

    # URL patterns with embedded credentials
    CREDENTIAL_URL_PATTERNS: List[Tuple[str, Pattern]] = [
        ('mongodb_cred', re.compile(r'mongodb(?:\+srv)?://([^:]+):([^@]+)@')),
        ('mysql_url_creds', re.compile(r'mysql://([^:]+):([^@]+)@')),
        ('postgres_url_creds', re.compile(r'postgresql?://([^:]+):([^@]+)@')),
        ('redis_url_creds', re.compile(r'redis://([^:]+):([^@]+)@')),
        ('smtp_cred', re.compile(r'smtp://([^:]+):([^@]+)@')),
    ]

    # Email + phone patterns
    CONTACT_PATTERNS: List[Tuple[str, Pattern]] = [
        ('email_in_context', re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')),
        ('phone_us', re.compile(r'\b1?[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b')),
    ]

    # ReDoS patterns (w3af ReDoS vulnerability detection)
    REDOS_PATTERNS: List[Tuple[str, Pattern]] = [
        ('redos_catastrophic_backtrack', re.compile(r'(\((?:[^\)]+|\([^\)]+\))*\)[*+])')),
        ('redos_nested_quantifier', re.compile(r'([^{}\[\]()>+][*+])\{[^}]+\}\s*\1')),
    ]

    # Response splitting patterns (w3af Response Splitting)
    RESPONSE_SPLITTING_PATTERNS: List[Tuple[str, Pattern]] = [
        ('crlf_in_response', re.compile(r'[\r\n][^\n]*?(?:Set-Cookie|Location|Content-Type)[:\s]')),
        ('http_response_splitting_header', re.compile(r'[\"\']?\r?\n.*?(?:HTTP/|200|30[12]|40[34])')),
    ]

    # Directory listing / public writable dir patterns (w3af Insecure DAV / Publicly writable)
    DIR_VULN_PATTERNS: List[Tuple[str, Pattern]] = [
        ('dav_configuration', re.compile(r'(?:DAV:\s*dav|allowmethods\s*:\s*\*)', re.I)),
        ('publicly_writable_dir', re.compile(r'207\s*MULTI-STATUS|Allow:\s*([A-Z,]+).*?WRITE', re.I)),
    ]

    # Server-side include patterns (w3af SSI vulnerability)
    SSI_PATTERNS: List[Tuple[str, Pattern]] = [
        ('ssi_include', re.compile(r'<!--\s*(?:#include|#exec|<!--#set\b)[^>]+-->', re.I)),
        ('ssi_persistent', re.compile(r'(?:<!--#include virtual|file\s*=\s*)"[^"]{3,}"', re.I)),
    ]

    # FrontPage extension patterns (w3af insecure frontpage)
    FRONTPAGE_PATTERNS: List[Tuple[str, Pattern]] = [
        ('frontpage_exists', re.compile(r'(?:_vti_pvt|_layouts|_private|fpcount\.php)', re.I)),
        ('frontpage_credentials_in_config', re.compile(r'(?:_vti_bin/ows\.dll|_vti_inf\.html)', re.I)),
    ]

    # Phishing vector patterns (w3af phishing_vector plugin)
    PHISHING_PATTERNS: List[Tuple[str, Pattern]] = [
        ('phishing_form', re.compile(r'<form[^>]*action=["\']https?://[^/]{10,}[^/]{4,}/[^\n]+["\'][^>]*>[^<]*login[^<]*</form>', re.I | re.S)),
        ('credential_capture_action', re.compile(r'(?:action|href)\s*=\s*["\']https?://(?!localhost)([^"/]{10,}/)[^\n"\'<>]+\.(?:php|asp|jsp|html)[^\n"\'<>]*login', re.I | re.S)),
    ]

    # Eval/input injection (w3af eval plugin)
    EVAL_INJECTION_PATTERNS: List[Tuple[str, Pattern]] = [
        ('eval_injection', re.compile(r'(?<![a-zA-Z_])eval\s*\(\s*(?:\$_(?:GET|POST|REQUEST|COOKIE)|param|input|query)', re.I)),
        ('assert_injection', re.compile(r'(?<![a-zA-Z_])assert\s*\(\s*(?:\$_(?:GET|POST|REQUEST|COOKIE)|request\.form)', re.I)),
        ('exec_injection', re.compile(r'(?<![a-zA-Z_])(?:exec|system|passthru|popen)\s*\(\s*(?:\$_|param|input|request\.get)', re.I)),
    ]

    # preg_replace patterns (w3af unsafe preg_replace)
    PREG_REPLACE_PATTERNS: List[Tuple[str, Pattern]] = [
        ('preg_replace_e_flag', re.compile(r'preg_replace\s*\(\s*[^\n]+,\s*["\']([^"\']+)[^"\']*e[^"\']*["\'],\s*.*?\)', re.I)),
        ('preg_replace_dynamic_pattern', re.compile(r'preg_replace\s*\(\s*(\$|param|input|request)', re.I)),
    ]

    # Shell shock pattern (w3af shell_shock)
    SHELL_SHOCK_PATTERNS: List[Tuple[str, Pattern]] = [
        ('shellshock_ua', re.compile(r'\(\)\s*{\s*:\s*\);\s*/[a-z]')),
    ]

    # Format string patterns (w3af format_string vulnerability)
    FORMAT_STRING_PATTERNS: List[Tuple[str, Pattern]] = [
        ('format_string_unsafe', re.compile(r'(?:printf|sprintf|fprintf)\s*\(\s*(?!\")(?:%[^n])', re.I)),
    ]

    # MX injection pattern (w3af mx_injection) - detecting mail header injection
    MX_INJECTION_PATTERNS: List[Tuple[str, Pattern]] = [
        ('mail_header_injection', re.compile(r'(?:To|Cc|Bcc|Reply-To)\s*[:=]\s*[^\n]*[@][\r\n]')),
    ]

    # LDAP injection patterns (w3af ldap_injection)
    LDAP_INJECTION_PATTERNS: List[Tuple[str, Pattern]] = [
        ('ldap_injection_payload', re.compile(r'(?<=[()\w])(?:[\*\(\)]|\\\\)', re.I)),
        ('ldap_dynamic_filter', re.compile(r'(?:ldap_search|LDAPSearch)\s*\(.*?(\$\{|%[0-9]|\.\.)')),
    ]

    # XPATH injection patterns (w3af xpath_injection)
    XPATH_INJECTION_PATTERNS: List[Tuple[str, Pattern]] = [
        ('xpath_dynamic_input', re.compile(r'(?:xpath|XPath)\s*[=:]\s*.*?(?:\$\{|request|param)', re.I)),
        ('xpath_eval_with_concat', re.compile(r'xpath\s*\(\s*(.+?)\.\.', re.I)),
    ]

    # Reflected file download (w3af RFD)
    RFD_PATTERNS: List[Tuple[str, Pattern]] = [
        ('rfd_filename_param', re.compile(r'(?:download|file|name)\s*=\s*\$\{?[0-9a-f]{4,}\}?', re.I)),
        ('rfd_content_disposition_echo', re.compile(r'disposition:\s*attachment;\s*filename\s*=\s*[\"\']?(?:\$\{|request|param)', re.I)),
    ]

    # Server-side include vulnerability patterns
    SSI_RESPONSE_PATTERNS: List[Tuple[str, Pattern]] = [
        ('ssi_echoed', re.compile(r'(?:<!--#include|#exec)-->', re.I)),
    ]

    def __init__(self, min_confidence: float = 0.3):
        self._min_confidence = min_confidence
        # Compile all patterns at once for performance
        self._compiled_patterns: List[Tuple[str, str, Pattern, str]] = []
        self._compile_all_patterns()

    def _compile_all_patterns(self):
        """Compile all pattern lists into a single list for efficient scanning."""
        groups = [
            ('credit_card', 'credential', self.CREDIT_CARD_PATTERNS),
            ('ssn', 'pii', self.SSN_PATTERNS),
            ('secret_or_key', 'secret', self.SECRET_PATTERNS),
            ('password_in_source', 'credential', self.PASSWORD_IN_SOURCE),
            ('cred_url', 'url', self.CREDENTIAL_URL_PATTERNS),
            ('contact', 'pii', self.CONTACT_PATTERNS),
            ('redos', 'info', self.REDOS_PATTERNS),
            ('response_splitting', 'high', self.RESPONSE_SPLITTING_PATTERNS),
            ('dir_vuln', 'medium', self.DIR_VULN_PATTERNS),
            ('ssi', 'info', self.SSI_PATTERNS),
            ('frontpage', 'info', self.FRONTPAGE_PATTERNS),
            ('phishing', 'critical', self.PHISHING_PATTERNS),
            ('eval_injection', 'high', self.EVAL_INJECTION_PATTERNS),
            ('preg_replace', 'medium', self.PREG_REPLACE_PATTERNS),
            ('shell_shock', 'critical', self.SHELL_SHOCK_PATTERNS),
            ('format_string', 'medium', self.FORMAT_STRING_PATTERNS),
            ('mx_injection', 'high', self.MX_INJECTION_PATTERNS),
            ('ldap_injection', 'high', self.LDAP_INJECTION_PATTERNS),
            ('xpath_injection', 'high', self.XPATH_INJECTION_PATTERNS),
            ('rfd', 'medium', self.RFD_PATTERNS),
        ]

        for category, severity, patterns in groups:
            for pattern_name, regex in patterns:
                self._compiled_patterns.append((category, pattern_name, regex, severity))

    def scan(self, url: str, response_text: str) -> List[PIIFinding]:
        """Scan a response body for all known PII/credential patterns."""
        findings: List[PIIFinding] = []
        seen_patterns: set = set()

        # Limit scanning to first 500KB of response text (prevent DoS on huge responses)
        scan_text = response_text[:500_000]

        for category, pattern_name, regex, severity in self._compiled_patterns:
            if pattern_name in seen_patterns:
                continue
            try:
                matches = regex.findall(scan_text)
                if not matches:
                    continue
            except re.error:
                continue

            found_count = len(matches) if isinstance(matches[0], str) else 1
            seen_patterns.add(pattern_name)

            # Determine value masking based on category
            if isinstance(matches[0], tuple):
                values = [m[0] for m in matches[:5]]  # first 5 match groups
            elif isinstance(matches[0], str):
                values = matches[:5]
            else:
                values = [str(m) for m in matches[:5]]

            for value in values:
                masked = self._mask_value(value, category)
                if not masked:
                    continue

                finding = PIIFinding(
                    finding_type=category,
                    value=masked[:120],
                    raw_value=value[:200] if len(value) <= 200 else '',  # optional raw storage
                    pattern_name=pattern_name,
                    confidence=self._compute_confidence(category, severity),
                    context=f'url={url} count={found_count}',
                    category=severity,
                )
                findings.append(finding)

        logger.info('PII grep found %d findings in %s (%d patterns matched)', len(findings), url, len(seen_patterns))
        return findings

    def scan_response(self, url: str, headers: Dict[str, str], body: str, status_code: int = 200) -> List[PIIFinding]:
        """Scan a full HTTP response (headers + body) for PII/credentials."""
        combined = f'{url}\n' + '\n'.join(f'{k}: {v}' for k, v in headers.items()) + '\n\n' + body
        return self.scan(url, combined)

    @staticmethod
    def _mask_value(value: str, category: str) -> Optional[str]:
        """Mask sensitive values for safe logging/reporting."""
        if len(value) < 3:
            return None
        if 'key' in category or 'secret' in category:
            head = value[:4]
            tail = value[-2:] if len(value) > 6 else ''
            return f'{head}{"*" * max(1, len(value) - 6)}{tail}'
        elif 'cred_url' in category:
            parts = value.split('@')
            user_part = parts[0][:4] + '***' if len(parts[0]) > 4 else '***'
            host_part = parts[-1][:6] + '***' if len(parts[-1]) > 6 else '***'
            return f'{user_part}@{host_part}'
        elif 'credit_card' in category:
            digits = re.sub(r'\D', '', value)
            return f'****-****-****-{digits[-4:]}' if len(digits) >= 13 else '****-****-****-XXXX'
        elif 'ssn' in category:
            digits = re.sub(r'\D', '', value)
            return f'***-**-{digits[-4:]}' if len(digits) == 9 else '***-**-XXXX'
        elif 'contact' in category:
            local, domain = value.split('@') if '@' in value else ('***', '***')
            masked_local = local[:2] + '***' if len(local) > 2 else '***'
            return f'{masked_local}@{domain}'
        return value[:60]

    @staticmethod
    def _compute_confidence(category: str, severity: str) -> float:
        """Compute confidence score for a finding."""
        base = {'critical': 0.95, 'high': 0.85, 'medium': 0.7, 'low': 0.5, 'info': 0.3}.get(severity, 0.5)
        bonus = {
            'credit_card': 0.1,   # card numbers are highly specific patterns
            'ssn': 0.1,           # SSN format is very specific
            'secret_or_key': 0.05,
            'eval_injection': 0.1,
        }
        return min(1.0, base + bonus.get(category, 0))

    def get_pattern_catalog(self) -> List[Dict[str, str]]:
        """Return the catalog of all grep patterns for documentation/audit."""
        return [
            {'category': cat, 'pattern': name, 'severity': sev}
            for cat, name, _, sev in self._compiled_patterns
        ]

    def get_summary(self, findings: List[PIIFinding]) -> Dict[str, Any]:
        """Generate a summary of PII findings by category."""
        counts: Dict[str, int] = {}
        severity_counts: Dict[str, int] = {}
        for f in findings:
            counts[f.finding_type] = counts.get(f.finding_type, 0) + 1
            severity_counts[f.category] = severity_counts.get(f.category, 0) + 1
        return {
            'total_findings': len(findings),
            'by_type': counts,
            'by_severity': severity_counts,
            'high_confidence': sum(1 for f in findings if f.confidence >= 0.8),
            'categories': list(set(f.category for f in findings)),
        }


# ====================================================================
# Convenience function
# ====================================================================

def detect_pii_in_text(url: str, text: str) -> List[PIIFinding]:
    """Quick PII detection (w3af-style grep)."""
    engine = PIIGrepEngine()
    return engine.scan(url, text)
