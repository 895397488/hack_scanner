#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HackerOne 计划范围抓取（scope）— GraphQL 结构化范围 + 离线降级
=====================================================================

用途:
    抓取/规范化 HackerOne 计划的 in-scope / out-of-scope 资产列表，
    供扫描编排做"目标是否允许测试"的硬校验（out_of_scope 优先、
    空范围放行），并可渲染进最终报告（`## 计划范围（HackerOne）` 段）。

参照:
    vulnclaw/agent/hackerone_scope.py 的 GraphQL query 结构
    （team(handle: $handle) { structured_scopes(first/after) { nodes } }）、
    分页游标策略、以及 eligible_for_submission 分流 in/out 的规范化路径。
    本模块只做 API 适配：dataclass 取代 pydantic，不 import vulnclaw，
    纯标准库（urllib.request），零新增依赖。

离线降级:
    - fetch_h1_scope 任何网络失败 → 抛 H1ScopeError（中文 reason），
      由调用方决定降级策略（本模块不静默吞异常）；
    - 降级路径：save_scope_file / load_scope_file 读写本地 scope.json
      （handle/in_scope/out_of_scope/asset_types/fetched_at 结构），
      文件缺失或损坏 → H1ScopeError；
    - 模块自身默认不发任何请求：opener / url 均可注入，
      测试用 fake opener monkeypatch，零真实网络。

脏输入纪律:
    normalize_scope / host_in_scope / render_scope_snapshot 对脏/缺字段
    一律返回安全默认值（空列表 / 放行或拒绝 + 中文理由 / 空串），不抛异常。
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
H1_GRAPHQL_URL = "https://hackerone.com/graphql"
# 带 API key 时走认证端点（仍可被 url 参数覆盖）
API_GRAPHQL_URL = "https://api.hackerone.com/graphql"

_PAGE_SIZE = 100
_MAX_PAGES = 20
_DEFAULT_TIMEOUT_S = 15.0

_GRAPHQL_QUERY = """
query HackScannerProgramScope($handle: String!, $first: Int!, $after: String) {
  team(handle: $handle) {
    id
    handle
    name
    structured_scopes(first: $first, after: $after, archived: false) {
      total_count
      pageInfo {
        hasNextPage
        endCursor
      }
      nodes {
        id
        asset_type
        asset_identifier
        instruction
        eligible_for_bounty
        eligible_for_submission
        max_severity
      }
    }
  }
}
""".strip()


# ---------------------------------------------------------------------------
# 数据结构
# ---------------------------------------------------------------------------
@dataclass
class ProgramScope:
    """HackerOne 计划范围（规范化后，字符串级，便于序列化与匹配）。"""

    handle: str = ""
    in_scope: list[str] = field(default_factory=list)    # 资产字符串（域名/URL/Wildcard/其他）
    out_of_scope: list[str] = field(default_factory=list)
    asset_types: list[str] = field(default_factory=list)  # 如 ["URL", "Wildcard", "CIDR", "Other"]
    fetched_at: str = ""  # ISO8601（离线文件加载时为文件 mtime 或空）
    source: str = "hackerone_api"  # "hackerone_api" | "local_file"


class H1ScopeError(Exception):
    """HackerOne 范围抓取/读写失败（reason 为中文描述）。"""


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------
def _as_bool(value: Any, *, default: bool = False) -> bool:
    """宽松布尔解析（照搬 vulnclaw _as_bool 思路）。"""
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"true", "1", "yes"}:
        return True
    if text in {"false", "0", "no"}:
        return False
    return default


def _now_iso8601() -> str:
    try:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")
    except Exception:  # noqa: BLE001 — 时钟异常不应阻断
        return ""


def _clean_handle(seed: Any) -> str:
    """清洗 handle：容忍 URL / 引号 / 斜杠包裹；提取不到则返回空串。"""
    if seed is None:
        return ""
    s = str(seed).strip().strip("'\"").strip()
    if not s:
        return ""
    if "://" in s or "hackerone.com" in s.lower():
        try:
            u = s if "://" in s else "https://" + s
            path = (urlparse(u).path or "").strip("/")
            seg = path.split("/")[0] if path else ""
            if seg:
                s = seg
        except Exception:  # noqa: BLE001
            pass
    return s.strip("/").strip()


def _iter_scope_nodes(raw: Any) -> list[dict]:
    """从多种响应结构中抽取 scope node 列表（脏结构安全，绝不抛异常）。

    支持路径（参照 vulnclaw data.team.structured_scopes.nodes，
    并兼容 securityTeams / program / 平铺 scope 列表）：
      data.team.structured_scopes.nodes
      data.securityTeams[].structured_scopes.nodes
      data.program.structured_scopes.nodes
      data.structured_scopes.nodes / data.scope[] / data.scopes[]
      顶层平铺: in_scope / out_of_scope（本地文件形状）
    """
    nodes: list[dict] = []
    if not isinstance(raw, dict):
        return nodes

    data = raw.get("data")
    if not isinstance(data, dict):
        data = raw  # 允许直接传 data 层

    containers: list[dict] = []
    for key in ("team", "program"):
        v = data.get(key)
        if isinstance(v, dict):
            containers.append(v)
    teams = data.get("securityTeams")
    if isinstance(teams, list):
        containers.extend(t for t in teams if isinstance(t, dict))
    elif isinstance(teams, dict):
        containers.append(teams)

    for c in containers:
        ss = c.get("structured_scopes")
        if isinstance(ss, dict) and isinstance(ss.get("nodes"), list):
            nodes.extend(n for n in ss["nodes"] if isinstance(n, dict))
        elif isinstance(c.get("nodes"), list):
            nodes.extend(n for n in c["nodes"] if isinstance(n, dict))

    for key in ("structured_scopes", "scope", "scopes"):
        v = data.get(key)
        if isinstance(v, dict) and isinstance(v.get("nodes"), list):
            nodes.extend(n for n in v["nodes"] if isinstance(n, dict))
        elif isinstance(v, list):
            nodes.extend(n for n in v if isinstance(n, dict))
    return nodes


def _node_identifier(node: dict) -> str:
    return str(
        node.get("asset_identifier") or node.get("identifier") or ""
    ).strip()


def _node_asset_type(node: dict) -> str:
    return str(node.get("asset_type") or node.get("display_name") or "").strip().upper()


def _node_handle(raw: Any, data: Any) -> str:
    candidates: list[Any] = []
    if isinstance(data, dict):
        for key in ("team", "program", "securityTeams"):
            v = data.get(key)
            if isinstance(v, dict):
                candidates.append(v.get("handle"))
        teams = data.get("securityTeams")
        if isinstance(teams, list):
            for t in teams:
                if isinstance(t, dict):
                    candidates.append(t.get("handle"))
    if isinstance(raw, dict):
        candidates.append(raw.get("handle"))
    for c in candidates:
        if c is not None and str(c).strip():
            return str(c).strip()
    return ""


def _str_list(value: Any) -> list[str]:
    """把任意值宽松转成去空白的字符串列表。"""
    if value is None:
        return []
    if isinstance(value, (str, int, float, bool)):
        s = str(value).strip()
        return [s] if s else []
    if isinstance(value, (list, tuple, set, frozenset)):
        out: list[str] = []
        for item in value:
            s = str(item).strip()
            if s:
                out.append(s)
        return out
    return []


# ---------------------------------------------------------------------------
# 公开 API：规范化
# ---------------------------------------------------------------------------
def normalize_scope(raw: dict) -> ProgramScope:
    """从 GraphQL 响应结构（或本地文件平铺结构）规范化为 ProgramScope。

    - in/out 分流沿用 vulnclaw：eligible_for_submission 为真 → in_scope，
      否则 → out_of_scope（缺字段按 False，保守入 out）。
    - asset_types 去重保序（大写）。
    - raw 脏/缺字段 → 空列表，不抛异常。
    """
    try:
        handle = _node_handle(raw, (raw or {}).get("data") if isinstance(raw, dict) else None)
        nodes = _iter_scope_nodes(raw)

        in_scope: list[str] = []
        out_of_scope: list[str] = []
        asset_types: list[str] = []
        seen_types: set[str] = set()

        # 平铺结构（本地文件形状）优先兜底
        if isinstance(raw, dict):
            in_scope.extend(_str_list(raw.get("in_scope")))
            out_of_scope.extend(_str_list(raw.get("out_of_scope")))

        seen_in: set[str] = set()
        seen_out: set[str] = set()

        for node in nodes:
            identifier = _node_identifier(node)
            if not identifier:
                continue
            atype = _node_asset_type(node)
            if atype and atype not in seen_types:
                seen_types.add(atype)
                asset_types.append(atype)
            if _as_bool(node.get("eligible_for_submission"), default=False):
                if identifier not in seen_in:
                    seen_in.add(identifier)
                    in_scope.append(identifier)
            else:
                if identifier not in seen_out:
                    seen_out.add(identifier)
                    out_of_scope.append(identifier)

        for extra in _str_list(raw.get("asset_types") if isinstance(raw, dict) else None):
            up = str(extra).strip().upper()
            if up and up not in seen_types:
                seen_types.add(up)
                asset_types.append(up)

        return ProgramScope(
            handle=handle,
            in_scope=in_scope,
            out_of_scope=out_of_scope,
            asset_types=asset_types,
            fetched_at=_now_iso8601(),
            source="hackerone_api",
        )
    except Exception:  # noqa: BLE001 — 契约：脏输入不抛异常
        return ProgramScope(
            handle="",
            in_scope=[],
            out_of_scope=[],
            asset_types=[],
            fetched_at="",
            source="hackerone_api",
        )


# ---------------------------------------------------------------------------
# 公开 API：在线抓取（可注入 url / opener，默认不发请求）
# ---------------------------------------------------------------------------
def fetch_h1_scope(
    handle: str,
    api_key: str | None = None,
    timeout: float = 15.0,
    url: str | None = None,
    opener: object | None = None,
) -> ProgramScope:
    """抓取 HackerOne 计划范围（GraphQL POST，vulnclaw 同款 query 结构 + 分页）。

    - url 可注入（默认 H1_GRAPHQL_URL；带 api_key 时默认 api.hackerone.com）
    - opener 可注入（签名同 urllib.request.urlopen：open(req, timeout=..)
      返回可读上下文管理器；测试传 fake 即可零真实网络）
    - 任何网络失败 → 抛 H1ScopeError（带中文 reason），调用方决定降级
    """
    clean_handle = _clean_handle(handle)
    if not clean_handle:
        raise H1ScopeError("程序 handle 为空，无法查询 HackerOne")

    target_url = url or (API_GRAPHQL_URL if api_key else H1_GRAPHQL_URL)
    try:
        timeout = float(timeout)
    except (TypeError, ValueError):
        timeout = _DEFAULT_TIMEOUT_S

    open_url = opener if opener is not None else urllib.request.urlopen

    all_nodes: list[dict] = []
    after: str | None = None
    complete = False
    last_data: dict | None = None

    for _ in range(_MAX_PAGES):
        payload = {
            "operationName": "HackScannerProgramScope",
            "variables": {
                "handle": clean_handle,
                "first": _PAGE_SIZE,
                "after": after,
            },
            "query": _GRAPHQL_QUERY,
        }
        body = json.dumps(payload).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "hack_scanner/h1_scope",
        }
        if api_key:
            headers["Authorization"] = str(api_key)

        request = urllib.request.Request(
            target_url, data=body, method="POST", headers=headers
        )

        try:
            with open_url(request, timeout=timeout) as response:  # type: ignore[operator]
                raw_text = response.read().decode("utf-8", errors="replace")
                status = getattr(response, "status", None)
                if status is None:
                    try:
                        status = response.getcode()  # type: ignore[union-attr]
                    except Exception:  # noqa: BLE001
                        status = 200
        except urllib.error.HTTPError as exc:
            try:
                err_body = exc.read().decode("utf-8", errors="replace")[:300]
            except Exception:  # noqa: BLE001
                err_body = ""
            raise H1ScopeError(
                f"HackerOne GraphQL 返回 HTTP {exc.code}：{err_body or '无响应体'}"
            ) from exc
        except urllib.error.URLError as exc:
            raise H1ScopeError(f"HackerOne GraphQL 网络错误：{exc.reason}") from exc
        except Exception as exc:  # noqa: BLE001 — socket 超时等统一降级
            raise H1ScopeError(f"HackerOne GraphQL 请求失败：{exc}") from exc

        try:
            status_i = int(status)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            status_i = 200
        if status_i >= 400:
            raise H1ScopeError(
                f"HackerOne GraphQL 返回 HTTP {status}：{raw_text[:300]}"
            )

        try:
            data = json.loads(raw_text)
        except json.JSONDecodeError as exc:
            raise H1ScopeError("HackerOne GraphQL 返回非 JSON 响应") from exc
        if not isinstance(data, dict):
            raise H1ScopeError("HackerOne GraphQL 返回结构异常（非对象）")

        errors = data.get("errors")
        if errors:
            msgs: list[str] = []
            for item in errors:
                if isinstance(item, dict):
                    msgs.append(str(item.get("message") or item))
                else:
                    msgs.append(str(item))
            raise H1ScopeError(
                "HackerOne GraphQL 错误：" + "；".join(msgs[:5])
            )

        d = data.get("data") if isinstance(data.get("data"), dict) else None
        if d is None:
            d = {}
        team = d.get("team")
        if not isinstance(team, dict):
            raise H1ScopeError(
                f"HackerOne 未找到程序或其不可公开访问：{clean_handle}"
            )
        last_data = d

        scopes = team.get("structured_scopes")
        batch = scopes.get("nodes") if isinstance(scopes, dict) else None
        if batch is None:
            batch = []
        if not isinstance(batch, list):
            raise H1ScopeError("HackerOne structured_scopes.nodes 结构异常")
        all_nodes.extend(n for n in batch if isinstance(n, dict))

        page_info = scopes.get("pageInfo") if isinstance(scopes, dict) else None
        page_info = page_info if isinstance(page_info, dict) else {}
        if not page_info.get("hasNextPage"):
            complete = True
            break
        after = page_info.get("endCursor")
        if not after:
            raise H1ScopeError(
                f"HackerOne 分页游标缺失（已读 {len(all_nodes)} 条），"
                "拒绝返回不完整范围"
            )

    if not complete:
        raise H1ScopeError(
            f"程序 {clean_handle} 的范围超过 {_MAX_PAGES} 页，"
            "拒绝返回不完整范围"
        )

    # 归一为 normalize_scope 可识别的响应结构（合并全部分页节点）
    merged = {
        "data": {
            "team": {
                "handle": clean_handle,
                "structured_scopes": {"nodes": all_nodes},
            }
        }
    }
    scope = normalize_scope(merged)
    # 保留服务端返回的 handle（若有）
    if isinstance(last_data, dict):
        for key in ("team", "program"):
            v = last_data.get(key)
            if isinstance(v, dict) and str(v.get("handle") or "").strip():
                scope.handle = str(v["handle"]).strip()
                break
    return scope


# ---------------------------------------------------------------------------
# 公开 API：离线降级（scope.json 读写）
# ---------------------------------------------------------------------------
def save_scope_file(path: str, scope: ProgramScope) -> str:
    """把 ProgramScope 写成本地 scope.json，返回写入路径。

    结构: {"handle", "in_scope", "out_of_scope", "asset_types", "fetched_at", "source"}
    写入失败 → H1ScopeError。
    """
    try:
        p = str(path).strip()
        if not p:
            raise H1ScopeError("scope 文件路径为空")
        parent = os.path.dirname(os.path.abspath(p))
        if parent:
            os.makedirs(parent, exist_ok=True)
        payload = {
            "handle": str(scope.handle or "").strip(),
            "in_scope": [str(x).strip() for x in (scope.in_scope or []) if str(x).strip()],
            "out_of_scope": [str(x).strip() for x in (scope.out_of_scope or []) if str(x).strip()],
            "asset_types": [str(x).strip() for x in (scope.asset_types or []) if str(x).strip()],
            "fetched_at": str(scope.fetched_at or ""),
            "source": str(scope.source or "local_file"),
        }
        with open(p, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return p
    except H1ScopeError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise H1ScopeError(f"写入 scope 文件失败：{exc}") from exc


def load_scope_file(path: str) -> ProgramScope:
    """读取本地 scope.json 为 ProgramScope（source="local_file"）。

    fetched_at 取文件内值，缺失时用文件 mtime（ISO8601）。
    文件缺失/损坏 → H1ScopeError。
    """
    try:
        p = str(path).strip()
        if not p or not os.path.isfile(p):
            raise H1ScopeError(f"scope 文件不存在：{p or '(空路径)'}")
        with open(p, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, dict):
            raise H1ScopeError("scope 文件结构损坏（应为 JSON 对象）")
        try:
            mtime_iso = datetime.fromtimestamp(
                os.path.getmtime(p), tz=timezone.utc
            ).isoformat(timespec="seconds")
        except (OSError, ValueError):
            mtime_iso = ""
        fetched = str(raw.get("fetched_at") or "").strip()
        return ProgramScope(
            handle=str(raw.get("handle") or "").strip(),
            in_scope=_str_list(raw.get("in_scope")),
            out_of_scope=_str_list(raw.get("out_of_scope")),
            asset_types=_str_list(raw.get("asset_types")),
            fetched_at=fetched or mtime_iso,
            source="local_file",
        )
    except H1ScopeError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise H1ScopeError(f"读取 scope 文件失败：{exc}") from exc


# ---------------------------------------------------------------------------
# 公开 API：host 范围判定
# ---------------------------------------------------------------------------
def _normalize_host(value: Any) -> str:
    """把 host / URL / 带端口 / 带 userinfo 的输入归一成小写 host 串。"""
    if value is None:
        return ""
    s = str(value).strip().lower()
    if not s:
        return ""
    if "://" in s:
        s = s.split("://", 1)[1]
    if s.startswith("//"):
        s = s[2:]
    host = s.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    if "@" in host:
        host = host.split("@", 1)[1]
    if host.startswith("["):
        host = host[1:].split("]", 1)[0]
    elif ":" in host:
        h, sep, rest = host.rpartition(":")
        if sep and rest.isdigit():
            host = h
    return host.strip(".")


def _asset_domain(asset: Any) -> str | None:
    """从资产字符串提取可匹配域名；非域名资产（移动 App 名等）返回 None。

    - "*.example.com" → 记为 example.com（通配符同时覆盖 apex 本身）
    - "https://a.example.com/x" → a.example.com
    - "example.com/path" → example.com
    """
    s = str(asset or "").strip().lower()
    if not s or " " in s:
        return None
    if s.startswith("*."):
        s = s[2:]
    if "://" in s:
        s = s.split("://", 1)[1]
    if s.startswith("//"):
        s = s[2:]
    dom = s.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
    if "@" in dom:
        dom = dom.split("@", 1)[1]
    if dom.startswith("["):
        dom = dom[1:].split("]", 1)[0]
    elif ":" in dom:
        h, sep, rest = dom.rpartition(":")
        if sep and rest.isdigit():
            dom = h
    dom = dom.strip(".")
    if not dom or " " in dom or any(c in dom for c in "\\*"):
        return None
    return dom


def host_in_scope(host: str, scope: ProgramScope) -> tuple[bool, str]:
    """判定 host 是否在计划范围内。

    规则（out_of_scope 优先）:
      - scope 全空 → (True, "未提供范围约束（放行）")
      - 命中 out_of_scope（精确/子域/URL 的 host 部分）→ 拒绝
      - 命中 in_scope：精确 / 子域（example.com 覆盖 a.example.com；
        *.example.com 覆盖 apex 与全部子域）/ 前缀 URL（取 host 比较）
      - 均未命中 → 拒绝（默认保守）
    永不抛异常。
    """
    try:
        if scope is None:
            return (True, "未提供范围约束（放行）")
        in_list = _str_list(scope.in_scope)
        out_list = _str_list(scope.out_of_scope)
        if not in_list and not out_list:
            return (True, "未提供范围约束（放行）")

        h = _normalize_host(host)
        if not h:
            return (False, "目标 host 为空或无法解析（拒绝）")

        def _matches(dom: str) -> bool:
            return h == dom or h.endswith("." + dom)

        for asset in out_list:
            dom = _asset_domain(asset)
            if dom and _matches(dom):
                return (False, f"命中范围外条目：{asset.strip()}（out_of_scope 优先）")

        for asset in in_list:
            dom = _asset_domain(asset)
            if dom and _matches(dom):
                return (True, f"命中范围内条目：{asset.strip()}（精确/子域/URL 覆盖）")

        return (False, "未匹配任何范围内条目（默认拒绝）")
    except Exception as exc:  # noqa: BLE001 — 脏输入不抛异常
        return (False, f"范围匹配内部错误（拒绝）：{exc}")


# ---------------------------------------------------------------------------
# 公开 API：报告段渲染
# ---------------------------------------------------------------------------
def render_scope_snapshot(scope: ProgramScope) -> str:
    """渲染 "## 计划范围（HackerOne）" 报告段；空 scope → 空串。永不抛异常。"""
    try:
        if scope is None:
            return ""
        in_list = _str_list(scope.in_scope)
        out_list = _str_list(scope.out_of_scope)
        if not in_list and not out_list:
            return ""

        lines: list[str] = [
            "## 计划范围（HackerOne）",
            "",
            f"- handle: `{str(scope.handle or '未知').strip()}`",
            f"- 来源: {str(scope.source or '未知').strip()}",
        ]
        if str(scope.fetched_at or "").strip():
            lines.append(f"- 抓取时间: {str(scope.fetched_at).strip()}")
        if scope.asset_types:
            types = [str(t).strip() for t in scope.asset_types if str(t).strip()]
            if types:
                lines.append(f"- 资产类型: {', '.join(types)}")
        lines.extend(["", f"### 范围内（in scope，共 {len(in_list)} 项）"])
        lines.extend(f"- {x}" for x in in_list)
        lines.extend(["", f"### 范围外（out of scope，禁止测试，共 {len(out_list)} 项）"])
        if out_list:
            lines.extend(f"- {x}" for x in out_list)
        else:
            lines.append("- （未列出）")
        return "\n".join(lines)
    except Exception:  # noqa: BLE001
        return ""
