#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按目标反循环 + 阶段检测 — 同一 host 连续失败自动暂停
=====================================================================

背景（整合 vulnclaw 优势 ③，参照 vulnclaw/agent/anti_loop.py）:
    orchestrator 内置的 loop_guard 只抑制"同一 (tool,args) 第 3 次精确重复"，
    不看"同一目标是否连续失败"——模型对单个被 WAF 拦/超时的 host 反复换
    payload 重试时，每次 args 都不同，loop_guard 全数放行，迭代被烧光、
    目标被打穿、有效进展为零。

    这里把 vulnclaw 的 anti-loop 机制落到入口层（orchestrator 零改动）:
    - LoopTracker.observe(): 按 hostname 记失败，≥3 次自动拉黑（blocked_targets）；
      成功一次计数【递减 1】（不是清零，容忍偶发抖动，vulnclaw 同款）
    - 被拉黑 host 的 http_probe / exploit 不再发真实请求，直接回灌黑名单文案
      让 LLM 换目标/换路径/换策略
    - detect_phase_from_output / is_meaningful_step / detect_attack_path /
      is_completion_signal：信号词分类（供 ② ReflexionEngine 失败归因、
      ① 蒸馏打 tag、⑤ KB 检索词）

设计纪律（与 M6/M7/M11/M12 入口层包装一致）:
    - 只包装 tool.execute（同 install_result_recorder 模式），orchestrator 零改动
    - 纯标准库、异常静默降级；recorder 保持最内层，记到的是拦截后的真实返回
    - hostname 提取用 vulnclaw 原 URL 正则（args JSON 字符串与结果文本都适用）
"""

import re
from typing import Callable, Dict, List, Optional, Set

# ---------------------------------------------------------------------------
# 失败特征表（vulnclaw FAILED_ACCESS_PATTERNS 原表，中英混合）
# ---------------------------------------------------------------------------
FAILED_ACCESS_PATTERNS = [
    "SSLError",
    "ReadTimeout",
    "连接超时",
    "连接失败",
    "502 Bad Gateway",
    "502",
    "503",
    "无法访问",
    "访问失败",
    "Connection refused",
    "ConnectionError",
    "TimeoutError",
    "Name or service not known",
    "No route to host",
    "SSL: CERTIFICATE_VERIFY_FAILED",
    "超时",
    "connection timed out",
    "connection failed",
    "cannot access",
    "access failed",
    "unreachable",
    "connection reset",
    "timed out",
]

# hostname 提取（vulnclaw 原正则：URL 后取到空白/引号/括号为止）
_URL_RE = re.compile(r'https?://([^\s/<>"\')\]]+)')

# 阶段名常量（替代 vulnclaw 的 PentestPhase 枚举，避免 import 耦合）
PHASE_VULN_DISCOVERY = "vuln_discovery"
PHASE_EXPLOITATION = "exploitation"
PHASE_POST_EXPLOITATION = "post_exploitation"
PHASE_REPORTING = "reporting"


def extract_host(text: Optional[str]) -> Optional[str]:
    """从文本（args JSON / 工具结果）里提取第一个 URL 的 hostname。

    BUG_REPORT [9]：_URL_RE 捕获类不排除 ?/#，`http://host?token=x` 会被记成
    `host?token=x`——同一目标按变体分裂计数，fail_threshold 永不触发、拉黑失效。
    先剥 ?query/#frag 再取 host（query 里的 @/: 也一并隔离掉）。
    """
    if not text:
        return None
    m = _URL_RE.search(text)
    if not m:
        return None
    host = (m.group(1).lower()
            .split("?")[0].split("#")[0]
            .split("@")[-1].split(":")[0].split("/")[0])
    return host or None


def detect_phase_from_output(output: Optional[str]) -> Optional[str]:
    """从 LLM 输出/工具结果中检测阶段切换信号（vulnclaw 原信号表）。"""
    if not output:
        return None
    text = output.lower()
    transitions = [
        (PHASE_VULN_DISCOVERY, [
            "进入漏洞发现", "开始漏洞扫描", "漏洞检测", "切换到漏洞发现",
            "phase: vuln_discovery", "vulnerability discovery",
            "start vulnerability scan", "scanning for vulnerabilities",
            "vuln scan", "vulnerability scanning",
        ]),
        (PHASE_EXPLOITATION, [
            "进入漏洞利用", "开始利用", "尝试利用", "切换到漏洞利用",
            "phase: exploitation", "starting exploitation",
            "begin exploitation", "attempting exploit",
            "try to exploit", "exploitation phase",
        ]),
        (PHASE_POST_EXPLOITATION, [
            "进入后渗透", "内网渗透", "横向移动", "切换到后渗透",
            "phase: post_exploitation", "post-exploitation",
            "lateral movement", "pivot", "privilege escalation",
        ]),
        (PHASE_REPORTING, [
            "生成报告", "整理结果", "渗透测试完成", "切换到报告",
            "phase: reporting", "generate report", "write report",
            "compile results", "pentest complete", "reporting phase",
        ]),
    ]
    for phase, signals in transitions:
        if any(s in text for s in signals):
            return phase
    return None


def is_completion_signal(output: Optional[str]) -> bool:
    """检查 LLM 输出是否带有任务完成信号（vulnclaw 原表）。"""
    if not output:
        return False
    completion_signals = [
        "[DONE]",
        "[COMPLETE]",
        "渗透测试已完成",
        "测试结束",
        "任务完成",
        "pentest completed",
        "testing complete",
        "task completed",
        "all tasks completed",
    ]
    return any(s in output for s in completion_signals)


def is_meaningful_step(step: Optional[str]) -> bool:
    """区分"有效进展"与"纯失败重试"（vulnclaw 原词表）。

    含进展关键词 → True；否则含纯失败关键词 → False；其余默认 True。
    """
    if not step:
        return False
    failure_only_keywords = [
        "SSLError", "ReadTimeout", "连接超时", "连接失败",
        "502 Bad Gateway", "无法访问", "访问失败", "Connection refused",
        "ConnectionError", "TimeoutError", "请求失败",
    ]
    progress_keywords = [
        "发现", "确认", "漏洞", "端口", "路径", "flag", "成功",
        "CVE", "泄露", "绕过", "验证通过", "已确认",
    ]
    if any(k in step for k in progress_keywords):
        return True
    if any(k in step for k in failure_only_keywords):
        return False
    return True


def detect_attack_path(output: Optional[str]) -> Optional[str]:
    """从输出中识别当前攻击路径/技术（vulnclaw 原 12 类）。

    供 ① 蒸馏打 tag + ⑤ KB 检索词。
    """
    if not output:
        return None
    text = output.lower()
    path_patterns = [
        ("regex_bypass", [
            "preg_replace", "preg_match", "正则绕过", "大小写绕过",
            "数组绕过", "双写绕过",
        ]),
        ("file_inclusion", [
            "php://filter", "文件包含", "include", "require",
            "伪协议", "php://input", "data://",
        ]),
        ("rce", ["eval(", "system(", "exec(", "passthru(", "shell_exec(", "命令执行", "rce"]),
        ("sqli", ["sql注入", "union select", "information_schema", "sqli", "sqlmap"]),
        ("ssti", ["ssti", "template", "jinja2", "twig", "{{", "模板注入"]),
        ("deserialization", ["反序列化", "unserialize", "serialize", "pop链", "wakeup"]),
        ("file_upload", ["文件上传", "upload", "webshell", "一句话木马"]),
        ("ssrf", ["ssrf", "gopher://", "dict://", "内网访问"]),
        ("xxe", ["xxe", "xml外部实体", "entity"]),
        ("info_leak", ["源码泄露", ".git", ".svn", "备份文件", "目录遍历", "robots.txt"]),
        ("brute_force", ["爆破", "弱口令", "字典", "brute"]),
    ]
    for path_name, keywords in path_patterns:
        if any(k in text for k in keywords):
            return path_name
    return None


# ---------------------------------------------------------------------------
# 按目标失败追踪
# ---------------------------------------------------------------------------
class LoopTracker:
    """按 hostname 记失败/拉黑（vulnclaw track_failed_target 的实例化形态）。

    - observe(text): 消费一条工具结果文本；命中失败特征 → 计数 +1，
      ≥ fail_threshold 拉黑；未命中 → 计数递减 1（容忍偶发抖动）。
    - is_blocked(host) / blocked_message(host): 拉黑判定与回灌文案。
    - on_event 回调: (event, host, text) -> None，供 ② ReflexionEngine
      共享同一失败事件源（failure / blocked / recovered）。
    """

    def __init__(self, fail_threshold: int = 3,
                 on_event: Optional[Callable[[str, str, str], None]] = None):
        self.fail_threshold = max(2, int(fail_threshold))
        self.failed_targets: Dict[str, int] = {}
        self.blocked_targets: Set[str] = set()
        self.events: List[dict] = []
        self.on_event = on_event

    def _emit(self, event: str, host: str, text: str = "") -> None:
        self.events.append({"event": event, "host": host})
        if self.on_event:
            try:
                self.on_event(event, host, text or "")
            except Exception:
                pass  # 回调异常静默，不阻断核心循环

    def observe(self, response_text: Optional[str]) -> Optional[str]:
        """消费一条结果文本。刚被拉黑的 host 返回其 hostname，否则 None。"""
        host = extract_host(response_text)
        if not host:
            return None
        if any(p in (response_text or "") for p in FAILED_ACCESS_PATTERNS):
            self.failed_targets[host] = self.failed_targets.get(host, 0) + 1
            self._emit("failure", host, response_text or "")
            if self.failed_targets[host] >= self.fail_threshold:
                self.blocked_targets.add(host)
                self._emit("blocked", host, response_text or "")
                return host
        else:
            if 0 < self.failed_targets.get(host, 0):
                self.failed_targets[host] -= 1
                self._emit("recovered", host, response_text or "")
        return None

    def is_blocked(self, host: Optional[str]) -> bool:
        return bool(host) and host.lower() in self.blocked_targets

    def blocked_message(self, host: str) -> str:
        n = self.failed_targets.get(host, self.fail_threshold)
        return (
            f"[anti-loop] {host} 已连续失败 {n} 次被暂停。"
            "换目标、换路径或换策略（见升级提示）。现在不要重试该 host。"
        )

    def reset(self) -> None:
        self.failed_targets.clear()
        self.blocked_targets.clear()
        self.events.clear()


# ---------------------------------------------------------------------------
# 入口层包装器
# ---------------------------------------------------------------------------
def install_anti_loop_tracker(orch,
                              tracker: Optional[LoopTracker] = None,
                              protected_tools=("http_probe", "exploit")) -> LoopTracker:
    """包装 orch.tools 中网络类工具的 execute（同 install_result_recorder 模式）。

    - 被拉黑 host：不发真实请求，直接返回黑名单文案（res 文本 + err=None，
      让 LLM 读到"暂停"语义而不是报错语义）
    - 其余调用：透传执行，结果文本喂给 tracker.observe()
    - 返回 tracker（调用方可共享给 ReflexionEngine / 摘要打印）
    """
    tracker = tracker or LoopTracker()
    for name, tool in list(orch.tools.items()):
        if name not in protected_tools:
            continue
        orig = tool.execute

        def wrap(args, _orig=orig, _tracker=tracker):
            # 1) 拉黑短路（追踪器自身异常 → 静默放行，不阻断核心循环）
            try:
                host = extract_host(args)
                if host and _tracker.is_blocked(host):
                    return _tracker.blocked_message(host), None
            except Exception:
                pass
            # 2) 透传执行（工具异常照常抛出，orchestrator 有既有 try/except；
            #    与 install_result_recorder 一致）
            res, err = _orig(args)
            # 3) 喂给追踪器（追踪器自身异常 → 静默忽略）
            try:
                text = res if isinstance(res, str) else (str(res) if res is not None else "")
                if err:
                    text = f"{text} [ERROR: {err}]"
                _tracker.observe(text)
            except Exception:
                pass
            return res, err

        tool.execute = wrap
    return tracker


if __name__ == "__main__":
    # 自测：3 连败拉黑 / 成功递减 / 信号词分类
    t = LoopTracker(fail_threshold=3)
    fail = "GET http://bad.example.com/api -> ReadTimeout 连接超时"
    ok = "GET http://bad.example.com/api -> 200 OK 发现 info 泄露"
    assert t.observe(fail) is None
    assert t.observe(fail) is None
    assert t.observe(fail) == "bad.example.com", "第 3 次失败应拉黑"
    assert t.is_blocked("bad.example.com")
    # 成功一次 → 计数递减（不清零，vulnclaw 同款）
    t2 = LoopTracker(fail_threshold=3)
    t2.observe(fail); t2.observe(fail)
    t2.observe(ok)
    assert t2.failed_targets["bad.example.com"] == 1, "成功应递减 1 而非清零"
    # 拉黑文案
    assert "暂停" in t.blocked_message("bad.example.com") and "bad.example.com" in t.blocked_message("bad.example.com")
    # 阶段/攻击路径/完成信号
    assert detect_phase_from_output("进入漏洞利用阶段") == PHASE_EXPLOITATION
    assert detect_phase_from_output("generate report now") == PHASE_REPORTING
    assert detect_attack_path("尝试 union select 注入") == "sqli"
    assert detect_attack_path("unserialize pop链") == "deserialization"
    assert is_completion_signal("渗透测试已完成")
    assert not is_meaningful_step("ReadTimeout 连接超时")
    assert is_meaningful_step("发现 2 个漏洞")
    assert extract_host('{"url": "http://Sub.Example.com:8080/x?a=1"}') == "sub.example.com"
    # 包装器自测（假 orch / 假 tool）
    class _FakeTool:
        def __init__(self):
            self.calls = 0
        def execute(self, args):
            self.calls += 1
            return "ReadTimeout 连接超时 http://bad.example.com", None
    class _FakeOrch:
        def __init__(self):
            self.tools = {"http_probe": _FakeTool()}
    orch = _FakeOrch()
    tr = install_anti_loop_tracker(orch)
    for _ in range(3):
        orch.tools["http_probe"].execute('{"url": "http://bad.example.com/x"}')
    assert orch.tools["http_probe"].calls == 3
    res, err = orch.tools["http_probe"].execute('{"url": "http://bad.example.com/again"}')
    assert err is None and "anti-loop" in res and orch.tools["http_probe"].calls == 3, "拉黑后不得再发请求"
    print("self-test OK")
