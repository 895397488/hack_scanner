#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nuclei Scanner — 通过 Nuclei CLI wrapper 进行模板驱动的漏洞扫描。

Nuclei 是业界最活跃的开源漏洞扫描引擎，社区维护 6000+ 模板，
覆盖 CRLF注入、SSRF、RCE、XSS、信息泄露等所有常见漏洞类型。

集成方式：需要安装 nuclei（go install github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest）。
本模块只负责 CLI 调用和结果解析。

Usage:
    from scanners.nuclei_scanner import nuclei_scan, nuclei_template_search
    result = nuclei_scan("https://example.com", tags="crlf")
"""

import json
import logging
import os
import subprocess
from typing import Dict, List, Optional

logger = logging.getLogger('nuclei_scanner')


def _find_nuclei() -> Optional[str]:
    """查找 nuclei 可执行文件"""
    for name in ["nuclei", "nuclei.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def nuclei_scan(
    target: str,
    tags: List[str] = None,
    templates: List[str] = None,
    max_time: int = 600,
) -> dict:
    """运行 Nuclei 模板扫描（推荐对每个目标使用）。

    Args:
        target: 目标 URL 或网段
        tags: 按标签过滤模板（如 ["crlf", "ssrf", "xss"]），不传则全部扫描
        templates: 指定模板文件列表，优先级高于 tags
        max_time: 最大运行时间秒

    Returns:
        {
            "ok": True,
            "target": "...",
            "findings": [
                {"template": "...", "template_id": "xxx", "name": "...",
                 "severity": "high", "matched_at": "https://...", "result": ...}
            ],
            "stats": {"critical": 0, "high": 5, "medium": 3, "low": 1, "info": 2},
            "total_findings": N,
            "error": ""
        }
    """
    nuclei_path = _find_nuclei()

    if not nuclei_path:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "total_findings": 0,
            "stats": {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0},
            "error": "nuclei 未找到，请安装: go install github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest",
        }

    cmd = [
        nuclei_path,
        "-u", target,
        "-jsonl",       # JSONL 格式输出每行一个 JSON
        "-silent",      # 静默模式（只有结果）
        "-timeout", "30",
        "-bulk-size", "25",
    ]

    if tags:
        cmd.extend(["-tags", ",".join(tags)])
    if templates:
        cmd.extend(["-t", ",".join(templates)])

    logger.info(f"nuclei scan: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=max_time + 30,
        )

        findings = []
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict) and entry.get("template-id"):
                    # Normalize severity to match hack_scanner format
                    sev_map = {"info": "info", "low": "low", "medium": "medium", "high": "high", "critical": "critical"}
                    raw_sev = (entry.get("info", {}).get("severity", "") or "").lower()
                    severity = sev_map.get(raw_sev, "info")

                    findings.append({
                        "template": entry.get("template", ""),
                        "template_id": entry.get("template-id", ""),
                        "name": entry.get("info", {}).get("name", ""),
                        "severity": severity,
                        "matched_at": entry.get("matched-at", entry.get("host", "")),
                        "description": (entry.get("info", {}).get("description", "") or "")[:500],
                        "reference": entry.get("info", {}).get("reference", [])[:3],
                        "result": {
                            "http_request_dump": (entry.get("extracted-results", [{}])[0] if isinstance(entry.get("extracted-results"), list) else {})
                                .get("dump", "")[:500] if entry.get("extracted-results") else "",
                        },
                        "type": entry.get("type", ""),  # http/dns/dnsx/httpx/file/etc.
                    })
            except json.JSONDecodeError:
                continue

        critical = sum(1 for f in findings if f["severity"] == "critical")
        high = sum(1 for f in findings if f["severity"] == "high")
        medium = sum(1 for f in findings if f["severity"] == "medium")
        low = sum(1 for f in findings if f["severity"] == "low")
        info = sum(1 for f in findings if f["severity"] == "info")

        return {
            "ok": True,
            "target": target,
            "findings": findings[:500],
            "stats": {"critical": critical, "high": high, "medium": medium, "low": low, "info": info},
            "total_findings": len(findings),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "total_findings": 0,
            "stats": {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0},
            "error": f"nuclei 超时（最大时间 {max_time}s）",
        }


def nuclei_template_search(
    query: str = "",
    tags: List[str] = None,
    severity: List[str] = None,
) -> dict:
    """搜索 Nuclei 模板库（不需要 target）。

    Args:
        query: 关键词搜索（如 "wordpress" / "ssrf"）
        tags: 按标签过滤
        severity: 按严重度过滤

    Returns:
        {"ok": True, "templates_found": [...], ...}
    """
    nuclei_path = _find_nuclei()
    if not nuclei_path:
        return {"ok": False, "error": "nuclei 未找到"}

    cmd = [nuclei_path, "--list"]
    if query:
        cmd.extend(["-search", query])
    if tags:
        cmd.extend(["-tags", ",".join(tags)])
    if severity:
        cmd.extend(["-s", ",".join(severity)])

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        # Nuclei --list 输出 JSONL
        templates = []
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict):
                    templates.append({
                        "id": entry.get("template-id", ""),
                        "name": entry.get("info", {}).get("name", ""),
                        "severity": (entry.get("info", {}).get("severity", "") or "").lower(),
                        "tags": (entry.get("info", {}).get("tags", []) or [])[:10],
                    })
            except json.JSONDecodeError:
                continue

        return {"ok": True, "templates_found": templates[:500]}

    except Exception as e:
        return {"ok": False, "error": str(e)}


def nuclei_scan_cwd(
    cwd: str = None,
) -> dict:
    """扫描本地目录中的潜在 web 路径（file 类型模板）。"""
    if _find_nuclei():
        cmd = [_find_nuclei(), "-u", ".", "--silent", "-jsonl"]
        # This is a stub for file-based scanning using nuclei templates
        return {"ok": True, "message": "File scan via nuclei requires target URL. Use nuclei_scan(target)."}
    return {"ok": False, "error": "nuclei 未安装"}
