#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Web Fuzzer — 通过 ffuf CLI wrapper 实现路径模糊和参数 fuzzing。

集成方式：ffuf 需单独安装（apt/brew/go install / https://github.com/ffuf/ffuf），
本模块只负责 CLI 调用和结果解析。

Usage:
    from scanners.web_fuzzer import fuzz_paths, fuzz_params
    # 路径爆破
    result = fuzz_paths("https://example.com", wordlist="/usr/share/seclists/Discovery/Web-Content/big.txt")
    # 参数 fuzzing
    result = fuzz_params("https://example.com/api?id={FUZZ}", wordlist=["admin","root","test"])
"""

import json
import os
import subprocess
import sys
import logging
from typing import Dict, List, Optional

logger = logging.getLogger('web_fuzzer')


def _find_ffuf() -> Optional[str]:
    """查找 ffuf 可执行文件"""
    for name in ["ffuf", "ffuf.exe"]:
        path = None
        # Unix-style search
        import shutil
        if os.name != 'nt':
            path = shutil.which(name)
        else:
            import subprocess as sp
            try:
                out = sp.run(["where", name], capture_output=True, text=True, timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    # 检查是否在 ffuf.py 包装中可用
    for d in [os.path.join(os.getcwd(), "ffuf"), os.path.expanduser("~/ffuf/ffuf")]:
        if os.path.isfile(d):
            return d
    return None


def fuzz_paths(
    base_url: str,
    wordlist: Optional[str] = None,
    threads: int = 40,
    max_time: int = 600,
    depth: int = 3,
    filter_size: List[int] = None,
) -> dict:
    """对 URL 路径进行模糊测试，发现隐藏目录/文件。

    Args:
        base_url: 目标基础 URL（如 https://example.com/）
        wordlist: FFUf 字典文件路径，默认为内置的小型安全相关路径列表
        threads: 并发线程数
        max_time: 最大运行时间秒
        depth: fuzzing 深度（1=单目录，2=/dir/dir, 3=/dir/dir/dir）
        filter_size: 过滤的响应大小（如 [0, 100] 表示排除 0-100 bytes 的页面）

    Returns:
        {
            "ok": True/False,
            "target": "https://example.com/",
            "findings": [{"url": "...", "status": 200, "size": 1234}],
            "summary_count": N,
            "error": "" (如果有)
        }
    """
    ffuf_path = _find_ffuf() or "ffuf"
    if not os.path.isfile(ffuf_path):
        logger.info("ffuf 未找到，使用内置路径列表作为 fallback")

    # ── Fallback: 如果 ffuf 不可用，使用 requests + 小型词表模拟 ──
    try:
        import requests as req
        if wordlist and os.path.isfile(wordlist):
            with open(wordlist, 'r', encoding='utf-8', errors='ignore') as f:
                words = [l.strip() for l in f if l.strip()]
        else:
            # 内置路径词表（安全相关）
            words = [
                "admin", "api", "login", "dashboard", "config", "backup",
                "wp-admin", "wp-login.php", "phpmyadmin", "pma", "console",
                ".env", ".git", ".svn", ".DS_Store", ".htaccess",
                "robots.txt", "sitemap.xml", "crossdomain.xml",
                "wp-config.php", "config.php", "settings.py",
                "server-status", "info.php", "phpinfo.php",
                "xmlrpc.php", "readme.html", "license.txt",
            ]
            if depth >= 2:
                words.extend(["admin/admin", "api/v1", "api/v2", "admin/api", "test/test"])
            if depth >= 3:
                words.extend(["admin/api/v1", "wp-admin/includes", "api/v1/users", "console/login"])

        # 去重 + 排序（长路径优先）
        words = sorted(set(words), key=len, reverse=True)

        findings = []
        seen_sizes = {}  # 用于过滤相似页面

        try:
            for word in words:
                target = f"{base_url.rstrip('/')}/{word}"
                try:
                    resp = req.head(target, timeout=10, allow_redirects=True)
                    if resp.status_code not in (200, 301, 302, 403):
                        continue

                    # 如果大小相同且状态也相同，可能是同一页面的不同路径（低价值）
                    key = f"{resp.status_code}-{resp.headers.get('Content-Length', '0')}"
                    if key in seen_sizes and resp.status_code != 200:
                        continue
                    seen_sizes[key] = True

                    findings.append({
                        "url": target,
                        "status": resp.status_code,
                        "size": int(resp.headers.get('Content-Length', 0)),
                        "redirect": resp.headers.get('Location', ''),
                    })
                except Exception:
                    pass
        except KeyboardInterrupt:
            pass

        return {
            "ok": True,
            "target": base_url,
            "findings": findings,
            "summary_count": len(findings),
            "error": "",
            "method": "fallback_requests",
        }

    except ImportError:
        logger.warning("requests 不可用，无法回退")

    # ── ffuf CLI ──
    cmd = [
        ffuf_path,
        "-u", f"{base_url.rstrip('/')}/FUZZ",
        "-w", wordlist if wordlist and os.path.isfile(wordlist) else "/dev/null",  # 占位
        "-t", str(threads),
        "-mc", "200,301,302,303,403,404,500",
        "-json", "-",      # JSON 输出便于解析
        "-timeout", "10",
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd[cmd.index("-w") + 1] = wordlist
    elif os.path.isfile("/usr/share/seclists/Discovery/Web-Content/big.txt"):
        cmd[cmd.index("-w") + 1] = "/usr/share/seclists/Discovery/Web-Content/big.txt"
    else:
        logger.warning("无 ffuf 字典，跳过。请安装 ffuf 或提供 -w 参数。")
        return {"ok": False, "error": "未找到 ffuf 且无备用字典", "target": base_url, "findings": [], "summary_count": 0}

    logger.info(f"运行 ffuf: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=max_time + 10,
        )
        findings = []
        # ffuf JSON 输出格式: {"input": {"FUZZ": "admin"}, "url": "...", ...}
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict) and "input" in entry:
                    fuzz_val = entry["input"].get("FUZZ", "")
                    url = f"{base_url.rstrip('/')}/{fuzz_val}"
                    findings.append({
                        "url": url,
                        "status": entry.get("status", 0),
                        "size": entry.get("length", 0),
                        "word_count": entry.get("words", 0),
                        "line_count": entry.get("lines", 0),
                    })
            except json.JSONDecodeError:
                continue

        # 排序：按状态码 -> 大小降序
        findings.sort(key=lambda x: (x["status"], -x["size"]))

        return {
            "ok": True,
            "target": base_url,
            "findings": findings,
            "summary_count": len(findings),
            "error": "",
            "method": "ffuf",
        }

    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "target": base_url,
            "findings": [],
            "summary_count": 0,
            "error": f"ffuf 超时（最大时间 {max_time}s）",
        }


def fuzz_params(
    url: str,
    wordlist: List[str],
) -> dict:
    """对 URL 中的参数值进行模糊测试。

    Args:
        url: 包含 {FUZZ} 占位符的 URL（如 https://example.com/api?id={FUZZ}）
        wordlist: fuzzing 词表

    Returns:
        {"ok": True, "findings": [...], ...}
    """
    ffuf_path = _find_ffuf() or "ffuf"

    cmd = [
        ffuf_path,
        "-u", url,
        "-w", "-",       # stdin wordlist
        "-t", "20",
        "-mc", "200,301,302,403,500",
        "-json", "-",
        "-timeout", "5",
    ]

    logger.info(f"参数 fuzzing: {url[:80]}...")
    try:
        proc = subprocess.run(
            cmd, input="\n".join(wordlist), capture_output=True, text=True, timeout=300,
        )
        findings = []
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict) and "input" in entry:
                    fuzz_val = entry["input"].get("FUZZ", "")
                    findings.append({
                        "value": fuzz_val,
                        "url": url.replace("{FUZZ}", fuzz_val),
                        "status": entry.get("status", 0),
                        "size": entry.get("length", 0),
                    })
            except json.JSONDecodeError:
                continue

        return {
            "ok": True,
            "target": url,
            "findings": findings,
            "summary_count": len(findings),
            "error": "",
            "method": "ffuf",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target": url, "findings": [], "summary_count": 0, "error": "fuzzing 超时"}


def fuzz_headers(
    url: str,
    header_wordlist: List[str],
) -> dict:
    """对 HTTP Header 进行模糊测试（发现隐藏请求头等）。"""
    ffuf_path = _find_ffuf() or "ffuf"

    cmd = [
        ffuf_path,
        "-u", url,
        "-H", f"X-Forensic:FUZZ",
        "-w", "-",       # stdin
        "-t", "10",
        "-mc", "200,403,500",
        "-json", "-",
        "-timeout", "5",
    ]

    try:
        proc = subprocess.run(
            cmd, input="\n".join(header_wordlist), capture_output=True, text=True, timeout=300,
        )
        findings = []
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict):
                    fuzz_val = entry.get("input", {}).get("FUZZ", "")
                    findings.append({
                        "value": fuzz_val,
                        "header": "X-Forensic",
                        "status": entry.get("status", 0),
                        "size": entry.get("length", 0),
                    })
            except json.JSONDecodeError:
                continue

        return {
            "ok": True,
            "target": url,
            "findings": findings,
            "method": "ffuf-headers",
        }
    except Exception as e:
        return {"ok": False, "target": url, "findings": [], "error": str(e)}
