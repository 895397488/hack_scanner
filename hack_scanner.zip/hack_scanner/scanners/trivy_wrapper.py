#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trivy Wrapper — trivy CLI wrapper，依赖/容器镜像/文件系统漏洞扫描。

对应 swarm_playbooks.py CI/CD playbook 的 "dependency audit" 步骤，
单引擎覆盖 SBOM 漏洞 + 容器镜像 + 配置文件 + 密钥四类扫描。

集成方式：需要安装 trivy
  - Windows: choco install trivy  或  https://github.com/aquasecurity/trivy/releases
  - Linux:   curl -sfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sh
本模块只负责 CLI 调用和结果解析。config.json → tools.trivy_path 可指定路径。

Usage:
    from scanners.trivy_wrapper import trivy_scan
    result = trivy_scan("./app", scan_type="fs")
"""

import json
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('trivy_scanner')


def _find_trivy() -> Optional[str]:
    """查找 trivy 可执行文件：先 config.json → tools.trivy_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("trivy_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["trivy", "trivy.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def trivy_scan(target: str, scan_type: str = "fs", max_time: int = 600) -> dict:
    """运行 trivy 漏洞扫描。

    Args:
        target:    文件/目录路径（fs）或镜像名（image）
        scan_type: fs | image | repo | config | secret
        max_time:  最大运行时间秒

    Returns:
        {"ok": bool, "vulnerabilities": [...], "vuln_count": N, "error": ...}
    """
    if scan_type.lower() not in ("repo", "image"):
        if not target or not os.path.exists(target):
            return {"ok": False, "vulnerabilities": [], "vuln_count": 0, "error": f"路径不存在: {target}"}

    tv = _find_trivy()
    if not tv:
        return {"ok": False, "vulnerabilities": [], "vuln_count": 0,
                "error": "trivy 未找到，请安装: choco install trivy (Windows) 或见 github.com/aquasecurity/trivy"}

    t = scan_type.lower()
    if t == "fs":
        cmd = [tv, "fs", "--format", "json", "--quiet", "--no-progress", target]
    elif t == "image":
        cmd = [tv, "image", "--format", "json", "--quiet", "--no-progress", target]
    elif t == "repo":
        cmd = [tv, "repo", "--format", "json", "--quiet", "--no-progress", target]
    elif t == "config":
        cmd = [tv, "config", "--format", "json", "--quiet", "--no-progress", target]
    elif t == "secret":
        cmd = [tv, "secret", "--format", "json", "--quiet", "--no-progress", target]
    else:
        return {"ok": False, "vulnerabilities": [], "vuln_count": 0, "error": f"未知扫描类型: {scan_type}"}

    logger.info(f"trivy {t}: {target}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = proc.stdout or "{}"
        brace = raw.find("{")
        if brace >= 0:
            raw = raw[brace:]
        data = json.loads(raw)

        # fs/image/repo: Results[].Vulnerabilities
        vulns = []
        for res in (data.get("Results", []) or []):
            target_name = res.get("Target", "")
            for v in (res.get("Vulnerabilities", []) or []):
                sev = v.get("Severity", "UNKNOWN").lower()
                severity = "high" if sev == "critical" else ("high" if sev == "high" else ("medium" if sev == "medium" else "low"))
                vulns.append({
                    "vuln_id": v.get("VulnerabilityID", ""),
                    "package": v.get("PkgName", ""),
                    "installed": v.get("InstalledVersion", ""),
                    "fixed": v.get("FixedVersion", "") or "N/A",
                    "severity": severity,
                    "target": target_name,
                })

        # config/secret: Misconfigurations / Secrets（归一化）
        misconfigs = data.get("Misconfigurations", [])
        if isinstance(misconfigs, list) and misconfigs and isinstance(misconfigs[0], dict) and "Type" in misconfigs[0]:
            for mc in misconfigs:
                sev = (mc.get("Severity", "UNKNOWN") or "UNKNOWN").lower()
                severity = "high" if sev in ("critical", "high") else ("medium" if sev == "medium" else "low")
                vulns.append({
                    "vuln_id": mc.get("ID", ""),
                    "package": mc.get("Type", ""),
                    "installed": "",
                    "fixed": "",
                    "severity": severity,
                    "target": mc.get("Target", "") or mc.get("Cause", "")[:60],
                })

        return {
            "ok": True,
            "target": target,
            "scan_type": t,
            "vulnerabilities": vulns[:500],
            "vuln_count": len(vulns),
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "vulnerabilities": [], "vuln_count": 0, "error": "trivy 超时"}
    except json.JSONDecodeError as e:
        return {"ok": False, "vulnerabilities": [], "vuln_count": 0, "error": f"trivy 输出解析失败: {e}"}
