#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Checkov Wrapper — checkov CLI wrapper，IaC（基础设施即代码）静态分析。

对接 file_analyzer.py 的 YAML/配置扫描方向，覆盖：
  - Terraform / CloudFormation / Kubernetes / Serverless / Dockerfile / Bicep

集成方式：需要安装 checkov
  - pip install checkov   (推荐)
  - 或独立二进制: https://www.bracciolabs.com/  /  https://docs.bridgecrew.io/docs/getting-started-with-checkov
本模块只负责 CLI 调用和结果解析。config.json → tools.checkov_path 可指定路径。

Usage:
    from scanners.checkov_wrapper import checkov_scan
    result = checkov_scan("./iac")
"""

import json
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('checkov_scanner')


def _find_checkov() -> Optional[str]:
    """查找 checkov 可执行文件：先 config.json → tools.checkov_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("checkov_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["checkov", "checkov.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def checkov_scan(target_path: str, framework: str = "", max_time: int = 300) -> dict:
    """运行 checkov IaC 静态分析。

    Args:
        target_path: IaC 代码目录
        framework:  指定框架（空=自动检测；terraform/cloudformation/kubernetes/dockerfile/bicep）
        max_time:   最大运行时间秒

    Returns:
        {"ok": bool, "findings": [...], "passed": int, "failed": int, "error": ...}
    """
    if not target_path or not os.path.exists(target_path):
        return {"ok": False, "findings": [], "passed": 0, "failed": 0, "error": f"路径不存在: {target_path}"}

    ck = _find_checkov()
    if not ck:
        return {"ok": False, "findings": [], "passed": 0, "failed": 0,
                "error": "checkov 未找到，请安装: pip install checkov"}

    cmd = [ck, "-d", target_path, "--output", "json", "--quiet"]
    if framework:
        cmd.extend(["--framework", framework.lower()])
    logger.info(f"checkov scan: {target_path} (framework={framework or 'auto'})")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = proc.stdout or "{}"
        brace = raw.find("{")
        if brace >= 0:
            raw = raw[brace:]
        data = json.loads(raw)

        summary = data.get("summary", {}) or {}
        results = data.get("results", []) or []

        findings = []
        for r in results:
            if r.get("evaluation", "UNKNOWN") == "FAILED":
                sev_raw = r.get("definition", {}).get("severity", "INFO")
                sev = sev_raw.lower()
                severity = "high" if sev == "HIGH" else ("medium" if sev == "MEDIUM" else "low")
                findings.append({
                    "check_id": r.get("check_id", ""),
                    "filename": r.get("filename", ""),
                    "line": (r.get("range", [0, 0])[0]) if isinstance(r.get("range"), list) else None,
                    "message": (r.get("guideline", "") or "")[:200],
                    "severity": severity,
                })

        return {
            "ok": True,
            "target": target_path,
            "findings": findings[:500],
            "findings_count": len(findings),
            "passed": summary.get("passed_checks", 0),
            "failed": summary.get("failed_checks", 0),
            "skipped": summary.get("skipped_checks", 0),
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "findings": [], "passed": 0, "failed": 0, "error": "checkov 超时"}
    except json.JSONDecodeError as e:
        return {"ok": False, "findings": [], "passed": 0, "failed": 0, "error": f"checkov 输出解析失败: {e}"}
