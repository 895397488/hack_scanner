#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IOC / 威胁情报检测器 — 把 IP / 域名 / URL / 文件哈希 对照公开威胁情报源做匹配。

这是 hack_scanner 的"蓝队检测侧"能力：侦察/扫描拿到的一堆 IP、域名、URL、
上传文件的哈希，可一键对照已知恶意情报（C2、恶意域、恶意 URL、恶意样本）。

情报源（免费、无需 API Key，纯 HTTP 拉取 + 本地缓存 + 离线降级）：
  - URLhaus (abuse.ch)   — 恶意 URL / IP / 域名 / 样本 MD5
  - Malware Domain List  — 恶意域名
  - Spamhaus DROP        — 恶意 IP 网段 (CIDR)

特性：
  - 本地缓存（默认 24h TTL，存 data/ioc_cache/），避免频繁打上游；
  - 离线自动降级：下载失败时用最近一次缓存（标记 stale），完全没有则返回友好错误；
  - 纯 Python + requests（已是核心依赖），零新增原生依赖。

Usage:
    from scanners.ioc_detector import check_ioc, check_iocs, refresh_feeds, ioc_status
    check_ioc("203.0.113.66")
    check_iocs(["example-bad.com", "http://bad.example/x.php", "d41d8cd98f00b204e9800998ecf8427e"])
    refresh_feeds(force=True)
"""

import csv
import ipaddress
import io
import json
import logging
import os
import re
import time
from typing import Dict, List, Optional

logger = logging.getLogger('ioc_detector')

try:
    import requests
except Exception:  # pragma: no cover
    requests = None

# ── 默认情报源（免费、无 Key） ────────────────────────────
# 每源独立 timeout（秒）：不同源在慢网下的表现差异极大，不能用统一超时。
#   urlhaus       — abuse.ch CDN 在部分网络极慢（实测可达 70s+），但价值最高，给足时间
#   mdl           — mirror/主站都常被墙、不稳定，快速失败，别拖垮整个刷新（且 URLhaus 已含其恶意域名，属冗余源）
#   spamhaus_drop — 稳定且快
DEFAULT_FEEDS = [
    {
        "name": "urlhaus",
        "type": "urlhaus",
        "url": "https://urlhaus.abuse.ch/downloads/csv/",
        "ext": "csv",
        "timeout": 90,
        "desc": "abuse.ch URLhaus — 恶意 URL/IP/域名/样本MD5",
    },
    {
        "name": "malware_domain_list",
        "type": "mdl",
        "url": "https://mirror.malwaredomainlist.com/hostslist/hosts",
        "ext": "txt",
        "timeout": 15,
        "desc": "Malware Domain List — 恶意域名（常被墙/不稳定，属冗余源，可在 config.ioc.disable_feeds 关闭）",
    },
    {
        "name": "spamhaus_drop",
        "type": "spamhaus_drop",
        "url": "https://www.spamhaus.org/drop/drop.txt",
        "ext": "txt",
        "timeout": 30,
        "desc": "Spamhaus DROP — 恶意 IP 网段 (CIDR)",
    },
]

_USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
               "HackScanner/1.0 (threat-intel-lookup; contact: local)")


def _project_root() -> str:
    return os.path.normpath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def _default_cache_dir() -> str:
    return os.path.join(_project_root(), "data", "ioc_cache")


def _load_cfg() -> dict:
    p = os.path.join(_project_root(), "config.json")
    try:
        if os.path.isfile(p):
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f) or {}
    except Exception:
        pass
    return {}


# ── 数据模型 ─────────────────────────────────────────────
class IocDB:
    """内存 IOC 集合。"""

    def __init__(self):
        self.bad_ips = set()            # 精确 IP
        self.ip_nets = []               # ipaddress._Network 列表 (CIDR)
        self.bad_domains = set()        # 小写域名
        self.bad_urls = set()           # 小写 URL
        self.bad_hashes = set()         # 小写 md5/sha1/sha256
        self.source_meta: Dict[str, dict] = {}  # name -> {fetched_at, size, url}

    def stats(self) -> dict:
        return {
            "ips": len(self.bad_ips),
            "ip_networks": len(self.ip_nets),
            "domains": len(self.bad_domains),
            "urls": len(self.bad_urls),
            "hashes": len(self.bad_hashes),
            "feeds": {k: v for k, v in self.source_meta.items()},
        }


# ── 解析各情报源 ─────────────────────────────────────────
def _parse_urlhaus(text: str, db: IocDB) -> int:
    count = 0
    # 注意：csv 模块要求以 newline='' 打开，否则遇未引号包裹的换行会报错
    reader = csv.reader(io.StringIO(text, newline=''))
    try:
        header = next(reader, None)
    except Exception:
        header = None
    for row in reader:
        if not row or len(row) < 4:
            continue
        # 列: url, ip, port, domain, urlstatus, maltype, hash, filename, reporttime
        url = (row[0] or "").strip().lower()
        ip = (row[1] or "").strip()
        domain = (row[3] or "").strip().lower()
        # hash 列位置（urlstatus=4, maltype=5, hash=6）
        h = row[6].strip().lower() if len(row) > 6 else ""
        if url:
            db.bad_urls.add(url)
        if domain:
            db.bad_domains.add(domain)
        if ip:
            try:
                db.bad_ips.add(str(ipaddress.ip_address(ip)))
                db.ip_nets.append(ipaddress.ip_network(ip, strict=False))
            except ValueError:
                pass
        if re.fullmatch(r"[0-9a-f]{32}", h or ""):
            db.bad_hashes.add(h)
        count += 1
    return count


def _parse_mdl(text: str, db: IocDB) -> int:
    count = 0
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 2:
            ip, domain = parts[0], parts[1].lower().lstrip("*.")
            if domain:
                db.bad_domains.add(domain)
            if ip:
                try:
                    db.bad_ips.add(str(ipaddress.ip_address(ip)))
                except ValueError:
                    pass
            count += 1
    return count


def _parse_spamhaus_drop(text: str, db: IocDB) -> int:
    count = 0
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        # 去掉行内注释（Spamhaus 用 `; SBLxxxx` 标注，如 "1.10.16.0/20 ; SBL256894"）
        for sep in (";", "#"):
            idx = line.find(sep)
            if idx != -1:
                line = line[:idx].strip()
        if not line:
            continue
        try:
            net = ipaddress.ip_network(line, strict=False)
            db.ip_nets.append(net)
            count += 1
        except ValueError:
            continue
    return count


_PARSERS = {
    "urlhaus": _parse_urlhaus,
    "mdl": _parse_mdl,
    "spamhaus_drop": _parse_spamhaus_drop,
}


# ── 下载 + 缓存 ──────────────────────────────────────────
def refresh_feeds(
    feeds: Optional[List[dict]] = None,
    force: bool = False,
    timeout: int = 30,
    cache_dir: str = "",
) -> dict:
    """拉取情报源并写入本地缓存。

    Args:
        feeds: 自定义源列表（默认用内置 DEFAULT_FEEDS + config ioc.feeds 合并）
        force: 忽略 TTL 强制刷新
        timeout: 单源下载超时秒
        cache_dir: 缓存目录（默认 data/ioc_cache）

    Returns:
        {"ok": bool, "cache_dir": "...", "feeds": [{name, ok, entries, bytes,
         fetched_at, error}, ...], "error": ""}
    """
    cfg = _load_cfg().get("ioc", {}) or {}
    cache_dir = cache_dir or cfg.get("cache_dir", "") or _default_cache_dir()
    os.makedirs(cache_dir, exist_ok=True)
    # 允许 config 关闭某些源（如某网络下 MDL 不可达，避免每次刷新都卡它）
    disabled = {str(n) for n in (cfg.get("disable_feeds") or [])}

    if feeds is None:
        feeds = list(DEFAULT_FEEDS)
        # 允许 config 追加自定义源
        for f in (cfg.get("feeds") or []):
            if isinstance(f, dict) and f.get("url"):
                feeds.append(f)

    if requests is None:
        return {"ok": False, "cache_dir": cache_dir, "feeds": [],
                "error": "requests 库不可用，无法下载情报源"}

    results = []
    any_ok = False
    for feed in feeds:
        name = feed.get("name") or os.path.basename(feed.get("url", "feed"))
        if name in disabled:
            results.append({
                "name": name, "ok": True, "skipped": True, "entries": 0,
                "bytes": 0, "fetched_at": None, "error": "",
                "note": "已在 config.ioc.disable_feeds 中关闭（跳过）"})
            continue
        feed_url = feed.get("url", "")
        ftype = feed.get("type", "")
        ext = feed.get("ext", "txt")
        file_path = os.path.join(cache_dir, f"{name}.{ext}")
        meta_path = os.path.join(cache_dir, f"{name}.meta.json")

        entry = {"name": name, "ok": False, "entries": 0, "bytes": 0,
                 "fetched_at": None, "error": ""}

        # TTL 判断
        ttl_hours = float(cfg.get("cache_ttl_hours", 24) or 24)
        if not force and os.path.isfile(file_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as fh:
                    meta = json.load(fh)
                age_h = (time.time() - meta.get("fetched_at", 0)) / 3600.0
                if age_h < ttl_hours:
                    entry.update({"ok": True, "fetched_at": meta.get("fetched_at"),
                                  "note": "cached"})
                    results.append(entry)
                    any_ok = True
                    continue
            except Exception:
                pass

        # 下载（每源独立超时：优先用源自带的 timeout，退回全局默认）
        try:
            feed_timeout = int(feed.get("timeout") or timeout)
            resp = requests.get(feed_url, timeout=feed_timeout,
                                headers={"User-Agent": _USER_AGENT})
            resp.raise_for_status()
            text = resp.text
            db = IocDB()
            parser = _PARSERS.get(ftype)
            if parser is None:
                raise ValueError(f"未知情报源类型: {ftype}")
            n = parser(text, db)
            with open(file_path, "w", encoding="utf-8") as fh:
                fh.write(text)
            meta = {"name": name, "url": feed_url, "type": ftype,
                    "fetched_at": time.time(), "entries": n,
                    "size": len(text.encode('utf-8', 'ignore'))}
            with open(meta_path, "w", encoding="utf-8") as fh:
                json.dump(meta, fh, ensure_ascii=False, indent=2)
            entry.update({"ok": True, "entries": n, "bytes": len(text),
                          "fetched_at": meta["fetched_at"]})
            any_ok = True
        except Exception as e:
            entry["error"] = str(e)[:300]
            # 下载失败但本地有旧缓存 → 标记为 stale 可用
            if os.path.isfile(file_path):
                try:
                    with open(meta_path, "r", encoding="utf-8") as fh:
                        meta = json.load(fh)
                    entry.update({"ok": True, "fetched_at": meta.get("fetched_at"),
                                  "note": "stale-cache"})
                    any_ok = True
                except Exception:
                    pass
        results.append(entry)

    return {"ok": any_ok, "cache_dir": cache_dir, "feeds": results, "error": ""}


def _load_from_cache(cache_dir: str) -> Optional[IocDB]:
    """从本地缓存构建 IocDB；无任何缓存返回 None。"""
    if not os.path.isdir(cache_dir):
        return None
    db = IocDB()
    loaded_any = False
    for fname in os.listdir(cache_dir):
        if not fname.endswith(".meta.json"):
            continue
        meta_path = os.path.join(cache_dir, fname)
        try:
            with open(meta_path, "r", encoding="utf-8") as fh:
                meta = json.load(fh)
            name = meta.get("name")
            ftype = meta.get("type")
            data_file = None
            # 找到对应数据文件
            for cand in os.listdir(cache_dir):
                if cand.startswith(name + ".") and cand != fname:
                    data_file = os.path.join(cache_dir, cand)
                    break
            if not data_file or not os.path.isfile(data_file):
                continue
            with open(data_file, "r", encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
            parser = _PARSERS.get(ftype)
            if parser:
                parser(text, db)
                db.source_meta[name] = meta
                loaded_any = True
        except Exception:
            continue
    return db if loaded_any else None


def _get_db(refresh_if_missing: bool = True) -> Optional[IocDB]:
    cfg = _load_cfg().get("ioc", {}) or {}
    cache_dir = cfg.get("cache_dir", "") or _default_cache_dir()
    db = _load_from_cache(cache_dir)
    if db is None and refresh_if_missing:
        rep = refresh_feeds(force=False, cache_dir=cache_dir)
        if rep.get("ok"):
            db = _load_from_cache(cache_dir)
    return db


def _classify(value: str) -> str:
    v = value.strip()
    if re.fullmatch(r"[0-9a-fA-F]{32}", v):
        return "hash_md5"
    if re.fullmatch(r"[0-9a-fA-F]{40}", v):
        return "hash_sha1"
    if re.fullmatch(r"[0-9a-fA-F]{64}", v):
        return "hash_sha256"
    if re.match(r"^https?://", v, re.IGNORECASE):
        return "url"
    try:
        ipaddress.ip_address(v)
        return "ip"
    except ValueError:
        pass
    if re.fullmatch(r"[a-z0-9.\-]+(\.[a-z0-9\-]+)+", v.lower()):
        return "domain"
    return "unknown"


def _match_ip(ip_str: str, db: IocDB) -> Optional[str]:
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return None
    if str(ip) in db.bad_ips:
        return "exact-ip"
    for net in db.ip_nets:
        if ip in net:
            return str(net)
    return None


def check_ioc(value: str) -> dict:
    """检测单个 IOC（自动识别 IP/域名/URL/哈希）。

    Returns:
        {"ok": True, "value": "...", "type": "ip|domain|url|hash",
         "malicious": bool, "matched_in": "...", "matched_feed": "...",
         "db_stats": {...}, "error": ""}
    """
    if not value or not value.strip():
        return {"ok": False, "value": value, "malicious": False,
                "error": "value 不能为空"}

    db = _get_db(refresh_if_missing=True)
    if db is None:
        return {"ok": False, "value": value, "malicious": False,
                "error": "无可用威胁情报（下载失败且无本地缓存），请检查网络后重试 refresh_feeds()"}

    v = value.strip()
    kind = _classify(v)
    malicious = False
    matched_in = ""

    if kind in ("hash_md5", "hash_sha1", "hash_sha256"):
        if v.lower() in db.bad_hashes:
            malicious = True
            matched_in = "urlhaus-hash"
    elif kind == "url":
        low = v.lower()
        if low in db.bad_urls:
            malicious = True
            matched_in = "urlhaus-url"
        else:
            # 尝试从 URL 提取域名/IP 再查
            m = re.match(r"^https?://([^/:]+)", low)
            host = m.group(1) if m else ""
            if host:
                hit = _match_ip(host, db) if _classify(host) == "ip" else None
                if hit:
                    malicious, matched_in = True, f"urlhaus-ip({hit})"
                elif host in db.bad_domains:
                    malicious, matched_in = True, "urlhaus-domain"
    elif kind == "ip":
        hit = _match_ip(v, db)
        if hit:
            malicious, matched_in = True, hit
    elif kind == "domain":
        low = v.lower().lstrip("*.")
        if low in db.bad_domains:
            malicious = True
            matched_in = "mdl/urlhaus-domain"
    else:
        # 未知类型：宽松地在各集合里找
        low = v.lower()
        if low in db.bad_domains:
            malicious, matched_in = True, "domain"
        elif low in db.bad_urls:
            malicious, matched_in = True, "url"

    return {
        "ok": True,
        "value": value,
        "type": kind,
        "malicious": malicious,
        "matched_in": matched_in,
        "db_stats": db.stats(),
        "error": "",
    }


def check_iocs(values: List[str]) -> dict:
    """批量检测多个 IOC。

    Returns:
        {"ok": True, "total": N, "malicious": N, "results": [check_ioc(...), ...],
         "db_stats": {...}, "error": ""}
    """
    results = []
    for v in values or []:
        r = check_ioc(v)
        if not r.get("ok") and r.get("error", "").startswith("无可用威胁情报"):
            return r  # 情报不可用，直接返回
        results.append(r)
    malicious = sum(1 for r in results if r.get("malicious"))
    db_stats = next((r["db_stats"] for r in results if "db_stats" in r), {})
    return {
        "ok": True,
        "total": len(results),
        "malicious": malicious,
        "results": results,
        "db_stats": db_stats,
        "error": "",
    }


def ioc_status() -> dict:
    """IOC 引擎状态（供 tool_detector / tools_status / MCP 调用）。"""
    cfg = _load_cfg().get("ioc", {}) or {}
    cache_dir = cfg.get("cache_dir", "") or _default_cache_dir()
    db = _load_from_cache(cache_dir)
    if db is None:
        return {"ok": False, "available": False, "cache_dir": cache_dir,
                "feeds": [], "note": "尚未缓存任何情报源，请先调用 refresh_feeds()"}
    meta = db.stats()
    return {
        "ok": True,
        "available": True,
        "cache_dir": cache_dir,
        "counts": {k: meta[k] for k in ("ips", "ip_networks", "domains", "urls", "hashes")},
        "feeds": meta["feeds"],
    }
