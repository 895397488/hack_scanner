#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DNS Zone Transfer / Enumeration — DNS 区域转移 + 深度枚举。

利用 dnspython（已安装）的 AXFR/IXFR 功能进行 zone transfer，
以及 DNS SRV/MX/TXT/NS/SOA/SPIRIT/CDNSKEY 等记录查询。

Usage:
    from scanners.dns_zone_transfer import dns_recon
    result = dns_recon("example.com")
"""

import json
import logging
from typing import Dict, List, Optional

logger = logging.getLogger('dns_zone_transfer')


def _try_axfr(domain: str) -> list:
    """尝试 DNS 区域转移 (AXFR)"""
    records = []
    try:
        import dns.resolver
        import dns.query
        import dns.zone
        import dns.rdatatype

        resolver = dns.resolver.Resolver()
        resolver.timeout = 10
        resolver.lifetime = 30

        # Find the authoritative nameserver
        try:
            ns_answers = resolver.resolve(domain, 'NS')
            ns_servers = [str(ns.target).rstrip('.') for ns in ns_answers]
        except dns.resolver.NoAnswer:
            return []

        for ns_server in ns_servers[:3]:  # Check up to 3 NS servers
            try:
                zone = dns.zone.from_xfr(dns.query.xfr(ns_server, domain))
                for name, node in zone.nodes.items():
                    for rdataset in node.rdatasets:
                        rdtype = dns.rdatatype.to_text(rdataset.rdtype)
                        for rr in rdataset:
                            rdata = str(rr).rstrip('.')
                            records.append({
                                "name": str(name),
                                "type": rdtype,
                                "value": rdata,
                                "ttl": rdataset.ttl,
                                "server": ns_server,
                            })

                if records:
                    return {"transfer_success": True, "records": records}
            except Exception:
                pass

        return {"transfer_success": False, "records": []}

    except ImportError:
        return {"error": "dnspython not installed", "records": []}


def _query_all_records(domain: str) -> list:
    """查询所有 DNS 记录类型"""
    records = []
    record_types = ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'SRV',
                    'CAA', 'SPF', 'PTR', 'DNSKEY', 'DS', 'NSEC', 'RRSIG']

    try:
        import dns.resolver
        resolver = dns.resolver.Resolver()
        resolver.timeout = 5
        resolver.lifetime = 15

        for rtype in record_types:
            try:
                answers = resolver.resolve(domain, rtype)
                for ans in answers:
                    records.append({
                        "name": str(ans.name),
                        "type": rtype,
                        "value": str(ans).rstrip('.') if hasattr(ans, 'target') else str(ans),
                    })
            except dns.resolver.NoAnswer:
                pass
            except dns.resolver.NXDOMAIN:
                break
            except Exception:
                pass

    except ImportError:
        return {"error": "dnspython not installed", "records": []}

    return records


def _find_sdns(domain: str) -> list:
    """Find Service Discovery (SRV records)"""
    srv_records = []
    try:
        import dns.resolver
        resolver = dns.resolver.Resolver()
        answers = resolver.resolve(f"_sip._tcp.{domain}", 'SRV') if domain else []
        for ans in answers:
            srv_records.append({
                "service": "_sip",
                "transport": "_tcp",
                "target": str(ans.target).rstrip('.'),
                "priority": ans.priority,
                "weight": ans.weight,
                "port": ans.port,
            })
    except Exception:
        pass
    return srv_records


def _urlparse(url):
    from urllib.parse import urlparse
    return urlparse(url)


def dns_recon(domain: str) -> dict:
    """综合 DNS 侦察：区域转移 + 记录查询。

    Args:
        domain: 目标域名

    Returns:
        {
            "ok": True,
            "domain": "...",
            "zone_transfer": {"success": True/False},
            "all_records": [...],
            "ns_servers": [...],
            "mx_records": [...],
            "txt_records": [...],
            "spf_record": "...",
            "dmarc_record": "...",
            "error": ""
        }
    """
    from urllib.parse import urlparse as _urlparse
    domain = _urlparse(f"https://{domain}").hostname if '://' in domain else domain
    result = {
        "ok": False,
        "domain": domain,
        "zone_transfer": {"success": False, "records": []},
        "all_records": [],
        "ns_servers": [],
        "mx_records": [],
        "txt_records": [],
        "dmarc_record": "",
        "error": "",
    }

    try:
        # AXFR
        axfr = _try_axfr(domain)
        if "records" in axfr and axfr["records"]:
            result["zone_transfer"] = {
                "success": True,
                "records": axfr["records"][:200],
            }

        # All records
        all_recs = _query_all_records(domain)
        result["all_records"] = all_recs[:100]

        # Filter by type
        for r in all_recs:
            if r.get("type") == "NS":
                result["ns_servers"].append(r.get("value", ""))
            elif r.get("type") == "MX":
                result["mx_records"].append({
                    "priority": r.get("value", ""),
                    "mail_server": r.get("value", ""),
                })
            elif r.get("type") == "TXT":
                val = r.get("value", "")
                if val.startswith("v=spf1"):
                    result["spf_record"] = val
                if val.startswith("v=DMARC1") or "_dmarc" in str(r.get("name", "")):
                    result["dmarc_record"] = val

        result["ok"] = True

    except Exception as e:
        result["error"] = str(e)

    return result
