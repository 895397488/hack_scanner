#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
攻击面知识图谱 — host/subdomain/endpoint/param/finding 五类节点
=====================================================================

背景（参照 redamon graph_db/schema.py + Neo4j 攻击面图）:
    redamon 把 recon 各工具输出并入一张图（host/subdomain/endpoint/param/
    finding），agent 可自然语言查询"这个 host 上有哪些端点、哪些发现打在
    哪个参数上"。Neo4j 是重依赖；本模块落 **SQLite 单文件版**（sqlite3
    是标准库）：同构的五类节点 + 关系边，查询走结构化操作（确定性、
    可审计），Neo4j 版本可作后续可选项。

节点/边模型:
    节点  host       注册域（example.com）
    节点  subdomain  具体子域（api.example.com）
    节点  endpoint   路径（/api/v1/users），attrs 带所属 host
    节点  param      参数名（id），attrs 带所属 endpoint
    节点  finding    漏洞发现（title），attrs 带 severity/vuln_type/confidence
    边    subdomain_of  subdomain → host
    边    endpoint_on   endpoint → host|subdomain
    边    param_of      param → endpoint
    边    finding_on    finding → endpoint|host|param

数据流（入口层模式，orchestrator 零改动）:
    - install_graph_ingest(orch, graph): 包装 execute（装在不可信边界内侧，
      看原文），每次工具返回后 ingest_text 抽取 host/subdomain/endpoint/param
    - 收尾（run_adaptive 5e 分诊后）: ingest_findings 把最终 findings 并图
    - attack_graph 工具: LLM 可查询 stats/list/neighbors/findings/paths
    - export_section(): 报告 Markdown 段

设计纪律（与 correction/anti_loop 一致）:
    - 纯标准库（sqlite3）；脏输入/DB 异常全程静默降级，绝不阻断核心循环
    - 有界：max_nodes/max_edges 上限 + 每次 ingest 的候选上限
    - 幂等：UNIQUE(kind,value) / UNIQUE(src,dst,rel)，重复 ingest 不翻倍
    - 可关闭：config advanced.attack_graph.enabled=false → 零变化
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

__all__ = [
    "GraphStore",
    "make_attack_graph_tool",
    "install_graph_ingest",
    "default_db_path",
    "slugify_target",
]


# ---------------------------------------------------------------------------
# 域识别（URL 锚定为主 + FQDN 正则兜底，TLD 白名单控噪）
# ---------------------------------------------------------------------------
_URL_RE = re.compile(r"https?://[^\s'\"<>()\[\]{}]+", re.IGNORECASE)
_IP_RE = re.compile(r"(?<![\d.])((?:\d{1,3}\.){3}\d{1,3})(?![\d.])")
_FQDN_RE = re.compile(
    r"\b((?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,24})\b")
# 注意：query 串第一个参数前无 ?（? 属于完整 URL），用 ^ 兜住首参
_PARAM_RE = re.compile(r"(?:^|&)([A-Za-z0-9_][A-Za-z0-9_.\-]{0,63})=")

# 常见单标签 TLD（gTLD + ISO-3166 二字码全表 + 内网常见）
_TLD_SET = frozenset("""
    com net org info biz dev io app ai cloud site online tech xyz top vip pro me ws
    local localdomain internal
    ac ad ae af ag al am ao ar at au aw az ba bb bd be bf bg bi bj bn bo br bs bt bw by bz
    ca cd cf cg ch ci ck cl cm cn co cr cu cy cz de dj dk dm do dz ec ee eg er es et fi fj
    fm fr ga gd ge gh gi gl gm gn gp gr gt gu gw gy hn hr ht hu id ie il im in iq ir is it
    je jm jo jp ke kg kh ki km kn kp kr kw ky kz la lb lc li lk lr ls lt lu lv ly ma mc
    md mg mh mk ml mm mn mr mt mu mv mw mx my mz na ne nf ng ni nl no np nr nu nz om pa pe
    pf pg ph pk pl pm pn pr ps pw py qa re ro rs ru rw sa sb sc sd se sg sh si sk sl sm sn
    so sr ss st sv sx sy sz tc td tg th tj tk tl tm tn to tr tt tv tw tz ua ug us uy uz
    va vc ve vg vi vn vu wf ye yt za zm zw
""".split())

# 双段 TLD（xxx.co.uk / com.cn …）
_TWO_PART_TLDS = frozenset("""
    co.uk org.uk gov.uk ac.uk net.uk
    co.jp co.in co.kr co.id co.th co.nz co.za co.il co.ke co.ao co.nz
    com.cn net.cn org.cn gov.cn
    com.hk org.hk com.tw org.tw
    com.au org.au com.my org.my com.sg org.sg com.ph org.ph
    com.vn com.pk com.bd com.lk com.kh com.np com.mm
    com.ar com.br com.cl com.co com.ve com.pe com.ec com.gt com.do
    com.cr com.sv com.hn com.ni com.py com.uy com.cu com.pr com.mx
    com.tr com.eg com.ma com.tn com.dz com.sa com.ae com.qa com.om
    com.iq com.jo com.lb com.kw com.bh com.cy com.gr
    org.cn org.hk org.tw org.jp org.in org.kr org.sg org.my org.au
""".split())

# 无意义路径（HTML 伪路径/资产类 — 不作 endpoint 节点）
_PSEUDO_PATHS = {
    "/a", "/b", "/code", "/div", "/em", "/i", "/li", "/p", "/pre",
    "/script", "/span", "/strong", "/style", "/head", "/body", "/html",
    "/title", "/meta", "/link", "/favicon.ico", "/robots.txt",
}

# 每次 ingest 的候选上限（防单个巨输出灌爆图）
_MAX_HOSTS_PER_INGEST = 40
_MAX_ENDPOINTS_PER_INGEST = 40
_MAX_PARAMS_PER_INGEST = 20
_MAX_PARAMS_PER_ENDPOINT = 8


def _clean_url(raw: str) -> str:
    return str(raw or "").rstrip(".,;:!?'\"}）,;:，。")


def _registered_domain(domain: str) -> str:
    """example.com → example.com；api.example.com → example.com；x.co.uk → x.co.uk。"""
    labels = str(domain or "").lower().split(".")
    if len(labels) < 2:
        return str(domain or "").lower()
    # 双段 TLD（co.uk）：注册域=后 3 段；判定用后 2 段查 TLD 表
    if len(labels) >= 3 and ".".join(labels[-2:]) in _TWO_PART_TLDS:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def _is_plausible_domain(domain: str) -> bool:
    d = str(domain or "").lower().strip().rstrip(".")
    labels = d.split(".")
    if len(labels) < 2:
        return False
    if any(l.startswith("xn--") for l in labels):
        return True  # punycode 域名，视为可信
    if all(l.isdigit() for l in labels):
        return False  # 全数字 → IP 形态（走 IP 通道）
    if ".".join(labels[-2:]) in _TWO_PART_TLDS:
        return True
    return labels[-1] in _TLD_SET


def _is_valid_ip(ip: str) -> bool:
    parts = str(ip or "").split(".")
    if len(parts) != 4:
        return False
    for p in parts:
        if not p.isdigit() or len(p) > 3 or int(p) > 255:
            return False
    return True


def _is_meaningful_path(path: str) -> bool:
    value = str(path or "").strip().lower()
    if len(value) < 3 or value == "/":
        return False
    if value in _PSEUDO_PATHS:
        return False
    if value.startswith(("//", "/usr/", "/lib/", "/site-packages/", "/dev/",
                        "/bin/", "/etc/", "/var/", "/opt/", "/tmp/")):
        return False
    if value.endswith((".js", ".css", ".png", ".jpg", ".jpeg", ".gif",
                       ".svg", ".ico", ".woff", ".woff2", ".ttf", ".map")):
        return False  # 静态资产不作端点节点
    return True


def slugify_target(target: Any) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(target or "target").strip())[:80].strip("._")
    return s or "target"


def default_db_path(base_dir: str, target: Any) -> str:
    return os.path.join(str(base_dir), slugify_target(target) + ".sqlite")


# ---------------------------------------------------------------------------
# GraphStore — SQLite 单文件图谱
# ---------------------------------------------------------------------------
class GraphStore:
    """攻击面图谱（五类节点 + 四类边；sqlite3 单文件）。

    所有公共方法脏输入安全：异常/非法值 → 静默降级（返回 None/False/[]），
    绝不向核心循环外溢。
    """

    KINDS = ("host", "subdomain", "endpoint", "param", "finding")
    RELS = ("subdomain_of", "endpoint_on", "param_of", "finding_on")

    def __init__(self, db_path: str, max_nodes: int = 2000, max_edges: int = 8000):
        db_path = str(db_path or "").strip()
        if not db_path:
            raise ValueError("db_path is required")
        self.db_path = os.path.abspath(db_path)
        self.max_nodes = max(10, int(max_nodes))
        self.max_edges = max(20, int(max_edges))
        d = os.path.dirname(self.db_path)
        if d:
            os.makedirs(d, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path)
        self._create_schema()

    # -- 生命周期 -------------------------------------------------------------
    def _create_schema(self) -> None:
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS nodes(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              kind TEXT NOT NULL,
              value TEXT NOT NULL,
              attrs TEXT NOT NULL DEFAULT '{}',
              UNIQUE(kind, value)
            );
            CREATE TABLE IF NOT EXISTS edges(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              src INTEGER NOT NULL,
              dst INTEGER NOT NULL,
              rel TEXT NOT NULL,
              UNIQUE(src, dst, rel)
            );
            CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind);
            CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src);
            CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst);
            """
        )
        self._conn.commit()

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass

    def __enter__(self) -> "GraphStore":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- 基础写 ---------------------------------------------------------------
    def upsert_node(self, kind: str, value: str, attrs: Optional[Dict] = None) -> Optional[int]:
        """插入或取回节点 id。非法/超上限 → None。attrs 与既有合并（非空覆盖）。"""
        kind = str(kind or "").strip().lower()
        value = str(value or "").strip()
        if kind not in self.KINDS or not value:
            return None
        value = value[:512]
        try:
            row = self._conn.execute(
                "SELECT id, attrs FROM nodes WHERE kind=? AND value=?",
                (kind, value)).fetchone()
            if row is not None:
                nid = int(row[0])
                if attrs:
                    try:
                        cur = json.loads(row[1] or "{}")
                        if not isinstance(cur, dict):
                            cur = {}
                        cur.update({k: v for k, v in attrs.items() if v is not None})
                        self._conn.execute(
                            "UPDATE nodes SET attrs=? WHERE id=?",
                            (json.dumps(cur, ensure_ascii=False), nid))
                        self._conn.commit()
                    except Exception:
                        pass
                return nid
            if self._node_count() >= self.max_nodes:
                return None
            cur = self._conn.execute(
                "INSERT INTO nodes(kind, value, attrs) VALUES(?, ?, ?)",
                (kind, value, json.dumps(attrs or {}, ensure_ascii=False)))
            self._conn.commit()
            return int(cur.lastrowid)
        except (sqlite3.Error, TypeError, ValueError):
            return None

    def add_edge(self, src: Optional[int], dst: Optional[int], rel: str) -> bool:
        if src is None or dst is None or rel not in self.RELS:
            return False
        try:
            if self._edge_count() >= self.max_edges:
                return False
            self._conn.execute(
                "INSERT OR IGNORE INTO edges(src, dst, rel) VALUES(?, ?, ?)",
                (int(src), int(dst), rel))
            self._conn.commit()
            return True
        except (sqlite3.Error, TypeError, ValueError):
            return False

    def _node_count(self) -> int:
        try:
            return int(self._conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0])
        except sqlite3.Error:
            return 0

    def _edge_count(self) -> int:
        try:
            return int(self._conn.execute("SELECT COUNT(*) FROM edges").fetchone()[0])
        except sqlite3.Error:
            return 0

    # -- 域/端点/参数 抽取入库 -------------------------------------------------
    def _add_domain(self, domain: str, tool: str, stats: Dict[str, int]) -> Optional[int]:
        """domain → host/subdomain 节点 + subdomain_of 边。返回该域节点 id。"""
        d = str(domain or "").lower().strip().rstrip(".")
        if not d or not _is_plausible_domain(d):
            return None
        root = _registered_domain(d)
        root_id = self.upsert_node("host", root,
                                   {"source_tool": tool, "type": "ip" if _is_valid_ip(root) else "domain"})
        if root_id is None:
            return None
        if d == root:
            stats["hosts"] += 1
            return root_id
        sub_id = self.upsert_node("subdomain", d, {"source_tool": tool})
        if sub_id is None:
            return root_id
        if self.add_edge(sub_id, root_id, "subdomain_of"):
            stats["edges"] += 1
        stats["subdomains"] += 1
        return sub_id

    def _add_endpoint(self, path: str, host_node_id: Optional[int], host: str,
                      tool: str, stats: Dict[str, int]) -> Optional[int]:
        ep_id = self.upsert_node("endpoint", path, {"host": host, "source_tool": tool})
        if ep_id is None:
            return None
        if host_node_id is not None and self.add_edge(ep_id, host_node_id, "endpoint_on"):
            stats["edges"] += 1
        stats["endpoints"] += 1
        return ep_id

    def ingest_text(self, tool: str, text: str) -> Dict[str, int]:
        """从一段工具输出抽取 host/subdomain/endpoint/param 并入库（有界、幂等）。"""
        stats = {"hosts": 0, "subdomains": 0, "endpoints": 0, "params": 0, "edges": 0}
        text = str(text or "")
        if not text.strip():
            return stats
        seen_hosts: Dict[str, Any] = {}   # host → 节点 id（供 endpoint_on 边）
        seen_eps: set = set()
        seen_params: set = set()

        # 1) URL 锚定（最可信）：host + path + query 参数
        for raw in _URL_RE.findall(text)[:80]:
            url = _clean_url(raw)
            try:
                host = (urlparse(url).hostname or "").lower()
                path = (urlparse(url).path or "").split("#")[0]
                query = urlparse(url).query or ""
            except ValueError:
                continue
            if host:
                if host not in seen_hosts and stats["hosts"] + stats["subdomains"] < _MAX_HOSTS_PER_INGEST:
                    node_id = self._add_domain(host, str(tool), stats)
                    if node_id is not None:
                        seen_hosts[host] = node_id
            ep_node_id = None
            if host and _is_meaningful_path(path):
                key = (host, path)
                if key not in seen_eps and stats["endpoints"] < _MAX_ENDPOINTS_PER_INGEST:
                    ep_node_id = self._add_endpoint(path, seen_hosts.get(host), host,
                                                    str(tool), stats)
                    seen_eps.add(key)
            for key in _PARAM_RE.findall(query):
                pkey = (path or "/", key)
                if pkey in seen_params or stats["params"] >= _MAX_PARAMS_PER_INGEST:
                    continue
                p_id = self.upsert_node("param", key, {"endpoint": path or "/"})
                if p_id is None:
                    continue
                if ep_node_id is not None and self.add_edge(p_id, ep_node_id, "param_of"):
                    stats["edges"] += 1
                seen_params.add(pkey)
                stats["params"] += 1

        # 2) 裸 FQDN（subfinder/amass 类输出，无 URL 前缀）
        for m in _FQDN_RE.finditer(text):
            if stats["hosts"] + stats["subdomains"] >= _MAX_HOSTS_PER_INGEST:
                break
            d = m.group(1).lower().rstrip(".")
            if d in seen_hosts:
                continue
            if _is_valid_ip(d):
                continue  # IP 形态走 IP 通道
            if not _is_plausible_domain(d):
                continue
            node_id = self._add_domain(d, str(tool), stats)
            if node_id is not None:
                seen_hosts[d] = node_id

        # 3) IPv4
        for ip in _IP_RE.findall(text)[:20]:
            if stats["hosts"] >= _MAX_HOSTS_PER_INGEST:
                break
            if not _is_valid_ip(ip) or ip in seen_hosts:
                continue
            if self.upsert_node("host", ip, {"source_tool": str(tool), "type": "ip"}) is not None:
                stats["hosts"] += 1
                seen_hosts[ip] = True
        return stats

    def ingest_finding(self, finding: Any) -> Optional[int]:
        """一条 finding → finding 节点 + finding_on 边（endpoint/host/param）。"""
        f = finding if isinstance(finding, dict) else {}
        title = str(f.get("title") or f.get("name") or f.get("vuln_type")
                    or f.get("type") or "finding").strip()[:256] or "finding"
        target = str(f.get("url") or f.get("target") or f.get("endpoint") or "").strip()
        deepdive = f.get("deepdive") if isinstance(f.get("deepdive"), dict) else {}
        vt = (str(f.get("type") or f.get("vuln_type") or f.get("category")
                  or deepdive.get("vuln_type") or "")).strip()[:64]
        attrs: Dict[str, Any] = {}
        for key, attr in (("severity", "severity"), ("confidence", "confidence"),
                          ("cvss_score", "cvss"), ("triage_score", "triage_score"),
                          ("triage_rank", "triage_rank")):
            v = f.get(key)
            if v is not None and v != "":
                attrs[attr] = v
        if vt:
            attrs["vuln_type"] = vt
        if target:
            attrs["target"] = target[:300]
        fid = self.upsert_node("finding", title, attrs)
        if fid is None:
            return None

        if target and re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", target):
            try:
                host = (urlparse(target).hostname or "").lower()
                path = (urlparse(target).path or "").split("#")[0]
            except ValueError:
                host, path = "", ""
            host_node = self._add_domain(host, "finding", {"hosts": 0, "subdomains": 0,
                                                          "endpoints": 0, "params": 0,
                                                          "edges": 0}) if host else None
            ep_node = None
            if host and _is_meaningful_path(path):
                ep_node = self.upsert_node("endpoint", path, {"host": host,
                                                              "source": "finding"})
            # endpoint 与 host 双挂：host 级查询（findings_about(host)）能直接
            # 命中该 host 端点上的 finding，而不必依赖 endpoint 单跳
            if ep_node is not None:
                self.add_edge(fid, ep_node, "finding_on")
            if host_node is not None:
                self.add_edge(fid, host_node, "finding_on")
        elif target.startswith("/") and _is_meaningful_path(target):
            ep_node = self.upsert_node("endpoint", target, {"source": "finding"})
            if ep_node is not None:
                self.add_edge(fid, ep_node, "finding_on")
        elif target and _is_plausible_domain(target):
            host_node = self._add_domain(target, "finding",
                                         {"hosts": 0, "subdomains": 0, "endpoints": 0,
                                          "params": 0, "edges": 0})
            if host_node is not None:
                self.add_edge(fid, host_node, "finding_on")

        # 显式参数（param/params 字段）
        for pname in self._params_of(f):
            p_id = self.upsert_node("param", pname, {})
            if p_id is not None:
                self.add_edge(fid, p_id, "finding_on")
        return fid

    @staticmethod
    def _params_of(f: Dict[str, Any]) -> List[str]:
        out: List[str] = []
        for key in ("param", "params", "parameter", "parameters"):
            v = f.get(key)
            if v is None:
                continue
            if isinstance(v, (list, tuple)):
                out.extend(str(x).strip() for x in v if str(x).strip())
            elif isinstance(v, str):
                out.extend(p.strip() for p in v.replace(";", ",").split(",") if p.strip())
            else:
                s = str(v).strip()
                if s:
                    out.append(s)
        return list(dict.fromkeys(out))[:10]

    def ingest_findings(self, findings: Any) -> int:
        """批量入库。返回成功条数（脏条目跳过）。"""
        n = 0
        for f in (findings or []):
            if not isinstance(f, dict):
                continue  # 非 dict 脏条目直接跳过（不造 "finding" 占位节点）
            try:
                if self.ingest_finding(f) is not None:
                    n += 1
            except Exception:
                continue
        return n

    # -- 查询（LLM 工具用；全部有界） ------------------------------------------
    def _resolve_node(self, value: Any) -> Optional[Tuple[int, str, str]]:
        """按 value 精确解析节点 → (id, kind, value)；优先更具体的 kind。"""
        value = str(value or "").strip()
        if not value:
            return None
        try:
            row = self._conn.execute(
                "SELECT id, kind, value FROM nodes WHERE value = ? ORDER BY "
                "CASE kind WHEN 'endpoint' THEN 0 WHEN 'subdomain' THEN 1 "
                "WHEN 'host' THEN 2 WHEN 'param' THEN 3 WHEN 'finding' THEN 4 END "
                "LIMIT 1", (value,)).fetchone()
            if row is None:
                row = self._conn.execute(
                    "SELECT id, kind, value FROM nodes WHERE lower(value) = lower(?) "
                    "LIMIT 1", (value,)).fetchone()
            return (int(row[0]), str(row[1]), str(row[2])) if row else None
        except sqlite3.Error:
            return None

    def stats(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"nodes": {k: 0 for k in self.KINDS}, "edges": 0,
                              "db_path": self.db_path}
        try:
            for row in self._conn.execute("SELECT kind, COUNT(*) FROM nodes GROUP BY kind"):
                if row[0] in out["nodes"]:
                    out["nodes"][row[0]] = int(row[1])
            out["edges"] = self._edge_count()
            try:
                out["db_bytes"] = os.path.getsize(self.db_path)
            except OSError:
                pass
        except sqlite3.Error:
            pass
        return out

    def list_nodes(self, kind: Optional[str] = None, limit: int = 20) -> List[Dict[str, Any]]:
        try:
            limit = min(max(1, int(limit or 20)), 50)
        except (TypeError, ValueError):
            limit = 20
        kind = str(kind or "").strip().lower()
        out: List[Dict[str, Any]] = []
        try:
            if kind and kind in self.KINDS:
                rows = self._conn.execute(
                    "SELECT id, kind, value, attrs FROM nodes WHERE kind=? "
                    "ORDER BY id LIMIT ?", (kind, limit)).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT id, kind, value, attrs FROM nodes ORDER BY id LIMIT ?",
                    (limit,)).fetchall()
            for nid, nkind, value, attrs in rows:
                try:
                    a = json.loads(attrs or "{}")
                except (json.JSONDecodeError, TypeError):
                    a = {}
                out.append({"id": int(nid), "kind": str(nkind), "value": str(value),
                            "attrs": a if isinstance(a, dict) else {}})
        except sqlite3.Error:
            pass
        return out

    def neighbors(self, value: Any, limit: int = 40) -> List[Dict[str, str]]:
        """value 的直接邻居（入+出边）→ [{rel, direction, kind, value}]。"""
        node = self._resolve_node(value)
        if node is None:
            return []
        try:
            limit = min(max(1, int(limit or 40)), 100)
        except (TypeError, ValueError):
            limit = 40
        nid, nkind, nvalue = node
        out: List[Dict[str, str]] = []
        try:
            rows = self._conn.execute(
                """SELECT e.rel, e.src, e.dst, n.kind, n.value
                   FROM edges e JOIN nodes n ON n.id = e.dst
                   WHERE e.src = ?
                   UNION ALL
                   SELECT e.rel, e.src, e.dst, n.kind, n.value
                   FROM edges e JOIN nodes n ON n.id = e.src
                   WHERE e.dst = ?""", (nid, nid)).fetchall()
            for rel, src, dst, nkind, nvalue in rows:
                out.append({
                    "rel": str(rel),
                    "direction": "out" if int(src) == nid else "in",
                    "kind": str(nkind),
                    "value": str(nvalue),
                })
        except sqlite3.Error:
            pass
        # 去重保序 + 截断
        seen = set()
        uniq = []
        for item in out:
            key = (item["rel"], item["direction"], item["value"])
            if key in seen:
                continue
            seen.add(key)
            uniq.append(item)
        return uniq[:limit]

    def findings_about(self, value: Any, limit: int = 20) -> List[Dict[str, Any]]:
        """与 value（host/subdomain/endpoint/param）直接相连的 findings。"""
        node = self._resolve_node(value)
        if node is None:
            return []
        nid, nkind, nvalue = node
        out: List[Dict[str, Any]] = []
        try:
            limit = min(max(1, int(limit or 20)), 50)
            if nkind == "finding":
                rows = self._conn.execute(
                    "SELECT id, value, attrs FROM nodes WHERE id=?", (nid,)).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT n.id, n.value, n.attrs FROM nodes n
                       JOIN edges e ON (e.src = n.id AND e.dst = ? AND e.rel = 'finding_on')
                       WHERE n.kind = 'finding'
                       UNION
                       SELECT n.id, n.value, n.attrs FROM nodes n
                       JOIN edges e ON (e.dst = n.id AND e.src = ? AND e.rel = 'finding_on')
                       WHERE n.kind = 'finding'
                       ORDER BY n.id LIMIT ?""", (nid, nid, limit)).fetchall()
            for fid, fvalue, attrs in rows:
                try:
                    a = json.loads(attrs or "{}")
                except (json.JSONDecodeError, TypeError):
                    a = {}
                out.append({"id": int(fid), "value": str(fvalue),
                            "attrs": a if isinstance(a, dict) else {}})
        except sqlite3.Error:
            pass
        return out[:limit]

    def paths(self, a: Any, b: Any, max_depth: int = 3) -> List[str]:
        """a→b 最短路径（无向视图，BFS；只返回跳数 ≤ max_depth 的路径，节点访问上限 500）。无此路径 → []。
        BUG_REPORT [2]：旧实现先找真实最短路径再 `chain[:max_depth+1]` 截断——
        路径超限时返回首尾不连通的"断裂路径"（终点不是 b）。改为深度限制搜索：
        返回的每条路径必然完整（a→…→b）。
        """
        na, nb = self._resolve_node(a), self._resolve_node(b)
        if na is None or nb is None:
            return []
        try:
            max_depth = min(max(1, int(max_depth or 3)), 4)
        except (TypeError, ValueError):
            max_depth = 3
        start, goal = na[0], nb[0]
        if start == goal:
            return [na[2]]
        try:
            adj: Dict[int, List[int]] = {}
            for src, dst in self._conn.execute("SELECT src, dst FROM edges"):
                adj.setdefault(int(src), []).append(int(dst))
                adj.setdefault(int(dst), []).append(int(src))
        except sqlite3.Error:
            return []
        from collections import deque
        prev = {start: None}
        depth = {start: 0}
        q = deque([start])
        visited = 0
        while q and visited < 500:
            cur = q.popleft()
            visited += 1
            for nxt in adj.get(cur, ()):  # noqa: B020
                if nxt in prev:
                    continue
                prev[nxt] = cur
                depth[nxt] = depth[cur] + 1
                if nxt == goal:
                    chain = []
                    node_id = goal
                    while node_id is not None:
                        row = self._conn.execute(
                            "SELECT value FROM nodes WHERE id=?", (node_id,)).fetchone()
                        if row is None:
                            break
                        chain.append(str(row[0]))
                        node_id = prev[node_id]
                    chain.reverse()
                    # BFS 保证最短；深度 ≤ max_depth → 返回完整路径（a→…→b）
                    return chain
                if depth[nxt] >= max_depth:
                    continue  # 已达深度上限 → 不再向外扩展
                q.append(nxt)
        return []


# ---------------------------------------------------------------------------
# LLM 查询工具（ToolDefinition — orchestrator.register_tool 挂载，零改动）
# ---------------------------------------------------------------------------
_MAX_TOOL_JSON = 16000  # 工具返回 JSON 软上限（超限截断列表 + 提示收敛查询）


def _parse_tool_args(args_string: Any) -> Any:
    try:
        if isinstance(args_string, str):
            return json.loads(args_string)
        if isinstance(args_string, (dict, list)):
            return args_string
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return None


def make_attack_graph_tool(graph: Optional[GraphStore] = None) -> Any:
    """构造 attack_graph 查询工具（参照 kb_search.make_consult_kb_tool 的约定）。

    参数: {"action": "stats" | "list" | "neighbors" | "findings" | "paths", ...}
      stats:     图规模概览（节点/边计数）
      list:      {"kind": "host|subdomain|endpoint|param|finding", "limit": <=50}
      neighbors: {"value": "api.example.com", "limit": <=100}
      findings:  {"value": "example.com", "limit": <=50}
      paths:     {"a": "...", "b": "...", "max_depth": 1-4}
    输出: JSON（ok + 数据）；脏参数 → ok=false + error（不抛异常）。
    """
    graph = graph or GraphStore(":memory:")

    def execute(args_string: str):
        obj = _parse_tool_args(args_string)
        if not isinstance(obj, dict):
            return json.dumps({"ok": False, "error": "args must be a JSON object",
                               "hint": '{"action": "stats"}'}, ensure_ascii=False), "invalid_args"
        action = str(obj.get("action") or "").strip().lower()
        try:
            if action == "stats":
                payload: Dict[str, Any] = {"ok": True, "action": action, **graph.stats()}
            elif action == "list":
                payload = {"ok": True, "action": action,
                           "nodes": graph.list_nodes(obj.get("kind"),
                                                     int(obj.get("limit") or 20))}
            elif action == "neighbors":
                value = str(obj.get("value") or "").strip()
                if not value:
                    return json.dumps({"ok": False, "error": "value is required"},
                                      ensure_ascii=False), "invalid_args"
                payload = {"ok": True, "action": action, "value": value,
                           "neighbors": graph.neighbors(value, int(obj.get("limit") or 40))}
            elif action == "findings":
                value = str(obj.get("value") or "").strip()
                if not value:
                    return json.dumps({"ok": False, "error": "value is required"},
                                      ensure_ascii=False), "invalid_args"
                payload = {"ok": True, "action": action, "value": value,
                           "findings": graph.findings_about(value, int(obj.get("limit") or 20))}
            elif action == "paths":
                a = str(obj.get("a") or "").strip()
                b = str(obj.get("b") or "").strip()
                if not a or not b:
                    return json.dumps({"ok": False, "error": "a and b are required"},
                                      ensure_ascii=False), "invalid_args"
                payload = {"ok": True, "action": action,
                           "paths": graph.paths(a, b, int(obj.get("max_depth") or 3))}
            else:
                return json.dumps({"ok": False, "error": f"unknown action: {action!r}",
                                   "hint": "action ∈ stats|list|neighbors|findings|paths"},
                                  ensure_ascii=False), "invalid_args"
            text = json.dumps(payload, ensure_ascii=False)
            if len(text) > _MAX_TOOL_JSON:
                # 软上限兜底：列表截到前 5 条 + truncated 标记（提示模型收敛查询）
                for key in ("nodes", "neighbors", "findings"):
                    if isinstance(payload.get(key), list) and len(payload[key]) > 5:
                        payload[key] = payload[key][:5]
                        payload["truncated"] = True
                        text = json.dumps(payload, ensure_ascii=False)
                        break
            return text, None
        except Exception as exc:
            return json.dumps({"ok": False,
                               "error": f"{type(exc).__name__}: {str(exc)[:120]}"},
                              ensure_ascii=False), "query_failed"

    from scanners.swarm_orchestrator import ToolDefinition
    return ToolDefinition(
        name="attack_graph",
        description=(
            "Query the campaign attack-surface graph (hosts/subdomains/endpoints/"
            "params/findings accumulated from tool outputs). Actions: "
            "stats (graph size), list (nodes by kind), neighbors (direct relations "
            "of a host/endpoint/param), findings (findings touching a node), "
            "paths (shortest link between two nodes). Use to answer questions like "
            "'which findings hit this host?' or 'which endpoints does this finding "
            "touch?' instead of re-scanning."),
        parameters={
            "type": "object",
            "properties": {
                "action": {"type": "string",
                           "enum": ["stats", "list", "neighbors", "findings", "paths"]},
                "kind": {"type": "string",
                         "enum": ["host", "subdomain", "endpoint", "param", "finding"],
                         "description": "list 用：节点类型（缺省=全部）"},
                "value": {"type": "string",
                          "description": "neighbors/findings 用：节点值（域名/路径/参数名）"},
                "a": {"type": "string", "description": "paths 用：起点"},
                "b": {"type": "string", "description": "paths 用：终点"},
                "limit": {"type": "integer", "description": "结果条数上限（默认 20）"},
                "max_depth": {"type": "integer",
                              "description": "paths 用：最大深度（1-4，默认 3）"},
            },
            "required": ["action"],
        },
        execute=execute,
    )


# ---------------------------------------------------------------------------
# execute 包装 — 工具输出持续并入图谱（入口层模式，装在最内侧看原文）
# ---------------------------------------------------------------------------
def install_graph_ingest(orch, graph: GraphStore) -> int:
    """包装 orch.tools 中全部已注册工具的 execute：每次返回后 ingest_text。

    - 包装链位置：装在 anti_loop 之后、untrusted 边界【之前】（链由里向外
      anti_loop → ingest → untrusted → 审批门 → offload → recorder），
      看到的是目标原始输出（未加 nonce 边界）
    - ingest 纯观测：任何异常静默，返回原 (res, err) 不变（不改变工具语义）
    - 返回被包装的工具数（0 = 无工具可包，静默）
    """
    n = 0
    for name, tool in list(getattr(orch, "tools", {}).items()):
        orig = getattr(tool, "execute", None)
        if orig is None:
            continue

        def wrap(args, _orig=orig, _graph=graph, _name=name):
            res, err = _orig(args)
            try:
                text = res if isinstance(res, str) else (str(res) if res is not None else "")
                if text.strip():
                    _graph.ingest_text(_name, text)
            except Exception:
                pass  # 图谱异常静默降级，绝不阻断核心循环
            return res, err

        tool.execute = wrap
        n += 1
    return n


# ---------------------------------------------------------------------------
# 报告段（收尾：图谱概览 + findings 关联写进报告；中文，与 triage 段同款）
# ---------------------------------------------------------------------------
def export_section(graph: GraphStore, max_findings: int = 10) -> str:
    """Markdown 报告段；空图（无 finding 节点）→ 空串。"""
    try:
        st = graph.stats()
        nodes = st.get("nodes") or {}
        findings = graph.list_nodes("finding", limit=max_findings)
        if not findings:
            return ""
        lines = [
            "## 攻击面图谱（attack surface graph）",
            "",
            f"> 节点: host {nodes.get('host', 0)} | subdomain {nodes.get('subdomain', 0)} "
            f"| endpoint {nodes.get('endpoint', 0)} | param {nodes.get('param', 0)} "
            f"| finding {nodes.get('finding', 0)}；边 {st.get('edges', 0)}；"
            f"DB `{os.path.basename(str(st.get('db_path') or ''))}`",
            "",
            "| finding | 关联攻击面（直接邻居） |",
            "|---|---|",
        ]
        for f in findings:
            title = str(f.get("value") or "").replace("|", "\\|").replace("\n", " ")
            try:
                nbrs = graph.neighbors(f.get("value"), limit=3)
            except Exception:
                nbrs = []
            related = " / ".join(f"[{n.get('kind')}] {n.get('value')}" for n in nbrs[:3]) or "—"
            lines.append(f"| {title} | {related} |")
        return "\n".join(lines)
    except Exception:
        return ""


if __name__ == "__main__":
    # 自测：域解析 / 抽取 / 幂等 / 上限 / finding 入图 / 查询 / 工具契约 / ingest 包装 / 报告段
    # 直接以脚本运行时 sys.path[0] 是 scanners/，补上项目根（ToolDefinition 走
    # scanners. 包导入）；从 run_adaptive 调用时根已在 path，此步无副作用。
    import sys as _sys
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    import tempfile

    def _assert(cond, msg):
        if not cond:
            raise AssertionError(msg)

    _d = tempfile.mkdtemp()
    _db = os.path.join(_d, "g.sqlite")
    with GraphStore(_db, max_nodes=200, max_edges=800) as g:
        # 1) 域解析
        _assert(_registered_domain("api.example.com") == "example.com", "registered domain")
        _assert(_registered_domain("x.y.co.uk") == "y.co.uk", "two-part TLD")
        _assert(_is_plausible_domain("example.com") and not _is_plausible_domain("localhost"),
                "plausible domain")
        _assert(_is_valid_ip("10.0.0.1") and not _is_valid_ip("999.1.1.1"), "valid ip")
        _assert(not _is_meaningful_path("/favicon.ico") and _is_meaningful_path("/api/v1/users"),
                "meaningful path")

        # 2) ingest_text：URL 锚定 + 裸 FQDN + IP + query 参数
        s = g.ingest_text("recon", (
            "GET http://api.example.com/v1/users?id=3&role=admin -> 200\n"
            "subdomains: www.example.com, mail.example.com\n"
            "internal: 10.0.0.15\n"
            "asset noise: /favicon.ico /script.png\n"
        ))
        _assert(s["hosts"] >= 1 and s["subdomains"] >= 2, f"hosts/subs: {s}")
        _assert(s["endpoints"] >= 1 and s["params"] >= 2, f"eps/params: {s}")

        # 3) 幂等：重复 ingest 不翻倍
        st1 = g.stats()
        g.ingest_text("recon", "http://api.example.com/v1/users?id=3")
        st2 = g.stats()
        _assert(st2["nodes"]["host"] == st1["nodes"]["host"], "host 幂等")
        _assert(st2["nodes"]["subdomain"] == st1["nodes"]["subdomain"], "subdomain 幂等")
        _assert(st2["nodes"]["endpoint"] == st1["nodes"]["endpoint"], "endpoint 幂等")
        _assert(st2["edges"] == st1["edges"], "edge 幂等")

        # 4) findings 入图 + 查询（脏条目跳过不崩）
        g.ingest_findings([
            {"title": "SQL Injection", "url": "http://api.example.com/v1/users",
             "severity": "high", "confidence": 8, "type": "sqli"},
            {"title": "Info Disclosure", "target": "www.example.com", "severity": "info"},
            "junk-not-dict",
        ])
        _assert(g.stats()["nodes"]["finding"] == 2, "finding 节点数")
        fa = g.findings_about("api.example.com")
        _assert(any("SQL" in f["value"] for f in fa), f"findings_about: {fa}")
        nb = g.neighbors("example.com")
        _assert(any(n["kind"] in ("subdomain", "endpoint") for n in nb), f"neighbors: {nb}")
        p = g.paths("id", "example.com")
        _assert(p == ["id", "/v1/users", "api.example.com", "example.com"], f"paths: {p}")
        _assert(g.paths("nonexistent-xyz", "example.com") == [], "无路径 → []")

        # 5) 节点上限封顶
        with GraphStore(os.path.join(_d, "small.sqlite"), max_nodes=10, max_edges=20) as gs:
            for i in range(30):
                gs.ingest_text("t", f"http://h{i}.example.com/p{i}?q={i}")
            _assert(gs._node_count() <= 10, f"max_nodes 封顶: {gs._node_count()}")

        # 6) 工具契约
        tool = make_attack_graph_tool(g)
        r, e = tool.execute(json.dumps({"action": "stats"}))
        _assert(e is None and json.loads(r)["ok"] is True, f"stats: {r} {e}")
        r2, e2 = tool.execute(json.dumps({"action": "findings", "value": "api.example.com"}))
        _assert(e2 is None and json.loads(r2)["findings"], f"findings: {r2} {e2}")
        r3, e3 = tool.execute("not-json")
        _assert(e3 == "invalid_args", f"bad args: {r3} {e3}")
        r4, e4 = tool.execute(json.dumps({"action": "bogus"}))
        _assert(e4 == "invalid_args" and "unknown action" in r4, f"bogus: {r4} {e4}")
        _assert(tool.name == "attack_graph" and "action" in tool.parameters["required"],
                "工具元数据")

        # 7) install_graph_ingest（stub orch；新 subdomain 入库 + 原返回不变）
        class _T:
            def __init__(self, out):
                self.out = out
            def execute(self, args):
                return self.out, None

        class _Orch:
            def __init__(self):
                self.tools = {}

        o = _Orch()
        o.tools["probe"] = _T("hit http://a.example.com/x?y=1\n")
        o.tools["note"] = _T("no domains here")
        n_wrap = install_graph_ingest(o, g)
        _assert(n_wrap == 2, f"包装数: {n_wrap}")
        res, err = o.tools["probe"].execute("{}")
        _assert(res.startswith("hit http://a.example.com") and err is None, "原返回不变")
        subs = [n["value"] for n in g.list_nodes("subdomain", limit=50)]
        _assert("a.example.com" in subs, f"ingest 入库: {subs}")

        # 8) 报告段
        sec = export_section(g)
        _assert("## 攻击面图谱" in sec and "SQL Injection" in sec, sec[:200])
        with GraphStore(os.path.join(_d, "empty.sqlite")) as ge:
            _assert(export_section(ge) == "", "空图 → 空段")

    print("self-test OK")
