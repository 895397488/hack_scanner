#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
vuln_deepdive.py — 逐漏洞类深挖 + 置信度纪律（4 项目升级清单 #3）
=====================================================================

借鉴 vulnhuntr vulnhuntr/{__main__.py, prompts.py}:
    1. 两段式分析：初扫（classify）只出候选 → 本模块对每条 finding
       按漏洞类单独深挖，prompt 带该类【专注点 + 真实 bypass 样例库】
       （data/vuln_bypasses.json，样例逐字来自 vulnhuntr）。
    2. 置信度纪律（vulnhuntr GUIDELINES 同款）：
       - 0-10 分，必须给依据（scratchpad 先推理后结论）；
       - **PoC 不从远程输入发起 → 置信度必须 ≤6**（prompt 强制）。
    3. scratchpad 字段：强制先推理后结论，防"先结论后找理由"。

本模块契约（与入口层纪律一致）:
    - 纯标准库、无网络；LLM 由调用方注入（``llm_chat``）
    - ``llm_chat(system, user) -> Optional[str]``：抛异常/返回 None →
      该条 finding 原样保留，绝不外溢异常
    - 深挖有界：``score_findings(cap=5)`` 默认只深挖前 5 条（token 预算）
    - 挂点：run_adaptive.py 5c（报告自检）之后、ATT&CK 映射之前；
      ``advanced.deepdive.enabled`` 默认开

llm_chat 说明：
    run_adaptive 的 ``llm_invoke(system, messages, tools, max_tokens, temperature)``
    不是本模块直接消费的签名——run_adaptive 用 ``make_llm_chat(llm_invoke)``
    适配成 (system, user) -> str。桩 LLM（验收脚本）直接提供 (system, user) 即可。
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

__all__ = [
    "CONFIDENCE_DISCIPLINE",
    "load_bypass_library",
    "normalize_vuln_type",
    "build_deepdive_prompt",
    "deep_dive",
    "score_findings",
    "render_confidence_section",
    "make_llm_chat",
]

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_LIB_PATH = os.path.join(_PROJECT_ROOT, "data", "vuln_bypasses.json")

CONFIDENCE_DISCIPLINE = (
    "Confidence discipline (0-10):"
    " justify every score. "
    "If your proof of concept (PoC) does NOT start with remote user input via "
    "remote networking calls (HTTP/API/RPC), the confidence score MUST be 6 or "
    "below. Never report local-only or CLI-argument-only issues above 6."
)

# 规范类名（bypass 库键）
_TYPE_KEYS = ("LFI", "RCE", "SSRF", "AFO", "SQLI", "XSS", "IDOR")

# finding 里各种叫法 → 规范类（子串匹配，大小写不敏感）
_TYPE_ALIASES = {
    "LFI": ("lfi", "file inclusion", "path traversal", "local file"),
    "RCE": ("rce", "remote code exec", "code execution", "command injection",
            "cmd injection", "deserialization", "ssti", "template injection", "eval"),
    "SSRF": ("ssrf", "server-side request"),
    "AFO": ("afo", "file overwrite", "upload", "arbitrary file"),
    "SQLI": ("sqli", "sql injection", "sql-injection", "nosql"),
    "XSS": ("xss", "cross-site scripting", "cross site scripting"),
    "IDOR": ("idor", "insecure direct object", "broken access control", "baca"),
}


def normalize_vuln_type(value: Any) -> Optional[str]:
    """把 finding 的类型字段（任意叫法）归一到 bypass 库键；不匹配 → None。"""
    if value is None:
        return None
    s = str(value).strip().lower()
    if not s:
        return None
    s = re.sub(r"[\s\-_/]+", " ", s)
    for key, aliases in _TYPE_ALIASES.items():
        for a in aliases:
            if a in s:
                return key
    return None


def load_bypass_library(path: Optional[str] = None) -> Dict[str, Any]:
    """读 data/vuln_bypasses.json；缺失/损坏 → 内置最小 GENERIC 库（不抛异常）。"""
    p = path or DEFAULT_LIB_PATH
    try:
        with open(p, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        types = data.get("types") or {}
        if types:
            return data
    except (OSError, json.JSONDecodeError, ValueError, TypeError):
        pass
    return {
        "version": 0,
        "confidence_discipline": CONFIDENCE_DISCIPLINE,
        "types": {"GENERIC": {
            "label": "Generic", "focus": [], "bypasses": []}},
    }


# ---------------------------------------------------------------------------
# Prompt 构造
# ---------------------------------------------------------------------------
def build_deepdive_prompt(finding: Dict[str, Any], vuln_type: str,
                          library: Dict[str, Any]) -> Tuple[str, str]:
    """构造单类深挖的 (system, user) prompt。

    结构（vulnhuntr 两段式的深挖段）:
        system: 角色 + 置信度纪律 + JSON 输出 schema
        user:   finding 原文 + 该类专注点 + bypass 样例 + 输出要求
    """
    tinfo = (library.get("types") or {}).get(vuln_type) or (
        (library.get("types") or {}).get("GENERIC") or {})
    focus = tinfo.get("focus") or []
    bypasses = tinfo.get("bypasses") or []

    system = (
        "You are a world-class application security researcher performing a "
        "single-class deep-dive on ONE candidate vulnerability from an "
        "earlier triage scan. Be rigorous: verify the claim, trace the exact "
        "data path, and only score confidence for what you can defend.\n"
        f"{CONFIDENCE_DISCIPLINE}\n"
        "Output a SINGLE well-formed JSON object (no prose outside the JSON) "
        "with exactly these fields:\n"
        "  scratchpad : string — step-by-step reasoning BEFORE conclusions "
        "(mandatory, do the analysis here first);\n"
        "  analysis   : string — final verdict: is the claim valid? data "
        "path entry→sink; which controls were bypassed or are missing;\n"
        "  poc        : string — concrete PoC (request/payload) that starts "
        "from remote input, or 'None' if no defensible PoC exists;\n"
        "  confidence : integer 0-10 (must be <=6 if PoC is not "
        "remote-input-initiated; must be <=2 if poc is 'None' or unverified). "
        "Use 0 if the claim is refuted."
    )

    f = dict(finding or {})
    finding_text = json.dumps(f, ensure_ascii=False, default=str, indent=1)[:6000]

    parts = [
        "Candidate finding (from initial scan):",
        "<finding>", finding_text, "</finding>",
        "",
        f"Deep-dive target class: {tinfo.get('label') or vuln_type}",
    ]
    if focus:
        parts.append("")
        parts.append("Class-specific focus areas:")
        parts.extend(f"- {x}" for x in focus)
    if bypasses:
        parts.append("")
        parts.append("Known bypass techniques for this class (real-world samples; "
                     "adapt, do not copy blindly):")
        parts.extend(f"  {i + 1}. {b}" for i, b in enumerate(bypasses))
    parts += [
        "",
        "If the finding text is insufficient to verify the claim, say so in "
        "scratchpad and set confidence accordingly (do not inflate).",
        "Respond with the JSON object only.",
    ]
    return system, "\n".join(parts)


# ---------------------------------------------------------------------------
# 深挖 + 有界打分
# ---------------------------------------------------------------------------
def _parse_confidence(value: Any) -> Optional[int]:
    """宽松解析 0-10 整数置信度；无法解析 → None。"""
    try:
        if isinstance(value, str):
            m = re.search(r"\d+", value)
            value = int(m.group(0)) if m else None
        v = int(value)
        return max(0, min(10, v))
    except (TypeError, ValueError):
        return None


def _extract_json(text: str) -> Optional[Dict[str, Any]]:
    """从 LLM 回复里救出一个 JSON 对象（容忍前后散文/代码围栏）。"""
    if not isinstance(text, str):
        return None
    t = text.strip()
    # 直接解析
    try:
        d = json.loads(t)
        return d if isinstance(d, dict) else None
    except (json.JSONDecodeError, ValueError):
        pass
    # 代码围栏
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", t, re.DOTALL)
    if m:
        try:
            d = json.loads(m.group(1))
            return d if isinstance(d, dict) else None
        except (json.JSONDecodeError, ValueError):
            pass
    # 从 { 位置起解析 JSON 对象。
    # BUG_REPORT [19]：旧手工 depth 配平不识别字符串边界——字符串内含未配平
    # `}`（{"a": "payload} 注入", "b": 2}）→ 切片提前终止、解析失败 → 整条
    # 返回 None；或早期切片恰好可解析 → 静默截断丢字段。改用
    # json.JSONDecoder().raw_decode（真 JSON 解析器，原生识别字符串/转义），
    # 从每个 { 位置依次尝试，取第一个能解析出的对象。
    decoder = json.JSONDecoder()
    i = t.find("{")
    while i >= 0:
        try:
            d, _end = decoder.raw_decode(t, i)
            if isinstance(d, dict):
                return d
        except (json.JSONDecodeError, ValueError):
            pass
        i = t.find("{", i + 1)
    return None


def deep_dive(llm_chat: Callable[[str, str], Optional[str]],
              finding: Dict[str, Any], vuln_type: str,
              library: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """对单条 finding 做单类深挖。

    返回 {scratchpad, analysis, poc, confidence, vuln_type, ok}；
    LLM 不可用/解析失败 → None（调用方保留原 finding）。
    """
    lib = library or load_bypass_library()
    system, user = build_deepdive_prompt(finding, vuln_type, lib)
    try:
        raw = llm_chat(system, user)
    except Exception:
        return None
    if not raw:
        return None
    parsed = _extract_json(raw)
    if not parsed:
        return None
    conf = _parse_confidence(parsed.get("confidence"))
    poc = parsed.get("poc")
    if poc in (None, "None", "none", ""):
        poc = None
        # PoC 缺失 → 置信度纪律封顶 2（无 PoC 不得高置信）
        if conf is not None and conf > 2:
            conf = 2
    return {
        "scratchpad": str(parsed.get("scratchpad") or "")[:4000],
        "analysis": str(parsed.get("analysis") or "")[:4000],
        "poc": poc,
        "confidence": conf,
        "vuln_type": vuln_type,
        "ok": True,
    }


def score_findings(llm_chat: Callable[[str, str], Optional[str]],
                   findings: List[Dict[str, Any]], cap: int = 5,
                   library: Optional[Dict[str, Any]] = None) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """初筛→逐条深挖（有界）→ 写回 confidence + deepdive 块。

    - 无类型字段的 finding：跳过深挖（无法选类）
    - 类型不匹配 7 类 → 用 GENERIC 库深挖（仍产出置信度）
    - 任何单条失败 → 该条原样保留，其余继续
    - 返回 (findings 原列表就地更新, stats)
    """
    lib = library or load_bypass_library()
    stats = {"attempted": 0, "scored": 0, "failed": 0, "skipped": 0}
    if not isinstance(findings, list) or not findings or not isinstance(cap, int) or cap <= 0:
        return findings, stats

    for f in findings[:cap]:
        if not isinstance(f, dict):
            stats["skipped"] += 1
            continue
        vt = normalize_vuln_type(
            f.get("type") or f.get("vuln_type") or f.get("vulnerability_type")
            or f.get("category"))
        stats["attempted"] += 1
        dd = deep_dive(llm_chat, f, vt or "GENERIC", lib)
        if dd is None:
            stats["failed"] += 1
            continue
        f["deepdive"] = dd
        if dd["confidence"] is not None:
            f["confidence"] = dd["confidence"]
        stats["scored"] += 1
    return findings, stats


# ---------------------------------------------------------------------------
# 报告段
# ---------------------------------------------------------------------------
def render_confidence_section(findings: List[Dict[str, Any]]) -> str:
    """生成"置信度评分"报告段（每条：类型/置信度/依据摘要）。"""
    scored = [f for f in (findings or [])
              if isinstance(f, dict) and f.get("deepdive")]
    if not scored:
        return ""
    lines = ["## 置信度评分（逐类深挖）", ""]
    lines.append(f"| # | 漏洞类型 | 置信度 (0-10) | 依据摘要 |")
    lines.append(f"|---|---|---|---|")
    for i, f in enumerate(scored, 1):
        dd = f.get("deepdive") or {}
        title = str(f.get("title") or f.get("vulnerability") or f.get("type") or f.get("name") or "(未命名)")[:60]
        vt = dd.get("vuln_type") or "?"
        conf = dd.get("confidence")
        conf_s = str(conf) if conf is not None else "未评"
        analysis = re.sub(r"\s+", " ", str(dd.get("analysis") or dd.get("scratchpad") or ""))[:140]
        lines.append(f"| {i} | {title} [{vt}] | {conf_s} | {analysis or '—'} |")
    lines.append("")
    lines.append("纪律：PoC 非远程输入发起 → 置信度 ≤6；无 PoC/未验证 → ≤2。")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# run_adaptive 适配：llm_invoke → llm_chat
# ---------------------------------------------------------------------------
def make_llm_chat(llm_invoke: Callable[..., Any]) -> Callable[[str, str], Optional[str]]:
    """把 run_adaptive 的 llm_invoke(system, messages, tools, max_tokens, temperature)
    适配成 deep_dive 消费的 llm_chat(system, user) -> Optional[str]。
    任何异常 → None（深挖降级，不阻断收尾）。
    """
    def chat(system: str, user: str) -> Optional[str]:
        try:
            resp = llm_invoke(system, [{"role": "user", "content": user}], [],
                              max_tokens=2048, temperature=0.1)
        except TypeError:
            # 某些包装器签名不同 → 位置参数兜底
            try:
                resp = llm_invoke(system, [{"role": "user", "content": user}], [])
            except Exception:
                return None
        except Exception:
            return None
        if isinstance(resp, dict):
            return resp.get("content")
        if isinstance(resp, str):
            return resp
        return None

    return chat


# ---------------------------------------------------------------------------
# CLI 自测（桩 LLM，无网络）
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    def stub_chat(system: str, user: str) -> str:
        assert "Confidence discipline" in system
        return json.dumps({
            "scratchpad": "step1: entry /api/read?file= ... step2: no realpath guard",
            "analysis": "Valid LFI: user-controlled path reaches open() unsanitized.",
            "poc": "GET /api/read?file=../../../etc/passwd",
            "confidence": 8,
        })

    lib = load_bypass_library()
    assert "LFI" in lib.get("types", {}), "bypass 库缺 LFI"
    f = {"title": "LFI in /api/read", "type": "Local File Inclusion",
         "evidence": "open(params['file'])"}
    out, stats = score_findings(stub_chat, [f], cap=5, library=lib)
    assert out[0]["confidence"] == 8 and out[0]["deepdive"]["ok"], stats
    sec = render_confidence_section(out)
    assert "置信度评分" in sec and "8" in sec
    print(f"[OK ] deep_dive + score_findings + 报告段 | stats={stats}")

    # 失败降级：llm_chat 抛异常 → finding 原样、无异常外溢
    def boom(system: str, user: str) -> str:
        raise RuntimeError("llm down")

    f2 = {"title": "SQLI", "type": "sqli"}
    out2, stats2 = score_findings(boom, [f2], cap=5, library=lib)
    assert "deepdive" not in out2[0] and stats2["failed"] == 1, stats2
    print(f"[OK ] 桩 LLM 异常 → finding 原样、无外溢 | stats={stats2}")

    # 置信度纪律：poc=None → conf 被压到 ≤2
    def weak(system: str, user: str) -> str:
        return json.dumps({"scratchpad": "no path", "analysis": "unverified",
                           "poc": "None", "confidence": 9})
    f3 = {"title": "maybe", "type": "rce"}
    out3, _ = score_findings(weak, [f3], cap=5, library=lib)
    assert out3[0]["deepdive"]["confidence"] == 2, out3[0]
    print("[OK ] poc 缺失 → 置信度封顶 2")
    sys.exit(0)
