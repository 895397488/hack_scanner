# from-source-of: Pentest-Swarm-AI (internal/agent/report/roi/)
# ROI 计算引擎 — 评估扫描投入产出比
"""
ROI（投资回报率）计算器。
核心算法源自 Pentest-Swarm-AI 的 roi/roi.go：

- 对比预期赏金（bounty）与 LLM/token 花费
- 三色灯：绿(>10x) / 黄(2x-10x) / 红(<2x)
- 低估值策略：用 bounty 的低端计算 verdict，避免过度乐观
"""

import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# 数据类型定义 (对应 roi.Result + Verdict)
# ---------------------------------------------------------------------------

class Verdict:
    """ROI 三色灯评估结果"""
    GREEN = "green"   # ratio > 10x — 高回报，强烈推荐提交
    YELLOW = "yellow"  # ratio 2x-10x — 中等回报
    RED = "red"       # ratio < 2x — 低回报，谨慎运行


@dataclass
class ROIResult:
    """ROI 计算结果"""
    spend_usd: float            # 花费（美元）
    bounty_low_usd: int         # 预估最低赏金（美元）
    bounty_high_usd: int        # 预估最高赏金（美元）
    ratio_low: float = 0.0      # 最低回报率 (bounty_low / spend)
    ratio_high: float = 0.0     # 最高回报率 (bounty_high / spend)
    verdict: str = Verdict.RED  # 评估等级

    def footer_markdown(self) -> str:
        """生成报告底部的 ROI 行"""
        icon_map = {
            Verdict.GREEN: "\U0001F7E2",  # green circle
            Verdict.YELLOW: "\U0001F7E1", # yellow circle
            Verdict.RED: "\U0001F534",    # red circle
        }
        icon = icon_map.get(self.verdict, "")
        return (
            f"**Campaign ROI:** {icon} estimated bounty "
            f"${self.bounty_low_usd}-${self.bounty_high_usd}  ·  "
            f"LLM spend ${self.spend_usd:.2f}  ·  "
            f"ratio {self.ratio_low:.1f}x-{self.ratio_high:.1f}x"
        )


# ---------------------------------------------------------------------------
# ROI 计算引擎 (对应 roi.go Calculate + Footer)
# ---------------------------------------------------------------------------

class ROICalculator:
    """
    ROI（投资回报率）计算引擎。

    计算逻辑：
        1. 从 bounty 估算器获取每条发现的赏金范围
        2. 汇总所有发现的赏金范围（low, high）
        3. 与 LLM/token 花费对比，计算回报率
        4. 用低端的回报率决定 verdict（保守策略）

    Verdict 判定规则（对应 Go roi.go Calculate()）:
        - ratio_low > 10x : GREEN — 高回报
        - ratio_low >= 2x : YELLOW — 中等回报
        - ratio_low <  2x : RED   — 低回报
    """

    def __init__(self):
        self._bounty_lookup_cache: Dict[str, dict] = {}

    def calculate(self, scan_hours: float, bounty_estimated: Optional[dict] = None,
                  tools_cost: float = 0.0) -> ROIResult:
        """
        计算扫描的 ROI。

        Args:
            scan_hours:     扫描耗时（小时）
            bounty_estimated: 赏金估算数据，格式：
                {
                    "low_usd": int,
                    "high_usd": int,
                    "source": str
                }
                如果为 None，则从发现的严重等级自动估算
            tools_cost:     工具成本（美元）

        Returns:
            ROIResult 对象
        """
        # Step 1: 获取赏金范围
        if bounty_estimated and isinstance(bounty_estimated, dict):
            low_usd = bounty_estimated.get("low_usd", 0)
            high_usd = bounty_estimated.get("high_usd", 0)
        else:
            # 从严重等级分布自动估算（使用 swarm_bounty_estimator）
            low_usd, high_usd = self._estimate_from_severity_distribution()

        # Step 2: 计算总花费
        total_spend = scan_hours * 2.0 + tools_cost  # 假设 $2/小时 LLM 成本

        # Step 3: 计算回报率
        ratio_low = float(low_usd) / total_spend if total_spend > 0 else 0.0
        ratio_high = float(high_usd) / total_spend if total_spend > 0 else 0.0

        # Step 4: 判定 — 使用低端回报率（保守）
        verdict = Verdict.RED
        if ratio_low > 10:
            verdict = Verdict.GREEN
        elif ratio_low >= 2:
            verdict = Verdict.YELLOW

        return ROIResult(
            spend_usd=total_spend,
            bounty_low_usd=low_usd,
            bounty_high_usd=high_usd,
            ratio_low=round(ratio_low, 1),
            ratio_high=round(ratio_high, 1),
            verdict=verdict,
        )

    def calculate_per_finding(self, findings_severity: List[str],
                              scan_hours: float = 0.0,
                              tools_cost: float = 0.0) -> dict:
        """
        按单条发现计算 ROI。

        Args:
            findings_severity: 每条发现的严重等级列表
            scan_hours:       扫描耗时
            tools_cost:       工具成本

        Returns:
            包含总览和每条发现详情的 ROI 字典
        """
        # 从 severity 估算赏金（使用 swarm_bounty_estimator）
        from scanners.swarm_bounty_estimator import PUBLIC_MARKET, estimate_total_bounty

        low_usd, high_usd = estimate_total_bounty(findings_severity)

        total_spend = scan_hours * 2.0 + tools_cost
        ratio_low = float(low_usd) / total_spend if total_spend > 0 else 0.0
        ratio_high = float(high_usd) / total_spend if total_spend > 0 else 0.0

        # 每条发现的单独估算
        per_finding = []
        for sev in findings_severity:
            bounty = PUBLIC_MARKET.get(sev, {"low_usd": 0, "high_usd": 50})
            if isinstance(bounty, dict):
                per_finding.append({
                    "severity": sev,
                    "estimated_low": bounty.get("low_usd", 0),
                    "estimated_high": bounty.get("high_usd", 50),
                    "expected_ratio_low": round(bounty.get("low_usd", 0) / max(total_spend, 0.01), 1),
                })

        verdict = Verdict.RED
        if ratio_low > 10:
            verdict = Verdict.GREEN
        elif ratio_low >= 2:
            verdict = Verdict.YELLOW

        return {
            "total": {
                "spend_usd": round(total_spend, 2),
                "bounty_low_usd": low_usd,
                "bounty_high_usd": high_usd,
                "ratio_low": round(ratio_low, 1),
                "ratio_high": round(ratio_high, 1),
                "verdict": verdict,
            },
            "per_finding": per_finding,
        }

    @staticmethod
    def _estimate_from_severity_distribution() -> tuple:
        """从严重等级分布估算赏金（使用 swarm_bounty_estimator）"""
        from scanners.swarm_bounty_estimator import PUBLIC_MARKET

        # 假设一个典型的发现分布
        distribution = {
            "critical": 0,   # 实际扫描时传入
            "high": 0,
            "medium": 0,
            "low": 0,
            "informational": 0,
        }

        low = 0
        high = 0
        for sev, count in distribution.items():
            b = PUBLIC_MARKET.get(sev, {"low_usd": 0, "high_usd": 50})
            if isinstance(b, dict):
                low += b.get("low_usd", 0) * count
                high += b.get("high_usd", 50) * count

        return low, high


# ---------------------------------------------------------------------------
# 便捷函数
# ---------------------------------------------------------------------------

def calculate_roi(scan_hours: float, bounty_estimated: Optional[dict] = None,
                  tools_cost: float = 0.0) -> ROIResult:
    """
    快速计算 ROI（便捷入口）。

    Args:
        scan_hours:     扫描耗时（小时）
        bounty_estimated: 赏金估算 {low_usd, high_usd}
        tools_cost:     工具成本

    Returns:
        ROIResult 对象
    """
    calc = ROICalculator()
    return calc.calculate(scan_hours, bounty_estimated, tools_cost)


def format_roi_footer(roi_result: ROIResult) -> str:
    """
    将 ROI 结果格式化为报告底部的 markdown 行。

    Args:
        roi_result: ROIResult 对象

    Returns:
        Markdown 格式的 ROI 脚注
    """
    return roi_result.footer_markdown()


def generate_roi_analysis(findings_severity: List[str], scan_hours: float = 0.0,
                          tools_cost: float = 0.0) -> dict:
    """
    生成完整的 ROI 分析报告。

    Args:
        findings_severity: 每条发现的严重等级列表
        scan_hours:       扫描耗时（小时）
        tools_cost:       工具成本（美元）

    Returns:
        {
            "total_spend": float,
            "estimated_bounty_low": int,
            "estimated_bounty_high": int,
            "ratio_low": float,
            "ratio_high": float,
            "verdict": str,
            "recommendation": str,
            "breakdown": {sev: count} 严重等级分布,
        }
    """
    from scanners.swarm_bounty_estimator import estimate_total_bounty

    low_usd, high_usd = estimate_total_bounty(findings_severity)
    total_spend = scan_hours * 2.0 + tools_cost

    ratio_low = float(low_usd) / total_spend if total_spend > 0 else 0.0
    ratio_high = float(high_usd) / total_spend if total_spend > 0 else 0.0

    # Verdict 判定
    verdict = Verdict.RED
    if ratio_low > 10:
        verdict = Verdict.GREEN
    elif ratio_low >= 2:
        verdict = Verdict.YELLOW

    # 严重等级分布
    breakdown = {}
    for sev in findings_severity:
        breakdown[sev] = breakdown.get(sev, 0) + 1

    # 建议
    recommendations = []
    if verdict == Verdict.GREEN:
        recommendations.append("ROI 优秀 — 预期回报远超成本，强烈建议提交所有符合条件的发现")
    elif verdict == Verdict.YELLOW:
        recommendations.append("ROI 中等 — 部分低严重性发现可能不值得投入时间，优先提交高价值项")
    else:
        recommendations.append("ROI 不佳 — 考虑缩减扫描范围或优化工具链以降低 LLM 成本")

    return {
        "total_spend": round(total_spend, 2),
        "estimated_bounty_low": low_usd,
        "estimated_bounty_high": high_usd,
        "ratio_low": round(ratio_low, 1),
        "ratio_high": round(ratio_high, 1),
        "verdict": verdict,
        "recommendations": recommendations,
        "breakdown": breakdown,
    }
