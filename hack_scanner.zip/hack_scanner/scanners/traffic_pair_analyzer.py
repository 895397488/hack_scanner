#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
traffic_pair_analyzer.py — 请求/响应对 LLM 分析（4 项目升级清单 #6）
=====================================================================

借鉴 burpgpt lib/src/main/java/burp/{GPTRequest.java, MyScanCheck.java}:
    1. 占位符模板：{REQUEST} {RESPONSE} {URL} {METHOD}
       {REQUEST_HEADERS} {REQUEST_BODY} {RESPONSE_HEADERS} {RESPONSE_BODY}
    2. 截断标记：超长截断时 {IS_TRUNCATED_PROMPT}=true，
       让模型**知道自己看到的是残缺上下文**（防对残缺数据过度自信）
    3. 发现溯源（provenance）：finding 随附 model / max_prompt_size /
       truncated / prompt_sha256 —— 可审计、可复现（sha256 锚定 prompt 原文）

与 burpgpt 的差异（按 hack_scanner 场景裁剪）:
    - burpgpt 挂在 Burp 的被动扫描钩子；这里做独立 API + CLI，
      run_adaptive 不强制挂（避免每条流量对烧 token），
      advanced.traffic_pair.enabled 默认关
    - 输出从"Burp issue 对象"改为纯 JSON（findings 列表 + provenance）

接口:
    build_prompt(request, response, template=None, max_size=None)
        -> (prompt, truncated)
    analyze_pair(llm_chat, request, response,
                 template=None, max_size=None, model_name=None)
        -> {"findings": [...], "provenance": {model, max_prompt_size,
            truncated, prompt_sha256}}

request/response 接受两种形态:
    dict: {url, method, headers: dict|str, body: str, status?: int}
    str : 原始报文（整个当作 REQUEST/RESPONSE，URL/METHOD 等占位符为空）

llm_chat(system, user) -> Optional[str]：同 vuln_deepdive.make_llm_chat 契约。
LLM 失败 → findings 为空列表 + provenance 照常（溯源不依赖 LLM 成功）。
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

__all__ = [
    "DEFAULT_MAX_SIZE",
    "DEFAULT_TEMPLATE",
    "PLACEHOLDERS",
    "build_prompt",
    "analyze_pair",
]

# burpgpt 截断前的默认 prompt 预算（字符）
DEFAULT_MAX_SIZE = 24000

# 8 个占位符 + 截断标记（burpgpt GPTRequest 同款）
PLACEHOLDERS = (
    "{REQUEST}", "{RESPONSE}", "{URL}", "{METHOD}",
    "{REQUEST_HEADERS}", "{REQUEST_BODY}",
    "{RESPONSE_HEADERS}", "{RESPONSE_BODY}",
    "{IS_TRUNCATED_PROMPT}",
)

DEFAULT_TEMPLATE = """You are a security analyst reviewing ONE request/response pair captured during an authorized assessment.

[REQUEST]
{REQUEST}

[RESPONSE]
{RESPONSE}

Analysis focus:
- Reflected/tainted data in the response that echoes request input (XSS, header injection)
- Error messages leaking paths, stack traces, DB/schema details (info disclosure)
- Suspicious status codes / redirects / security headers (missing HSTS/CSP, CORS *, token echo)
- Sensitive data in body (PII, tokens, credentials, internal IDs)
- Auth/IDOR signals: same resource reachable with different/missing credentials
- WAF/error fingerprints useful for follow-up

Rules:
- Only report what THIS pair evidences; do not speculate beyond it.
- If {IS_TRUNCATED_PROMPT} is true, the pair was truncated for size — lower confidence and say so.
- Output a JSON array (possibly empty). Each item:
  {{"finding": str, "severity": "critical|high|medium|low|info",
    "evidence": str (quote the exact bytes), "confidence": int 0-10}}
"""


def _headers_to_text(headers: Any) -> str:
    if headers is None:
        return ""
    if isinstance(headers, str):
        return headers
    if isinstance(headers, dict):
        try:
            return "\n".join(f"{k}: {v}" for k, v in headers.items())
        except Exception:
            return json.dumps(headers, ensure_ascii=False, default=str)
    return str(headers)


def _pair_text(pair: Any) -> str:
    """把 request/response 渲染成完整报文本（占位符 {REQUEST}/{RESPONSE} 用）。"""
    if pair is None:
        return ""
    if isinstance(pair, str):
        return pair
    if not isinstance(pair, dict):
        return str(pair)
    lines: List[str] = []
    method = str(pair.get("method") or "").strip() or "GET"
    url = str(pair.get("url") or "").strip() or "/"
    lines.append(f"{method} {url} HTTP/1.1")
    hdr = _headers_to_text(pair.get("headers"))
    if hdr:
        lines.append(hdr)
    body = pair.get("body")
    if body:
        lines.append("")
        lines.append(body if isinstance(body, str) else json.dumps(body, ensure_ascii=False, default=str))
    status = pair.get("status")
    if status is not None:
        lines.insert(0, f"HTTP/1.1 {status} (response)")
    return "\n".join(lines)


def build_prompt(request: Any, response: Any,
                 template: Optional[str] = None,
                 max_size: Optional[int] = None) -> Tuple[str, bool]:
    """渲染分析 prompt。返回 (prompt, truncated)。

    - 8 占位符 + {IS_TRUNCATED_PROMPT} 全部替换（无对应内容 → 空串）
    - 超 max_size：先砍 REQUEST_BODY/RESPONSE_BODY（各留 1/6 预算）重渲染；
      仍超 → 硬截断到 max_size；两种情况都置 truncated=True
    """
    tpl = template if isinstance(template, str) and template.strip() else DEFAULT_TEMPLATE
    budget = max_size if (isinstance(max_size, int) and max_size > 0) else DEFAULT_MAX_SIZE

    def render(trunc_flag: bool) -> str:
        req = request if isinstance(request, dict) else ({"body": request} if isinstance(request, str) else {})
        resp = response if isinstance(response, dict) else ({"body": response} if isinstance(response, str) else {})
        req_body = str(req.get("body") or "")
        resp_body = str(resp.get("body") or "")
        subs = {
            "{REQUEST}": _pair_text(request),
            "{RESPONSE}": _pair_text(response),
            "{URL}": str(req.get("url") or ""),
            "{METHOD}": str(req.get("method") or ""),
            "{REQUEST_HEADERS}": _headers_to_text(req.get("headers")),
            "{REQUEST_BODY}": req_body,
            "{RESPONSE_HEADERS}": _headers_to_text(resp.get("headers")),
            "{RESPONSE_BODY}": resp_body,
            "{IS_TRUNCATED_PROMPT}": "true" if trunc_flag else "false",
        }
        out = tpl
        for k, v in subs.items():
            out = out.replace(k, v)
        return out

    prompt = render(trunc_flag=False)
    truncated = False
    if len(prompt) > budget:
        truncated = True
        # 砍两侧 body 到各 1/6 预算，保留头尾上下文
        body_budget = max(500, budget // 6)
        if isinstance(request, dict):
            b = str(request.get("body") or "")
            if len(b) > body_budget:
                request = dict(request)
                request["body"] = b[: body_budget // 2] + "\n[TRUNCATED]\n" + b[-body_budget // 2:]
        if isinstance(response, dict):
            b = str(response.get("body") or "")
            if len(b) > body_budget:
                response = dict(response)
                response["body"] = b[: body_budget // 2] + "\n[TRUNCATED]\n" + b[-body_budget // 2:]
        prompt = render(trunc_flag=True)
        if len(prompt) > budget:
            prompt = prompt[:budget]  # 硬截断兜底
    return prompt, truncated


def _extract_findings(raw: Any) -> List[Dict[str, Any]]:
    """从 LLM 回复里救出 findings 数组（容忍代码围栏/散文包裹）。"""
    if not raw:
        return []
    if isinstance(raw, list):
        return [f for f in raw if isinstance(f, dict)]
    if not isinstance(raw, str):
        return []
    t = raw.strip()
    candidates: List[str] = []
    m = re.search(r"```(?:json)?\s*(\[.*?\]|\{.*?\})\s*```", t, re.DOTALL)
    if m:
        candidates.append(m.group(1))
    lb, rb = t.find("["), t.rfind("]")
    if 0 <= lb < rb:
        candidates.append(t[lb:rb + 1])
    lb, rb = t.find("{"), t.rfind("}")
    if 0 <= lb < rb:
        candidates.append(t[lb:rb + 1])
    for c in candidates:
        try:
            d = json.loads(c)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(d, list):
            return [f for f in d if isinstance(f, dict)]
        if isinstance(d, dict) and isinstance(d.get("findings"), list):
            return [f for f in d["findings"] if isinstance(f, dict)]
    return []


def analyze_pair(llm_chat: Callable[[str, str], Optional[str]],
                 request: Any, response: Any,
                 template: Optional[str] = None,
                 max_size: Optional[int] = None,
                 model_name: Optional[str] = None) -> Dict[str, Any]:
    """分析一个请求/响应对。

    返回 {findings: [...], provenance: {model, max_prompt_size, truncated,
    prompt_sha256}}。LLM 抛异常 → findings=[]，provenance 照常（可审计失败本身）。
    """
    prompt, truncated = build_prompt(request, response, template, max_size)
    budget = max_size if (isinstance(max_size, int) and max_size > 0) else DEFAULT_MAX_SIZE
    sha = hashlib.sha256(prompt.encode("utf-8", errors="replace")).hexdigest()
    findings: List[Dict[str, Any]] = []
    try:
        raw = llm_chat(
            "You output well-formed JSON only. No prose outside the JSON.",
            prompt,
        )
        findings = _extract_findings(raw)
    except Exception:
        findings = []  # 深挖降级：溯源块仍完整
    return {
        "findings": findings,
        "provenance": {
            "model": model_name or "(injected llm_chat)",
            "max_prompt_size": budget,
            "truncated": truncated,
            "prompt_sha256": sha,
        },
    }


# ---------------------------------------------------------------------------
# CLI 自测（桩 LLM，无网络）
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    def stub_chat(system: str, user: str) -> str:
        return json.dumps([
            {"finding": "SQL error reflected in body", "severity": "high",
             "evidence": "You have an error in your SQL syntax", "confidence": 8}
        ])

    req = {"url": "http://x/api?q=1", "method": "GET",
           "headers": {"Host": "x", "User-Agent": "t"}, "body": ""}
    resp = {"status": 500, "headers": {"Server": "nginx"},
            "body": "You have an error in your SQL syntax near '1'"}
    out = analyze_pair(stub_chat, req, resp, model_name="stub")
    assert out["findings"] and out["findings"][0]["confidence"] == 8, out
    p = out["provenance"]
    assert p["truncated"] is False and len(p["prompt_sha256"]) == 64
    assert p["max_prompt_size"] == DEFAULT_MAX_SIZE and p["model"] == "stub"
    print("[OK ] analyze_pair: findings + provenance 完整")

    # 占位符全替换
    pr, tr = build_prompt(req, resp)
    for ph in PLACEHOLDERS:
        assert ph not in pr, f"占位符未替换: {ph}"
    assert "{IS_TRUNCATED_PROMPT}" not in pr and "false" in pr
    print("[OK ] build_prompt: 9 占位符全部替换，截断标记=false")

    # 超长 → 截断且 truncated=true，长度有界
    big = req | {"body": "A" * 100000}
    pr2, tr2 = build_prompt(big, resp, max_size=8000)
    assert tr2 is True and len(pr2) <= 8000, (tr2, len(pr2))
    assert "true" in pr2 and "[TRUNCATED]" in pr2
    print(f"[OK ] 超长截断: truncated=true, len={len(pr2)}<=8000")

    # 桩 LLM 抛异常 → findings 空、provenance 齐、无异常外溢
    def boom(system: str, user: str) -> str:
        raise RuntimeError("llm down")
    out2 = analyze_pair(boom, req, resp, model_name="stub")
    assert out2["findings"] == [] and len(out2["provenance"]["prompt_sha256"]) == 64
    print("[OK ] LLM 异常降级: findings=[] 且 provenance 完整")
    sys.exit(0)
