#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WPScan Wrapper — WPScan CLI wrapper，WordPress 专项安全扫描。

hack_scanner 此前的能力空缺：无 WordPress 专项扫描器。
WPScan 覆盖：
- 插件/主题枚举 + 版本识别（含未披露版本探测）
- 用户枚举（author、user-id、wp-json）
- 已知漏洞匹配（WPVulnDB，含 CVE）
- 默认/弱口令尝试（--attack 系列，默认不启用）
- 可写文件/目录、备份文件检测

集成方式：需要安装 WPScan（Ruby）
  - Windows: 先装 Ruby (choco install ruby) 再 gem install wpscan
  - Linux:   gem install wpscan  或  bundle install（见 github）
本模块只负责 CLI 调用和结果解析。config.json → tools.wpscan_path 可指定路径。

Usage:
    from scanners.wpscan_wrapper import wpscan_scan
    result = wpscan_scan("https://example.com")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('wpscan_scanner')


def _find_wpscan() -> Optional[str]:
    """查找 wpscan 可执行文件：先 config.json → tools.wpscan_path，再 PATH"""
    # 1) config.json tools.wpscan_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("wpscan_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["wpscan", "wpscan.exe", "wpscan.bat"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_wpscan_json(data: dict) -> dict:
    """解析 wpscan --json 输出的 scan 段"""
    scan = data.get("scan", data) if isinstance(data, dict) else {}
    return {
        "plugins": [
            {"name": p.get("name", ""), "version": p.get("version", ""),
             "last_updated": p.get("last_updated", "")}
            for p in (scan.get("plugins", []) or [])
        ],
        "themes": [
            {"name": t.get("name", ""), "version": t.get("version", "")}
            for t in (scan.get("themes", []) or [])
        ],
        "users": [
            {"user": u.get("user", ""), "id": u.get("id", ""),
             "role": u.get("role", ""), "avatar": u.get("avatar_url", "")}
            for u in (scan.get("users", []) or [])
        ],
        "vulnerabilities": [
            {"name": v.get("name", ""), "refs": (v.get("refs", []) or [])[:5],
             "found_in": v.get("found_in", "")}
            for v in (scan.get("vulnerabilities", []) or [])
        ],
        "wordpress_version": scan.get("wordpress_version", ""),
        "title": scan.get("title", ""),
    }


def _parse_wpscan_text(output: str) -> dict:
    """解析 wpscan 文本输出（[+] 前缀行）"""
    result = {"plugins": [], "themes": [], "users": [], "vulnerabilities": [],
              "wordpress_version": "", "title": ""}
    current_section = None
    for line in output.splitlines():
        line = line.strip()
        if line.startswith("[+]"):
            body = line[3:].strip()
            # 章节头
            if "Plugins" in body and "detection" in body.lower():
                current_section = "plugins"
            elif "Themes" in body and "detection" in body.lower():
                current_section = "themes"
            elif "Users" in body:
                current_section = "users"
            elif "Vulnerabilities" in body:
                current_section = "vulns"
            elif "version" in body.lower() and "WordPress" in body:
                m = re.search(r'version\s+(\S+)', body, re.I)
                if m:
                    result["wordpress_version"] = m.group(1)
            elif "title" in body.lower():
                result["title"] = body.split(":")[-1].strip()
            # 条目行
            elif current_section == "plugins" and ":" in body and "detection" not in body:
                name, _, ver = body.partition(": ")
                result["plugins"].append({"name": name.strip(), "version": ver.strip()})
            elif current_section == "themes" and ":" in body:
                name, _, ver = body.partition(": ")
                result["themes"].append({"name": name.strip(), "version": ver.strip()})
            elif current_section == "users" and body:
                m = re.search(r'\((\S+)\)', body)
                result["users"].append({"user": body, "id": m.group(1) if m else "", "role": ""})
            elif current_section == "vulns" and body:
                result["vulnerabilities"].append({"name": body, "refs": [], "found_in": ""})
    return result


def wpscan_scan(
    target: str,
    enumerate_items: str = "ap,at,u",
    max_time: int = 600,
) -> dict:
    """运行 WPScan WordPress 专项扫描。

    Args:
        target: 目标 URL（如 https://example.com）
        enumerate_items: 枚举项，逗号分隔：
            ap=authored plugins, at=authored themes, u=users,
            atb=all themes, apb=all plugins, tt=timthumbs
        max_time: 最大运行时间秒

    Returns:
        {
            "ok": True,
            "target": "...",
            "wordpress_version": "...",
            "plugins": [...], "themes": [...], "users": [...], "vulnerabilities": [...],
            "error": ""
        }
    """
    wpscan_path = _find_wpscan()
    if not wpscan_path:
        return {
            "ok": False,
            "target": target,
            "error": "WPScan 未找到，请安装: gem install wpscan (需先装 Ruby)",
        }

    cmd = [
        wpscan_path,
        "--url", target,
        "--enumerate", enumerate_items or "ap,at,u",
        "--json",       # JSON 输出便于解析
        "--quiet",      # 减少噪声
    ]

    logger.info(f"wpscan scan: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 30)
        output = proc.stdout or proc.stderr or ""

        # 优先解析 JSON
        parsed = None
        try:
            # wpscan --json 可能混入进度行，找第一个 { 开始解析
            start = output.find("{")
            if start >= 0:
                parsed = _parse_wpscan_json(json.loads(output[start:]))
        except (json.JSONDecodeError, ValueError):
            pass

        if parsed is None:
            parsed = _parse_wpscan_text(output)

        result = {"ok": True, "target": target, "error": ""}
        result.update(parsed)
        result["plugin_count"] = len(result.get("plugins", []))
        result["theme_count"] = len(result.get("themes", []))
        result["user_count"] = len(result.get("users", []))
        result["vulnerability_count"] = len(result.get("vulnerabilities", []))
        return result

    except subprocess.TimeoutExpired:
        return {"ok": False, "target": target, "error": f"wpscan 超时（最大时间 {max_time}s）"}
