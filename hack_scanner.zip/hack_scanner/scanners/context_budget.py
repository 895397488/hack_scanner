#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
真实 token 预算管理 — llm_invoke 的 token 级硬预算包装器
=====================================================================

背景（整合 vulnclaw 优势 ④，参照 vulnclaw/agent/token_counter.py + context_budget.py）:
    orchestrator 现有的上下文压缩是"消息数 > 40 就摘要"（swarm_orchestrator.py:563-582），
    不看真实体量。一条 2000 字符的工具结果 ≈ 500 token，40 条轻松超窗——
    64k 窗口的本地模型一旦被撑爆，API 直接报错或截断，整个 campaign 崩掉。

    这里在入口层加一个【token 级硬预算】包装器：每次 llm_invoke 前估算
    system + messages + tools 的总 token，超预算就从最老的历史消息开始丢弃
    （保留 campaign 启动消息 + 最近若干条），把丢弃内容压成 digest 行注入，
    让模型知道"前面发生过什么"而不必保留原文。

设计纪律（沿用 M6/M7/M11/M12 入口层模式）:
    - orchestrator 零改动：只改传给 llm_invoke 的 messages 副本
    - 纯标准库、无外部依赖；import/运行失败静默降级（核心循环不受影响）
    - 与既有"消息数>40 摘要"【并存】（双保险）：那个在内层粗筛，本层在外层做 token 硬约束
    - digest 行做敏感值脱敏（authorization/cookie/sk-* 等 → ***），防密钥进上下文

包装顺序（run_adaptive 组装）: 注入类在里、预算类在外——
    context_budget 位于 budget_guard 之内、experience/reflexion 之外，
    即：先 trim 历史（可丢弃），后由内层 coach 追加策略/经验/反思块（有界、不 trim）。
"""

import json
import os
import re
import sys
from typing import Any, Callable, Dict, List, Optional, Tuple

# 直接运行本文件时保证项目根目录在 sys.path（与 swarm_strategy 同一模式）
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


# ---------------------------------------------------------------------------
# token 估算（纯标准库，vulnclaw token_counter 原常量，中英混合 ~4 字符/token）
# ---------------------------------------------------------------------------
_CHARS_PER_TOKEN = 4.0          # 中英混合经验值
_MESSAGE_OVERHEAD = 4           # 每条消息的结构开销（role / framing）
_TOOL_RESULT_RENDER_CHARS = 2000  # llm_client.build_transcript 对 tool 结果的截断上限
_DIGEST_PREFIX = "[context digest v1]"
_DIGEST_LIMIT = 900             # digest 总字符上限（vulnclaw _message_history_digest 同款）
_LINE_LIMIT = 180               # 单条 digest 行字符上限


def _text_tokens(text: str) -> int:
    """估算一段文本的 token 数（空串 = 0）。"""
    if not text:
        return 0
    return int(len(text) / _CHARS_PER_TOKEN) + 1


def _message_tokens(m: Any) -> int:
    """估算单条消息 token 数。

    hack_scanner 历史里 tool 结果在 build_transcript 会被截到 2000 字符，
    这里按同样口径估算，避免高估导致过度丢弃。
    """
    if not isinstance(m, dict):
        return _text_tokens(str(m)) + _MESSAGE_OVERHEAD
    total = _MESSAGE_OVERHEAD
    total += _text_tokens(str(m.get("role", "") or ""))
    content = m.get("content")
    if isinstance(content, str):
        if m.get("role") == "tool":
            content = content[:_TOOL_RESULT_RENDER_CHARS]
        total += _text_tokens(content)
    elif isinstance(content, list):
        for part in content:
            if isinstance(part, dict) and isinstance(part.get("text"), str):
                total += _text_tokens(part["text"])
            else:
                total += _text_tokens(str(part))
    elif content is not None:
        total += _text_tokens(str(content))
    if m.get("name"):
        total += _text_tokens(str(m["name"]))
    return total


def estimate_messages_tokens(messages: Optional[List[dict]]) -> int:
    """估算消息列表的总 token。"""
    if not messages:
        return 0
    return sum(_message_tokens(m) for m in messages)


def _tools_tokens(tools: Optional[List[dict]]) -> int:
    if not tools:
        return 0
    try:
        return _text_tokens(json.dumps(tools, ensure_ascii=False, default=str))
    except (TypeError, ValueError):
        return _text_tokens(str(tools))


def estimate_prompt_tokens(system_prompt: Optional[str],
                          messages: Optional[List[dict]],
                          tools: Optional[List[dict]]) -> int:
    """估算一次 llm_invoke 的完整 prompt token（system + tools + messages）。"""
    total = 0
    if system_prompt:
        total += _text_tokens(system_prompt)
    total += _tools_tokens(tools)
    total += estimate_messages_tokens(messages)
    return total


# ---------------------------------------------------------------------------
# 敏感值脱敏（vulnclaw context_budget._redact 思路）
# ---------------------------------------------------------------------------
_KV_SECRET_RE = re.compile(
    r"(?i)\b(authorization|cookie|set-cookie|api[_-]?key|access[_-]?token|"
    r"refresh[_-]?token|secret|password|token|bearer)\s*[:=]\s*(\S+)"
)
_BEARER_RE = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._\-+/=]{8,}")
_TOKEN_LIKE_RE = re.compile(r"\b(sk-[A-Za-z0-9]{12,}|ghp_[A-Za-z0-9]{16,}|AKIA[0-9A-Z]{16})\b")


def _redact(value: str) -> str:
    """把 digest 行里的疑似密钥/凭据替换为 ***。

    顺序敏感：先脱敏 `Bearer <token>` 整体（否则 KV 正则只吃到 Bearer 一词、
    真正的 token 被留在后面），再 KV 键值对，最后裸 token 特征。
    """
    text = str(value or "")
    text = _BEARER_RE.sub("Bearer ***", text)
    text = _KV_SECRET_RE.sub(lambda m: m.group(1) + "=***", text)
    text = _TOKEN_LIKE_RE.sub("***", text)
    return text


def _one_line(value: Any, limit: int = _LINE_LIMIT) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def _message_history_digest(messages: List[dict], limit: int = _DIGEST_LIMIT) -> str:
    """把被丢弃的历史消息压成 digest 行（每条一行 ≤ _LINE_LIMIT，总 ≤ limit）。"""
    lines: List[str] = []
    for m in messages:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role", "message") or "message")
        content = str(m.get("content", "") or "")
        if not content.strip():
            continue
        lines.append(f"- {role}: {_redact(_one_line(content))}")
    rendered = "\n".join(lines)
    if len(rendered) > limit:
        rendered = rendered[: limit - 1] + "…"
    return rendered


def _truncation_notice() -> str:
    return ("[上下文截断] 为控制 token 用量，部分较早的历史消息已被摘要移除，"
            "仅保留系统提示、目标信息和最近的对话。")


# ---------------------------------------------------------------------------
# 历史裁剪
# ---------------------------------------------------------------------------
def fit_messages(messages: List[dict],
                 system_prompt: Optional[str],
                 tools: Optional[List[dict]],
                 budget_tokens: int,
                 max_recent: int = 24) -> Tuple[List[dict], List[dict]]:
    """把 messages 裁到预算内。保留首条（campaign 启动）+ 最近若干条。

    返回 (kept_messages, dropped_messages)。未超预算时 kept 为原列表副本、dropped 为空。
    """
    if not messages:
        return list(messages or []), []
    if budget_tokens <= 0:
        return list(messages), []
    if estimate_prompt_tokens(system_prompt, messages, tools) <= budget_tokens:
        return list(messages), []

    n = len(messages)
    # system + tools 占用固定，给 messages 留的预算
    fixed = 0
    if system_prompt:
        fixed += _text_tokens(system_prompt)
    fixed += _tools_tokens(tools)
    msg_budget = max(256, budget_tokens - fixed)

    # 从"保留最多"往"保留最少"试，找到第一个 messages 体量子集的预算可行解
    upper = min(max_recent, n - 1) if n > 1 else 0
    for keep_recent in range(upper, 0, -1):
        kept = [messages[0]] + messages[-keep_recent:]
        if estimate_messages_tokens(kept) <= msg_budget:
            dropped = messages[1 : n - keep_recent] if n - keep_recent > 1 else []
            return kept, dropped
    # 极端：连"首条 + 最后一条"都超（单条巨大消息）——保留首条 + 最后一条，
    # 真正的兜底交给 llm_client.TRANSCRIPT_TAIL_CHARS 与 API 自身窗口。
    # BUG_REPORT [11]：n==1 时 messages[0] is messages[-1]，原兜底把同一条
    # 消息保留两份（token 估算翻倍、LLM 上下文重复）。
    if n == 1:
        return [messages[0]], []
    return [messages[0], messages[-1]], messages[1:-1]


def _build_digest_message(dropped: List[dict]) -> Dict[str, str]:
    digest = _message_history_digest(dropped)
    content = _DIGEST_PREFIX
    if digest:
        content += "\n" + digest
    content += "\n\n" + _truncation_notice()
    return {"role": "system", "content": content}


# ---------------------------------------------------------------------------
# 包装器
# ---------------------------------------------------------------------------
def install_context_budget(llm_invoke: Callable,
                           window_tokens: int = 59536,
                           max_recent: int = 24) -> Callable:
    """包装 llm_invoke：每次调用前按 token 预算裁剪 messages。

    window_tokens: 0/None = 关闭（原样透传）。默认 59536 = 64k 窗口 - 6000 输出余量。
    兼容 kwargs 调用（orchestrator 用 system_prompt=/messages=/tools= kwargs）
    与位置参数调用（system, messages, tools）。
    """
    if not window_tokens or window_tokens <= 0:
        return llm_invoke

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        # 取三要素（kwargs 优先，其次位置参数）
        system_prompt = kwargs.get("system_prompt")
        if system_prompt is None and len(args) >= 1:
            system_prompt = args[0]
        messages = kwargs.get("messages")
        if messages is None and len(args) >= 2:
            messages = args[1]
        tools = kwargs.get("tools")
        if tools is None and len(args) >= 3:
            tools = args[2]

        try:
            kept, dropped = fit_messages(messages or [], system_prompt, tools,
                                         window_tokens, max_recent)
        except Exception:
            return llm_invoke(*args, **kwargs)  # 估算异常 → 原样透传，不阻断

        if not dropped or kept is messages:
            return llm_invoke(*args, **kwargs)

        digest_msg = _build_digest_message(dropped)
        new_messages = [digest_msg] + kept
        # 回写（只改副本，不污染 orchestrator 的历史）
        if "messages" in kwargs:
            kwargs["messages"] = new_messages
        elif len(args) >= 2:
            new_args = list(args)
            new_args[1] = new_messages
            args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._window_tokens = window_tokens  # 测试用
    return wrapped


def load_window_tokens(config: Optional[dict] = None) -> int:
    """从 config.json 读 context_budget.window_tokens（0 = 关闭）。

    缺省 59536。config 传 None 时自动加载项目 config.json。
    """
    default = 59536
    conf = config
    if conf is None:
        try:
            path = os.path.join(_PROJECT_ROOT, "config.json")
            with open(path, "r", encoding="utf-8") as f:
                conf = json.load(f) or {}
        except Exception:
            return default
    val = (conf or {}).get("context_budget", {}).get("window_tokens", default)
    try:
        return int(val)
    except (TypeError, ValueError):
        return default


if __name__ == "__main__":
    # 自测：构造超长历史，用小预算强制触发裁剪，验证 kept/digest/脱敏
    msgs = [{"role": "user", "content": "Campaign started. Target: http://x"}]
    for i in range(60):
        msgs.append({"role": "assistant", "content": f"step {i} thinking..." * 30})
        msgs.append({"role": "tool", "content": f"tool result {i} " + "A" * 3000})
    budget = 8000  # 故意远小于 59536 默认窗口，确保触发裁剪分支
    kept, dropped = fit_messages(msgs, "SYSTEM PROMPT" * 20, [{"name": "t"}], budget)
    print(f"original={len(msgs)} kept={len(kept)} dropped={len(dropped)}")
    assert dropped, "应触发裁剪（测试数据必须超预算）"
    assert kept and kept[0].get("role") == "user", "首条（campaign 启动）必须保留"
    assert estimate_prompt_tokens("SYSTEM PROMPT" * 20, kept, [{"name": "t"}]) <= budget, "裁剪后必须 ≤ 预算"
    digest_msg = _build_digest_message(dropped)
    print("digest sample:")
    print(digest_msg["content"][:400])
    d = {"role": "tool", "content": "Authorization: Bearer abcdef1234567890 sk-abcdef1234567890123456"}
    redacted = _redact(d["content"])
    print("redact:", redacted)
    assert "abcdef1234567890" not in redacted and "sk-abcdef" not in redacted, "脱敏必须抹掉凭据"

    # 包装器自测：kwargs 调用 + 短历史不触发
    seen = {}
    def fake_llm(system_prompt=None, messages=None, tools=None, **kw):
        seen["n"] = len(messages or [])
        return "ok"
    wrapped = install_context_budget(fake_llm, window_tokens=8000)
    wrapped(system_prompt="S" * 100, messages=msgs, tools=[{"name": "t"}])
    assert seen["n"] < len(msgs), "包装器应裁剪 messages"
    short = [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hello"}]
    wrapped(system_prompt="S" * 100, messages=short, tools=[{"name": "t"}])
    assert seen["n"] == 2, "短历史不应被裁剪"
    print("self-test OK")
