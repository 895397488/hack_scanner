#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TodoWrite 任务清单层 — 全量清单随 prompt 携带（借鉴 holmes TodoWrite）
=====================================================================

背景（参照 holmes plugins/toolsets/investigator/core_investigation.py）:
    复杂多步调查中，模型常见的失败模式是"丢步骤"——上下文变长后忘记
    还有一整段没做，或把已做的重做。holmes 的解法是 TodoWrite 工具：
    agent 自己维护一份**完整任务清单**（pending/in_progress/completed/failed），
    清单**每轮随 prompt 携带**——即使上下文被摘要压缩，清单仍然在场，
    复杂调查不丢步骤。

    本模块是 holmes TodoWrite 语义的纯标准库移植，落地 hack_scanner 的
    入口层模式（orchestrator 零改动）：
    - TodoStore: 全量写（每次调用以完整清单整体替换，holmes TodoWrite 语义，
      不引入 add/update/remove 操作原语——状态面最小、无局部更新竞态）；
      状态 pending/in_progress/completed/failed（脏值静默归一，未知→pending）
    - todo 工具（ToolDefinition）: agent 调用维护清单；返回紧凑确认
    - install_todo_coach: 包装 llm_invoke，每轮把当前清单追加到 system_prompt
    - 报告段 render_todo_section(): 收尾把最终清单状态写进报告

与 40 条摘要机制的 token 交互（升级清单 #8 明确要求的注意事项）:
    清单注入 **system_prompt**（每轮稳定重附），不注入 messages 历史——
    orchestrator 的 _summarize_context 压缩的是 messages，system_prompt
    不受影响，清单在摘要后依然在场；块本身有硬上限（≤1200 字符），
    且不动 messages，不干扰 context_budget 的 token 裁剪。

设计纪律（与 correction/anti_loop/recorder 一致）:
    - orchestrator 零改动；纯标准库；脏输入全程静默降级，绝不阻断核心循环
    - 可关闭：enabled=False / config advanced.todo.enabled=false → 零变化
    - 续扫持久化：可选 persist_path（runs/<run_id>/todo.json），变更即原子写，
      中断/续扫时清单不丢

注入块用英文（与 hack_scanner 既有注入块风格一致，correction/reflexion 同款）。
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Callable, Dict, List, Optional

__all__ = [
    "VALID_STATUSES",
    "TodoStore",
    "make_todo_tool",
    "install_todo_coach",
    "render_todo_section",
]


VALID_STATUSES = ("pending", "in_progress", "completed", "failed")

# 常见别名 → 规范状态（模型常写 done/todo/doing；脏值最终归 pending）
_STATUS_ALIASES = {
    "pending": "pending", "todo": "pending", "open": "pending",
    "new": "pending", "waiting": "pending",
    "in_progress": "in_progress", "inprogress": "in_progress",
    "doing": "in_progress", "active": "in_progress",
    "current": "in_progress", "progress": "in_progress",
    "completed": "completed", "complete": "completed", "done": "completed",
    "finished": "completed", "closed": "completed",
    "failed": "failed", "error": "failed", "blocked": "failed", "dead": "failed",
}

MAX_TASK_CONTENT = 160   # 单条任务文本上限（注入块有总预算）
MAX_BLOCK_CHARS = 1200   # 注入块总预算（与 correction._MAX_BLOCK_CHARS 同量级）

_MARKERS = {
    "completed": "[x]",
    "in_progress": "[>]",
    "pending": "[ ]",
    "failed": "[!]",
}

_TAIL = (
    "Keep this list current: whenever a step starts/completes/fails, call todo "
    "with the FULL updated list (1-15 items, one in_progress at a time). "
    "Do not re-do steps marked completed; a step is done only when it has "
    "an explicit outcome."
)


def _norm_status(raw: Any) -> str:
    key = str(raw or "").strip().lower().replace(" ", "_").replace("-", "_")
    return _STATUS_ALIASES.get(key, "pending")


def _norm_task(item: Any) -> Optional[Dict[str, str]]:
    """把一条任务归一为 {content, status}；无效 → None（静默丢弃）。"""
    try:
        if isinstance(item, str):
            content = item.strip()
            status = "pending"
        elif isinstance(item, dict):
            content = str(
                item.get("content") or item.get("task")
                or item.get("description") or "").strip()
            status = _norm_status(item.get("status"))
        else:
            return None
        content = re.sub(r"\s+", " ", content)[:MAX_TASK_CONTENT]
        if not content:
            return None
        return {"content": content, "status": status}
    except Exception:
        return None


class TodoStore:
    """全量任务清单存储（每次 set_tasks 整体替换）。

    - set_tasks(): 校验/归一/去重/截断 → 替换全部清单；脏输入不抛异常外溢
      （非法整体 → ValueError，由工具层转成 error 返回）
    - render(): 紧凑英文注入块（≤MAX_BLOCK_CHARS）；空清单 → ""
    - persist_path: 可选；每次变更原子落盘（tmp + os.replace），异常静默
    - snapshot()/restore(): 续扫/测试用往返
    """

    def __init__(self, max_tasks: int = 15, persist_path: Optional[str] = None):
        try:
            self.max_tasks = max(1, int(max_tasks))
        except (TypeError, ValueError):
            self.max_tasks = 15
        self._persist_path = str(persist_path).strip() if persist_path else None
        self._tasks: List[Dict[str, str]] = []

    # -- 写 -----------------------------------------------------------------
    def set_tasks(self, raw: Any) -> Dict[str, Any]:
        """以完整清单整体替换。返回摘要 dict。

        raw: list[dict|str]；dict 取 content/task/description + status。
        整体非法（非 list / 无有效条目）→ ValueError（工具层转 error 返回）。
        """
        if isinstance(raw, dict):
            # 容忍 {"todos": [...]} / {"tasks": [...]} 包一层的情况
            raw = raw.get("todos") or raw.get("tasks") or []
        if not isinstance(raw, (list, tuple)):
            raise ValueError("todos must be a list of {content, status}")
        tasks: List[Dict[str, str]] = []
        seen = set()
        for item in raw:
            t = _norm_task(item)
            if t is None:
                continue
            key = t["content"].lower()
            if key in seen:
                continue  # 同内容去重（保留首次出现的状态）
            seen.add(key)
            tasks.append(t)
        if not tasks:
            raise ValueError("no valid tasks (need at least one non-empty content)")
        if len(tasks) > self.max_tasks:
            tasks = tasks[:self.max_tasks]
        self._tasks = tasks
        self._persist()
        return {"count": len(self._tasks), "counts": self.counts()}

    # -- 读 -----------------------------------------------------------------
    @property
    def tasks(self) -> List[Dict[str, str]]:
        return [dict(t) for t in self._tasks]

    @property
    def empty(self) -> bool:
        return not self._tasks

    def counts(self) -> Dict[str, int]:
        c = {s: 0 for s in VALID_STATUSES}
        for t in self._tasks:
            c[t["status"]] += 1
        return c

    def render(self) -> str:
        """紧凑英文注入块（≤MAX_BLOCK_CHARS）；空清单 → 空串。

        格式:
            [Todo — campaign task list]
            [x]=completed  [>]=in_progress  [ ]=pending  [!]=failed
            - [x] Enumerate subdomains of example.com
            - [>] Probe /api/v1 for IDOR
            - [ ] Attempt auth bypass on /login
            - [!] Verify RCE (env missing)
            Keep this list current: ...
        """
        if not self._tasks:
            return ""
        head = (
            "[Todo — campaign task list]\n"
            "[x]=completed  [>]=in_progress  [ ]=pending  [!]=failed"
        )
        tail = _TAIL
        budget = MAX_BLOCK_CHARS - len(head) - len(tail) - 2
        items: List[str] = []
        overflow = 0
        for t in self._tasks:
            line = f"- {_MARKERS[t['status']]} {t['content']}"
            if len(line) + 1 > budget and items:
                overflow = len(self._tasks) - len(items)
                break
            items.append(line)
            budget -= len(line) + 1
        if overflow > 0:
            items.append(f"- +{overflow} more (maintained via the todo tool)")
        return "\n".join([head, *items, tail])[:MAX_BLOCK_CHARS]

    # -- 持久化（续扫） -------------------------------------------------------
    def set_persist_path(self, path: Optional[str]) -> None:
        """改绑落盘位置（run_id 晚于 store 创建的场景）；传空串/None 关闭。

        仅改绑、不立即写盘（下次 set_tasks 变更才落）。"""
        self._persist_path = str(path).strip() if path else None

    def snapshot(self) -> List[Dict[str, str]]:
        return self.tasks

    def restore(self, snapshot: Any) -> int:
        """从快照恢复（整体替换）。返回恢复条数；非法 → 0（不抛）。"""
        try:
            tasks = snapshot.get("tasks") if isinstance(snapshot, dict) else snapshot
            if not isinstance(tasks, (list, tuple)):
                return 0
            self.set_tasks(tasks)
            return len(self._tasks)
        except Exception:
            return 0

    def restore_from_file(self, path: str) -> int:
        """从 JSON 文件恢复（{version, tasks}）。文件缺失/损坏 → 0（不抛）。"""
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return self.restore(data)
        except Exception:
            return 0

    def _persist(self) -> None:
        if not self._persist_path:
            return
        try:
            d = os.path.dirname(self._persist_path)
            if d:
                os.makedirs(d, exist_ok=True)
            tmp = self._persist_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump({"version": 1, "tasks": self._tasks}, fh, ensure_ascii=False)
            os.replace(tmp, self._persist_path)
        except Exception:
            pass  # 落盘失败静默（清单仍在内存 + prompt 里，不阻断核心循环）


# ---------------------------------------------------------------------------
# todo 工具（ToolDefinition — orchestrator.register_tool 挂载，零改动）
# ---------------------------------------------------------------------------
def _parse_args(args: Any) -> Any:
    try:
        if isinstance(args, str):
            return json.loads(args)
        if isinstance(args, (dict, list)):
            return args
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return None


def make_todo_tool(store: Optional[TodoStore] = None) -> Any:
    """构造 todo 工具（参照 kb_search.make_consult_kb_tool 的约定）。

    参数: {"todos": [{"content": "...", "status": "pending|in_progress|completed|failed"}]}
    语义: 每次调用以完整清单整体替换（holmes TodoWrite）；
    输出: JSON 确认（count + 各状态计数 + 当前清单渲染）。
    """
    store = store or TodoStore()

    def execute(args_string: str):
        obj = _parse_args(args_string)
        todos = obj
        if isinstance(obj, dict):
            todos = obj.get("todos")
            if todos is None:
                todos = obj.get("tasks")
        try:
            summary = store.set_tasks(todos)
        except ValueError as exc:
            payload = {
                "ok": False,
                "error": str(exc),
                "hint": ('e.g. {"todos": [{"content": "enumerate subdomains", '
                         '"status": "pending"}, {"content": "probe /api/v1", '
                         '"status": "in_progress"}]}'),
            }
            return json.dumps(payload, ensure_ascii=False), "invalid_args"
        payload = {"ok": True, **summary}
        return json.dumps(payload, ensure_ascii=False), None

    from scanners.swarm_orchestrator import ToolDefinition
    return ToolDefinition(
        name="todo",
        description=(
            "Maintain the full campaign task list (TodoWrite). Each call REPLACES the "
            "entire list with its current state — pass ALL tasks with updated statuses, "
            "not just the changed one. Use at the start of each phase and whenever a step "
            "starts/completes/fails. Statuses: pending, in_progress, completed, failed. "
            "Keep 1-15 items, one in_progress at a time. The list is carried in your "
            "prompt every round — keep it current and complete; do not re-do completed steps."),
        parameters={
            "type": "object",
            "properties": {
                "todos": {
                    "type": "array",
                    "description": "The FULL task list (replaces the previous list)",
                    "items": {
                        "type": "object",
                        "properties": {
                            "content": {"type": "string",
                                       "description": "One concrete step (<=160 chars)"},
                            "status": {"type": "string",
                                       "enum": list(VALID_STATUSES),
                                       "description": "pending | in_progress | completed | failed"},
                        },
                        "required": ["content"],
                    },
                },
            },
            "required": ["todos"],
        },
        execute=execute,
    )


# ---------------------------------------------------------------------------
# llm_invoke 教练 — 每轮把清单挂到 system_prompt
# ---------------------------------------------------------------------------
def install_todo_coach(
    llm_invoke: Callable,
    store: Optional[TodoStore] = None,
    enabled: bool = True,
) -> Callable:
    """包装 llm_invoke：每次调用前，若清单非空 → 追加到 system_prompt。

    - 注入 system_prompt（稳定面、每轮重附）而非 messages 历史：
      orchestrator 的摘要压缩作用于 messages，清单不受影响；
      也不干扰 context_budget 的 token 裁剪（它只看 messages）
    - 块有硬上限（≤1200 字符）；render 异常 → 无注入降级
    - enabled=False → 原样返回 llm_invoke
    - 透传 .client（usage 记账）
    """
    if not enabled:
        return llm_invoke
    store = store or TodoStore()

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        block = ""
        try:
            block = store.render()
        except Exception:
            block = ""
        if block:
            if "system_prompt" in kwargs:
                cur = kwargs["system_prompt"]
                cur = cur if isinstance(cur, str) else str(cur or "")
                kwargs["system_prompt"] = cur + "\n\n" + block
            elif args and isinstance(args[0], str):
                args = (args[0] + "\n\n" + block,) + tuple(args[1:])
        return llm_invoke(*args, **kwargs)

    wrapped.client = getattr(llm_invoke, "client", None)  # type: ignore[attr-defined]
    wrapped._store = store  # 测试用
    return wrapped


# ---------------------------------------------------------------------------
# 报告段（收尾：最终清单状态写进报告；中文，与 render_triage_section 同款）
# ---------------------------------------------------------------------------
_STATUS_ZH = {
    "completed": "已完成",
    "in_progress": "进行中",
    "pending": "待办",
    "failed": "失败",
}


def render_todo_section(store: TodoStore) -> str:
    """Markdown 报告段；空清单 → 空串。"""
    try:
        tasks = store.tasks
        if not tasks:
            return ""
        c = store.counts()
        lines = [
            "## 任务清单（TodoWrite 全程跟踪）",
            "",
            f"> 共 {len(tasks)} 步：已完成 {c['completed']} | 进行中 {c['in_progress']} "
            f"| 待办 {c['pending']} | 失败 {c['failed']}",
            "",
            "| 状态 | 任务 |",
            "|---|---|",
        ]
        for t in tasks:
            content = str(t["content"]).replace("|", "\\|").replace("\n", " ")
            lines.append(f"| {_STATUS_ZH.get(t['status'], t['status'])} | {content} |")
        return "\n".join(lines)
    except Exception:
        return ""


if __name__ == "__main__":
    # 自测：归一/去重/截断/渲染预算/持久化往返/工具契约/教练注入
    # 直接以脚本运行时 sys.path[0] 是 scanners/，补上项目根（ToolDefinition 走
    # scanners. 包导入）；从 run_adaptive 调用时根已在 path，此步无副作用。
    import sys as _sys
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _root not in _sys.path:
        _sys.path.insert(0, _root)
    _s = TodoStore(max_tasks=5)
    summary = _s.set_tasks([
        {"content": "  Enumerate   subdomains", "status": "done"},
        {"content": "Probe /api/v1", "status": "weird-status"},
        {"content": "", "status": "pending"},            # 空内容 → 丢
        {"content": "Enumerate subdomains", "status": "pending"},  # 去重（忽略大小写）
        "Attempt auth bypass",
        {"content": "Verify RCE", "status": "error"},
    ])
    assert summary["count"] == 4, f"去重后 4 条: {summary}"
    assert summary["counts"]["completed"] == 1
    assert summary["counts"]["pending"] == 2
    assert summary["counts"]["failed"] == 1
    assert _s.tasks[0]["content"] == "Enumerate subdomains", "空白归一"
    assert _s.tasks[1]["status"] == "pending", "未知状态 → pending"
    # max_tasks 截断
    _s2 = TodoStore(max_tasks=2)
    _s2.set_tasks([{"content": f"t{i}"} for i in range(6)])
    assert len(_s2.tasks) == 2, f"max_tasks 截断: {len(_s2.tasks)}"

    block = _s.render()
    assert "[Todo — campaign task list]" in block and "[x]" in block, block
    assert len(block) <= 1200, f"len={len(block)}"
    assert TodoStore().render() == "", "空清单 → 空串"

    # 渲染预算：超长清单仍 ≤1200
    _big = TodoStore(max_tasks=50)
    _big.set_tasks([
        {"content": f"step {i:02d} " + "x" * 150, "status": "pending"}
        for i in range(50)
    ])
    _b = _big.render()
    assert len(_b) <= 1200, f"big len={len(_b)}"
    import re as _re
    assert _re.search(r"\+\d+ more", _b), _b[-120:]

    # 持久化往返
    import tempfile
    _d = tempfile.mkdtemp()
    _p = os.path.join(_d, "runs", "r1", "todo.json")
    _pstore = TodoStore(persist_path=_p)
    _pstore.set_tasks([{"content": "a", "status": "completed"}, {"content": "b"}])
    assert os.path.isfile(_p), "原子落盘"
    _rstore = TodoStore()
    assert _rstore.restore_from_file(_p) == 2, "文件恢复"
    assert _rstore.restore_from_file(os.path.join(_d, "nope.json")) == 0, "缺失 → 0"
    assert _rstore.restore({"tasks": "not-a-list"}) == 0, "非法快照 → 0"
    assert _rstore.restore("junk") == 0, "非法快照 → 0"

    # 工具契约
    _tool = make_todo_tool(_rstore)
    _r, _e = _tool.execute(json.dumps({"todos": [{"content": "t1"}, {"content": "t2", "status": "done"}]}))
    assert _e is None and json.loads(_r)["ok"] is True, (_r, _e)
    _r2, _e2 = _tool.execute("not-json")
    assert _e2 == "invalid_args" and "error" in _r2, (_r2, _e2)
    _r3, _e3 = _tool.execute(json.dumps({"todos": []}))
    assert _e3 == "invalid_args", "空清单 → invalid_args"
    assert _tool.name == "todo" and "todos" in _tool.parameters["properties"]

    # 教练注入（kw + 位置双路径）+ .client 透传 + enabled=False 恒等
    _calls = []
    def _llm(system_prompt=None, messages=None, tools=None, **_kw):
        _calls.append((system_prompt, list(messages or [])))
        return {"content": "ok"}
    _llm.client = "CLIENT"
    _co = install_todo_coach(_llm, _rstore)
    assert _co.client == "CLIENT", ".client 透传"
    _co(system_prompt="S", messages=[{"role": "user", "content": "go"}], tools=[])
    _sp, _msgs = _calls[-1]
    assert _sp.startswith("S") and "[Todo — campaign task list]" in _sp, _sp[:120]
    assert len(_msgs) == 1, "不动 messages"
    # 位置参数路径
    _llm_pos = lambda sp, msgs, *a, **k: None
    _co2 = install_todo_coach(_llm_pos, _rstore)
    _co2("S", [])
    assert install_todo_coach(_llm, _rstore, enabled=False) is _llm, "enabled=False 原样返回"

    # 报告段
    sec = render_todo_section(_rstore)
    assert "## 任务清单" in sec and "已完成" in sec, sec[:120]
    assert render_todo_section(TodoStore()) == "", "空清单 → 空段"

    print("self-test OK")
