#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm 工具绑定层 — 把 orchestrator 的占位工具接到真实扫描/分析模块
=====================================================================

给 SwarmOrchestrator 注册一组 execute 真实可用的 ToolDefinition：

    reconnaissance   子域/端点/技术栈侦察（theharvester + crawler + HTTP 指纹）
    http_probe       LLM 自定义请求探测（scope 门控 + 限速 + 响应截断）
    classify         发现分类（swarm_classifier.classify_finding_set）
    exploit          命令执行（swarm_exploit_engine.Executor，默认 dry-run）
    generate_report  报告生成（swarm_report_generator，落盘 + 返回预览）
    finish_scan      生命周期收尾（orchestrator 按名字拦截）

    ── 辅助工具箱（scanners/swarm_aux_tools.py，按需调用成熟检测模块）──
    run_detector   指名跑单个成熟检测器（sqli/xss/lfi/xxe/csrf/jwt/… 共 24 个）
    scan_endpoint  单端点全流程扫描（URLScanner，300s 墙钟上限）
    dir_bust       纯 Python 目录爆破（内置 ~90 路径，无需外部工具）
    ext_scan       外部工具 wrapper（dirsearch/gobuster/nikto/ffuf/…，未装则降级提示）

安全策略:
    - http_probe / exploit 均受 scope 白名单硬约束（出 scope 直接拒绝并
      回灌解释，让 LLM 自我纠正）
    - http_probe 走 rate_limiter 全局限速
    - exploit 默认 dry_run=True（调用方显式开启才真执行，且仍受
      SafeMode/allowlist/scope 三重门控）
    - 所有工具输出统一截断，防 LLM 上下文爆炸

execute 契约（swarm_orchestrator.py:133）:
    execute(args_string) -> (result_string, error_or_None)
"""

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from urllib.parse import urlparse

logger = logging.getLogger('swarm_tool_binders')

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 直接运行本文件时保证项目根目录在 sys.path（包导入场景下无副作用）
import sys
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from scanners.swarm_orchestrator import ToolDefinition

# 输出截断上限（字符）
RECON_MAX_CHARS = 4096
PROBE_BODY_MAX = 2048
REPORT_INLINE_MAX = 8192

_HTTP_TIMEOUT = 15        # http_probe 单请求超时（秒）
_CRAWL_TIMEOUT = 60       # crawler 总超时（秒）
_THEHARVEST_TIMEOUT = 60  # theharvester 超时（秒）


# ---------------------------------------------------------------------------
# 上下文
# ---------------------------------------------------------------------------
@dataclass
class CampaignContext:
    """一次 campaign 的共享上下文（scope / 报告目录 / 安全开关）。"""
    target_url: str = ""
    objective: str = "find all vulnerabilities"
    scope_hosts: Set[str] = field(default_factory=set)   # 规范化后的 host（小写）
    scope_patterns: List[str] = field(default_factory=list)  # 给 exploit 的 scope 模式
    dry_run: bool = True
    report_dir: str = ""
    # --- 富报告数据源（M14：报告整合此前扫描结果） ---
    tool_log: List[dict] = field(default_factory=list)  # 入口层指向 recorder 同一 list（只读消费）
    model_info: str = ""                                 # 如 "ollama/qwen3.8:27b"（入口层注入）
    started_at: float = 0.0                              # campaign 开始时间戳（报告"用时"）


def _host_from_url(url: str) -> str:
    try:
        p = urlparse(url if "//" in url else f"//{url}")
        return (p.netloc or "").lower().split("@")[-1].split(":")[0]
    except Exception:
        return ""


def build_context(target_url: str, objective: str = "", dry_run: bool = True) -> CampaignContext:
    """从目标 URL 构建上下文（scope = 该 host + 其子域 + loopback）。"""
    host = _host_from_url(target_url)
    scope: Set[str] = set()
    patterns: List[str] = []
    if host:
        scope.add(host)
        patterns.append(host)
    # loopback 永远允许（本地测试页场景）
    scope |= {"localhost", "127.0.0.1", "::1", "0.0.0.0"}

    # 对齐项目既有报告目录约定（用 hack_report/）
    report_dir = os.path.join(_PROJECT_ROOT, "hack_report")
    os.makedirs(report_dir, exist_ok=True)

    return CampaignContext(
        target_url=target_url,
        objective=objective or "find all vulnerabilities",
        scope_hosts=scope,
        scope_patterns=patterns,
        dry_run=dry_run,
        report_dir=report_dir,
        started_at=time.time(),
    )


def _in_scope(host: str, ctx: CampaignContext) -> bool:
    """scope 判定: 精确匹配 / 子域 / IP 相等 / loopback。"""
    h = (host or "").lower().strip(".")
    if not h:
        return False
    for s in ctx.scope_hosts:
        if h == s or h.endswith("." + s):
            return True
    return False


# ---------------------------------------------------------------------------
# 参数解析辅助
# ---------------------------------------------------------------------------
def _parse_args(args_string: str) -> Dict[str, Any]:
    """把 LLM 给的 args（JSON 字符串）解析成 dict；失败返回 {}。"""
    if not args_string:
        return {}
    if isinstance(args_string, dict):
        return args_string
    try:
        obj = json.loads(args_string)
        return obj if isinstance(obj, dict) else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _err(msg: str) -> tuple:
    """统一的"软错误"返回: 不抛异常，把解释回灌给 LLM 让它自纠。"""
    return (msg, None)


# ---------------------------------------------------------------------------
# JSON 安全截断
# ---------------------------------------------------------------------------
def _json_safe_dumps(obj: Any, max_chars: int) -> str:
    """序列化结果且保证输出永远是【合法 JSON】。

    直接对序列化结果做 ``[:max_chars]`` 硬截断，超长时会产出未闭合字符串的
    坏 JSON，下游 ``json.loads`` 必失败（2026-09-14"发现列表 0 条"事故根因：
    classify 输出 4584 字符被截成 4096，LLM 与摘要提取都拿到坏 JSON）。

    因此这里截断的是*内容*而非*序列化字符串*，逐级降级：
      1. 收缩长字符串（保留 200 字符头部 + 标记）；
      2. 仍超限则收缩列表（20 → 10 → 5 → 3 保头）；
      3. 最后兜底返回带头部 preview 的标记对象（preview 本身是字符串值，
         整体仍为合法 JSON 且长度 ≤ max_chars）。
    """
    def _dumps(o: Any) -> str:
        return json.dumps(o, ensure_ascii=False, default=str)

    s = _dumps(obj)
    if len(s) <= max_chars:
        return s

    def _trim_strs(v):
        if isinstance(v, str):
            return v[:200] + "…[truncated]" if len(v) > 200 else v
        if isinstance(v, dict):
            return {k: _trim_strs(x) for k, x in v.items()}
        if isinstance(v, list):
            return [_trim_strs(x) for x in v]
        return v

    obj = _trim_strs(obj)
    s = _dumps(obj)
    if len(s) <= max_chars:
        return s

    def _trim_lists(v, cap):
        if isinstance(v, dict):
            return {k: _trim_lists(x, cap) for k, x in v.items()}
        if isinstance(v, list):
            return [_trim_lists(x, cap) for x in v[:cap]]
        return v

    for cap in (20, 10, 5, 3):
        obj = _trim_lists(obj, cap)
        s = _dumps(obj)
        if len(s) <= max_chars:
            return s

    # 兜底：标记 + 头部 preview（作为字符串值，整体仍是合法 JSON）
    preview_len = max(100, max_chars - 120)
    return json.dumps({
        "truncated": True,
        "note": f"output exceeded {max_chars} chars; head preview below",
        "preview": s[:preview_len],
    }, ensure_ascii=False)


# ---------------------------------------------------------------------------
# 1. reconnaissance
# ---------------------------------------------------------------------------
def _make_reconnaissance(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        targets = args.get("targets") or [ctx.target_url]
        if isinstance(targets, str):
            targets = [t.strip() for t in targets.replace(",", " ").split() if t.strip()]
        if not targets:
            targets = [ctx.target_url]

        result: Dict[str, Any] = {"subdomains": [], "endpoints": [], "tech": {}, "errors": []}
        domain = _host_from_url(targets[0])
        if not domain:
            non_loopback = {h for h in ctx.scope_hosts if h not in ("localhost", "127.0.0.1", "::1", "0.0.0.0")}
            domain = non_loopback.pop() if non_loopback else ""

        # --- 子域枚举（theharvester，工具缺失时优雅降级） ---
        if domain:
            try:
                from scanners.theharvester_wrapper import theharvester_recon
                th = theharvester_recon(domain, max_time=_THEHARVEST_TIMEOUT)
                subs = th.get("subdomains") or th.get("results") or []
                if isinstance(subs, list):
                    result["subdomains"] = [str(s) for s in subs[:50]]
                elif isinstance(subs, dict):
                    result["subdomains"] = list(subs.keys())[:50]
            except Exception as exc:
                result["errors"].append(f"theharvester: {type(exc).__name__}: {str(exc)[:120]}")

        # --- 端点爬取（crawler，异步） ---
        try:
            from scanners.crawler import crawl_url
            loop = asyncio.new_event_loop()
            try:
                cr = loop.run_until_complete(asyncio.wait_for(crawl_url(targets[0]), timeout=_CRAWL_TIMEOUT))
                urls = cr.get("urls") or cr.get("endpoints") or []
                if isinstance(urls, dict):
                    urls = list(urls.keys())
                result["endpoints"] = [str(u) for u in urls[:100]]
                if isinstance(cr.get("forms"), list):
                    result["forms"] = cr["forms"][:10]
            finally:
                loop.close()
        except Exception as exc:
            result["errors"].append(f"crawler: {type(exc).__name__}: {str(exc)[:120]}")

        # --- HTTP 指纹（Server/框架/标题） ---
        try:
            import requests as req
            url = targets[0] if targets[0].startswith("http") else f"https://{targets[0]}"
            r = req.get(url, timeout=_HTTP_TIMEOUT, allow_redirects=True,
                        headers={"User-Agent": "Mozilla/5.0 (hack-scanner-adaptive)"})
            tech = {
                "final_url": str(r.url),
                "status": r.status_code,
                "server": r.headers.get("Server", ""),
                "x_powered_by": r.headers.get("X-Powered-By", ""),
            }
            ct = (r.headers.get("Content-Type") or "").lower()
            if "html" in ct and r.text:
                import re as _re
                m = _re.search(r"<title[^>]*>(.*?)</title>", r.text, _re.I | _re.S)
                if m:
                    tech["title"] = m.group(1).strip()[:120]
            result["tech"] = tech
        except Exception as exc:
            result["errors"].append(f"fingerprint: {type(exc).__name__}: {str(exc)[:120]}")

        return (_json_safe_dumps(result, RECON_MAX_CHARS), None)

    return ToolDefinition(
        name="reconnaissance",
        description="Discover attack surface: subdomains, endpoints, forms, technology stack",
        parameters={"targets": "target URL or domain (defaults to campaign target)"},
        execute=execute,
    )


# ---------------------------------------------------------------------------
# 2. http_probe（自适应核心）
# ---------------------------------------------------------------------------
def _make_http_probe(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        url = str(args.get("url") or "").strip()
        if not url:
            return _err("ERROR: http_probe requires 'url'. Available args: url, method, headers, body, follow_redirects.")
        if not url.startswith(("http://", "https://")):
            url = "http://" + url

        host = _host_from_url(url)
        if not _in_scope(host, ctx):
            allowed = ", ".join(sorted(h for h in ctx.scope_hosts if h not in ("localhost", "127.0.0.1", "::1", "0.0.0.0")))
            return _err(
                f"ERROR: BLOCKED — host '{host}' is outside the authorized scope. "
                f"Allowed scope: {allowed}. Only probe URLs within this scope."
            )

        method = str(args.get("method") or "GET").upper()
        if method not in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
            method = "GET"
        headers = args.get("headers") or {}
        if not isinstance(headers, dict):
            headers = {}
        body = args.get("body")
        body_str = None
        if body is not None:
            body_str = body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)
        follow = bool(args.get("follow_redirects", True))

        # 限速（全局单例，per-domain 间隔）
        try:
            from rate_limiter import get_rate_limiter
            get_rate_limiter().wait(url)
        except Exception as exc:  # 限速器异常不应阻断探测
            logger.debug(f"rate_limiter skipped: {exc}")

        try:
            import requests as req
            start = time.time()
            r = req.request(
                method, url,
                headers=headers,
                data=body_str,
                allow_redirects=follow,
                timeout=_HTTP_TIMEOUT,
            )
            elapsed_ms = int((time.time() - start) * 1000)
            text = r.text or ""
            out = {
                "status": r.status_code,
                "final_url": str(r.url),
                "elapsed_ms": elapsed_ms,
                "headers": {k: v for k, v in list(r.headers.items())[:20]},
                "length": len(r.content),
                "body_excerpt": text[:PROBE_BODY_MAX] + ("...[truncated]" if len(text) > PROBE_BODY_MAX else ""),
            }
            return (json.dumps(out, ensure_ascii=False), None)
        except req.exceptions.Timeout:
            return _err(f"ERROR: request to {url} timed out after {_HTTP_TIMEOUT}s. Try a different endpoint or shorter timeout expectation.")
        except Exception as exc:
            return _err(f"ERROR: request failed: {type(exc).__name__}: {str(exc)[:200]}")

    return ToolDefinition(
        name="http_probe",
        description="Send a custom HTTP request and observe the response (status/headers/body). The core adaptive tool — use it to test specific hypotheses.",
        parameters={
            "url": "full URL to request (must be within campaign scope)",
            "method": "GET/POST/PUT/DELETE/etc (default GET)",
            "headers": "object of header name -> value",
            "body": "request body string (for POST/PUT)",
            "follow_redirects": "boolean (default true)",
        },
        execute=execute,
    )


# ---------------------------------------------------------------------------
# 3. classify
# ---------------------------------------------------------------------------
def _make_classify(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        findings = args.get("findings") or []
        if not isinstance(findings, list) or not findings:
            return _err("ERROR: classify requires 'findings': a non-empty list of objects with detail/evidence/type/target.")

        try:
            from scanners.swarm_classifier import RawFinding, classify_finding_set
            raws = []
            for i, f in enumerate(findings[:50]):
                if isinstance(f, dict):
                    raws.append(RawFinding(
                        id=str(f.get("id") or f"finding-{i}"),
                        detail=str(f.get("detail") or f.get("description") or f.get("title") or f.get("evidence") or ""),
                        raw_output=str(f.get("raw_output") or f.get("evidence") or ""),
                        type_=str(f.get("type_") or f.get("vuln_type") or f.get("type") or ""),
                        target=str(f.get("target") or f.get("url") or ctx.target_url),
                    ))
                else:
                    raws.append(f)
            classified = classify_finding_set(raws)
            from dataclasses import asdict, is_dataclass
            payload = asdict(classified) if is_dataclass(classified) else classified
            return (_json_safe_dumps(payload, RECON_MAX_CHARS), None)
        except Exception as exc:
            return _err(f"ERROR: classify failed: {type(exc).__name__}: {str(exc)[:200]}")

    return ToolDefinition(
        name="classify",
        description="Classify raw findings: false-positive filtering + CVSS v3.1 scoring. Input findings as list of {detail, evidence, type, target}.",
        parameters={"findings": "list of finding objects (detail/evidence/type/target)"},
        execute=execute,
    )


# ---------------------------------------------------------------------------
# 4. exploit（默认 dry-run）
# ---------------------------------------------------------------------------
def _make_exploit(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        command = str(args.get("command") or "").strip()
        if not command:
            return _err("ERROR: exploit requires 'command' — a single safe command (no shell metacharacters). "
                        "Example: 'curl -s http://target/admin'. Current mode: "
                        + ("DRY-RUN (preview only)" if ctx.dry_run else "LIVE (will execute!)"))

        try:
            from scanners.swarm_exploit_engine import Executor, AttackStep
            executor = Executor(
                scope_patterns=ctx.scope_patterns or None,
                dry_run=ctx.dry_run,
                safe_mode=True,
            )
            step = AttackStep(
                id=f"adaptive-{int(time.time())}",
                name=str(args.get("name") or "adaptive-step"),
                command=command,
                expected_output_pattern=str(args.get("expected_output_pattern") or ""),
            )
            result = executor.execute(step, campaign_id="swarm-adaptive")
            from dataclasses import asdict
            return (_json_safe_dumps(asdict(result), RECON_MAX_CHARS), None)
        except Exception as exc:
            return _err(f"ERROR: exploit failed: {type(exc).__name__}: {str(exc)[:200]}")

    return ToolDefinition(
        name="exploit",
        description=("Execute a single safe command against an in-scope target. "
                     + ("DRY-RUN mode: command is validated and previewed but NOT executed."
                        if ctx.dry_run else
                        "LIVE mode: command WILL be executed (still gated by safe-mode/scope/allowlist).")),
        parameters={
            "command": "single command, no shell metacharacters (|, ;, &, >, $, backtick)",
            "name": "short label for this step",
            "expected_output_pattern": "optional regex the output must match to count as success",
        },
        execute=execute,
    )


# ---------------------------------------------------------------------------
# 5. generate_report
# ---------------------------------------------------------------------------
def _make_report(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        findings = args.get("findings") or []
        if not isinstance(findings, list):
            return _err("ERROR: generate_report requires 'findings': a list of {title, severity, description, cvss_score}.")

        try:
            # M14: 富报告 — 把此前扫描结果（recon tech/子域/端点、classify 置信度/CVE/攻击面、
            # 工具异常、用时、LLM 模型）整合进报告；remediation/CWE 缺失字段由关键词规则
            # 确定性补全（LLM 显式传了则优先用 LLM 的），不依赖模型自觉传字段。
            # 老模板 swarm_report_generator 保留给其他消费方，本路径不再使用。
            from scanners import swarm_html_report as hr
            data = hr.build_report_data(
                target=ctx.target_url,
                objective=ctx.objective,
                findings_raw=findings,
                tool_log=ctx.tool_log or None,
                model_info=ctx.model_info,
                dry_run=ctx.dry_run,
                elapsed=(time.time() - ctx.started_at) if ctx.started_at else 0.0,
            )
            report_md = hr.render_markdown(data)
            report_html = hr.render_html(data)

            ts = time.strftime("%Y%m%d-%H%M%S")
            html_path = os.path.join(ctx.report_dir, f"adaptive_{ts}.html")
            md_path = os.path.join(ctx.report_dir, f"adaptive_{ts}.md")
            with open(html_path, "w", encoding="utf-8") as fh:
                fh.write(report_html)
            with open(md_path, "w", encoding="utf-8") as fh:
                fh.write(report_md)

            out = {
                "report_path": html_path,   # 主报告（HTML）；run_adaptive._extract_report_path 提取此键
                "report_md": md_path,       # Markdown 副报告
                "length": len(report_md),
                "preview": report_md[:REPORT_INLINE_MAX] + ("...[truncated]" if len(report_md) > REPORT_INLINE_MAX else ""),
            }
            return (json.dumps(out, ensure_ascii=False), None)
        except Exception as exc:
            return _err(f"ERROR: report generation failed: {type(exc).__name__}: {str(exc)[:200]}")

    return ToolDefinition(
        name="generate_report",
        description=("Generate the final pentest report (HTML main + Markdown companion) with risk rating, "
                     "auto-completed remediation/CWE, tech stack / subdomains / endpoints scan surface and "
                     "prior tool results. Saves to disk and returns path + preview."),
        parameters={
            "findings": "list of confirmed findings {title, severity, description, cvss_score, evidence} "
                        "(remediation optional — auto-completed if omitted)",
        },
        execute=execute,
    )


# ---------------------------------------------------------------------------
# 6. finish_scan（orchestrator 按名字拦截，execute 仅为占位）
# ---------------------------------------------------------------------------
def _make_finish_scan(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        return (f"finish_scan accepted — campaign terminated. Summary: {str(args.get('summary') or '(none)')[:500]}", None)

    return ToolDefinition(
        name="finish_scan",
        description=("LIFECYCLE: terminate the campaign. Call exactly once, when the objective "
                     "is reached or all attack paths are exhausted. This is the ONLY way to end the run."),
        parameters={
            "summary": "executive summary of the campaign",
            "complete": "boolean — true only if all planned phases finished",
        },
        execute=execute,
    )


# ---------------------------------------------------------------------------
# 总入口
# ---------------------------------------------------------------------------
def register_campaign_tools(
    orchestrator,
    target_url: str,
    objective: str = "find all vulnerabilities",
    dry_run: bool = True,
) -> CampaignContext:
    """给 orchestrator 注册全部真实工具。返回 CampaignContext（供入口层读报告目录等）。

    先注册 6 个核心工具（自适应闭环的骨架），再挂载辅助工具箱
    （swarm_aux_tools：按需调用成熟检测模块）。辅助层是【可选增强】——
    若其 import 失败（如缺依赖），只降级并告警，核心 6 工具不受影响。
    """
    ctx = build_context(target_url, objective, dry_run)
    orchestrator.register_tool(_make_reconnaissance(ctx))
    orchestrator.register_tool(_make_http_probe(ctx))
    orchestrator.register_tool(_make_classify(ctx))
    orchestrator.register_tool(_make_exploit(ctx))
    orchestrator.register_tool(_make_report(ctx))
    orchestrator.register_tool(_make_finish_scan(ctx))

    aux_count = 0
    try:
        from scanners.swarm_aux_tools import register_aux_tools
        aux_count = register_aux_tools(orchestrator, ctx)
    except Exception as exc:
        logger.warning(f"辅助工具箱加载失败（跳过，核心 6 工具可用）: {type(exc).__name__}: {str(exc)[:160]}")

    total = 6 + aux_count
    logger.info(f"已注册 {total} 个 campaign 工具（含辅助 {aux_count}）| scope={ctx.scope_patterns} | dry_run={ctx.dry_run}")
    return ctx


if __name__ == "__main__":
    # 自测: 注册到空 orchestrator 并检查工具清单
    from scanners.swarm_orchestrator import SwarmOrchestrator
    orch = SwarmOrchestrator(llm_invoke=lambda **kw: None)
    c = register_campaign_tools(orch, "http://localhost:8000", dry_run=True)
    print("tools:", list(orch.tools.keys()))
    print("scope:", c.scope_hosts)
