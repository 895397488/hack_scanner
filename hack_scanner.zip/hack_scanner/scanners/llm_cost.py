#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM 成本核算 (LLM Cost Accounting)
==================================
借鉴 Strix v1.6.2 (usestrix/strix, Apache-2.0) 的:
  - strix/report/usage.py   — LLMUsageLedger（按 agent 聚合 + token 占比分摊）
  - strix/report/pricing.py — 模型名解析为可计价的规范名

Findings 回答"发现了什么"，Coverage 回答"检查了什么"，
成本账回答**"这次扫描花了多少钱"**——审计与排期决策都需要它：
一次"零 SQL 注入"的扫描，如果烧了 20 美元、一次"发现 3 个高危"的扫描只花 2 美元，
两者在报告里必须各自诚实标注，否则无法比较单位产出。

Strix 用 LiteLLM 查价；hack_scanner 走裸 requests（无 LiteLLM 依赖），
因此本模块自包含一份**内置计价表**（每 1M token 的 USD 价），
并允许 ``config.json → ai.cost_tracking.prices_per_mtok`` 覆盖/扩展。

三个 Strix 设计细节（本模块全部保留）:
  1. **observed 优先 estimated**：provider 直接回了 cost 就以它为准，
     否则才用计价表估算；两者都无 → 记 $0 但**仍记 token**（诚实，不瞎猜价）
  2. **按 agent 拆分**：每次 record 带 agent_id，账本按 agent 汇总
     token/call/费用，报告里逐 agent 列出
  3. **本地/订阅模型零计费**：未知模型（含 Ollama/vLLM 本地模型）
     查不到价 → cost $0、``cost_basis="none"``，但 token 全额计入——
     读者能区分"本地跑，无按量费用"与"云端烧了 N 美元"

hack_scanner 适配:
  - 单进程为主（ai_analyzer 的 ``_call_llm`` 是唯一 LLM 收口），
    swarm 多 agent 也可各自 record，按 agent_id 归并
  - 线程安全（RLock）+ 原子写 + 断点续扫 hydrate，与 coverage_ledger 同惯例
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

COST_FILENAME = "llm_cost.json"
COST_SCHEMA_VERSION = 1
CURRENCY = "USD"

#: 内置计价表 — 每 1M token 的 USD 价 {"input": 每1M输入, "output": 每1M输出}。
#: 覆盖 hack_scanner PROVIDER_DB 支持的主流云端模型；版本化模型走**最长前缀**匹配
#: （qwen-max-2025-01-25 → qwen-max；gpt-4o-mini 优先于 gpt-4o）。
#: 未命中的模型 → 不计价（cost $0，token 仍记），绝不瞎猜。
DEFAULT_PRICING_PER_MTK: Dict[str, Dict[str, float]] = {
    # Anthropic Claude
    "claude-opus-4-1":   {"input": 15.0, "output": 75.0},
    "claude-opus-4":     {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-5": {"input": 3.0,  "output": 15.0},
    "claude-sonnet-4":   {"input": 3.0,  "output": 15.0},
    "claude-haiku-4-5":  {"input": 1.0,  "output": 5.0},
    "claude-3-5-haiku":  {"input": 0.80, "output": 4.0},
    # OpenAI
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4o":      {"input": 2.50, "output": 10.0},
    "gpt-4.1":     {"input": 2.00, "output": 8.0},
    "gpt-4.1-mini": {"input": 0.40, "output": 1.60},
    "o1":          {"input": 15.0, "output": 60.0},
    "o3-mini":     {"input": 1.10, "output": 4.40},
    # DeepSeek
    "deepseek-reasoner": {"input": 0.55, "output": 2.19},
    "deepseek-chat":     {"input": 0.27, "output": 1.10},
    # 阿里 Qwen (DashScope)
    "qwen-max":  {"input": 2.40, "output": 9.60},
    "qwen-plus": {"input": 0.40, "output": 1.20},
    "qwen-turbo": {"input": 0.03, "output": 0.06},
    "qwen-long": {"input": 0.05, "output": 0.20},
    # 智谱 GLM
    "glm-4-plus":  {"input": 0.50, "output": 5.00},
    "glm-4-flash": {"input": 0.10, "output": 1.00},
    "glm-4.5":     {"input": 0.80, "output": 2.50},
    # Moonshot Kimi
    "moonshot-v1-128k": {"input": 0.20, "output": 0.20},
    "moonshot-v1-32k":  {"input": 0.06, "output": 0.06},
    "moonshot-v1-8k":   {"input": 0.011, "output": 0.011},
    # Google Gemini
    "gemini-2.5-pro":     {"input": 1.25, "output": 10.0},
    "gemini-2.5-flash":   {"input": 0.30, "output": 2.50},
    "gemini-1.5-pro":     {"input": 1.25, "output": 5.0},
    "gemini-1.5-flash":   {"input": 0.075, "output": 0.30},
}

#: 剥离的 provider 前缀（OpenAI 兼容网关常带）
_PROVIDER_PREFIXES = ("litellm/", "any-llm/", "openai/", "anthropic/", "bedrock/", "vertex/")

_DEFAULT_AGENT = "ai-analyzer"
_ROUND_DIGITS = 10


# ---------------------------------------------------------------------------
# 计价表 + 查价
# ---------------------------------------------------------------------------

def _merge_pricing(override: Optional[Dict[str, Dict[str, float]]]) -> Tuple[Dict[str, Dict[str, float]], str]:
    """内置表 ⊕ config 覆盖（config 胜出）。返回 (pricing, source 说明)。"""
    if not override:
        return dict(DEFAULT_PRICING_PER_MTK), "builtin"
    merged = dict(DEFAULT_PRICING_PER_MTK)
    clean: Dict[str, Dict[str, float]] = {}
    for k, v in override.items():
        if not isinstance(v, dict):
            continue
        try:
            in_p = float(v.get("input") or 0.0)
            out_p = float(v.get("output") or 0.0)
        except (TypeError, ValueError):
            continue
        if in_p < 0 or out_p < 0:  # 非法配置 → 丢弃该模型回退内置表，绝不静默改成 $0
            continue
        clean[str(k)] = {"input": in_p, "output": out_p}
    if clean:
        merged.update(clean)
        return merged, "config+builtin"
    return dict(DEFAULT_PRICING_PER_MTK), "builtin"


def _model_candidates(model: str) -> List[str]:
    """展开 model 的候选名（剥 provider 前缀、取 '/' 后的裸名），去重保序。"""
    out: List[str] = []
    m = (model or "").strip()
    if not m:
        return out
    for p in _PROVIDER_PREFIXES:
        if m.startswith(p):
            m = m[len(p):]
            break
    for cand in (m, m.rsplit("/", 1)[-1] if "/" in m else ""):
        cand = cand.strip()
        if cand and cand not in out:
            out.append(cand)
    return out


def _match_price_key(pricing: Dict[str, Dict[str, float]], model: str) -> Optional[str]:
    """最长前缀匹配：qwen-max-2025-01-25→qwen-max，gpt-4o-mini 优先于 gpt-4o。"""
    best: Optional[str] = None
    for cand in _model_candidates(model):
        for key in pricing:
            if cand == key or cand.startswith(key):
                if best is None or len(key) > len(best):
                    best = key
    return best


def estimate_cost(pricing: Dict[str, Dict[str, float]], model: str,
                  prompt_tokens: int, completion_tokens: int) -> Optional[float]:
    """按计价表估算一次调用的费用（USD）。查不到价 → None（不瞎猜）。"""
    key = _match_price_key(pricing, model)
    if not key:
        return None
    p = pricing.get(key) or {}
    in_p = _float_or_zero(p.get("input"))
    out_p = _float_or_zero(p.get("output"))
    if in_p == 0.0 and out_p == 0.0:
        return None
    cost = (max(0, prompt_tokens) / 1_000_000.0) * in_p + (max(0, completion_tokens) / 1_000_000.0) * out_p
    return _round_cost(cost)


def _round_cost(cost: float) -> float:
    try:
        return round(max(0.0, float(cost)), _ROUND_DIGITS)
    except (TypeError, ValueError):
        return 0.0


def _float_or_zero(value: Any) -> float:
    try:
        r = float(value or 0.0)
    except (TypeError, ValueError):
        return 0.0
    return r if r >= 0 else 0.0


def _int_or_zero(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------
# LLMCostLedger — 线程安全的共享成本账本
# ---------------------------------------------------------------------------

class LLMCostLedger:
    """扫描共享的 LLM 成本账本。

    - ``record``: 记一次 LLM 调用的 token（+ 可选 provider 直接回的 cost）
    - 按 agent_id 汇总 token/call/费用
    - 可选磁盘持久化（原子写，断点续扫 hydrate）
    """

    def __init__(self, persist_path: Optional[str] = None,
                 pricing: Optional[Dict[str, Dict[str, float]]] = None):
        self._lock = threading.RLock()
        self._persist_path = persist_path
        self._pricing, self._pricing_source = _merge_pricing(pricing)
        self._agents: Dict[str, Dict[str, Any]] = {}
        self._calls = 0
        self._prompt_tokens = 0
        self._completion_tokens = 0
        if persist_path and os.path.exists(persist_path):
            self.hydrate(persist_path)

    # ---- 内部 ----

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    def _agent_bucket(self, agent_id: str) -> Dict[str, Any]:
        aid = str(agent_id or _DEFAULT_AGENT).strip() or _DEFAULT_AGENT
        b = self._agents.get(aid)
        if b is None:
            b = {"agent_id": aid, "agent_name": aid, "model": "",
                 "calls": 0, "prompt_tokens": 0, "completion_tokens": 0,
                 "estimated_cost": 0.0, "observed_cost": 0.0, "no_price_calls": 0}
            self._agents[aid] = b
        return b

    def _persist_locked(self) -> None:
        """镜像到磁盘（原子写）。调用方必须已持有 ``_lock``。"""
        path = self._persist_path
        if not path:
            return
        try:
            payload = json.dumps(self._snapshot_locked(), ensure_ascii=False, default=str)
            d = os.path.dirname(os.path.abspath(path))
            os.makedirs(d, exist_ok=True)
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=d,
                prefix=f".{os.path.basename(path)}.", suffix=".tmp", delete=False,
            ) as tmp:
                tmp.write(payload)
                tmp_path = tmp.name
            os.replace(tmp_path, path)
        except Exception:
            logger.exception("llm cost persist to %s failed", path)

    def _snapshot_locked(self) -> Dict[str, Any]:
        return {
            "schema_version": COST_SCHEMA_VERSION,
            "agents": {aid: dict(b) for aid, b in self._agents.items()},
            "calls": self._calls,
            "prompt_tokens": self._prompt_tokens,
            "completion_tokens": self._completion_tokens,
        }

    # ---- 对外 API ----

    def record(self, agent: str = "", model: str = "",
               prompt_tokens: int = 0, completion_tokens: int = 0,
               observed_cost: float = 0.0) -> Dict[str, Any]:
        """记一次 LLM 调用的 token 用量。

        Args:
            agent:          记账的 agent/调用方标识（默认 ai-analyzer）
            model:          模型名（用于查价；本地模型查不到价 → 仍记 token，cost $0）
            prompt_tokens:  输入 token
            completion_tokens: 输出 token
            observed_cost:  provider 直接返回的费用（若 >0 优先于估算）
        """
        prompt = _int_or_zero(prompt_tokens)
        completion = _int_or_zero(completion_tokens)
        observed = _float_or_zero(observed_cost)
        if prompt == 0 and completion == 0 and observed <= 0.0:
            return {"ok": True, "recorded": False, "reason": "no_usage"}

        est = 0.0
        with self._lock:
            b = self._agent_bucket(agent)
            if (model or "").strip():
                b["model"] = str(model).strip()
            b["calls"] += 1
            b["prompt_tokens"] += prompt
            b["completion_tokens"] += completion
            self._calls += 1
            self._prompt_tokens += prompt
            self._completion_tokens += completion

            if observed > 0.0:
                b["observed_cost"] += _round_cost(observed)
            else:
                est = estimate_cost(self._pricing, model, prompt, completion) or 0.0
                if est > 0.0:
                    b["estimated_cost"] += est
                else:
                    b["no_price_calls"] += 1
            self._persist_locked()

        return {"ok": True, "recorded": True, "agent": str(agent or _DEFAULT_AGENT),
                "estimated": _round_cost(est), "model": model or ""}

    def totals(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "calls": self._calls,
                "prompt_tokens": self._prompt_tokens,
                "completion_tokens": self._completion_tokens,
                "total_tokens": self._prompt_tokens + self._completion_tokens,
            }

    def clear(self) -> None:
        with self._lock:
            self._agents.clear()
            self._calls = 0
            self._prompt_tokens = 0
            self._completion_tokens = 0
            self._persist_locked()

    def hydrate(self, path: str) -> int:
        """从磁盘恢复账本（断点续扫用）。返回恢复的 agent 数。"""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            logger.exception("llm cost state at %s unreadable; starting empty", path)
            return 0
        with self._lock:
            self._agents.clear()
            self._calls = 0
            self._prompt_tokens = 0
            self._completion_tokens = 0
            if isinstance(data, dict):
                self._calls = _int_or_zero(data.get("calls"))
                self._prompt_tokens = _int_or_zero(data.get("prompt_tokens"))
                self._completion_tokens = _int_or_zero(data.get("completion_tokens"))
                for aid, b in (data.get("agents") or {}).items():
                    if isinstance(aid, str) and isinstance(b, dict):
                        self._agents[aid] = {
                            "agent_id": aid,
                            "agent_name": str(b.get("agent_name") or aid),
                            "model": str(b.get("model") or ""),
                            "calls": _int_or_zero(b.get("calls")),
                            "prompt_tokens": _int_or_zero(b.get("prompt_tokens")),
                            "completion_tokens": _int_or_zero(b.get("completion_tokens")),
                            "estimated_cost": _float_or_zero(b.get("estimated_cost")),
                            "observed_cost": _float_or_zero(b.get("observed_cost")),
                            "no_price_calls": _int_or_zero(b.get("no_price_calls")),
                        }
            n = len(self._agents)
        logger.info("llm cost ledger hydrated from %s (%d agent(s))", path, n)
        return n

    def to_record(self, *, run_id: str = "", currency: str = CURRENCY,
                  notes: Optional[List[str]] = None) -> Dict[str, Any]:
        """汇总为可落盘 / 入报告的 dict（含逐 agent 拆分）。"""
        with self._lock:
            agents_out: List[Dict[str, Any]] = []
            total_est = 0.0
            total_obs = 0.0
            for aid in sorted(self._agents):
                b = dict(self._agents[aid])
                total_est += _float_or_zero(b.get("estimated_cost"))
                total_obs += _float_or_zero(b.get("observed_cost"))
                agent_cost = _float_or_zero(b.get("observed_cost")) or _float_or_zero(b.get("estimated_cost"))
                basis = "observed" if _float_or_zero(b.get("observed_cost")) > 0 else (
                    "estimated" if _float_or_zero(b.get("estimated_cost")) > 0 else "none")
                agents_out.append({
                    "agent_id": b.get("agent_id", aid),
                    "agent_name": b.get("agent_name") or aid,
                    "model": b.get("model", ""),
                    "calls": _int_or_zero(b.get("calls")),
                    "prompt_tokens": _int_or_zero(b.get("prompt_tokens")),
                    "completion_tokens": _int_or_zero(b.get("completion_tokens")),
                    "total_tokens": _int_or_zero(b.get("prompt_tokens")) + _int_or_zero(b.get("completion_tokens")),
                    "cost": _round_cost(agent_cost),
                    "cost_basis": basis,
                    "no_price_calls": _int_or_zero(b.get("no_price_calls")),
                })

            total_prompt = self._prompt_tokens
            total_completion = self._completion_tokens
            total_cost = total_obs if total_obs > 0 else total_est
            basis = "observed" if total_obs > 0 else ("estimated" if total_est > 0 else "none")

            return {
                "schema_version": COST_SCHEMA_VERSION,
                "generated_at": self._now(),
                "run_id": run_id,
                "currency": currency,
                "totals": {
                    "calls": self._calls,
                    "prompt_tokens": total_prompt,
                    "completion_tokens": total_completion,
                    "total_tokens": total_prompt + total_completion,
                    "cost": _round_cost(total_cost),
                    "cost_basis": basis,
                    "estimated_cost": _round_cost(total_est),
                    "observed_cost": _round_cost(total_obs),
                },
                "agents": agents_out,
                "pricing_source": self._pricing_source,
                "notes": notes or [],
            }

    def __len__(self) -> int:
        with self._lock:
            return len(self._agents)


# ---------------------------------------------------------------------------
# 落盘 + Markdown 章节
# ---------------------------------------------------------------------------

def write_cost(output_dir: str, record: Dict[str, Any]) -> str:
    """原子写 llm_cost.json 到 output_dir，返回路径。"""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, COST_FILENAME)
    payload = json.dumps(record, ensure_ascii=False, indent=2, default=str)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8",
        dir=os.path.abspath(output_dir),
        prefix=f".{COST_FILENAME}.", suffix=".tmp", delete=False,
    ) as tmp:
        tmp.write(payload)
        tmp_path = tmp.name
    os.replace(tmp_path, path)
    t = record.get("totals", {})
    logger.info("Saved LLM cost record to %s (%d call(s), $%.4f)",
                path, t.get("calls", 0), t.get("cost", 0.0))
    return path


def _fmt_money(v: Any) -> str:
    try:
        return f"${float(v or 0.0):,.4f}".rstrip("0").rstrip(".") if float(v or 0.0) else "$0"
    except (TypeError, ValueError):
        return "$0"


def render_cost_section(record: Dict[str, Any]) -> str:
    """把成本记录渲染成报告里的"本次扫描 AI 成本"章节（中文）。"""
    t = record.get("totals", {})
    agents = record.get("agents", [])
    basis = t.get("cost_basis", "none")
    cur = record.get("currency", CURRENCY)
    cost = _float_or_zero(t.get("cost"))

    lines: List[str] = []
    lines.append("## 本次扫描 AI 成本 (LLM Cost)")
    lines.append("")
    if t.get("calls", 0) == 0:
        lines.append("> 本次扫描**未发生** LLM 调用（AI 分析未启用或全部走本地规则引擎），无 token 消耗、无费用。")
        lines.append("")
        return "\n".join(lines)

    basis_note = {
        "observed": "provider 直接返回的费用（观测值，最准确）",
        "estimated": "按内置计价表估算（近似值，以实际账单为准）",
        "none": "无按量计费（本地模型 / 未定价模型）— token 已计入，费用记 0",
    }.get(basis, basis)

    lines.append("| 指标 | 值 |")
    lines.append("|---|---|")
    lines.append(f"| 调用次数 (calls) | {t.get('calls', 0)} |")
    lines.append(f"| 输入 token | {t.get('prompt_tokens', 0):,} |")
    lines.append(f"| 输出 token | {t.get('completion_tokens', 0):,} |")
    lines.append(f"| 合计 token | {t.get('total_tokens', 0):,} |")
    lines.append(f"| **总费用** | **{_fmt_money(cost)} {cur}** |")
    lines.append(f"| 计价依据 | {basis_note} |")
    lines.append("")

    if len(agents) > 1:
        lines.append("### 按 agent 拆分")
        lines.append("")
        lines.append("| agent | 模型 | 调用 | token | 费用 | 依据 |")
        lines.append("|---|---|---|---|---|---|")
        for a in agents:
            basis_zh = {"observed": "观测", "estimated": "估算", "none": "无计费"}.get(a.get("cost_basis", ""), "—")
            lines.append(
                f"| {a.get('agent_name', '')} | {a.get('model') or '—'} "
                f"| {a.get('calls', 0)} | {a.get('total_tokens', 0):,} "
                f"| {_fmt_money(a.get('cost'))} {cur} | {basis_zh} |"
            )
        lines.append("")

    no_price = [a for a in agents if a.get("no_price_calls", 0) > 0]
    if no_price:
        names = ", ".join(a.get("model") or a.get("agent_name", "?") for a in no_price)
        lines.append(f"> 注：{names} 等模型无公开定价/为本地模型，其 token 已计入但费用记 0（不估算）。")
        lines.append("")
    if record.get("notes"):
        for n in record["notes"]:
            lines.append(f"> {n}")
        lines.append("")
    lines.append(f"> 计价来源：{record.get('pricing_source', 'builtin')}；币种 {cur}。"
                 "估算值仅供排期参考，实际以各平台账单为准。")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 模块级默认账本 + 便捷函数（MCP 工具 / ai_analyzer / 脚本入口用）
# ---------------------------------------------------------------------------

#: 默认状态文件 — 断点续扫时 hydrate（落在 CWD/hack_report，不污染项目目录）
DEFAULT_STATE_PATH = os.path.join("hack_report", ".llm_cost.json")

#: 项目根 config.json（scanners/ 上一级）— 读取 ai.cost_tracking.prices_per_mtok
_PROJECT_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")

_default_ledger: Optional[LLMCostLedger] = None
_default_lock = threading.Lock()


def load_pricing_from_config(config_path: str = _PROJECT_CONFIG_PATH
                             ) -> Optional[Dict[str, Dict[str, float]]]:
    """读 ``config.json → ai.cost_tracking.prices_per_mtok``（未配置/读失败 → None）。"""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        prices = ((cfg.get("ai") or {}).get("cost_tracking") or {}).get("prices_per_mtok")
        return prices if isinstance(prices, dict) else None
    except (OSError, json.JSONDecodeError):
        logger.debug("llm cost: pricing config unreadable at %s", config_path)
        return None


def get_default_cost_ledger(state_path: str = DEFAULT_STATE_PATH,
                            pricing: Optional[Dict[str, Dict[str, float]]] = None) -> LLMCostLedger:
    """进程内共享的默认成本账本（首次调用时从状态文件恢复）。

    ``pricing`` 未显式给出时，自动加载 ``config.json → ai.cost_tracking.prices_per_mtok``。
    """
    global _default_ledger
    with _default_lock:
        if _default_ledger is None:
            if pricing is None:
                pricing = load_pricing_from_config()
            _default_ledger = LLMCostLedger(persist_path=state_path, pricing=pricing)
        return _default_ledger


def reset_default_cost_ledger() -> None:
    """清空默认账本（新扫描开始时调用）。状态文件一并清空。"""
    global _default_ledger
    with _default_lock:
        if _default_ledger is not None:
            _default_ledger.clear()
        _default_ledger = None


def record_llm_usage(agent: str = "", model: str = "",
                     prompt_tokens: int = 0, completion_tokens: int = 0,
                     observed_cost: float = 0.0) -> Dict[str, Any]:
    """记账便捷入口（默认账本）。永不抛异常——成本核算不能拖垮 LLM 调用。"""
    try:
        return get_default_cost_ledger().record(
            agent=agent, model=model,
            prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
            observed_cost=observed_cost,
        )
    except Exception:
        logger.exception("record_llm_usage failed (ignored)")
        return {"ok": False, "recorded": False, "error": "record_failed"}


def close_default_ledger() -> None:
    """释放默认账本引用（测试用）。"""
    global _default_ledger
    with _default_lock:
        _default_ledger = None
