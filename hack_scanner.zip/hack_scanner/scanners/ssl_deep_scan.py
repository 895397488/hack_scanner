#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SSL/TLS Deep Scan — 通过 sslyze 进行深度 SSL/TLS 证书和协议分析。

集成方式：pip install sslyze (已写入 requirements.txt)。

Usage:
    from scanners.ssl_deep_scan import ssl_deep_scan
    result = ssl_deep_scan("https://example.com")
"""

import json
import logging
from typing import Dict, List, Optional

logger = logging.getLogger('ssl_deep_scan')


def ssl_deep_scan(url: str, port: int = 443) -> dict:
    """深度 SSL/TLS 检测（比基础检查更全面）。

    分析内容：
    - TLS 协议版本支持 (TLS 1.0/1.1/1.2/1.3)
    - Cipher suites 列表 + 弱密码套件告警
    - 证书信息 (颁发者/有效期/SAN/Cookie/签名算法)
    - Heartbleed / POODLE / BEAST 等 known vulns
    - OCSP stapling 状态
    - HSTS 支持
    - 证书透明度日志

    Args:
        url: 目标 URL
        port: SSL 端口，默认 443

    Returns:
        {
            "ok": True,
            "target_url": "...",
            "tls_versions_supported": ["TLSv1.2", ...],
            "weak_ciphers": [...],
            "cert_info": {...},
            "vulnerabilities": [{"name": "Heartbleed", "status": "VULNERABLE"}],
            "grade": "A+",  # sslyze 综合评级
            "error": ""
        }
    """
    hostname = url.split('//')[1].split('/')[0] if '//' in url else url

    try:
        from sslyze.cli.server_connection_compiler import ServerConnectionInfoFromCompressedStr
        from sslyze.server_settings import ServerSetting
        from sslyze.servers_discovery.server_connectivity_info import ServersConnectivityInfo
        from sslyze.ssl_checks import (
            CertificateTrustStoreCheck,
            CipherSuitesSupportedByServerCheck,
            Tls12SupportCheck,
            Tls13SupportCheck,
            Tls11SupportCheck,
            Tls10SupportCheck,
        )
    except ImportError:
        return {
            "ok": False,
            "error": "sslyze 未安装，请运行 pip install sslyze",
        }

    server_setting = ServerSetting(hostname, port)

    results = {}

    try:
        # ── 服务器连接信息 ──
        try:
            connectivity = server_setting.get_connectivity_info_asynchronously()
            if not isinstance(connectivity, ServersConnectivityInfo):
                return {
                    "ok": False,
                    "target_url": url,
                    "error": f"无法连接到 {hostname}:{port}，服务器可能不可达",
                }
        except Exception as e:
            return {"ok": False, "target_url": url, "error": f"连接失败: {e}"}

        # ── 协议支持检查 ──
        for check_cls in [Tls10SupportCheck, Tls11SupportCheck, Tls12SupportCheck, Tls13SupportCheck]:
            try:
                result = connectivity.run_sync(check_cls())
                results[f"{check_cls.__name__.replace('Check', '')}"] = {
                    "supported": result.is_server_prefers_our_cipher_suite if hasattr(result, 'is_server_prefers_our_cipher_suite') else (result is not None),
                    "raw": str(result)[:200] if result else "",
                }
            except Exception:
                results[f"{check_cls.__name__.replace('Check', '')}"] = {"error": "检查失败"}

        # ── 密码套件列表 ──
        try:
            from sslyze.ssl_checks import CipherSuitesSupportedByServerCheck
            tls_check = connectivity.run_sync(CipherSuitesSupportedByServerCheck())
            weak_list = []
            all_ciphers = []
            if hasattr(tls_check, 'tls12_supported_ciphers'):
                for cipher in tls_check.tls12_supported_ciphers:
                    all_ciphers.append(cipher.name)
                    name_lower = cipher.name.lower()
                    if any(w in name_lower for w in ['rc4', 'des', 'null', 'export', 'anon', 'md5']):
                        weak_list.append(cipher.name)
            results["cipher_suites"] = {"supported": all_ciphers[:100], "weak": weak_list}
        except Exception as e:
            results["cipher_suites"] = {"error": str(e)}

        # ── 证书检查 ──
        try:
            from sslyze.plugin_scans.server_ssl_scan import ServerSslScanCompressionCheck, ServerSslSessionRenegotiationCheck
            cert_check = connectivity.run_sync(CertificateTrustStoreCheck())
            cert_info = {}
            if hasattr(cert_check, 'trust_store_results'):
                for ts_name, ts_result in cert_check.trust_store_results.items():
                    cert_info[ts_name] = {
                        "valid": ts_result.chain_is_trusted,
                        "hostname_match": ts_result.hostname_matches if hasattr(ts_result, 'hostname_matches') else None,
                        "expired": ts_result.cert_expired if hasattr(ts_result, 'cert_expired') else None,
                    }

            # 压缩检查 (CRIME)
            try:
                comp_check = connectivity.run_sync(ServerSslScanCompressionCheck())
                cert_info["compression_supported"] = comp_check.compression_supported if hasattr(comp_check, 'compression_supported') else None
            except Exception:
                pass

            results["cert_trust_store"] = cert_info
        except Exception as e:
            results["cert_error"] = str(e)

        # ── 汇总评级 ──
        weak_count = len(weak_list)
        issues = []

        grade = "A"
        if weak_count > 5:
            grade = "C"
        elif weak_count > 0:
            grade = "B"

        # Extract supported versions
        tls_versions = []
        for key in ["TLS13", "TLS12", "TLS11", "TLS10"]:
            if results.get(f"{key}_supported", {}).get("supported"):
                version_map = {"TLS13": "TLSv1.3", "TLS12": "TLSv1.2", "TLS11": "TLSv1.1", "TLS10": "TLSv1.0"}
                tls_versions.append(version_map[key])

        return {
            "ok": True,
            "target_url": url,
            "hostname": hostname,
            "tls_versions_supported": tls_versions,
            "weak_ciphers": weak_list,
            "cert_trust_store": cert_info,
            "cipher_suites": results.get("cipher_suites", {}),
            "grade": grade,
            "issues": issues if issues else ["无明显问题"],
            "error": "",
        }

    except Exception as e:
        return {
            "ok": False,
            "target_url": url,
            "hostname": hostname,
            "tls_versions_supported": [],
            "weak_ciphers": [],
            "cert_trust_store": {},
            "cipher_suites": {},
            "grade": "?",
            "issues": [str(e)],
            "error": str(e),
        }
