#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File Metadata Analyzer — 提取文件元数据（EXIF、文档属性）、隐写检测。

用途：文件/照片分析场景（授权渗透测试 / CTF）。

Usage:
    from scanners.file_meta import file_metadata, check_steganography
    result = file_metadata("/path/to/photo.jpg")
"""

import json
import logging
import os
import subprocess
import struct
from typing import Dict, List, Optional

logger = logging.getLogger('file_meta')


def file_metadata(file_path: str) -> dict:
    """提取文件元数据（图片 EXIF、文档属性等）。

    Args:
        file_path: 文件路径

    Returns:
        {
            "ok": True,
            "file_path": "...",
            "is_image": True/False,
            "image_info": {"width": ..., "height": ...},
            "exif": {...},
            "document_meta": {...},  # docx/pptx/pdf 属性
            "error": ""
        }
    """
    result = {
        "ok": False,
        "file_path": file_path,
        "is_image": False,
        "image_info": {},
        "exif": {},
        "document_meta": {},
        "stego_suspects": [],
        "error": "",
    }

    if not os.path.isfile(file_path):
        return {**result, "ok": False, "error": f"文件不存在: {file_path}"}

    file_size = os.path.getsize(file_path)
    result["file_size"] = file_size

    # ── EXIF 图片分析 ──
    image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.tiff', '.bmp', '.webp', '.svg'}
    ext = os.path.splitext(file_path)[1].lower()

    if ext in image_extensions:
        result["is_image"] = True
        try:
            import exifread
            with open(file_path, 'rb') as f:
                tags = exifread.process_file(f, details=False, verbose=True)
            exif_data = {}
            for tag, value in tags.items():
                # 跳过二进制值
                val_str = str(value)
                if len(val_str) > 2000:
                    val_str = val_str[:2000] + "...(truncated)"
                exif_data[str(tag)] = val_str

            # 关键 EXIF 字段
            key_fields = {
                'Image Make': 'camera_make',
                'Image Model': 'camera_model',
                'EXIF DateTimeOriginal': 'datetime_original',
                'GPS GPSLatitude': 'gps_latitude',
                'GPS GPSLongitude': 'gps_longitude',
                'GPS GPSAltitude': 'gps_altitude',
                'Image Software': 'software',
                'Image Artist': 'artist',
                'Image Copyright': 'copyright',
                'Image Description': 'description',
            }
            result["exif"] = {
                "full": exif_data,
                "key_fields": {},
            }
            for key, field_name in key_fields.items():
                if key in exif_data:
                    result["exif"]["key_fields"][field_name] = exif_data[key][:500]

            # GPS 坐标提取
            try:
                lat = exifread.get('GPS GPSLatitude', tags)
                lon = exifread.get('GPS GPSLongitude', tags)
                if lat and lon:
                    result["exif"]["key_fields"]["gps_coordinates"] = f"{lat}, {lon}"
            except Exception:
                pass

        except ImportError:
            pass
        except Exception as e:
            logger.warning(f"EXIF 提取失败: {e}")

        # ── Steganography 可疑指标 ──
        stego_suspects = _check_stego_indicators(file_path, ext)
        result["stego_suspects"] = stego_suspects

    # ── Office/PDF 文档属性 ──
    doc_extensions = {'.docx', '.xlsx', '.pptx', '.pdf'}
    if ext in doc_extensions:
        try:
            import zipfile
            if ext in ('.docx', '.xlsx', '.pptx'):
                with zipfile.ZipFile(file_path, 'r') as z:
                    for name in z.namelist():
                        if 'meta' in name.lower() or 'app.xml' in name:
                            content = z.read(name).decode('utf-8', errors='ignore')
                            result["document_meta"][name] = content[:2000]

            elif ext == '.pdf':
                with open(file_path, 'rb') as f:
                    data = f.read(4096)
                    # PDF metadata extraction (basic)
                    pdf_meta = {}
                    for i in range(len(data) - 10):
                        if b'/Title' in data[i:i+10]:
                            end = data.index(b')', i+6) if b')' in data[i:] else i + 50
                            pdf_meta['title'] = data[i+6:end].decode('utf-8', errors='ignore')
                        if b'/Author' in data[i:i+10]:
                            end = data.index(b')', i+7) if b')' in data[i:] else i + 50
                            pdf_meta['author'] = data[i+7:end].decode('utf-8', errors='ignore')
                        if b'/Creator' in data[i:i+10]:
                            end = data.index(b')', i+8) if b')' in data[i:] else i + 50
                            pdf_meta['creator'] = data[i+8:end].decode('utf-8', errors='ignore')
                        if b'/Producer' in data[i:i+10]:
                            end = data.index(b')', i+9) if b')' in data[i:] else i + 50
                            pdf_meta['producer'] = data[i+9:end].decode('utf-8', errors='ignore')
                    result["document_meta"]["pdf_basic"] = pdf_meta
        except Exception as e:
            logger.warning(f"文档属性提取失败: {e}")

    # ── 文件类型验证 ──
    try:
        proc = subprocess.run(
            ["file", file_path], capture_output=True, text=True, timeout=10,
        )
        result["file_type"] = proc.stdout.strip() or ''
    except Exception:
        # Windows fallback
        pass

    result["ok"] = True
    return result


def _check_stego_indicators(file_path: str, ext: str) -> list:
    """检查隐写可疑指标。"""
    suspects = []
    file_size = os.path.getsize(file_path)

    # 1. 文件大小异常（图片文件过大 → 可能嵌入数据）
    if file_size > 10 * 1024 * 1024:  # >10MB
        suspects.append({
            "indicator": "oversized_file",
            "description": f"文件异常大 ({file_size / 1024 / 1024:.1f} MB)，可能嵌入隐藏数据",
            "severity": "medium",
        })

    # 2. PNG 中 IDAT chunk 大小异常
    if ext == '.png':
        try:
            with open(file_path, 'rb') as f:
                header = f.read(8)
                if header[:4] == b'\x89PNG':
                    # Read chunks
                    pos = 8
                    while pos < min(file_size, 1024 * 1024):  # 最多检查前 1MB
                        f.seek(pos)
                        chunk_data = f.read(8)
                        if len(chunk_data) < 8:
                            break
                        chunk_len = struct.unpack('>I', chunk_data[:4])[0]
                        chunk_type = chunk_data[4:8]
                        if chunk_type == b'IDAT':
                            # IDAT chunk > 5MB in small PNG = suspicious
                            if chunk_len > 5 * 1024 * 1024 and file_size < 5 * 1024 * 1024:
                                suspects.append({
                                    "indicator": "oversized_idat",
                                    "description": f"PNG IDAT chunk 过大 ({chunk_len / 1024:.0f} KB)，可能隐藏数据",
                                    "severity": "high",
                                })
                        pos += 8 + chunk_len + 4  # header + data + CRC
        except Exception:
            pass

    # 3. JPEG APP segments with extra data
    if ext in ('.jpg', '.jpeg'):
        try:
            with open(file_path, 'rb') as f:
                data = f.read(1024)
                if b'JFIF' in data or b'EXIF' in data:
                    # Check for APPn segments after EXIF (possible steg)
                    pass  # Complex check, keep it simple
        except Exception:
            pass

    # 4. Zip 末尾 finder for extra files
    try:
        with open(file_path, 'rb') as f:
            data = f.read()
            # Look for appended text files after image markers
            if b'PK\x03\x04' in data:
                suspects.append({
                    "indicator": "embedded_zip",
                    "description": "文件包含 ZIP 签名，可能嵌入了隐藏压缩包",
                    "severity": "medium",
                })
    except Exception:
        pass

    return suspects


def check_steganography(file_path: str) -> dict:
    """深度隐写检测。

    Args:
        file_path: 文件路径

    Returns:
        {
            "ok": True,
            "suspects": [...],
            "suggested_tools": ["steghide", "foremost", "binwalk"],
            "error": ""
        }
    """
    result = {"ok": False, "suspects": [], "suggested_tools": []}

    if not os.path.isfile(file_path):
        return {**result, "error": f"文件不存在: {file_path}"}

    # 元数据提取
    meta = file_metadata(file_path)
    result["suspects"].extend(meta.get("stego_suspects", []))

    # binwalk 检测隐藏文件/签名
    try:
        proc = subprocess.run(
            ["binwalk", "-e", "--dd", ".*", file_path],
            capture_output=True, text=True, timeout=60,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            result["suspects"].append({
                "indicator": "hidden_files_detected",
                "description": f"binwalk 发现可能隐藏的文件: {proc.stdout[:500]}",
                "severity": "high",
            })
    except FileNotFoundError:
        pass
    except Exception as e:
        logger.warning(f"binwalk failed: {e}")

    # stegdetect (可选)
    try:
        proc = subprocess.run(
            ["stegdetect", "-t", "jphide steghide exif jsteg outguess sbstego", file_path],
            capture_output=True, text=True, timeout=30,
        )
        if proc.stdout.strip():
            result["suspects"].append({
                "indicator": "stegdetect_findings",
                "description": proc.stdout[:500],
                "severity": "high",
            })
    except FileNotFoundError:
        pass

    # 建议工具
    tools = []
    ext = os.path.splitext(file_path)[1].lower()
    if ext in ('.jpg', '.jpeg'):
        tools.extend(["steghide", "stegbreak", "binwalk"])
    elif ext == '.png':
        tools.extend(["zsteg", "foremost", "binwalk"])
    elif ext == '.gif':
        tools.extend(["gifsicle", "exiftool"])
    elif ext in ('.docx', '.xlsx'):
        tools.extend(["olevba", "mso-hydra"])
    else:
        tools.append("binwalk")

    result["suggested_tools"] = tools
    result["ok"] = True
    return result
