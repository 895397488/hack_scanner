#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YARA Scanner — 通过 YARA CLI 做基于规则的文件检测（webshell / 后门 / 恶意样本特征）。

这是 hack_scanner 的"蓝队检测侧"能力，与 `webshell_detector.py`（纯正则特征）互补：
- YARA 规则表达力更强（字节/十六进制/PE 特征/逻辑组合），业界通用；
- 攻击侧种下的 payload、或目标上残留的后门，可用同一套规则回扫验证——
  这才是"攻防一体"的闭环：攻击 → 检测 → 验证检出。

集成方式：需要安装 YARA CLI（choco install -y yara  或  winget install VirusTotal.Yara）。
本模块只负责 CLI 调用和结果解析，不引入任何 C 扩展 Python 依赖
（避免 pyyara 在 Python 3.13/3.14 上无 wheel 需要现场编译的问题，见 requirements.txt 备注）。

内置规则：`scanners/yara_rules/`（含 webshell.yar）。用户可往该目录丢自己的 .yar 规则，
yara_scan 默认会加载整个规则目录。

Usage:
    from scanners.yara_wrapper import yara_scan, yara_engine_status
    result = yara_scan("C:\\path\\to\\upload_dir")
"""

import json
import logging
import os
import re
import subprocess
from typing import List, Optional

logger = logging.getLogger('yara_scanner')

# YARA -s 模式的证据行形如:  0x1d:$s1: eval(base64_decode(
# 用"0x<十六进制>:"前缀把它和命中行(RULENAME FILEPATH)区分开（证据行同样顶格、无缩进）
_YARA_EVIDENCE_RE = re.compile(r"^0x[0-9a-fA-F]+:")

# 内置规则目录（相对本文件 ../scanners/yara_rules）
_BUNDLED_RULES_DIR = os.path.normpath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "yara_rules"))


def _config_path() -> Optional[str]:
    """返回项目根 config.json 绝对路径（若存在）。"""
    p = os.path.normpath(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
    return p if os.path.isfile(p) else None


def _load_cfg() -> dict:
    p = _config_path()
    if not p:
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _find_yara() -> Optional[str]:
    """查找 yara 可执行文件：先 config.json → tools.yara_path，再 PATH。"""
    # 1) config 指定路径
    p = (_load_cfg().get("tools", {}) or {}).get("yara_path", "")
    if p and os.path.isfile(p):
        return p
    # 2) PATH（注意 choco 安装的是 yara64.exe，winget 可能是 yara.exe）
    for name in ["yara", "yara.exe", "yara64", "yara64.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True,
                                     encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    # 3) 常见安装目录（chocolatey / winget links / 本机 bin）
    candidates = [
        r"C:\ProgramData\chocolatey\bin\yara.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links\yara.exe"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "bin", "yara.exe"),
    ]
    for c in candidates:
        try:
            c = os.path.normpath(c)
            if os.path.isfile(c):
                return c
        except Exception:
            continue
    return None


def _resolve_rules_dir(rules_path: str = "") -> Optional[str]:
    """确定要用的规则目录。

    优先级：显式 rules_path（目录）> config yara.rules_dir > 内置 yara_rules 目录。
    若显式 rules_path 是单个 .yar/.yara 文件，则返回其所在目录（随后展开为规则文件列表）。
    """
    if rules_path:
        if os.path.isfile(rules_path):
            return os.path.dirname(os.path.abspath(rules_path))
        if os.path.isdir(rules_path):
            return rules_path
        return None
    cfg_dir = (_load_cfg().get("yara", {}) or {}).get("rules_dir", "")
    if cfg_dir:
        d = cfg_dir if os.path.isabs(cfg_dir) else os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", cfg_dir))
        if os.path.isdir(d):
            return d
    return _BUNDLED_RULES_DIR if os.path.isdir(_BUNDLED_RULES_DIR) else None


def yara_scan(
    target: str,
    rules_path: str = "",
    recursive: bool = True,
    include_strings: bool = False,
    max_time: int = 300,
) -> dict:
    """用 YARA 规则扫描文件或目录，检测 webshell / 后门 / 恶意特征。

    Args:
        target: 要扫描的文件或目录路径
        rules_path: 规则文件或规则目录（可选）。留空则用内置/配置规则目录
        recursive: 目录是否递归扫描（-r）
        include_strings: 是否附带命中的字符串证据（-s）
        max_time: 最大运行秒数

    Returns:
        {
            "ok": True,
            "target": "...",
            "rules_dir": "...",
            "rules_loaded": N,
            "total_files": N,        # 命中文件数（YARA 只报命中项）
            "matches": [
                {"rule": "...", "file": "...", "evidence": "..."}
            ],
            "total_matches": N,
            "error": ""
        }
    """
    yara_path = _find_yara()
    if not yara_path:
        return {
            "ok": False,
            "target": target,
            "matches": [],
            "total_matches": 0,
            "error": "yara 未找到，请安装: choco install -y yara  或  winget install VirusTotal.Yara",
        }

    if not os.path.exists(target):
        return {"ok": False, "target": target, "matches": [], "total_matches": 0,
                "error": f"目标不存在: {target}"}

    rules_dir = _resolve_rules_dir(rules_path)
    if not rules_dir or not os.path.isdir(rules_dir):
        return {"ok": False, "target": target, "matches": [], "total_matches": 0,
                "error": "未找到可用 YARA 规则目录（内置 scanners/yara_rules 缺失，且未指定 rules_path）"}

    # 展开规则目录 → 具体规则文件。YARA CLI 用"位置参数"传规则文件，
    # 没有"规则目录"选项（早期误用了不存在的 -R，导致命令直接失败却报 0 命中）。
    rule_files = _rule_files(rules_dir)
    if not rule_files:
        return {"ok": False, "target": target, "matches": [], "total_matches": 0,
                "error": f"规则目录里没有可用规则文件 (.yar/.yara/.yrc): {rules_dir}"}

    cmd = [yara_path, "-w"]  # -w 抑制警告
    if recursive:
        cmd.append("-r")     # 递归扫目录
    if include_strings:
        cmd.append("-s")     # 打印命中的字符串证据
    cmd.extend(rule_files)   # 规则文件作为位置参数（在目标之前）
    cmd.append(target)

    logger.info(f"yara scan: {len(rule_files)} 规则文件 → {target}")
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=max_time,
        )
        # YARA 规则编译/运行失败（规则语法错误、目标不可读等）→ 非 0 退出码。
        # 之前没查退出码，把失败当成"扫完 0 命中"返回了，这里必须拦住。
        if proc.returncode != 0:
            err = (proc.stderr or "").strip() or f"yara 退出码 {proc.returncode}"
            return {"ok": False, "target": target, "matches": [], "total_matches": 0,
                    "error": err[:500]}

        # 命中行:  RULENAME  FILEPATH
        # -s 证据行:  0x<hex>:$<id>: <文本>   （顶格、以 0x 开头）
        # 二者都顶格，靠"是否 0x 前缀"区分；证据行逐行挂到最近一次命中上。
        matches = []
        last = None
        for raw in (proc.stdout or "").splitlines():
            line = raw.strip()
            if not line:
                continue
            if _YARA_EVIDENCE_RE.match(line):
                if last is not None:
                    last["evidence"] = (last["evidence"] + " " + line).strip()[:500]
                continue
            parts = line.split(None, 1)
            if len(parts) < 2:
                continue
            last = {"rule": parts[0], "file": parts[1], "evidence": ""}
            matches.append(last)

        # 去重（同一 rule+file 可能因多字符串命中而重复）
        seen = set()
        dedup = []
        for m in matches:
            key = (m["rule"], m["file"])
            if key in seen:
                continue
            seen.add(key)
            dedup.append(m)

        return {
            "ok": True,
            "target": target,
            "rules_dir": rules_dir,
            "rules_loaded": len(rule_files),
            "total_files": len({m["file"] for m in dedup}),
            "matches": dedup[:500],
            "total_matches": len(dedup),
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "target": target, "matches": [], "total_matches": 0,
                "error": f"yara 超时（最大 {max_time}s）"}
    except Exception as e:
        return {"ok": False, "target": target, "matches": [], "total_matches": 0,
                "error": str(e)}


def _rule_files(rules_dir: str) -> List[str]:
    """列出规则目录下的 .yar/.yara/.yrc 规则文件（排序，供命令行位置参数使用）。"""
    try:
        return sorted(
            os.path.join(rules_dir, f) for f in os.listdir(rules_dir)
            if f.lower().endswith((".yar", ".yara", ".yrc")))
    except OSError:
        return []


def _rules_compile_ok(yara_path: str, rules_dir: str) -> Optional[bool]:
    """用空目标文件做一次真实编译校验，确认规则能被 YARA 加载。

    返回 True/False；无法校验（无规则文件 / 无 yara / 异常）时返回 None。
    这能抓住"规则语法错误但文件数正常"的假绿灯——之前只数文件数，
    规则编译不过也报 ok。
    """
    rf = _rule_files(rules_dir)
    if not rf or not yara_path:
        return None
    dummy = None
    try:
        import tempfile
        fd, dummy = tempfile.mkstemp(prefix="yara_check_", suffix=".bin")
        os.close(fd)
        proc = subprocess.run(
            [yara_path, "-w", *rf, dummy],
            capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=30,
        )
        return proc.returncode == 0
    except Exception:
        return None
    finally:
        if dummy:
            try:
                if os.path.exists(dummy):
                    os.unlink(dummy)
            except OSError:
                pass


def yara_engine_status() -> dict:
    """YARA 引擎自检（供 tool_detector / tools_status 调用）。

    除"yara 在不在 + 规则文件数"外，还会做一次真实编译校验（rules_valid），
    避免规则本身编译不过却报绿灯。

    Returns:
        {"ok": bool, "yara_path": "...", "rules_dir": "...", "rules_loaded": N,
         "rules_valid": true/false/null, "engine": "cli"}
    """
    yara_path = _find_yara()
    rules_dir = _resolve_rules_dir("")
    rule_files = _rule_files(rules_dir) if rules_dir else []
    rules_valid = _rules_compile_ok(yara_path, rules_dir) if rules_dir else None
    return {
        "ok": bool(yara_path),
        "yara_path": yara_path or "",
        "rules_dir": rules_dir or "",
        "rules_loaded": len(rule_files),
        "rules_valid": rules_valid,
        "engine": "cli",
    }
