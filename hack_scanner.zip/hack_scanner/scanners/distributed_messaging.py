#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Distributed Scan Messaging — NATS 风格的分布式扫描协调器

借鉴 Acunetix API Hub + NATS broker 架构，实现多扫描节点的消息驱动协作。
用于大规模目标群的扫描任务分发、结果汇聚和状态同步。

核心能力：
- 任务分发（Topic-based routing）
- 结果汇聚（Aggregation across nodes）
- 分布式子域名枚举（多台机器并行解析）
- 扫描状态监控与心跳
- 本地内存实现（无需外部 NATS 服务器）+ 可选远程 NATS

Usage:
    from scanners.distributed_messaging import ScanCluster, ScanTopic
    cluster = ScanCluster()
    # 分发子域名枚举任务
    nodes = cluster.spawn_workers(5)
    results = cluster.collect_results(timeout=60)
"""

import json
import time
import uuid
import logging
import threading
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

logger = logging.getLogger('distributed_messaging')


# ==================== Topic 定义（借鉴 NATS + Acunetix apihub）====================

class ScanTopic(Enum):
    """扫描任务主题"""
    # 子域名枚举
    SUBDOMAIN_ENUM = "scan/subdomain/enum"
    # 端口扫描
    PORT_SCAN = "scan/port/enumerate"
    # SSL/TLS 检查
    SSL_CHECK = "scan/ssl/check"
    # WAF 检测
    WAF_DETECT = "scan/waf/detect"
    # SQLi 探测
    SQLI_PROBE = "scan/sqli/probe"
    # XSS 探测
    XSS_PROBE = "scan/xss/probe"
    # SSRF 探测
    SSRF_PROBE = "scan/ssrf/probe"
    # 目录爆破
    DIR_BUST = "scan/dir/bust"
    # 全局状态更新
    GLOBAL_STATUS = "scan/status/update"
    # 结果报告
    RESULT_REPORT = "scan/result/report"
    # 节点心跳
    HEARTBEAT = "cluster/node/heartbeat"
    # 紧急停止
    EMERGENCY_STOP = "cluster/control/stop"


class WorkerState(Enum):
    IDLE = 'idle'
    BUSY = 'busy'
    DRAINING = 'draining'
    OFFLINE = 'offline'


# ==================== 消息格式 ====================

@dataclass
class ScanMessage:
    """扫描任务消息"""
    topic: str
    payload: Dict[str, Any]
    sender_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    msg_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    timestamp: float = field(default_factory=time.time)
    ttl: int = 300  # 消息存活时间（秒）

    def to_dict(self):
        return {
            'topic': self.topic,
            'payload': self.payload,
            'sender_id': self.sender_id,
            'msg_id': self.msg_id,
            'timestamp': self.timestamp,
            'ttl': self.ttl,
        }

    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            topic=data.get('topic', ''),
            payload=data.get('payload', {}),
            sender_id=data.get('sender_id', ''),
            msg_id=data.get('msg_id', ''),
            timestamp=data.get('timestamp', time.time()),
            ttl=data.get('ttl', 300),
        )

    def is_expired(self) -> bool:
        return (time.time() - self.timestamp) > self.ttl


@dataclass
class ScanResult:
    """扫描结果"""
    task_id: str
    topic: str
    worker_id: str
    data: Dict[str, Any]
    completed_at: float = field(default_factory=time.time)
    duration_ms: float = 0.0

    def to_dict(self):
        return {
            'task_id': self.task_id,
            'topic': self.topic,
            'worker_id': self.worker_id,
            'data': self.data,
            'completed_at': self.completed_at,
            'duration_ms': self.duration_ms,
        }


# ==================== 本地消息总线（替代外部 NATS）====================

class LocalMessageBus:
    """本地内存消息总线 — 功能等效于 Acunetix nats-server"""

    def __init__(self):
        self._subscriptions: Dict[str, List[Callable]] = defaultdict(list)
        self._message_log: List[ScanMessage] = []
        self._lock = threading.Lock()
        self._max_log_size = 10000

    def subscribe(self, topic: str, callback: Callable[[ScanMessage], None]) -> str:
        """订阅主题并注册回调"""
        sub_id = uuid.uuid4().hex[:8]
        with self._lock:
            self._subscriptions[topic].append((sub_id, callback))
        logger.debug(f"Subscribe: {topic} → sub={sub_id}")
        return sub_id

    def unsubscribe(self, topic: str, sub_id: str):
        """取消订阅"""
        with self._lock:
            if topic in self._subscriptions:
                self._subscriptions[topic] = [
                    (sid, cb) for sid, cb in self._subscriptions[topic] if sid != sub_id
                ]

    def publish(self, message: ScanMessage):
        """发布消息到主题"""
        # 过滤过期消息
        if message.is_expired():
            logger.debug(f"Skip expired message {message.msg_id}")
            return

        with self._lock:
            # 限制日志大小
            if len(self._message_log) > self._max_log_size:
                self._message_log = self._message_log[-self._max_log_size // 2:]
            self._message_log.append(message)

        topic_subs = []
        with self._lock:
            # 精确匹配 + 通配符匹配 (scan/* → scan/+)
            for t, subs in self._subscriptions.items():
                if t == message.topic:
                    topic_subs.extend(subs)
                elif t.endswith('/+'):
                    prefix = t.rstrip('/+')
                    if message.topic.startswith(prefix):
                        topic_subs.extend(subs)

        # 异步触发回调（在单独线程中）
        for sub_id, callback in topic_subs:
            try:
                thread = threading.Thread(target=callback, args=(message,), daemon=True)
                thread.start()
            except Exception as e:
                logger.error(f"Message bus callback error: {e}")

    def get_messages_for_topic(self, topic: str, limit: int = 100) -> List[ScanMessage]:
        """获取指定主题的历史消息"""
        with self._lock:
            msgs = [m for m in self._message_log if m.topic == topic and not m.is_expired()]
            return msgs[-limit:]


# ==================== 扫描节点（Worker）====================

@dataclass
class WorkerNode:
    """扫描工作节点"""
    node_id: str
    host: str = 'localhost'
    port: int = 0
    state: WorkerState = WorkerState.IDLE
    capabilities: List[str] = field(default_factory=list)
    last_heartbeat: float = field(default_factory=time.time)
    tasks_completed: int = 0
    current_task: Optional[str] = None

    def to_dict(self):
        return {
            'node_id': self.node_id,
            'host': self.host,
            'port': self.port,
            'state': self.state.value,
            'capabilities': self.capabilities,
            'last_heartbeat': self.last_heartbeat,
            'tasks_completed': self.tasks_completed,
            'current_task': self.current_task,
        }


# ==================== 扫描集群（Cluster）====================

class ScanCluster:
    """分布式扫描集群管理器 — 等效于 Acunetix apihub + nats-server 的组合"""

    def __init__(self, max_workers: int = 8):
        self.max_workers = max_workers
        self.bus = LocalMessageBus()
        self.workers: Dict[str, WorkerNode] = {}
        self.results_store: Dict[str, List[ScanResult]] = defaultdict(list)
        self._result_lock = threading.Lock()

        # 订阅全局状态和结果主题
        self.bus.subscribe(ScanTopic.GLOBAL_STATUS.value, self._on_status_update)
        self.bus.subscribe(ScanTopic.RESULT_REPORT.value, self._on_result_report)
        self.bus.subscribe(ScanTopic.HEARTBEAT.value, self._on_heartbeat)

    def _on_status_update(self, msg: ScanMessage):
        worker_id = msg.sender_id
        if worker_id in self.workers:
            self.workers[worker_id].state = WorkerState(msg.payload.get('state', 'idle'))
            self.workers[worker_id].last_heartbeat = time.time()

    def _on_result_report(self, msg: ScanMessage):
        result = ScanResult(
            task_id=msg.payload.get('task_id', ''),
            topic=msg.topic,
            worker_id=msg.sender_id,
            data=msg.payload.get('data', {}),
        )
        with self._result_lock:
            self.results_store[msg.topic].append(result)

    def _on_heartbeat(self, msg: ScanMessage):
        worker_id = msg.sender_id
        if worker_id in self.workers:
            self.workers[worker_id].last_heartbeat = time.time()
            self.workers[worker_id].tasks_completed = msg.payload.get('tasks_completed', 0)

    def spawn_worker(self, node_id: str = None, host: str = 'localhost', port: int = 0,
                     capabilities: List[str] = None) -> WorkerNode:
        """启动一个工作节点"""
        worker_id = node_id or uuid.uuid4().hex[:16]
        if worker_id in self.workers:
            logger.warning(f"Worker {worker_id} already exists")
            return self.workers[worker_id]

        node = WorkerNode(
            node_id=worker_id,
            host=host,
            port=port,
            state=WorkerState.IDLE,
            capabilities=capabilities or [],
        )
        self.workers[worker_id] = node

        # 发送心跳消息
        heartbeat_msg = ScanMessage(
            topic=ScanTopic.HEARTBEAT.value,
            payload={
                'state': 'idle',
                'tasks_completed': 0,
                'node': node.to_dict(),
            },
            sender_id=worker_id,
            ttl=60,
        )
        self.bus.publish(heartbeat_msg)

        logger.info(f"Spawned worker: {worker_id} @ {host}:{port}")
        return node

    def spawn_workers(self, count: int, capabilities: List[str] = None) -> List[WorkerNode]:
        """批量启动工作节点"""
        nodes = []
        for i in range(count):
            node = self.spawn_worker(capabilities=capabilities)
            nodes.append(node)
        return nodes

    def distribute_task(self, topic: str, task_data: Dict[str, Any],
                        target_workers: List[str] = None) -> str:
        """分发扫描任务到指定/随机工作节点"""
        task_id = uuid.uuid4().hex[:16]

        if not target_workers:
            available = [w for w, n in self.workers.items() if n.state == WorkerState.IDLE]
            if available:
                target_workers = [available[0]]  # 分发到第一个空闲节点

        msg = ScanMessage(
            topic=topic,
            payload={
                'task_id': task_id,
                'command': task_data.get('command', ''),
                'target': task_data.get('target', ''),
                'params': task_data.get('params', {}),
                'distribute_to': target_workers,
            },
            ttl=300,
        )

        # 广播到所有目标（或全部节点）
        self.bus.publish(msg)

        # 更新工作节点状态
        for wid in target_workers or list(self.workers.keys()):
            if wid in self.workers:
                self.workers[wid].state = WorkerState.BUSY
                self.workers[wid].current_task = task_id

        return task_id

    def collect_results(self, topic: str, timeout: float = 60) -> List[ScanResult]:
        """收集指定主题的结果（等待超时时间）"""
        deadline = time.time() + timeout

        while time.time() < deadline:
            # 检查结果是否稳定（3秒内无新结果则认为完成）
            if hasattr(self, '_last_result_time'):
                if time.time() - self._last_result_time > 3:
                    break
            time.sleep(0.5)

        return self.results_store.get(topic, [])

    def get_cluster_health(self) -> Dict[str, Any]:
        """集群健康状态"""
        states = defaultdict(int)
        for node in self.workers.values():
            states[node.state.value] += 1

        # 计算平均心跳年龄（秒）
        heartbeats = [time.time() - n.last_heartbeat for n in self.workers.values()]
        avg_hb_age = sum(heartbeats) / len(heartbeats) if heartbeats else float('inf')

        return {
            'total_workers': len(self.workers),
            'states': dict(states),
            'idle': states.get('idle', 0),
            'busy': states.get('busy', 0),
            'offline': states.get('offline', 0),
            'avg_heartbeat_age_s': round(avg_hb_age, 1),
            'results_collected': sum(len(r) for r in self.results_store.values()),
        }

    def emergency_stop_all(self):
        """紧急停止所有工作节点"""
        stop_msg = ScanMessage(
            topic=ScanTopic.EMERGENCY_STOP.value,
            payload={},
            ttl=60,
        )
        self.bus.publish(stop_msg)

        for node in self.workers.values():
            node.state = WorkerState.OFFLINE
            node.current_task = None

    def remove_worker(self, worker_id: str):
        """移除工作节点"""
        if worker_id in self.workers:
            self.workers[worker_id].state = WorkerState.OFFLINE
            del self.workers[worker_id]
            logger.info(f"Removed worker: {worker_id}")

    def list_workers(self) -> List[Dict]:
        """列出所有工作节点"""
        return [n.to_dict() for n in self.workers.values()]


# ==================== 分布式子域名枚举（示例应用）====================

class DistributedSubdomainEnum:
    """分布式子域名枚举 — 利用集群并行解析"""

    def __init__(self, cluster: ScanCluster):
        self.cluster = cluster

    def enum(self, domain: str, wordlist: List[str] = None) -> Dict[str, Any]:
        """分发给多个节点并行执行"""
        result = {
            'domain': domain,
            'found_subdomains': set(),
            'workers_used': 0,
            'time_start': time.time(),
            'time_end': 0,
        }

        # 准备 wordlist
        if not wordlist:
            from url_scanner import SubdomainEnum as URLSubdomainEnum
            wordlist = URLSubdomainEnum.COMMON_SUBDOMAINS[:50]  # 只用前50个做示例

        chunk_size = max(1, len(wordlist) // min(self.cluster.max_workers, len(self.cluster.workers)))
        chunks = [wordlist[i:i + chunk_size] for i in range(0, len(wordlist), chunk_size)]

        tasks_sent = 0
        for i, chunk in enumerate(chunks):
            node_list = list(self.cluster.workers.keys())[:min(len(self.cluster.workers), i + 1)]
            if not node_list:
                self.cluster.spawn_worker(capabilities=['subdomain_enum'])

            task_id = self.cluster.distribute_task(
                topic=ScanTopic.SUBDOMAIN_ENUM.value,
                task_data={
                    'command': 'enum_subdomains',
                    'target': domain,
                    'params': {'wordlist': chunk},
                },
                target_workers=node_list,
            )
            tasks_sent += 1

        result['workers_used'] = tasks_sent
        result['time_end'] = time.time()
        result['duration_s'] = round(result['time_end'] - result['time_start'], 2)

        return result


# ==================== 便捷函数 ====================

def create_cluster(max_workers: int = 8) -> ScanCluster:
    """快速创建扫描集群"""
    return ScanCluster(max_workers=max_workers)


def enum_distributed(domain: str, workers: int = 4) -> Dict[str, Any]:
    """分布式子域名枚举（一行命令）"""
    cluster = create_cluster(workers)
    cluster.spawn_workers(workers, capabilities=['subdomain_enum'])
    enum = DistributedSubdomainEnum(cluster)
    return enum.enum(domain)
