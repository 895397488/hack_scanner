#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
llm_guard.py — LLM 侧令牌桶 + 调用上限护栏（4 项目升级清单 #7）
=====================================================================

借鉴 redamon agentic/llm_guard.py（"防预算被烧穿"）:
    hack_scanner 的 rate_limiter 只管 **HTTP 侧** per-domain 限速，
    llm_cost 只**记账不限流**——一次失控的 agent 循环（或本地
    Ollama 无限额）可以在几分钟内烧掉几千次 LLM 调用 / 一整天的
    云端配额。本模块在 **LLM 调用侧**加一道护栏：

    1. 令牌桶限速（token bucket）：按 (calls/分钟) 补令牌，桶容量=突发，
       空桶 → 拒绝本次调用（fail-fast，不阻塞核心循环）。
    2. 每日调用上限：按 UTC 日分桶计数，超上限 → 拒绝（预算耗尽语义）。
    3. 总量调用上限：进程内硬顶（防失控长跑）。
    4. 成本上限：读 ``llm_cost.LLMCostLedger`` 的累计费用（observed 优先
       estimated），超上限 → 拒绝。账本未启用/未记账时该项自动失效。

    拒绝的表现：``install_llm_guard`` 包装的 invoke 返回 ``None``——
    orchestrator 有现成的"干净终止"分支（llm_invoke 失败即安全停止），
    这正是"预算用尽就停"的正确语义；拒绝原因写日志（区分
    限速/每日上限/总量上限/成本上限），绝不抛异常外溢。

设计纪律（与 anti_loop / exec_gate / prompt_safety / output_offload 一致）:
    - 入口层包装 ``llm_invoke``（函数级，非 tool 级），orchestrator 零改动
    - 纯标准库；**时钟/账本均可注入** → 桩 LLM 下确定性验收
    - 护栏自身异常 → **fail-open**（放行），绝不因护栏拖垮 LLM 调用
    - 所有上限 0/None = 关闭（默认全关，用户按需打开，行为零变化）
    - 包装器幂等（_llm_guard_wrapped 标记）

挂点（run_adaptive.py 预算守卫之后、SwarmOrchestrator 之前）:
    包住最外层的 llm_guarded——在任何 coach/预算包装器**之前**短路，
    省得为一次注定被拒的调用白跑一遍上下文裁剪。
"""

from __future__ import annotations

import logging
import math
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable, Optional, Tuple

logger = logging.getLogger(__name__)

__all__ = [
    "LLMGuard",
    "install_llm_guard",
    "build_guard_from_advanced",
]


def _env_int(name: str, default: Optional[int]) -> Optional[int]:
    """读 int 型 env；非法/空 → 回退 default。"""
    raw = os.environ.get(name, "")
    if raw is None or str(raw).strip() == "":
        return default
    try:
        v = int(str(raw).strip())
        return v if v > 0 else default
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: Optional[float]) -> Optional[float]:
    raw = os.environ.get(name, "")
    if raw is None or str(raw).strip() == "":
        return default
    try:
        v = float(str(raw).strip())
        return v if v > 0 else default
    except (TypeError, ValueError):
        return default


class LLMGuard:
    """LLM 调用侧护栏：令牌桶限速 + 每日/总量调用上限 + 成本上限。

    所有上限 0/None = 关闭。``now``/``ledger``/``cost_source`` 可注入以便确定性测试。
    """

    def __init__(
        self,
        rate_per_min: Optional[float] = None,   # 令牌桶补充速率（calls/分钟）；None/0=关
        burst: Optional[int] = None,            # 桶容量（突发）；None → 取 ceil(rate_per_min)
        daily_call_cap: Optional[int] = None,   # 每 UTC 日最多调用；None/0=关
        max_calls: Optional[int] = None,        # 进程内硬顶（总量）；None/0=关
        cost_cap_usd: Optional[float] = None,   # 累计成本上限（USD）；None/0=关
        ledger: Optional[Any] = None,           # llm_cost.LLMCostLedger（成本上限数据源）
        cost_source: Optional[Callable[[], float]] = None,  # 自定义成本读取（优先于 ledger）
        now: Optional[Callable[[], float]] = None,          # 时钟（默认 time.monotonic）
        day_key: Optional[Callable[[], str]] = None,        # UTC 日键（默认取 UTC 日期串）
    ):
        self._lock = threading.RLock()
        self._rate = max(0.0, float(rate_per_min or 0.0))
        if burst and int(burst) > 0:
            self._burst = int(burst)
        else:
            self._burst = int(math.ceil(self._rate)) if self._rate > 0 else 0
        # 速率开启时突发桶至少容 1 次；速率关闭时桶为 0（令牌桶判定自动失效）
        self._burst = max(self._burst, 1) if self._rate > 0 else 0
        self._daily_cap = int(daily_call_cap) if daily_call_cap and int(daily_call_cap) > 0 else 0
        self._max_calls = int(max_calls) if max_calls and int(max_calls) > 0 else 0
        self._cost_cap = float(cost_cap_usd) if cost_cap_usd and float(cost_cap_usd) > 0 else 0.0

        self._ledger = ledger
        self._cost_source = cost_source

        self._now = now or time.monotonic
        self._day_key = day_key or (lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d"))

        # 令牌桶状态
        self._tokens: float = float(self._burst) if self._rate > 0 else 0.0
        self._last_refill: Optional[float] = None

        # 计数（拒绝判定用）
        self._total_calls = 0
        self._day = ""
        self._day_calls = 0
        self._denied = {"rate": 0, "daily": 0, "total": 0, "cost": 0}

    # ---- 内部 ----

    def _refill(self, t: float) -> None:
        """按经过时间补充令牌（调用方须持有锁）。"""
        if self._rate <= 0:
            return
        if self._last_refill is None:
            self._last_refill = t
            return
        elapsed = max(0.0, t - self._last_refill)
        if elapsed <= 0:
            return
        self._tokens = min(float(self._burst), self._tokens + elapsed * (self._rate / 60.0))
        self._last_refill = t

    def _current_cost(self) -> float:
        """读累计成本（USD）。无源 → 0.0（成本上限自动失效）。"""
        try:
            if self._cost_source is not None:
                v = self._cost_source()
                return float(v) if v and float(v) > 0 else 0.0
            if self._ledger is not None:
                rec = self._ledger.to_record()
                v = (rec.get("totals") or {}).get("cost", 0.0)
                return float(v) if v and float(v) > 0 else 0.0
        except Exception:  # 读成本失败 → 视为无成本（不阻断）
            return 0.0
        return 0.0

    # ---- 对外 ----

    def check(self) -> Tuple[bool, str]:
        """判定本次 LLM 调用是否放行。返回 (allowed, reason)。

        判定顺序（先硬预算、后限速，语义清晰）:
            1. 成本上限（读账本/源）
            2. 每日调用上限
            3. 总量调用上限
            4. 令牌桶限速
        注意：``check`` 本身**不消耗**令牌；放行后由 ``note_call`` 扣减，
        避免"检查即消耗"导致并发下的双重计数。
        """
        with self._lock:
            t = self._now()
            self._refill(t)

            # 1. 成本上限
            if self._cost_cap > 0 and self._current_cost() >= self._cost_cap:
                self._denied["cost"] += 1
                return False, (f"cost_cap_reached: cost>=${self._cost_cap:.4f} "
                               f"(llm guard cost limit)")

            # 日键滚动
            dk = self._day_key()
            if dk != self._day:
                self._day = dk
                self._day_calls = 0

            # 2. 每日上限
            if self._daily_cap > 0 and self._day_calls >= self._daily_cap:
                self._denied["daily"] += 1
                return False, (f"daily_call_cap_reached: {self._day_calls} calls on {dk} "
                               f"cap={self._daily_cap} (llm guard daily limit)")

            # 3. 总量上限
            if self._max_calls > 0 and self._total_calls >= self._max_calls:
                self._denied["total"] += 1
                return False, (f"total_call_cap_reached: {self._total_calls} calls "
                               f"cap={self._max_calls} (llm guard total limit)")

            # 4. 令牌桶
            if self._rate > 0 and self._tokens < 1.0:
                self._denied["rate"] += 1
                return False, (f"rate_limited: token bucket empty "
                               f"(rate={self._rate}/min, burst={self._burst}); retry after refill")

            return True, ""

    def note_call(self) -> None:
        """放行后记账：扣 1 令牌 + 累计计数（调用方在 invoke 成功发起后调用）。"""
        with self._lock:
            if self._rate > 0:
                self._tokens = max(0.0, self._tokens - 1.0)
            self._total_calls += 1
            dk = self._day_key()
            if dk != self._day:
                self._day = dk
                self._day_calls = 0
            self._day_calls += 1

    def status(self) -> dict:
        """当前护栏状态（报告/验收用）。"""
        with self._lock:
            return {
                "rate_per_min": self._rate,
                "burst": self._burst,
                "daily_call_cap": self._daily_cap,
                "max_calls": self._max_calls,
                "cost_cap_usd": self._cost_cap,
                "total_calls": self._total_calls,
                "day": self._day,
                "day_calls": self._day_calls,
                "tokens": round(self._tokens, 4),
                "denied": dict(self._denied),
            }


def build_guard_from_advanced(adv: Optional[dict],
                              ledger: Optional[Any] = None,
                              cost_source: Optional[Callable[[], float]] = None
                              ) -> Optional[LLMGuard]:
    """从 ``advanced.llm_guard`` 配置段构造护栏（env 可覆盖）。

    - ``enabled: false`` 或无任何上限 → 返回 None（不装，行为零变化）
    - ``ledger`` / ``cost_source``: 成本上限的数据源（cost_source 优先）
    - env 覆盖：HACKSCANNER_LLM_RATE / _BURST / _DAILY_CAP / _MAX_CALLS / _COST_CAP
    """
    cfg = (adv or {}).get("llm_guard") or {}
    if cfg.get("enabled", True) is False:
        return None

    rate = _env_float("HACKSCANNER_LLM_RATE", cfg.get("rate_per_min"))
    burst = _env_int("HACKSCANNER_LLM_BURST", cfg.get("burst"))
    daily = _env_int("HACKSCANNER_LLM_DAILY_CAP", cfg.get("daily_call_cap"))
    total = _env_int("HACKSCANNER_LLM_MAX_CALLS", cfg.get("max_calls"))
    cost = _env_float("HACKSCANNER_LLM_COST_CAP", cfg.get("cost_cap_usd"))

    # 全关 → 不装（避免零变化的包装层）
    if not any([rate, daily, total, cost]):
        return None

    return LLMGuard(
        rate_per_min=rate, burst=burst,
        daily_call_cap=daily, max_calls=total, cost_cap_usd=cost,
        ledger=ledger, cost_source=cost_source,
    )


def install_llm_guard(llm_invoke: Callable, guard: LLMGuard) -> Callable:
    """包 ``llm_invoke``：调用前经护栏判定；拒绝 → 返回 None（干净终止）。

    - orchestrator 零改动（只换 invoke 函数）
    - 护栏自身异常 → fail-open 放行（绝不因护栏拖垮 LLM 调用）
    - 幂等：已包装的返回原函数
    - 保留 ``.client``（入口层读 usage 用）
    """
    if guard is None:
        return llm_invoke
    if getattr(llm_invoke, "_llm_guard_wrapped", False):
        return llm_invoke

    def wrapped(*args, **kwargs):
        allowed, reason = True, ""
        try:
            allowed, reason = guard.check()
        except Exception as exc:  # 护栏自身异常 → 放行（fail-open）
            allowed, reason = True, f"guard_error:{type(exc).__name__}"
        if not allowed:
            logger.warning("🚫 LLM 调用被护栏拒绝: %s", reason)
            return None

        res = llm_invoke(*args, **kwargs)
        try:
            guard.note_call()
        except Exception:
            pass
        return res

    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._llm_guard_wrapped = True
    wrapped.guard = guard
    return wrapped
