#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
报告验证器 — campaign 收尾时对"发现列表 + 报告文件"做结构化自检。

参照 vulnclaw/report/verifier.py 的结构化验证思路
（VerificationStatus / VerifiedFinding / verify_batch 的分级裁决 + 中文拒绝理由），
但【不移植】其 VerifierExecutor.execute_poc 子进程执行——那是真实发请求跑 PoC，
超出本次"零执行"边界（留作后续 --verify-live 开关）。

本模块纯标准库、纯逻辑、不发任何网络请求：
    verify_report(report_path, findings) -> VerifiedSummary
        - 每条 finding：title/severity 合法、severity 与 CVSS 一致、evidence 非占位符
        - 报告文件：存在且非空、HTML 主标签基本闭合
        - 每条 rejected finding 给出中文 rejection_reason（vulnclaw 同款映射）
    generate_poc_snippets(findings) -> [str]
        - 可复现 finding（evidence/description 含 http(s) URL）→ curl 复现片段
          （只生成不执行）
    append_poc_appendix(report_path, findings) -> bool
        - 把 PoC 片段以 <section> 附进 HTML 报告尾部（幂等：带标记注释）

任何异常都收敛为"跳过 + 记录原因"，不崩、不阻断主摘要（入口层钩子语义）。
"""

from __future__ import annotations

import html
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# 裁决模型
# ---------------------------------------------------------------------------
class VerificationStatus(str, Enum):
    VERIFIED = "verified"    # 通过
    REJECTED = "rejected"    # 不通过（附 rejection_reason）
    SKIPPED = "skipped"      # 无法裁决（输入缺失，不算失败）


_SEVERITY_ALIASES = {
    "critical": "critical", "crit": "critical",
    "high": "high",
    "medium": "medium", "moderate": "medium", "med": "medium",
    "low": "low",
    "info": "info", "informational": "info", "none": "info",
}

# severity 与 CVSS v3.1 分数带的对应关系（计划⑥：critical≥9 / high 7–<9 /
# medium 4–<7 / low <4 / info 0）
_SEVERITY_BANDS: Dict[str, tuple] = {
    "critical": (9.0, 10.0),
    "high": (7.0, 8.999),
    "medium": (4.0, 6.999),
    "low": (0.0, 3.999),
    "info": (0.0, 0.499),
}

# 占位符 evidence 特征（vulnclaw verifier 同款思路）
_PLACEHOLDER_VALUES = {
    "", "n/a", "na", "tbd", "todo", "none", "null", "undefined",
    "-", "—", "…", "see above", "见上文", "略",
}

# 中文拒绝理由映射（按检查顺序取第一条命中）
_REASON_MISSING_TITLE = "缺少发现标题"
_REASON_BAD_SEVERITY = "severity 取值非法（应为 critical/high/medium/low/info）"
_REASON_SEV_CVSS = "severity 与 CVSS 分数不一致（{sev} vs {cvss:g}）"
_REASON_NO_EVIDENCE = "evidence 缺失或为占位符"
_REASON_NO_CVSS = "缺少 CVSS 分数且 severity 高于 info"


@dataclass
class VerifiedFinding:
    title: str = ""
    status: VerificationStatus = VerificationStatus.SKIPPED
    rejection_reason: str = ""
    severity: str = ""
    cvss_score: Optional[float] = None


@dataclass
class VerifiedSummary:
    total: int = 0
    verified: int = 0
    rejected: int = 0
    skipped: int = 0
    report_ok: Optional[bool] = None        # None = 未检查（无报告路径）
    report_reasons: List[str] = field(default_factory=list)
    findings: List[VerifiedFinding] = field(default_factory=list)

    @property
    def passed(self) -> int:
        return self.verified

    @property
    def failures(self) -> List[VerifiedFinding]:
        return [f for f in self.findings if f.status is VerificationStatus.REJECTED]

    def to_lines(self) -> List[str]:
        """打印用行（中文，非阻塞语义）。"""
        lines = [f"报告自检: {self.verified}/{self.total} 通过"]
        if self.report_ok is True:
            lines.append("  报告文件: 存在且结构完整")
        elif self.report_ok is False:
            lines.append("  报告文件: " + "；".join(self.report_reasons))
        else:
            lines.append("  报告文件: 未检查")
        for f in self.failures:
            lines.append(f"  ✗ [{f.severity or '?'}] {f.title or '(无标题)'} — {f.rejection_reason}")
        return lines


# ---------------------------------------------------------------------------
# 单项检查
# ---------------------------------------------------------------------------
def _normalize_severity(value: Any) -> Optional[str]:
    s = str(value or "").strip().lower()
    return _SEVERITY_ALIASES.get(s)


def _cvss_of(finding: Dict[str, Any]) -> Optional[float]:
    raw = finding.get("cvss_score")
    try:
        if raw is None:
            return None
        v = float(raw)
        return max(0.0, min(10.0, v))
    except (TypeError, ValueError):
        m = re.search(r'"?cvss_score"?\s*[:=]\s*([\d.]+)', str(finding.get("cvss_score", "")))
        if m:
            try:
                return float(m.group(1))
            except ValueError:
                return None
        return None


def _evidence_text(finding: Dict[str, Any]) -> str:
    """evidence 可能是 list(Evidence) / str / None — 统一成可检查的文本。"""
    ev = finding.get("evidence")
    if ev is None:
        return ""
    if isinstance(ev, str):
        return ev
    if isinstance(ev, (list, tuple)):
        parts = []
        for item in ev:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                for key in ("value", "content", "text", "raw_output", "data"):
                    v = item.get(key)
                    if isinstance(v, str) and v.strip():
                        parts.append(v)
                        break
        return " | ".join(parts)
    return str(ev)


def _is_placeholder(text: str) -> bool:
    t = " ".join(str(text or "").split())
    # BUG_REPORT [7]：删掉 `len(t) < 15` 一刀切长度闸——经典短证据
    # （/etc/passwd、1=1、admin、<b>、alert(1)、200 OK）全被误判为占位符，
    # 导致 verify_finding 误 REJECT、X/Y passed 指标失真。
    # 占位词表（_PLACEHOLDER_VALUES）+ 空文本判断已足以覆盖占位语义。
    return not t or t.lower() in _PLACEHOLDER_VALUES


def verify_finding(finding: Any) -> VerifiedFinding:
    """单条 finding 裁决（纯逻辑）。非 dict 输入 → SKIPPED，不崩。"""
    if not isinstance(finding, dict):
        return VerifiedFinding(title=str(finding)[:80] or "(非结构化)",
                               status=VerificationStatus.SKIPPED,
                               rejection_reason="非结构化输入，跳过裁决")

    title = str(finding.get("title") or "").strip()
    severity_raw = finding.get("severity")
    cvss = _cvss_of(finding)
    severity = _normalize_severity(severity_raw)

    out = VerifiedFinding(title=title[:120] or "(无标题)",
                           severity=severity or "",
                           cvss_score=cvss)

    if not title:
        out.status = VerificationStatus.REJECTED
        out.rejection_reason = _REASON_MISSING_TITLE
        return out
    if severity is None:
        out.status = VerificationStatus.REJECTED
        out.rejection_reason = _REASON_BAD_SEVERITY
        return out
    if cvss is None:
        if severity in ("critical", "high", "medium"):
            out.status = VerificationStatus.REJECTED
            out.rejection_reason = _REASON_NO_CVSS
            return out
        # info/low 允许 0 分
        cvss = 0.0
        out.cvss_score = cvss
    band = _SEVERITY_BANDS[severity]
    if not (band[0] <= cvss <= band[1]):
        out.status = VerificationStatus.REJECTED
        out.rejection_reason = _REASON_SEV_CVSS.format(sev=severity, cvss=cvss)
        return out
    if _is_placeholder(_evidence_text(finding)):
        out.status = VerificationStatus.REJECTED
        out.rejection_reason = _REASON_NO_EVIDENCE
        return out

    out.status = VerificationStatus.VERIFIED
    return out


def _check_report_file(report_path: str) -> tuple:
    """报告文件存在性 + 基本结构。返回 (ok, reasons)。"""
    reasons: List[str] = []
    if not report_path:
        return False, ["报告路径为空"]
    if not os.path.isfile(report_path):
        return False, [f"文件不存在: {report_path}"]
    try:
        size = os.path.getsize(report_path)
    except OSError as exc:
        return False, [f"无法读取: {exc}"]
    if size < 200:
        return False, [f"文件过小（{size} 字节），疑似空报告"]
    try:
        with open(report_path, "r", encoding="utf-8", errors="replace") as fh:
            head = fh.read(4096)
        body_l = head.lower()
        is_html = "<html" in body_l or "<!doctype html" in body_l
        if is_html:
            with open(report_path, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read()
            tl = text.lower()
            for tag in ("</html>", "</body>"):
                if tag not in tl:
                    reasons.append(f"HTML 缺少闭合标签 {tag}")
    except OSError as exc:
        reasons.append(f"读取失败: {exc}")
    if reasons:
        return False, reasons
    return True, []


# ---------------------------------------------------------------------------
# PoC 复现片段（只生成不执行）
# ---------------------------------------------------------------------------
_URL_RE = re.compile(r"https?://[^\s'\"<>)\]\},]+")


def _finding_urls(finding: Dict[str, Any]) -> List[str]:
    text_parts = [
        str(finding.get("title") or ""),
        str(finding.get("description") or finding.get("detail") or ""),
        _evidence_text(finding),
    ]
    urls: List[str] = []
    for part in text_parts:
        for u in _URL_RE.findall(part or ""):
            u = u.rstrip(".,;:")
            if u not in urls:
                urls.append(u)
    return urls


def generate_poc_snippets(findings: Optional[List[Any]], max_findings: int = 5) -> List[str]:
    """为可复现 finding（含 http(s) URL）生成 curl 复现片段。

    只生成文本，不执行任何请求。无 URL 的 finding 跳过。
    """
    snippets: List[str] = []
    for f in findings or []:
        if not isinstance(f, dict):
            continue
        urls = _finding_urls(f)
        if not urls:
            continue
        url = urls[0]
        title = str(f.get("title") or "finding")[:80]
        snippets.append(
            f"# {title}\n"
            f"# 复现片段（只读探测，请在已授权环境内自行执行）\n"
            f"curl -sS -i --max-time 10 '{url}' \\\n"
            f"  -H 'User-Agent: Mozilla/5.0 (PoC-repro)'"
        )
        if len(snippets) >= max_findings:
            break
    return snippets


_POC_MARKER = "<!-- hack-scanner:poc-appendix -->"


def append_poc_appendix(report_path: str, findings: Optional[List[Any]],
                        max_findings: int = 5) -> bool:
    """把 PoC 片段附进 HTML 报告尾部。幂等（标记注释已存在则跳过）。"""
    if not report_path or not os.path.isfile(report_path):
        return False
    snippets = generate_poc_snippets(findings, max_findings)
    if not snippets:
        return False
    try:
        with open(report_path, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
        if _POC_MARKER in text:
            return False
        if "</html>" in text.lower():
            block = (
                "\n" + _POC_MARKER + "\n"
                + '<section id="poc-appendix" style="font-family:monospace;">'
                + "<h2>Appendix A — PoC reproduction snippets (read-only)</h2>\n"
                + "".join(f"<pre>{html.escape(s)}</pre>\n" for s in snippets)
                + "</section>\n"
            )
            idx = text.lower().rfind("</html>")
            text = text[:idx] + block + text[idx:]
        else:
            text += "\n\n" + _POC_MARKER + "\n" + "\n---\n\n".join(snippets) + "\n"
        with open(report_path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return True
    except OSError:
        return False


# ---------------------------------------------------------------------------
# 批量入口
# ---------------------------------------------------------------------------
def verify_report(report_path: Optional[str], findings: Optional[List[Any]]
                  ) -> VerifiedSummary:
    """批量验证入口。任何异常 → SKIPPED 兜底，绝不抛出。"""
    summary = VerifiedSummary()
    findings = [f for f in (findings or []) if f is not None][:50]
    summary.total = len(findings)
    for f in findings:
        try:
            vf = verify_finding(f)
        except Exception as exc:  # 单项异常不影响整体
            vf = VerifiedFinding(title=str(f)[:80],
                                 status=VerificationStatus.SKIPPED,
                                 rejection_reason=f"裁决异常: {type(exc).__name__}")
        summary.findings.append(vf)
        if vf.status is VerificationStatus.VERIFIED:
            summary.verified += 1
        elif vf.status is VerificationStatus.REJECTED:
            summary.rejected += 1
        else:
            summary.skipped += 1

    try:
        ok, reasons = _check_report_file(report_path or "")
        summary.report_ok = ok
        summary.report_reasons = reasons
    except Exception as exc:
        summary.report_ok = None
        summary.report_reasons = [f"报告检查异常: {type(exc).__name__}"]
    return summary


if __name__ == "__main__":
    # 自测：好报告全过 / 坏报告列失败 / PoC 片段 / 附录幂等
    good = [
        {"title": "SQL injection in /login", "severity": "critical", "cvss_score": 9.8,
         "evidence": "response contained 'SELECT * FROM users' with our marker string"},
        {"title": "Reflected XSS in /search", "severity": "high", "cvss_score": 7.5,
         "evidence": "http://target/search? q=<script>alert(1)</script> reflected unencoded"},
        {"title": "Missing security headers", "severity": "low", "cvss_score": 2.0,
         "evidence": "CSP header absent on all 40 sampled responses"},
    ]
    bad = [
        {"title": "", "severity": "high", "cvss_score": 8.0, "evidence": "ok evidence here"},
        {"title": "Bad sev", "severity": "urgent", "cvss_score": 8.0, "evidence": "ok evidence here"},
        {"title": "Sev/CVSS mismatch", "severity": "high", "cvss_score": 5.0,
         "evidence": "ok evidence here long enough"},
        {"title": "No evidence", "severity": "medium", "cvss_score": 5.0, "evidence": "N/A"},
    ]
    s = verify_report("", good)
    assert s.verified == 3 and s.rejected == 0, f"好报告应 3/3: {s.to_lines()}"
    s2 = verify_report("", bad)
    assert s2.verified == 0 and s2.rejected == 4, f"坏报告应 4 条失败: {s2.to_lines()}"
    assert all(f.rejection_reason for f in s2.failures), "每条失败都要有中文理由"

    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        rp = os.path.join(tmp, "r.html")
        with open(rp, "w", encoding="utf-8") as fh:
            fh.write("<html><body><h1>Report</h1>" + "x" * 300 + "</body></html>")
        s3 = verify_report(rp, good)
        assert s3.report_ok is True, f"好 HTML 报告应通过: {s3.report_reasons}"
        assert append_poc_appendix(rp, good) is True, "含 URL 的 finding 应生成 PoC 附录"
        assert append_poc_appendix(rp, good) is False, "附录应幂等（第二次跳过）"
        with open(rp, "r", encoding="utf-8") as fh:
            content = fh.read()
        assert _POC_MARKER in content and "curl -sS" in content
        # 空报告 → report_ok False
        with open(os.path.join(tmp, "empty.html"), "w") as fh:
            fh.write("<html>")
        assert verify_report(os.path.join(tmp, "empty.html"), good).report_ok is False

    print("report_verifier self-test OK")
