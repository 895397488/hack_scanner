#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FeroxBuster Wrapper — feroxbuster CLI wrapper，Rust 编写的最快目录爆破引擎。

作为 gobuster/ffuf 的大目标备选：多线程、速度快，
适合对大型站点做快速目录普查。

集成方式：需要安装 feroxbuster
  - Windows: choco install feroxbuster  或  https://github.com/epi/feroxbuster/releases
  - Linux:   手动安装（见 release 页面）
本模块只负责 CLI 调用和结果解析。config.json → tools.feroxbuster_path 可指定路径。

Usage:
    from scanners.feroxbuster_wrapper import feroxbuster_scan
    result = feroxbuster_scan("https://example.com")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('feroxbuster_scanner')


def _find_feroxbuster() -> Optional[str]:
    """查找 feroxbuster 可执行文件：先 config.json → tools.feroxbuster_path，再 PATH"""
    # 1) config.json tools.feroxbuster_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("feroxbuster_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["feroxbuster", "feroxbuster.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_feroxbuster_output(output: str, base_url: str = "") -> list:
    """解析 feroxbuster 输出。

    feroxbuster 关键行格式（默认 -x 不带扩展名，URL + [status] + size + time）:
      /admin                  [200]      1234     0.001
      /admin/                 [301]        0     0.002
    或带状态:
      [200] /admin  (1234 bytes)
    """
    findings = []
    for line in output.splitlines():
        line = line.strip()
        if not line or line.startswith("=="):
            continue

        # 格式 1: /path [200] size time
        m = re.match(r'^(\S+)\s+\[(\d{3})\]', line)
        if m:
            path, status = m.group(1), m.group(2)
            size_m = re.search(r'\[(\d{3})\]\s+(\d+)', line)
            size = int(size_m.group(2)) if size_m else 0
        else:
            # 格式 2: [200] /path
            m2 = re.match(r'^\[(\d{3})\]\s+(\S+)', line)
            if not m2:
                continue
            status, path = m2.group(1), m2.group(2)
            size = 0

        if not path.startswith("/"):
            continue

        url = f"{base_url.rstrip('/')}{path}"
        code = int(status)
        severity = "medium" if code in (200, 403, 401, 500) else "info"

        findings.append({
            "url": url,
            "path": path,
            "status": status,
            "size": size,
            "severity": severity,
        })

    return findings


def feroxbuster_scan(
    target: str,
    wordlist: str = "",
    threads: int = 37,
    extensions: str = "",
    max_time: int = 300,
) -> dict:
    """运行 feroxbuster 目录爆破。

    Args:
        target: 目标 URL（如 https://example.com/）
        wordlist: 字典文件路径（不传用内置字典）
        threads: 并发线程数
        extensions: 扩展名（如 php,html,jsp）
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "findings": [...], "findings_count": N, "error": ""}
    """
    ferox_path = _find_feroxbuster()
    if not ferox_path:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "findings_count": 0,
            "error": "feroxbuster 未找到，请安装: choco install feroxbuster (Windows) 或见 https://github.com/epi/feroxbuster/releases",
        }

    cmd = [
        ferox_path,
        "-u", target.rstrip("/"),
        "-t", str(threads),
        "-s", "200,201,204,301,302,307,401,403,500",  # 状态码过滤
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd.extend(["-x", wordlist])
    if extensions:
        cmd.extend(["-e", extensions])

    logger.info(f"feroxbuster scan: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""
        findings = _parse_feroxbuster_output(output, target)

        return {
            "ok": True,
            "target": target,
            "findings": findings[:500],
            "findings_count": len(findings),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target": target, "findings": [], "findings_count": 0, "error": "feroxbuster 超时"}
