#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Parameter Injection Engine (参数注入引擎)
============================================

当目标 URL 无 query string 时，自动推断并生成探测参数。

解决的问题：
- REST API: /api/users/123 → 路径参数 id=123
- POST endpoint: POST /api/orders → body {id, name, action}
- Cookie-based: Set-Cookie session=xxx → cookie injection
- Header-based: X-User-ID, Authorization → header injection
- 无 query string URL (如 taobao.com/goods/detail) → 自动注入默认测试参数

使用方式：
    from scanners.parameter_injector import ParameterInjector

    injector = ParameterInjector()

    # 分析 URL，返回 (has_query, injection_points)
    has_query, points = injector.analyze_url(
        "https://example.com/api/users/123",
        response_headers={"Set-Cookie": "session=abc123"},
        response_body="<form>...",
    )

    # 获取带注入参数的测试 URL 列表
    test_urls = injector.build_test_urls("https://example.com/api/users", points)
"""

from __future__ import annotations

import re
import logging
from urllib.parse import urlparse, urlencode, quote_plus
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------

class InjectionPoint:
    """一个注入点，描述在哪个位置、用什么参数名、测试什么载荷。"""

    def __init__(self, location: str, param_name: str, test_value: str,
                 payload_desc: str = ""):
        self.location = location     # 'get' | 'post_body' | 'cookie' | 'header' | 'path_param'
        self.param_name = param_name
        self.test_value = test_value
        self.payload_desc = payload_desc

    @property
    def description(self) -> str:
        return f"{self.location}:{self.param_name}={self.test_value}"


# ---------------------------------------------------------------------------
# Keyword Dictionaries — 常见 Web 框架的参数名约定
# ---------------------------------------------------------------------------

PATH_SEGMENT_KEYWORDS = [
    'user', 'api', 'admin', 'product', 'order', 'post', 'article',
    'file', 'doc', 'item', 'record', 'project', 'task', 'comment',
]

ID_PARAM_MAP = {
    'user': 'user_id', 'users': 'user_id',
    'admin': 'id',
    'product': 'product_id', 'products': 'product_id',
    'order': 'order_id', 'orders': 'order_id',
    'post': 'post_id', 'posts': 'post_id',
    'article': 'article_id', 'articles': 'article_id',
    'file': 'file_id', 'files': 'file_id',
    'doc': 'doc_id', 'docs': 'doc_id',
    'item': 'item_id', 'items': 'item_id',
    'record': 'record_id', 'records': 'record_id',
    'project': 'project_id', 'projects': 'project_id',
    'task': 'task_id', 'tasks': 'task_id',
    'comment': 'comment_id', 'comments': 'comment_id',
    'api': 'id',
}

COOKIE_KEYWORDS = [
    'session', 'token', 'auth', 'sid', 'phpsessid', 'jsessionid',
    'csrftoken', 'csrf_token', 'remember_me', 'user_id', 'uid',
]

HEADER_KEYWORDS = [
    'X-User-ID', 'X-Auth-Token', 'Authorization', 'X-API-Key',
    'X-Session-ID', 'X-CSRF-Token', 'Cookie',
]


# ---------------------------------------------------------------------------
# Core: Parameter Injector
# ---------------------------------------------------------------------------

class ParameterInjector:
    """URL query string 缺失时的自动参数注入引擎。"""

    def __init__(self):
        # SQLi payloads (按风险递增)
        self._sqli_payloads = [
            ("1'%20OR%20'1'='1", "SQLi-OR-tautology"),
            ("1'%20AND%20'1'='2--", "SQLi-AND-false"),
        ]
        # XSS payloads
        self._xss_payloads = [
            ("<script>alert(1)</script>", "XSS-script"),
            ("<img src=x onerror=alert(1)>", "XSS-img-onerror"),
            ("javascript:alert(1)", "XSS-javascript-uri"),
            ("<svg onload=alert(1)>", "XSS-svg-onload"),
        ]
        # LFI payloads
        self._lfi_payloads = [
            ("/etc/passwd", "LFI-etc-passwd"),
            ("....//....//....//etc/passwd", "LFI-traversal"),
        ]

    # -------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------

    def analyze_url(self, url: str, response_headers: Dict[str, str] = None,
                    response_body: str = "") -> Tuple[bool, List[InjectionPoint]]:
        """
        分析 URL，判断是否有 query string；如果没有则生成注入点列表。

        Returns:
            (has_query, injection_points) — has_query=True 时无需额外注入
        """
        parsed = urlparse(url)
        has_query = bool(parsed.query.strip())

        if has_query:
            return True, []

        # 无 query string → 生成探测参数
        points = self._generate_injection_points(
            url, parsed, response_headers or {}, response_body or ""
        )

        if points:
            locations = {}
            for p in points:
                locations[p.location] = locations.get(p.location, 0) + 1
            loc_str = ", ".join(f"{k}: {v}" for k, v in sorted(locations.items()))
            logger.info(
                f"  [ParameterInjection] URL 无 query string，已自动注入 "
                f"{len(points)} 个探测点 [{loc_str}]"
            )

        return False, points

    def build_test_urls(self, base_url: str, points: List[InjectionPoint]) -> List[str]:
        """将注入点转为测试 URL (GET/cookie/header) 列表。"""
        urls = []
        seen = set()

        for pt in points:
            if pt.location == 'get':
                query = f"{pt.param_name}={quote_plus(pt.test_value)}"
                sep = '&' if urlparse(base_url).query else '?'
                test_url = f"{base_url}{sep}{query}"
                urls.append(test_url)

            elif pt.location == 'cookie':
                # Cookie 注入通过请求头传递，URL 不变 → 记录为单独标记
                urls.append(f"__COOKIE__:{pt.param_name}={pt.test_value}")

            elif pt.location == 'header':
                # Header 注入同样 URL 不变
                urls.append(f"__HEADER__:{pt.param_name}={pt.test_value}")

            elif pt.location in ('post_body', 'path_param'):
                # Body/Path → 通过 query param 模拟（最兼容的方式）
                sep = '&' if urlparse(base_url).query else '?'
                test_url = f"{base_url}{sep}{pt.param_name}={quote_plus(pt.test_value)}"
                urls.append(test_url)

            key = f"{pt.location}:{pt.param_name}"
            seen.add(key)

        return list(dict.fromkeys(urls))  # dedupe while preserving order

    def get_injection_headers(self, points: List[InjectionPoint]) -> Dict[str, str]:
        """返回需要附加的 Cookie/Header 注入请求头。"""
        headers = {}
        for pt in points:
            if pt.location == 'cookie':
                cookie_val = f"{pt.param_name}={pt.test_value}"
                current = headers.get('Cookie', '')
                headers['Cookie'] = f"{current}; {cookie_val}".strip().lstrip('; ')
            elif pt.location == 'header':
                headers[pt.param_name] = pt.test_value
        return headers

    def get_injection_bodies(self, points: List[InjectionPoint]) -> Dict[str, str]:
        """返回需要作为 POST body 发送的参数。"""
        body = {}
        for pt in points:
            if pt.location == 'post_body':
                body[pt.param_name] = pt.test_value
        return body

    # -------------------------------------------------------------------
    # Internal: Injection Point Generation Strategies
    # -------------------------------------------------------------------

    def _generate_injection_points(
        self, url: str, parsed, resp_headers: Dict[str, str], body: str
    ) -> List[InjectionPoint]:
        """综合多策略生成注入点。"""
        points: List[InjectionPoint] = []

        # Strategy 1: URL path segment 推断 (GET + path param)
        points.extend(self._strategy_path_params(url, parsed))

        # Strategy 2: Set-Cookie → cookie injection
        points.extend(self._strategy_cookie(resp_headers))

        # Strategy 3: Auth/API paths → header injection
        points.extend(self._strategy_header(url, parsed))

        # Strategy 4: POST body (form-heavy pages) → body injection
        if '<form' in body.lower() or 'submit' in body.lower():
            points.extend(self._strategy_body(parsed, body))

        # Strategy 5: Generic fallback — 基于 URL path 猜常见参数名
        if not points:
            points.extend(self._strategy_fallback(parsed))

        return points

    def _strategy_path_params(self, url: str, parsed) -> List[InjectionPoint]:
        """从 URL 路径段推断 ID/名称参数。"""
        points = []
        segments = [s for s in parsed.path.strip('/').split('/') if s]

        for seg in segments:
            # a) 路径段是数字/UUID → 很可能是 ID
            if self._looks_like_id(seg):
                for payload, desc in self._sqli_payloads[:1]:
                    points.append(InjectionPoint('get', 'id', payload, desc))
                for pload, pdesc in self._xss_payloads[:1]:
                    points.append(InjectionPoint('get', 'id', pload, pdesc))
                break

            # b) 路径段是关键词 → 映射到对应参数名
            seg_lower = seg.lower()
            if seg_lower in ID_PARAM_MAP:
                param = ID_PARAM_MAP[seg_lower]
                for payload, desc in self._sqli_payloads[:1]:
                    points.append(InjectionPoint('get', param, payload, desc))
                for pload, pdesc in self._xss_payloads[:1]:
                    points.append(InjectionPoint('get', param, pload, pdesc))
                break

        return points

    def _strategy_cookie(self, headers: Dict[str, str]) -> List[InjectionPoint]:
        """从 Set-Cookie 头提取 cookie 名称并注入。"""
        points = []
        set_cookie = headers.get('Set-Cookie', headers.get('set-cookie', ''))

        if not set_cookie:
            return points

        # Parse cookie names from Set-Cookie
        cookie_names = re.findall(r'([^=;]+?)\s*=', set_cookie)
        for cname in cookie_names[:3]:
            points.append(InjectionPoint('cookie', cname.strip(), "injected"))

        if not cookie_names:
            for cname in COOKIE_KEYWORDS[:2]:
                points.append(InjectionPoint('cookie', cname, "injected"))

        return points

    def _strategy_header(self, url: str, parsed) -> List[InjectionPoint]:
        """对认证/API 路径推断 header injection。"""
        points = []
        path_lower = parsed.path.lower()

        if any(kw in path_lower for kw in ['auth', 'api', 'token', 'admin', 'login', 'session']):
            for hname in HEADER_KEYWORDS[:3]:
                points.append(InjectionPoint('header', hname, "injected"))

        return points

    def _strategy_body(self, parsed, body: str) -> List[InjectionPoint]:
        """对 form 页面推断 body injection。"""
        points = []

        # Try to extract input names from HTML forms
        form_inputs = re.findall(r'<input[^>]*name=["\']([^"\']+)["\']', body, re.I)
        if form_inputs:
            for fname in form_inputs[:5]:
                fl = fname.lower()
                if any(k in fl for k in ['id', 'user', 'email', 'name', 'action', 'token']):
                    for payload, desc in self._sqli_payloads[:1]:
                        points.append(InjectionPoint('post_body', fname, payload, desc))

        if not form_inputs:
            # Fallback to common form field names
            for fname in ['id', 'name', 'action']:
                for payload, desc in self._sqli_payloads[:1]:
                    points.append(InjectionPoint('post_body', fname, payload, desc))

        return points

    def _strategy_fallback(self, parsed) -> List[InjectionPoint]:
        """无更多信息时的通用回退。"""
        points = []
        path_lower = parsed.path.lower()

        # Extract potential parameter names from URL segments
        for seg in path_lower.split('/'):
            if seg in ID_PARAM_MAP:
                param = ID_PARAM_MAP[seg]
                for payload, desc in self._sqli_payloads[:1]:
                    points.append(InjectionPoint('get', param, payload, desc))
                for pload, pdesc in self._xss_payloads[:1]:
                    points.append(InjectionPoint('get', param, pload, pdesc))
                break

        # Still no match → universal fallback
        if not points:
            for param in ['id', 'p', 'page']:
                for payload, desc in self._sqli_payloads[:1]:
                    points.append(InjectionPoint('get', param, payload, desc))
                for pload, pdesc in self._xss_payloads[:1]:
                    points.append(InjectionPoint('get', param, pload, pdesc))

        return points

    @staticmethod
    def _looks_like_id(seg: str) -> bool:
        """判断路径段是否像 ID (纯数字/UUID)。"""
        if seg.isdigit():
            return True
        uuid_pat = re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
        return bool(uuid_pat.match(seg))


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def analyze_url_injections(
    url: str,
    response_headers: Dict[str, str] = None,
    response_body: str = "",
) -> Tuple[bool, List[InjectionPoint]]:
    """快捷函数：分析 URL 是否需要参数注入。"""
    injector = ParameterInjector()
    return injector.analyze_url(url, response_headers or {}, response_body or "")


# ---------------------------------------------------------------------------
# CLI Entry-point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    test_cases = [
        ("https://example.com/api/users/123", {"Set-Cookie": "session=abc"}, ""),
        ("https://www.taobao.com/goods/detail", {}, ""),
        ("https://example.com/login", {}, "<form name='login'><input name='username'/><input name='password'/></form>"),
        ("https://example.com/api/products?category=electronics", {}, ""),  # has query → skip
    ]

    injector = ParameterInjector()

    for url, headers, body in test_cases:
        print(f"\n{'='*70}")
        print(f"URL: {url}")
        has_q, pts = injector.analyze_url(url, headers, body)
        print(f"  has_query={has_q}, injection_points={len(pts)}")

        if not has_q and pts:
            urls = injector.build_test_urls(url, pts)
            for u in urls[:5]:
                print(f"    → {u}")
            hdrs = injector.get_injection_headers(pts)
            bodies = injector.get_injection_bodies(pts)
            if hdrs:
                print(f"    Headers: {hdrs}")
            if bodies:
                print(f"    Body: {bodies}")
