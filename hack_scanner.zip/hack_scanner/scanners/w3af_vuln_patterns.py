#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
w3af 漏洞模式数据库 — 从 w3af (w3af.org) audit/attack 插件中提取的完整漏洞检测模式库。

涵盖 w3af 定义的所有主要漏洞类型，为 hack_scanner 提供丰富的正则匹配规则：
- SQL 注入特征模式 (MySQL/PostgreSQL/MSSQL/Oracle/SQLite)
- XSS 反射/存储型/DOM-based 检测
- CSRF Token 验证缺失检测
- LDAP/XPath 注入
- ReDoS / SSRF / RFI / LFI
- 服务器端 Include / PHP Info / ShellShock
- SSL/TLS 配置问题
- Open Redirect / Insecure DAV

Usage:
    from scanners.w3af_vuln_patterns import VulnPatternDB, check_for_patterns

    patterns = VulnPatternDB()
    findings = patterns.scan_response(response_text, url)
    # -> [{'type': 'sqli', 'confidence': 0.9, 'pattern_name': 'mysql_sleep'}, ...]
"""

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Pattern, Tuple


logger = logging.getLogger('w3af_vuln_patterns')

# Severity levels (used in pattern tuples like ('sqli', re.compile(...), 'name', HIGH))
CRITICAL = 'critical'
HIGH = 'high'
MEDIUM = 'medium'
LOW = 'low'
INFO = 'info'


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class VulnPatternFinding:
    """A vulnerability pattern match."""
    vuln_type: str                  # 'sqli', 'xss', 'csrf', etc.
    pattern_name: str               # Specific pattern that matched
    confidence: float = 0.5         # 0-1 confidence score
    severity: str = 'info'          # 'critical', 'high', 'medium', 'low', 'info'
    dbms_guess: str = ''            # Detected database system (for SQLi)
    description: str = ''           # Human-readable description
    remediation: str = ''           # Suggested fix
    w3af_vuln_id: int = 0           # w3af internal vulnerability ID

    def to_dict(self) -> Dict[str, Any]:
        return {
            'type': self.vuln_type,
            'pattern': self.pattern_name,
            'confidence': self.confidence,
            'severity': self.severity,
            'dbms_guess': self.dbms_guess,
            'description': self.description[:120],
            'w3af_vuln_id': self.w3af_vuln_id,
        }


# ====================================================================
# Vulnerability Pattern Database (from w3af vulns.py + all audit plugins)
# ====================================================================

class VulnPatternDB:
    """Complete vulnerability pattern database from w3af (adapted for hack_scanner)."""

    # SQL Injection detection patterns (w3af audit_sqli plugin)
    SQLI_PATTERNS: List[Tuple[str, Pattern, str]] = [
        # MySQL time-based
        ('sqli', re.compile(r'SLEEP\(\d+\)', re.I), 'mysql_sleep', HIGH),
        ('sqli', re.compile(r'benchmark\s*\(\s*\d+', re.I), 'mysql_benchmark', HIGH),
        # PostgreSQL time-based
        ('sqli', re.compile(r'pg_sleep\s*\(', re.I), 'postgresql_pg_sleep', HIGH),
        # MSSQL time-based
        ('sqli', re.compile(r'WAITFOR\s+DELAY', re.I), 'mssql_waitfor', HIGH),
        ('sqli', re.compile(r'waitfor\s+delay', re.I), 'mssql_waitfor_lower', HIGH),
        # Oracle
        ('sqli', re.compile(r'dbms_utility\.time_delay', re.I), 'oracle_time_delay', HIGH),
        # UNION SELECT
        ('sqli', re.compile(r'UNION\s+(ALL\s+)?SELECT', re.I), 'union_select', HIGH),
        # Comment injection
        ('sqli', re.compile(r"'--", re.I), 'sql_comment_injection', MEDIUM),
        ('sqli', re.compile(r'"\-\-', re.I), 'sql_comment_double_quote', MEDIUM),
        # OR tautology
        ('sqli', re.compile(r"OR\s+[0-9]+\s*=\s*[0-9]+", re.I), 'sql_tautology', HIGH),
        ('sqli', re.compile(r"OR\s+'[^']*'\s*=\s*'[^']*'", re.I), 'sql_tautology_str', HIGH),
        # Stack query (Oracle)
        ('sqli', re.compile(r';\s*(SELECT|INSERT|UPDATE|DELETE|DROP)\b', re.I), 'sql_stack_query', HIGH),
    ]

    # XSS detection patterns (w3af audit_xss plugin)
    XSS_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('xss', re.compile(r'<\s*script[^>]*>', re.I), 'script_tag', HIGH),
        ('xss', re.compile(r'javascript\s*:', re.I), 'javascript_uri', HIGH),
        ('xss', re.compile(r'on(error|load|click|mouseover|focus|blur)\s*=', re.I), 'event_handler_xss', HIGH),
        ('xss', re.compile(r'<\s*img[^>]+onerror\s*=', re.I), 'img_onerror_xss', HIGH),
        ('xss', re.compile(r'<\s*svg[^>]+onload\s*=', re.I), 'svg_onload_xss', HIGH),
        ('xss', re.compile(r'<\s*iframe[^>]*>', re.I), 'iframe_injection', HIGH),
        ('xss', re.compile(r'document\.cookie', re.I), 'document_cookie_access', MEDIUM),
        ('xss', re.compile(r'alert\s*\(', re.I), 'alert_call', LOW),
        ('xss', re.compile(r'eval\s*\(\s*["\'].*?</script>', re.I | re.S), 'eval_xss', HIGH),
    ]

    # CSRF detection patterns (w3af audit_csrf plugin)
    CSRF_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('csrf', re.compile(r"<form[^>]*method\s*=\s*(?:\"[Gg][Ee][Tt]\"|[Gg][Ee][Tt])", re.I), 'form_get_method', MEDIUM),
        ('csrf', re.compile(r'(?<![^a-zA-Z])token[^\w]?(?:id|name)\s*[=:]\s*["\']?\s*["\']', re.I), 'empty_token_field', HIGH),
        ('csrf', re.compile(r'SameSite\s*=\s*(?:"")', re.I), 'empty_samesite_cookie', MEDIUM),
    ]

    # LDAP Injection patterns (w3af audit_ldap_injection)
    LDAP_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('ldap', re.compile(r'[\\]{2}', re.I), 'ldap_escape_bypass', HIGH),
        ('ldap', re.compile(r'\*\)', re.I), 'ldap_wildcard_filter', HIGH),
        ('ldap', re.compile(r'\(\|=.*\)', re.I), 'ldap_or_injection', HIGH),
    ]

    # XPath Injection patterns (w3af audit_xpath_injection)
    XPATH_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('xpath', re.compile(r'xpath\s*\(\s*[\'"].*?\.\'', re.I), 'xpath_concat', HIGH),
        # XPath dynamic filter patterns: /] or /[expression]=  (bracket expressions)
        ('xpath', re.compile(r'(/\]|/\[[^\]]*=[\w\-]+)', re.I), 'xpath_dynamic_filter', HIGH),
    ]

    # SSRF patterns (w3af audit_ssrf)
    SSRF_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('ssrf', re.compile(r'127\.0\.0\.\d+|localhost|::1', re.I), 'loopback_url', HIGH),
        ('ssrf', re.compile(r'169\.254\.169\.254', re.I), 'aws_metadata_ip', CRITICAL),
        ('ssrf', re.compile(r'metadata\.google\.internal', re.I), 'gcp_metadata', CRITICAL),
        ('ssrf', re.compile(r'dict://|ftp://|file://|gopher://', re.I), 'dangerous_protocol', HIGH),
        ('ssrf', re.compile(r'&url=(https?://)', re.I), 'redirect_param_ssrf', HIGH),
    ]

    # LFI/RFI patterns (w3af audit_lfi + audit_rfi)
    LFI_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('lfi', re.compile(r'\.\./[^\s]*etc/passwd', re.I), 'lfi_etc_passwd', HIGH),
        ('lfi', re.compile(r'/proc/self/environ', re.I), 'lfi_proc_environ', HIGH),
        ('lfi', re.compile(r'php://filter/convert', re.I), 'lfi_php_filter', HIGH),
        ('lfi', re.compile(r'win\.ini|boot\.ini', re.I), 'lfi_windows_ini', MEDIUM),
    ]

    RFI_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('rfi', re.compile(r'(?:allow_url_include\s*=\s*on|file_get_contents|include|require)\s*\(\s*(?:\$_|http://)', re.I), 'rfi_http_include', CRITICAL),
        ('rfi', re.compile(r'\\.(?:php|asp|aspx|jsp|cgi)\\?.*cmd=.*', re.I), 'rfi_remote_shell', CRITICAL),
    ]

    # SSRF URL patterns (w3af ssrfdetector)
    SRI_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('ssri', re.compile(r'https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0)/', re.I), 'local_host_redirect', HIGH),
        ('ssri', re.compile(r'<img[^>]+src\s*=\s*[\'"](https?://)', re.I), 'image_src_external_url', LOW),
    ]

    # PHP Info patterns (w3af phpinfo crawl plugin)
    PHPINFO_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('phpinfo', re.compile(r'<table[^>]*id\s*=\s*["\'](request|post|get|files|env)', re.I), 'phpinfo_table', INFO),
        ('phpinfo', re.compile(r'PHP Version [0-9]+\.[0-9]+', re.I), 'php_version_exposed', INFO),
    ]

    # FrontPage extension patterns (w3af audit_frontpage)
    FRONTPAGE_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('frontpage', re.compile(r'_vti_pvt|_vti_bin|_vti_inf', re.I), 'frontpage_hidden_dirs', INFO),
        ('frontpage', re.compile(r'fpcount\.php|owssvr\.dll', re.I), 'frontpage_cgi', INFO),
    ]

    # Server-side Include patterns (w3af audit_ssi)
    SSI_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('ssi', re.compile(r'<!--#include', re.I), 'ssi_include_directive', LOW),
        ('ssi', re.compile(r'#exec\s+', re.I), 'ssi_exec_directive', MEDIUM),
    ]

    # ShellShock (CVE-2014-6271) patterns (w3af shell_shock)
    SHELLSHOCK_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('shellshock', re.compile(r'\(\)\s*{\s*:\s*\);\s*/[a-z]', re.I), 'shellshock_ua_pattern', CRITICAL),
    ]

    # Format string vulnerability patterns (w3af audit_format_string)
    FORMAT_STRING_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('format_string', re.compile(r'printf\s*\(\s*%[^n].*?\)', re.I), 'printf_unsafe_format', HIGH),
        ('format_string', re.compile(r'sprintf\s*\(\s*.*?\%', re.I), 'sprintf_unsafe_format', HIGH),
    ]

    # ReDoS patterns (w3af audit_redos)
    REDOS_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('redos', re.compile(r'\([^\)]+\)\{[1-9]\d*,?\s*\}', re.I), 'nested_quantifier_reDOS', HIGH),
        ('redos', re.compile(r'(\w)\1+', re.I), 'greedy_repeat_redos', MEDIUM),
    ]

    # MX Injection patterns (w3af audit_mx_injection)
    MX_INJECTION_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('mx_injection', re.compile(r'[Cc][Cc]\s*[:=].*[\r\n]', re.I), 'cc_header_injection', HIGH),
        ('mx_injection', re.compile(r'[Bb][Cc]\s*[:=].*[\r\n]', re.I), 'bcc_header_injection', HIGH),
    ]

    # Insecure SSL patterns (w3af audit_ssl)
    SSL_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('ssl', re.compile(r'insecure\s*content\s+over\s+insecure\s+channel', re.I), 'insecure_content_channel', MEDIUM),
        ('ssl', re.compile(r'Weak DH key|weak.*diffie[- ]?hellman', re.I), 'weak_dh_key', HIGH),
    ]

    # Open Redirect patterns (w3af audit_open_redirect)
    OPEN_REDIRECT_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('open_redirect', re.compile(r'(?:redirect|goto|return|r)[\s:=]+["\']?\s*https?://[^/]', re.I), 'url_redirect_param', HIGH),
        ('open_redirect', re.compile(r'window\.location\s*=\s*(?:\$|param)', re.I), 'js_redirect_injection', HIGH),
    ]

    # Phishing Vector patterns (w3af audit_phishing_vector)
    PHISHING_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('phishing', re.compile(r'action\s*=\s*["\']https?://(?!localhost)[^/]{5,}/[^/]{4,}\.(?:php|asp|jsp|html)', re.I | re.S), 'external_form_action', CRITICAL),
        ('phishing', re.compile(r'href\s*=\s*["\']https?://(?!localhost|example\.com)[^/]{5,}', re.I | re.S), 'external_link_from_page', HIGH),
    ]

    # Eval/Input Injection (w3af audit_eval)
    EVAL_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('eval_injection', re.compile(r'(?<![a-zA-Z_])eval\s*\(\s*(?:\$_|param|input|query)', re.I), 'eval_with_user_input', CRITICAL),
        ('eval_injection', re.compile(r'assert\s*\(\s*(?:\$_|request\.form)', re.I), 'assert_with_user_input', HIGH),
        ('eval_injection', re.compile(r'(?:exec|system|passthru|popen)\s*\(\s*(?:\$_|param)', re.I), 'cmd_exec_with_user_input', CRITICAL),
    ]

    # Unsafe preg_replace (w3af audit_preg_replace)
    PREG_REPLACE_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('preg_replace', re.compile(r'preg_replace\s*\(\s*[^\n]*e[^"]*["\'].*?\)', re.I), 'preg_replace_e_flag', HIGH),
        ('preg_replace', re.compile(r'preg_replace\s*\(\s*(?:\$|param|request)', re.I), 'preg_replace_dynamic_pattern', HIGH),
    ]

    # Insecure DAV / WebDAV patterns (w3af infrastructure_dav)
    DAV_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('dav', re.compile(r'(?:DAV:\s*dav|WebDAV)', re.I), 'webdav_enabled', INFO),
        ('dav', re.compile(r'Allow\s*:\s*\*(.*?)WRITE', re.I), 'dav_write_enabled', MEDIUM),
    ]

    # Response splitting (w3af audit_resp_splitting)
    RESPONSE_SPLITTING_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('resp_splitting', re.compile(r'[\r\n][^\n]*?(?:Set-Cookie|Location)\s*[:=]', re.I), 'crlf_header_injection', HIGH),
    ]

    # Phishing Vector: credential capture form action (w3af phishing_vector)
    CREDENTIAL_CAPTURE_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('credential_capture', re.compile(r'<form[^>]*action\s*=\s*["\']https?://(?!localhost)[^/]{5,}/[^\n]*login[^"\']{0,40}["\']', re.I | re.S), 'external_login_form', CRITICAL),
    ]

    # Format string (printf/fprintf) patterns for format_string vuln
    INSECURE_DESERIALIZE_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('insecure_deserialize', re.compile(r'(?:unserialize|ObjectInputStream|readObject|pickle\.loads|yaml\.load)\s*\(', re.I), 'dangerous_deserialize_call', HIGH),
    ]

    # Publicly writable directory (w3af audit_publicly_writable_dir)
    PUBLICLY_WRITABLE_DIR_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('publicly_writable_dir', re.compile(r'(?:207\s*MULTI-STATUS|Allow:\s*\*.*WRITE)', re.I), 'dav_publicly_writable', MEDIUM),
    ]

    # Insecure Redirect (w3af audit_insecure_redirect)
    INSECURE_REDIRECT_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('insecure_redirect', re.compile(r'redirect\s*[=:]\s*\$\{?[0-9a-f]{4,}\}?', re.I), 'param_based_redirect', MEDIUM),
    ]

    # Reflected File Download (w3af audit_rfd)
    RFD_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('rfd', re.compile(r'(?:download|file)\s*=\s*\$\{?[0-9a-f]{4,}\}?', re.I), 'rfd_filename_echo', MEDIUM),
    ]

    # MX Injection (mail header) - already defined in w3af_pii_grep but here for response matching
    HEADER_INJECTION_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('header_injection', re.compile(r'(?:To|Cc|Bcc)\s*[:=]\s*[^\n]*[@][\r\n]', re.I), 'mail_header_crlf', HIGH),
    ]

    # Buffer overflow indicators (w3af audit_buffer_overflow) - detected via oversized responses
    BUFFER_OVERFLOW_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('buffer_overflow', re.compile(r'Buffer\s*overflow|stack\s*sมmble\s*detected', re.I), 'overflow_detection', CRITICAL),
    ]

    # PHP config exposure (w3af crawl_phpinfo)
    PHP_CONFIG_PATTERNS: List[Tuple[str, Pattern, str]] = [
        ('php_config', re.compile(r'PHP\s*Version\s+[0-9]+\.[0-9]+', re.I), 'php_version_info', INFO),
        ('php_config', re.compile(r'display_errors\s*=\s*On', re.I), 'display_errors_on', MEDIUM),
        ('php_config', re.compile(r'allow_url_fopen\s*=\s*On|allow_url_include\s*=\s*On', re.I), 'php_insecure_config', HIGH),
        ('php_config', re.compile(r'register_globals\s*=\s*On', re.I), 'register_globals_on', CRITICAL),
    ]

    def __init__(self):
        # Compile all pattern groups into a single unified list
        self._patterns: List[Tuple[str, str, Pattern, str]] = []
        for group_name in [
            ('sqli', self.SQLI_PATTERNS),
            ('xss', self.XSS_PATTERNS),
            ('csrf', self.CSRF_PATTERNS),
            ('ldap', self.LDAP_PATTERNS),
            ('xpath', self.XPATH_PATTERNS),
            ('ssrf', self.SSRF_PATTERNS),
            ('lfi', self.LFI_PATTERNS),
            ('rfi', self.RFI_PATTERNS),
            ('ssri', self.SRI_PATTERNS),
            ('phpinfo', self.PHPINFO_PATTERNS),
            ('frontpage', self.FRONTPAGE_PATTERNS),
            ('ssi', self.SSI_PATTERNS),
            ('shellshock', self.SHELLSHOCK_PATTERNS),
            ('format_string', self.FORMAT_STRING_PATTERNS),
            ('redos', self.REDOS_PATTERNS),
            ('mx_injection', self.MX_INJECTION_PATTERNS),
            ('ssl', self.SSL_PATTERNS),
            ('open_redirect', self.OPEN_REDIRECT_PATTERNS),
            ('phishing', self.PHISHING_PATTERNS),
            ('eval_injection', self.EVAL_PATTERNS),
            ('preg_replace', self.PREG_REPLACE_PATTERNS),
            ('dav', self.DAV_PATTERNS),
            ('resp_splitting', self.RESPONSE_SPLITTING_PATTERNS),
            ('credential_capture', self.CREDENTIAL_CAPTURE_PATTERNS),
            ('insecure_deserialize', self.INSECURE_DESERIALIZE_PATTERNS),
            ('publicly_writable_dir', self.PUBLICLY_WRITABLE_DIR_PATTERNS),
            ('insecure_redirect', self.INSECURE_REDIRECT_PATTERNS),
            ('rfd', self.RFD_PATTERNS),
            ('header_injection', self.HEADER_INJECTION_PATTERNS),
            ('buffer_overflow', self.BUFFER_OVERFLOW_PATTERNS),
            ('php_config', self.PHP_CONFIG_PATTERNS),
        ]:
            group, patterns = group_name
            for vuln_type, regex, pattern_name in patterns:
                self._patterns.append((group, pattern_name, regex, vuln_type))

    def scan_response(self, response_text: str, url: str = '') -> List[VulnPatternFinding]:
        """Scan a full HTTP response for all known vulnerability patterns."""
        findings: List[VulnPatternFinding] = []
        seen_patterns: set = set()

        # Limit to first 500KB for performance
        scan_text = response_text[:500_000]

        for group, pattern_name, regex, vuln_type in self._patterns:
            if pattern_name in seen_patterns:
                continue
            try:
                matches = regex.findall(scan_text)
            except re.error:
                continue

            if not matches:
                continue

            severity = self._get_severity_for_pattern(vuln_type, pattern_name)
            dbms_guess = self._guess_dbms(response_text) if vuln_type == 'sqli' else ''
            description = self._get_description(vuln_type, pattern_name)
            remediation = self._get_remediation(vuln_type, pattern_name)

            # w3af vulnerability ID mapping
            w3af_id = self._get_w3af_vuln_id(vuln_type)

            finding = VulnPatternFinding(
                vuln_type=vuln_type,
                pattern_name=pattern_name,
                confidence=self._compute_confidence(vuln_type, pattern_name),
                severity=severity,
                dbms_guess=dbms_guess,
                description=f'w3af: {description}',
                remediation=remediation[:200],
                w3af_vuln_id=w3af_id,
            )
            findings.append(finding)
            seen_patterns.add(pattern_name)

        logger.info('Vulnerability patterns found %d matches in %s', len(findings), url or 'local')
        return findings

    def scan_text(self, text: str, url: str = '') -> List[VulnPatternFinding]:
        """Scan raw text for vulnerability patterns."""
        return self.scan_response(text, url)

    def get_pattern_catalog(self) -> List[Dict[str, str]]:
        """Return the full catalog of vulnerability patterns (for documentation)."""
        catalog = []
        for group, pattern_name, _, vuln_type in self._patterns:
            catalog.append({
                'vuln_type': group,
                'pattern': pattern_name,
                'category': vuln_type,
            })
        return catalog

    def scan_and_classify(self, response_text: str, url: str = '') -> Dict[str, List[VulnPatternFinding]]:
        """Scan and classify findings by vulnerability type."""
        all_findings = self.scan_response(response_text, url)
        classified: Dict[str, List[VulnPatternFinding]] = {}
        for f in all_findings:
            classified.setdefault(f.vuln_type, []).append(f)
        return classified

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_severity_for_pattern(vuln_type: str, pattern_name: str) -> str:
        """Get severity level for a vulnerability type."""
        severities = {
            'critical': {'shellshock', 'rfi', 'eval_injection', 'credential_capture', 'insecure_deserialize'},
            'high': {'sqli', 'xss', 'ldap', 'xpath', 'ssrf', 'lfi', 'php_config', 'format_string', 'redos', 'mx_injection', 'open_redirect', 'resp_splitting', 'header_injection'},
            'medium': {'csrf', 'dav', 'insecure_redirect', 'publicly_writable_dir', 'phpinfo'},
            'low': {'rfd', 'ssi'},
            'info': {'frontpage', 'shellshock', 'phpinfo', 'php_config'},
        }
        for sev, types in severities.items():
            if vuln_type in types:
                return sev.upper()
        return 'INFO'

    def _guess_dbms(self, response_text: str) -> str:
        """Guess the database system from error messages (w3af blind_sqli)."""
        lower_text = response_text.lower()
        indicators = {
            'MySQL': ['mysql', 'mysqli', 'pdo_mysql'],
            'PostgreSQL': ['postgres', 'pg_', 'postgresql'],
            'MSSQL': ['mssql', 'sqlserver', 'sysobjects', 'sp_'],
            'Oracle': ['oracle', 'ora-', 'ora_', 'pl/sql', 'PLS-'],
            'SQLite': ['sqlite', 'sqlite3'],
        }
        for dbms, indicators_list in indicators.items():
            if any(ind in lower_text for ind in indicators_list):
                return dbms
        return ''

    @staticmethod
    def _get_description(vuln_type: str, pattern_name: str) -> str:
        descriptions = {
            'sqli': f'SQL injection pattern detected ({pattern_name})',
            'xss': f'XSS vulnerability pattern ({pattern_name})',
            'csrf': f'CSRF protection missing ({pattern_name})',
            'ssrf': f'SSRF risk detected ({pattern_name})',
            'lfi': f'Local file inclusion pattern ({pattern_name})',
            'rfi': f'Remote file inclusion risk ({pattern_name})',
            'shellshock': f'ShellShock vulnerability indicator ({pattern_name})',
            'ldap': f'LDAP injection pattern ({pattern_name})',
            'xpath': f'XPath injection pattern ({pattern_name})',
            'open_redirect': f'Open redirect potential ({pattern_name})',
        }
        return descriptions.get(vuln_type, f'{vuln_type}: {pattern_name}')

    @staticmethod
    def _get_remediation(vuln_type: str, pattern_name: str) -> str:
        remediations = {
            'sqli': '使用参数化查询 (prepared statements)，避免字符串拼接SQL',
            'xss': '对所有用户输入进行HTML转义输出，配置CSP头',
            'csrf': '添加CSRF token并验证每个状态变更请求',
            'ssrf': '限制URL协议白名单，禁用内部IP访问，使用allowlist',
            'lfi': '对文件路径参数做严格白名单校验，禁止../ traversal',
            'rfi': '禁用allow_url_include，对include路径做白名单校验',
            'shellshock': '升级bash到>=4.3修复CVE-2014-6271',
            'open_redirect': '验证redirect参数为目标域名白名单',
        }
        return remediations.get(vuln_type, '请审查相关代码')

    @staticmethod
    def _compute_confidence(vuln_type: str, pattern_name: str) -> float:
        """Compute confidence score for a vulnerability finding."""
        high_conf = {
            'mysql_sleep', 'postgresql_pg_sleep', 'mssql_waitfor',
            'union_select', 'script_tag', 'img_onerror_xss', 'svg_onload_xss',
            'rfi', 'eval_with_user_input', 'cmd_exec_with_user_input',
        }
        if pattern_name in high_conf:
            return 0.95

        medium_conf = {
            'sql_tautology', 'sql_comment_injection', 'tautology',
            'event_handler_xss', 'phpinfo_table', 'register_globals_on',
        }
        if pattern_name in medium_conf:
            return 0.75

        return 0.5

    @staticmethod
    def _get_w3af_vuln_id(vuln_type: str) -> int:
        """Map to w3af vulnerability ID (from vulns.py)."""
        ids = {
            'sqli': 45, 'xss': 55, 'csrf': 13, 'ssrf': 88,
            'lfi': 17, 'rfi': 42, 'ldap': 30, 'xpath': 54,
            'open_redirect': 50, 'shellshock': 68, 'ssi': None,
            'redos': None, 'format_string': None, 'mx_injection': None,
            'phpinfo': None, 'frontpage': 69, 'dav': 52,
            'insecure_redirect': 50, 'rfd': 71, 'eval_injection': 6,
            'resp_splitting': 41, 'credential_capture': 74,
        }
        return ids.get(vuln_type, 0)


# ====================================================================
# Convenience function
# ====================================================================

def check_for_patterns(response_text: str, url: str = '') -> List[VulnPatternFinding]:
    """Quick vulnerability pattern check (w3af grep-style)."""
    db = VulnPatternDB()
    return db.scan_response(response_text, url)
