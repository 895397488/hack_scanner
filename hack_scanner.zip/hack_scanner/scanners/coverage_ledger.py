#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Coverage Ledger 覆盖率账本
==========================
借鉴 Strix v1.6.2 (usestrix/strix, Apache-2.0) 的:
  - strix/tools/coverage/tools.py  — agent 端记账工具（VALID_OUTCOMES 状态枚举）
  - strix/report/coverage.py       — 汇总生成 coverage.json（provenance + gap 检测）

Findings 回答"发现了什么"，Coverage 回答"检查了什么、每项怎么收尾的"——
这是审计报告需要的**负空间**：读到"零 SQL 注入"时，必须能区分
"测了 14 个端点全是参数化 ✅" 和 "根本没看 ❌"。

两类陈述刻意分开记录（provenance）:
  - ``agent_reported``  — 账本条目：agent 对自己工作的自述，丰富但需要核验
  - ``machine_observed`` — 运行时事实：哪些 agent 跑了、带了哪些技能、
    结果数量、扫描是否正常收尾——矛盾时以机器观测为准

三个 Strix 设计细节（本模块全部保留）:
  1. 每条记录带 provenance，自述与观测分列
  2. gap 检测：带了某技能却没产出对应记录 → 自动进 ``gaps`` 列表
  3. 超预算/中断的扫描强制 ``complete: false`` + caveats

hack_scanner 适配:
  - 单进程 ReAct 编排（swarm_orchestrator）+ 技能路由（skill_loader），
    没有 Strix 的 coordinator 图，agent 信息以"名称+状态"传入
  - 技能义务表 SKILL_OBLIGATIONS 按本项目 skills/ 下 8 份 SKILL.md 的范围
    逐技能定义（流程类技能 fix-vulnerabilities / pentest-workflow 不设义务，
    同 Strix 对 tooling/reconnaissance 类技能的豁免原则）
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

COVERAGE_FILENAME = "coverage.json"
COVERAGE_SCHEMA_VERSION = 1

#: 状态枚举 — 与 Strix VALID_OUTCOMES 一致
VALID_OUTCOMES: tuple = (
    "reported",          # 确认漏洞并已报告
    "no_issue_found",    # 正经测过，无问题
    "ruled_out",         # 有具体候选，已证伪（必须给控制点证据）
    "not_applicable",    # 该风险在此不适用（必须说明原因）
    "needs_follow_up",   # 存疑未决 — 合法结局，禁止用 no_issue_found 掩盖
)

#: 必须附 evidence 的结局 — "看起来没问题"不算 ruled_out
_OUTCOMES_REQUIRING_EVIDENCE = frozenset({"ruled_out", "not_applicable", "needs_follow_up"})

#: 面向读者的双语标签
OUTCOME_LABELS: Dict[str, str] = {
    "reported": "已报告漏洞 (Finding reported)",
    "no_issue_found": "已测试无问题 (No issue found)",
    "ruled_out": "已排除 (Ruled out)",
    "not_applicable": "不适用 (Not applicable)",
    "needs_follow_up": "待跟进 (Needs follow-up)",
}

#: 这些 run 状态意味着扫描没有跑完
_INCOMPLETE_RUN_STATUSES = frozenset({"failed", "interrupted", "stopped", "running", "timeout"})
#: 这些 agent 状态意味着该 agent 提前停了
_INCOMPLETE_AGENT_STATUSES = frozenset({"crashed", "stopped", "running", "waiting", "failed", "interrupted"})
#: 这些 exit_reason 表示"root 自己决定结束"，不视为中断
_CLEAN_EXIT_REASONS = frozenset({"finished_by_tool", "completed", "complete", ""})

_ENTRY_ID_ATTEMPTS = 1024
_EVIDENCE_PREVIEW_CHARS = 240
_DEFAULT_AGENT = "orchestrator"


# ---------------------------------------------------------------------------
# 技能义务表 — gap 检测依据
# ---------------------------------------------------------------------------
#
# 每个技能 -> 义务列表；每条义务 = {"risk_area": 标签, "phrasings": 同义词组列表}。
# 匹配规则：把 entry 的 surface+risk_area 归一化（小写、标点折成空格）后，
# 某同义词组的**所有词**都作为子串出现 → 该义务视为已覆盖。
# 义务覆盖不到 → 进 gaps："带了技能却没记录对应类别 = 未检查，不是干净"。
#
# 显式 [] = 流程类技能，不设风险类别义务（Strix 对 tooling/recon 类的豁免）。
# 不在表中的技能 → 回退用自己的名字做严格匹配（新技能只会被严格对待，不会崩溃）。

SKILL_OBLIGATIONS: Dict[str, List[Dict[str, Any]]] = {
    "owasp-top-10-testing": [
        {"risk_area": "访问控制失效 / 越权 (A01)",
         "phrasings": [["access control"], ["authorization"], ["idor"], ["bola"],
                        ["越权"], ["授权"], ["privilege"]]},
        {"risk_area": "注入 (A05)",
         "phrasings": [["injection"], ["sqli"], ["sql injection"], ["xss"], ["注入"]]},
        {"risk_area": "认证失效 (A07)",
         "phrasings": [["authentication"], ["认证"], ["jwt"], ["session"],
                        ["password"], ["凭据"], ["mfa"]]},
        {"risk_area": "安全配置错误 (A02)",
         "phrasings": [["misconfig"], ["安全配置"], ["cors"], ["debug"], ["默认凭据"]]},
        {"risk_area": "敏感信息泄露",
         "phrasings": [["disclosure"], ["leak"], ["泄露"], ["sensitive"]]},
    ],
    "web-app-pentest": [
        {"risk_area": "越权 / IDOR",
         "phrasings": [["idor"], ["越权"], ["授权"], ["bola"], ["access control"], ["authorization"]]},
        {"risk_area": "注入 / XSS",
         "phrasings": [["injection"], ["sqli"], ["xss"], ["注入"]]},
        {"risk_area": "认证 / 会话",
         "phrasings": [["authentication"], ["认证"], ["session"], ["jwt"], ["登录"], ["凭据"]]},
        {"risk_area": "业务逻辑 / 竞态",
         "phrasings": [["business logic"], ["业务逻辑"], ["race condition"], ["并发"], ["race"]]},
    ],
    "api-security-testing": [
        {"risk_area": "BOLA / IDOR (API1)",
         "phrasings": [["bola"], ["idor"], ["越权"], ["object level"], ["授权"]]},
        {"risk_area": "认证失效 (API2)",
         "phrasings": [["authentication"], ["认证"], ["token"], ["oauth"], ["jwt"], ["凭据"]]},
        {"risk_area": "批量赋值 / 过度暴露 (API3)",
         "phrasings": [["mass assignment"], ["过度暴露"], ["over exposure"], ["mass-assignment"]]},
        {"risk_area": "资源消耗限制 (API4)",
         "phrasings": [["rate limit"], ["rate limiting"], ["限流"], ["resource consumption"]]},
        {"risk_area": "SSRF / 注入",
         "phrasings": [["ssrf"], ["server side request forgery"], ["injection"], ["注入"]]},
    ],
    "application-security-testing": [
        {"risk_area": "资产盘点 / 测试策略",
         "phrasings": [["asset"], ["盘点"], ["inventory"], ["scope"], ["范围"]]},
        {"risk_area": "注入",
         "phrasings": [["injection"], ["sqli"], ["xss"], ["注入"]]},
        {"risk_area": "敏感数据 / 密钥",
         "phrasings": [["secret"], ["密钥"], ["credential"], ["凭据"], ["sensitive data"]]},
        {"risk_area": "认证 / 授权",
         "phrasings": [["authentication"], ["authorization"], ["认证"], ["授权"], ["idor"]]},
    ],
    "ci-security-scanning": [
        {"risk_area": "供应链 / 依赖审计 (SCA)",
         "phrasings": [["supply chain"], ["dependency"], ["依赖"], ["sca"], ["trivy"]]},
        {"risk_area": "流水线密钥泄露",
         "phrasings": [["secret"], ["密钥"], ["gitleaks"], ["trufflehog"]]},
        {"risk_area": "IaC / 配置审计",
         "phrasings": [["iac"], ["terraform"], ["checkov"], ["configuration"]]},
    ],
    "find-vulns-in-code": [
        {"risk_area": "注入 (Sink 分析)",
         "phrasings": [["injection"], ["sqli"], ["xss"], ["ssrf"], ["注入"], ["sink"]]},
        {"risk_area": "越权 / IDOR",
         "phrasings": [["authorization"], ["idor"], ["越权"], ["access control"]]},
        {"risk_area": "不安全反序列化",
         "phrasings": [["deserialization"], ["反序列化"]]},
        {"risk_area": "硬编码密钥",
         "phrasings": [["secret"], ["密钥"], ["credential"], ["凭据"]]},
    ],
    # 流程类技能 — 描述"怎么工作"而非"查什么"，不设覆盖义务
    "fix-vulnerabilities": [],
    "pentest-workflow": [],
}


# ---------------------------------------------------------------------------
# 归一化匹配
# ---------------------------------------------------------------------------

def _normalized(text: str) -> str:
    """小写化并把标点折成空格，用于子串匹配。CJK 是 alnum，原样保留。"""
    return "".join(ch if ch.isalnum() else " " for ch in (text or "").lower())


def _entry_matches(entry: Dict[str, Any], terms: List[str]) -> bool:
    """某同义词组的所有词都出现在 entry 的 surface+risk_area 里 → 命中。"""
    hay = _normalized(f"{entry.get('risk_area', '')} {entry.get('surface', '')}")
    return all(t in hay for t in terms)


# ---------------------------------------------------------------------------
# CoverageLedger — 线程安全的共享账本
# ---------------------------------------------------------------------------

class CoverageLedger:
    """扫描共享的覆盖率账本。

    - ``record``: 记录"某 surface 对某风险类别的评估如何收尾"
    - ``update``: 同一 surface+risk_area 只能有一行 — 结论变化用 update 迁移，
      旧结论进 ``history``（防止报告里出现"过期结论与它的修正版并排"）
    - 可选磁盘持久化（原子写，用于断点续扫）
    """

    def __init__(self, persist_path: Optional[str] = None):
        self._storage: Dict[str, Dict[str, Any]] = {}
        self._lock = threading.RLock()
        self._persist_path = persist_path
        if persist_path and os.path.exists(persist_path):
            self.hydrate(persist_path)

    # ---- 内部 ----

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    def _persist_locked(self) -> None:
        """镜像到磁盘。调用方必须已持有 ``_lock``。

        序列化与 rename 在同一临界区内完成：中间放锁会让持旧序列化的写入者
        赢得 rename，把并发 agent 的条目悄悄回滚（Strix 同款问题）。
        """
        path = self._persist_path
        if not path:
            return
        try:
            payload = json.dumps(self._storage, ensure_ascii=False, default=str)
            d = os.path.dirname(os.path.abspath(path))
            os.makedirs(d, exist_ok=True)
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=d,
                prefix=f".{os.path.basename(path)}.", suffix=".tmp", delete=False,
            ) as tmp:
                tmp.write(payload)
                tmp_path = tmp.name
            os.replace(tmp_path, path)
        except Exception:
            logger.exception("coverage ledger persist to %s failed", path)

    def _generate_id_locked(self) -> Optional[str]:
        """分配未占用的 entry id。调用方必须已持有 ``_lock``。"""
        for _ in range(_ENTRY_ID_ATTEMPTS):
            eid = uuid.uuid4().hex[:6]
            if eid not in self._storage:
                return eid
        return None

    @staticmethod
    def _validate(surface: str, risk_area: str, outcome: str, evidence: str
                  ) -> tuple:
        """返回 (normalized_outcome, errors)。"""
        errors: List[str] = []
        if not (surface or "").strip():
            errors.append("surface 不能为空 — 写明端点/路由/文件/组件")
        if not (risk_area or "").strip():
            errors.append("risk_area 不能为空 — 写明测的是什么风险类别")
        normalized = (outcome or "").strip().lower().replace("-", "_").replace(" ", "_")
        if normalized not in VALID_OUTCOMES:
            errors.append(f"非法 outcome: {outcome!r}，必须是 {list(VALID_OUTCOMES)} 之一")
        elif normalized in _OUTCOMES_REQUIRING_EVIDENCE and not (evidence or "").strip():
            errors.append(
                f"outcome '{normalized}' 必须附 evidence — 写明控制点/不适用原因/"
                "还缺什么，'看起来没问题'不算证据"
            )
        return normalized, errors

    def _duplicate_of_locked(self, surface: str, risk_area: str):
        """找同一 surface+risk_area 的既有行。调用方必须已持有 ``_lock``。

        查重与插入必须是同一临界区：否则两个 agent 并发记录同一 surface
        都看到"无重复"，账本里就留下这行查重本要挡掉的并行记录。
        """
        key = (surface.strip().lower(), risk_area.strip().lower())
        for eid, entry in self._storage.items():
            existing = (
                str(entry.get("surface", "")).strip().lower(),
                str(entry.get("risk_area", "")).strip().lower(),
            )
            if existing == key:
                return eid, dict(entry)
        return None

    # ---- 对外 API（返回统一 {"ok": bool, ...} 结构）----

    def record(self, surface: str, risk_area: str, outcome: str,
               evidence: str = "", agent: str = "") -> Dict[str, Any]:
        """记录一条覆盖：某 surface 对某风险类别的评估如何收尾。

        测完就记（尤其是没发现问题的时候），不要攒到结束批量补。
        同一 surface+risk_area 已有记录（无论谁记的）会被拒绝并返回该条目 id —
        结论变化请用 ``update`` 迁移。
        """
        normalized, errors = self._validate(surface, risk_area, outcome, evidence)
        if errors:
            return {"ok": False, "error": "校验失败", "errors": errors}

        entry: Dict[str, Any] = {
            "surface": surface.strip(),
            "risk_area": risk_area.strip(),
            "outcome": normalized,
            "created_at": self._now(),
            "agent": (agent or _DEFAULT_AGENT).strip(),
        }
        if (evidence or "").strip():
            entry["evidence"] = evidence.strip()

        with self._lock:
            dup = self._duplicate_of_locked(surface, risk_area)
            if dup is not None:
                eid, existing = dup
                owner = existing.get("agent") or "其他 agent"
                return {
                    "ok": False,
                    "error": (
                        f"'{surface.strip()}' ({risk_area.strip()}) 已有覆盖记录 {eid}"
                        f"（{owner} 记为 '{existing.get('outcome', '')}'）。"
                        "一个 surface 两行会让报告出现过期结论与修正版并排。"
                        f"结论变了就用 update_coverage(entry_id='{eid}', ...) 迁移"
                        "并在 evidence 说明变化；测的其实是另一回事就把 "
                        "surface/risk_area 说得更精确再记。"
                    ),
                    "existing_entry_id": eid,
                    "existing_outcome": existing.get("outcome", ""),
                }

            eid = self._generate_id_locked()
            if eid is None:
                return {"ok": False, "error": "无法分配覆盖条目 id"}
            self._storage[eid] = entry
            self._persist_locked()
        logger.info("Coverage recorded: id=%s outcome=%s surface=%s", eid, normalized, entry["surface"])
        return {"ok": True, "entry_id": eid, "outcome": normalized,
                "message": f"已记录 '{entry['surface']}' 的覆盖 ({normalized})"}

    def update(self, entry_id: str, outcome: str,
               evidence: str = "", agent: str = "") -> Dict[str, Any]:
        """迁移已有记录的结论。

        surface+risk_area 保持不变 — 这是同一次评估换了一个结论：
        - 接手别人的 needs_follow_up 并解决了 → 迁到 reported / ruled_out / no_issue_found
        - 反过来，原先记 no_issue_found 的后来发现可被利用 → 迁回
        旧结论/证据/作者保留在 ``history``。
        """
        key = (entry_id or "").strip()
        with self._lock:
            existing = self._storage.get(key)
            if existing is None:
                return {
                    "ok": False,
                    "error": (f"找不到覆盖条目 {entry_id!r}。"
                              "用 list_coverage 按 surface 过滤找到你要的那条"),
                }
            surface = str(existing.get("surface", ""))
            risk_area = str(existing.get("risk_area", ""))
            normalized, errors = self._validate(surface, risk_area, outcome, evidence)
            if errors:
                return {"ok": False, "error": "校验失败", "errors": errors}

            previous = str(existing.get("outcome", ""))
            superseded: Dict[str, Any] = {
                "outcome": previous,
                "recorded_at": existing.get("created_at", ""),
            }
            if existing.get("evidence"):
                superseded["evidence"] = existing["evidence"]
            if existing.get("agent"):
                superseded["agent"] = existing["agent"]
            history = existing.get("history")
            existing["history"] = (history if isinstance(history, list) else []) + [superseded]

            existing["outcome"] = normalized
            existing["updated_at"] = self._now()
            if (evidence or "").strip():
                existing["evidence"] = evidence.strip()
            if (agent or "").strip():
                existing["agent"] = agent.strip()
            self._persist_locked()
        logger.info("Coverage updated: id=%s %s -> %s surface=%s", key, previous, normalized, surface)
        return {"ok": True, "entry_id": key, "previous_outcome": previous,
                "outcome": normalized,
                "message": f"'{surface}' ({risk_area}) 由 {previous} 迁移到 {normalized}，旧结论已保留"}

    def list(self, outcome: Optional[str] = None,
             surface: Optional[str] = None) -> Dict[str, Any]:
        """列出已记录的覆盖。收尾前用 outcome='needs_follow_up' 过滤看未决项。"""
        norm_outcome = None
        if outcome and outcome.strip():
            norm_outcome = outcome.strip().lower().replace("-", "_").replace(" ", "_")
            if norm_outcome not in VALID_OUTCOMES:
                return {"ok": False,
                        "error": f"非法 outcome: {outcome!r}，必须是 {list(VALID_OUTCOMES)} 之一"}

        entries: List[Dict[str, Any]] = []
        for e in self.entries():
            if norm_outcome and e.get("outcome") != norm_outcome:
                continue
            if surface and surface.strip().lower() not in str(e.get("surface", "")).lower():
                continue
            item = {
                "entry_id": e.get("entry_id"),
                "surface": e.get("surface", ""),
                "risk_area": e.get("risk_area", ""),
                "outcome": e.get("outcome", ""),
                "agent": e.get("agent", ""),
                "created_at": e.get("created_at", ""),
            }
            ev = str(e.get("evidence", ""))
            if ev:
                item["evidence"] = (ev[:_EVIDENCE_PREVIEW_CHARS].rstrip() + "..."
                                   if len(ev) > _EVIDENCE_PREVIEW_CHARS else ev)
            if isinstance(e.get("history"), list) and e["history"]:
                item["previous_outcomes"] = [str(h.get("outcome", "")) for h in e["history"]]
            entries.append(item)

        return {"ok": True, "entries": entries, "filtered_count": len(entries),
                "total_count": len(self._storage), "outcome_counts": self.outcome_counts()}

    def entries(self) -> List[Dict[str, Any]]:
        """全部条目，最旧在前。"""
        with self._lock:
            out = [{**e, "entry_id": eid} for eid, e in self._storage.items()]
        out.sort(key=lambda e: str(e.get("created_at", "")))
        return out

    def outcome_counts(self) -> Dict[str, int]:
        """按规范顺序统计各 outcome 数量。"""
        counts: Dict[str, int] = {}
        for e in self.entries():
            o = str(e.get("outcome", "")).lower()
            counts[o] = counts.get(o, 0) + 1
        return {o: counts[o] for o in VALID_OUTCOMES if o in counts}

    def clear(self) -> None:
        with self._lock:
            self._storage.clear()
            self._persist_locked()

    def hydrate(self, path: str) -> int:
        """从磁盘恢复账本（断点续扫用）。返回恢复的条目数。"""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError):
            logger.exception("coverage ledger at %s unreadable; starting empty", path)
            return 0
        with self._lock:
            self._storage.clear()
            if isinstance(data, dict):
                self._storage.update({
                    eid: entry for eid, entry in data.items()
                    if isinstance(eid, str) and isinstance(entry, dict)
                })
            n = len(self._storage)
        logger.info("coverage ledger hydrated from %s (%d entr(ies))", path, n)
        return n

    def __len__(self) -> int:
        with self._lock:
            return len(self._storage)


# ---------------------------------------------------------------------------
# gap 检测 + completeness
# ---------------------------------------------------------------------------

def _obligations_for(skill: str) -> List[Dict[str, Any]]:
    """技能对应的义务列表。显式 [] = 豁免；未登记技能回退用名字严格匹配。"""
    if skill in SKILL_OBLIGATIONS:
        return SKILL_OBLIGATIONS[skill]
    # 未登记技能：用自己的名字做义务（严格匹配，不崩溃）
    name = skill.rsplit("/", 1)[-1].strip().lower().replace("-", "_")
    words = _normalized(name).split()
    if not words:
        return []
    return [{"risk_area": name.replace("_", " "), "phrasings": [words]}]


def skill_coverage_gaps(entries: List[Dict[str, Any]],
                        skills: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """带了某技能却没有任何对应记录 → gap。

    给 agent 分配技能是运行时独立观测到的"意图声明"。没有任何账本行提到
    该类别时，这个类别就是**未解释**的 — 与"测过、没发现"是两种完全不同的
    报告行。
    """
    gaps: List[Dict[str, Any]] = []
    for skill in sorted({(s or "").strip().lower() for s in (skills or []) if (s or "").strip()}):
        for ob in _obligations_for(skill):
            phrasings = ob.get("phrasings") or []
            if any(_entry_matches(e, terms) for terms in phrasings for e in entries):
                continue
            gaps.append({
                "kind": "unrecorded_risk_class",
                "skill": skill,
                "risk_area": ob["risk_area"],
                "detail": (
                    f"本次扫描带 '{skill}' 技能，但没有任何覆盖记录涉及 "
                    f"'{ob['risk_area']}'。按'未检查'对待，不是'干净'。"
                ),
            })
    return gaps


def agent_coverage_gaps(entries: List[Dict[str, Any]],
                        agents: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """跑了但一条覆盖都没记的 agent。

    root agent 在有子 agent 时豁免：它负责编排与汇总而非亲手测试 — 否则每次
    干净的扫描都有一条恒定的假 gap，会让读者学会跳过这一节。单独跑时的
    root 就是唯一测试者，照判。
    """
    if not agents:
        return []
    recorded = {str(e.get("agent", "")).lower() for e in entries if e.get("agent")}
    delegated = len(agents) > 1
    gaps: List[Dict[str, Any]] = []
    for a in agents:
        name = str(a.get("name", "")).strip()
        if not name:
            continue
        if name.lower() in recorded or (a.get("is_root") and delegated):
            continue
        gaps.append({
            "kind": "agent_recorded_no_coverage",
            "agent_name": name,
            "detail": (
                f"{name}（状态: {a.get('status', 'unknown')}）跑完了但没记任何覆盖。"
                "它检查过的内容不在这份记录里。"
            ),
        })
    return gaps


def unresolved_gaps(entries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """agent 自己留下的未决项（needs_follow_up）。"""
    return [
        {
            "kind": "needs_follow_up",
            "surface": e.get("surface", ""),
            "risk_area": e.get("risk_area", ""),
            "detail": str(e.get("evidence") or "留下未决，未说明原因。"),
        }
        for e in entries
        if e.get("outcome") == "needs_follow_up"
    ]


def _completeness(run_status: str,
                  agents: Optional[List[Dict[str, Any]]],
                  exit_reason: Optional[str]) -> Dict[str, Any]:
    """这条记录能否被读作完整账。任何一条都让它变 partial，caveats 写明原因。"""
    status = str(run_status or "unknown").strip().lower()
    caveats: List[str] = []

    if status in _INCOMPLETE_RUN_STATUSES or status != "completed":
        if status in _INCOMPLETE_RUN_STATUSES or status in ("", "unknown"):
            caveats.append(
                f"扫描以状态 '{status or 'unknown'}' 结束而非正常完成，"
                "覆盖只反映停止前完成的工作。"
            )
    unfinished = [a for a in (agents or []) if str(a.get("status", "")).lower() in _INCOMPLETE_AGENT_STATUSES]
    if unfinished:
        names = ", ".join(sorted(str(a.get("name", "?")) for a in unfinished))
        caveats.append(f"{len(unfinished)} 个 agent 未正常结束（{names}），其负责面覆盖不足。")
    if exit_reason and exit_reason.strip().lower() not in _CLEAN_EXIT_REASONS:
        caveats.append(
            f"运行以 '{exit_reason}' 终止而非编排器自行结束（常见于预算上限），"
            "剩余范围未到达。"
        )

    return {
        "complete": not caveats,
        "scan_status": status or "unknown",
        "exit_reason": exit_reason,
        "caveats": caveats,
    }


# ---------------------------------------------------------------------------
# coverage.json 文档组装
# ---------------------------------------------------------------------------

def build_coverage_document(
    *,
    run_id: str = "",
    scope: Optional[Dict[str, Any]] = None,
    entries: Optional[List[Dict[str, Any]]] = None,
    agents: Optional[List[Dict[str, Any]]] = None,
    skills: Optional[List[str]] = None,
    findings_count: int = 0,
    run_status: str = "completed",
    exit_reason: Optional[str] = None,
) -> Dict[str, Any]:
    """组装 coverage.json 文档。

    Args:
        run_id:         扫描/任务 id
        scope:          {"targets": [...], "mode": ..., "instruction": ...} 自由结构
        entries:        ledger.entries() 的条目列表
        agents:         [{"name","status","is_root"?}] 运行时观测的 agent 列表
        skills:         本次扫描实际使用的技能名列表（机器观测）
        findings_count: 报告出的发现数（机器观测）
        run_status:     completed / failed / interrupted / stopped / running
        exit_reason:    终止原因（finished_by_tool / budget_exceeded / ...）
    """
    entries = entries or []
    skills = sorted({(s or "").strip().lower() for s in (skills or []) if (s or "").strip()})

    ledger = [
        {
            "surface": e.get("surface", ""),
            "risk_area": e.get("risk_area", ""),
            "outcome": e.get("outcome", ""),
            "outcome_label": OUTCOME_LABELS.get(str(e.get("outcome", "")), ""),
            "evidence": e.get("evidence", ""),
            "recorded_by": e.get("agent", ""),
            "recorded_at": e.get("created_at", ""),
            "updated_at": e.get("updated_at", ""),
            "previous_outcomes": [
                str(p.get("outcome", "")) for p in e.get("history", []) if isinstance(p, dict)
            ],
            "source": "agent_reported",
        }
        for e in entries
    ]

    gaps = [
        *unresolved_gaps(entries),
        *skill_coverage_gaps(entries, skills),
        *agent_coverage_gaps(entries, agents),
    ]

    counts: Dict[str, int] = {}
    for e in entries:
        o = str(e.get("outcome", ""))
        counts[o] = counts.get(o, 0) + 1
    outcome_counts = {label: counts[label] for label in OUTCOME_LABELS if label in counts}

    return {
        "schema_version": COVERAGE_SCHEMA_VERSION,
        "generated_at": CoverageLedger._now(),
        "run_id": run_id,
        "scope": scope or {},
        "summary": {
            "surfaces_reviewed": len(ledger),
            "outcomes": outcome_counts,
            "findings_filed": findings_count,
            "gaps": len(gaps),
        },
        "machine_observed": {
            "agents": agents or [],
            "skills_used": skills,
            "findings_filed": findings_count,
            "source": "runtime",
        },
        "completeness": _completeness(run_status, agents, exit_reason),
        "entries": ledger,
        "gaps": gaps,
    }


def write_coverage(output_dir: str, document: Dict[str, Any]) -> str:
    """原子写 coverage.json 到 output_dir，返回路径。"""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, COVERAGE_FILENAME)
    payload = json.dumps(document, ensure_ascii=False, indent=2, default=str)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8",
        dir=os.path.abspath(output_dir),
        prefix=f".{COVERAGE_FILENAME}.", suffix=".tmp", delete=False,
    ) as tmp:
        tmp.write(payload)
        tmp_path = tmp.name
    os.replace(tmp_path, path)
    logger.info("Saved coverage record to %s (%d surface(s), %d gap(s))",
                path, len(document.get("entries", [])), len(document.get("gaps", [])))
    return path


# ---------------------------------------------------------------------------
# Markdown "检查覆盖" 章节
# ---------------------------------------------------------------------------

def render_coverage_section(document: Dict[str, Any]) -> str:
    """把 coverage 文档渲染成报告里的"检查覆盖"章节（中文）。"""
    comp = document.get("completeness", {})
    summary = document.get("summary", {})
    entries = document.get("entries", [])
    gaps = document.get("gaps", [])
    outcomes = summary.get("outcomes", {})

    lines: List[str] = []
    lines.append("## 检查覆盖 (Coverage)")
    lines.append("")
    lines.append("> 本节记录**检查了什么、每项怎么收尾的**。"
                 "“零发现”只有与下面的检查范围并列时才可信 —"
                 "“测了 N 个面都干净” 和 “没测” 是两种完全不同的结论。")
    lines.append("")

    if comp.get("complete"):
        lines.append("**完成状态**：✅ 完整 — 扫描正常收尾，无未决 agent")
    else:
        lines.append("**完成状态**：⚠️ **不完整** — 以下保留意见适用：")
        for c in comp.get("caveats", []) or ["（未注明原因）"]:
            lines.append(f"> - {c}")
    lines.append("")

    lines.append("| 指标 | 值 |")
    lines.append("|---|---|")
    lines.append(f"| 检查面 (surfaces) | {summary.get('surfaces_reviewed', 0)} |")
    for key, label in [("reported", "已报告漏洞"), ("no_issue_found", "已测试无问题"),
                       ("ruled_out", "已排除"), ("not_applicable", "不适用"),
                       ("needs_follow_up", "待跟进")]:
        lines.append(f"| {label} | {outcomes.get(key, 0)} |")
    lines.append(f"| 报告发现数 (findings filed) | {summary.get('findings_filed', 0)} |")
    lines.append(f"| 未覆盖缺口 (gaps) | {summary.get('gaps', 0)} |")
    lines.append("")

    if entries:
        lines.append("### 检查记录")
        lines.append("")
        lines.append("| 检查面 | 风险类别 | 结论 | 证据 | 记录人 |")
        lines.append("|---|---|---|---|---|")
        for e in entries:
            ev = str(e.get("evidence", "") or "—").replace("|", "\\|").replace("\n", " ")
            if len(ev) > 120:
                ev = ev[:120] + "…"
            lines.append(
                f"| {e.get('surface', '')} | {e.get('risk_area', '')} "
                f"| {e.get('outcome_label') or e.get('outcome', '')} | {ev} "
                f"| {e.get('recorded_by', '')} |"
            )
        lines.append("")

    if gaps:
        lines.append("### 缺口 (Gaps)")
        lines.append("")
        kind_labels = {
            "needs_follow_up": "待跟进",
            "unrecorded_risk_class": "技能覆盖缺口",
            "agent_recorded_no_coverage": "静默 agent",
        }
        for g in gaps:
            tag = kind_labels.get(g.get("kind", ""), g.get("kind", "?"))
            target = g.get("risk_area") or g.get("surface") or g.get("agent_name") or ""
            lines.append(f"- ⚠️ **[{tag}]** {target} — {g.get('detail', '')}")
        lines.append("")
    else:
        lines.append("### 缺口 (Gaps)")
        lines.append("")
        lines.append("- ✅ 无 — 所有技能义务均有对应覆盖记录，无静默 agent，无未决项。")
        lines.append("")

    lines.append("> 自述条目（source: agent_reported）与运行时观测（source: runtime）"
                 "已分列；两者矛盾时以运行时观测为准。")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 模块级默认账本 + 便捷函数（MCP 工具 / 脚本入口用）
# ---------------------------------------------------------------------------

#: 默认状态文件 — 断点续扫时 hydrate
DEFAULT_STATE_PATH = os.path.join("hack_report", ".coverage_ledger.json")

_default_ledger: Optional[CoverageLedger] = None
_default_lock = threading.Lock()


def get_default_ledger(state_path: str = DEFAULT_STATE_PATH) -> CoverageLedger:
    """进程内共享的默认账本（首次调用时从状态文件恢复）。"""
    global _default_ledger
    with _default_lock:
        if _default_ledger is None:
            _default_ledger = CoverageLedger(persist_path=state_path)
        return _default_ledger


def reset_default_ledger() -> None:
    """清空默认账本（新扫描开始时调用）。状态文件一并清空。"""
    global _default_ledger
    with _default_lock:
        if _default_ledger is not None:
            _default_ledger.clear()
        _default_ledger = None


def record_coverage(surface: str, risk_area: str, outcome: str,
                    evidence: str = "", agent: str = "") -> Dict[str, Any]:
    """记账便捷入口（默认账本）。"""
    return get_default_ledger().record(surface, risk_area, outcome, evidence, agent)


def update_coverage(entry_id: str, outcome: str,
                    evidence: str = "", agent: str = "") -> Dict[str, Any]:
    """迁移便捷入口（默认账本）。"""
    return get_default_ledger().update(entry_id, outcome, evidence, agent)


def list_coverage(outcome: Optional[str] = None,
                  surface: Optional[str] = None) -> Dict[str, Any]:
    """查询便捷入口（默认账本）。"""
    return get_default_ledger().list(outcome, surface)


def close_ledger() -> None:
    """释放默认账本引用（测试用）。"""
    global _default_ledger
    with _default_lock:
        _default_ledger = None
