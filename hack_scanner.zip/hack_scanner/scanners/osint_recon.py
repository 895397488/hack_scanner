#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OSINT Recon — 开源情报侦察模块。

集成 Shodan API、WHOIS 查询、基础 OSINT。

Usage:
    from scanners.osint_recon import osint_recon
    result = osint_recon("example.com", shodan_key="your_api_key")
"""

import json
import logging
import socket
import subprocess
import sys
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger('osint_recon')


def _whois_cli(domain: str) -> dict:
    """WHOIS 查询 — CLI fallback"""
    try:
        # Whois Python library
        import whois
        try:
            w = whois.whois(domain)
            return {
                "ok": True,
                "registrar": getattr(w, 'registrar', '') or '',
                "creation_date": str(getattr(w, 'creation_date', '')) if getattr(w, 'creation_date') else '',
                "expiration_date": str(getattr(w, 'expiration_date', '')) if getattr(w, 'expiration_date') else '',
                "updated_date": str(getattr(w, 'updated_date', '')) if getattr(w, 'updated_date') else '',
                "name_servers": [str(ns) for ns in (getattr(w, 'name_servers', []) or [])],
                "country": getattr(w, 'country', '') or '',
                "org": getattr(w, 'organization', '') or '',
                "admin_email": getattr(w, 'admin_email', '') or '',
                "tech_email": getattr(w, 'tech_email', '') or '',
                "raw_whois": (getattr(w, 'text', '') or '')[:3000],
            }
        except Exception as e:
            logger.debug(f"whois lib failed: {e}")
    except ImportError:
        pass

    # CLI fallback
    try:
        proc = subprocess.run(
            ["whois", domain], capture_output=True, text=True, timeout=15,
        )
        return {
            "ok": True,
            "raw_whois": (proc.stdout or '')[:3000],
            "error": "whois CLI 输出（需手动解析）",
        }
    except Exception:
        return {"ok": False, "raw_whois": "", "error": "WHOIS 查询失败"}


def _shodan_search(domain: str, shodan_key: str = "") -> dict:
    """Shodan API 侦察"""
    result = {
        "ok": True,
        "domain": domain,
        "ports_open": [],
        "services": [],
        "vulns": [],
        "error": "",
    }

    if not shodan_key:
        return {"ok": False, "error": "需要 Shodan API Key。在 https://account.shodan.io/account 免费注册获取，然后配置 shodan_key", **result}

    try:
        import shodan
        api = shodan.Shodan(shodan_key)

        # DNS 解析获得 IP
        ips = []
        try:
            ips = socket.getaddrinfo(domain, None, socket.AF_INET)
            ips = list(set([ip[4][0] for ip in ips]))
        except Exception:
            pass

        if not ips:
            return {**result, "error": f"无法解析域名: {domain}"}

        # 对每个 IP 查询 Shodan
        all_ports = []
        all_services = []
        all_vulns = []
        for ip in ips[:5]:  # 最多查 5 个 IP
            try:
                data = api.host(ip)
                for s in data.get('ports', []):
                    svc = data.get('ports_info', {}).get(s, {})
                    all_ports.append({
                        "port": s,
                        "protocol": "tcp",
                        "ip": ip,
                        "service": svc.get('product', '') or svc.get('name', ''),
                        "version": svc.get('version', ''),
                    })
                for v in data.get('vulns', []):
                    all_vulns.append({"cve": v, "ip": ip})

                # 获取 banner
                for s in data.get('data', []):
                    all_services.append({
                        "ip": ip,
                        "port": s.get('port'),
                        "banner": (s.get('data', '') or '')[:500],
                        "product": s.get('product', ''),
                        "hostname": s.get('hostnames', []),
                    })

                result["asn"] = data.get('asn', '')
                result["org"] = data.get('org', '')
                result["country"] = data.get('country_name', '')
                result["last_update"] = data.get('last_update', '')
                result["domains"] = data.get('domains', [])

            except shodan.SpotifyError as e:
                logger.debug(f"Shodan host error for {ip}: {e}")
            except Exception as e:
                logger.warning(f"Shodan host error: {e}")

        result["ports_open"] = all_ports[:100]
        result["services"] = all_services[:50]
        result["vulns"] = all_vulns[:20]

    except Exception as e:
        return {"ok": False, "error": f"Shodan 查询失败: {e}", **result}

    return result


def _basic_recon(domain: str) -> dict:
    """基础 OSINT：IP、端口范围、ASN、反向 DNS"""
    parsed = urlparse(domain)
    host = parsed.hostname or domain

    recon = {"domain": host, "ip": "", "ips": [], "reverse_dns": []}

    try:
        addrs = socket.getaddrinfo(host, None)
        recon["ips"] = list(set([a[4][0] for a in addrs]))
        if recon["ips"]:
            recon["ip"] = recon["ips"][0]
        # Reverse DNS
        for ip in recon["ips"][:5]:
            try:
                rdns = socket.getnameinfo((ip, 0), socket.NI_DGRAM)[0]
                recon["reverse_dns"].append(rdns)
            except Exception:
                pass
    except Exception as e:
        recon["error_resolve"] = str(e)

    return recon


def osint_recon(
    domain: str,
    shodan_key: str = "",
    include_ports: bool = True,
) -> dict:
    """综合 OSINT 侦察。

    Args:
        domain: 目标域名，如 example.com
        shodan_key: Shodan API Key（可选，不传则只做 WHOIS + 基础 recon）
        include_ports: 是否查询开放端口

    Returns:
        {
            "ok": True,
            "domain": "...",
            "ip": "...",
            "whois": {...},
            "shodan": {...},
            "basic_recon": {...},
            "error": ""
        }
    """
    if not domain.startswith(('http://', 'https://')):
        parsed = urlparse(domain)
        domain = parsed.hostname or domain

    recon = {"ok": False, "domain": domain}

    # 基础 recon
    recon["basic_recon"] = _basic_recon(domain)

    # WHOIS
    try:
        recon["whois"] = _whois_cli(domain)
    except Exception as e:
        recon["whois_error"] = str(e)

    # Shodan
    if include_ports:
        try:
            recon["shodan"] = _shodan_search(domain, shodan_key)
        except Exception as e:
            recon["shodan_error"] = str(e)

    recon["ok"] = True
    return recon
