#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Domain Utility — 基于 Acunetix public_suffix_list.dat 的精确域名解析

提供公共后缀列表支持，用于：
- 精确识别注册域名（base_domain）而非仅 TLD
- 子域名合法性验证
- 域名相似度扩展计算
- 钓鱼域名检测增强

借鉴 Acunetix data/tld/public_suffix_list.dat (13626+ 条记录)

Usage:
    from scanners.domain_util import PublicSuffixList, parse_domain
    psl = PublicSuffixList()
    base = psl.get_ Registrable Domain('www.sub.example.co.uk')  # → 'example.co.uk'
"""

import os
import re
from typing import List, Optional, Tuple


class PublicSuffixList:
    """从 public_suffix_list.dat 加载的公共后缀列表解析器"""

    def __init__(self, psl_path: str = None):
        self._public_suffixes: set = set()
        self._wildcard_rules: list = []  # *.example.com → example.com
        self._exceptions: set = set()
        self._loaded = False

        if psl_path is None:
            # 默认使用 hack_scanner/data/tld/public_suffix_list.dat
            psl_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                'data', 'tld', 'public_suffix_list.dat'
            )

        self._load(psl_path)

    def _load(self, path: str):
        """加载公共后缀列表"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
        except (FileNotFoundError, IOError) as e:
            # 如果文件不存在，尝试使用 tldextract 作为回退
            self._loaded = False
            return

        in_icann = False
        for line in content.splitlines():
            line = line.strip()

            # 跳过空行和注释
            if not line or line.startswith('//'):
                # 标记 ICANN 区域（优先级高于私有时）
                if '===BEGIN ICANN DOMAINS===' in line:
                    in_icann = True
                    continue
                elif '===END ICANN DOMAINS===' in line:
                    in_icann = False
                    continue
                elif '===BEGIN PRIVATE DOMAINS===' in line:
                    in_icann = False
                    continue
                elif '===END PRIVATE DOMAINS===' in line:
                    break
                continue

            # 跳过范围规则（如 *.xn--...）
            if line.startswith('<'):
                continue

            # 异常规则（!preceded by exception）
            if line.startswith('!'):
                self._exceptions.add(line[1:])
                continue

            # 通配符规则（*.example.com → example.com 也是注册域名）
            if line.startswith('*.'):
                rule = line[2:]  # strip *.
                self._wildcard_rules.append(rule)
                # 通配符的基域名本身也是公共后缀（即 sch.uk 本身是可注册的）
                self._public_suffixes.add(rule)
                continue

            # 普通规则
            rule = line.lower()
            # 跳过已存在的通配符父规则
            if f'*.{rule}' in self._public_suffixes:
                continue
            self._public_suffixes.add(rule)

        self._loaded = True

        # ── 受限 TLD 白名单 ──
        # 某些 TLD 有注册限制，不能直接注册 foo.uk
        # 只能注册二级域名如 sch.uk, co.uk, ac.uk 等
        self._restricted_tlds: set = {
            'uk',   # .uk — second-level registration (ac.uk, co.uk, gov.uk...)
            'au',   # .au — restricted second-level (com.au, net.au, org.au...)
            'jp',   # .jp — restricted (co.jp, or.jp, ac.jp...)
            'nz',   # .nz — restricted (co.nz, govt.nz...)
            'cn',   # .cn — restricted (com.cn, edu.cn...)
            'hk',   # .hk — restricted (net.hk, org.hk...)
        }

    def _is_tld_restricted(self, tld: str) -> bool:
        """判断 TLD 是否有二级注册限制（如 .uk 只能注册 sch.uk 等二级域名）"""
        return tld in self._restricted_tlds

    def get_registrable_domain(self, hostname: str) -> Optional[str]:
        """提取注册域名（不含子域）。

        算法：从后往前找**最长的** PSL 匹配。返回 parts[best_match_start:]
        （即 PSL 匹配部分 + 前一个标签作为 base domain，除非该 TLD 有二级限制）。

        例如:
            'www.sub.example.co.uk' → 'example.co.uk'  (co.uk 是注册域名)
            'mail.google.com'       → 'google.com'     (com 下可自由注册)
            'api.github.com'        → 'github.com'
            'deep.nested.sch.uk'    → 'sch.uk'         (.uk 有二级限制，sch.uk 本身可注册)
        """
        if not self._loaded:
            return None

        hostname = hostname.lower().rstrip('.')
        parts = hostname.split('.')

        if len(parts) < 2:
            return hostname

        # 如果整个 hostname 本身就是 PSL entry（如 co.uk, sch.uk），直接返回
        if hostname in self._public_suffixes:
            return hostname

        # 从后往前扫描，找到最长的 PSL 匹配（最小的 best_match_start）
        best_start = None
        for i in range(len(parts) - 1, 0, -1):
            suffix = '.'.join(parts[i:])
            if suffix in self._public_suffixes:
                if best_start is None or i < best_start:
                    best_start = i

        if best_start is not None:
            matched_labels = len(parts) - best_start

            if matched_labels == 1:
                # 单段后缀（.com, .org, .net...）→ base_domain = parts[best_start-1:]
                # www.google.com → parts[0:] = google.com ✓
                return '.'.join(parts[best_start - 1:])

            # 多段后缀（sch.uk, co.uk, com.au...）
            # 检查：匹配到的 PSL 规则是否本身就是可注册域名？
            # 例如 'sch.uk' 是可注册域名，但 'co.uk' 下还可以注册 'example.co.uk'
            # 区别：对于 .uk 这类受限 TLD，二级域（sch, ac, co 等）本身可注册
            # → sch.uk 作为 base_domain 就是 registrable domain
            tld = parts[-1]
            if self._is_tld_restricted(tld):
                return '.'.join(parts[best_start:])
            else:
                return '.'.join(parts[best_start - 1:])

        # 未找到匹配 → 返回裸 TLD + 顶级（兜底）
        return '.'.join(parts[-2:]) if len(parts) >= 2 else hostname

    def is_subdomain(self, hostname: str, base_domain: str) -> bool:
        """检查 hostname 是否是 base_domain 的子域名"""
        if not self._loaded:
            return False

        hostname = hostname.lower().rstrip('.')
        base_domain = base_domain.lower().rstrip('.')

        if hostname == base_domain:
            return False  # 相同 ≠ 子域名

        # 比较注册域名：hostname 的注册域名必须等于 base_domain
        # 且 hostname 必须有更多的标签（确实是子域）
        host_registrable = self.get_registrable_domain(hostname)
        if not host_registrable:
            return False

        return host_registrable == base_domain and \
               len(hostname.split('.')) > len(base_domain.split('.'))

    def is_public_suffix(self, hostname: str) -> bool:
        """检查是否为公共后缀（非注册域名）"""
        if not self._loaded:
            return False
        return hostname.lower() in self._public_suffixes

    def get_all_public_suffixes(self) -> set:
        """返回所有公共后缀"""
        return set(self._public_suffixes) | set(f'*.{r}' for r in self._wildcard_rules)


def parse_domain(hostname: str) -> Optional[str]:
    """快捷函数：提取注册域名"""
    psl = PublicSuffixList()
    return psl.get_registrable_domain(hostname)


def is_subdomain_of(hostname: str, base_domain: str) -> bool:
    """快捷函数：检查子域名关系"""
    psl = PublicSuffixList()
    return psl.is_subdomain(hostname, base_domain)


# 全局缓存实例
_psl_instance = None

def get_psl() -> PublicSuffixList:
    """获取全局 PSL 实例（单例）"""
    global _psl_instance
    if _psl_instance is None:
        _psl_instance = PublicSuffixList()
    return _psl_instance


# 模块初始化时自动加载 PSL
get_psl()
