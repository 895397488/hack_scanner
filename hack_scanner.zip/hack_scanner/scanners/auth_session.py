#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Auth Session Manager -- authenticated scanning session management modeled after
Acunetix SiteLogin (automatic login detection, form-based auth, OAuth2, SSO).

Core capabilities:
  - Form-based login (auto-detect + manual sequence)
  - Cookie/token persistence across scan requests
  - OAuth2 access-token injection
  - Client certificate (mTLS) authentication
  - Custom per-URL-scope HTTP headers and cookies
  - Login success/failure detection

Usage:
    from scanners.auth_session import AuthSession, LoginSequence

    # Auto-detect login form
    session = AuthSession(target_url="https://example.com")
    forms = session.discover_login_forms()
    seq = forms[0].build_sequence(username="admin", password="secret")
    success = session.authenticate(seq)
    print(f"Authenticated: {session.is_authenticated()}")

    # Manual login sequence
    seq = LoginSequence(
        login_url="https://example.com/login",
        credentials={"username": "admin", "password": "secret"},
        method="POST",
        success_criteria=["Location: /dashboard"],
    )
    session.authenticate(seq)
"""

import base64
import json
import logging
import re
import ssl
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger('auth_session')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class LoginFormField:
    """A form field identified during login detection."""
    name: str
    type_: str = 'text'
    required: bool = False
    value_hint: str = ''          # e.g. "username" or "email" in the name/label


@dataclass
class LoginFormInfo:
    """Discovered login form."""
    action: str
    method: str = 'POST'
    fields: List[LoginFormField] = field(default_factory=list)
    csrf_token_name: Optional[str] = None
    submit_button_name: Optional[str] = None

    def build_sequence(self, username: str = 'admin', password: str = 'password') -> 'LoginSequence':
        """Auto-build a LoginSequence from this form."""
        creds: Dict[str, str] = {}
        for f in self.fields:
            fh = f.value_hint.lower()
            if 'user' in fh or 'login' in fh or 'email' in fh:
                creds[f.name] = username
            elif 'pass' in fh or 'pwd' in fh:
                creds[f.name] = password
            else:
                creds[f.name] = f.value_hint or ''

        # If no creds found, default to first two fields
        if not creds and self.fields:
            creds[self.fields[0].name] = username
            if len(self.fields) > 1:
                creds[self.fields[1].name] = password
            elif len(self.fields) == 1:
                creds[self.fields[0].name] = f'{username}:{password}'

        return LoginSequence(
            login_url=self.action,
            credentials=creds,
            method=self.method,
            submit_field=self.submit_button_name,
        )


@dataclass
class LoginSequence:
    """A single login request definition."""
    login_url: str
    credentials: Dict[str, str]
    method: str = 'POST'
    extra_headers: Dict[str, str] = field(default_factory=dict)
    extra_cookies: Dict[str, str] = field(default_factory=dict)
    submit_field: Optional[str] = None
    # Success criteria: list of patterns to look for in response
    success_criteria: List[str] = field(default_factory=lambda: [
        'location:', '/dashboard', '/profile', '/account', '/admin', '/home', '/welcome',
    ])
    failure_criteria: List[str] = field(default_factory=lambda: [
        'login failed', 'invalid password', 'incorrect', 'unauthorized', 'bad credentials',
    ])

    def __post_init__(self):
        if not self.login_url.startswith(('http://', 'https://')):
            self.login_url = 'https://' + self.login_url


# ====================================================================
# AuthSession -- main class
# ====================================================================

class AuthSession:
    """Manage authenticated scanning sessions."""

    def __init__(self, target_url: str = '', user_agent: str = ''):
        self.target_url = target_url
        if not self.target_url.startswith(('http://', 'https://')) and self.target_url:
            self.target_url = 'https://' + self.target_url

        self._user_agent = user_agent or (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )

        # Session state
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': self._user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
        })

        # Auth state
        self._authenticated: bool = False
        self._auth_method: str = ''
        self._cookie_jar_cookies: Dict[str, Tuple[str, str]] = {}  # name -> (value, scope_url)
        self._header_creds: Dict[str, str] = {}      # header_name -> value
        self._token: Optional[str] = None             # OAuth2 / Bearer token
        self._mtls_cert: Optional[Tuple[str, str]] = None  # (cert_path, key_path)

        # Collected info
        self._discovered_forms: List[LoginFormInfo] = []
        self._last_login_response: Optional[requests.Response] = None
        self._login_url: Optional[str] = None         # auto-discovered login page URL

    @property
    def is_authenticated(self) -> bool:
        return self._authenticated

    @property
    def auth_method(self) -> str:
        return self._auth_method

    @property
    def cookies(self) -> Dict[str, str]:
        """Return current session cookies."""
        return {c.name: c.value for c in self._session.cookies}

    # ------------------------------------------------------------------
    # Login form discovery
    # ------------------------------------------------------------------

    def discover_login_forms(self, pages: Optional[List[str]] = None) -> List[LoginFormInfo]:
        """Discover login forms by scanning pages for common patterns."""
        targets = pages or [self.target_url] if self.target_url else []

        # Also try common login URLs
        common_paths = ['/login', '/signin', '/auth', '/authenticate', '/account/login', '/user/login']
        parsed = urlparse(self.target_url) if self.target_url else None
        for path in common_paths:
            if parsed and parsed.hostname:
                base = f'{parsed.scheme}://{parsed.hostname}'
                candidate = urljoin(base, path)
                if candidate not in targets:
                    targets.append(candidate)

        forms: List[LoginFormInfo] = []
        for page_url in targets:
            try:
                resp = self._session.get(page_url, timeout=10, allow_redirects=True, verify=False)
                soup = BeautifulSoup(resp.text, 'html.parser')
                page_forms = self._find_forms_in_page(soup, page_url)
                forms.extend(page_forms)

                # Look for login indicators in HTML text
                body_text = soup.get_text().lower()
                if any(kw in body_text for kw in ['login', 'sign in', 'authenticate', 'username', 'password']):
                    form_candidates = soup.find_all('form')
                    for form_tag in form_candidates:
                        action = form_tag.get('action', '')
                        if action and not any(f.action == urljoin(page_url, action) for f in forms):
                            info = self._parse_form(form_tag, page_url)
                            if info and any(f.type_ in ('text', 'email', 'password') for f in info.fields):
                                forms.append(info)
            except requests.RequestException as exc:
                logger.debug('discover_login_forms(%s): %s', page_url, exc)

        self._discovered_forms = forms
        logger.info('Discovered %d login forms from %d pages', len(forms), len(targets))
        return forms

    def _find_forms_in_page(self, soup: BeautifulSoup, base_url: str) -> List[LoginFormInfo]:
        """Find login forms in a parsed HTML page."""
        forms: List[LoginFormInfo] = []
        body_text = soup.get_text().lower()

        for form_tag in soup.find_all('form'):
            action = urljoin(base_url, form_tag.get('action', '') or '')
            info = self._parse_form(form_tag, base_url)
            if not info:
                continue

            # Heuristic: is this a login form?
            has_password = any(f.type_ == 'password' for f in info.fields)
            has_username = any('user' in f.value_hint.lower() or 'login' in f.value_hint.lower()
                               for f in info.fields)
            action_has_login = 'login' in action.lower() or 'auth' in action.lower() or 'signin' in action.lower()

            if has_password or (has_username and action_has_login):
                forms.append(info)

        return forms

    @staticmethod
    def _parse_form(form_tag, base_url: str) -> Optional[LoginFormInfo]:
        """Parse a <form> tag into LoginFormInfo."""
        method = (form_tag.get('method', 'GET') or 'GET').upper()
        action = form_tag.get('action', '') or ''

        fields: List[LoginFormField] = []
        csrf_name: Optional[str] = None
        submit_name: Optional[str] = None

        # Check for CSRF tokens
        for tag in form_tag.find_all(['input', 'meta']):
            name = (tag.get('name') or tag.get('property') or '').lower()
            type_ = (tag.get('type') or '').lower()
            if 'csrf' in name or 'token' in name or '_token' in name:
                csrf_name = tag.get('name') or tag.get('content')
            inp_type = type_ or ''
            if inp_type == 'submit':
                submit_name = tag.get('name')

        for inp in form_tag.find_all(['input', 'select', 'textarea']):
            name = inp.get('name', '')
            if not name:
                continue
            fields.append(LoginFormField(
                name=name,
                type_=(inp.get('type') or 'text').lower(),
                required=inp.has_attr('required'),
                value_hint=name.lower(),
            ))

        # Look for hidden password/username clues in labels
        for label in form_tag.find_all('label'):
            for_field = (label.get('for') or '').lower()
            for ff in fields:
                if ff.name == for_field:
                    text = label.get_text().lower()
                    if 'pass' in text:
                        ff.type_ = 'password'
                        ff.value_hint = 'password'
                    elif 'user' in text or 'login' in text or 'email' in text:
                        ff.value_hint = 'username'

        # Also check form's hidden inputs for csrf
        if not csrf_name:
            for inp in form_tag.find_all('input', type='hidden'):
                name = inp.get('name', '').lower()
                if 'csrf' in name or 'token' in name:
                    csrf_name = inp.get('name')

        return LoginFormInfo(
            action=urljoin(base_url, action),
            method=method,
            fields=fields,
            csrf_token_name=csrf_name,
            submit_button_name=submit_name,
        )

    # ------------------------------------------------------------------
    # Authentication methods
    # ------------------------------------------------------------------

    def authenticate(self, sequence: LoginSequence) -> bool:
        """Execute a login sequence and persist cookies/tokens."""
        url = sequence.login_url

        # Build headers
        headers = dict(sequence.extra_headers)
        if sequence.method == 'POST':
            headers['Content-Type'] = headers.get('Content-Type', 'application/x-www-form-urlencoded')

        try:
            resp = self._session.request(
                method=sequence.method, url=url,
                data=sequence.credentials, headers=headers,
                timeout=15, allow_redirects=True, verify=False,
            )
        except requests.RequestException as exc:
            logger.error('authenticate(%s): %s', url, exc)
            return False

        self._last_login_response = resp
        success = self._check_success(resp, sequence)

        if success:
            self._authenticated = True
            self._auth_method = 'form_post'
            self._login_url = url
            logger.info('Login successful at %s', url)
        else:
            # Try with cookies from sequence
            for k, v in sequence.extra_cookies.items():
                self._session.cookies.set(k, v, domain=urlparse(url).netloc)
            resp2 = self._session.request(
                method=sequence.method, url=url,
                data=sequence.credentials, headers=headers,
                timeout=15, allow_redirects=True, verify=False,
            )
            if self._check_success(resp2, sequence):
                self._authenticated = True
                self._auth_method = 'form_post_with_cookies'
                self._login_url = url
                logger.info('Login successful at %s (with cookies)', url)

        return success or self._authenticated

    def authenticate_oauth2(self, token: str, target_url: Optional[str] = None) -> bool:
        """Authenticate via OAuth2 Bearer token."""
        self._token = token
        self._auth_method = 'oauth2_bearer'
        self._authenticated = True
        self._session.headers['Authorization'] = f'Bearer {token}'
        logger.info('OAuth2 auth configured for %s', target_url or 'all targets')
        return True

    def authenticate_api_key(self, api_key: str, header_name: str = 'X-API-Key') -> bool:
        """Authenticate via API key (common pattern)."""
        self._header_creds[header_name] = api_key
        self._auth_method = 'api_key'
        self._authenticated = True
        self._session.headers[header_name] = api_key
        logger.info('API key auth configured (%s)', header_name)
        return True

    def configure_mtls(self, cert_path: str, key_path: Optional[str] = None) -> bool:
        """Configure mTLS client certificate authentication."""
        try:
            if key_path:
                self._mtls_cert = (cert_path, key_path)
                self._session.cert = (cert_path, key_path)
            else:
                self._mtls_cert = (cert_path, cert_path)
                self._session.cert = cert_path
            self._auth_method = 'mtls'
            self._authenticated = True
            logger.info('mTLS cert configured: %s', cert_path)
            return True
        except Exception as exc:
            logger.error('mTLS config failed: %s', exc)
            return False

    def configure_ssl_client(self, cert_data: bytes, key_data: bytes):
        """Configure mTLS from raw PEM data."""
        ctx = ssl.create_default_context()
        try:
            import tempfile, os
            with tempfile.NamedTemporaryFile(suffix='.crt', delete=False) as cf:
                cf.write(cert_data)
                cert_file = cf.name
            with tempfile.NamedTemporaryFile(suffix='.key', delete=False) as kf:
                kf.write(key_data)
                key_file = kf.name
        except Exception:
            return
        self.configure_mtls(cert_file, key_file)

    # ------------------------------------------------------------------
    # Cookie / header management
    # ------------------------------------------------------------------

    def add_cookie(self, name: str, value: str, domain: Optional[str] = None, path: str = '/'):
        """Manually add a session cookie."""
        self._cookie_jar_cookies[name] = (value, domain or '/')
        self._session.cookies.set(name, value, domain=domain, path=path)
        logger.debug('Cookie added: %s=%s @%s', name, value[:20], domain or '/')

    def add_header(self, name: str, value: str):
        """Add a custom HTTP header to all subsequent requests."""
        self._header_creds[name] = value
        self._session.headers[name] = value

    def inject_session_into_requests(self, url: str) -> Dict[str, Any]:
        """Return the session state (cookies + headers) that should be used for a specific URL.

        Useful when feeding results to another scanner module.
        """
        cookies = {k: v for k, (val, scope) in self._cookie_jar_cookies.items() if not scope or urlparse(url).netloc == scope}
        extra_headers = dict(self._header_creds)
        if self._token and self._auth_method == 'oauth2_bearer':
            extra_headers['Authorization'] = f'Bearer {self._token}'
        return {'cookies': cookies, 'headers': extra_headers}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _check_success(self, resp: requests.Response, sequence: LoginSequence) -> bool:
        """Check if login succeeded based on criteria patterns."""
        body = resp.text + resp.url
        body_lower = body.lower()

        # Check success criteria
        for pat in sequence.success_criteria:
            if pat.lower() in body_lower:
                return True

        # If no success criteria matched, check failure criteria
        for pat in sequence.failure_criteria:
            if pat.lower() in body_lower:
                return False

        # Default heuristic: 3xx redirect + location points away from login = success
        if resp.is_redirect and self._login_url:
            loc = resp.headers.get('Location', '')
            if 'login' not in loc.lower() and 'signin' not in loc.lower():
                return True

        # If status is 200 and we have new cookies, likely success
        if resp.status_code == 200 and len(self._session.cookies) > 0:
            non_persistent = [c for c in self._session.cookies if not c.expires]
            if non_persistent:
                return True

        return False

    def get_session(self) -> requests.Session:
        """Return the underlying requests.Session for direct use."""
        return self._session

    def reset(self):
        """Clear all authentication state."""
        self._session = requests.Session()
        self._session.headers.update({'User-Agent': self._user_agent})
        self._authenticated = False
        self._auth_method = ''
        self._cookie_jar_cookies.clear()
        self._header_creds.clear()
        self._token = None
        self._mtls_cert = None
        self._discovered_forms.clear()
        self._last_login_response = None
        self._login_url = None


# ====================================================================
# Convenience functions
# ====================================================================

def auto_login(target_url: str, username: str = 'admin', password: str = 'password') -> Tuple[bool, AuthSession]:
    """Quick auto-login: discover forms and attempt authentication."""
    session = AuthSession(target_url=target_url)
    forms = session.discover_login_forms()
    if not forms:
        return False, session
    for form in forms:
        seq = form.build_sequence(username, password)
        if session.authenticate(seq):
            return True, session
    return False, session


def load_session_from_json(json_path: str) -> AuthSession:
    """Load saved session cookies + headers from a JSON file."""
    with open(json_path, 'r') as f:
        data = json.load(f)
    session = AuthSession()
    for cookie in data.get('cookies', []):
        session.add_cookie(cookie['name'], cookie['value'], domain=cookie.get('domain'))
    for header in data.get('headers', []):
        session.add_header(header['name'], header['value'])
    if data.get('token'):
        session.authenticate_oauth2(data['token'])
    session._authenticated = True
    logger.info('Session loaded from %s: %d cookies, %d headers', json_path,
                len(data.get('cookies', [])), len(data.get('headers', [])))
    return session


def save_session_to_json(session: AuthSession, json_path: str):
    """Save current session cookies + headers to a JSON file."""
    data = {
        'cookies': [{'name': k, 'value': v} for k, v in session.cookies.items()],
        'headers': [{'name': k, 'value': v} for k, v in session._header_creds.items()],
        'token': session._token or '',
        'auth_method': session._auth_method,
    }
    with open(json_path, 'w') as f:
        json.dump(data, f, indent=2)
    logger.info('Session saved to %s', json_path)
