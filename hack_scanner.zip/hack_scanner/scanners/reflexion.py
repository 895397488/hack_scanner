#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
结构化反思引擎 + WAF 绕过逐级升级 — 失败归因与策略强制切换
=====================================================================

背景（整合 vulnclaw 优势 ②，参照 vulnclaw/agent/reflexion.py）:
    小模型（27b 级）撞墙后的默认行为是"同一攻击路径换 payload 重试"，
    循环烧迭代。vulnclaw 的 ReflexionEngine 把失败【结构化】：
    分类（env_constraint/path_error/param_error/info_needed）→ 连败计数
    → 触发反思接管（停止重复 payload + 审查假设 + 换路径）→ 逐级升级
    WAF 绕过提示（L0 原始 payload → L4 换攻击面）→ 沉淀经验供蒸馏。

    本模块为纯标准库 dataclass 重写（vulnclaw 用 pydantic，不新增依赖），
    并通过 install_reflexion_coach 在入口层接入（orchestrator 零改动）：
    每轮 llm_invoke 前扫描 messages 里【新增】的 tool 结果，
    classify_failure 归因后记 attempt；触发阈值时把接管指令作为
    独立 user 消息追加（同 budget warning 模式，每轮重算、不污染历史）。

设计纪律（与 M6/M7/M11/M12 入口层包装一致）:
    - 只改传给 llm_invoke 的 messages 副本，orchestrator 零改动
    - 纯标准库、异常静默降级
    - 失败事件源与 ③ anti_loop 的 LoopTracker 互补：anti_loop 按 host 拉黑，
      reflexion 按"攻击路径×漏洞类型"归因升级
"""

import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

# 直接运行本文件时保证项目根目录在 sys.path（与 context_budget 同一模式）
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# 失败特征表复用 ③ 模块（同一来源，避免双份维护）
from scanners.anti_loop import (
    FAILED_ACCESS_PATTERNS,
    detect_attack_path,
    extract_host,
    is_meaningful_step,
)


class FailureCategory(str, Enum):
    ENV_CONSTRAINT = "env_constraint"
    PATH_ERROR = "path_error"
    PARAM_ERROR = "param_error"
    INFO_NEEDED = "info_needed"
    UNKNOWN = "unknown"


@dataclass
class Attempt:
    path: str
    success: bool
    category: Optional[FailureCategory] = None
    details: str = ""
    vuln_type: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class ReflexionState:
    attempts: List[Attempt] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    failed_paths: List[str] = field(default_factory=list)
    reflections: List[Dict[str, Any]] = field(default_factory=list)
    consecutive_failures: int = 0
    last_vuln_type: str = ""
    vuln_type_fail_count: int = 0


# ---------------------------------------------------------------------------
# 失败分类（纯逻辑，无 LLM；vulnclaw classify_failure 原特征表）
# ---------------------------------------------------------------------------
_CATEGORY_PATTERNS: Dict[FailureCategory, List[str]] = {
    FailureCategory.ENV_CONSTRAINT: [
        # English
        "waf", "403", "forbidden", "blocked", "filtered",
        "permission denied", "unauthorized", "rate limit", "timeout",
        "connection refused", "bad gateway", "service unavailable",
        # 中文
        "被拦截", "被过滤", "被waf", "拦截", "过滤掉", "转义",
        "禁止访问", "无权限", "权限不足", "频率限制", "限流",
    ],
    FailureCategory.PATH_ERROR: [
        # English
        "vulnerability does not exist", "not vulnerable", "no injection",
        "not injectable", "false positive", "dead end", "wrong attack surface",
        # 中文
        "不存在该漏洞", "没有漏洞", "无漏洞", "不是注入点", "无注入",
        "此处无", "误报", "死胡同", "走不通", "换攻击面", "换个方向",
    ],
    FailureCategory.PARAM_ERROR: [
        # English
        "invalid payload", "syntax error", "bad parameter", "wrong parameter",
        "encoding error", "malformed", "parse error", "delimiter",
        # 中文
        "参数错误", "参数不对", "payload无效", "payload 无效",
        "语法错误", "编码错误", "格式错误", "分隔符",
    ],
    FailureCategory.INFO_NEEDED: [
        # English
        "need more information", "need more recon", "unknown parameter",
        "insufficient information", "collect more", "fingerprint first",
        "enumerate first",
        # 中文
        "需要更多信息", "信息不足", "未知参数", "先收集", "先侦察", "先枚举",
        "先指纹", "再收集",
    ],
}

_SUGGESTIONS = {
    FailureCategory.ENV_CONSTRAINT: (
        "Use encoding or obfuscation to bypass filters, switch protocols or "
        "endpoints, and confirm access restrictions (WAF, permissions, or rate limits)."),
    FailureCategory.PATH_ERROR: (
        "Lower this path's priority and switch to a different attack surface or "
        "vulnerability type."),
    FailureCategory.PARAM_ERROR: (
        "Adjust parameter names, delimiters, payload syntax, or the injection location."),
    FailureCategory.INFO_NEEDED: (
        "Gather more reconnaissance before retrying this path."),
    FailureCategory.UNKNOWN: (
        "Review the failure history and try a different approach."),
}

# WAF 绕过逐级升级提示表（vulnclaw en.json 原文，L0 → L4）
_ESCALATION_HINTS: Dict[int, List[str]] = {
    0: ["First try the raw payload without encoding."],
    1: [
        "URL-encode special characters.",
        "Change keyword letter case (SeLeCt).",
        "Try whitespace variants (/**/, newline, Tab).",
    ],
    2: [
        "Try double URL encoding.",
        "Insert inline comments such as /**/.",
        "Use HTML entity encoding for browser-facing injection points.",
    ],
    3: [
        "Try Unicode escapes (\\u0027).",
        "Try hex encoding (0x...).",
        "Split keywords with string concatenation (con||cat).",
        "Use an equivalent alternative function to bypass a blocked function.",
    ],
    4: [
        "Combine multiple layers of encoding and obfuscation.",
        "Use alternative syntax for the same goal (for example, HANDLER instead of SELECT).",
        "Confirm with time-based blind injection or an out-of-band (OOB) channel.",
        "Switch to a completely different vulnerability type or attack surface.",
    ],
}


def classify_failure(response_text: Optional[str]) -> Optional[FailureCategory]:
    """把一段失败/结果文本分类到 5 类之一（空文本 → None，无特征 → UNKNOWN）。"""
    text = (response_text or "").lower()
    if not text.strip():
        return None
    if any(p.lower() in text for p in FAILED_ACCESS_PATTERNS):
        return FailureCategory.ENV_CONSTRAINT
    for category, patterns in _CATEGORY_PATTERNS.items():
        if any(p in text for p in patterns):
            return category
    return FailureCategory.UNKNOWN


# ---------------------------------------------------------------------------
# 反思引擎（vulnclaw ReflexionEngine 纯标准库重写）
# ---------------------------------------------------------------------------
class ReflexionEngine:
    """连败计数 → 触发反思 → 逐级升级（阈值与 vulnclaw 原值一致）。"""

    def __init__(self,
                 max_same_vuln_fails: int = 2,
                 max_total_no_progress: int = 5,
                 max_reflections_before_escalate: int = 3,
                 escalation_max_level: int = 4):
        self.max_same_vuln_fails = max_same_vuln_fails
        self.max_total_no_progress = max_total_no_progress
        self.max_reflections_before_escalate = max_reflections_before_escalate
        self.escalation_max_level = escalation_max_level
        self.state = ReflexionState()

    # -- 记录 ----------------------------------------------------------------
    def record_attempt(self, path: str, success: bool,
                       category: Optional[FailureCategory] = None,
                       details: str = "", vuln_type: str = "") -> None:
        self.state.attempts.append(Attempt(path=path, success=success,
                                           category=category, details=details,
                                           vuln_type=vuln_type))
        if success:
            self.state.consecutive_failures = 0
            self.state.vuln_type_fail_count = 0
            if vuln_type:
                self.state.last_vuln_type = vuln_type
            return

        self.state.consecutive_failures += 1
        # 不把占位符 "unknown"/空路径塞进失败路径列表，避免污染失败历史与归因
        if path and path != "unknown":
            self.state.failed_paths.append(path)

        if vuln_type:
            if vuln_type == self.state.last_vuln_type:
                self.state.vuln_type_fail_count += 1
            else:
                self.state.last_vuln_type = vuln_type
                self.state.vuln_type_fail_count = 1

        if category and category != FailureCategory.UNKNOWN and details:
            self.state.constraints.append(details)

    def record_reflection(self, old_path: str, new_path: str, reasoning: str) -> None:
        self.state.reflections.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "old_path": old_path,
            "new_path": new_path,
            "reasoning": reasoning,
        })
        self.state.consecutive_failures = 0
        self.state.vuln_type_fail_count = 0

    # -- 判定 ----------------------------------------------------------------
    def should_reflect(self) -> bool:
        same_vuln_stale = self.state.vuln_type_fail_count >= self.max_same_vuln_fails
        no_progress_stale = self.state.consecutive_failures >= self.max_total_no_progress
        return same_vuln_stale or no_progress_stale

    def should_escalate(self) -> bool:
        return len(self.state.reflections) >= self.max_reflections_before_escalate

    def get_escalation_level(self) -> int:
        level = (self.state.consecutive_failures // 2) + len(self.state.reflections)
        return min(self.escalation_max_level, max(0, level))

    def get_escalation_hints(self) -> List[str]:
        return list(_ESCALATION_HINTS[self.get_escalation_level()])

    # -- 分析 ----------------------------------------------------------------
    def analyze_failure_patterns(self) -> List[Dict[str, Any]]:
        patterns: Dict[str, Dict[str, Any]] = {}
        for attempt in self.state.attempts:
            if attempt.success:
                continue
            category = attempt.category.value if attempt.category else FailureCategory.UNKNOWN.value
            if category not in patterns:
                patterns[category] = {"count": 0, "paths": set(), "examples": []}
            patterns[category]["count"] += 1
            patterns[category]["paths"].add(attempt.path)
            if attempt.details and len(patterns[category]["examples"]) < 3:
                patterns[category]["examples"].append(attempt.details[:200])

        result = []
        for category, info in sorted(patterns.items(),
                                     key=lambda item: item[1]["count"], reverse=True):
            result.append({
                "category": category,
                "occurrences": info["count"],
                "affected_paths": sorted(info["paths"]),
                "example_details": info["examples"],
                "suggested_action": _SUGGESTIONS.get(
                    FailureCategory(category),
                    _SUGGESTIONS[FailureCategory.UNKNOWN]),
            })
        return result

    def get_failed_paths(self) -> List[str]:
        return list(dict.fromkeys(self.state.failed_paths))

    # -- 提示块 --------------------------------------------------------------
    def to_prompt_block(self) -> str:
        """轻量状态块（vulnclaw 原文英文提示；无状态时返回空串）。"""
        if not self.state.attempts and not self.state.reflections:
            return ""
        lines = [
            "🔁 Reflexion state:",
            f"- Consecutive rounds without progress: {self.state.consecutive_failures}",
            f"- Same vulnerability type failures: {self.state.vuln_type_fail_count}",
            f"- Current escalation level: L{self.get_escalation_level()}",
        ]
        failed_paths = self.get_failed_paths()
        if failed_paths:
            lines.append(f"- Failed paths (do not repeat): {', '.join(failed_paths[:8])}")
        return "\n".join(lines)

    def to_reflection_prompt(self) -> str:
        """反思接管指令，仅在 should_reflect() 触发时有内容。"""
        if not self.should_reflect():
            return ""
        lines = [
            "🔴 Reflexion takeover (repeated failures require a strategy change):",
            "- Stop changing payloads on the current attack path.",
            "- Review the failure history and identify which earlier assumption is likely wrong.",
            "- Before trying another payload, choose a materially different attack path or vulnerability type.",
            f"- Current escalation level: L{self.get_escalation_level()}",
        ]
        if self.should_escalate():
            lines.append("- ⚠️ Forced escalation: switch to a completely different "
                         "vulnerability type or attack surface and stop pursuing the current direction.")
        patterns = self.analyze_failure_patterns()
        if patterns:
            lines.append("- Failure pattern analysis:")
            for pattern in patterns[:3]:
                lines.append(f"  - {pattern['category']} ×{pattern['occurrences']}: "
                             f"{pattern['suggested_action']}")
        hints = self.get_escalation_hints()
        if hints:
            lines.append(f"- Bypass hints for level L{self.get_escalation_level()}:")
            for hint in hints:
                lines.append(f"  - {hint}")
        return "\n".join(lines)

    # -- 经验提取（① 蒸馏输入）----------------------------------------------
    def extract_experience(self) -> Optional[Dict[str, Any]]:
        if not self.state.attempts:
            return None
        successful_paths = [a.path for a in self.state.attempts if a.success]
        return {
            "total_attempts": len(self.state.attempts),
            "successful_paths": successful_paths,
            "failed_paths": self.get_failed_paths(),
            "constraints": list(dict.fromkeys(self.state.constraints)),
            "reflections": self.state.reflections,
            "failure_patterns": self.analyze_failure_patterns(),
            "last_vuln_type": self.state.last_vuln_type,
            "escalation_level": self.get_escalation_level(),
        }


# ---------------------------------------------------------------------------
# 入口层包装器：每轮扫描新增 tool 结果 → 记 attempt → 触发时注入接管指令
# ---------------------------------------------------------------------------
def _record_from_text(engine: ReflexionEngine, text: str) -> None:
    """把一条工具结果文本归因后记入引擎（UNKNOWN 时按 is_meaningful_step 判进展）。"""
    text = (text or "").strip()
    if not text:
        return
    cat = classify_failure(text)
    vuln_type = detect_attack_path(text) or ""
    path = detect_attack_path(text) or extract_host(text) or "unknown"
    if cat is not None and cat != FailureCategory.UNKNOWN:
        engine.record_attempt(path=path, success=False, category=cat,
                              details=text[:200], vuln_type=vuln_type)
    elif cat is FailureCategory.UNKNOWN and is_meaningful_step(text):
        engine.record_attempt(path=path, success=True, vuln_type=vuln_type)
    # UNKNOWN 且无进展关键词 → 不记（噪音，避免误重置连败计数）


def install_reflexion_coach(llm_invoke: Callable,
                            engine: Optional[ReflexionEngine] = None,
                            enabled: bool = True) -> Callable:
    """包装 llm_invoke：每轮调用前消化新增 tool 结果并注入反思块。

    - 新增 tool 结果（messages 尾部自上次以来）→ _record_from_text 归因计数
    - should_reflect() 触发 → to_reflection_prompt() 作为独立 user 消息追加，
      并 record_reflection()（重置连败、推进升级级别，避免每轮重复接管）
    - 未触发但有连败 → to_prompt_block() 轻量状态块（每轮重算，不污染历史）
    - orchestrator 零改动：只改 messages 副本；透传 .client
    """
    if not enabled:
        return llm_invoke
    engine = engine or ReflexionEngine()

    state = {"seen": 0}

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        messages = kwargs.get("messages") if "messages" in kwargs else (
            args[1] if len(args) >= 2 else None)
        if isinstance(messages, list):
            n = len(messages)
            if n < state["seen"]:
                # 外层（context_budget）截断了历史 → 跳过旧消息，避免重复计数
                state["seen"] = n
            else:
                for m in messages[state["seen"]:n]:
                    if isinstance(m, dict) and m.get("role") == "tool":
                        try:
                            _record_from_text(engine, str(m.get("content") or ""))
                        except Exception:
                            pass  # 归因异常静默，不阻断核心循环
                state["seen"] = n

        block = ""
        try:
            if engine.should_reflect():
                block = engine.to_reflection_prompt()
                if block:
                    engine.record_reflection(
                        engine.state.last_vuln_type or "unknown",
                        "auto-escalation",
                        "reflexion takeover injected (repeated failures)")
            else:
                # 轻量状态块：仅在确有连败/升级状态时注入，避免无信息占位
                if engine.state.consecutive_failures >= 1 or engine.state.reflections:
                    block = engine.to_prompt_block()
        except Exception:
            block = ""

        if block:
            msg = {"role": "user", "content": block}
            if "messages" in kwargs:
                kwargs["messages"] = list(kwargs["messages"] or []) + [msg]
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = list(new_args[1] or []) + [msg]
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)
    wrapped._engine = engine  # 测试用
    return wrapped


if __name__ == "__main__":
    # 自测：失败分类 / 连败触发 / 升级递进 / 接管指令 / 经验提取
    assert classify_failure("WAF blocked the request 被拦截") == FailureCategory.ENV_CONSTRAINT
    assert classify_failure("no injection found, false positive") == FailureCategory.PATH_ERROR
    assert classify_failure("syntax error in payload 参数错误") == FailureCategory.PARAM_ERROR
    assert classify_failure("need more recon 先枚举") == FailureCategory.INFO_NEEDED
    assert classify_failure("200 OK 发现 flag") == FailureCategory.UNKNOWN
    assert classify_failure("") is None

    eng = ReflexionEngine()
    # 同一漏洞类型连败 2 次 → 触发反思
    eng.record_attempt(path="sqli", success=False, category=FailureCategory.ENV_CONSTRAINT,
                       details="waf blocked", vuln_type="sqli")
    eng.record_attempt(path="sqli", success=False, category=FailureCategory.ENV_CONSTRAINT,
                       details="403 forbidden", vuln_type="sqli")
    assert eng.should_reflect(), "同类漏洞连败 2 次应触发反思"
    rp = eng.to_reflection_prompt()
    assert "Reflexion takeover" in rp and "Bypass hints" in rp
    assert "L" in rp  # 升级级别行
    eng.record_reflection("sqli", "auto", "test")
    assert not eng.should_reflect(), "record_reflection 后应重置"
    # 升级递进：reflections 数推进级别
    assert eng.get_escalation_level() >= 1
    # 成功清零
    eng2 = ReflexionEngine()
    eng2.record_attempt(path="xss", success=False, category=FailureCategory.PARAM_ERROR, vuln_type="xss")
    eng2.record_attempt(path="xss", success=True, vuln_type="xss")
    assert eng2.state.consecutive_failures == 0 and eng2.state.vuln_type_fail_count == 0
    # 经验提取（① 蒸馏输入）
    exp = eng2.extract_experience()
    assert exp and exp["total_attempts"] == 2 and exp["successful_paths"] == ["xss"]
    # 包装器：新增 tool 结果 → 触发接管；短历史不误注入
    seen_msgs = []
    def fake_llm(system_prompt=None, messages=None, tools=None, **kw):
        seen_msgs.append(len(messages or []))
        return {"content": "ok", "stop_reason": "end_turn", "tool_calls": []}
    wrapped = install_reflexion_coach(fake_llm)
    base = [{"role": "user", "content": "Campaign started."}]
    wrapped(system_prompt="S", messages=base, tools=[])
    assert seen_msgs[0] == 1, "无失败状态不应注入"
    # 连续喂 2 条 waf 失败结果 → 第 2 轮应注入接管块
    base.append({"role": "tool", "content": "http://t/x WAF blocked 被拦截 403"})
    wrapped(system_prompt="S", messages=base, tools=[])
    base.append({"role": "tool", "content": "http://t/y forbidden 无权限 blocked"})
    wrapped(system_prompt="S", messages=base, tools=[])
    assert seen_msgs[-1] == len(base) + 1, "触发后应追加 1 条接管消息"
    # 已消费的消息不重复计数（再调一次不应再触发）
    wrapped(system_prompt="S", messages=base, tools=[])
    assert seen_msgs[-1] == len(base) + 1, "接管后连败计数已重置，不应再次注入"
    print("self-test OK")
