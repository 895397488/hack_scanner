#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Domain Typosquatting / Homograph Detector — 域名混淆/相似域名检测。

用途：发现与目标域名相似的恶意域名（钓鱼网站注册的同名域名）。

Usage:
    from scanners.domain_similarity import find_typosquats
    result = find_typosquats("google.com")
"""

import logging
from typing import Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger('domain_similarity')

try:
    from rapidfuzz import fuzz, process
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False


def _levenshtein_ratio(a: str, b: str) -> float:
    """计算 Levenshtein 相似度 (0-100)"""
    if not HAS_RAPIDFUZZ:
        # Fallback simple implementation
        if len(a) == 0: return 100.0
        if len(b) == 0: return 100.0
        m, n = len(a), len(b)
        dp = list(range(n + 1))
        for i in range(1, m + 1):
            prev = dp[0]
            dp[0] = i
            for j in range(1, n + 1):
                cost = 0 if a[i-1] == b[j-1] else 1
                dp[j], prev = min(prev + 1, dp[j] + 1, prev + cost), dp[j]
        return (1 - dp[n] / max(m, n)) * 100.0
    return fuzz.ratio(a.lower(), b.lower())


def _find_typosquats_manual(domain: str) -> list:
    """手动生成可能的域名混淆变体"""
    parsed = urlparse(f"https://{domain}")
    hostname = parsed.hostname or domain
    parts = hostname.split('.')

    if len(parts) < 2:
        return []

    # 分离 root domain (last two parts)
    root = f"{parts[-2]}.{parts[-1]}"
    sub = '.'.join(parts[:-2])

    tld = parts[-1]
    name = parts[-2]

    suspects = set()

    # ── 1. 重复字符 (gooogle.com) ──
    for i in range(len(name)):
        new_name = name[:i] + name[i] + name[i:] + tld
        full = f"{sub}.{new_name}" if sub else new_name
        suspects.add(full)

    # ── 2. 删除字符 (gogle.com) ──
    for i in range(len(name)):
        new_name = name[:i] + name[i+1:] + tld
        full = f"{sub}.{new_name}" if sub else new_name
        suspects.add(full)

    # ── 3. 替换相邻字符 (google.com → gooogle, gogole) ──
    for i in range(len(name) - 1):
        swapped = name[:i] + name[i+1] + name[i] + name[i+2:] + tld
        full = f"{sub}.{swapped}" if sub else swapped
        suspects.add(full)

    # ── 4. 键盘相邻键替换 (qwerty → qweety) ──
    keymap = {
        'q': '12wasx', 'w': 'qwer3edc', 'e': 'wrt56yui7ojd', 'r': 'etfgy8ikju9op',
        't': 'ryg6u7ih', 'y': 'tegzh7ujk8ol', 'u': 'yhj8ikl9op;', 'i': 'ujk0p[]ytr5',
        'o': 'ipl;[uyr6', 'p': 'oil[{opyr5',
        'a': 'qsxzwe', 's': 'aqzdw3xedc', 'd': 'sfxcwer5tgcz', 'f': 'dgvcert6yhxb',
        'g': 'fhvbety8ujn', 'h': 'gjnwuty7ikm', 'j': 'hkmyu8i9olp;', 'k': 'jlniy0op[];',
        'l': 'kmo;[plok',
        'z': 'axscd', 'x': 'zasvcd', 'c': 'xszvfde', 'v': 'cxgbf',
        'b': 'vgcnh', 'n': 'bhjm', 'm': 'nkj',
    }
    for i, ch in enumerate(name):
        neighbors = keymap.get(ch, '')
        for nb in neighbors:
            if nb.isalpha() and nb != ch:
                new_name = name[:i] + nb + name[i+1:] + tld
                full = f"{sub}.{new_name}" if sub else new_name
                suspects.add(full)

    # ── 5. TLD 替换 (.com → .net/.org/.info/.xyz/.co) ──
    alt_tlds = ['net', 'org', 'info', 'xyz', 'co', 'biz', 'us', 'cc', 'me', 'tv']
    for alt in alt_tlds:
        full = f"{sub}.{name}.{alt}" if sub else f"{name}.{alt}"
        suspects.add(full)

    # ── 6. 添加/删除子域名前缀 ──
    prefixes = ['', 'www.', 'mail.', 'api.', 'admin.', 'login.', 'account.', 'secure.',
                'my-', 'get-', 'the-', 'pro-', 'web-']
    for pfx in prefixes:
        full = f"{pfx}{root}" if sub else f"{pfx}{root}"
        suspects.add(full)

    # ── 7. Homograph / IDN (用 Cyrillic 替换 Latin) ──
    homograph_map = {
        'a': '\u0430', 'b': '\u0431', 'c': '\u0446', 'd': '\u0434', 'e': '\u0435',
        'f': '\u0444', 'g': '\u0433', 'h': '\u0445', 'i': '\u0456', 'j': '\u0458',
        'k': '\u043a', 'l': '\u043b', 'm': '\u043c', 'n': '\u043d', 'o': '\u043e',
        'p': '\u043f', 'q': '\u0455', 'r': '\u0440', 's': '\u0441', 't': '\u0442',
        'u': '\u0443', 'v': '\u0432', 'w': '\u0448', 'x': '\u044d', 'y': '\u044b',
        'z': '\u0437',
    }
    cyrillic_name = ''.join(homograph_map.get(ch, ch) for ch in name)
    if cyrillic_name != name:
        full_cyrillic = f"{sub}.{cyrillic_name}.{tld}" if sub else f"{cyrillic_name}.{tld}"
        suspects.add(full_cyrillic)

    # 过滤掉原始域名
    suspects.discard(f"{sub}.{root}" if sub else root)
    suspects.discard(root)

    return list(suspects)


def find_typosquats(
    domain: str,
    similarity_threshold: float = 80.0,
) -> dict:
    """发现与目标域名相似的潜在钓鱼域名。

    Args:
        domain: 目标域名
        similarity_threshold: 相似度阈值 (60-95)，越高越精确

    Returns:
        {
            "ok": True,
            "target_domain": "...",
            "suspects": [
                {"domain": "gooogle.com", "similarity": 92.5, "type": "char_repeat"}
            ],
            "total_suspects": N,
            "error": ""
        }
    """
    domain = urlparse(f"https://{domain}").hostname or domain

    suspects = []
    variants = _find_typosquats_manual(domain)

    for variant in variants:
        ratio = _levenshtein_ratio(domain, variant)
        if ratio >= similarity_threshold and len(variant) > 0:
            suspect_type = ''
            parsed_v = urlparse(f"https://{variant}")
            v_parts = (parsed_v.hostname or variant).split('.')

            # Determine why it's similar
            if domain == variant:
                continue

            root_d = '.'.join(domain.split('.')[-2:])
            root_v = '.'.join(v_parts[-2:])

            if root_d != root_v and len(root_v) > 3:
                suspect_type = 'tld_swapped'
            elif ratio >= 90:
                suspect_type = 'homograph_possible'
            else:
                suspect_type = 'typo_variant'

            suspects.append({
                "domain": variant,
                "similarity": round(ratio, 1),
                "type": suspect_type,
            })

    # Sort by similarity descending
    suspects.sort(key=lambda x: x["similarity"], reverse=True)

    return {
        "ok": True,
        "target_domain": domain,
        "suspects": suspects[:100],
        "total_suspects": len(suspects),
        "error": "",
    }


def check_domain_similarity(domain_a: str, domain_b: str) -> dict:
    """比较两个域名的相似度。"""
    ratio = _levenshtein_ratio(domain_a, domain_b)
    return {
        "domain_a": domain_a,
        "domain_b": domain_b,
        "similarity": round(ratio, 1),
        "likely_typosquat": ratio >= 80 and domain_a != domain_b,
    }
