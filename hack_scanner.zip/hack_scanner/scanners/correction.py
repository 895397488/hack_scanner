#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自纠正信号层 — 工具生命周期观察 + 证据事实累积 + 每轮纠正注入
=====================================================================

背景（参照 vulnclaw/agent/correction_layer.py）:
    模型撞墙后的常见行为是"重复无效探测"——同一假设换 payload 反复打。
    vulnclaw 的 correction layer 不做规划，只观察工具生命周期、从响应里
    累积紧凑事实（真实 URL/端点、JS 端点、SQL 错误片段、WAF 特征、
    解析器差异、认证线索），每轮把"你目前确认的事实 + 与假设的偏差"
    注入提示，让模型自我纠正而不是重复已发生过的动作。

    本模块是 vulnclaw 事实抽取规则（_extract_*_facts 正则族 + 去重/
    滚动窗口 + 紧凑块格式）的纯标准库移植：vulnclaw 依赖 pydantic/
    AgentState，这里用 dataclass + 入口层包装落地 hack_scanner 的
    ToolDefinition.execute 与 llm_invoke kwargs 契约，零新增依赖，
    不 import vulnclaw。

与 scanners/reflexion.py 的分工（互补，不重叠）:
    - reflexion 管【失败升级】：失败归因（env/path/param/info）→ 连败计数
      → 强制反思接管 + WAF 绕过逐级升级（L0→L4）
    - correction 管【证据/事实累积】：观察工具生命周期，抽取紧凑事实，
      每轮注入"已确认事实 + 与假设的偏差"块，让模型对照事实自我纠正
    - anti_loop 管【host 拉黑】：同一 host 连续失败短路，不再发真实请求
    三者共享同一失败事件源（tool 结果文本），各司其职。

设计纪律（与 run_adaptive.py 的入口层包装一致）:
    - install_correction_observer 只包装 tool.execute（同 install_result_recorder
      模式），透传原始 (result, error)，orchestrator 零改动
    - install_correction_coach 只改传给 llm_invoke 的 messages 副本；
      纠正块每轮重算、不污染 orchestrator 消息历史；透传 .client
    - 纯标准库；脏输入不抛异常（observe/抽取/注入全程静默降级）
    - 注入 LLM 的提示块用英文（与 hack_scanner 既有注入块风格一致）
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Tuple
from urllib.parse import urlparse

__all__ = [
    "Fact",
    "CorrectionObserver",
    "install_correction_observer",
    "install_correction_coach",
]


# ---------------------------------------------------------------------------
# 事实数据契约
# ---------------------------------------------------------------------------
@dataclass
class Fact:
    """一条从工具响应中抽取的紧凑事实。

    kind: url | endpoint | js_endpoint | sql_error | parser_diff | waf | auth | other
    text: 事实文本（≤200 字符，注入提示用英文）
    source_tool: 产出该事实的工具名
    at: 观察序号（第几次 observe 累积进来）
    """

    kind: str
    text: str
    source_tool: str
    at: int


# ---------------------------------------------------------------------------
# 抽取规则（vulnclaw correction_layer.py 正则族 + 本项目特征表）
# ---------------------------------------------------------------------------
_URL_RE = re.compile(r"https?://[^\s'\"<>）)\]]+", re.IGNORECASE)

# 独立路径（前面不是词字符/连字符 — URL 内路径由 URL 事实推导，不在此重复）
_PATH_RE = re.compile(r"(?<![\w-])/[A-Za-z0-9._~!$&'()*+,;=:@%-]{2,120}")

# JS 端点：src/href/url 引用 或 fetch/axios/import/require 调用
_JS_CTX_RE = re.compile(
    r"""(?ix)
    (?:
      \b(?:src|href|url)\s*=\s*["']
      | \b(?:fetch|import|require|axios\.\w+)\s*\(\s*["']
    )
    ([^"'\n]{1,180}?\.js(?:\?[^"'\n]*)?)
    ["']
    """
)
# JS 端点：裸 .js 路径提及（/static/app.min.js 等）
_JS_PATH_RE = re.compile(r"(?<![\w-])/[A-Za-z0-9._~-]*[A-Za-z0-9_-]\.js(?:\?[^ \t'\"()\]\}>]*)?")

# SQL 错误特征（MySQL/Postgres/Oracle/SQLite/通用）
_SQL_ERROR_PATTERNS: List[str] = [
    r"syntax error near\s*['\"`]?[^'\"`,;\n]{0,60}",
    r"You have an error in your SQL syntax[^\n]{0,160}",
    r"unclosed quotation mark[^\n]{0,80}",
    r"SQLSTATE\[[0-9A-Fa-f]{5}\][^\n]{0,120}",
    r"ORA-\d{5}[^\n]{0,120}",
    r"Postgres(ql)?[ -]?error[^\n]{0,120}",
    r"pg_query\(\)[^\n]{0,80}",
    r"sqlite3\.[A-Za-z]+Error[^\n]{0,120}",
    r"MySQLSyntaxErrorException[^\n]{0,120}",
    r"mysqli_\w+[^\n]{0,80}",
    r"near ['\"]\.['\"] at line \d+",
    r"valid SQL statement[^\n]{0,80}",
    r"unterminated string[^\n]{0,80}",
    r"Database error[^\n]{0,120}",
    r"SQL syntax error[^\n]{0,120}",
]

# WAF 特征（状态码/拦截语义/厂商指纹）
_WAF_PATTERNS: List[str] = [
    r"\b403\b[^\n]{0,100}",
    r"\bWAF\b[^\n]{0,100}",
    r"\bforbidden\b[^\n]{0,80}",
    r"request (?:was )?blocked[^\n]{0,100}",
    r"\bblocked\b[^\n]{0,80}",
    r"challenge[^\n]{0,80}",
    r"verify you are (?:a )?human[^\n]{0,60}",
    r"captcha[^\n]{0,60}",
    r"modsecurity|cloudflare|imperva|aws waf|f5 big-?ip|datadome|perimeterx[^\n]{0,80}",
    r"\b429\b[^\n]{0,80}",
    r"too many requests[^\n]{0,60}",
    r"rate.?limit(?:ed)?[^\n]{0,80}",
]

# 认证头线索
_AUTH_PATTERNS: List[str] = [
    r"WWW-Authenticate[^\n]{0,120}",
    r"\b401\b[^\n]{0,100}",
    r"\bunauthorized\b[^\n]{0,80}",
    r"authentication (?:required|failed|expired)[^\n]{0,80}",
    r"login required[^\n]{0,80}",
    r"session (?:expired|invalid)[^\n]{0,80}",
    r"(?:invalid|expired|missing) (?:token|jwt|session)[^\n]{0,80}",
    r"Basic realm[^\n]{0,80}",
    r"Bearer realm[^\n]{0,80}",
]

# 解析器/过滤器差异线索（vulnclaw _extract_parser_filter_facts 思路）
_PARSER_RUNTIME_MARKERS = (
    "unserialize", "deserialize", "json_decode", "simplexml_load",
    "xpath", "template", "eval(", "assert(", "include(", "require(",
)
_FILTER_MARKERS = (
    "preg_match", "regex", "filter", "blacklist", "sanitiz",
    "regex_hit", "filter_hit",
)

# 源码 SQL 片段（select...from...where/limit/union — 非报错，归 "other"）
_SQL_SOURCE_RE = re.compile(
    r"(?is)\bselect\b.{0,240}?\bfrom\b.{0,160}?"
    r"(?:\bwhere\b|\blimit\b|\bunion\b|\bgroup\s+by\b|\border\s+by\b)[^\n]{0,120}"
)

# flag 类 token（"other" 事实）
_FLAG_RE = re.compile(r"(?i)\bctf\{[^}\n]{1,120}\}|\bflag[:=]\s*[A-Za-z0-9_\-]{4,64}")

# 噪音过滤：依赖文档链接 / 系统路径 / HTML 伪路径
_IGNORED_URL_PARTS = (
    "urllib3.readthedocs.io",
    "pythonhosted.org",
    "requests.readthedocs.io",
    "readthedocs.io",
    "pypi.org",
    "docs.python.org",
    "github.com/urllib3",
)
_IGNORED_PATH_PREFIXES = (
    "//", "/usr/", "/lib/", "/site-packages/", "/dev/",
    "/bin/", "/etc/", "/var/", "/opt/", "/tmp/",
)
_IGNORED_HTML_PSEUDO_PATHS = {
    "/a", "/b", "/br", "/code", "/div", "/em", "/i", "/li", "/p",
    "/pre", "/script", "/span", "/strong", "/style", "/head",
    "/body", "/html", "/title", "/meta", "/link",
}

# 提示块：kind → 英文标签（顺序即块内顺序）与每类条数上限
_KIND_LABELS: List[Tuple[str, str]] = [
    ("url", "urls"),
    ("endpoint", "endpoints"),
    ("js_endpoint", "js endpoints"),
    ("sql_error", "sql error"),
    ("parser_diff", "parser diff"),
    ("waf", "waf"),
    ("auth", "auth"),
    ("other", "other"),
]
_PER_KIND_LIMITS = {
    "url": 5, "endpoint": 6, "js_endpoint": 5, "sql_error": 3,
    "parser_diff": 2, "waf": 3, "auth": 3, "other": 3,
}
_MAX_BLOCK_CHARS = 1200
_MAX_FACT_TEXT = 200
_MAX_CANDIDATES_PER_OBSERVE = 24


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------
def _one_line(text: Any, limit: int) -> str:
    """压成单行并截断（脏输入安全）。"""
    try:
        s = re.sub(r"\s+", " ", str(text or "")).strip()
        return s[:limit].rstrip()
    except Exception:
        return ""


def _clean_url(raw: str) -> str:
    """去掉 URL 尾随标点（正则吃到行尾标点时的收尾）。"""
    return str(raw or "").rstrip(".,;:!?'\"}）,;:，。")


def _is_meaningful_path(path: str) -> bool:
    value = str(path or "").strip().lower().rstrip(">:\"'")
    if not value or value == "/":
        return False
    if value.startswith(_IGNORED_PATH_PREFIXES):
        return False
    if value.rstrip("/") in _IGNORED_HTML_PSEUDO_PATHS:
        return False
    if value.endswith(".js"):  # JS 资产走 js_endpoint 类，避免双重计数
        return False
    return True


def _endpoint_from_url(url: str) -> str:
    """从 URL 取 path 作为端点事实（http://host/api/v1/x → /api/v1/x）。"""
    try:
        path = (urlparse(url).path or "").split("?")[0]
    except Exception:
        return ""
    if len(path) < 3 or not _is_meaningful_path(path):
        return ""
    return path


def _merge_texts(result_text: Any, error: Any) -> str:
    """把结果与错误文本合并成一段（供正则抽取；错误里也常带 403/WAF 线索）。"""
    parts: List[str] = []
    for v in (result_text, error):
        if v is None:
            continue
        if isinstance(v, str):
            if v:
                parts.append(v)
        else:
            try:
                s = str(v)
                if s:
                    parts.append(s)
            except Exception:
                pass
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# 事实抽取（每类独立；返回 [(kind, text), ...]，已按 (kind,text) 去重）
# ---------------------------------------------------------------------------
def _extract_urls(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    for raw in _URL_RE.findall(text):
        url = _clean_url(raw)
        if not url:
            continue
        lowered = url.lower()
        if any(part in lowered for part in _IGNORED_URL_PARTS):
            continue
        out.append(("url", _one_line(url, _MAX_FACT_TEXT)))
        if len(out) >= _PER_KIND_LIMITS["url"]:
            break
    return out


def _extract_endpoints(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    # 1) URL 里的 path（http://host/api/v1/users → /api/v1/users）
    for raw in _URL_RE.findall(text):
        ep = _endpoint_from_url(_clean_url(raw))
        if ep and ("endpoint", ep) not in out:
            out.append(("endpoint", ep))
    # 2) 独立路径提及（"403 on /api/admin" / "GET /api/v1/login"）
    for p in _PATH_RE.findall(text):
        ep = _one_line(p, _MAX_FACT_TEXT)
        if not ep or not _is_meaningful_path(ep):
            continue
        if ("endpoint", ep) not in out:
            out.append(("endpoint", ep))
        if len(out) >= _PER_KIND_LIMITS["endpoint"]:
            break
    return out


def _extract_js_endpoints(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    # BUG_REPORT [8]：_JS_PATH_RE 无捕获组（仅非捕获 (?:...)），同循环取
    # m.group(1) 在首个 PATH 命中即抛 IndexError，外层 _extract_facts 的
    # except: continue 静默吞掉 → 本次调用 js_endpoint 事实全丢（含 CTX
    # 已抽到的合法端点）。两正则分开取组：CTX 有 group(1)，PATH 取 group(0)。
    for rx, grp in ((_JS_CTX_RE, 1), (_JS_PATH_RE, 0)):
        for m in rx.finditer(text):
            ep = _one_line(m.group(grp), _MAX_FACT_TEXT)
            if ep and ("js_endpoint", ep) not in out:
                out.append(("js_endpoint", ep))
            if len(out) >= _PER_KIND_LIMITS["js_endpoint"]:
                return out
    return out


def _extract_sql_errors(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    for pattern in _SQL_ERROR_PATTERNS:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            snippet = _one_line(m.group(0), _MAX_FACT_TEXT)
            if snippet and ("sql_error", snippet) not in out:
                out.append(("sql_error", snippet))
            if len(out) >= _PER_KIND_LIMITS["sql_error"]:
                return out
    return out


def _extract_waf(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    for pattern in _WAF_PATTERNS:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            snippet = _one_line(m.group(0), _MAX_FACT_TEXT)
            if snippet and ("waf", snippet) not in out:
                out.append(("waf", snippet))
            if len(out) >= _PER_KIND_LIMITS["waf"]:
                return out
    return out


def _extract_auth(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    for pattern in _AUTH_PATTERNS:
        for m in re.finditer(pattern, text, re.IGNORECASE):
            snippet = _one_line(m.group(0), _MAX_FACT_TEXT)
            if snippet and ("auth", snippet) not in out:
                out.append(("auth", snippet))
            if len(out) >= _PER_KIND_LIMITS["auth"]:
                return out
    return out


def _extract_parser_diff(text: str) -> List[Tuple[str, str]]:
    """解析器/过滤器边界线索（vulnclaw _extract_parser_filter_facts 移植）。"""
    lower = text.lower()
    has_runtime = any(m in lower for m in _PARSER_RUNTIME_MARKERS)
    has_filter = any(m in lower for m in _FILTER_MARKERS)
    has_php_serialized = bool(re.search(r"(?<![A-Za-z0-9_])[OC]:\d+:", text))
    if has_runtime and has_filter:
        return [
            (
                "parser_diff",
                "parser/filter boundary: input is filtered by regex/string logic "
                "before a runtime parser/interpreter; filter behavior and parser "
                "behavior may not be equivalent",
            )
        ]
    if has_php_serialized and has_filter:
        return [
            (
                "parser_diff",
                "parser/filter boundary: PHP serialized input is checked by a "
                "regex/string filter before unserialize; behavior may differ "
                "across lexical variants and runtime versions",
            )
        ]
    return []


def _extract_other(text: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    m = _SQL_SOURCE_RE.search(text)
    if m:
        snippet = _one_line(m.group(0), _MAX_FACT_TEXT)
        if snippet:
            out.append(("other", f"source SQL: {snippet}"))
    for flag in _FLAG_RE.findall(text)[:2]:
        token = _one_line(flag, _MAX_FACT_TEXT)
        if token:
            out.append(("other", f"flag-like token: {token}"))
    return out[:_PER_KIND_LIMITS["other"]]


def _extract_facts(text: str) -> List[Tuple[str, str]]:
    """从一段工具结果/错误文本抽取全部事实（脏输入安全，永不抛异常）。"""
    text = str(text or "")
    if not text.strip():
        return []
    facts: List[Tuple[str, str]] = []
    for extractor in (
        _extract_urls,
        _extract_endpoints,
        _extract_js_endpoints,
        _extract_sql_errors,
        _extract_waf,
        _extract_auth,
        _extract_parser_diff,
        _extract_other,
    ):
        try:
            facts.extend(extractor(text))
        except Exception:
            continue  # 单类抽取异常 → 静默跳过，不影响其余类别
    # 按 (kind, text) 去重、保序
    return list(dict.fromkeys(facts))[:_MAX_CANDIDATES_PER_OBSERVE]


# ---------------------------------------------------------------------------
# 观察者：事实累积（去重 + 滚动窗口）
# ---------------------------------------------------------------------------
class CorrectionObserver:
    """观察工具生命周期，累积紧凑事实，供每轮纠正注入。

    - observe(): 从结果/错误文本抽取事实；同 (kind,text) 不重复；
      超 max_facts 丢最老（滚动窗口，丢弃的事实可再累积回来）
    - to_prompt_block(): 紧凑英文块（≤1200 字符）；空事实 → ""
    - reset(): 清空全部状态（新 campaign 用）
    """

    def __init__(self, max_facts: int = 40):
        try:
            self.max_facts = max(1, int(max_facts))
        except (TypeError, ValueError):
            self.max_facts = 40
        self._facts: List[Fact] = []
        self._seen: set = set()  # {(kind, text)}
        self._seq = 0

    # -- 观察 --------------------------------------------------------------
    def observe(
        self,
        tool_name: str,
        args_string: str,
        result_text: str,
        error: Optional[str] = None,
    ) -> int:
        """观察一次工具调用，从结果（+错误）中抽取事实。返回新增事实数。

        args_string 为接口对称保留（事实只从结果文本抽取——args 是假设，
        result 才是证据）。任何异常都静默降级，返回 0，不阻断核心循环。
        """
        try:
            self._seq += 1
            at = self._seq
            tool = str(tool_name or "tool")
            text = _merge_texts(result_text, error)
            added = 0
            for kind, fact_text in _extract_facts(text):
                key = (kind, fact_text)
                if key in self._seen:
                    continue  # 同 kind+text 去重
                self._seen.add(key)
                self._facts.append(Fact(
                    kind=kind,
                    text=fact_text[:_MAX_FACT_TEXT],
                    source_tool=tool,
                    at=at,
                ))
                added += 1
            overflow = len(self._facts) - self.max_facts
            if overflow > 0:
                for _ in range(overflow):
                    old = self._facts.pop(0)
                    self._seen.discard((old.kind, old.text))
            return added
        except Exception:
            return 0

    # -- 读取 --------------------------------------------------------------
    @property
    def facts(self) -> List[Fact]:
        """当前累积的全部事实（按观察顺序；返回副本，外部改动不影响内部状态）。"""
        return list(self._facts)

    def to_prompt_block(self) -> str:
        """紧凑英文纠正块（≤1200 字符）；空事实 → 空串。

        格式（vulnclaw correction_layer 块风格）:
            [Correction — observed facts]
            - urls: http://t/api/v1/users
            - endpoints: /api/v1/users, /api/v1/login
            - sql error: syntax error near 'union' ...
            - waf: 403 challenge on /api/admin
            Reconcile your next probe against these facts; do not repeat
            an action whose outcome is already above.
        """
        if not self._facts:
            return ""
        lines: List[str] = ["[Correction — observed facts]"]
        for kind, label in _KIND_LABELS:
            items = [
                f.text
                for f in self._facts
                if f.kind == kind and f.text
            ][: _PER_KIND_LIMITS.get(kind, 3)]
            if not items:
                continue
            lines.append(f"- {label}: " + ", ".join(items))
        if len(lines) == 1:
            return ""
        lines.append(
            "Reconcile your next probe against these facts; "
            "do not repeat an action whose outcome is already above."
        )
        block = "\n".join(lines)
        if len(block) > _MAX_BLOCK_CHARS:
            # 超预算：从尾部事实行丢弃（头部/收尾指令行恒保留）
            head, tail = lines[0], lines[-1]
            budget = _MAX_BLOCK_CHARS - len(head) - len(tail) - 2
            kept: List[str] = []
            for ln in lines[1:-1]:
                cost = len(ln) + 1
                if cost > budget and kept:
                    break
                kept.append(ln)
                budget -= cost
            block = "\n".join([head] + kept + [tail])
        return block[:_MAX_BLOCK_CHARS]

    def reset(self) -> None:
        """清空事实/去重表/序号（新 campaign 调用）。"""
        self._facts.clear()
        self._seen.clear()
        self._seq = 0


# ---------------------------------------------------------------------------
# 入口层包装器（orchestrator 零改动）
# ---------------------------------------------------------------------------
def install_correction_observer(
    orch: Any,
    observer: Optional[CorrectionObserver] = None,
) -> CorrectionObserver:
    """包装 orch 每个 tool.execute：执行后把 (args, result, error) 喂给 observer。

    - 透传原始 (result, error)，工具异常照常抛出（orchestrator 有既有 try/except）
    - observer 自身异常 → 静默忽略，绝不阻断核心循环
    - 与 install_result_recorder / install_anti_loop_tracker 同为 execute 包装，
      互不干扰（各自透传返回值）
    - 返回 observer（调用方可共享给 coach / 摘要打印）
    """
    observer = observer or CorrectionObserver()
    tools = getattr(orch, "tools", None) or {}
    for name, tool in list(tools.items()):
        orig = getattr(tool, "execute", None)
        if orig is None:
            continue

        def wrap(args: Any, _orig=orig, _obs=observer, _name=name):
            try:
                args_s = args if isinstance(args, str) else str(args)
            except Exception:
                args_s = ""
            res, err = _orig(args)  # 工具异常透传（既有语义）
            try:
                text = res if isinstance(res, str) else (
                    str(res) if res is not None else "")
                _obs.observe(_name, args_s, text,
                             err if isinstance(err, str)
                             else (str(err) if err is not None else None))
            except Exception:
                pass  # 观察异常静默，不阻断核心循环
            return res, err

        tool.execute = wrap
    return observer


def install_correction_coach(
    llm_invoke: Callable,
    observer: Optional[CorrectionObserver] = None,
    enabled: bool = True,
) -> Callable:
    """包装 llm_invoke：每次调用前，若 observer 有事实 → 追加一条 user 消息。

    - 纠正块 = observer.to_prompt_block()（每轮重算，事实随观察滚动更新）
    - 只改传给 llm_invoke 的 messages 副本末尾，不污染 orchestrator 历史
      （同 install_budget_guard / install_reflexion_coach 模式）
    - enabled=False → 原样返回 llm_invoke
    - 透传 .client（usage 记账）；to_prompt_block 异常 → 无注入降级
    """
    if not enabled:
        return llm_invoke
    observer = observer or CorrectionObserver()

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        block = ""
        try:
            block = observer.to_prompt_block()
        except Exception:
            block = ""
        if block:
            msg = {"role": "user", "content": block}
            if "messages" in kwargs:
                kwargs["messages"] = list(kwargs["messages"] or []) + [msg]
            elif len(args) >= 2:
                new_args = list(args)
                new_args[1] = list(new_args[1] or []) + [msg]
                args = tuple(new_args)
        return llm_invoke(*args, **kwargs)

    # 透传 .client（usage 记账）
    wrapped.client = getattr(llm_invoke, "client", None)  # type: ignore[attr-defined]
    wrapped._observer = observer  # 测试用
    return wrapped


if __name__ == "__main__":
    # 自测：抽取 / 去重 / 滚动窗口 / 块格式 / 包装透传
    _obs = CorrectionObserver()
    _res = (
        "GET http://t.local/api/v1/users -> 200 OK\n"
        "SQLSTATE[42000]: You have an error in your SQL syntax; "
        "near 'union select * from users' at line 1\n"
        "403 WAF blocked on /api/admin (challenge page)\n"
        'src="/static/app.min.js"\n'
        '401 Unauthorized WWW-Authenticate: Bearer realm="api"'
    )
    assert _obs.observe("http_probe", "{}", _res) >= 5, "应抽到多类事实"
    assert _obs.observe("http_probe", "{}", _res) == 0, "重复观察不翻倍（去重）"
    kinds = {f.kind for f in _obs.facts}
    assert {"url", "endpoint", "sql_error", "waf", "auth", "js_endpoint"} <= kinds, kinds
    block = _obs.to_prompt_block()
    assert "Correction" in block and "Reconcile" in block, block[:120]
    assert len(block) <= 1200, f"len={len(block)}"
    assert CorrectionObserver().to_prompt_block() == "", "空观察者 → 空串"

    _small = CorrectionObserver(max_facts=3)
    for _i in range(5):
        _small.observe("t", "", "403 forbidden on /admin/v1 waf blocked")
    assert len(_small.facts) == 3, f"滚动窗口: {len(_small.facts)}"

    class _FT:
        name = "http_probe"
        def execute(self, args):
            return (_res, None)

    class _FO:
        def __init__(self):
            self.tools = {"http_probe": _FT()}

    _orch = _FO()
    _obs2 = CorrectionObserver()
    assert install_correction_observer(_orch, _obs2) is _obs2, "返回同一 observer"
    _r, _e = _orch.tools["http_probe"].execute("{}")
    assert _r == _res and _e is None, "透传 (result, error)"
    assert len(_obs2.facts) >= 5, f"执行后累积: {len(_obs2.facts)}"

    _llm_calls = []
    def _llm(system_prompt=None, messages=None, tools=None, **_kw):
        _llm_calls.append(list(messages or []))
        return {"content": "{}"}
    _llm.client = "CLIENT"
    _coach = install_correction_coach(_llm, _obs2)
    assert _coach.client is _obs2 and False or _coach.client == "CLIENT", ".client 透传"
    _coach(system_prompt="S", messages=[{"role": "user", "content": "probe"}], tools=[])
    _sent = _llm_calls[-1]
    assert _sent[-1]["role"] == "user" and "Correction" in _sent[-1]["content"], str(_sent[-1])[:120]
    assert len(_sent) == 2, "追加 1 条、不复制膨胀"
    assert install_correction_coach(_llm, _obs2, enabled=False) is _llm, "enabled=False 原样返回"
    print("self-test OK")
