#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OWASP ZAP Scanner — 通过 OWASP ZAP API 进行自动化 Web 应用安全扫描。

ZAP (Zed Attack Proxy) 是业界最主流的免费 Web 应用安全测试工具，
支持 Spider、Active Scan、Fuzzer 等核心能力。

集成方式：使用 zaproxy Python SDK（pip install zaproxy）。
需要本地运行 ZAP Desktop/Daemon：zap.sh -daemon -port 8090
或 docker run -d --name zap -p 8090:8090 ghcr.io/zaproxy/zaproxy:stable

Usage:
    from scanners.zap_scanner import zap_scan, zap_spider, get_active_scan_report
    result = zap_scan("https://example.com")
"""

import json
import logging
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger('zap_scanner')


def _get_zap_client():
    """获取 ZAP Python 客户端"""
    try:
        from zaproxy import Zaproxy
        return Zaproxy("127.0.0.1", "8090")
    except Exception as e:
        return None


def zap_spider(url: str, max_duration: int = 60) -> dict:
    """ZAP Spider — 自动爬取站点所有页面。

    Args:
        url: 目标 URL
        max_duration: 爬虫最大运行时间（秒）

    Returns:
        {"ok": True, "pages_found": N, "urls_crawled": [...], ...}
    """
    client = _get_zap_client()
    if not client:
        return {"ok": False, "error": "ZAP 未启动，请先运行: docker run -d --name zap -p 8090:8090 ghcr.io/zaproxy/zaproxy:stable"}

    result = {"ok": True, "url": url, "pages_found": 0, "urls_crawled": []}

    try:
        spider = client.spider
        scan_id = spider.scan(url, maxduration=max_duration)

        # Wait for spider to complete
        while int(spider.status(scan_id)) < 100:
            time.sleep(2)

        result["pages_found"] = len(spider.results(scan_id))
        result["urls_crawled"] = spider.results(scan_id)[:500]

    except Exception as e:
        result["error"] = str(e)

    return result


def zap_active_scan(url: str, max_duration: int = 300) -> dict:
    """ZAP Active Scan — 对已爬取的页面进行主动漏洞扫描。

    Args:
        url: 目标 URL（会 spider + active scan）
        max_duration: 主动扫描最大时间（秒）

    Returns:
        {
            "ok": True,
            "alerts": [
                {"risk": "High", "name": "SQL Injection", "url": "...", ...}
            ],
            "stats": {"high": 1, "medium": 3, "low": 5, "info": 2},
            "error": ""
        }
    """
    client = _get_zap_client()
    if not client:
        return {"ok": False, "error": "ZAP 未启动", "alerts": [], "stats": {}}

    result = {"ok": False, "url": url, "alerts": [], "stats": {"high": 0, "medium": 0, "low": 0, "info": 0}, "error": ""}

    try:
        # Phase 1: Spider to discover pages
        spider = client.spider
        spider_id = spider.scan(url, runscan=False)
        while int(spider.status(spider_id)) < 100:
            time.sleep(2)

        logger.info(f"ZAP Spider discovered {spider.results(spider_id).__len__()} URLs")

        # Phase 2: Active Scan
        ascan = client.ascan
        scan_id = ascan.scan(url, recurse=True, scanpolicyname="Baseline-Scan")

        while int(ascan.status(scan_id)) < 100:
            time.sleep(3)

        logger.info(f"ZAP Active Scan complete for {url}")

        # Phase 3: Get alerts
        pscan = client.pscan
        alerts = ascan.results(scan_id)
        all_alerts = []

        # Also get from pscan (post-scan)
        base_url = urlparse(url).netloc
        for alert in pscan.baseurlalerts(base_url):
            all_alerts.append(alert)

        # Deduplicate by alert+url+param
        seen = set()
        unique_alerts = []
        for a in alerts:
            key = f"{a.get('alert', '')}::{a.get('url', '')}::{a.get('param', '')}"
            if key not in seen:
                seen.add(key)
                all_alerts.append(a)

        # Format alerts
        for a in all_alerts[:200]:
            alert_entry = {
                "risk": a.get("risk", ""),
                "name": a.get("alert", ""),
                "url": a.get("url", url),
                "param": a.get("param", ""),
                "evidence": (a.get("description", "") or "")[:500],
                "solution": (a.get("solution", "") or "")[:300],
            }
            # CWE info
            if a.get("cweid"):
                alert_entry["cwe"] = f"CWE-{a.get('cweid')}"
            if a.get("wascid"):
                alert_entry["wasc"] = f"WASC-{a.get('wascid')}"

            all_alerts_unique = [x for x in unique_alerts if not (x["name"] == alert_entry["name"] and x["url"] == alert_entry["url"])]
            unique_alerts.append(alert_entry)

        result["alerts"] = unique_alerts

        # Stats by risk level
        risk_counts = {"high": 0, "medium": 0, "low": 0, "info": 0}
        for a in unique_alerts:
            r = a.get("risk", "").lower()
            if r in risk_counts:
                risk_counts[r] += 1

        result["stats"] = risk_counts
        result["total_alerts"] = len(unique_alerts)
        result["ok"] = True

    except Exception as e:
        result["error"] = str(e)

    return result


def zap_scan(url: str, max_duration: int = 300) -> dict:
    """一键完成 ZAP Spider + Active Scan（推荐入口）。

    Args:
        url: 目标 URL
        max_duration: 总扫描时间（秒）

    Returns:
        {"ok": True, "alerts": [...], "stats": {...}, ...}
    """
    # First spider
    spider_result = zap_spider(url, max_duration=max_duration // 2)

    # Then active scan
    return zap_active_scan(url, max_duration=max_duration)


def get_zap_context_info(url: str) -> dict:
    """获取 ZAP 上下文中的站点信息（子页面/技术栈）。"""
    client = _get_zap_client()
    if not client:
        return {"ok": False, "error": "ZAP 未启动"}

    try:
        base_url = urlparse(url).netloc
        urls = client.core.urls(base_url) if client else []
        site_map = client.site if hasattr(client, 'site') else None

        return {
            "ok": True,
            "target": url,
            "pages": urls[:200] if urls else [],
            "error": "",
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}
