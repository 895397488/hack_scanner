#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Git Secret Scanner — 通过 gitleaks CLI wrapper 扫描 Git 仓库中的敏感信息。

Gitleaks 是目前最流行的开源 Git 密钥泄露检测工具，
支持 AWS、Azure、GCP、Alibaba Cloud、JWT、SSH Key、私钥等 100+ pattern。

集成方式：需要安装 gitleaks（go install github.com/zricethezav/gitleaks/v2@latest）。
本模块只负责 CLI 调用和结果解析。

Usage:
    from scanners.git_secret_scanner import scan_git_repo
    result = scan_git_repo("/path/to/repo")
"""

import json
import logging
import os
import subprocess
from typing import Dict, List, Optional

logger = logging.getLogger('git_secret_scanner')


def _find_gitleaks() -> Optional[str]:
    """查找 gitleaks 可执行文件"""
    for name in ["gitleaks", "gitleaks.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def scan_git_repo(
    repo_path: str,
    branch: str = "",
    depth: str = "1",
) -> dict:
    """扫描 Git 仓库中的密钥泄露。

    Args:
        repo_path: 本地 Git 仓库路径（支持裸仓库/普通仓库）
        branch: 要扫描的分支（默认 HEAD/main/master）
        depth: git log --depth，推荐 0（全量）或 1000

    Returns:
        {
            "ok": True,
            "repo_path": "...",
            "findings": [
                {"rule_id": "aws-access-key-id", "file": "...",
                 "line": 42, "commit": "abc123", ...}
            ],
            "total_findings": N,
            "critical": N,  # AWS/Secret Keys
            "high": N,      # JWT/Tokens
            "medium": N,    # Generic patterns
            "error": ""
        }
    """
    gitleaks_path = _find_gitleaks()

    if not gitleaks_path:
        return {
            "ok": False,
            "repo_path": repo_path,
            "findings": [],
            "total_findings": 0,
            "critical": 0,
            "high": 0,
            "medium": 0,
            "error": "gitleaks 未找到，请安装: go install github.com/zricethezav/gitleaks/v2@latest",
        }

    cmd = [
        gitleaks_path,
        "detect",
        "-v", repo_path,  # verbose JSON output
        "--report-format", "json",
        "-r", "-",
    ]

    if branch:
        cmd.extend(["-b", branch])
    else:
        cmd.extend(["-b", "HEAD"])

    logger.info(f"gitleaks scan: {' '.join(cmd[:6])}...")
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=600, cwd=repo_path if os.path.isdir(repo_path) else None,
        )

        # Parse JSON output
        findings = []
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict):
                    # Normalize finding format
                    sev = "high"
                    if entry.get("ruleID", "").lower() in ["aws-access-key-id", "aws-secret-access-key-id", "gcp-service-account"]:
                        sev = "critical"
                    elif entry.get("ruleID", "").lower() in ["jwt-token", "private-key", "ssh-key"]:
                        sev = "high"
                    else:
                        sev = "medium"

                    findings.append({
                        "rule_id": entry.get("ruleID", ""),
                        "severity": sev,
                        "description": entry.get("description", ""),
                        "file": entry.get("file", ""),
                        "line": entry.get("line", 0),
                        "commit": entry.get("commit", ""),
                        "author": entry.get("author", ""),
                        "timestamp": entry.get("date", ""),
                        "match": (entry.get("match", "") or "")[:200],
                        "secret_type": entry.get("SecretType", entry.get("secret_type", "")),
                    })
            except json.JSONDecodeError:
                continue

        critical = sum(1 for f in findings if f["severity"] == "critical")
        high = sum(1 for f in findings if f["severity"] == "high")
        medium = sum(1 for f in findings if f["severity"] == "medium")

        return {
            "ok": True,
            "repo_path": repo_path,
            "findings": findings[:500],
            "total_findings": len(findings),
            "critical": critical,
            "high": high,
            "medium": medium,
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "repo_path": repo_path,
            "findings": [],
            "total_findings": 0,
            "critical": 0,
            "high": 0,
            "medium": 0,
            "error": "gitleaks 超时（最大时间 600s）",
        }


def scan_git_remote(
    repo_url: str,
    tmp_dir: Optional[str] = None,
    branch: str = "",
) -> dict:
    """扫描远程 Git 仓库的密钥泄露。

    Args:
        repo_url: 远程仓库 URL（如 https://github.com/user/repo.git）
        tmp_dir: 临时克隆目录（自动创建/删除）
        branch: 分支名

    Returns:
        {"ok": True, "repo_path": "...", "findings": [...], ...}
    """
    import tempfile
    import shutil

    clone_dir = None
    try:
        if tmp_dir:
            clone_dir = tmp_dir
        else:
            clone_dir = tempfile.mkdtemp(prefix="gitleaks-")

        logger.info(f"Cloning {repo_url} -> {clone_dir}")
        cmd = ["git", "clone"]
        if branch:
            cmd.extend(["--branch", branch, "--single-branch"])
        cmd.extend([repo_url, clone_dir])

        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if proc.returncode != 0:
            return {"ok": False, "repo_path": repo_url, "findings": [], "total_findings": 0, "critical": 0, "high": 0, "medium": 0, "error": f"git clone 失败: {proc.stderr[:500]}"}

        return scan_git_repo(clone_dir)

    except Exception as e:
        return {"ok": False, "repo_path": repo_url, "findings": [], "total_findings": 0, "critical": 0, "high": 0, "medium": 0, "error": str(e)}
