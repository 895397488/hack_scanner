#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Classifier — 漏洞分类器 + 误报过滤 + CVSS 评分。

源自: Pentest-Swarm-AI (https://github.com/Armur-Ai/Pentest-Swarm-AI)
from-source-of: Pentest-Swarm-AI

从 Go 源码 internal/agent/classifier/ 移植:
  - agent.go      -> classify/findings enrichment, batch processing
  - fp_filter.go  -> false positive probability scoring
  - scorer.go     -> CVSS v3.1 base score + severity mapping

Usage:
    from scanners.swarm_classifier import FPFilter, Scorer, ScoreToSeverity

    # 误报过滤
    f = FPFilter()
    if f.should_filter(finding):
        print("疑似误报，已过滤")

    # CVSS 评分
    scorer = Scorer()
    score = scorer.compute_base_score(components)
    severity = ScoreToSeverity(score)
"""

import math
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple


# ============================================================
# 枚举类型 (对应 pipeline.Severity / Confidence)
# ============================================================

class Severity(str, Enum):
    """漏洞严重等级"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFORMATIONAL = "informational"


class Confidence(str, Enum):
    """确认程度"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNVERIFIED = "unverified"


# ============================================================
# 数据结构 (对应 pipeline.RawFinding / ClassifiedFinding)
# ============================================================

@dataclass
class RawFinding:
    """原始漏洞发现，来源于扫描器输出"""
    id: str = ""                     # UUID or any identifier
    detail: str = ""                 # 发现描述文本
    raw_output: str = ""             # 原始输出内容
    type_: str = ""                  # 发现类型 (sqli, xss, open_port, ...)
    target: str = ""                 # 目标地址


@dataclass
class ClassifiedFinding:
    """分类后的漏洞发现"""
    title: str = ""
    description: str = ""
    cve_ids: List[str] = field(default_factory=list)
    cvss_score: float = 0.0
    cvss_vector: str = ""
    severity: Severity = Severity.MEDIUM
    attack_category: str = ""
    confidence: Confidence = Confidence.UNVERIFIED
    false_positive_probability: float = 0.0
    chain_candidates: List[str] = field(default_factory=list)


@dataclass
class ClassificationSummary:
    """分类摘要统计"""
    total_findings: int = 0
    by_severity: Dict[str, int] = field(default_factory=dict)
    top_categories: List[str] = field(default_factory=list)
    filtered_as_fp: int = 0


@dataclass
class ClassifiedFindingSet:
    """分类结果集合"""
    findings: List[ClassifiedFinding] = field(default_factory=list)
    summary: ClassificationSummary = field(default_factory=ClassificationSummary)


# ============================================================
# FPFilter — 误报过滤器 (fp_filter.go)
# ============================================================

class FPFilter:
    """误报概率评估器。

    基于启发式规则计算漏洞发现为误报的概率 (0.0~1.0)。
    当分数 > 0.75 时认为极大概率为误报，直接过滤。
    """

    def __init__(self):
        # 通用服务 banner（无版本号则标记为高误报）
        self._generic_banners = [
            "apache", "nginx", "iis", "lighttpd",
        ]
        # 已知服务名
        self._service_keywords = [
            "http", "https", "ssh", "ftp", "smtp", "mysql", "postgres",
            "redis", "mongodb", "dns", "telnet", "rdp",
        ]

    def score(self, finding: RawFinding) -> float:
        """计算误报概率，范围 0.0 (真实漏洞) ~ 1.0 (肯定是误报)。"""
        probability = 0.0
        detail_lower = finding.detail.lower()
        raw_output_lower = finding.raw_output.lower()

        # 规则1: 通用 server banner 且未包含版本号
        if self._contains_generic_banner(detail_lower):
            probability += 0.6

        # 规则2: open_port 发现但无服务信息
        if finding.type_ == "open_port" and not self._has_service_info(detail_lower):
            probability += 0.4

        # 规则3: 仅返回 4xx 状态码（未见到 200/302）
        if any(s in detail_lower for s in ["404", "403", "401"]):
            if not any(s in detail_lower for s in ["200", "302"]):
                probability += 0.5

        # 规则4: 版本不匹配（CVE mapped but version mismatch）
        if "version mismatch" in raw_output_lower or "not vulnerable" in raw_output_lower:
            probability += 0.7

        # 规则5: 非标准端口且无服务匹配
        if "non-standard port" in detail_lower and not self._has_service_info(detail_lower):
            probability += 0.3

        # 规则6: info 级别的发现倾向于噪声
        if "info" in finding.type_ or "informational" in detail_lower:
            probability += 0.2

        # 上限钳制
        return min(probability, 1.0)

    def should_filter(self, finding: RawFinding) -> bool:
        """若发现极大概率为误报，返回 True 以过滤。"""
        return self.score(finding) > 0.75

    # ---------- 内部辅助方法 ----------

    @staticmethod
    def _contains_generic_banner(text: str) -> bool:
        """检查文本是否包含通用 banner 但无版本号。"""
        for banner in ["apache", "nginx", "iis", "lighttpd"]:
            if banner in text and not FPFilter._has_version(text):
                return True
        return False

    @staticmethod
    def _has_version(text: str) -> bool:
        """检测文本中是否存在版本号模式（digit.digit）"""
        return bool(re.search(r'\d\.\d', text))

    def _has_service_info(self, text: str) -> bool:
        """检查文本是否包含已知服务名。"""
        return any(svc in text for svc in self._service_keywords)


# ============================================================
# CVSSComponents — CVSS v3.1 向量组件
# ============================================================

@dataclass
class CVSSComponents:
    """CVSS v3.1 向量各分量解析结果。"""
    attack_vector: str = ""              # N, A, L, P
    attack_complexity: str = ""          # L, H
    privileges_required: str = ""        # N, L, H
    user_interaction: str = ""           # N, R
    scope: str = ""                      # U, C
    confidentiality_impact: str = ""     # N, L, H
    integrity_impact: str = ""           # N, L, H
    availability_impact: str = ""        # N, L, H


@dataclass
class ScoringContext:
    """评分时的额外上下文信息。"""
    internet_facing: bool = False        # 是否面向互联网
    authentication_required: bool = False  # 是否需要认证
    exploit_available: bool = False      # 是否有现成 PoC/EXP


# ============================================================
# Scorer — CVSS v3.1 评分器 (scorer.go)
# ============================================================

class Scorer:
    """CVSS v3.1 评分引擎。

    完全按照 FIRST 官方规范实现 base score 计算公式，并支持
    基于环境上下分的 adjustments。

    用法:
        scorer = Scorer()
        components = scorer.parse_cvss_vector("AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H")
        base_score = scorer.compute_base_score(components)
        adj_score = scorer.adjust_for_context(base_score, ctx)
    """

    @staticmethod
    def parse_cvss_vector(vector: str) -> CVSSComponents:
        """解析 CVSS v3.1 向量字符串为组件对象。"""
        comp = CVSSComponents()
        for part in vector.split("/"):
            kv = part.split(":", 1)
            if len(kv) != 2:
                continue
            key, val = kv[0], kv[1]
            if key == "AV":
                comp.attack_vector = val
            elif key == "AC":
                comp.attack_complexity = val
            elif key == "PR":
                comp.privileges_required = val
            elif key == "UI":
                comp.user_interaction = val
            elif key == "S":
                comp.scope = val
            elif key == "C":
                comp.confidentiality_impact = val
            elif key == "I":
                comp.integrity_impact = val
            elif key == "A":
                comp.availability_impact = val

        if not comp.attack_vector:
            raise ValueError(f"无效的 CVSS 向量：缺少 AV 分量 — {vector!r}")
        return comp

    @staticmethod
    def compute_base_score(components: CVSSComponents) -> float:
        """根据 FIRST 规范计算 CVSS v3.1 基础分数。

        计算公式:
          ISS = 1 - (1-C)(1-I)(1-A)
          Impact = f(ISS, Scope)
          Exploitability = 8.22 * AV * AC * PR * UI
          BaseScore = round_up(f(Impact, Exploitability, Scope))
        """
        iss = 1.0 - (
            (1.0 - _impact_value(components.confidentiality_impact))
            * (1.0 - _impact_value(components.integrity_impact))
            * (1.0 - _impact_value(components.availability_impact))
        )

        if components.scope == "U":
            impact = 6.42 * iss
        else:
            impact = 7.52 * (iss - 0.029) - 3.25 * math.pow(iss - 0.02, 15)

        if impact <= 0:
            return 0.0

        exploitability = (
            8.22
            * _attack_vector_value(components.attack_vector)
            * _attack_complexity_value(components.attack_complexity)
            * _privileges_required_value(
                components.privileges_required, components.scope
            )
            * _user_interaction_value(components.user_interaction)
        )

        if components.scope == "U":
            score = min(impact + exploitability, 10.0)
        else:
            score = min(1.08 * (impact + exploitability), 10.0)

        return math.ceil(score * 10) / 10  # CVSS 规范要求向上取整到小数点后1位

    @staticmethod
    def adjust_for_context(base: float, ctx: ScoringContext) -> float:
        """根据环境上下文调整基础分数。"""
        score = base

        if ctx.internet_facing:
            score *= 1.15
        if ctx.authentication_required:
            score *= 0.8
        if ctx.exploit_available:
            score *= 1.2

        return round(max(0.0, min(score, 10.0)), 1)


# ============================================================
# 辅助函数（CVSS metric value lookup）
# ============================================================

def _attack_vector_value(av: str) -> float:
    """攻击向量值映射 (N=Network, Adjacent, Local, Physical)。"""
    return {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}.get(av, 0.85)


def _attack_complexity_value(ac: str) -> float:
    """攻击复杂度值映射 (L=Low, H=High)。"""
    return {"L": 0.77, "H": 0.44}.get(ac, 0.77)


def _privileges_required_value(pr: str, scope: str) -> float:
    """权限要求值映射 (受 Scope 影响)。"""
    if scope == "C":
        return {"N": 0.85, "L": 0.68, "H": 0.50}.get(pr, 0.85)
    return {"N": 0.85, "L": 0.62, "H": 0.27}.get(pr, 0.85)


def _user_interaction_value(ui: str) -> float:
    """用户交互值映射 (N=None, R=Required)。"""
    return {"N": 0.85, "R": 0.62}.get(ui, 0.85)


def _impact_value(impact: str) -> float:
    """影响值映射 (N=None, L=Low, H=High)。"""
    return {"H": 0.56, "L": 0.22, "N": 0}.get(impact, 0)


def score_to_severity(score: float) -> Severity:
    """将 CVSS 分数映射到严重等级。

    Critical: 9.0-10.0
    High:     7.0-8.9
    Medium:   4.0-6.9
    Low:      0.1-3.9
    Info:     0.0
    """
    if score >= 9.0:
        return Severity.CRITICAL
    if score >= 7.0:
        return Severity.HIGH
    if score >= 4.0:
        return Severity.MEDIUM
    if score > 0:
        return Severity.LOW
    return Severity.INFORMATIONAL


# ============================================================
# ClassifiedFindingSet 辅助方法 (来自 agent.go Classify)
# ============================================================

def classify_finding_set(
    raw_findings: List[RawFinding],
    fp_filter: Optional[FPFilter] = None,
) -> ClassifiedFindingSet:
    """对原始发现进行分类、过滤和评分。

    对应 Go agent.go Classify() 的主流程:
      1. FPFilter.ShouldFilter 过滤高误报发现
      2. 对所有通过过滤的发现构建 ClassifiedFinding 骨架
      3. (LLM enrichment 由调用方注入)
      4. 按 CVSS 分数降序排序
      5. 生成摘要统计

    Args:
        raw_findings: 原始扫描发现列表
        fp_filter: 误报过滤器（未指定则自动创建默认实例）

    Returns:
        ClassifiedFindingSet，包含分类结果与摘要。
    """
    if fp_filter is None:
        fp_filter = FPFilter()

    classified: List[ClassifiedFinding] = []
    filtered_count = 0

    for raw in raw_findings:
        # 误报过滤
        if fp_filter.should_filter(raw):
            filtered_count += 1
            continue

        fp_prob = fp_filter.score(raw)

        classified.append(ClassifiedFinding(
            title=raw.detail,
            description=raw.detail,
            severity=Severity.MEDIUM,       # LLM enrichment 后更新
            confidence=Confidence.UNVERIFIED,
            false_positive_probability=fp_prob,
            target=raw.target,
        ))

    # 按 CVSS 分数降序排序
    classified.sort(key=lambda f: f.cvss_score, reverse=True)

    # 构建摘要统计
    by_severity: Dict[str, int] = {}
    category_count: Dict[str, int] = {}
    for f in classified:
        by_severity[f.severity.value] = by_severity.get(f.severity.value, 0) + 1
        if f.attack_category:
            category_count[f.attack_category] = category_count.get(f.attack_category, 0) + 1

    # Top 5 类别按计数降序
    top_categories = sorted(category_count.keys(), key=lambda c: category_count[c], reverse=True)[:5]

    return ClassifiedFindingSet(
        findings=classified,
        summary=ClassificationSummary(
            total_findings=len(classified),
            by_severity=by_severity,
            top_categories=top_categories,
            filtered_as_fp=filtered_count,
        ),
    )


# ============================================================
# 自检（模块直接运行时可快速验证）
# ============================================================

if __name__ == "__main__":
    import uuid as _uuid

    # ---- 误报过滤测试 ----
    print("=== FPFilter 测试 ===")
    fp = FPFilter()
    findings = [
        RawFinding(
            id=str(_uuid.uuid4()),
            detail="Apache is running",          # generic banner, no version → high FP prob
            type_="service_banner",
        ),
        RawFinding(
            id=str(_uuid.uuid4()),
            detail="SQL injection in ?id= parameter",  # real vuln → low FP prob
            type_="sqli",
        ),
        RawFinding(
            id=str(_uuid.uuid4()),
            detail="Port 80 open on 10.0.0.1",   # open_port no service info
            type_="open_port",
        ),
        RawFinding(
            id=str(_uuid.uuid4()),
            detail="GET /admin → 404 Not Found",  # only 4xx → FP
            type_="endpoint_probe",
            raw_output="",
        ),
    ]
    for f in findings:
        prob = fp.score(f)
        filtered = fp.should_filter(f)
        print(f"  [{filtered}] {f.detail[:50]:50s}  FP={prob:.2f}")

    # ---- CVSS 评分测试 ----
    print("\n=== Scorer 测试 ===")
    scorer = Scorer()
    vec = "AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"  # 10.0
    comp = scorer.parse_cvss_vector(vec)
    base = scorer.compute_base_score(comp)
    print(f"  Vector: {vec}")
    print(f"  Base Score: {base}")
    print(f"  Severity: {score_to_severity(base).value}")

    # Medium vector
    vec2 = "AV:L/AC:H/PR:N/UI:N/S:C/C:L/I:N/A:N"
    comp2 = scorer.parse_cvss_vector(vec2)
    base2 = scorer.compute_base_score(comp2)
    print(f"\n  Vector: {vec2}")
    print(f"  Base Score: {base2}")
    print(f"  Severity: {score_to_severity(base2).value}")

    # ---- Context adjustment test ----
    ctx = ScoringContext(internet_facing=True, exploit_available=True)
    adj = scorer.adjust_for_context(base, ctx)
    print(f"\n  Base={base} → internet-facing + exploit available: {adj}")
