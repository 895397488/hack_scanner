# from-source-of: Pentest-Swarm-AI (internal/agent/report/dedup/)
# 发现去重模块 — 使用 Jaccard 相似度对漏洞发现进行聚类
"""
发现去重器。
核心算法源自 Pentest-Swarm-AI 的 dedup/dedup.go：
  - token-set Jaccard similarity with stopword removal
  - title + target boost
  - content hash for URL-level dedup

此外还实现了基于 SimHash 的 content similarity clustering（对应原文中提到的
similarity hash cluster）。
"""

import hashlib
import math
import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# 停用词表 (对应 Go stopwords map)
# ---------------------------------------------------------------------------

STOPWORDS = frozenset({
    "a", "an", "and", "at", "by", "for", "in", "is", "it", "of",
    "on", "or", "the", "to", "via", "with", "through", "this", "that",
    "from", "be", "can", "do", "if", "not", "or", "so", "up", "we",
})


# ---------------------------------------------------------------------------
# 数据类型
# ---------------------------------------------------------------------------

@dataclass
class PriorFinding:
    """历史发现的记录（用于对比去重）"""
    id: str = ""
    title: str = ""
    target: str = ""      # 可选，如果匹配则提升相似度
    state: str = ""        # "duplicate" | "resolved" | "open"


@dataclass
class DuplicateMatch:
    """去重匹配结果"""
    prior: PriorFinding
    similarity: float      # 0.0 - 1.0
    match_type: str = "title_jaccard"  # title_jaccard | content_hash | url_match


@dataclass
class Finding:
    """待去重的发现记录"""
    id: str = ""
    title: str = ""
    target: str = ""       # URL / IP / host
    description: str = ""
    severity: str = "info"
    http_request: str = ""  # 用于 content hash
    url_params: str = ""    # URL 参数


# ---------------------------------------------------------------------------
# Jaccard 相似度去重 (对应 dedup.go FindDuplicates)
# ---------------------------------------------------------------------------

def _tokenise(text: str) -> Set[str]:
    """
    分词：转小写、按非字母数字分割、去除停用词。
    对应 Go tokenise() 函数。
    """
    tokens = set()
    cur = []
    for ch in text.lower():
        if ch.isalnum():
            cur.append(ch)
        else:
            if cur:
                word = ''.join(cur)
                if len(word) >= 2 and word not in STOPWORDS:
                    tokens.add(word)
                cur = []
    if cur:
        word = ''.join(cur)
        if len(word) >= 2 and word not in STOPWORDS:
            tokens.add(word)
    return tokens


def _jaccard(a: Set[str], b: Set[str]) -> float:
    """
    Jaccard 相似度 = |A ∩ B| / |A ∪ B|
    1.0 = 完全相同, 0.0 = 完全不相交。
    对应 Go jaccard() 函数。
    """
    if not a and not b:
        return 0.0

    intersection = len(a & b)
    union = len(a | b)

    if union == 0:
        return 0.0

    return float(intersection) / float(union)


def find_duplicates(title: str, target: str, priors: List[PriorFinding],
                    threshold: float = 0.6, top_k: int = 3) -> List[DuplicateMatch]:
    """
    在历史发现中查找与当前发现相似（可能是重复）的记录。

    算法源自 dedup.go FindDuplicates():
      - 使用 token-set Jaccard 相似度
      - target 匹配时提升相似度 (1.0 - (1-sim)*0.5)
      - threshold 默认 0.6 — 标题有 60%+ 词重叠通常就是同一个漏洞

    Args:
        title:     当前发现的标题
        target:    当前发现的目标 URL/host
        priors:    历史发现列表（已提交的报告等）
        threshold: 相似度阈值（默认 0.6）
        top_k:     最多返回前 K 个匹配

    Returns:
        DuplicateMatch 列表，按相似度降序排列
    """
    if threshold <= 0:
        threshold = 0.6
    if top_k <= 0:
        top_k = 3

    tokens = _tokenise(title)
    hits: List[DuplicateMatch] = []

    for p in priors:
        # Jaccard 相似度
        sim = _jaccard(tokens, _tokenise(p.title))

        # target 匹配时提升相似度 — 强信号
        if target and p.target and target.lower() == p.target.lower():
            sim = 1.0 - (1.0 - sim) * 0.5

        if sim >= threshold:
            hits.append(DuplicateMatch(
                prior=p,
                similarity=sim,
                match_type="title_jaccard",
            ))

    # 简单排序（这里数据量极小，几十条而已）
    hits.sort(key=lambda m: m.similarity, reverse=True)

    return hits[:top_k]


# ---------------------------------------------------------------------------
# Content hash (similarity hash) 聚类 (SimHash-like fingerprinting)
# ---------------------------------------------------------------------------

def _content_hash(http_request: str, url: str = "") -> str:
    """
    生成内容的指纹 hash（minihash/SimHash 简化版）。
    用于 URL+参数级别的去重。
    """
    # 规范化输入：移除多余空白，统一分隔符
    text = (http_request + " " + url).strip()
    text = re.sub(r'\s+', ' ', text)
    return hashlib.md5(text.encode('utf-8')).hexdigest()


def _simhash(text: str, hash_bits: int = 64) -> int:
    """
    SimHash 实现 — 用于生成文本的感知哈希。
    两个相似的文本会生成非常接近的哈希值（Hamming 距离小）。

    简化版：将文本分词后对每个词做 hash，然后按位累加向量。
    """
    if not text:
        return 0

    tokens = _tokenise(text)
    if not tokens:
        return 0

    # 初始化零向量
    vector = [0] * hash_bits

    for token in tokens:
        # 对每个词做哈希，得到 hash_bits 位的结果
        h = hashlib.md5(token.encode('utf-8')).digest()
        for i in range(hash_bits):
            bit_idx = (i * 4) % len(h)
            byte_val = h[bit_idx]
            if (byte_val >> (i % 8)) & 1:
                vector[i] += 1
            else:
                vector[i] -= 1

    # 将向量转为整数哈希值
    result = 0
    for i, val in enumerate(vector):
        if val >= 0:
            result |= (1 << i)

    return result


def _hamming_distance(h1: int, h2: int, bits: int = 64) -> int:
    """计算两个 SimHash 值的 Hamming 距离"""
    xor = h1 ^ h2
    count = 0
    while xor:
        count += xor & 1
        xor >>= 1
    return count


def _simhash_similarity(h1: int, h2: int, bits: int = 64) -> float:
    """将 Hamming 距离转为相似度 (0.0-1.0)"""
    if h1 == 0 and h2 == 0:
        return 0.0
    dist = _hamming_distance(h1, h2, bits)
    # 相似度 = 1 - (距离 / 位数)，允许负值截断到 0
    return max(0.0, 1.0 - dist / bits)


def deduplicate_by_context(findings: List[Finding], threshold: float = 0.85) -> List[List[int]]:
    """
    基于 SimHash content similarity 聚类发现的重复项。

    算法流程：
      1. 为每条发现计算 SimHash
      2. 两两比较 Hamming 距离
      3. 相似度 >= threshold 的归为一组

    Args:
        findings: 待去重的发现列表
        threshold: 相似度阈值（默认 0.85）

    Returns:
        聚类结果：每个元素是一组重复发现的索引列表
    """
    if not findings:
        return []

    # Step 1: 计算所有 SimHash
    hashes = []
    for f in findings:
        text = f.title + " " + f.description + " " + (f.url_params or "")
        h = _simhash(text)
        hashes.append(h)

    # Step 2: 构建相似度矩阵并聚类
    clusters: List[List[int]] = []
    used = set()

    for i in range(len(findings)):
        if i in used:
            continue

        cluster = [i]
        used.add(i)

        for j in range(i + 1, len(findings)):
            if j in used:
                continue

            sim = _simhash_similarity(hashes[i], hashes[j])
            if sim >= threshold:
                cluster.append(j)
                used.add(j)

        if len(cluster) > 1:
            clusters.append(sorted(cluster))

    return clusters


def findings_dedup(findings: List[Finding], url_threshold: float = 0.85,
                   title_threshold: float = 0.6) -> List[Finding]:
    """
    综合去重：URL-level content hash + Title Jaccard。

    去重策略（双层）：
      Layer 1 (URL): 相同 URL+参数，content hash >= url_threshold → 重复
      Layer 2 (Title): 标题 Jaccard >= title_threshold 且 target 匹配 → 可能重复

    Args:
        findings:       发现列表
        url_threshold:  URL-level 去重阈值
        title_threshold: Title-level 去重阈值

    Returns:
        去重后的发现列表（保留每组中严重等级最高的）
    """
    if len(findings) <= 1:
        return list(findings)

    # Layer 1: URL/Content hash 去重
    url_hashes = {}  # content_hash -> index of first occurrence
    kept_indices = set()

    for i, f in enumerate(findings):
        chash = _content_hash(f.http_request, f.target)
        found = False
        for existing_hash, idx in url_hashes.items():
            if chash == existing_hash:
                # 完全相同的 content hash → 直接标记为重复
                if idx not in kept_indices:
                    kept_indices.add(idx)
                found = True
                break

        if not found:
            url_hashes[chash] = i
            kept_indices.add(i)

    # Layer 2: 对 Layer 1 保留的发现再做 title Jaccard 去重
    remaining = [findings[i] for i in sorted(kept_indices)]
    final_kept: List[Finding] = []

    for f in remaining:
        is_dup = False
        for existing in final_kept:
            sim = _jaccard(_tokenise(f.title), _tokenise(existing.title))

            # target 匹配时提升相似度
            if f.target and existing.target and f.target.lower() == existing.target.lower():
                sim = 1.0 - (1.0 - sim) * 0.5

            if sim >= title_threshold:
                is_dup = True
                break

        if not is_dup:
            final_kept.append(f)

    return final_kept


# ---------------------------------------------------------------------------
# 便捷函数 — 直接从 findings 列表中去除重复项
# ---------------------------------------------------------------------------

def dedup_findings(findings_list: List[dict], key_field: str = "target") -> list:
    """
    简单的基于字段的去重（对应 recon/parser.go MergeToolResults 的去重逻辑）。

    Args:
        findings_list: 发现字典列表（每个必须有 key_field）
        key_field:     用于判重的字段名

    Returns:
        去重后的列表
    """
    seen = set()
    result = []

    for f in findings_list:
        key = str(f.get(key_field, ""))
        if key and key not in seen:
            seen.add(key)
            result.append(f)

    return result


def dedup_findings_by_context(findings_list: List[dict], threshold: float = 0.85) -> dict:
    """
    基于上下文的去重，返回去重结果和重复组。

    Args:
        findings_list: 发现字典列表
        threshold:     相似度阈值

    Returns:
        {
            "deduplicated": list,      # 去重后的发现
            "duplicate_groups": list,  # 每组重复项的索引
            "total_deduped": int,      # 移除的重复数量
        }
    """
    # 先转成 Finding 对象
    findings = []
    for f in findings_list:
        findings.append(Finding(
            id=f.get("id", ""),
            title=f.get("title", ""),
            target=f.get("target", f.get("url", "")),
            description=f.get("description", ""),
            severity=f.get("severity", "info"),
            http_request=f.get("http_request", ""),
            url_params=f.get("url_params", ""),
        ))

    clusters = deduplicate_by_context(findings, threshold)

    # 从每组中保留第一个（通常是最详细的那个）
    dup_indices = set()
    for cluster in clusters:
        for idx in cluster[1:]:  # 保留第一个，其余标记为重复
            dup_indices.add(idx)

    total_duped = len(dup_indices)
    deduped = [f for i, f in enumerate(findings_list) if i not in dup_indices]

    return {
        "deduplicated": deduped,
        "duplicate_groups": clusters,
        "total_deduped": total_duped,
    }
