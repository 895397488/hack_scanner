#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AcuSensor-Style Sensor — 主动式WAF感知与目标加固检测

借鉴 Acunetix AcuSensor 多语言部署概念，实现 Python/PHP/JAR 感测器的等效功能。
通过主动注入感测参数和分析响应来探测目标防护机制。

核心能力：
- WAF 深度探测（基于特征响应和延迟差异）
- 敏感头注入测试（判断是否过滤/修改请求头）
- Cookie 注入检测（检测 WAF 对 Cookie 的篡改行为）
- 参数污染与拦截分析
- 目标应用层监控（通过响应指纹推断服务器组件）

Usage:
    from scanners.acusensor_sensor import AcusensorSensor
    sensor = AcusensorSensor()
    result = sensor.detect("https://example.com")
"""

import json
import re
import time
import hashlib
import logging
from typing import Dict, List, Optional, Any
from urllib.parse import urlparse, urlencode

import requests

logger = logging.getLogger('acusensor_sensor')


class AcusensorSensor:
    """主动式 Web 应用传感器 — 探测 WAF、IPS、CDN 防护机制"""

    # WAF 特征响应模式（基于 Acunetix WAF fingerprint 库）
    WAF_SIGNATURES = {
        'Cloudflare': [r'cloudflare-nginx', r'cf-ray', r'__cfduid', r'CloudFlare'],
        'Akamai': [r'sdkc=', r'sdkts=', r'akib_', r'ak_bmsc='],
        'Imperva/SiteLock': [r'_incog_session', r'SL_ICE', r'SITELOCK', r'imwps='],
        'F5 BIG-IP': [r'bigipserver', r'TM_CMMR_ID', r'ASPIDs='],
        'AWS WAF': [r'awselasticloadbalancing', r'_awswaf', r'AWSELB'],
        'ModSecurity': [r'mod_security', r'MOD_SECURITY', r'modsedna=', r'Rejected-By-modsecurity'],
        'Nginx WAF': [r'nginx/.*waf', r'nginx-waf'],
        'Squarespace WAF': [r'SQUARESPACE_WAF'],
        'Google Cloud Armor': [r'x-goog-*', r'googbase64'],
        'Aliyun CDN/WAF': [r'aliyuncs', r'_acw_tc', r'wafcloud'],
        'Qianxin WAF': [r'redirect_url=.*?waf', r'qax_waf'],
        'Baidu WAF': [r'baiduyun', r'waf.*baidu', r'scan.*baidu'],
        'Tencent Cloud WAF': [r'tencent.*waf', r'TencentCloud'],
        'Safedog': [r'SafeDog', r'safedog', r'scd_url='],
        '360 WAF': [r'wzws-waf-captcha', r'WZWS-Ray', r'360wzws'],
        'UCloud WAF': [r'ucloud.*waf', r'UWAF'],
        'ChinaNetcenter': [r'_cncc_', r'chinanetcenter'],
        'Anquanbao': [r'aq_bypass=', r'anquanbao'],
        'Venustech': [r'venustech', r'vtech.*waf'],
        'DigitalGuardian': [r'digital.guards', r'DigitalGurad'],
        'Yundun': [r'yundun', r'yd_danger', r'YUNDUN'],
    }

    # Cookie/响应篡改检测特征（WAF 通常会修改 cookie）
    TAMPER_INDICATORS = {
        'Akamai': [r'^BM*', r'_abck'],       # Akamai BM* cookies
        'Cloudflare': [r'cf_*', r'__cfuid'],   # Cloudflare cookies
        'F5 BIG-IP': [r'tmToken', r'TMSH'],
        'Imperva': [r'_incog_', r'_impexp_'],
        'Radware': [r'crva_session', r'crva_ba'],
        'NevisProxy': [r'NAVJSID='],
    }

    # 敏感头注入测试列表（探测 WAF 是否拦截/修改特定头部）
    SENSITIVE_HEADERS = {
        'X-Forwarded-For': ['127.0.0.1', '0.0.0.0', '::1'],
        'X-Originating-IP': ['127.0.0.1', '0.0.0.0'],
        'X-Real-IP': ['127.0.0.1'],
        'True-Client-IP': ['127.0.0.1'],
        'X-Cluster-Client-IP': ['127.0.0.1', '10.0.0.1'],
        'Forwarded': ['for=127.0.0.1', 'for="[::1]"'],
        'Via': ['1.1 waf-proxy', '1.0 suspicious'],
        'X-WAF-Blocked': ['true', 'blocked'],
        'X-Anti-Flood': ['true', 'system_uptime'],
        'User-Agent': [
            'sqlmap/1.8',       # SQL 注入工具
            'nikto/2.5',         # 扫描器
            'Acunetix-Product',  # Acunetix
            'Nessus',            # 漏洞扫描器
            'ZAP/2.14',          # OWASP ZAP
            'w3af.org/fuzzers',  # w3af
        ],
    }

    def __init__(self, timeout: int = 15):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.verify = False  # 关闭 SSL 证书验证（避免 Windows CA 根证书缺失）
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) HackScanner/AcuSensor/2.0',
            'Accept': '*/*',
        })

    def detect(self, url: str) -> Dict[str, Any]:
        """执行完整的 Acunetix 风格传感器探测。

        Args:
            url: 目标 URL

        Returns:
            {
                "ok": True/False,
                "target": "...",
                "wafs_detected": [...],
                "cdn_detected": {...},
                "header_filtering": [...],
                "cookie_tampering": [...],
                "sensor_bypass_possible": True/False,
                "sensitive_params_injected": [...],
                "server_fingerprint": {...},
                "error": ""
            }
        """
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        parsed = urlparse(url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"
        result = {
            'ok': True,
            'target': url,
            'wafs_detected': [],
            'cdn_detected': {},
            'header_filtering': [],
            'cookie_tampering': [],
            'sensor_bypass_possible': False,
            'sensitive_params_injected': [],
            'server_fingerprint': {},
            'error': '',
        }

        try:
            # === 1. WAF 深度探测（响应头 + Cookie + Body 指纹）===
            wafs = self._probe_waf(url)
            result['wafs_detected'] = list(set(wafs))  # 去重

            # === 2. CDN 检测 ===
            cdn = self._detect_cdn(url)
            result['cdn_detected'] = cdn

            # === 3. 敏感头注入检测（WAF 是否过滤/篡改）===
            header_filters = self._test_header_injection(url)
            result['header_filtering'] = header_filters

            # === 4. Cookie 篡改检测 ===
            cookie_tamper = self._test_cookie_injection(url)
            result['cookie_tampering'] = cookie_tamper

            # === 5. 参数注入探测（模拟 AcuSensor 探针）===
            params_injected = self._test_parameter_sensors(url)
            result['sensitive_params_injected'] = params_injected

            # === 6. 服务器指纹识别 ===
            fingerprint = self._fingerprint_server(url)
            result['server_fingerprint'] = fingerprint

            # === 7. 传感器绕过可能性评估 ===
            result['sensor_bypass_possible'] = self._assess_bypass(wafs, header_filters)

        except Exception as e:
            logger.error(f"AcuSensor 探测失败: {e}")
            result['ok'] = False
            result['error'] = str(e)

        return result

    def _probe_waf(self, url: str) -> List[str]:
        """通过响应头、Cookie 和 Body 指纹探测 WAF"""
        detected = set()

        # 发送测试请求
        try:
            resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)
        except requests.RequestException as e:
            logger.warning(f"WAF 探测请求失败: {e}")
            return list(detected)

        headers_lower = {k.lower(): v for k, v in resp.headers.items()}
        body_lower = resp.text[:5000].lower()
        set_cookie = resp.headers.get('Set-Cookie', '')
        all_cookies = f"{set_cookie} {resp.cookies.get_dict()}"

        # 检测响应头指纹
        for waf_name, signatures in self.WAF_SIGNATURES.items():
            for sig in signatures:
                if re.search(sig, str(headers_lower), re.IGNORECASE) or \
                   re.search(sig, body_lower, re.IGNORECASE):
                    detected.add(waf_name)
                    break

        # 检测 Set-Cookie 指纹（WAF 常注入特定 cookie）
        for waf_name, indicators in self.TAMPER_INDICATORS.items():
            for ind in indicators:
                if re.search(ind, set_cookie, re.IGNORECASE):
                    detected.add(waf_name)
                    break

        # === 特殊探测：发送恶意 User-Agent 看是否被拦截/修改 ===
        malicious_agents = [
            ('sqlmap', 'SQL注入'),
            ('nikto', '扫描器'),
            ('Acunetix', 'Web扫描器'),
            ('nessus', '漏洞扫描器'),
        ]

        blocked_by_waf = False
        normal_resp = None

        for agent_name, purpose in malicious_agents:
            self.session.headers['User-Agent'] = f'{agent_name}/1.0 (HackScanner Probe)'
            try:
                resp_malicious = self.session.get(url, timeout=self.timeout, allow_redirects=True)
            except requests.RequestException:
                blocked_by_waf = True
                detected.add('WAF-Interceptor')
                continue

            # 比较响应差异（状态码或Body长度）
            if normal_resp is None:
                self.session.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Normal'
                try:
                    normal_resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)
                except requests.RequestException:
                    pass

            if normal_resp and abs(len(resp_malicious.text) - len(normal_resp.text)) > 500:
                # 响应长度差异超过500字节 → WAF可能拦截/修改了响应
                detected.add('WAF-Response-Manipulation')
                blocked_by_waf = True

            if resp_malicious.status_code in (403, 429, 503):
                detected.add(f'WAF-Blocked({agent_name})')
                blocked_by_waf = True

        self.session.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) HackScanner/AcuSensor/2.0'

        if blocked_by_waf:
            detected.add('WAF-Interceptor')

        return list(detected)

    def _detect_cdn(self, url: str) -> Dict[str, Any]:
        """检测 CDN 服务"""
        cdn_info = {
            'is_cdn': False,
            'cdn_providers': [],
            'edge_ips': [],
        }

        try:
            resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)
        except requests.RequestException:
            return cdn_info

        headers_lower = {k.lower(): v for k, v in resp.headers.items()}

        cdn_headers = {
            'CF-RAY': 'Cloudflare',
            'X-Cache': ['Cloudflare', 'Akamai', 'Fastly'],
            'X-CDN': None,
            'X-Edge-IP': None,
            'Via': 'CDN-Via',
            'X-Src-Upstream': 'CDN-Hop',
            'Server-Timing': 'CDN-Metric',
        }

        for hdr, provider in cdn_headers.items():
            val = headers_lower.get(hdr.lower(), '')
            if val:
                if provider is None:
                    cdn_info['cdn_providers'].append(f'Custom:{hdr}')
                else:
                    cdn_info['cdn_providers'].append(provider)

        # 检测 IP 是否为已知 CDN 段（通过响应头中的 X-Forwarded-For 链判断）
        xff = headers_lower.get('x-forwarded-for', '')
        if xff and ',' in xff:
            ips = [ip.strip() for ip in xff.split(',')]
            if len(ips) > 1:
                cdn_info['is_cdn'] = True
                cdn_info['edge_ips'] = ips[:-1]  # 倒数第一个是真实源站

        return cdn_info

    def _test_header_injection(self, url: str) -> List[Dict]:
        """测试 WAF 是否拦截/修改特定请求头"""
        filters = []

        for header_name, test_values in self.SENSITIVE_HEADERS.items():
            for test_val in test_values[:2]:  # 每个头只测前2个值
                self.session.headers[header_name] = test_val
                try:
                    resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)

                    # 检查响应是否被拦截
                    if resp.status_code in (403, 429, 503):
                        filters.append({
                            'header': header_name,
                            'value': test_val,
                            'blocked': True,
                            'status_code': resp.status_code,
                            'type': 'WAF-Block',
                        })

                    # 检查响应头是否被篡改（原始值 vs 修改后）
                    resp_hdr_val = resp.headers.get(header_name, '')
                    if resp_hdr_val and resp_hdr_val != test_val:
                        filters.append({
                            'header': header_name,
                            'injected_value': test_val,
                            'returned_value': resp_hdr_val,
                            'blocked': False,
                            'type': 'WAF-Mangle',
                        })

                except requests.RequestException:
                    filters.append({
                        'header': header_name,
                        'value': test_val,
                        'blocked': True,
                        'type': 'Connection-Reset',
                    })

        self.session.headers.pop('X-Forwarded-For', None)
        self.session.headers.pop('X-Originating-IP', None)
        self.session.headers.pop('X-Real-IP', None)
        self.session.headers.pop('True-Client-IP', None)
        self.session.headers.pop('X-Cluster-Client-IP', None)
        self.session.headers.pop('Forwarded', None)
        self.session.headers.pop('Via', None)
        self.session.headers.pop('X-WAF-Blocked', None)
        self.session.headers.pop('X-Anti-Flood', None)

        return filters

    def _test_cookie_injection(self, url: str) -> List[Dict]:
        """测试 WAF 是否篡改 Cookie"""
        tamper_results = []

        test_cookies = {
            'hackscanner_test': '<script>alert(1)</script>',   # XSS payload
            'xss_test': ';alert(1)',                              # JS semicolon
            'cmd_test': '|cat /etc/passwd',                       # 命令注入
            'sqli_test': "' OR 1=1 --",                            # SQLi
        }

        for cookie_name, cookie_val in test_cookies.items():
            self.session.cookies.set(cookie_name, cookie_val)
            try:
                resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)

                # 检查返回的 Set-Cookie 是否被 WAF 修改
                set_cookie = resp.headers.get('Set-Cookie', '')
                if cookie_name in set_cookie:
                    # Cookie 值被 WAF 篡改（安全行为）
                    original_len = len(cookie_val)
                    waf_len = 0
                    start = set_cookie.find(cookie_name + '=')
                    if start >= 0:
                        end = set_cookie.find(';', start)
                        if end < 0:
                            end = len(set_cookie)
                        waf_val = set_cookie[start + len(cookie_name) + 1:end]
                        waf_len = len(waf_val)

                    if waf_len != original_len or set_cookie[start:].find(cookie_val) == -1:
                        tamper_results.append({
                            'cookie': cookie_name,
                            'injected_value': cookie_val,
                            'waf_modified': True,
                            'type': 'XSS-Cookie-Tamper' if '<' in cookie_val or '>' in cookie_val else 'Injection-Tamper',
                        })

            except requests.RequestException:
                pass

            self.session.cookies.clear()
            self.session.cookies.set_cookie(requests.cookies.create_cookie(cookie_name, ''))

        return tamper_results

    def _test_parameter_sensors(self, url: str) -> List[Dict]:
        """模拟 AcuSensor 探针参数注入"""
        injected = []

        # AcuSensor 风格的探测参数
        sensor_params = {
            'acunetix_wvs_security_test': 'true',          # Acunetix 探针标记
            'hack_sensor_probe': '<script>probe</script>',   # XSS 探针
            'cmd_inject_test': ';id;whoami;',               # 命令注入探针
            'sqli_test': "' OR '1'='1'",                      # SQLi 探针
            'path_traversal': '../../etc/passwd',            # LFI 探针
        }

        parsed = urlparse(url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        for param_name, param_val in sensor_params.items():
            test_url = f"{base_url}{parsed.path}?{param_name}={param_val}"
            if parsed.query:
                test_url += f"&{parsed.query}"

            try:
                resp = self.session.get(test_url, timeout=self.timeout, allow_redirects=True)

                # 检测响应是否包含探针输出（说明未被 WAF 拦截）
                body_lower = resp.text.lower()

                probe_detected = False
                probe_type = ''

                if 'acunetix' in param_val.lower() or 'hack_sensor' in param_val.lower():
                    if 'probe' in body_lower or 'script' in body_lower:
                        # 响应中包含脚本内容 → XSS 可能未被过滤
                        if '<script>' in resp.text:
                            probe_detected = True
                            probe_type = 'XSS-Unfiltered'

                if ';id;' in param_val or ';whoami' in param_val:
                    if resp.status_code == 200 and ('uid=' in body_lower or 'groups=' in body_lower):
                        # 可能是命令执行结果回显
                        probe_detected = True
                        probe_type = 'Command-Injected'

                if not probe_detected:
                    probe_detected = False
                    probe_type = 'Blocked-or-Ignored'

                injected.append({
                    'param': param_name,
                    'value': param_val[:50],  # 截断避免过大
                    'probe_detected': probe_detected,
                    'probe_type': probe_type,
                    'status_code': resp.status_code,
                    'blocked_by_waf': resp.status_code in (403, 429),
                })

            except requests.RequestException:
                injected.append({
                    'param': param_name,
                    'value': param_val[:50],
                    'probe_detected': False,
                    'probe_type': 'Request-Failed',
                    'blocked_by_waf': True,
                })

        return injected

    def _fingerprint_server(self, url: str) -> Dict[str, Any]:
        """服务器技术栈指纹识别"""
        fingerprint = {
            'web_server': '',
            'framework': '',
            'programming_language': '',
            'cdn': '',
            'os_guess': '',
        }

        try:
            resp = self.session.get(url, timeout=self.timeout, allow_redirects=True)
        except requests.RequestException:
            return fingerprint

        headers_lower = {k.lower(): v for k, v in resp.headers.items()}

        # Web 服务器识别
        server_hdr = headers_lower.get('server', '')
        if 'nginx' in server_hdr:
            fingerprint['web_server'] = 'Nginx'
        elif 'apache' in server_hdr:
            fingerprint['web_server'] = 'Apache'
        elif 'iis' in server_hdr or 'mswin64' in server_hdr:
            fingerprint['web_server'] = 'IIS'
        elif 'caddy' in server_hdr:
            fingerprint['web_server'] = 'Caddy'
        elif 'cloudflare' in server_hdr:
            fingerprint['web_server'] = 'Cloudflare-Edge'
        elif 'openresty' in server_hdr:
            fingerprint['web_server'] = 'OpenResty'
        elif 'tomcat' in server_hdr:
            fingerprint['web_server'] = 'Tomcat'

        # 框架/语言识别
        xpowered = headers_lower.get('x-powered-by', '')
        if 'express' in xpowered.lower():
            fingerprint['framework'] = 'Express.js'
            fingerprint['programming_language'] = 'JavaScript'
        elif 'django' in xpowered.lower() or 'djangosaml2' in xpowered.lower():
            fingerprint['framework'] = 'Django'
            fingerprint['programming_language'] = 'Python'
        elif 'flask' in xpowered.lower():
            fingerprint['framework'] = 'Flask'
            fingerprint['programming_language'] = 'Python'
        elif 'spring' in xpowered.lower() or 'javafx' in xpowered.lower():
            fingerprint['framework'] = 'Spring Boot'
            fingerprint['programming_language'] = 'Java'
        elif 'php' in xpowered.lower():
            fingerprint['programming_language'] = 'PHP'
        elif 'laravel' in xpowered.lower():
            fingerprint['framework'] = 'Laravel'
            fingerprint['programming_language'] = 'PHP'

        # 从响应体识别技术栈
        body_lower = resp.text.lower()

        framework_body_patterns = {
            ('wordpress', 'PHP'): ['wp-content', 'wp-includes', 'wp-json'],
            ('drupal', 'PHP'): ['/sites/default/', 'Drupal.settings'],
            ('joomla', 'PHP'): ['JFactory', 'Joomla'],
            ('django', 'Python'): ['csrfmiddlewaretoken', 'Django administration'],
            ('laravel', 'PHP'): ['XSRF-TOKEN', 'laravel_session'],
            ('spring', 'Java'): ['Whitelabel Error', '/error'],
        }

        for fw, lang in framework_body_patterns.items():
            if all(kw in body_lower for kw in fw[1:]):
                fingerprint['framework'] = fw[0]
                fingerprint['programming_language'] = lang
                break

        # CDN 检测
        cf_ray = headers_lower.get('cf-ray', '')
        akamai_hdr = headers_lower.get('x-akamai-transformed', '')
        if cf_ray:
            fingerprint['cdn'] = 'Cloudflare'
        elif akamai_hdr:
            fingerprint['cdn'] = 'Akamai'

        return fingerprint

    def _assess_bypass(self, wafs: List[str], header_filters: List[Dict]) -> bool:
        """评估传感器绕过可能性"""
        # 如果 WAF 已识别且没有头部过滤 → 难绕过
        if any('WAF-Interceptor' in w for w in wafs) and not header_filters:
            return False

        # 如果有头部过滤但仅针对恶意 UA → 可用正常 UA 绕过
        has_uaf_filter = any(f.get('type') == 'WAF-Block' and f.get('header') == 'User-Agent'
                            for f in header_filters)
        if has_uaf_filter:
            # WAF 只拦截了恶意 UA，正常请求可以通过 → 部分绕过可能
            return True

        # 没有任何过滤 → 传感器可能未被部署
        if not wafs and not header_filters:
            return True

        return False


class SensorBridge:
    """传感器桥接器 — 模拟 AcuSensor sensor-bridge.exe 的代理/中间层功能"""

    @staticmethod
    def analyze_response_intercept(url: str, resp: requests.Response) -> Dict[str, Any]:
        """分析响应中的潜在拦截点（类似 sensor-bridge.exe 的分析逻辑）"""
        intercepts = {
            'blocked_requests': [],
            'modified_headers': [],
            'injected_scripts': [],
            'redirect_chains': [],
        }

        # 检测页面是否包含 WAF 拦截页的特征
        body = resp.text
        status_code = resp.status_code

        waf_page_indicators = {
            'Cloudflare': [r'cloudflare.*ray', r'DDoS.*protection'],
            'Imperva': [r'SiteLock', r'Access denied'],
            'Akamai': [r'Request.*id.*blocked', r'access.denied'],
            'ModSecurity': [r'Rejected by ModSecurity', 'Apache-Error'],
            'Generic WAF': [r'403 Forbidden', 'access denied', 'request blocked'],
        }

        for provider, patterns in waf_page_indicators.items():
            for pattern in patterns:
                if re.search(pattern, body, re.IGNORECASE):
                    intercepts['blocked_requests'].append({
                        'provider': provider,
                        'pattern_matched': pattern,
                    })
                    break

        # 检测响应头修改（比较常见 WAF 注入的头）
        for hdr in ['X-Protected-By', 'X-WAF', 'X-CDN', 'X-Security']:
            if hdr.lower() in {k.lower() for k in resp.headers}:
                intercepts['modified_headers'].append(hdr)

        return intercepts


# 便捷函数
def detect_with_sensor(url: str, timeout: int = 15) -> Dict[str, Any]:
    """快速探测（类似 Acunetix 一键扫描）"""
    sensor = AcusensorSensor(timeout=timeout)
    return sensor.detect(url)
