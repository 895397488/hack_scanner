# from-source-of: Pentest-Swarm-AI (internal/agent/report/bounty/)
# 赏金估算模块 — 根据漏洞严重等级估算 bounty 收入范围
"""
Bounty（漏洞赏金）估算器。
核心算法源自 Pentest-Swarm-AI 的 bounty/bounty.go。

保守估算策略：不夸大，避免误导研究员。使用 HackerOne 等平台的公开数据作为基准。
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# 数据类型定义 (对应 bounty/Range 和 ProgramStats)
# ---------------------------------------------------------------------------

@dataclass
class BountyRange:
    """赏金收入范围估算"""
    low_usd: int = 0       # 预估最低奖金（美元）
    high_usd: int = 0      # 预估最高奖金（美元）
    source: str = ""        # 数据来源 ("program:slug" | "industry-average")


@dataclass
class ProgramStats:
    """某项目的赏金统计（可从平台公开资料爬取）"""
    slug: str = ""  # 项目在平台的标识

    # per_severity_avg — 该历史每个严重等级的平均奖金
    severity_avg: Dict[str, int] = field(default_factory=dict)

    # per_severity_top — 该平台公布的每级最高奖金
    severity_top: Dict[str, int] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# 行业基准数据 (对应 publicMarket map)
# 数值来自 HackerOne 年度公开报告，向下取整以避免高估
# ---------------------------------------------------------------------------

PUBLIC_MARKET = {
    "critical":      BountyRange(low_usd=1500, high_usd=10000, source="industry-average"),
    "high":          BountyRange(low_usd=500,  high_usd=3000, source="industry-average"),
    "medium":        BountyRange(low_usd=150,  high_usd=800,  source="industry-average"),
    "low":           BountyRange(low_usd=50,   high_usd=200,  source="industry-average"),
    "informational": BountyRange(low_usd=0,    high_usd=50,   source="industry-average"),
}

# CWE -> Severity 映射 (用于从 CVE/CWE 推导严重等级)
CWE_SEVERITY_MAP = {
    # 严重等级 -> 对应 CWE ID
    "critical": [94, 22, 78, 89, 611, 20, 434, 918, 502, 613],
    "high":     [287, 416, 269, 352, 472, 913, 601, 436, 693, 862],
    "medium":   [250, 200, 913, 79, 1337, 134, 829, 1835, 384, 116],
    "low":      [207, 928, 1035, 1037, 1038, 1040, 1041, 1053, 1054, 1055],
}

# CWE -> CVSS 基础分数映射（经验值）
CWE_BASE_SCORE = {
    94: 10.0,   # XSS (Server-Side)
    22: 9.8,    # Path Traversal
    78: 9.9,    # OS Command Injection
    89: 9.8,    # SQL Injection
    611: 5.3,   # XML External Entity
    20: 7.5,    # Improper Input Validation
    434: 9.8,   # SSRF
    918: 9.8,   # Server-Side Request Forgery (SSRF)
    502: 9.1,   # Deserialization of Untrusted Data
    287: 9.1,   # Improper Authentication
    416: 5.3,   # Uncontrolled Search Path Element
    269: 9.8,   # Improper Privilege Management
    352: 6.1,   # Cross-Site Request Forgery
    472: 5.0,   # External Parameter Reinterpretation
    913: 9.1,   # Improper Control of Dynamically-Managed Resources
    601: 5.3,   # Open Redirect
    436: 5.3,   # Interpretation Conflict
    693: 7.5,   # Protection Mechanism Bypass
    862: 5.3,   # Missing Authorization
    250: 7.5,   # Execution with Unnecessary Privileges
    200: 5.0,   # Information Exposure
    79: 6.1,    # Cross-site Scripting (XSS)
    1337: 5.0,  # Nginx Misconfiguration
    134: 7.5,   # Uncontrolled Format String
    829: 7.5,   # Suspicious URL Redirect
    116: 7.5,   # Improper Encoding
    1035: 5.0,  # Stripped Path Slash
    207: 3.0,   # Information Exposure Through Server Header
    928: 4.0,   # HTTP Response Splitting (potential)
}

# CVE -> CVSS 映射表（常见 CVE 的 CVSS v3.1 基础分数）
KNOWN_CVE_SCORES = {
    "CVE-2024-3094": 10.0,     # XZ Utils backdoor
    "CVE-2023-44487": 7.5,     # HTTP/2 Rapid Reset
    "CVE-2023-46805": 9.8,     # Apache Log4Shell follow-up
    "CVE-2021-44228": 10.0,     # Log4Shell
    "CVE-2023-27350": 5.6,     # Limesuite Web hijacking
    "CVE-2024-21762": 9.8,     # IIS path traversal
    "CVE-2024-1899": 9.8,      # Citrix Bleed
    "CVE-2023-4966": 7.5,      # Nexpose RCE
    "CVE-2024-3400": 9.8,      # Palo Alto PAN-OS CLI RCE
    "CVE-2023-0669": 9.8,      # SolarWinds Orion RCE
}


# ---------------------------------------------------------------------------
# 赏金估算引擎 (对应 bounty.go Estimate)
# ---------------------------------------------------------------------------

def estimate_bounty_severity(severity: str,
                             program_stats: Optional[ProgramStats] = None,
                             cve_id: str = "",
                             cwe_id: Optional[int] = None) -> BountyRange:
    """
    根据严重等级估算单条发现的赏金范围。

    优先级: program-specific data > industry average public market

    Args:
        severity:     严重等级 ("critical" | "high" | "medium" | "low" | "informational")
        program_stats: 项目赏金数据（可选，若提供则优先使用）
        cve_id:       CVE ID（用于查询已知评分）
        cwe_id:       CWE ID（用于推断严重程度）

    Returns:
        BountyRange 对象
    """
    # 如果有 program-specific stats，优先使用
    if program_stats and program_stats.slug:
        return _estimate_from_program(severity, program_stats)

    # 否则使用行业基准
    severity_key = severity.lower().strip()
    if severity_key in PUBLIC_MARKET:
        return BountyRange(
            low_usd=PUBLIC_MARKET[severity_key].low_usd,
            high_usd=PUBLIC_MARKET[severity_key].high_usd,
            source="industry-average",
        )

    # 默认返回最低档
    return BountyRange(low_usd=0, high_usd=50, source="industry-average")


def _estimate_from_program(severity: str, stats: ProgramStats) -> BountyRange:
    """
    使用项目特定数据估算赏金。

    算法源自 bounty.go Estimate():
      - 有 avg 和 top: low = avg, high = top
      - 只有 top:     low = top/2, high = top
      - 只有 avg:     low = avg,   high = avg * 5/2 (约2.5倍)
    """
    severity_key = severity.lower().strip()
    avg = stats.severity_avg.get(severity_key)
    top = stats.severity_top.get(severity_key)

    if avg is not None or top is not None:
        low = avg if avg is not None else (top // 2 if top is not None else 0)
        high = top if top is not None else (avg * 5 // 2 if avg is not None else avg)
        return BountyRange(low_usd=low, high_usd=high, source=f"program:{stats.slug}")

    # stats 存在但没有该等级的数据，回退到 industry average
    severity_key = severity.lower().strip()
    if severity_key in PUBLIC_MARKET:
        r = PUBLIC_MARKET[severity_key]
        return BountyRange(low_usd=r.low_usd, high_usd=r.high_usd, source=f"fallback:{stats.slug}")

    return BountyRange(source="program:")


# ---------------------------------------------------------------------------
# CVE/CWE 辅助工具
# ---------------------------------------------------------------------------

def get_cve_score(cve_id: str) -> float:
    """查询已知 CVE 的 CVSS 基础分数"""
    return KNOWN_CVE_SCORES.get(cve_id, 0.0)


def cwe_to_severity(cwe_id: int) -> str:
    """从 CWE ID 推导严重等级"""
    for severity, cwe_ids in CWE_SEVERITY_MAP.items():
        if cwe_id in cwe_ids:
            return severity
    # 默认 medium
    return "medium"


def get_base_score_from_cwe(cwe_id: int) -> float:
    """从 CWE ID 获取 CVSS 基础分数（经验值）"""
    return CWE_BASE_SCORE.get(cwe_id, 5.0)


# ---------------------------------------------------------------------------
# 总计汇总 (对应 bounty.go Total)
# ---------------------------------------------------------------------------

def estimate_total_bounty(findings_severity: List[str],
                          program_stats: Optional[ProgramStats] = None) -> tuple:
    """
    对一批发现的严重等级进行赏金总范围估算。

    Args:
        findings_severity: 每条发现的严重等级列表
        program_stats:     项目赏金数据（可选）

    Returns:
        (low_usd, high_usd) 元组
    """
    low = 0
    high = 0

    for sev in findings_severity:
        r = estimate_bounty_severity(sev, program_stats)
        low += r.low_usd
        high += r.high_usd

    return low, high


# ---------------------------------------------------------------------------
# 按 CWE 分类估算
# ---------------------------------------------------------------------------

def estimate_by_cwe(findings_cwe: List[tuple],
                    program_stats: Optional[ProgramStats] = None) -> dict:
    """
    按 CWE 统计赏金估算。

    Args:
        findings_cwe: [(cwe_id, finding_title), ...] 列表
        program_stats: 项目赏金数据

    Returns:
        {
            "total_low": int,
            "total_high": int,
            "by_cwe": { cwe_id: {"count": int, "low": int, "high": int} }
        }
    """
    by_cwe = {}
    total_low = 0
    total_high = 0

    for cwe_id, title in findings_cwe:
        severity = cwe_to_severity(cwe_id)
        r = estimate_bounty_severity(severity, program_stats)

        if cwe_id not in by_cwe:
            by_cwe[cwe_id] = {
                "cwe_name": f"CWE-{cwe_id}",
                "count": 0,
                "low": 0,
                "high": 0,
            }

        by_cwe[cwe_id]["count"] += 1
        by_cwe[cwe_id]["low"] += r.low_usd
        by_cwe[cwe_id]["high"] += r.high_usd
        total_low += r.low_usd
        total_high += r.high_usd

    return {
        "total_low": total_low,
        "total_high": total_high,
        "by_cwe": by_cwe,
        "source": f"program:{program_stats.slug}" if program_stats else "industry-average",
    }
