#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
remediation.py — 修复建议规则引擎（B）
=====================================================================

用途
----
按漏洞类型给 finding 生成结构化修复建议：

- 规则库：data/kb/remediation_rules.json（22 条规则，每条含
  pattern 正则 + 分步骤 steps（code/config/command/process）+ OWASP references）
- 引擎：把 finding 的 title/vuln_type/evidence/description 拼成匹配文本，
  命中 pattern 即返回该规则的修复建议；未命中返回通用建议（不静默吞掉）。

参照实现
--------
vulnclaw intel/remediation.py + intel/remediation_rules.py（1675 行）：
  - Remediation / RemediationStep / RemediationType / RemediationPriority 数据模型
  - @_rule(pattern) 装饰器 + 规则按序匹配（首个命中即返回）
  - _generic_remediation 兜底
  - get_markdown 渲染
本模块把"规则数据"从 Python 函数抽成 JSON（数据/逻辑分离，规则可独立更新），
引擎纯标准库，API 适配 hack_scanner 的 finding dict 约定，不 import vulnclaw。

优先级映射（severity → priority）
--------------------------------
  critical → immediate；high → high；medium/low → medium；info → low
  规则自带 priority 时以规则为准（如 sqli → immediate）。

零 orchestrator 改动：报告层钩子，run_adaptive 收尾时
remediate_all(findings) → append_remediation_section(report_path, ...)，
非阻塞、异常静默跳过。

纯标准库（Python 3.14），零第三方依赖，零网络。
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

__all__ = [
    "RemediationEngine",
    "Remediation",
    "default_rules_path",
    "remediate_finding",
    "remediate_all",
    "format_remediation_markdown",
    "append_remediation_section",
]

# 规则库默认位置：<项目根>/data/kb/remediation_rules.json
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_RULES_PATH = os.path.join(_PROJECT_ROOT, "data", "kb", "remediation_rules.json")

_SEVERITY_PRIORITY = {
    "critical": "immediate",
    "high": "high",
    "medium": "medium",
    "low": "medium",
    "info": "low",
}


def default_rules_path() -> str:
    """默认规则库路径（可被 config/参数覆盖）。"""
    return DEFAULT_RULES_PATH


@dataclass
class Remediation:
    """一条 finding 的结构化修复建议。"""
    finding_title: str
    finding_severity: str
    rule_id: str          # 命中的规则 id（generic 表示兜底）
    title: str
    summary: str
    priority: str         # immediate | high | medium | low
    steps: List[Dict[str, Any]] = field(default_factory=list)
    references: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "finding_title": self.finding_title,
            "finding_severity": self.finding_severity,
            "rule_id": self.rule_id,
            "title": self.title,
            "summary": self.summary,
            "priority": self.priority,
            "steps": self.steps,
            "references": self.references,
        }


def _severity_priority(severity: str) -> str:
    return _SEVERITY_PRIORITY.get(str(severity or "").lower(), "medium")


class RemediationEngine:
    """加载 JSON 规则库并对 finding 做匹配。

    用法::

        engine = RemediationEngine()               # 默认路径
        rem = engine.remediate_finding(finding)    # -> Remediation
        all_rems = engine.remediate_all(findings)  # -> List[Remediation]
        md = format_remediation_markdown(all_rems)
        append_remediation_section(report_path, all_rems)
    """

    def __init__(self, rules_path: Optional[str] = None):
        self.rules_path = rules_path or default_rules_path()
        self._rules: List[Dict[str, Any]] = []
        self._compiled: List[tuple[re.Pattern, Dict[str, Any]]] = []
        self._load()

    # ── 加载 ──────────────────────────────────────────────────────────────
    def _load(self) -> None:
        with open(self.rules_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        raw_rules = data.get("rules") or []
        for rule in raw_rules:
            if not isinstance(rule, dict):
                continue
            pattern = rule.get("pattern")
            if not pattern:
                continue
            try:
                compiled = re.compile(pattern, re.IGNORECASE)
            except re.error:
                continue  # 坏 pattern 跳过，不阻断整个库
            self._rules.append(rule)
            self._compiled.append((compiled, rule))

    @property
    def rule_count(self) -> int:
        return len(self._rules)

    # ── 匹配 ──────────────────────────────────────────────────────────────
    @staticmethod
    def _match_text(finding: Dict[str, Any]) -> str:
        """finding 的可匹配文本（多字段拼接）。"""
        return " ".join([
            str(finding.get("title") or ""),
            str(finding.get("vuln_type") or finding.get("type") or finding.get("type_") or ""),
            str(finding.get("description") or ""),
            str(finding.get("evidence") or ""),
        ]).strip()

    def _match_rule(self, finding: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        text = self._match_text(finding)
        if not text:
            return None
        for compiled, rule in self._compiled:
            if compiled.search(text):
                return rule
        return None

    # ── 对外 ──────────────────────────────────────────────────────────────
    def remediate_finding(self, finding: Dict[str, Any]) -> Remediation:
        """对单条 finding 生成修复建议。未命中规则 → 通用兜底。"""
        if not isinstance(finding, dict):
            finding = {}
        title = str(finding.get("title") or "Unknown Finding")
        severity = str(finding.get("severity") or "Medium")

        rule = self._match_rule(finding)
        if rule is not None:
            return Remediation(
                finding_title=title,
                finding_severity=severity,
                rule_id=str(rule.get("id") or "unknown"),
                title=str(rule.get("title") or title),
                summary=str(rule.get("summary") or ""),
                priority=str(rule.get("priority") or _severity_priority(severity)),
                steps=[s for s in (rule.get("steps") or []) if isinstance(s, dict)],
                references=[r for r in (rule.get("references") or []) if isinstance(r, str)],
            )

        # 通用兜底（参照 vulnclaw _generic_remediation）
        return Remediation(
            finding_title=title,
            finding_severity=severity,
            rule_id="generic",
            title="General Remediation",
            summary=(
                "未匹配到专项修复规则。按 OWASP 通用实践：修复根因（输入校验/安全编码），"
                "纵深防御（WAF/最小权限/网络隔离），并回归验证。"
            ),
            priority=_severity_priority(severity),
            steps=[
                {
                    "type": "process",
                    "title": "根因分析",
                    "description": "复现漏洞 → 定位引入点 → 确认影响范围（是否同类问题批量存在）。",
                },
                {
                    "type": "process",
                    "title": "修复与验证",
                    "description": "按漏洞类型选用对应安全编码实践；修复后重跑扫描确认消除且无回归。",
                },
            ],
            references=[
                "https://owasp.org/www-project-top-ten/",
                "https://owasp.org/www-project-web-security-testing-guide/",
            ],
        )

    def remediate_all(self, findings: List[Dict[str, Any]]) -> List[Remediation]:
        """批量生成修复建议（顺序保持）。"""
        out: List[Remediation] = []
        for f in (findings or []):
            if not isinstance(f, dict):
                continue
            out.append(self.remediate_finding(f))
        return out


# ── 模块级便捷函数（默认引擎单例）──────────────────────────────────────────
_default_engine: Optional[RemediationEngine] = None


def _get_engine() -> RemediationEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = RemediationEngine()
    return _default_engine


def remediate_finding(finding: Dict[str, Any]) -> Remediation:
    """便捷入口：用默认规则库对单条 finding 生成修复建议。"""
    return _get_engine().remediate_finding(finding)


def remediate_all(findings: List[Dict[str, Any]]) -> List[Remediation]:
    """便捷入口：批量。"""
    return _get_engine().remediate_all(findings)


# ── Markdown 渲染 ──────────────────────────────────────────────────────────
def format_remediation_markdown(remediations: List[Remediation]) -> str:
    """把修复建议列表渲染为 Markdown 段。"""
    if not remediations:
        return "_No remediation recommendations generated._"

    lines: List[str] = ["# 修复建议 (Remediation)\n"]
    for i, rem in enumerate(remediations, 1):
        icon = {"immediate": "🔴", "high": "🟠", "medium": "🟡", "low": "⚪"}.get(rem.priority, "⚪")
        lines.append(f"\n## {i}. {icon} {rem.title}\n")
        lines.append(f"- **发现:** {rem.finding_title}")
        lines.append(f"- **严重度:** {rem.finding_severity}")
        lines.append(f"- **修复优先级:** {rem.priority}")
        if rem.summary:
            lines.append(f"- **建议:** {rem.summary}")
        for j, step in enumerate(rem.steps, 1):
            step_title = str(step.get("title") or f"步骤 {j}")
            step_type = str(step.get("type") or "process")
            lines.append(f"\n### {i}.{j} {step_title} `[{step_type}]`")
            desc = str(step.get("description") or "").strip()
            if desc:
                lines.append(desc)
            content = str(step.get("content") or "").strip()
            if content:
                lang = str(step.get("language") or "").strip()
                lines.append(f"```{lang}")
                lines.append(content)
                lines.append("```")
        if rem.references:
            lines.append("\n**参考:**")
            for r in rem.references:
                lines.append(f"- {r}")
        lines.append("")

    lines.append("\n---\n*Generated by hack_scanner — 修复建议规则库 v"
                 f"{_get_engine().rule_count} rules*")
    return "\n".join(lines)


# ── 报告附录 ────────────────────────────────────────────────────────────────
def append_remediation_section(
    report_path: str,
    remediations: Optional[List[Remediation]] = None,
    findings: Optional[List[Dict[str, Any]]] = None,
) -> str:
    """把修复建议段追加到报告文件末尾（幂等：已存在则不重复追加）。

    remediations: 已生成的建议列表；若为空则用 findings 现算。
    返回追加的 Markdown 文本（文件不存在/不可写时只返回文本，不抛）。
    """
    if remediations is None or not remediations:
        remediations = remediate_all(findings or [])

    section = format_remediation_markdown(remediations)
    if not report_path or not os.path.isfile(report_path):
        return section  # 无报告文件 → 调用方可自行落盘

    try:
        with open(report_path, "r", encoding="utf-8", errors="replace") as f:
            existing = f.read()
        if "# 修复建议 (Remediation)" in existing:
            return section  # 幂等
        with open(report_path, "a", encoding="utf-8") as f:
            if existing and not existing.endswith("\n"):
                f.write("\n")
            f.write("\n\n" + section)
    except OSError:
        pass  # 写失败不阻断
    return section


# ── self-test（python scanners/remediation.py）──────────────────────────────
if __name__ == "__main__":
    eng = RemediationEngine()
    assert eng.rule_count >= 20, f"规则库应 ≥20 条，实际 {eng.rule_count}"

    _cases = [
        ({"title": "SQL Injection in /api/login", "vuln_type": "sqli", "severity": "Critical"},
         "sqli", "immediate"),
        ({"title": "Stored XSS in comment", "vuln_type": "xss", "severity": "High"},
         "xss", "high"),
        ({"title": "RCE via os.system", "vuln_type": "rce", "severity": "Critical"},
         "cmd-injection", "immediate"),
        ({"title": "Path traversal in /files", "vuln_type": "lfi", "severity": "High"},
         "path-traversal", "high"),
        ({"title": "Default admin:admin credentials", "vuln_type": "weak-creds", "severity": "High"},
         "weak-creds", "high"),
        ({"title": "TLS 1.0 enabled", "vuln_type": "ssl", "severity": "Medium"},
         "ssl-tls", "medium"),
        ({"title": "Missing HSTS header", "vuln_type": "headers", "severity": "Medium"},
         "headers", "medium"),
        ({"title": "CSRF on /transfer", "vuln_type": "csrf", "severity": "Medium"},
         "csrf", "medium"),
        ({"title": "SSH root password login", "vuln_type": "ssh", "severity": "High"},
         "ssh", "high"),
        ({"title": "Server version disclosed", "vuln_type": "info-leak", "severity": "Low"},
         "info-disclosure", "medium"),
        ({"title": "CVE-2024-1234 unpatched", "vuln_type": "outdated", "severity": "High"},
         "outdated", "high"),
        ({"title": "CORS wildcard origin", "vuln_type": "cors", "severity": "Medium"},
         "cors", "medium"),
        ({"title": "IDOR on /api/user/{id}", "vuln_type": "idor", "severity": "High"},
         "idor", "high"),
        ({"title": "Unrestricted file upload", "vuln_type": "upload", "severity": "High"},
         "file-upload", "high"),
        ({"title": "XXE in /api/xml", "vuln_type": "xxe", "severity": "High"},
         "xxe", "high"),
        ({"title": "SSRF in /api/fetch", "vuln_type": "ssrf", "severity": "High"},
         "ssrf", "high"),
        ({"title": "Pickle deserialization of user input", "vuln_type": "deserialization", "severity": "Critical"},
         "deserialization", "high"),
        ({"title": "MongoDB 27017 exposed", "vuln_type": "port", "severity": "Medium"},
         "open-ports", "medium"),
        ({"title": "JWT alg=none accepted", "vuln_type": "jwt", "severity": "Critical"},
         "jwt", "high"),
        ({"title": "phpinfo.php accessible", "vuln_type": "admin", "severity": "High"},
         "admin-panel", "high"),
        ({"title": "GraphQL introspection enabled", "vuln_type": "graphql", "severity": "Medium"},
         "graphql", "medium"),
        ({"title": "CRLF injection in Location", "vuln_type": "crlf", "severity": "Low"},
         "crlf-redirect", "low"),
        ({"title": "Dangling CNAME takeover", "vuln_type": "subdomain", "severity": "Medium"},
         "subdomain", "medium"),
        ({"title": ".env file with API keys exposed", "vuln_type": "secrets", "severity": "High"},
         "data-exposure", "high"),
        ({"title": "WAF bypass via double encoding", "vuln_type": "waf", "severity": "High"},
         "waf-bypass", "high"),
        ({"title": "Some totally novel vuln type", "vuln_type": "unknown-xyz", "severity": "Info"},
         "generic", "low"),
    ]

    for finding, expected_rule, expected_priority in _cases:
        rem = eng.remediate_finding(finding)
        assert rem.rule_id == expected_rule, \
            f"{finding['title']}: expected rule {expected_rule}, got {rem.rule_id}"
        assert rem.priority == expected_priority, \
            f"{finding['title']}: expected priority {expected_priority}, got {rem.priority}"
        assert rem.steps, f"{finding['title']}: should have steps"

    # 批量
    all_rems = eng.remediate_all([c[0] for c in _cases[:5]] + [None, "bad", 42])
    assert len(all_rems) == 5, len(all_rems)

    # Markdown 渲染
    md = format_remediation_markdown(all_rems)
    assert "# 修复建议 (Remediation)" in md
    assert "SQL Injection" in md
    assert "```python" in md
    assert "OWASP" in md or "owasp" in md

    # 幂等追加
    import tempfile
    with tempfile.TemporaryDirectory() as _td:
        _rp = os.path.join(_td, "report.html")
        with open(_rp, "w", encoding="utf-8") as f:
            f.write("<html><body>report</body></html>")
        section = append_remediation_section(_rp, all_rems)
        with open(_rp, encoding="utf-8") as f:
            content1 = f.read()
        assert "修复建议" in content1
        append_remediation_section(_rp, all_rems)
        with open(_rp, encoding="utf-8") as f:
            content2 = f.read()
        assert content1 == content2, "幂等：重复追加不应变化"

    # 空输入
    assert remediate_all([]) == []
    generic = remediate_finding({"title": "totally unknown"})
    assert generic.rule_id == "generic"
    assert generic.steps

    print(f"remediation self-test OK ({eng.rule_count} rules)")
