#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CRLF Injection & Response Splitting Detector
=============================================
借鉴 Pentest-Swarm-AI crlfuzz 适配器。
检测 CR/LF 注入、HTTP 响应拆分、Set-Cookie 反射等漏洞。
"""

import re
import logging
import requests
import sys
from typing import List, Dict, Optional
from urllib.parse import urlparse

# ==================== 速率限制（防止 DoS）====================
try:
    from ..rate_limiter import get_rate_limiter, RequestQuotaExceeded
    HAS_RATE_LIMITER = True
except (ImportError, ValueError):
    try:
        from rate_limiter import get_rate_limiter, RequestQuotaExceeded
        HAS_RATE_LIMITER = True
    except ImportError:
        HAS_RATE_LIMITER = False

        class RequestQuotaExceeded(Exception):
            """占位异常类（真实定义在 rate_limiter 模块；仅当限速器启用时才会被抛出）"""

def _rl_wait(url):
    """请求前速率限制 + per-domain 配额检查；配额耗尽时抛 RequestQuotaExceeded"""
    if not HAS_RATE_LIMITER or not url:
        return
    try:
        limiter = get_rate_limiter()
        config_path = None
        for mod in (sys.modules.get('url_scanner'), sys.modules.get('hack_scanner')):
            if mod and hasattr(mod, 'CONFIG'):
                config_path = mod.CONFIG
                break
        interval = None
        rl_cfg = (config_path or {}).get('scanner', {}).get('rate_limit', {})
        if rl_cfg and rl_cfg.get('enabled'):
            interval = rl_cfg.get('per_domain_sec', 2.0)
        if not limiter.try_wait(url, interval):
            try:
                from rate_limiter import RequestQuotaExceeded, domain_of
            except ImportError:
                from ..rate_limiter import RequestQuotaExceeded, domain_of
            raise RequestQuotaExceeded(domain_of(url), limiter.max_per_domain)
    except Exception as e:
        if type(e).__name__ == 'RequestQuotaExceeded':
            raise
        # 限速器自身故障时不阻断扫描（保持原行为）


def _cfg():
    """Lazy CONFIG lookup via caller's module globals."""
    for name in ('url_scanner', 'hack_scanner'):
        mod = sys.modules.get(name)
        if mod and 'CONFIG' in vars(mod):
            return vars(mod)['CONFIG']
    return None

logger = logging.getLogger('crlf_detector')


class CRLFInjectionDetector:
    """CRLF 注入检测器 — 测试 HTTP 响应拆分攻击面"""

    # CR/LF Payloads (URL-encoded + raw)
    CRLF_PAYLOADS = [
        '%0d%0a',          # URL-encoded \r\n
        '%0D%0A',          # upper case
        '\r\n',            # raw CRLF
        '%0a',             # just LF (sometimes works)
        '%0d',             # just CR  (header start in some parsers)
        '%%0d%%0a',        # double-encoded
        '%25%30%64%25%30%61',  # triple-encoded \r\n
    ]

    # Response splitting indicators
    SPLITTING_INDICATORS = [
        'set-cookie',       # cookie injection
        'location:',        # header redirect injection
        'content-type:',    # content-type injection
        '<html',            # HTML injection in headers
        '<script',          # XSS via response splitting
    ]

    @staticmethod
    def detect(url: str) -> List[Dict]:
        """检测 CRLF 注入漏洞"""
        findings = []
        parsed = urlparse(url)

        # Only test parameters and path segments that get reflected in headers
        targets = []

        # Add query parameters as targets
        if parsed.query:
            for param in parsed.query.split('&'):
                if '=' in param:
                    key = param.split('=')[0]
                    targets.append((url, f'query:{key}'))

        # Also test path segments (some apps reflect them in Location headers)
        if parsed.path and parsed.path != '/':
            targets.append((url, 'path'))

        if not targets:
            # Test common CRLF-prone paths even without parameters
            crlf_paths = [
                '/redirect?url=',
                '/return?url=',
                '/next?url=',
                '/goto?url=',
                '/r?url=',
                '/page?file=',
                '/include?file=',
                '/load?file=',
                '/view?page=',
            ]
            for p in crlf_paths:
                test_url = url.rstrip('/') + p
                targets.append((test_url, f'path:{p}'))

        logger.info(f"  CRLF: Testing {len(targets)} target(s)...")

        for target_url, label in targets:
            for payload in CRLFInjectionDetector.CRLF_PAYLOADS:
                try:
                    # Build URL with CRLF payload
                    if '?' in target_url:
                        sep = '&' if target_url.count('?') > 1 else '?'
                        test_url = f"{target_url}{sep}inject={payload}"
                    else:
                        test_url = f"{target_url}?inject={payload}"

                    _rl_wait(test_url)
                    resp = requests.get(
                        test_url,
                        timeout=_cfg()['scanner']['timeout'],
                        allow_redirects=False,
                        headers={'User-Agent': _cfg()['scanner'].get('user_agent', 'Mozilla/5.0')}
                    )

                    # Check response headers for CRLF injection indicators
                    resp_headers_lower = {k.lower(): v for k, v in resp.headers.items()}

                    # 1. Check if CRLF broke the header structure (extra blank lines or unexpected content)
                    raw_reason = resp.reason or ''
                    if any(c in raw_reason for c in ['\r', '\n']):
                        findings.append({
                            'id': 'CRLF_INJECTION',
                            'severity': 'high',
                            'title': f'CRLF 注入 (响应头拆分): {label}',
                            'description': f'目标在 HTTP 响应头中处理用户输入时存在 CRLF 注入漏洞。Payload: {payload}',
                            'url': test_url,
                            'evidence': f'Response reason contained CR/LF: {repr(raw_reason[:200])}',
                            'recommendation': '对所有用户输入进行严格过滤，只允许字母数字字符；设置 Content-Type 并使用 X-Content-Type-Options: nosniff',
                            'cwe': 'CWE-93',
                            'cvss': 7.4,
                        })
                        logger.warning(f"  [!] CRLF 注入 (header): {label} - {payload}")
                        break

                    # 2. Check for Set-Cookie reflection (cookie injection)
                    set_cookie = resp.headers.get('Set-Cookie', '')
                    if set_cookie and any(ind.lower() in set_cookie.lower() for ind in CRLFInjectionDetector.SPLITTING_INDICATORS):
                        findings.append({
                            'id': 'CRLF_COOKIE_INJECTION',
                            'severity': 'high',
                            'title': f'CRLF 注入 (Set-Cookie 反射): {label}',
                            'description': f'CRLF payload 成功注入了 Set-Cookie 头，可用来覆盖 cookie 属性',
                            'url': test_url,
                            'evidence': f'Set-Cookie header reflected CRLF pattern in: {set_cookie[:500]}',
                            'recommendation': '过滤请求中的 %0d%0a 序列；对 Set-Cookie 值进行 URL decoding 前验证',
                            'cwe': 'CWE-93',
                            'cvss': 7.1,
                        })
                        logger.warning(f"  [!] CRLF cookie injection: {label}")
                        break

                    # 3. Check for location header manipulation via CRLF
                    location = resp.headers.get('Location', '')
                    if location and '%0d' in location.lower() or '%0a' in location.lower():
                        findings.append({
                            'id': 'CRLF_LOCATION_INJECTION',
                            'severity': 'high',
                            'title': f'CRLF 注入 (Location 头): {label}',
                            'description': f'CRLF payload 被写入 Location 响应头，可能用于响应拆分攻击',
                            'url': test_url,
                            'evidence': f'Location header contains encoded CRLF: {location[:500]}',
                            'recommendation': '对 Location 头的用户输入进行白名单校验；使用相对路径而非绝对路径',
                            'cwe': 'CWE-601',
                            'cvss': 7.4,
                        })
                        logger.warning(f"  [!] CRLF location injection: {label}")
                        break

                    # 4. Check for response body HTML splitting (injected tags)
                    body = resp.text
                    if len(body) > 10:
                        # Look for unexpected HTML structure breaks
                        lines = body.split('\r\n') or body.split('\n')
                        for line in lines[:3]:
                            stripped = line.strip()
                            if stripped.startswith(('<', '>', '{')) and len(stripped) < 200:
                                # Could be header-injected HTML fragment
                                pass

                except RequestQuotaExceeded:
                    logger.warning('  CRLF注入检测: per-domain 请求配额已耗尽，停止后续探测')
                    return findings
                except requests.RequestException as e:
                    logger.debug(f"  CRLF request error ({label}): {e}")
                    continue
            else:
                continue
            break

        return findings


class HTTPRequestSmugglingDetector:
    """HTTP Request Smuggling Detector
    借鉴 Pentest-Swarm-AI Phase 5.11 (CL.TE, TE.CL patterns)
    """

    @staticmethod
    def detect(url: str) -> List[Dict]:
        """检测 HTTP 请求走私漏洞"""
        findings = []

        # Test with CL.TE and TE.CL patterns on POST endpoints
        base_url = url.rstrip('/')

        # Try common POST endpoints
        test_endpoints = [
            f"{base_url}/",
            f"{base_url}/api/",
            f"{base_url}/login",
        ]

        for endpoint in test_endpoints:
            try:
                # CL.TE pattern: Content-Length + Transfer-Encoding header confusion
                # If the front-end parses CL and back-end parses TE, we can smuggle
                body = "test=data"
                headers = {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Content-Length': '4',      # short CL (only counts "test")
                    'Transfer-Encoding': 'chunked',  # back-end will read more
                    'User-Agent': _cfg()['scanner'].get('user_agent', 'Mozilla/5.0'),
                }

                _rl_wait(endpoint)
                resp = requests.post(
                    endpoint,
                    data=b'test=data\r\n\r\nX-Forwarded-For: 127.0.0.1',
                    headers=headers,
                    timeout=_cfg()['scanner']['timeout'],
                    allow_redirects=False,
                )

                # Look for response splitting / header confusion indicators
                resp_headers_lower = {k.lower(): v for k, v in resp.headers.items()}

                # Check if extra data was parsed as a new request (response differs from normal)
                if len(resp.text) > 500:
                    # Unusually large response might indicate smuggled request was processed
                    pass

            except RequestQuotaExceeded:
                logger.warning('  请求走私检测: per-domain 请求配额已耗尽，停止后续探测')
                return findings
            except requests.RequestException:
                continue

        return findings


class WebCachePoisoningDetector:
    """Web Cache Poisoning Detector
    借鉴 Pentest-Swarm-AI Phase 5.11.4 (CDN cache-key inconsistency)
    """

    @staticmethod
    def detect(url: str, page_content: str = "") -> List[Dict]:
        """检测 Web Cache Poisoning"""
        findings = []
        parsed = urlparse(url)

        if not page_content:
            return findings

        # Check for cache-related headers (we need to identify cacheable endpoints)
        # These are usually endpoints with Vary headers or custom X- headers
        cache_headers_to_test = [
            'X-Forwarded-Host',
            'X-Forwarded-Server',
            'X-Forwarded-For',
            'X-Original-URL',
            'X-Rewrite-URL',
            'Referer',
            'X-Host',
            'X-Path',
        ]

        # Test common cache-poisoning headers
        test_headers = {
            'Vary': 'Accept-Encoding',  # Check if Vary is reflected
        }

        for header_name in cache_headers_to_test:
            test_url = url
            if parsed.query:
                test_url += f'&{header_name}=poisoned-value'
            else:
                test_url += f'?{header_name}=poisoned-value'

            try:
                _rl_wait(test_url)
                resp = requests.get(
                    test_url,
                    timeout=_cfg()['scanner']['timeout'],
                    headers={
                        header_name: 'poisoned-value',
                        'User-Agent': _cfg()['scanner'].get('user_agent', 'Mozilla/5.0'),
                    }
                )

                # Check if the custom header value appears in the response body (cache poisoning indicator)
                if 'poisoned-value' in resp.text:
                    findings.append({
                        'id': 'CACHE_POISONING_VARY',
                        'severity': 'high',
                        'title': f'Web Cache Poisoning (Vary header): {parsed.path}',
                        'description': f'X-Forwarded-* 头被写入响应体，可能导致缓存投毒攻击',
                        'url': test_url,
                        'evidence': f'Response body contains custom header value "poisoned-value"',
                        'recommendation': '对用户提供的请求头进行严格过滤；不要将用户输入直接写入响应或缓存键',
                        'cwe': 'CWE-113',
                        'cvss': 7.4,
                    })

            except RequestQuotaExceeded:
                logger.warning('  缓存投毒检测: per-domain 请求配额已耗尽，停止后续探测')
                return findings
            except requests.RequestException:
                continue

        return findings
