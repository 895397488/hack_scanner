#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
output_offload.py — 工具输出 offload（4 项目升级清单 #4）
=====================================================================

借鉴 redamon agentic/{tool_offload_policy.py, output_offload.py}:
    context_budget 旧行为是"超预算直接丢弃历史"——全文不可恢复，
    模型也看不到被丢弃部分的存在。offload 把大输出改成：
        全文落盘  <outdir>/<utc>-<tool>.txt
        回 LLM 的 = head 80 行 + tail 40 行（char cap 4000/2000）+ 路径提示
    模型需要全文时可自行读文件（工具链里有 fs/shell 能力时），
    信息不丢、token 有界。

策略（与 redamon 同款三态）:
    auto   默认：长度 > OFFLOAD_THRESHOLD(20000) 才 offload
    always 名单内工具：无条件 offload（如 nuclei/ffuf 这类洪水输出）
    never  名单内工具：永不 offload（小工具，stub 反而损失信息）

char cap 的意义：head/tail 按行切，但单行巨输出（base64 blob、压缩 JSON）
会一行吞掉所有预算——head 4000 / tail 2000 字符硬上限防这个。

设计纪律（与 anti_loop / exec_gate / prompt_safety 一致）:
    - 入口层包装 tool.execute，orchestrator 零改动
    - 落盘失败 → 原样返回（宁可超 token 也不丢结果/抛异常）
    - 小输出（非 str / 空 / 未超限）逐字透传
    - 包装器幂等（_offload_wrapped 标记）

挂点（run_adaptive.py 3c 段）:
    装在 exec_gate 之后、install_result_recorder 之前——
    recorder 记到的是模型实际看到的（可能是 stub 的）最终返回。
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

__all__ = [
    "OFFLOAD_THRESHOLD",
    "HEAD_LINES",
    "TAIL_LINES",
    "HEAD_CHAR_CAP",
    "TAIL_CHAR_CAP",
    "maybe_offload",
    "install_output_offload",
]

OFFLOAD_THRESHOLD = 20000   # 字符数（auto 策略触发线）
HEAD_LINES = 80
TAIL_LINES = 40
HEAD_CHAR_CAP = 4000        # 防单行巨输出撑爆 head
TAIL_CHAR_CAP = 2000        # 同上，tail

_TOOL_SAFE = re.compile(r"[^A-Za-z0-9._-]+")


def _safe_name(tool: str) -> str:
    return _TOOL_SAFE.sub("_", str(tool or "tool"))[:64] or "tool"


def _format_stub(output: str, filename: str, char_len: int) -> str:
    """head 80 行 + tail 40 行 + char cap + 路径提示（redamon _format_stub 同款）。"""
    lines = output.splitlines()
    head = "\n".join(lines[:HEAD_LINES])
    if len(head) > HEAD_CHAR_CAP:
        head = head[:HEAD_CHAR_CAP] + "\n[head truncated]"
    has_tail = len(lines) > HEAD_LINES
    tail = "\n".join(lines[-TAIL_LINES:]) if has_tail else ""
    if len(tail) > TAIL_CHAR_CAP:
        tail = "[tail truncated]\n" + tail[-TAIL_CHAR_CAP:]
    parts = [
        f"[Output offloaded: {char_len} chars, {len(lines)} lines -> {filename}]",
        "[Head %d / Tail %d lines below. Read the file above for full output.]"
        % (HEAD_LINES, TAIL_LINES),
        "--- head ---",
        head,
    ]
    if tail:
        parts.append("--- tail ---")
        parts.append(tail)
    return "\n".join(parts)


def maybe_offload(tool: str, text: Any, outdir: str,
                  mode: str = "auto") -> Tuple[Any, bool]:
    """按策略决定是否 offload。返回 (返回给模型的值, 是否 offload 了)。

    - mode 非法 → 按 auto
    - text 非 str → str() 化后判定（orchestrator 最终都要字符串化，先做无损失）
    - 空文本 → 原样透传
    - never → 透传；always → 落盘；auto → 超阈值才落盘
    - 落盘失败（目录不可建/磁盘满）→ 原样透传（fail-open 到"信息完整"侧）
    """
    if text is None:
        return "", False
    if not isinstance(text, str):
        text = str(text)
    if not text:
        return text, False

    mode = (mode or "auto").lower()
    if mode not in ("never", "always", "auto"):
        mode = "auto"
    if mode == "never":
        return text, False
    if mode == "auto" and len(text) <= OFFLOAD_THRESHOLD:
        return text, False

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    filename = f"{ts}-{_safe_name(tool)}.txt"
    try:
        os.makedirs(outdir, exist_ok=True)
        target = os.path.join(outdir, filename)
        # 并发/同秒重名 → 加序号，绝不覆盖既有全文
        n = 1
        while os.path.exists(target):
            target = os.path.join(outdir, f"{ts}-{_safe_name(tool)}-{n}.txt")
            n += 1
        with open(target, "w", encoding="utf-8") as fh:
            fh.write(text)
    except OSError:
        return text, False  # 落盘失败 → 透传全文（不丢信息、不抛异常）

    return _format_stub(text, target, len(text)), True


def install_output_offload(orch, outdir: str,
                           always_tools: tuple = (),
                           never_tools: tuple = ()) -> int:
    """包每个已注册工具的 execute：大输出 offload 后回 LLM。

    - 返回成功包装的工具数
    - 非文本结果透传（None/dict 由 orchestrator 自行渲染）
    - 包装器自身异常 → 返回原始结果（绝不阻断核心循环）
    - 幂等：_offload_wrapped 已标记的跳过
    """
    always = set(always_tools or ())
    never = set(never_tools or ())
    count = 0
    tools: Dict[str, Any] = getattr(orch, "tools", None) or {}
    for name, tool in list(tools.items()):
        if name in never:
            continue
        orig = getattr(tool, "execute", None)
        if orig is None or getattr(orig, "_offload_wrapped", False):
            continue

        # 模式在 def 前求值——默认值表达式不能引用同一 def 的其他默认参数（_name），
        # 否则安装时 NameError（会被入口层 try/except 静默吞掉，offload 白挂）
        _mode = "always" if name in always else "auto"

        def wrap(args, _orig=orig, _name=name, _mode=_mode):
            # 工具只执行一次：异常直接上抛（orchestrator 会转 error 消息），
            # 绝不在 except 里重跑——带副作用的工具重跑 = 副作用翻倍（BUG_REPORT [3d]）。
            res, err = _orig(args)
            if isinstance(res, str) and res:
                try:
                    new_res, _off = maybe_offload(_name, res, outdir, _mode)
                    res = new_res
                except Exception:
                    pass  # offload 自身失败 → 回退裸全文，绝不阻断核心循环
            return res, err

        wrap._offload_wrapped = True
        tool.execute = wrap
        count += 1
    return count
