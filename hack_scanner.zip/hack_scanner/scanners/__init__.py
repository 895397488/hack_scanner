#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hack Scanner 扩展模块包
========================
从 Pentest-Swarm-AI 借鉴的新扫描器集合。

覆盖的漏洞类型（hack 原版缺失）：
- CRLF 注入 & HTTP 响应拆分              (crlf_detector)
- JWT Token 漏洞                         (jwt_detector)
- Subdomain Takeover (子域名接管)         (subdomain_takeover)
- GraphQL 安全检查                       (graphql_detector)
- HTTP Parameter Pollution               (http_param_pollution)
- OOB/Blind XSS / Blind SSRF             (oob_detector)
- Playbook 扫描工作流                    (playbooks)
"""

from .crlf_detector import CRLFInjectionDetector, HTTPRequestSmugglingDetector, WebCachePoisoningDetector
from .jwt_detector import JWTAnalyzer
from .subdomain_takeover import SubdomainTakeoverDetector, CloudBucketEnumerator
from .graphql_detector import GraphQLSecurityDetector, GraphQLEndpointFinder
from .http_param_pollution import HTTPParamPollutionDetector, ParamDiscoveryHelper
from .oob_detector import OOBInteractshClient, BlindXSXDetector, BlindSSRFDetector, BlindRSFDetector
from .playbooks import PlaybookRunner, FPFalsePositiveCache

# 统一导出新扫描器列表
ALL_NEW_SCANNERS = [
    'CRLFInjectionDetector',
    'HTTPRequestSmugglingDetector',
    'WebCachePoisoningDetector',
    'JWTAnalyzer',
    'SubdomainTakeoverDetector',
    'CloudBucketEnumerator',
    'GraphQLSecurityDetector',
    'GraphQLEndpointFinder',
    'HTTPParamPollutionDetector',
    'ParamDiscoveryHelper',
    'OOBInteractshClient',
    'BlindXSXDetector',
    'BlindSSRFDetector',
    'BlindRSFDetector',
    'PlaybookRunner',
    'FPFalsePositiveCache',
]
