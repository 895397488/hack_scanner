#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hack Scanner 扩展模块包
========================
从 Pentest-Swarm-AI 借鉴的新扫描器集合。

覆盖的漏洞类型（hack 原版缺失）：
- CRLF 注入 & HTTP 响应拆分              (crlf_detector)
- JWT Token 漏洞                         (jwt_detector)
- Subdomain Takeover (子域名接管)         (subdomain_takeover)
- GraphQL 安全检查                       (graphql_detector)
- HTTP Parameter Pollution               (http_param_pollution)
- OOB/Blind XSS / Blind SSRF             (oob_detector)
- Playbook 扫描工作流                    (playbooks)
"""

from .crlf_detector import CRLFInjectionDetector, HTTPRequestSmugglingDetector, WebCachePoisoningDetector
from .jwt_detector import JWTAnalyzer
from .subdomain_takeover import SubdomainTakeoverDetector, CloudBucketEnumerator
from .graphql_detector import GraphQLSecurityDetector, GraphQLEndpointFinder
from .http_param_pollution import HTTPParamPollutionDetector, ParamDiscoveryHelper
from .oob_detector import OOBInteractshClient, BlindXSXDetector, BlindSSRFDetector, BlindRSFDetector
from .playbooks import PlaybookRunner, FPFalsePositiveCache

# ── P0/P1 新集成模块 ──
try:
    from .waf_detector import detect_waf
except (ImportError, Exception):
    pass

from .sql_exploit import exploit_sqli
from .web_fuzzer import fuzz_paths, fuzz_params
from .osint_recon import osint_recon
from .ssl_deep_scan import ssl_deep_scan
from .network_scan import port_scan, masscan_ports, network_scan, host_discovery
from .file_meta import file_metadata, check_steganography
from .domain_similarity import find_typosquats, check_domain_similarity
from .dns_zone_transfer import dns_recon
from .cve_lookup import lookup_cve, check_package_vulns
from .webshell_detector import detect_webshells
from .domain_cert_monitor import cert_monitor, subdomains_from_cert
from .zap_scanner import zap_scan, zap_active_scan, zap_spider
from .git_secret_scanner import scan_git_repo, scan_git_remote
from .nuclei_scanner import nuclei_scan, nuclei_template_search
from .gobuster_wrapper import gobuster_dir, gobuster_vhost, gobuster_dns, gobuster
from .hydra_wrapper import hydra_http_post, hydra_ssh, hydra_ftp
from .google_dorker import google_dork, get_owasp_ghdb, dork_by_keyword

# 统一导出新扫描器列表
ALL_NEW_SCANNERS = [
    'CRLFInjectionDetector',
    'HTTPRequestSmugglingDetector',
    'WebCachePoisoningDetector',
    'JWTAnalyzer',
    'SubdomainTakeoverDetector',
    'CloudBucketEnumerator',
    'GraphQLSecurityDetector',
    'GraphQLEndpointFinder',
    'HTTPParamPollutionDetector',
    'ParamDiscoveryHelper',
    'OOBInteractshClient',
    'BlindXSXDetector',
    'BlindSSRFDetector',
    'BlindRSFDetector',
    'PlaybookRunner',
    'FPFalsePositiveCache',
    'detect_waf',       # WAF 检测
    'exploit_sqli',     # SQLi 利用
    'fuzz_paths',       # 路径模糊测试
    'osint_recon',      # OSINT 侦察
    'ssl_deep_scan',    # SSL/TLS 深度分析
    'port_scan',        # nmap 端口扫描
    'file_metadata',    # 文件元数据/隐写检测
    'find_typosquats',  # 域名混淆检测
    'dns_recon',        # DNS 区域转移 + 记录查询
    'lookup_cve',       # CVE 查询 (NVD API)
    'detect_webshells', # Webshell 后门检测
    'cert_monitor',     # 证书透明度监控
    'zap_scan',         # OWASP ZAP 自动化扫描
    'scan_git_repo',    # Git 仓库密钥泄露检测
    'nuclei_scan',      # Nuclei 模板驱动漏洞扫描
    'gobuster_dir',     # GoBuster 目录/VHost/DNS 爆破
    'hydra_http_post',  # Hydra HTTP 登录暴力破解测试
    'google_dork',      # Google Hacking Dorks 侦察
]
