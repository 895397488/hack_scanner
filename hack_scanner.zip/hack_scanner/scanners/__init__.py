#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hack Scanner 扩展模块包
========================
从 Pentest-Swarm-AI 借鉴的新扫描器集合。

覆盖的漏洞类型（hack 原版缺失）：
- CRLF 注入 & HTTP 响应拆分              (crlf_detector)
- JWT Token 漏洞                         (jwt_detector)
- Subdomain Takeover (子域名接管)         (subdomain_takeover)
- GraphQL 安全检查                       (graphql_detector)
- HTTP Parameter Pollution               (http_param_pollution)
- OOB/Blind XSS / Blind SSRF             (oob_detector)
- Playbook 扫描工作流                    (playbooks)
"""

from .crlf_detector import CRLFInjectionDetector, HTTPRequestSmugglingDetector, WebCachePoisoningDetector
from .jwt_detector import JWTAnalyzer
from .subdomain_takeover import SubdomainTakeoverDetector, CloudBucketEnumerator
from .graphql_detector import GraphQLSecurityDetector, GraphQLEndpointFinder
from .http_param_pollution import HTTPParamPollutionDetector, ParamDiscoveryHelper
from .oob_detector import OOBInteractshClient, BlindXSXDetector, BlindSSRFDetector, BlindRSFDetector
from .playbooks import PlaybookRunner, FPFalsePositiveCache

# ── P0/P1 新集成模块 ──
try:
    from .waf_detector import detect_waf
except (ImportError, Exception):
    pass

from .sql_exploit import exploit_sqli
from .web_fuzzer import fuzz_paths, fuzz_params
from .osint_recon import osint_recon
from .ssl_deep_scan import ssl_deep_scan
from .network_scan import port_scan, masscan_ports, network_scan, host_discovery
from .file_meta import file_metadata, check_steganography
from .domain_similarity import find_typosquats, check_domain_similarity
from .dns_zone_transfer import dns_recon
from .cve_lookup import lookup_cve, check_package_vulns
from .webshell_detector import detect_webshells
from .domain_cert_monitor import cert_monitor, subdomains_from_cert
from .zap_scanner import zap_scan, zap_active_scan, zap_spider
from .git_secret_scanner import scan_git_repo, scan_git_remote
from .nuclei_scanner import nuclei_scan, nuclei_template_search
from .gobuster_wrapper import gobuster_dir, gobuster_vhost, gobuster_dns, gobuster
from .hydra_wrapper import hydra_http_post, hydra_ssh, hydra_ftp
from .google_dorker import google_dork, get_owasp_ghdb, dork_by_keyword

# ── Domain Utility（Acunetix public suffix list 精确解析）──
try:
    from .domain_util import PublicSuffixList, parse_domain, is_subdomain_of, get_psl
except (ImportError, Exception):
    pass

# ═══════════════════════════════════════════════════════
# Acunetix v25 借鉴新增模块（hack_scanner v7.0 升级）
# ═══════════════════════════════════════════════════════

# ── AcuSensor-Style Sensor (WAF 深度探测 + 服务器指纹) ──
try:
    from .acusensor_sensor import AcusensorSensor, SensorBridge, detect_with_sensor
except (ImportError, Exception):
    pass

# ── JS Rendering Scanner (Headless Browser 渲染分析) ──
try:
    from .js_render_scanner import JSRenderScanner, render_js_page
except (ImportError, Exception):
    pass

# ── Distributed Scan Messaging (NATS-style cluster coordination) ──
try:
    from .distributed_messaging import (
        ScanCluster, ScanTopic, WorkerState, WorkerNode,
        ScanMessage, ScanResult, LocalMessageBus,
        create_cluster, enum_distributed,
    )
except (ImportError, Exception):
    pass

# 统一导出新扫描器列表
ALL_NEW_SCANNERS = [
    'CRLFInjectionDetector',
    'HTTPRequestSmugglingDetector',
    'WebCachePoisoningDetector',
    'JWTAnalyzer',
    'SubdomainTakeoverDetector',
    'CloudBucketEnumerator',
    'GraphQLSecurityDetector',
    'GraphQLEndpointFinder',
    'HTTPParamPollutionDetector',
    'ParamDiscoveryHelper',
    'OOBInteractshClient',
    'BlindXSXDetector',
    'BlindSSRFDetector',
    'BlindRSFDetector',
    'PlaybookRunner',
    'FPFalsePositiveCache',
    'detect_waf',       # WAF 检测
    'exploit_sqli',     # SQLi 利用
    'fuzz_paths',       # 路径模糊测试
    'osint_recon',      # OSINT 侦察
    'ssl_deep_scan',    # SSL/TLS 深度分析
    'port_scan',        # nmap 端口扫描
    'file_metadata',    # 文件元数据/隐写检测
    'find_typosquats',  # 域名混淆检测
    'dns_recon',        # DNS 区域转移 + 记录查询
    'lookup_cve',       # CVE 查询 (NVD API)
    'detect_webshells', # Webshell 后门检测
    'cert_monitor',     # 证书透明度监控
    'zap_scan',         # OWASP ZAP 自动化扫描
    'scan_git_repo',    # Git 仓库密钥泄露检测
    'nuclei_scan',      # Nuclei 模板驱动漏洞扫描
    'gobuster_dir',     # GoBuster 目录/VHost/DNS 爆破
    'hydra_http_post',  # Hydra HTTP 登录暴力破解测试
    'google_dork',      # Google Hacking Dorks 侦察
    'PublicSuffixList', # 公共后缀列表解析器
    'parse_domain',     # 注册域名提取快捷函数
    'is_subdomain_of',  # 子域名关系检测快捷函数
    'get_psl',          # 全局 PSL 实例（单例）
    # ── Acunetix v25 新增 ──
    'AcusensorSensor',  # AcuSensor 主动式 WAF 感知传感器
    'SensorBridge',     # 传感器桥接器（响应拦截分析）
    'detect_with_sensor',  # 快速 AcuSensor 探测
    'JSRenderScanner',  # JS 渲染引擎 + SPA 端点发现
    'render_js_page',   # 快速 JS 页面渲染
    'ScanCluster',      # 分布式扫描集群
    'ScanTopic',        # 扫描主题枚举
    'WorkerState',      # 工作节点状态
    'create_cluster',   # 快速创建集群
    'enum_distributed', # 分布式子域名枚举
]

# ── Acunetix 新增模块列表（供文档/清单使用） ──
ACUNETIX_MODULES = {
    'acu_sensor': {
        'file': 'scanners/acusensor_sensor.py',
        'description': 'AcuSensor-Style WAF 主动感知传感器 — 探测 WAF/CDN/IPS 防护机制，模拟 AcuSensor 多语言探针部署',
        'classes': ['AcusensorSensor', 'SensorBridge'],
        'features': [
            'WAF 深度指纹识别（50+ WAF 产品）',
            'CDN 边缘节点检测',
            '敏感请求头注入探测',
            'Cookie 篡改检测',
            '参数探针注入分析',
            '服务器技术栈指纹识别',
            '传感器绕过可能性评估',
        ],
    },
    'js_renderer': {
        'file': 'scanners/js_render_scanner.py',
        'description': 'Headless Browser JS 渲染引擎 — 渲染 SPA/Rails/Vue/Angular 页面，发现隐藏 API 端点',
        'classes': ['JSRenderScanner'],
        'features': [
            'Selenium/Playwright 双引擎支持',
            '前端框架指纹识别（React/Vue/Angular/Next.js/Nuxt/Svelte...）',
            '状态管理检测（Redux/Vuex/MobX/NgRx/Pinia/Zustand）',
            'SPA 路由定义提取',
            'XHR/Fetch API 端点发现',
            'Console 日志捕获',
            '隐藏元素和配置数据提取',
            '无依赖 HTTP+JS 源码回退方案',
        ],
    },
    'distributed': {
        'file': 'scanners/distributed_messaging.py',
        'description': 'NATS-Style 分布式扫描协调器 — 多节点任务分发、结果汇聚、状态同步',
        'classes': ['ScanCluster', 'LocalMessageBus', 'WorkerNode', 'ScanTopic'],
        'features': [
            'Topic-based 消息路由（20+ 预定义主题）',
            '本地内存总线（无需外部 NATS 服务器）',
            '动态工作节点管理（spawn/remove/heartbeat）',
            '集群健康状态监控',
            '紧急停止机制',
            '分布式子域名枚举示例应用',
        ],
    },
    'domain_util': {
        'file': 'scanners/domain_util.py',
        'description': '精确域名解析器 — 基于 Acunetix public_suffix_list.dat (13626+ 条记录)',
        'classes': ['PublicSuffixList'],
        'features': [
            '注册域名提取（www.example.co.uk → example.co.uk）',
            '子域名合法性验证',
            '通配符规则支持 (*.example.com)',
            '异常规则支持 (!example.com)',
            '全局单例实例（get_psl）',
        ],
    },
}

# ═══════════════════════════════════════════════════════
# 扩展扫描器（可选依赖，按需提供）
# ═══════════════════════════════════════════════════════

# ── MITM Proxy Scanner ──
try:
    from .mitm_proxy_scanner import MitmProxyServer, CertFactory
    HAS_MITM_PROXY = True
except (ImportError, Exception):
    HAS_MITM_PROXY = False

# ── Scan Profiles ──
try:
    from .scan_profiles import ScanProfile, ProfileManager, apply_profile, list_profiles
    HAS_SCAN_PROFILES = True
except (ImportError, Exception):
    HAS_SCAN_PROFILES = False

# ── WAF Rule Generator ──
try:
    from .waf_rule_generator import (
        RuleGenerator,
        F5IRuleExporter,
        CloudflareWafRuleExporter,
        ModSecurityExporter,
    )
    HAS_WAF_RULE_GENERATOR = True
except (ImportError, Exception):
    HAS_WAF_RULE_GENERATOR = False

# ── Certificate Factory ──
try:
    from .cert_factory import MITMCA, FakeCertGenerator, CertCache
    HAS_CERT_FACTORY = True
except (ImportError, Exception):
    HAS_CERT_FACTORY = False

# ── AcuSensor Language Sensor Deployer ──
try:
    from .acusensor_lang_deploy import AcuSensorLangDetector, detect_server_language, generate_sensor_probes_for_url
    HAS_ACUSENSOR_LANG = True
except (ImportError, Exception):
    HAS_ACUSENSOR_LANG = False

# ── ZeroDiscovery: Inner Network Asset Discovery ──
try:
    from .zero_discovery import (
        ZeroDiscoveryEngine, ArpScanner, SnmpScanner,
        MqttScanner, SmbScanner, UnauthCacheScanner, discover_services_from_url
    )
    HAS_ZERO_DISCOVERY = True
except (ImportError, Exception):
    HAS_ZERO_DISCOVERY = False

# ── Enhanced CloudBucket Enumerator with boto3 ──
try:
    from .boto3_bucket_enhancer import EnhancedBucketEnumerator, detect_cloud_buckets_enhanced
    HAS_BOTO3_BUCKET_ENHANCER = True
except (ImportError, Exception):
    HAS_BOTO3_BUCKET_ENHANCER = False

# 统一导出（含可选模块）
__all__ = [
    # --- 必选扫描器 ---
    'CRLFInjectionDetector',
    'HTTPRequestSmugglingDetector',
    'WebCachePoisoningDetector',
    'JWTAnalyzer',
    'SubdomainTakeoverDetector',
    'CloudBucketEnumerator',
    'GraphQLSecurityDetector',
    'GraphQLEndpointFinder',
    'HTTPParamPollutionDetector',
    'ParamDiscoveryHelper',
    'OOBInteractshClient',
    'BlindXSXDetector',
    'BlindSSRFDetector',
    'BlindRSFDetector',
    'PlaybookRunner',
    'FPFalsePositiveCache',
    'detect_waf',
    'exploit_sqli',
    'fuzz_paths',
    'fuzz_params',
    'osint_recon',
    'ssl_deep_scan',
    'port_scan',
    'masscan_ports',
    'network_scan',
    'host_discovery',
    'file_metadata',
    'check_steganography',
    'find_typosquats',
    'check_domain_similarity',
    'dns_recon',
    'lookup_cve',
    'check_package_vulns',
    'detect_webshells',
    'cert_monitor',
    'subdomains_from_cert',
    'zap_scan',
    'zap_active_scan',
    'zap_spider',
    'scan_git_repo',
    'scan_git_remote',
    'nuclei_scan',
    'nuclei_template_search',
    'gobuster_dir',
    'gobuster_vhost',
    'gobuster_dns',
    'gobuster',
    'hydra_http_post',
    'hydra_ssh',
    'hydra_ftp',
    'google_dork',
    'get_owasp_ghdb',
    'dork_by_keyword',
    'PublicSuffixList',
    'parse_domain',
    'is_subdomain_of',
    'get_psl',
    'AcusensorSensor',
    'SensorBridge',
    'detect_with_sensor',
    'JSRenderScanner',
    'render_js_page',
    'ScanCluster',
    'ScanTopic',
    'WorkerState',
    'WorkerNode',
    'ScanMessage',
    'ScanResult',
    'LocalMessageBus',
    'create_cluster',
    'enum_distributed',
    # --- 可选扫描器（仅当对应 HAS_ = True 时可用）---
    'MitmProxyServer',      # mitm_proxy_scanner (HAS_MITM_PROXY)
    'CertFactory',          # mitm_proxy_scanner (HAS_MITM_PROXY)
    'ScanProfile',          # scan_profiles (HAS_SCAN_PROFILES)
    'ProfileManager',       # scan_profiles (HAS_SCAN_PROFILES)
    'apply_profile',        # scan_profiles (HAS_SCAN_PROFILES)
    'list_profiles',        # scan_profiles (HAS_SCAN_PROFILES)
    'RuleGenerator',        # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'F5IRuleExporter',      # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'CloudflareWafRuleExporter',  # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'ModSecurityExporter',  # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'MITMCA',               # cert_factory (HAS_CERT_FACTORY)
    'FakeCertGenerator',    # cert_factory (HAS_CERT_FACTORY)
    'CertCache',            # cert_factory (HAS_CERT_FACTORY)
    # ── 新增模块导出 ──
    'AcuSensorLangDetector',
    'detect_server_language',
    'generate_sensor_probes_for_url',
    'ZeroDiscoveryEngine',
    'ArpScanner',
    'SnmpScanner',
    'MqttScanner',
    'SmbScanner',
    'UnauthCacheScanner',
    'discover_services_from_url',
    'EnhancedBucketEnumerator',
    'detect_cloud_buckets_enhanced',
]

# ═══════════════════════════════════════════════════════
# 可选模块清单（供文档/清单使用）
# ═══════════════════════════════════════════════════════

OPTIONAL_MODULES = {
    'mitm_proxy_scanner': {
        'file': 'scanners/mitm_proxy_scanner.py',
        'flag': 'HAS_MITM_PROXY',
        'classes': ['MitmProxyServer', 'CertFactory'],
        'description': 'MITM 代理扫描器 — 中间人 TLS 解密与证书动态生成',
    },
    'scan_profiles': {
        'file': 'scanners/scan_profiles.py',
        'flag': 'HAS_SCAN_PROFILES',
        'classes': ['ScanProfile', 'ProfileManager'],
        'functions': ['apply_profile', 'list_profiles'],
        'description': '扫描配置文件 — 可复用扫描参数模板与加载器',
    },
    'waf_rule_generator': {
        'file': 'scanners/waf_rule_generator.py',
        'flag': 'HAS_WAF_RULE_GENERATOR',
        'classes': ['RuleGenerator', 'F5IRuleExporter', 'CloudflareWafRuleExporter', 'ModSecurityExporter'],
        'description': 'WAF 规则生成器 — 跨平台导出（F5 iRules / Cloudflare WAF / ModSecurity）',
    },
    'cert_factory': {
        'file': 'scanners/cert_factory.py',
        'flag': 'HAS_CERT_FACTORY',
        'classes': ['MITMCA', 'FakeCertGenerator', 'CertCache'],
        'description': '证书工厂 — MITM CA 签发、伪造证书、证书缓存管理',
    },
    'acusensor_lang_deploy': {
        'file': 'scanners/acusensor_lang_deploy.py',
        'flag': 'HAS_ACUSENSOR_LANG',
        'classes': ['AcuSensorLangDetector'],
        'functions': ['detect_server_language', 'generate_sensor_probes_for_url'],
        'description': 'AcuSensor 多语言传感器部署 — PHP/JAR/Node.js/.NET 服务端指纹与探针注入',
    },
    'zero_discovery': {
        'file': 'scanners/zero_discovery.py',
        'flag': 'HAS_ZERO_DISCOVERY',
        'classes': ['ZeroDiscoveryEngine', 'ArpScanner', 'SnmpScanner', 'MqttScanner', 'SmbScanner', 'UnauthCacheScanner'],
        'functions': ['discover_services_from_url'],
        'description': '内网资产发现 — ARP/SNMP/MQTT/SMB/Redis 协议探测',
    },
    'boto3_bucket_enhancer': {
        'file': 'scanners/boto3_bucket_enhancer.py',
        'flag': 'HAS_BOTO3_BUCKET_ENHANCER',
        'classes': ['EnhancedBucketEnumerator'],
        'functions': ['detect_cloud_buckets_enhanced'],
        'description': '增强版云存储桶枚举 — boto3 S3 + HTTP probe 多策略扫描',
    },
}
