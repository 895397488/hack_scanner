#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hack Scanner 扩展模块包
========================
从 Pentest-Swarm-AI 借鉴的新扫描器集合。

覆盖的漏洞类型（hack 原版缺失）：
- CRLF 注入 & HTTP 响应拆分              (crlf_detector)
- JWT Token 漏洞                         (jwt_detector)
- Subdomain Takeover (子域名接管)         (subdomain_takeover)
- GraphQL 安全检查                       (graphql_detector)
- HTTP Parameter Pollution               (http_param_pollution)
- OOB/Blind XSS / Blind SSRF             (oob_detector)
- Playbook 扫描工作流                    (playbooks)
"""

from .crlf_detector import CRLFInjectionDetector, HTTPRequestSmugglingDetector, WebCachePoisoningDetector
from .jwt_detector import JWTAnalyzer
from .subdomain_takeover import SubdomainTakeoverDetector, CloudBucketEnumerator
from .graphql_detector import GraphQLSecurityDetector, GraphQLEndpointFinder
from .http_param_pollution import HTTPParamPollutionDetector, ParamDiscoveryHelper
from .oob_detector import OOBInteractshClient, BlindXSXDetector, BlindSSRFDetector, BlindRSFDetector
from .playbooks import PlaybookRunner, FPFalsePositiveCache
from .skill_loader import (
    list_skills, load_skill, route_skills, build_prompt_block,
    SKILLS_DIR,
)
# ── Coverage Ledger 覆盖率账本（借鉴 Strix，与 Skill 系统配套）──
from .coverage_ledger import (
    CoverageLedger, VALID_OUTCOMES, OUTCOME_LABELS,
    SKILL_OBLIGATIONS, COVERAGE_FILENAME,
    skill_coverage_gaps, agent_coverage_gaps, unresolved_gaps,
    build_coverage_document, write_coverage, render_coverage_section,
    record_coverage, update_coverage, list_coverage,
    get_default_ledger, reset_default_ledger,
)
# ── LLM 成本核算（借鉴 Strix usage.py/pricing.py：token/费用按 agent 拆分）──
from .llm_cost import (
    LLMCostLedger, estimate_cost,
    COST_FILENAME, DEFAULT_PRICING_PER_MTK,
    load_pricing_from_config,
    get_default_cost_ledger, reset_default_cost_ledger,
    record_llm_usage, close_default_ledger,
)
# ── IDOR/BOLA 真实流量回放（借鉴 Strix caido_api：交叉身份重放）──
from .idor_replay import (
    scan_idor, normalize_sessions, extract_object_refs, swap_identity,
    body_similarity, fingerprint,
)

# ── Pentest-Swarm-AI Swarm 模块（Python 原生重写）──
from .swarm_playbooks import (
    get_playbook, get_all_playbooks, list_playbooks,
    execute_playbook, PlaybookExecutor, SwarmScanResult,
    get_pheromone, get_all_pheromone_types, PHEROMONES_CONFIG,
)
from .swarm_training_data import (
    generate_classifier_samples, generate_exploit_samples,
    generate_recon_samples, generate_report_samples,
    train_classifier_model, classify_severity,
    generate_all_samples, save_samples_to_jsonl, load_samples_from_jsonl,
)
from .swarm_legacy_bridge import (
    PentestAgent, PentestSession, SwarmOrchestrator,
    SimulateLLMEngine, APILLMEngine, ChatMessage,
)

# ── P0/P1 新集成模块 ──
try:
    from .waf_detector import detect_waf
except (ImportError, Exception):
    pass

from .sql_exploit import exploit_sqli
from .web_fuzzer import fuzz_paths, fuzz_params
from .osint_recon import osint_recon
from .ssl_deep_scan import ssl_deep_scan
from .network_scan import port_scan, masscan_ports, network_scan, host_discovery
from .file_meta import file_metadata, check_steganography
from .domain_similarity import find_typosquats, check_domain_similarity
from .dns_zone_transfer import dns_recon
from .cve_lookup import lookup_cve, check_package_vulns
from .webshell_detector import detect_webshells
from .domain_cert_monitor import cert_monitor, subdomains_from_cert
from .zap_scanner import zap_scan, zap_active_scan, zap_spider
from .git_secret_scanner import scan_git_repo, scan_git_remote
from .nuclei_scanner import nuclei_scan, nuclei_template_search
from .gobuster_wrapper import gobuster_dir, gobuster_vhost, gobuster_dns, gobuster
from .hydra_wrapper import hydra_http_post, hydra_ssh, hydra_ftp
from .google_dorker import google_dork, get_owasp_ghdb, dork_by_keyword

# ── P1/P2 外部工具 Wrapper（2026-08-25 新增）──
from .nikto_wrapper import nikto_web_scan
from .dirb_wrapper import dirb_scan
from .john_wrapper import john_crack, john_show, john_list_formats
from .ffuf_wrapper import ffuf_dir, ffuf_vhost, ffuf_dns
from .feroxbuster_wrapper import feroxbuster_scan
from .dirsearch_wrapper import dirsearch_scan
from .wpscan_wrapper import wpscan_scan
from .amass_wrapper import amass_enum
from .hakrawler_wrapper import hakrawler_crawl

# ── 工具自动检测（config.json 路径自愈，2026-09-07）──
# 换机器后 tools.*_path 全部失效时用；只补空/失效项，幂等
from .tool_detector import detect_tools, auto_update_config

# ── 攻防一体检测（YARA 规则引擎 + IOC 威胁情报，2026-09-12 新增）──
# 蓝队检测侧：YARA 扫 webshell/后门特征，IOC 对照恶意 IP/域名/URL/哈希。
try:
    from .yara_wrapper import yara_scan, yara_engine_status
    HAS_YARA = True
except (ImportError, Exception):
    HAS_YARA = False

try:
    from .ioc_detector import check_ioc, check_iocs, refresh_feeds, ioc_status
    HAS_IOC = True
except (ImportError, Exception):
    HAS_IOC = False

# ── P2 专项 Wrapper（2026-08-25 新增）──
try:
    from .hashcat_wrapper import hashcat_crack, hashcat_list_rules, hashcat_status
except (ImportError, Exception):
    HAS_HASHCAT = False
else:
    HAS_HASHCAT = True

try:
    from .exiftool_wrapper import exiftool_extract, exiftool_compare
except (ImportError, Exception):
    HAS_EXIFTOOL = False
else:
    HAS_EXIFTOOL = True

try:
    from .semgrep_wrapper import semgrep_scan
except (ImportError, Exception):
    HAS_SEMGREP = False
else:
    HAS_SEMGREP = True

try:
    from .trufflehog_wrapper import trufflehog_scan
except (ImportError, Exception):
    HAS_TRUFFLEHOG = False
else:
    HAS_TRUFFLEHOG = True

try:
    from .checkov_wrapper import checkov_scan
except (ImportError, Exception):
    HAS_CHECKOV = False
else:
    HAS_CHECKOV = True

try:
    from .trivy_wrapper import trivy_scan
except (ImportError, Exception):
    HAS_TRIVY = False
else:
    HAS_TRIVY = True

try:
    from .theharvester_wrapper import theharvester_recon
except (ImportError, Exception):
    HAS_THEHARVESTER = False
else:
    HAS_THEHARVESTER = True

try:
    from .sherlock_wrapper import sherlock_enum
except (ImportError, Exception):
    HAS_SHERLOCK = False
else:
    HAS_SHERLOCK = True

# ── Domain Utility（Acunetix public suffix list 精确解析）──
try:
    from .domain_util import PublicSuffixList, parse_domain, is_subdomain_of, get_psl
except (ImportError, Exception):
    pass

# ═══════════════════════════════════════════════════════
# Acunetix v25 借鉴新增模块（hack_scanner v7.0 升级）
# ═══════════════════════════════════════════════════════

# ── AcuSensor-Style Sensor (WAF 深度探测 + 服务器指纹) ──
try:
    from .acusensor_sensor import AcusensorSensor, SensorBridge, detect_with_sensor
except (ImportError, Exception):
    pass

# ── JS Rendering Scanner (Headless Browser 渲染分析) ──
try:
    from .js_render_scanner import JSRenderScanner, render_js_page
except (ImportError, Exception):
    pass

# ── Distributed Scan Messaging (NATS-style cluster coordination) ──
try:
    from .distributed_messaging import (
        ScanCluster, ScanTopic, WorkerState, WorkerNode,
        ScanMessage, ScanResult, LocalMessageBus,
        create_cluster, enum_distributed,
    )
except (ImportError, Exception):
    pass

# 统一导出新扫描器列表
ALL_NEW_SCANNERS = [
    'CRLFInjectionDetector',
    'HTTPRequestSmugglingDetector',
    'WebCachePoisoningDetector',
    'JWTAnalyzer',
    'SubdomainTakeoverDetector',
    'CloudBucketEnumerator',
    'GraphQLSecurityDetector',
    'GraphQLEndpointFinder',
    'HTTPParamPollutionDetector',
    'ParamDiscoveryHelper',
    'OOBInteractshClient',
    'BlindXSXDetector',
    'BlindSSRFDetector',
    'BlindRSFDetector',
    'PlaybookRunner',
    'FPFalsePositiveCache',
    'detect_waf',       # WAF 检测
    'exploit_sqli',     # SQLi 利用
    'fuzz_paths',       # 路径模糊测试
    'osint_recon',      # OSINT 侦察
    'ssl_deep_scan',    # SSL/TLS 深度分析
    'port_scan',        # nmap 端口扫描
    'file_metadata',    # 文件元数据/隐写检测
    'find_typosquats',  # 域名混淆检测
    'dns_recon',        # DNS 区域转移 + 记录查询
    'lookup_cve',       # CVE 查询 (NVD API)
    'detect_webshells', # Webshell 后门检测
    'yara_scan',        # YARA 规则引擎检测 (webshell/后门/恶意特征)
    'yara_engine_status',  # YARA 引擎自检
    'check_ioc',        # IOC 威胁情报检测 (单值)
    'check_iocs',       # IOC 威胁情报检测 (批量)
    'refresh_feeds',    # IOC 情报源刷新
    'ioc_status',       # IOC 引擎状态
    'cert_monitor',     # 证书透明度监控
    'zap_scan',         # OWASP ZAP 自动化扫描
    'scan_git_repo',    # Git 仓库密钥泄露检测
    'nuclei_scan',      # Nuclei 模板驱动漏洞扫描
    'gobuster_dir',     # GoBuster 目录/VHost/DNS 爆破
    'hydra_http_post',  # Hydra HTTP 登录暴力破解测试
    'google_dork',      # Google Hacking Dorks 侦察
    # ── P1/P2 外部工具 Wrapper（2026-08-25 新增）──
    'nikto_web_scan',       # Nikto Web 服务器审计
    'dirb_scan',            # DirBuster 目录爆破
    'john_crack',           # John the Ripper 离线 Hash 破解
    'john_show',            # John the Ripper 查看破解结果
    'john_list_formats',    # John the Ripper 支持的 Hash 格式
    'ffuf_dir',             # ffuf 目录爆破（Go 高速引擎）
    'ffuf_vhost',           # ffuf VHost 爆破
    'ffuf_dns',             # ffuf DNS 子域爆破
    'feroxbuster_scan',     # feroxbuster 目录爆破（Rust 最快引擎）
    'dirsearch_scan',       # Dirsearch 目录爆破（纯 Python）
    'wpscan_scan',          # WPScan WordPress 专项审计
    'amass_enum',           # amass 子域枚举（被动/主动）
    'hakrawler_crawl',      # hakrawler 爬虫（URL/JS 端点发现）
    'PublicSuffixList', # 公共后缀列表解析器
    'parse_domain',     # 注册域名提取快捷函数
    'is_subdomain_of',  # 子域名关系检测快捷函数
    'get_psl',          # 全局 PSL 实例（单例）
    # ── Acunetix v25 新增 ──
    'AcusensorSensor',  # AcuSensor 主动式 WAF 感知传感器
    'SensorBridge',     # 传感器桥接器（响应拦截分析）
    'detect_with_sensor',  # 快速 AcuSensor 探测
    'JSRenderScanner',  # JS 渲染引擎 + SPA 端点发现
    'render_js_page',   # 快速 JS 页面渲染
    'ScanCluster',      # 分布式扫描集群
    'ScanTopic',        # 扫描主题枚举
    'WorkerState',      # 工作节点状态
    'create_cluster',   # 快速创建集群
    'enum_distributed', # 分布式子域名枚举
]

# ── Acunetix 新增模块列表（供文档/清单使用） ──
ACUNETIX_MODULES = {
    'acu_sensor': {
        'file': 'scanners/acusensor_sensor.py',
        'description': 'AcuSensor-Style WAF 主动感知传感器 — 探测 WAF/CDN/IPS 防护机制，模拟 AcuSensor 多语言探针部署',
        'classes': ['AcusensorSensor', 'SensorBridge'],
        'features': [
            'WAF 深度指纹识别（50+ WAF 产品）',
            'CDN 边缘节点检测',
            '敏感请求头注入探测',
            'Cookie 篡改检测',
            '参数探针注入分析',
            '服务器技术栈指纹识别',
            '传感器绕过可能性评估',
        ],
    },
    'js_renderer': {
        'file': 'scanners/js_render_scanner.py',
        'description': 'Headless Browser JS 渲染引擎 — 渲染 SPA/Rails/Vue/Angular 页面，发现隐藏 API 端点',
        'classes': ['JSRenderScanner'],
        'features': [
            'Selenium/Playwright 双引擎支持',
            '前端框架指纹识别（React/Vue/Angular/Next.js/Nuxt/Svelte...）',
            '状态管理检测（Redux/Vuex/MobX/NgRx/Pinia/Zustand）',
            'SPA 路由定义提取',
            'XHR/Fetch API 端点发现',
            'Console 日志捕获',
            '隐藏元素和配置数据提取',
            '无依赖 HTTP+JS 源码回退方案',
        ],
    },
    'distributed': {
        'file': 'scanners/distributed_messaging.py',
        'description': 'NATS-Style 分布式扫描协调器 — 多节点任务分发、结果汇聚、状态同步',
        'classes': ['ScanCluster', 'LocalMessageBus', 'WorkerNode', 'ScanTopic'],
        'features': [
            'Topic-based 消息路由（20+ 预定义主题）',
            '本地内存总线（无需外部 NATS 服务器）',
            '动态工作节点管理（spawn/remove/heartbeat）',
            '集群健康状态监控',
            '紧急停止机制',
            '分布式子域名枚举示例应用',
        ],
    },
    'domain_util': {
        'file': 'scanners/domain_util.py',
        'description': '精确域名解析器 — 基于 Acunetix public_suffix_list.dat (13626+ 条记录)',
        'classes': ['PublicSuffixList'],
        'features': [
            '注册域名提取（www.example.co.uk → example.co.uk）',
            '子域名合法性验证',
            '通配符规则支持 (*.example.com)',
            '异常规则支持 (!example.com)',
            '全局单例实例（get_psl）',
        ],
    },
}

# ═══════════════════════════════════════════════════════
# 扩展扫描器（可选依赖，按需提供）
# ═══════════════════════════════════════════════════════

# ── MITM Proxy Scanner ──
try:
    from .mitm_proxy_scanner import MitmProxyServer, CertFactory
    HAS_MITM_PROXY = True
except (ImportError, Exception):
    HAS_MITM_PROXY = False

# ── Scan Profiles ──
try:
    from .scan_profiles import ScanProfile, ProfileManager, apply_profile, list_profiles
    HAS_SCAN_PROFILES = True
except (ImportError, Exception):
    HAS_SCAN_PROFILES = False

# ── WAF Rule Generator ──
try:
    from .waf_rule_generator import (
        RuleGenerator,
        F5IRuleExporter,
        CloudflareWafRuleExporter,
        ModSecurityExporter,
    )
    HAS_WAF_RULE_GENERATOR = True
except (ImportError, Exception):
    HAS_WAF_RULE_GENERATOR = False

# ── Certificate Factory ──
try:
    from .cert_factory import MITMCA, FakeCertGenerator, CertCache
    HAS_CERT_FACTORY = True
except (ImportError, Exception):
    HAS_CERT_FACTORY = False

# ── AcuSensor Language Sensor Deployer ──
try:
    from .acusensor_lang_deploy import AcuSensorLangDetector, detect_server_language, generate_sensor_probes_for_url
    HAS_ACUSENSOR_LANG = True
except (ImportError, Exception):
    HAS_ACUSENSOR_LANG = False

# ── ZeroDiscovery: Inner Network Asset Discovery ──
try:
    from .zero_discovery import (
        ZeroDiscoveryEngine, ArpScanner, SnmpScanner,
        MqttScanner, SmbScanner, UnauthCacheScanner, discover_services_from_url
    )
    HAS_ZERO_DISCOVERY = True
except (ImportError, Exception):
    HAS_ZERO_DISCOVERY = False

# ── Enhanced CloudBucket Enumerator with boto3 ──
try:
    from .boto3_bucket_enhancer import EnhancedBucketEnumerator, detect_cloud_buckets_enhanced
    HAS_BOTO3_BUCKET_ENHANCER = True
except (ImportError, Exception):
    HAS_BOTO3_BUCKET_ENHANCER = False

# ── Windows 文件所有权接管（TakeOwnershipPro v1.6 功能移植 + 锁定进程处理 + VSS 读取）──
try:
    from .ownership_take import (
        take_ownership, get_owner, check_admin,
        find_locking_processes, kill_locking_processes, read_via_vss,
    )
    HAS_OWNERSHIP_TAKE = True
except (ImportError, Exception):
    HAS_OWNERSHIP_TAKE = False

# ── 文件相关程序进程树强杀（解锁 Edge/WebView2 等"被占用"程序，2026-09-13 新增）──
# 三通道识别（进程映像/加载模块/打开句柄）+ 整棵进程树分级强杀（taskkill /F /T →
# psutil kill → sc stop 相关服务重试 → 终验）；PPL 受保护进程诚实报告
try:
    from .process_tree_kill import (
        find_related_processes, kill_process_tree, find_services_under,
    )
    HAS_PROCESS_TREE_KILL = True
except (ImportError, Exception):
    HAS_PROCESS_TREE_KILL = False

# 统一导出（含可选模块）
__all__ = [
    # --- 必选扫描器 ---
    'CRLFInjectionDetector',
    'HTTPRequestSmugglingDetector',
    'WebCachePoisoningDetector',
    'JWTAnalyzer',
    'SubdomainTakeoverDetector',
    'CloudBucketEnumerator',
    'GraphQLSecurityDetector',
    'GraphQLEndpointFinder',
    'HTTPParamPollutionDetector',
    'ParamDiscoveryHelper',
    'OOBInteractshClient',
    'BlindXSXDetector',
    'BlindSSRFDetector',
    'BlindRSFDetector',
    'PlaybookRunner',
    'FPFalsePositiveCache',
    # Skill 系统（LLM 测试方法论技能库）
    'list_skills', 'load_skill', 'route_skills', 'build_prompt_block', 'SKILLS_DIR',
    # Coverage Ledger 覆盖率账本（Strix 借鉴：检查了什么、每项怎么收尾）
    'CoverageLedger', 'VALID_OUTCOMES', 'OUTCOME_LABELS', 'SKILL_OBLIGATIONS',
    'COVERAGE_FILENAME', 'skill_coverage_gaps', 'agent_coverage_gaps', 'unresolved_gaps',
    'build_coverage_document', 'write_coverage', 'render_coverage_section',
    'record_coverage', 'update_coverage', 'list_coverage',
    'get_default_ledger', 'reset_default_ledger',
    # LLM 成本核算（Strix 借鉴：本次扫描花了多少钱，按 agent 拆分）
    'LLMCostLedger', 'estimate_cost', 'COST_FILENAME', 'DEFAULT_PRICING_PER_MTK',
    'load_pricing_from_config',
    'get_default_cost_ledger', 'reset_default_cost_ledger',
    'record_llm_usage', 'close_default_ledger',
    # IDOR/BOLA 真实流量回放（Strix caido_api 借鉴）
    'scan_idor', 'normalize_sessions', 'extract_object_refs', 'swap_identity',
    'body_similarity', 'fingerprint',
    'detect_waf',
    'exploit_sqli',
    'fuzz_paths',
    'fuzz_params',
    'osint_recon',
    'ssl_deep_scan',
    'port_scan',
    'masscan_ports',
    'network_scan',
    'host_discovery',
    'file_metadata',
    'check_steganography',
    'find_typosquats',
    'check_domain_similarity',
    'dns_recon',
    'lookup_cve',
    'check_package_vulns',
    'detect_webshells',
    'cert_monitor',
    'subdomains_from_cert',
    'zap_scan',
    'zap_active_scan',
    'zap_spider',
    'scan_git_repo',
    'scan_git_remote',
    'nuclei_scan',
    'nuclei_template_search',
    'gobuster_dir',
    'gobuster_vhost',
    'gobuster_dns',
    'gobuster',
    'hydra_http_post',
    'hydra_ssh',
    'hydra_ftp',
    'google_dork',
    'get_owasp_ghdb',
    'dork_by_keyword',
    # ── P1/P2 外部工具 Wrapper（2026-08-25 新增）──
    'nikto_web_scan',
    'dirb_scan',
    'john_crack',
    'john_show',
    'john_list_formats',
    'ffuf_dir',
    'ffuf_vhost',
    'ffuf_dns',
    'feroxbuster_scan',
    'dirsearch_scan',
    'wpscan_scan',
    'amass_enum',
    'hakrawler_crawl',
    # ── 工具自动检测（config.json 路径自愈）──
    'detect_tools',
    'auto_update_config',
    # ── 攻防一体检测（YARA + IOC，2026-09-12）──
    'yara_scan',
    'yara_engine_status',
    'check_ioc',
    'check_iocs',
    'refresh_feeds',
    'ioc_status',
    # ── P2 专项 Wrapper（可选，HAS_ 标志控制）──
    'hashcat_crack',        # hashcat (HAS_HASHCAT)
    'hashcat_list_rules',   # hashcat (HAS_HASHCAT)
    'hashcat_status',       # hashcat (HAS_HASHCAT)
    'exiftool_extract',     # exiftool (HAS_EXIFTOOL)
    'exiftool_compare',     # exiftool (HAS_EXIFTOOL)
    'semgrep_scan',         # semgrep (HAS_SEMGREP)
    'trufflehog_scan',      # trufflehog (HAS_TRUFFLEHOG)
    'checkov_scan',         # checkov (HAS_CHECKOV)
    'trivy_scan',           # trivy (HAS_TRIVY)
    'theharvester_recon',   # theHarvester (HAS_THEHARVESTER)
    'sherlock_enum',        # sherlock (HAS_SHERLOCK)
    'PublicSuffixList',
    'parse_domain',
    'is_subdomain_of',
    'get_psl',
    'AcusensorSensor',
    'SensorBridge',
    'detect_with_sensor',
    'JSRenderScanner',
    'render_js_page',
    'ScanCluster',
    'ScanTopic',
    'WorkerState',
    'WorkerNode',
    'ScanMessage',
    'ScanResult',
    'LocalMessageBus',
    'create_cluster',
    'enum_distributed',
    # --- 可选扫描器（仅当对应 HAS_ = True 时可用）---
    'MitmProxyServer',      # mitm_proxy_scanner (HAS_MITM_PROXY)
    'CertFactory',          # mitm_proxy_scanner (HAS_MITM_PROXY)
    'ScanProfile',          # scan_profiles (HAS_SCAN_PROFILES)
    'ProfileManager',       # scan_profiles (HAS_SCAN_PROFILES)
    'apply_profile',        # scan_profiles (HAS_SCAN_PROFILES)
    'list_profiles',        # scan_profiles (HAS_SCAN_PROFILES)
    'RuleGenerator',        # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'F5IRuleExporter',      # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'CloudflareWafRuleExporter',  # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'ModSecurityExporter',  # waf_rule_generator (HAS_WAF_RULE_GENERATOR)
    'MITMCA',               # cert_factory (HAS_CERT_FACTORY)
    'FakeCertGenerator',    # cert_factory (HAS_CERT_FACTORY)
    'CertCache',            # cert_factory (HAS_CERT_FACTORY)
    # ── 新增模块导出 ──
    'AcuSensorLangDetector',
    'detect_server_language',
    'generate_sensor_probes_for_url',
    'ZeroDiscoveryEngine',
    'ArpScanner',
    'SnmpScanner',
    'MqttScanner',
    'SmbScanner',
    'UnauthCacheScanner',
    'discover_services_from_url',
    'EnhancedBucketEnumerator',
    'detect_cloud_buckets_enhanced',
    # ── Windows 文件所有权接管（TakeOwnershipPro 移植）──
    'take_ownership',
    'get_owner',
    'check_admin',
    'find_locking_processes',
    'kill_locking_processes',
    'read_via_vss',
    # ── 文件相关程序进程树强杀（2026-09-13 新增）──
    'find_related_processes',
    'kill_process_tree',
    'find_services_under',
]

# ═══════════════════════════════════════════════════════
# 可选模块清单（供文档/清单使用）
# ═══════════════════════════════════════════════════════

OPTIONAL_MODULES = {
    'mitm_proxy_scanner': {
        'file': 'scanners/mitm_proxy_scanner.py',
        'flag': 'HAS_MITM_PROXY',
        'classes': ['MitmProxyServer', 'CertFactory'],
        'description': 'MITM 代理扫描器 — 中间人 TLS 解密与证书动态生成',
    },
    'scan_profiles': {
        'file': 'scanners/scan_profiles.py',
        'flag': 'HAS_SCAN_PROFILES',
        'classes': ['ScanProfile', 'ProfileManager'],
        'functions': ['apply_profile', 'list_profiles'],
        'description': '扫描配置文件 — 可复用扫描参数模板与加载器',
    },
    'waf_rule_generator': {
        'file': 'scanners/waf_rule_generator.py',
        'flag': 'HAS_WAF_RULE_GENERATOR',
        'classes': ['RuleGenerator', 'F5IRuleExporter', 'CloudflareWafRuleExporter', 'ModSecurityExporter'],
        'description': 'WAF 规则生成器 — 跨平台导出（F5 iRules / Cloudflare WAF / ModSecurity）',
    },
    'cert_factory': {
        'file': 'scanners/cert_factory.py',
        'flag': 'HAS_CERT_FACTORY',
        'classes': ['MITMCA', 'FakeCertGenerator', 'CertCache'],
        'description': '证书工厂 — MITM CA 签发、伪造证书、证书缓存管理',
    },
    'acusensor_lang_deploy': {
        'file': 'scanners/acusensor_lang_deploy.py',
        'flag': 'HAS_ACUSENSOR_LANG',
        'classes': ['AcuSensorLangDetector'],
        'functions': ['detect_server_language', 'generate_sensor_probes_for_url'],
        'description': 'AcuSensor 多语言传感器部署 — PHP/JAR/Node.js/.NET 服务端指纹与探针注入',
    },
    'zero_discovery': {
        'file': 'scanners/zero_discovery.py',
        'flag': 'HAS_ZERO_DISCOVERY',
        'classes': ['ZeroDiscoveryEngine', 'ArpScanner', 'SnmpScanner', 'MqttScanner', 'SmbScanner', 'UnauthCacheScanner'],
        'functions': ['discover_services_from_url'],
        'description': '内网资产发现 — ARP/SNMP/MQTT/SMB/Redis 协议探测',
    },
    'boto3_bucket_enhancer': {
        'file': 'scanners/boto3_bucket_enhancer.py',
        'flag': 'HAS_BOTO3_BUCKET_ENHANCER',
        'classes': ['EnhancedBucketEnumerator'],
        'functions': ['detect_cloud_buckets_enhanced'],
        'description': '增强版云存储桶枚举 — boto3 S3 + HTTP probe 多策略扫描',
    },
    'ownership_take': {
        'file': 'scanners/ownership_take.py',
        'flag': 'HAS_OWNERSHIP_TAKE',
        'functions': ['take_ownership', 'get_owner', 'check_admin',
                      'find_locking_processes', 'kill_locking_processes',
                      'read_via_vss'],
        'description': 'Windows 文件/文件夹所有权接管 + 授权（TakeOwnershipPro v1.6 移植）— takeown 改所有者 + icacls 授权 Everyone/Administrators；可检测锁定文件的目标进程（psutil）并可选终止后重试；可用 VSS 卷影读出被锁文件内容（read_via_vss）。用于解锁锁定文件/恶意软件取证/事件响应',
    },
    'process_tree_kill': {
        'file': 'scanners/process_tree_kill.py',
        'flag': 'HAS_PROCESS_TREE_KILL',
        'functions': ['find_related_processes', 'kill_process_tree', 'find_services_under'],
        'description': '文件相关程序进程树强杀（解锁 Edge/WebView2 等"被占用"程序，2026-09-13 新增）— 三通道识别（进程映像/加载模块/打开句柄）+ 整棵进程树分级强杀（taskkill /F /T → psutil kill → sc stop 相关服务重试 → 终验）；PPL 受保护进程诚实报告不硬杀。用于解锁锁定文件/事件响应',
    },
}

# ═══════════════════════════════════════════════════════
# 外部工具 Wrapper 清单（2026-08-25 集成批次）
# 来源对照：hack_scanner工具集成清单.md（hexstrike-ai 工具对齐）
# ═══════════════════════════════════════════════════════

NEW_TOOL_WRAPPERS = {
    # ── P1 占位补全 ──
    'nikto_wrapper': {
        'file': 'scanners/nikto_wrapper.py',
        'functions': ['nikto_web_scan'],
        'config_key': 'tools.nikto_path',
        'description': 'Nikto Web 服务器审计 — 过时软件/危险文件/HTTP 头检查',
    },
    'dirb_wrapper': {
        'file': 'scanners/dirb_wrapper.py',
        'functions': ['dirb_scan'],
        'config_key': 'tools.dirb_path',
        'description': 'DirBuster 目录爆破 — Perl 实现的经典目录枚举',
    },
    'john_wrapper': {
        'file': 'scanners/john_wrapper.py',
        'functions': ['john_crack', 'john_show', 'john_list_formats'],
        'config_key': 'tools.john_path',
        'description': 'John the Ripper 离线 Hash 破解 — 补 hydra 在线爆破空缺',
    },
    # ── P2 目录爆破备选引擎 ──
    'ffuf_wrapper': {
        'file': 'scanners/ffuf_wrapper.py',
        'functions': ['ffuf_dir', 'ffuf_vhost', 'ffuf_dns'],
        'config_key': 'tools.ffuf_path',
        'description': 'ffuf 高速 Fuzzing — Go 编写，目录/VHost/DNS 三模式',
    },
    'feroxbuster_wrapper': {
        'file': 'scanners/feroxbuster_wrapper.py',
        'functions': ['feroxbuster_scan'],
        'config_key': 'tools.feroxbuster_path',
        'description': 'feroxbuster 目录爆破 — Rust 编写，大目标首选',
    },
    'dirsearch_wrapper': {
        'file': 'scanners/dirsearch_wrapper.py',
        'functions': ['dirsearch_scan'],
        'config_key': 'tools.dirsearch_path',
        'description': 'Dirsearch 目录爆破 — 纯 Python，Windows 安装最方便',
    },
    # ── P2 专项扫描 ──
    'wpscan_wrapper': {
        'file': 'scanners/wpscan_wrapper.py',
        'functions': ['wpscan_scan'],
        'config_key': 'tools.wpscan_path',
        'description': 'WPScan WordPress 专项审计 — 插件/主题/用户枚举 + 漏洞匹配',
    },
    'amass_wrapper': {
        'file': 'scanners/amass_wrapper.py',
        'functions': ['amass_enum'],
        'config_key': 'tools.amass_path',
        'description': 'amass 子域枚举 — 被动/主动/被动+主动三模式',
    },
    'hakrawler_wrapper': {
        'file': 'scanners/hakrawler_wrapper.py',
        'functions': ['hakrawler_crawl'],
        'config_key': 'tools.hakrawler_path',
        'description': 'hakrawler 爬虫 — URL/JS 端点发现，原生 crawler.py 对照引擎',
    },
    # ── P2 密码破解/文件元数据 ──
    'hashcat_wrapper': {
        'file': 'scanners/hashcat_wrapper.py',
        'flag': 'HAS_HASHCAT',
        'functions': ['hashcat_crack', 'hashcat_list_rules', 'hashcat_status'],
        'config_key': 'tools.hashcat_path',
        'description': 'hashcat GPU 离线破解 — 与 hydra(在线)/john(CPU) 互补',
    },
    'exiftool_wrapper': {
        'file': 'scanners/exiftool_wrapper.py',
        'flag': 'HAS_EXIFTOOL',
        'functions': ['exiftool_extract', 'exiftool_compare'],
        'config_key': 'tools.exiftool_path',
        'description': 'exiftool 元数据提取 — file_meta.py(exifread) 的增强备选',
    },
    # ── P2 白盒 SAST/IaC/依赖审计 ──
    'semgrep_wrapper': {
        'file': 'scanners/semgrep_wrapper.py',
        'flag': 'HAS_SEMGREP',
        'functions': ['semgrep_scan'],
        'config_key': 'tools.semgrep_path',
        'description': 'Semgrep SAST — CI/CD playbook 已点名，多语言漏洞规则引擎',
    },
    'trufflehog_wrapper': {
        'file': 'scanners/trufflehog_wrapper.py',
        'flag': 'HAS_TRUFFLEHOG',
        'functions': ['trufflehog_scan'],
        'config_key': 'tools.trufflehog_path',
        'description': 'TruffleHog 密钥泄露检测 — git_secret_scanner(gitleaks) 双引擎',
    },
    'checkov_wrapper': {
        'file': 'scanners/checkov_wrapper.py',
        'flag': 'HAS_CHECKOV',
        'functions': ['checkov_scan'],
        'config_key': 'tools.checkov_path',
        'description': 'Checkov IaC 静态分析 — Terraform/CloudFormation/K8s 配置审计',
    },
    'trivy_wrapper': {
        'file': 'scanners/trivy_wrapper.py',
        'flag': 'HAS_TRIVY',
        'functions': ['trivy_scan'],
        'config_key': 'tools.trivy_path',
        'description': 'Trivy 依赖/镜像/文件系统漏洞扫描 — playbook dependency audit 步骤',
    },
    # ── P2 OSINT 增强 ──
    'theharvester_wrapper': {
        'file': 'scanners/theharvester_wrapper.py',
        'flag': 'HAS_THEHARVESTER',
        'functions': ['theharvester_recon'],
        'config_key': 'tools.theharvester_path',
        'description': 'theHarvester OSINT — 邮箱/hostname/子域公开情报收集',
    },
    'sherlock_wrapper': {
        'file': 'scanners/sherlock_wrapper.py',
        'flag': 'HAS_SHERLOCK',
        'functions': ['sherlock_enum'],
        'config_key': 'tools.sherlock_path',
        'description': 'Sherlock 社交账号枚举 — 300+ 社交平台用户名撞库',
    },
}

# ═══════════════════════════════════════════════════════
# 攻防一体检测模块（2026-09-12 新增）
# 蓝队检测侧：与攻击侧闭环 —— 攻击种 payload → 检测验证能否被检出
# ═══════════════════════════════════════════════════════

OFFENSE_DEFENSE_MODULES = {
    'yara_wrapper': {
        'file': 'scanners/yara_wrapper.py',
        'flag': 'HAS_YARA',
        'functions': ['yara_scan', 'yara_engine_status'],
        'config_key': 'tools.yara_path',
        'rules_dir': 'scanners/yara_rules',
        'description': 'YARA 规则引擎检测 — webshell/后门/恶意样本特征，内置 webshell.yar 规则包，'
                       '支持用户自定义规则目录。纯 CLI 调用，无 C 扩展依赖',
    },
    'ioc_detector': {
        'file': 'scanners/ioc_detector.py',
        'flag': 'HAS_IOC',
        'functions': ['check_ioc', 'check_iocs', 'refresh_feeds', 'ioc_status'],
        'config_key': 'ioc',
        'description': 'IOC/威胁情报检测 — 对照 URLhaus/MalwareDomainList/Spamhaus-DROP '
                       '匹配恶意 IP/域名/URL/文件哈希；本地缓存(24h TTL)+离线降级，纯 Python+requests',
    },
}

# ═══════════════════════════════════════════════════════
# Acunetix v25 能力迁移新增模块（hack_scanner v8.0+）
# ═══════════════════════════════════════════════════════

# ── DeepScan Recursive Web Crawler (P0) ──
try:
    from .crawler import DeepScanCrawler, CrawlConfig, CrawlResult, crawl_url
except (ImportError, Exception):
    pass

# ── Auth Session Manager (P0) ──
try:
    from .auth_session import AuthSession, LoginSequence, LoginFormInfo, LoginFormField, auto_login
except (ImportError, Exception):
    pass

# ── WAF/IPS Evasion Engine (P1) ──
try:
    from .waf_bypass import WAFEvasionEngine, EvasionTechnique, detect_waf_and_encode
except (ImportError, Exception):
    pass

# ── Multi-Format Report Export Engine (P1) ──
try:
    from .export_engine import (
        ExportEngine, CSVEporter, MarkdownExporter, RstExporter,
        DvcsExporter, PdfExporter, SarifExporter, generate_all_formats, normalize_scan_results,
    )
except (ImportError, Exception):
    pass

# ── Login Sequence Recorder LSR (P1) ──
try:
    from .login_sequence import (
        LoginSequenceRecorder, RecordedSequence, LoginStep,
        record_login_sequence, replay_sequence_from_file,
    )
except (ImportError, Exception):
    pass

# ── SSO / MFA / SAML Testing Module (P2) ──
try:
    from .ssoprobe import (
        SSPROBE, SSOProviderInfo, MFAResult, SAMLInfo,
        detect_sso_providers, test_saml_vulnerabilities, test_oauth2_vulnerabilities,
        detect_mfa_type, ssoprobe,
    )
except (ImportError, Exception):
    pass

# ── Continuous Scan + Regression Framework (P2) ──
try:
    from .continuous_scan import (
        ContinuousScanManager, Target, ScanRecord, RegressionReport,
        create_continuous_manager, add_target,
    )
except (ImportError, Exception):
    pass

# ── Acunetix 能力迁移模块清单 ──
ACUNETIX_MIGRATION_MODULES = {
    'deepscan_crawler': {
        'file': 'scanners/crawler.py',
        'description': 'DeepScan 递归 Web 站点爬虫引擎 — 三层爬取（HTTP/Selenium/Playwright）+ 域名范围限定 + SPA 检测',
        'classes': ['DeepScanCrawler', 'CrawlConfig', 'CrawlResult'],
        'features': [
            '递归 URL 发现（深度优先 + 并发控制）',
            '域名 scope 限定（基于 public_suffix_list.dat 的 registrable domain 检测）',
            'Robots.txt 合规',
            'SPA 框架检测 & JS XHR/Fetch 监听',
            '表单提取与结构解析',
            '技术栈指纹识别',
            'Rate limiting 防 DoS',
        ],
    },
    'auth_session': {
        'file': 'scanners/auth_session.py',
        'description': '认证会话管理器 — 借鉴 Acunetix SiteLogin（自动表单检测、Cookie/Token 持久化、OAuth2/mTLS）',
        'classes': ['AuthSession', 'LoginSequence', 'LoginFormInfo'],
        'features': [
            'Form-based auto-login（自动检测登录表单）',
            'Cookie/token 持久化 across scan requests',
            'OAuth2 access-token injection',
            'Client certificate (mTLS) authentication',
            'Custom per-URL-scope HTTP headers & cookies',
            'Login success/failure detection',
        ],
    },
    'waf_bypass': {
        'file': 'scanners/waf_bypass.py',
        'description': 'WAF/IPS 绕过引擎 — payload 编码、HTTP 参数分裂、Header manipulation、Case randomization',
        'classes': ['WAFEvasionEngine'],
        'features': [
            'Payload encoding（URL/hex/UTF-8/double-URL/HTML entity/null-byte）',
            'HTTP parameter pollution (param splitting)',
            'Header manipulation bypass',
            'Case randomization for pattern-matching WAFs',
            'Null-byte insertion on trigger characters',
        ],
    },
    'export_engine': {
        'file': 'scanners/export_engine.py',
        'description': '多格式报告导出引擎 — PDF/CSV/Markdown/RST/DVCS/SARIF（mirrors Acunetix /exports API）',
        'classes': ['ExportEngine', 'CSVEporter', 'MarkdownExporter', 'RstExporter', 'DvcsExporter', 'PdfExporter', 'SarifExporter'],
        'features': [
            'PDF export (weasyprint/wkhtmltopdf fallback)',
            'CSV tabular export',
            'Markdown with SRC report style',
            'RST reStructuredText',
            'DVCS XML format (DevCraft Vulnerability Scan compatible)',
            'SARIF 2.1.0 (OASIS) — GitHub Code Scanning / CI 安全门禁（CWE 规则键 + security-severity + partialFingerprints）',
            'Multi-format batch export',
        ],
    },
    'login_sequence': {
        'file': 'scanners/login_sequence.py',
        'description': '登录序列录制器 (LSR) — 录制多步登录流程（含2FA/captcha/redirect），支持重放用于认证扫描',
        'classes': ['LoginSequenceRecorder', 'RecordedSequence', 'LoginStep'],
        'features': [
            '多步认证录制（login -> 2FA -> captcha -> redirect）',
            '表单字段自动检测',
            'Session token/cookie capture',
            '每步骤截图验证',
            '序列重放用于 authenticated scanning',
            'JSON 序列化保存/加载',
        ],
    },
    'ssoprobe': {
        'file': 'scanners/ssoprobe.py',
        'description': 'SSO/MFA/SAML 测试模块 — 检测 Okta/Google/AzureAD/ADFS 配置，测试 SAML/OAuth2/MFA 漏洞',
        'classes': ['SSPROBE', 'SSOProviderInfo', 'MFAResult', 'SAMLInfo'],
        'features': [
            'SSO provider 检测（Okta/Google/AzureAD/ADFS/Auth0/Keycloak...）',
            'SAML 签名绕过测试、弱算法检测',
            'OAuth2 flow probing (implicit/hybrid/code)',
            'MFA type 检测 + TOTP/HOTP brute-force feasibility',
            'Client certificate (mTLS) detection',
            'Session fixation vulnerability detection',
        ],
    },
    'continuous_scan': {
        'file': 'scanners/continuous_scan.py',
        'description': '持续扫描 + 回归检测框架 — 定时目标扫描、结果比对、漏洞趋势分析',
        'classes': ['ContinuousScanManager', 'Target', 'ScanRecord', 'RegressionReport'],
        'features': [
            'Target list management with schedule (hourly/daily/weekly/monthly)',
            '增量扫描（仅扫描变更页面）',
            '回归检测（新增/消失/严重程度变化）',
            '扫描历史与趋势分析',
            '磁盘持久化 scan history',
            'Regressionscore 加权评分',
        ],
    },
}

# ═══════════════════════════════════════════════════════
# w3af 能力迁移模块（hack_scanner v8.0+）
# ═══════════════════════════════════════════════════════

# ── PII / Credential Grep Engine (from w3af grep plugins) ──
try:
    from .w3af_pii_grep import PIIGrepEngine, PIIFinding, detect_pii_in_text
except (ImportError, Exception):
    pass

# ── Bloom Filter URL Deduplication (from w3af scalable_bloom.py) ──
try:
    from .w3af_bloom_filter import ScalableBloomFilter, SeekFileBloom, URLDeduplicator, get_global_bloom
except (ImportError, Exception):
    pass

# ── Timing Attack Detector (from w3af blind_sqli timing attack) ──
try:
    from .w3af_timing_detector import TimingAttackDetector, TimingResult, detect_blind_sqli_by_timing
except (ImportError, Exception):
    pass

# ── Payload Manipulation Engine (from w3af mangle_plugin + tools/) ──
try:
    from .w3af_payload_engine import PayloadEngine, PayloadVariant
except (ImportError, Exception):
    pass

# ── Vulnerability Pattern Database (from w3af vulns.py + all audit plugins) ──
try:
    from .w3af_vuln_patterns import VulnPatternDB, VulnPatternFinding, check_for_patterns
except (ImportError, Exception):
    pass

# ── Proxy Daemon (from w3af daemons/proxy.py) ──
try:
    from .w3af_proxy_server import ProxyDaemon, InterceptedRequest, ProxyRule, start_proxy
except (ImportError, Exception):
    pass

# ── ACUNETIX_MODULES (already defined above) + W3AF MODULES ──
W3AF_MIGRATION_MODULES = {
    'pii_grep': {
        'file': 'scanners/w3af_pii_grep.py',
        'description': 'PII/敏感数据 Grep 引擎 — 从 w3af grep 插件移植，扫描响应中的信用卡号、API Key、密码等',
        'classes': ['PIIGrepEngine'],
        'features': [
            '信用卡号检测 (Visa/MC/Amex/Discover/JCB)',
            'SSN / 国家身份证号码检测',
            'AWS/GCP/Azure 凭证检测',
            'JWT Token、Slack token、SendGrid key',
            '密码硬编码检测 (PHP/JS/Python/YAML/MySQL URL)',
            'MongoDB/PostgreSQL/Redis 连接字符串中的密码检测',
            '邮箱地址与电话号码提取',
            'ReDoS / SSRF / LFI / RFI 模式匹配',
        ],
    },
    'bloom_filter': {
        'file': 'scanners/w3af_bloom_filter.py',
        'description': '布隆过滤器 URL 去重 — 从 w3af scalable_bloom.py 移植，大规模扫描中高效去重已探测 URL',
        'classes': ['ScalableBloomFilter', 'SeekFileBloom', 'URLDeduplicator'],
        'features': [
            '动态增长布隆过滤器 (0.1% false positive)',
            'O(1) 添加/查询操作',
            '磁盘持久化 SeekFileBloom (长时间扫描会话)',
            '全局单例 global_bloom',
            'URL 规范化去重 (canonicalize + sort params)',
        ],
    },
    'timing_detector': {
        'file': 'scanners/w3af_timing_detector.py',
        'description': '盲注时间延迟攻击检测 — 从 w3af blind_sqli timing attack 移植，精确/近似时间测量',
        'classes': ['TimingAttackDetector'],
        'features': [
            'MySQL SLEEP()/benchmark() 检测',
            'PostgreSQL pg_sleep() 检测',
            'MS SQL WAITFOR DELAY 检测',
            'Oracle DBMS_UTILITY.TIME_DELAY 检测',
            'SQLite 盲注时间差检测',
            '多轮统计验证降低网络噪声影响',
            'DBMS 自动识别',
        ],
    },
    'payload_engine': {
        'file': 'scanners/w3af_payload_engine.py',
        'description': '载荷变异引擎 — 从 w3af mangle_plugin + tools/ 移植，完整 payload 编码/解码/mutation',
        'classes': ['PayloadEngine'],
        'features': [
            'URL 双层编码、Hex编码、Unicode编码',
            'Base64 编解码 (w3af base64encode/decode)',
            'MD5 / SHA1 / SHA256 哈希 (w3af md5hash/sha1hash)',
            'SQL/XSS/LFI/RFI/SSRF/命令注入 mutation',
            'WAF 绕过编码变体 (8种技术)',
            'GET→POST / POST→GET 转换 (CommonAttackMethods)',
        ],
    },
    'vuln_patterns': {
        'file': 'scanners/w3af_vuln_patterns.py',
        'description': '漏洞模式数据库 — 从 w3af vulns.py + 所有 audit 插件提取的完整漏洞检测模式库',
        'classes': ['VulnPatternDB'],
        'features': [
            'SQL注入 (MySQL/PostgreSQL/MSSQL/Oracle/SQLite)',
            'XSS 反射/存储型/DOM-based 检测',
            'CSRF Token 缺失检测',
            'LDAP/XPath 注入检测',
            'ReDoS / SSRF / RFI / LFI',
            'Server-Side Include / PHP Info / ShellShock',
            'SSL/TLS 配置问题 / Open Redirect / Phishing Vector',
            'Insecure DAV / Response Splitting / Eval Injection',
            'preg_replace 不安全使用 / MX Injection',
        ],
    },
    'proxy_server': {
        'file': 'scanners/w3af_proxy_server.py',
        'description': '本地代理服务器 — 从 w3af daemons/proxy.py 移植，MITM HTTP/HTTPS 中间人代理',
        'classes': ['ProxyDaemon'],
        'features': [
            'HTTP 明文代理 (本地端口转发)',
            'HTTPS SSL stripping (降级为明文)',
            '请求拦截/篡改/注入测试载荷',
            '响应修改检测防御机制',
            '规则系统支持 block/modify/redirect/log',
            'MITM 扫描中间人攻击场景模拟',
        ],
    },
}

# ── Combined scan modules list ──
ALL_ACUNETIX_W3AF_MODULES = {**ACUNETIX_MIGRATION_MODULES, **W3AF_MIGRATION_MODULES}


# ═══════════════════════════════════════════════════════
# Swarm AI 模块（Pentest-Swarm-AI 完整 Python 重写）
# ═══════════════════════════════════════════════════════

try:
    from .swarm_classifier import (
        FalsePositiveFilter, VulnerabilityScorer, FindingClassifier,
        classify_finding_set, FP_FILTER_CONFIG, get_scoring_rules,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_exploit_engine import ExploitExecutor, SafeModeExecutor
except (ImportError, Exception):
    pass

try:
    from .swarm_path_builder import PathBuilder, AttackChain
except (ImportError, Exception):
    pass

try:
    from .swarm_shell_parser import parse_command, SafeShellParser, extract_executable
except (ImportError, Exception):
    pass

try:
    from .swarm_pheromones import (
        PheromoneConfig, PheromoneDecay, load_pheromones_from_yaml,
        get_pheromone_info, PHENOMONES_DEFAULT,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_orchestrator import (
        Phase, AgentRole, SwarmOrchestrator, PhantomState, Planner,
        create_default_orchestrator,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_prompts import (
        SYSTEM_PROMPTS, PromptFactory, RefusalHandler, RetryPolicy,
        build_attack_prompt, get_refusal_phrases,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_prompt_examples import (
        AttackScenario, SCENARIO_DATABASE,
        get_scenario_prompt, get_all_scenarios, get_scenarios_by_category,
        get_scenario_for_hypothesis, build_few_shot_chain,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_recon_parser import (
        Finding as ReconFinding, FindingCategory, AttackSurface,
        parse_nmap_output, parse_gobuster_output, classify_recon_finding,
        merge_tool_results, plan_recon,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_report_generator import ReportFormat, ReportGenerator
except (ImportError, Exception):
    pass

try:
    from .swarm_bounty_estimator import estimate_bounty_severity
except (ImportError, Exception):
    pass

try:
    from .swarm_dedup import findings_dedup, deduplicate_by_context
except (ImportError, Exception):
    pass

try:
    from .swarm_evidence import EvidenceCollector, EvidenceItem
except (ImportError, Exception):
    pass

try:
    from .swarm_quality_gate import QualityGate
except (ImportError, Exception):
    pass

try:
    from .swarm_roi_calculator import calculate_roi
except (ImportError, Exception):
    pass

try:
    from .swarm_training_data import (
        generate_classifier_samples, generate_exploit_samples,
        generate_recon_samples, generate_report_samples,
        train_classifier_model, classify_severity, save_samples_to_jsonl, load_samples_from_jsonl,
    )
except (ImportError, Exception):
    pass

try:
    from .swarm_legacy_bridge import (
        PentestAgent, PentestSession, SwarmOrchestrator as LegacySwarmOrchestrator,
        SimulateLLMEngine, APILLMEngine, ChatMessage,
    )
except (ImportError, Exception):
    pass


# ═══════════════════════════════════════════════════════
# vulnclaw 整合：自学习闭环（6 个纯标准库模块，按需提供）
# 全部为可选导入——任一模块缺失/异常时 HAS_* = False，核心扫描不受影响。
# ═══════════════════════════════════════════════════════

# ── context_budget: 真实 token 预算管理 ──
try:
    from .context_budget import (
        estimate_messages_tokens, estimate_prompt_tokens, fit_messages,
        install_context_budget, load_window_tokens,
    )
    HAS_CONTEXT_BUDGET = True
except (ImportError, Exception):
    HAS_CONTEXT_BUDGET = False

# ── anti_loop: 按目标反循环 + 阶段检测 ──
try:
    from .anti_loop import (
        LoopTracker, install_anti_loop_tracker, extract_host,
        detect_phase_from_output, is_meaningful_step, detect_attack_path,
    )
    HAS_ANTI_LOOP = True
except (ImportError, Exception):
    HAS_ANTI_LOOP = False

# ── reflexion: 结构化反思 + WAF 绕过逐级升级 ──
try:
    from .reflexion import (
        ReflexionEngine, classify_failure, install_reflexion_coach, FailureCategory,
    )
    HAS_REFLEXION = True
except (ImportError, Exception):
    HAS_REFLEXION = False

# ── kb_search: 知识库检索（BM25） ──
try:
    from .kb_search import (
        KnowledgeBase, make_consult_kb_tool, bigram_tokenize, BM25,
    )
    HAS_KB_SEARCH = True
except (ImportError, Exception):
    HAS_KB_SEARCH = False

# ── experience: 自学习经验闭环（落盘 + 审核 + 蒸馏） ──
try:
    from .experience import (
        Lesson, ExperienceStore, LessonStatus, make_store,
        distill_lessons, persist_distilled_lessons,
        build_experience_injection, install_experience_coach, RunArtifacts,
    )
    HAS_EXPERIENCE = True
except (ImportError, Exception):
    HAS_EXPERIENCE = False

# ── report_verifier: 报告验证器 ──
try:
    from .report_verifier import (
        verify_report, verify_finding, VerifiedSummary, generate_poc_snippets,
        append_poc_appendix,
    )
    HAS_REPORT_VERIFIER = True
except (ImportError, Exception):
    HAS_REPORT_VERIFIER = False


# ── SWARM_MIGRATION_MODULES ──
SWARM_MIGRATION_MODULES = {
    'swarm_classifier': {
        'file': 'scanners/swarm_classifier.py',
        'description': '漏洞分类器 + 误报过滤 + CVSS 评分引擎（源自 Pentest-Swarm-AI classifier/agent.go, fp_filter.go, scorer.go）',
        'classes': ['FalsePositiveFilter', 'VulnerabilityScorer', 'FindingClassifier'],
    },
    'swarm_exploit_engine': {
        'file': 'scanners/swarm_exploit_engine.py',
        'description': 'Exploit 执行引擎 + 6层安全门控（源自 Pentest-Swarm-AI exploit/executor.go）',
        'classes': ['ExploitExecutor', 'SafeModeExecutor'],
    },
    'swarm_path_builder': {
        'file': 'scanners/swarm_path_builder.py',
        'description': '攻击链路径构建器（源自 Pentest-Swarm-AI exploit/pathbuilder.go）',
        'classes': ['PathBuilder', 'AttackChain'],
    },
    'swarm_shell_parser': {
        'file': 'scanners/swarm_shell_parser.py',
        'description': 'Shell 命令安全解析器（源自 Pentest-Swarm-AI exploit/shellparse.go）',
        'classes': ['SafeShellParser'],
    },
    'swarm_pheromones': {
        'file': 'scanners/swarm_pheromones.py',
        'description': '蜂群费洛蒙系统（源自 Pentest-Swarm-AI config/pheromones.yaml）',
        'classes': ['PheromoneConfig', 'PheromoneDecay'],
    },
    'swarm_orchestrator': {
        'file': 'scanners/swarm_orchestrator.py',
        'description': '蜂群编排器 + 侦察规划器（源自 Pentest-Swarm-AI orchestrator/agent.go, planner.go）',
        'classes': ['SwarmOrchestrator', 'PhantomState', 'Planner'],
    },
    'swarm_prompts': {
        'file': 'scanners/swarm_prompts.py',
        'description': '提示词工程系统（源自 Pentest-Swarm-AI prompts/prompts.go, factory.go, refusal.go, retry.go）',
        'classes': ['PromptFactory', 'RefusalHandler', 'RetryPolicy'],
    },
    'swarm_prompt_examples': {
        'file': 'scanners/swarm_prompt_examples.py',
        'description': '攻击场景提示词示例库（源自 Pentest-Swarm-AI prompts/examples/）',
        'classes': ['AttackScenario'],
    },
    'swarm_recon_parser': {
        'file': 'scanners/swarm_recon_parser.py',
        'description': '侦察结果解析器（源自 Pentest-Swarm-AI recon/parser.go, agent.go）',
        'classes': ['AttackSurface', 'FindingCategory'],
    },
    'swarm_report_generator': {
        'file': 'scanners/swarm_report_generator.py',
        'description': '多格式报告生成器（源自 Pentest-Swarm-AI report/renderer.go, agent.go）',
        'classes': ['ReportGenerator'],
    },
    'swarm_bounty_estimator': {
        'file': 'scanners/swarm_bounty_estimator.py',
        'description': 'Bounty 估算引擎（源自 Pentest-Swarm-AI report/bounty/bounty.go）',
        'functions': ['estimate_bounty_severity'],
    },
    'swarm_dedup': {
        'file': 'scanners/swarm_dedup.py',
        'description': '发现去重引擎（源自 Pentest-Swarm-AI report/dedup/dedup.go）',
        'functions': ['findings_dedup', 'deduplicate_by_context'],
    },
    'swarm_evidence': {
        'file': 'scanners/swarm_evidence.py',
        'description': '证据收集器（源自 Pentest-Swarm-AI report/evidence/evidence.go）',
        'classes': ['EvidenceCollector', 'EvidenceItem'],
    },
    'swarm_quality_gate': {
        'file': 'scanners/swarm_quality_gate.py',
        'description': '质量门控（源自 Pentest-Swarm-AI report/qualitygate/gate.go）',
        'classes': ['QualityGate'],
    },
    'swarm_roi_calculator': {
        'file': 'scanners/swarm_roi_calculator.py',
        'description': 'ROI 计算引擎（源自 Pentest-Swarm-AI report/roi/roi.go）',
        'functions': ['calculate_roi'],
    },
}


# ═══════════════════════════════════════════════════════
# 完整模块索引
# ═══════════════════════════════════════════════════════

ALL_SCANNER_MODULES = {
    **ACUNETIX_MIGRATION_MODULES,
    **W3AF_MIGRATION_MODULES,
    **SWARM_MIGRATION_MODULES,
}
