#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Scanner — 通过 nmap 和 masscan 进行网络层扫描。

集成方式：
- nmap: apt install nmap / choco install nmap (已有 python-nmap)
- masscan: 需单独安装 https://github.com/robertdavidgraham/masscan

Usage:
    from scanners.network_scan import network_scan, port_scan, host_discovery
    result = port_scan("192.168.1.1", ports="1-1000")
"""

import json
import logging
import os
import subprocess
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse

logger = logging.getLogger('network_scan')


def _find_nmap() -> str:
    """查找 nmap 可执行文件"""
    for path in ["/usr/bin/nmap", "/usr/local/bin/nmap"]:
        if os.path.isfile(path):
            return path
    return "nmap"  # PATH


def _run_nmap(args: list, timeout: int = 120) -> str:
    """运行 nmap 并返回输出"""
    cmd = [_find_nmap()] + args
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout,
        )
        return proc.stdout or proc.stderr or ""
    except Exception as e:
        return f"NMAP_ERROR:{e}"


def port_scan(
    target: str,
    ports: str = "1-65535",
    scan_type: str = "SYN",
    aggressive: bool = False,
    timeout: int = 600,
) -> dict:
    """端口扫描（TCP SYN/XMAS/UDP）。

    Args:
        target: IP 或域名
        ports: 端口范围，如 "1-1000", "22,80,443,8080"
        scan_type: "SYN"(s), "XMAS"(A), "UDP"(U)
        aggressive: 是否启用服务版本检测和 OS 识别
        timeout: 扫描超时秒数

    Returns:
        {
            "ok": True,
            "target": "...",
            "open_ports": [{"port": 80, "protocol": "tcp", "state": "open", "service": "http"}],
            "filtered_ports": [...],
            "error": ""
        }
    """
    open_ports = []
    filtered_ports = []

    if scan_type == "SYN":
        nmap_args = ["-sS", "-p", ports]
    elif scan_type == "XMAS":
        nmap_args = ["-sA", "-p", ports]  # ACK scan for filtering
    elif scan_type == "UDP":
        nmap_args = ["-sU", "-p", ports]
    else:
        nmap_args = ["-sS", "-p", ports]

    if aggressive:
        nmap_args.extend(["-sV", "-O"])  # 服务版本 + OS 识别

    nmap_args.append(target)

    logger.info(f"nmap scan: {' '.join(nmap_args)}")
    output = _run_nmap(nmap_args, timeout=timeout)

    if "NMAP_ERROR" in output:
        return {"ok": False, "target": target, "open_ports": [], "filtered_ports": [], "error": output.split(":", 1)[1]}

    # 解析 nmap XML/文本输出
    current_port = None
    current_proto = "tcp"

    for line in output.splitlines():
        if '/open/' in line:
            parts = line.split('/')
            port = int(parts[0]) if parts[0].isdigit() else None
            proto = parts[1] if len(parts) > 1 else 'tcp'
            service = parts[2].strip() if len(parts) > 2 and not parts[2].startswith('open') else ''

            # Check for version info in next lines or context
            state = "open"
            if port is not None:
                open_ports.append({
                    "port": port,
                    "protocol": proto,
                    "state": state,
                    "service": service or 'unknown',
                })
        elif '/filtered/' in line:
            parts = line.split('/')
            port = int(parts[0]) if parts[0].isdigit() else None
            proto = parts[1] if len(parts) > 1 else 'tcp'
            if port is not None:
                filtered_ports.append({"port": port, "protocol": proto, "state": "filtered"})

    return {
        "ok": True,
        "target": target,
        "open_ports": open_ports[:500],
        "filtered_ports": filtered_ports[:200],
        "error": "",
        "method": "nmap",
    }


def masscan_ports(
    target: str,
    ports: str = "1-65535",
    rate: int = 10000,
    output_json: bool = True,
) -> dict:
    """masscan 快速端口扫描（比 nmap 快数百倍）。

    Args:
        target: IP 或网段（如 192.168.1.0/24）
        ports: 端口范围
        rate: 发包速率 (packets/sec)，默认 10000
        output_json: 是否输出 JSON

    Returns:
        {"ok": True, "open_ports": [...], ...}
    """
    open_ports = []
    masscan_path = None

    for name in ["masscan", "masscan.exe"]:
        import shutil
        p = shutil.which(name)
        if p and os.path.isfile(p):
            masscan_path = p
            break

    if not masscan_path:
        return {
            "ok": False,
            "target": target,
            "open_ports": [],
            "error": "masscan 未找到。请安装: https://github.com/robertdavidgraham/masscan",
        }

    cmd = [masscan_path, "-p", ports, target, "--rate", str(rate)]
    if output_json:
        cmd.append("--json")

    logger.info(f"masscan: {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

        # 解析 JSON 输出
        for line in (proc.stdout or proc.stderr).splitlines():
            try:
                entry = json.loads(line)
                if isinstance(entry, dict) and 'ports' in entry:
                    for port_entry in entry['ports']:
                        p = port_entry.get('port')
                        proto = port_entry.get('proto', 'tcp')
                        if p is not None:
                            open_ports.append({
                                "port": int(p),
                                "protocol": proto,
                                "state": "open",
                                "service": "",
                            })
                elif isinstance(entry, dict) and 'ip' in entry and 'ports' in entry:
                    # Single port result
                    port_entry = entry.get('ports', [{}])[0] if entry.get('ports') else {}
                    p = port_entry.get('port')
                    proto = port_entry.get('proto', 'tcp')
                    if p is not None:
                        open_ports.append({
                            "port": int(p),
                            "protocol": proto,
                            "state": "open",
                            "service": "",
                        })
            except json.JSONDecodeError:
                continue

        return {
            "ok": True,
            "target": target,
            "open_ports": open_ports[:1000],
            "error": "",
            "method": "masscan",
            "rate_pps": rate,
        }

    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "target": target,
            "open_ports": [],
            "error": "masscan 超时（最大时间 300s）",
        }


def host_discovery(
    network: str,
) -> dict:
    """ARP/ICMP 主机发现（局域网设备扫描）。

    Args:
        network: 网段，如 192.168.1.0/24

    Returns:
        {"ok": True, "hosts": [{"ip": "...", "mac": "..."}], ...}
    """
    cmd = [_find_nmap(), "-sn", network]
    logger.info(f"host discovery: {' '.join(cmd)}")
    output = _run_nmap(cmd)

    hosts = []
    for line in output.splitlines():
        # nmap -sn 输出: Nmap scan report for 192.168.1.1
        if 'Nmap scan report' in line:
            ip = line.split()[-1]
            hosts.append({"ip": ip, "status": "up"})

    return {
        "ok": True,
        "network": network,
        "hosts_found": len(hosts),
        "hosts": hosts[:256],
        "error": "",
    }


def network_scan(
    target: str,
    scan_type: str = "SYN",
    aggressive: bool = False,
) -> dict:
    """综合网络扫描：masscan 快速发现 → nmap 详细分析。

    Args:
        target: IP 或网段
        scan_type: "quick" (仅 masscan) / "full" (masscan + nmap) / "nmap" (仅 nmap)
        aggressive: nmap 深度扫描开关

    Returns:
        {
            "ok": True,
            "target": "...",
            "masscan_results": {...},
            "nmap_results": {...},
            "merged_ports": [...],
            "error": ""
        }
    """
    result = {"ok": False, "target": target}

    if scan_type == "quick":
        result["masscan"] = masscan_ports(target)
    elif scan_type == "nmap":
        result["nmap"] = port_scan(target, aggressive=aggressive)
    else:
        # 综合扫描
        logger.info("Phase 1: masscan 快速端口发现")
        mc_result = masscan_ports(target)
        result["masscan"] = mc_result

        if mc_result.get("ok") and mc_result.get("open_ports"):
            # Open ports 超过 500 说明可能有更多服务，用 nmap 进一步检查
            open_ports = [str(p["port"]) for p in mc_result["open_ports"]]
            port_range = ",".join(open_ports)
            logger.info(f"Phase 2: nmap 深度分析 → {len(open_ports)} 个开放端口")
            nm_result = port_scan(
                target, ports=port_range if port_range else "1-65535",
                scan_type="SYN", aggressive=True, timeout=300,
            )
            result["nmap"] = nm_result

            # 合并结果（nmap 优先，补充 service 信息）
            merged = {p["port"]: dict(p) for p in (result["nmap"].get("open_ports") or [])}
            for p in (mc_result.get("open_ports") or []):
                if p["port"] not in merged:
                    merged[p["port"]] = dict(p)
            result["merged_ports"] = sorted(merged.values(), key=lambda x: x["port"])[:500]

        result["ok"] = True

    return result
