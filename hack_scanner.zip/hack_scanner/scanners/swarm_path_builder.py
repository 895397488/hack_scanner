#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Path Builder — 漏洞利用路径构建器（基于规则的攻击链推导）。

源自: Pentest-Swarm-AI (https://github.com/Armur-Ai/Pentest-Swarm-AI)
from-source-of: Pentest-Swarm-AI

从 Go 源码 internal/agent/exploit/pathbuilder.go 移植。

核心逻辑：根据预设的 finding_type → target_type 关系规则，
自动推导所有可能的攻击链路径，并按预估成功率排序。

Usage:
    from scanners.swarm_path_builder import PathBuilder, ChainRule
    from scanners.swarm_classifier import ClassifiedFinding, Confidence

    builder = PathBuilder()
    paths = builder.build_chains(findings)
    for p in paths[:3]:
        print(f"[{p.estimated_success_probability:.0%}] {p.name}")
"""

import random
import sys
import uuid as _uuid
from dataclasses import dataclass, field
from pathlib import Path as _Path
from typing import Dict, List, Optional, Tuple

# 跨模块导入（处理 from __main__ 运行时路径解析）
_parent = str(_Path(__file__).parents[1])
if _parent not in sys.path:
    sys.path.insert(0, _parent)
from scanners.swarm_classifier import ClassifiedFinding, Confidence


# ============================================================
# 数据结构（与 swarm_exploit_engine.py 的 AttackPath/AttackStep 对应）
# ============================================================

@dataclass
class PathStep:
    """路径中的一步"""
    id: str = ""
    name: str = ""


@dataclass
class AttackPath:
    """一条完整的攻击链路径"""
    id: str = ""
    name: str = ""                           # e.g. "SQLi -> Data Extraction"
    description: str = ""                    # 描述
    steps: List[PathStep] = field(default_factory=list)
    estimated_success_probability: float = 0.5  # 预估成功率 (0.0~1.0)
    expected_impact: str = "medium"           # low/medium/high/critical
    target_finding_ids: List[str] = field(default_factory=list)


# ============================================================
# 关系规则定义（对应 Go chainRules）
# ============================================================

class RelationshipRule:
    """发现类型之间的映射关系规则。"""
    def __init__(self, from_type: str, to_types: List[str]):
        self.from_type = from_type
        self.to_types = to_types


# 预定义的漏洞利用链关系（来自 pathbuilder.go line 17-30）
CHAIN_RULES: List[RelationshipRule] = [
    # SQL注入可进一步利用
    RelationshipRule("sqli", ["data_extraction", "auth_bypass", "file_read"]),
    # 路径遍历可利用
    RelationshipRule("path_traversal", ["file_read", "source_code_disclosure", "credential_access"]),
    # 开放重定向可放大
    RelationshipRule("open_redirect", ["phishing_amplification", "oauth_bypass"]),
    # 暴露的 Git 仓库信息
    RelationshipRule("exposed_git", ["source_code_disclosure", "credential_extraction", "secret_discovery"]),
    # 弱凭据可提升权限
    RelationshipRule("weak_credentials", ["authentication_bypass", "privilege_escalation"]),
    # 过时软件可利用已知漏洞
    RelationshipRule("outdated_software", ["known_exploit"]),
    # CORS 配置错误
    RelationshipRule("misconfigured_cors", ["cross_origin_data_theft"]),
    # XML 外部实体注入
    RelationshipRule("xxe", ["ssrf", "file_read", "internal_network_scan"]),
    # SSRF 可探测内网
    RelationshipRule("ssrf", ["internal_network_scan", "cloud_metadata_access", "port_scan"]),
    # XSS 会话劫持
    RelationshipRule("xss", ["session_hijack", "credential_theft", "phishing"]),
    # 远程代码执行
    RelationshipRule("rce", ["full_system_access", "lateral_movement", "data_exfiltration"]),
    # 本地文件包含
    RelationshipRule("lfi", ["file_read", "rce_via_log_poisoning", "credential_access"]),
    # IDOR 数据/权限提升
    RelationshipRule("idor", ["data_extraction", "privilege_escalation"]),
]

# 复杂度目标修正系数（复杂目标的概率降低）
_COMPLEX_TARGET_MODIFIERS: Dict[str, float] = {
    "full_system_access":    0.6,
    "lateral_movement":      0.5,
    "privilege_escalation":  0.7,
    "cloud_metadata_access": 0.8,
    "data_extraction":       0.9,
    "session_hijack":        0.7,
}

# 高影响目标列表
_HIGH_IMPACT_TARGETS = frozenset([
    "full_system_access", "rce_via_log_poisoning",
    "lateral_movement", "data_exfiltration",
    "credential_access", "privilege_escalation",
])


# ============================================================
# PathBuilder — 攻击链路径构建器
# ============================================================

class PathBuilder:
    """基于规则的漏洞利用路径构建器。

    工作流程：
      1. 遍历所有发现，按 attack_category 匹配 CHAIN_RULES
      2. 对每个命中规则，生成从当前发现到目标的攻击链
      3. 计算预估成功率和影响等级
      4. 按成功率降序排序返回
    """

    def __init__(self, rules: Optional[List[RelationshipRule]] = None):
        """初始化路径构建器。

        Args:
            rules: 自定义关系规则列表，None 则使用内置的 CHAIN_RULES
        """
        self.rules = rules if rules is not None else CHAIN_RULES

    def build_chains(
        self,
        findings: List['ClassifiedFinding'],
    ) -> List[AttackPath]:
        """构建所有合法的攻击链路径。

        Args:
            findings: 分类后的发现列表（需包含 attack_category 和 confidence）

        Returns:
            按预估成功率降序排序的攻击路径列表
        """
        paths: List[AttackPath] = []

        for finding in findings:
            category = getattr(finding, "attack_category", "")
            if not category:
                continue

            # 查找该分类匹配的关系规则
            for rule in self.rules:
                if rule.from_type != category:
                    continue

                # 对规则中每个目标类型，生成一条攻击链
                for target in rule.to_types:
                    path = AttackPath(
                        id=str(_uuid.uuid4()),
                        name=f"{category} -> {target}",
                        description=f"Chain from {getattr(finding, 'title', finding.__class__.__name__)} to {target}",
                        steps=[
                            PathStep(
                                id=str(_uuid.uuid4()),
                                name=f"Exploit {getattr(finding, 'title', '')}",
                            ),
                            PathStep(
                                id=str(_uuid.uuid4()),
                                name=f"Achieve {target}",
                            ),
                        ],
                        target_finding_ids=[getattr(finding, "id", "")],
                        estimated_success_probability=self._estimate_success(finding, target),
                        expected_impact=self._impact_level(target),
                    )
                    paths.append(path)

        # 按预估成功率降序排序（与 Go sort.Slice 一致）
        paths.sort(key=lambda p: p.estimated_success_probability, reverse=True)

        return paths

    @staticmethod
    def _estimate_success(finding: 'ClassifiedFinding', target: str) -> float:
        """估算攻击链的成功率。

        基础概率来自发现的可信度(confidence):
          high   -> 0.8 (高可信)
          medium -> 0.6 (中等可信)
          low    -> 0.3 (低可信)

        对复杂目标类型应用修正系数（降低概率，因为越复杂的攻击越难成功）。
        """
        # Go源码使用 0.5 作为默认基础值
        base = 0.5

        confidence = getattr(finding, "confidence", "")
        if hasattr(confidence, "value"):
            confidence_val = confidence.value
        else:
            confidence_val = str(confidence).lower()

        if confidence_val == "high":
            base = 0.8
        elif confidence_val == "medium":
            base = 0.6
        elif confidence_val == "low":
            base = 0.3

        # 应用复杂度修正系数
        modifier = _COMPLEX_TARGET_MODIFIERS.get(target)
        if modifier is not None:
            base *= modifier

        return base

    @staticmethod
    def _impact_level(target: str) -> str:
        """评估目标的影响等级。"""
        if target in _HIGH_IMPACT_TARGETS:
            return "high"
        return "medium"


# ============================================================
# 便捷函数
# ============================================================

def build_attack_chains(
    findings: List['ClassifiedFinding'],
    rules: Optional[List[RelationshipRule]] = None,
) -> List[AttackPath]:
    """快捷函数：构建攻击链并排序。

    Usage:
        paths = build_attack_chains(findings)
        for path in paths[:5]:
            print(f"[{path.estimated_success_probability:.0%}] {path.name}")
    """
    builder = PathBuilder(rules=rules)
    return builder.build_chains(findings)


# ============================================================
# 快速验证
# ============================================================

if __name__ == "__main__":
    # 模拟一些分类后的发现（使用本地数据类避免跨模块导入）
    findings = [
        ClassifiedFinding(
            title="SQL injection in user parameter",
            attack_category="sqli",
            confidence=Confidence.HIGH,
        ),
        ClassifiedFinding(
            title="Path traversal in file download",
            attack_category="path_traversal",
            confidence=Confidence.MEDIUM,
        ),
        ClassifiedFinding(
            title="Reflected XSS in search field",
            attack_category="xss",
            confidence=Confidence.LOW,
        ),
        ClassifiedFinding(
            title="SSRF to cloud metadata endpoint",
            attack_category="ssrf",
            confidence=Confidence.HIGH,
        ),
    ]

    builder = PathBuilder()
    paths = builder.build_chains(findings)

    print(f"构建 {len(paths)} 条攻击链路径:\n")
    for i, p in enumerate(paths, 1):
        print(f"  [{i}] {p.name}")
        print(f"      成功率: {p.estimated_success_probability:.0%}")
        print(f"      影响等级: {p.expected_impact}")
        print(f"      描述: {p.description[:60]}...")
        print()
