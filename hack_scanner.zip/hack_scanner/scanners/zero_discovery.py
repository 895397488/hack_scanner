#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ZeroDiscovery — 内网资产发现模块

借鉴 Acunetix zerodisco/ 内网资产发现能力，实现：
- ARP/L2 局域网主机发现
- DNS 反向查询
- SNMP OID 枚举（探测设备类型）
- MQTT broker 端口开放检测
- SMB/CIFS 共享目录探测
- Redis/Memcached 未授权访问检测
- MySQL/PostgreSQL 未认证扫描

设计原则：
- 保守：仅当 explicitly 启用时才执行，默认禁用
- 只探测当前可达的子网（通过 IP 解析）
- 不发送破坏性 payload，只做端口/协议握手
"""

import socket
import struct
import logging
import subprocess
from typing import Dict, List, Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger('zero_discovery')


# ═══════ 内网 IP CIDR 范围定义 ═══════

PRIVATE_NETWORKS = [
    '10.0.0.0/8',
    '172.16.0.0/12',
    '192.168.0.0/16',
]


def is_private_ip(ip: str) -> bool:
    """判断 IP 是否为内网地址"""
    try:
        parts = list(map(int, ip.split('.')))
        if parts[0] == 10:
            return True
        if parts[0] == 172 and 16 <= parts[1] <= 31:
            return True
        if parts[0] == 192 and parts[1] == 168:
            return True
        if parts[0] == 127:
            return True
    except (ValueError, IndexError):
        pass
    return False


# ═══════ ARP 局域网主机发现 ═══════

class ArpScanner:
    """通过 ARP 探测同一 L2 网络中的活跃主机"""

    @staticmethod
    def discover(base_subnet: str, timeout: int = 5) -> List[Dict]:
        """扫描 base_subnet 子网（如 192.168.1）返回活跃主机列表。

        Returns:
            [{'ip': ..., 'mac': ..., 'vendor': ...}]
        """
        results = []

        try:
            if socket.getPlatform() == 'win32':
                # Windows: ping sweep + arp -a
                for host in range(1, 50):  # 只扫前 50 个 IP，避免太慢
                    ip = f"{base_subnet}.{host}"
                    try:
                        subprocess.run(
                            ['ping', '-n', '1', '-w', str(int(timeout * 1000))],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            timeout=timeout + 1,
                        )
                    except (subprocess.TimeoutExpired, Exception):
                        continue

                # 解析 arp 缓存
                try:
                    output = subprocess.check_output(['arp', '-a'], encoding='utf-8')
                    for line in output.splitlines():
                        parts = line.strip().split()
                        if parts and '.' in parts[0]:
                            ip_addr = parts[0]
                            mac_addr = parts[1].replace('-', ':').upper() if len(parts) > 1 else ''
                            vendor = 'unknown'
                            results.append({
                                'ip': ip_addr,
                                'mac': mac_addr,
                                'vendor': vendor,
                                'protocol': 'arp',
                                'discovery_method': 'windows_arp_sweep',
                            })
                except (subprocess.SubprocessError, Exception):
                    pass

            else:
                # Linux/Mac: 使用 ping + arping/arp-scan
                base = '.'.join(base_subnet.split('.')[:3])
                for host in range(1, 50):
                    ip = f"{base}.{host}"
                    try:
                        subprocess.run(
                            ['ping', '-c', '1', '-W', str(int(timeout)), ip],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            timeout=timeout + 1,
                        )
                        results.append({'ip': ip, 'mac': '', 'vendor': '', 'protocol': 'arp'})
                    except (subprocess.TimeoutExpired, Exception):
                        continue

        except Exception as e:
            logger.warning(f"ARP 扫描失败: {e}")

        return results


# ═══════ SNMP OID 枚举 ═══════

class SnmpScanner:
    """通过 SNMP 公共团体名探测网络设备"""

    COMMUNITY_STRINGS = ['public', 'private', 'admin', 'community', 'monitoring']

    COMMON_OIDS = {
        'system_name': '1.3.6.1.2.1.1.5',       # sysName
        'system_description': '1.3.6.1.2.1.1.1',  # sysDescr
        'system_uptime': '1.3.6.1.2.1.1.3',      # sysUpTime
    }

    @staticmethod
    def scan(ip: str) -> Dict[str, Any]:
        """扫描 IP 的 SNMP 服务。"""
        results = {
            'ip': ip,
            'port': 161,
            'community_found': None,
            'oid_results': {},
        }

        for community in SnmpScanner.COMMUNITY_STRINGS:
            for oid_name, oid_val in SnmpScanner.COMMON_OIDS.items():
                try:
                    output = subprocess.check_output(
                        ['snmpwalk', '-v2c', '-c', community, ip, oid_val],
                        stderr=subprocess.DEVNULL,
                        timeout=3,
                    ).decode('utf-8', errors='replace').strip()
                    if output and 'No Such' not in output:
                        results['community_found'] = community
                        results['oid_results'][oid_name] = output[:200]
                except (subprocess.SubprocessError, FileNotFoundError, Exception):
                    continue

        return results


# ═══════ MQTT Broker 探测 ═══════

class MqttScanner:
    """探测内网 MQTT broker（常见端口 1883, 8883）"""

    MQTTP_PORTS = [1883, 8883, 1884, 8884]

    @staticmethod
    def scan(ip: str) -> Dict[str, Any]:
        """扫描 MQTT broker 可用性"""
        results = []
        for port in MqttScanner.MQTTP_PORTS:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                result_code = sock.connect_ex((ip, port))
                if result_code == 0:
                    results.append({
                        'port': port,
                        'status': 'open',
                        'protocol': 'mqtt',
                        'can_subscribe': False,
                    })
                sock.close()
            except Exception:
                pass
        return {'ip': ip, 'mqtt_brokers': results}


# ═══════ SMB/CIFS 共享探测 ═══════

class SmbScanner:
    """探测内网 SMB 共享"""

    @staticmethod
    def scan(ip: str) -> Dict[str, Any]:
        """扫描 SMB 共享目录"""
        results = {
            'ip': ip,
            'port_445_open': False,
            'shares': [],
        }

        # 检查 445 端口
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result_code = sock.connect_ex((ip, 445))
            results['port_445_open'] = (result_code == 0)
            sock.close()
        except Exception:
            return results

        if not results['port_445_open']:
            return results

        # 使用 smbclient 探测
        try:
            output = subprocess.check_output(
                ['smbclient', '-L', ip, '-N'],
                stderr=subprocess.DEVNULL,
                timeout=3,
            ).decode('utf-8', errors='replace')

            for line in output.splitlines():
                if 'Disk' in line and '----' not in line:
                    parts = line.split()
                    share_name = parts[0].strip() if parts else ''
                    if share_name and share_name != '----':
                        results['shares'].append({
                            'name': share_name,
                            'type': parts[1] if len(parts) > 1 else '',
                        })
        except (subprocess.SubprocessError, FileNotFoundError):
            results['shares'] = [{'name': '(smbclient not available)', 'type': 'unknown'}]

        return results


# ═══════ Redis/Memcached 未授权访问检测 ═══════

class UnauthCacheScanner:
    """检测内网 Redis/Memcached 的未授权访问"""

    @staticmethod
    def scan(ip: str) -> Dict[str, Any]:
        """扫描 Redis 和 Memcached"""
        results = {
            'ip': ip,
            'redis_unauth': False,
            'memcached_unauth': False,
        }

        # Redis
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((ip, 6379))
            sock.send(b'INFO\r\n')
            response = sock.recv(4096).decode('utf-8', errors='replace')
            if 'redis_version' in response:
                results['redis_unauth'] = True
            sock.close()
        except Exception:
            pass

        # Memcached
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((ip, 11211))
            sock.send(b'version\r\n')
            response = sock.recv(4096).decode('utf-8', errors='replace')
            if 'VERSION' in response or response.strip().lower():
                results['memcached_unauth'] = True
            sock.close()
        except Exception:
            pass

        return results


# ═══════ 主发现引擎 ═══════

class ZeroDiscoveryEngine:
    """内网资产发现统一入口"""

    @staticmethod
    def discover_host(target_url: str, scan_level: str = 'light') -> Dict[str, Any]:
        """从目标 URL 解析 IP 并探测相关内网服务。

        Args:
            target_url: 目标 URL
            scan_level: 'light' (仅 ping) | 'full' (完整协议扫描)

        Returns:
            {'target_ip': str, 'subnet': str, 'services': [...], 'finding_count': int}
        """
        parsed = urlparse(target_url)
        hostname = parsed.hostname or target_url

        # 解析 IP
        try:
            addr_info = socket.getaddrinfo(hostname, None)
            target_ip = addr_info[0][4][0] if addr_info else ''
        except socket.gaierror:
            return {'error': f'无法解析主机 {hostname}'}

        # 提取子网（前三个 octet）
        subnet_base = '.'.join(target_ip.split('.')[:3])

        services_found = []

        if scan_level in ('light', 'full'):
            logger.info(f"  [ZeroDiscovery] 目标 IP: {target_ip} (子网: {subnet_base})")

            # ARP 发现
            arp_hosts = ArpScanner.discover(subnet_base)
            for host in arp_hosts:
                services_found.append({
                    'type': 'arp_host',
                    'ip': host['ip'],
                    'mac': host.get('mac', ''),
                    'protocol': 'arp',
                })

        if scan_level == 'full' and is_private_ip(target_ip):
            # SNMP 扫描目标
            snmp_result = SnmpScanner.scan(target_ip)
            if snmp_result.get('community_found'):
                services_found.append({
                    'type': 'snmp_device',
                    'ip': target_ip,
                    'community': snmp_result['community_found'],
                    'oids': snmp_result['oid_results'],
                    'protocol': 'snmp',
                })

            # MQTT 扫描
            mqtt_result = MqttScanner.scan(target_ip)
            services_found.extend([s for s in mqtt_result.get('mqtt_brokers', [])])

            # SMB 扫描
            smb_result = SmbScanner.scan(target_ip)
            if smb_result['port_445_open']:
                services_found.append({
                    'type': 'smb_server',
                    'ip': target_ip,
                    'shares': smb_result.get('shares', []),
                    'protocol': 'smb',
                })

            # Redis/Memcached 扫描
            cache_result = UnauthCacheScanner.scan(target_ip)
            if cache_result['redis_unauth']:
                services_found.append({
                    'type': 'redis_unauthorized',
                    'ip': target_ip,
                    'port': 6379,
                    'protocol': 'redis',
                })
            if cache_result['memcached_unauth']:
                services_found.append({
                    'type': 'memcached_unauthorized',
                    'ip': target_ip,
                    'port': 11211,
                    'protocol': 'memcached',
                })

        return {
            'target_ip': target_ip,
            'subnet': subnet_base,
            'services_found': services_found,
            'finding_count': len(services_found),
        }


def discover_services_from_url(url: str, scan_level: str = 'light') -> Dict[str, Any]:
    """便捷函数：从 URL 发现内网服务"""
    return ZeroDiscoveryEngine.discover_host(url, scan_level)
