# from-source-of: Pentest-Swarm-AI
#
# 蜂群编排器模块
# 源自 Pentest-Swarm-AI/internal/agent/orchestrator/agent.go
#          Pentest-Swarm-AI/internal/agent/orchestrator/planner.go
#
# 核心逻辑忠实地翻译自 Go 源码：ReAct 循环、阶段编排、
# 上下文传递（PhantomState）、里程碑分解。

"""
蜂群编排器 — SwarmOrchestrator + Planner

SwarmOrchestrator:
    - 管理多个 agent 的生命周期（侦察 → 分类 → 利用 → 报告）
    - 通过 PhantomState 在阶段间传递上下文
    - 按阶段调度对应 agent，执行 ReAct 循环
    - 内置 token 预算管理和工具调用处理

Planner:
    - 根据目标类型自动生成里程碑列表
    - 支持 RCE / Bug Bounty / CTF / 通用渗透测试的递进式侦察规划
"""

import re
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


# ---------------------------------------------------------------------------
# Phase enum: 蜂群攻击阶段（与 Go 源码中的 pipeline 状态对应）
# ---------------------------------------------------------------------------
class Phase(Enum):
    """蜂群攻击的四个阶段，按顺序递进。"""
    RECON = auto()          # 侦察 — 发现目标表面
    CLASSIFY = auto()       # 分类 — 映射漏洞、评分 CVSS、过滤误报
    EXPLOIT = auto()        # 利用 — 构建并执行攻击链
    REPORT = auto()         # 报告 — 生成专业渗透测试报告


# ---------------------------------------------------------------------------
# AgentRole enum: 蜂群中的代理角色
# ---------------------------------------------------------------------------
class AgentRole(Enum):
    """蜂群中的四类专用代理。"""
    RECON_AGENT = "recon_agent"       # 侦察代理：发现子域名、端口、服务、端点和技术栈
    CLASSIFIER_AGENT = "classifier_agent"   # 分类代理：映射 CVE、评分 CVSS、过滤误报
    EXPLOIT_AGENT = "exploit_agent"     # 利用代理：构建并执行多步攻击链
    REPORT_AGENT = "report_agent"       # 报告代理：生成专业渗透测试报告


# ---------------------------------------------------------------------------
# PhantomState: 跨阶段传递的上下文对象
# ---------------------------------------------------------------------------
class PhantomState:
    """
    蜂群攻击的全局上下文（对应 Go 源码中的 campaign / findings 传递）。

    在阶段间流转，每个 agent 可以读取和更新此状态。
    """

    def __init__(self):
        self.targets: list[str] = []          # 目标列表
        self.findings: list[dict[str, Any]] = []  # 漏洞发现
        self.progress: dict[str, Any] = {}    # 进度追踪
        self.current_phase: Phase = Phase.RECON
        self.milestones: list["Milestone"] = []
        self.tool_results: list[dict[str, Any]] = []  # 工具调用结果历史
        self.iteration: int = 0               # 当前迭代次数

    def add_finding(self, finding: dict[str, Any]) -> None:
        """添加一条漏洞发现。"""
        self.findings.append(finding)

    def record_tool_result(self, tool_name: str, result: str, error: Optional[str] = None) -> None:
        """记录一次工具调用结果。"""
        self.tool_results.append({
            "tool": tool_name,
            "result": result,
            "error": error,
            "iteration": self.iteration,
        })

    def advance_phase(self, phase: Phase) -> None:
        """推进到下一阶段并标记前一个阶段完成。"""
        self.current_phase = phase
        self.progress[phase.name.lower()] = True

    @property
    def is_complete(self) -> bool:
        """判断蜂群攻击是否已全部完成。"""
        return (
            self.current_phase == Phase.REPORT
            and self.progress.get("report_completed", False)
        )


# ---------------------------------------------------------------------------
# Milestone: 里程碑（源自 planner.go）
# ---------------------------------------------------------------------------
class Milestone:
    """一个检查点，编排器追踪进度。"""

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.completed = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "completed": self.completed,
        }


# ---------------------------------------------------------------------------
# ToolDefinition: 编排器可调用的工具定义（对应 Go 源码的 OrchestratorTool）
# ---------------------------------------------------------------------------
class ToolDefinition:
    """
    编排器可调用的工具定义。

    对应 Go 源码中的 OrchestratorTool struct：
        - Name / Description / Parameters / Execute
    """

    def __init__(
        self,
        name: str,
        description: str,
        parameters: Optional[dict[str, Any]] = None,
        execute: Optional[Callable[[str], tuple[str, Optional[str]]]] = None,
    ):
        self.name = name
        self.description = description
        self.parameters = parameters or {}
        self.execute = execute  # (args_string) -> (result_string, error_or_None)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }


# ---------------------------------------------------------------------------
# SwarmOrchestrator: 蜂群编排器核心类
# ---------------------------------------------------------------------------
class SwarmOrchestrator:
    """
    蜂群编排器 — 协调所有专用代理的 ReAct 循环。

    对应 Go 源码中的 OrchestratorAgent struct:
        - provider      -> llm.Provider（在 Python 中为 LLM 回调函数）
        - tools         -> 工具注册表
        - max_iterations -> 最大迭代次数（默认 50，同 Go 源码）
        - event_sink    -> 事件回调

    核心流程:
        1. 初始化消息历史（包含 campaign 启动的用户消息）
        2. 进入 ReAct 循环：
           a. 检查 token 预算，超出则摘要压缩
           b. 向 LLM 发送系统提示 + 消息历史
           c. 处理推理文本或工具调用
           d. 执行工具，将结果追加到消息历史
           e. 检查完成信号
        3. 达到最大迭代次数后停止
    """

    # 编排器系统提示（忠实地从 Go 源码的 orchestratorSystemPrompt 常量翻译）
    SYSTEM_PROMPT = (
        "You are the orchestrator of an autonomous penetration testing platform. You coordinate four specialist agents:\n\n"
        "1. **Recon Agent**: Discovers subdomains, ports, services, endpoints, and technologies\n"
        "2. **Classifier Agent**: Maps findings to CVEs, scores CVSS, filters false positives\n"
        "3. **Exploit Agent**: Constructs and executes multi-step attack chains\n"
        "4. **Report Agent**: Generates professional pentest reports\n\n"
        "Your job is to:\n"
        "- Plan the campaign strategy based on the target and objective\n"
        "- Decide which agent to invoke and when\n"
        "- Adapt the strategy based on results\n"
        "- Know when to stop (objective reached, all paths exhausted, or diminishing returns)\n\n"
        "Use the available tools to coordinate the agents. Think step by step about what to do next.\n\n"
        "When the campaign objective is achieved or all attack paths are exhausted, declare 'Campaign complete' and invoke the report generator.\n\n"
        "IMPORTANT: Never target anything outside the defined scope. If you're unsure, ask."
    )

    # 完成信号关键词（源自 Go 源码的 isCompletionSignal）
    COMPLETION_SIGNALS = [
        "campaign complete",
        "objective reached",
        "all paths exhausted",
        "report generated",
    ]

    def __init__(
        self,
        llm_invoke: Callable[[str, list[dict[str, str]], list[dict], int], dict],
        max_iterations: int = 50,
        event_sink: Optional[Callable[[dict[str, Any]], None]] = None,
    ):
        """
        初始化编排器。

        Args:
            llm_invoke: LLM 调用回调函数
                签名: (system_prompt, messages, tools, max_tokens) -> {content, stop_reason, tool_calls}
                content: str — LLM 回复内容
                stop_reason: str — "end_turn" 或 None
                tool_calls: list[dict] — [{name, arguments, id}]
            max_iterations: 最大迭代次数（默认 50，与 Go 源码一致）
            event_sink: 事件回调函数，接收 campaign event dict
        """
        self.llm_invoke = llm_invoke
        self.max_iterations = max_iterations if max_iterations > 0 else 50
        self.event_sink = event_sink
        self.tools: dict[str, ToolDefinition] = {}
        self.messages: list[dict[str, str]] = []

    # ------------------------------------------------------------------
    # 工具注册
    # ------------------------------------------------------------------
    def register_tool(self, tool: ToolDefinition) -> None:
        """注册一个编排器可调用的工具。"""
        self.tools[tool.name] = tool

    # ------------------------------------------------------------------
    # ReAct 循环核心 — run_campaign（对应 Go 源码的 Run 方法）
    # ------------------------------------------------------------------
    def run_campaign(
        self,
        targets: list[str],
        objective: str = "find all vulnerabilities",
        mode: str = "full",
    ) -> PhantomState:
        """
        执行完整蜂群攻击流程。

        对应 Go 源码 orchestratorAgent.Run() 方法：
            1. 构建初始消息（campaign 启动信息）
            2. 构建工具定义列表发送给 LLM
            3. ReAct 循环：LLM → 推理/工具调用 → 执行 → 追加结果 → 继续

        Args:
            targets: 目标列表
            objective: 攻击目标描述
            mode: 攻击模式（full / shallow / targeted）

        Returns:
            PhantomState: 包含所有发现和进度的最终状态对象
        """
        state = PhantomState()
        state.targets = list(targets)

        # Step 1: 构建初始消息（忠实于 Go 源码的 campaign 启动消息）
        self.messages = [
            {
                "role": "user",
                "content": (
                    f"Campaign started.\n"
                    f"Target: {', '.join(targets)}\n"
                    f"Objective: {objective}\n"
                    f"Mode: {mode}\n\n"
                    f"Begin the penetration test. Start with reconnaissance."
                ),
            },
        ]

        # Step 2: 构建 LLM 可用的工具定义列表
        llm_tools = [t.to_dict() for t in self.tools.values()]

        # Step 3: 初始化进度
        state.advance_phase(Phase.RECON)
        self._emit_event(state, "state_change", "orchestrator", "Campaign started", None)

        # Step 4: ReAct 主循环
        for iteration in range(self.max_iterations):
            state.iteration = iteration

            # a. 检查取消信号（对应 Go 源码的 ctx.Done()）
            if self._check_cancel(state, iteration):
                break

            # b. Token 预算管理（对应 Go 源码的 budgetManager.NeedsSummarization）
            if self._needs_summarization():
                self.messages = self._summarize_context()

            # c. 发送请求到 LLM
            resp = self.llm_invoke(
                system_prompt=self.SYSTEM_PROMPT,
                messages=self.messages,
                tools=llm_tools,
                max_tokens=4096,  # 与 Go 源码一致
                temperature=0.1,  # 与 Go 源码一致
            )

            if resp is None:
                self._emit_event(state, "error", "orchestrator", "LLM call returned None", None)
                break

            content = resp.get("content", "")
            stop_reason = resp.get("stop_reason", "")
            tool_calls = resp.get("tool_calls", [])

            # d. 处理推理文本（对应 Go 源码的 resp.Content 处理）
            if content:
                self._emit_event(state, "thought", "orchestrator", content, None)
                self.messages.append({"role": "assistant", "content": content})

            # e. 检查完成信号（对应 isCompletionSignal）
            if stop_reason == "end_turn" and len(tool_calls) == 0:
                if self._is_completion_signal(content):
                    self._emit_event(state, "milestone", "orchestrator", "Campaign complete", None)
                    state.progress["report_completed"] = True
                    return state

            # f. 处理工具调用（对应 Go 源码的工具调用循环）
            if len(tool_calls) == 0:
                # 无工具调用也无完成信号 → 提示 LLM 采取行动
                self.messages.append({
                    "role": "user",
                    "content": "What's the next step? Use one of the available tools to continue the campaign.",
                })
                continue

            # g. 遍历并执行所有工具调用
            for tc in tool_calls:
                tool_name = tc.get("name", "")
                arguments = tc.get("arguments", "{}")
                call_id = tc.get("id", "")

                self._emit_event(
                    state, "tool_call", "orchestrator",
                    f"Calling {tool_name}", arguments,
                )

                # 查找工具
                tool = self.tools.get(tool_name)
                if tool is None:
                    available = list(self.tools.keys())
                    result_str = f"Tool {tool_name!r} not found. Available tools: {available}"
                    error = "tool_not_found"
                    self.messages.append({
                        "role": "tool",
                        "content": result_str,
                        "tool_call_id": call_id,
                    })
                    continue

                # 执行工具（对应 Go 源码的 tool.Execute）
                try:
                    result, err = tool.execute(arguments)
                except Exception as exc:
                    result = f"Tool {tool_name} failed: {exc}"
                    err = str(exc)

                if err is not None:
                    self._emit_event(state, "error", tool_name, result, None)
                else:
                    truncated = self._truncate(result, 500)
                    self._emit_event(state, "tool_result", tool_name, truncated, None)

                self.messages.append({
                    "role": "tool",
                    "content": result,
                    "tool_call_id": call_id,
                })

                # 将工具结果记录到 PhantomState
                state.record_tool_result(tool_name, result[:200], err)

        # 达到最大迭代次数
        self._emit_event(
            state, "milestone", "orchestrator",
            f"Max iterations reached ({self.max_iterations})", None,
        )
        return state

    # ------------------------------------------------------------------
    # 阶段编排器 — run_phased（按阶段的显式调度）
    # ------------------------------------------------------------------
    def run_phased(
        self,
        targets: list[str],
        objective: str = "find all vulnerabilities",
    ) -> PhantomState:
        """
        按阶段顺序执行蜂群攻击（替代 ReAct 循环的阶段化版本）。

        对应 Planner 的里程碑分解逻辑：
            RECON → CLASSIFY → EXPLOIT → REPORT

        每个阶段的 agent 独立调度，上下文通过 PhantomState 传递。
        """
        state = PhantomState()
        state.targets = list(targets)
        self.messages = [
            {
                "role": "user",
                "content": (
                    f"Phase-based campaign started.\n"
                    f"Target: {', '.join(targets)}\n"
                    f"Objective: {objective}\n\n"
                    f"Begin phased penetration testing."
                ),
            },
        ]

        # 定义每个阶段的代理角色和对应的工具要求
        phase_config = [
            (Phase.RECON, AgentRole.RECON_AGENT, "Reconnaissance phase", self._recon_system_prompt),
            (Phase.CLASSIFY, AgentRole.CLASSIFIER_AGENT, "Classification phase", self._classify_system_prompt),
            (Phase.EXPLOIT, AgentRole.EXPLOIT_AGENT, "Exploitation phase", self._exploit_system_prompt),
            (Phase.REPORT, AgentRole.REPORT_AGENT, "Reporting phase", self._report_system_prompt),
        ]

        for phase, role, description, sys_prompt in phase_config:
            state.current_phase = phase
            state.advance_phase(phase)
            self._emit_event(state, "state_change", role.value, f"Entering {phase.name} phase", None)

            # 向对应 agent 的 LLM 发送请求
            resp = self.llm_invoke(
                system_prompt=sys_prompt,
                messages=list(self.messages),
                tools=[],
                max_tokens=4096,
                temperature=0.1,
            )

            if resp is None:
                continue

            content = resp.get("content", "")
            if content:
                self._emit_event(state, "milestone", role.value, f"{phase.name} result:\n{content[:500]}", None)

            # 将结果追加到消息历史，传递给下一阶段
            state.add_finding({
                "phase": phase.name,
                "agent": role.value,
                "content": content,
                "objective": objective,
            })

        state.progress["report_completed"] = True
        self._emit_event(state, "milestone", "orchestrator", "Campaign complete", None)
        return state

    # ------------------------------------------------------------------
    # 内部方法 — 对应 Go 源码的各个辅助函数
    # ------------------------------------------------------------------

    @staticmethod
    def _is_completion_signal(content: str) -> bool:
        """检查 LLM 回复是否包含完成信号（源自 isCompletionSignal）。"""
        lower = content.lower()
        for signal in SwarmOrchestrator.COMPLETION_SIGNALS:
            if signal in lower:
                return True
        return False

    @staticmethod
    def _contains_ignore_case(s: str, substr: str) -> bool:
        """不区分大小写的子串搜索（对应 Go 源码的 containsIgnoreCase）。"""
        return substr.lower() in s.lower()

    @staticmethod
    def _truncate(s: str, max_len: int) -> str:
        """截断字符串到指定长度（对应 Go 源码的 truncate）。"""
        if len(s) <= max_len:
            return s
        return s[:max_len] + "..."

    def _emit_event(
        self,
        state: PhantomState,
        event_type: str,
        agent: str,
        detail: str,
        data: Optional[dict],
    ) -> None:
        """发送事件到回调 sink（对应 emitEvent）。"""
        if self.event_sink is None:
            return
        self.event_sink({
            "event_type": event_type,
            "agent": agent,
            "detail": detail,
            "data": data,
            "phase": state.current_phase.name,
            "iteration": state.iteration,
        })

    def _check_cancel(self, state: PhantomState, iteration: int) -> bool:
        """检查取消信号（对应 Go 源码的 ctx.Done()）。"""
        if state.progress.get("cancelled"):
            self._emit_event(state, "state_change", "orchestrator", "Campaign cancelled", None)
            return True
        return False

    def _needs_summarization(self) -> bool:
        """判断是否需要摘要压缩上下文（对应 Go 源码的 budgetManager.NeedsSummarization）。"""
        # 简单启发式：消息历史超过一定深度时触发摘要
        MAX_MESSAGES = 40
        return len(self.messages) > MAX_MESSAGES

    def _summarize_context(self) -> list[dict[str, str]]:
        """压缩上下文（对应 Go 源码的 budgetManager.Summarize）。"""
        # 保留初始消息和最近的消息，中间部分摘要化
        if len(self.messages) <= 5:
            return self.messages

        # 保留第一条和最后三条，压缩中间部分
        preserved = [self.messages[0]]  # campaign 启动消息
        middle_start = max(1, len(self.messages) - 6)
        compressed = f"[Messages {middle_start} to {len(self.messages) - 3} compressed]\n"
        preserved.append({"role": "system", "content": compressed})
        preserved.extend(self.messages[len(self.messages) - 3:])

        return preserved

    # ------------------------------------------------------------------
    # 各阶段的系统提示（阶段化版本专用）
    # ------------------------------------------------------------------
    _recon_system_prompt = (
        "You are the Reconnaissance Agent of an autonomous penetration testing swarm.\n\n"
        "Your role: discover the full attack surface.\n"
        "Actions: enumerate subdomains, ports, services, endpoints, technologies, and misconfigurations.\n\n"
        "For every finding, record:\n"
        "- Target URL / hostname\n"
        "- Service type (HTTP, DNS, SSH, etc.)\n"
        "- Evidence (response headers, status codes, version strings)\n\n"
        "Begin reconnaissance on the provided targets."
    )

    _classify_system_prompt = (
        "You are the Classifier Agent of an autonomous penetration testing swarm.\n\n"
        "Your role: analyze findings from reconnaissance and classify vulnerabilities.\n"
        "Actions:\n"
        "- Map findings to CVE identifiers where applicable\n"
        "- Score severity using CVSS v3.1 base metrics\n"
        "- Filter false positives using confirmation tests\n"
        "- Deduplicate related findings\n\n"
        "For each confirmed finding, provide:\n"
        "- Vulnerability class (OWASP category)\n"
        "- CVE reference (if any)\n"
        "- CVSS score and vector string\n"
        "- Confidence level (high / medium / low)\n"
        "- Confirmation indicator (the concrete evidence)"
    )

    _exploit_system_prompt = (
        "You are the Exploitation Agent of an autonomous penetration testing swarm.\n\n"
        "Your role: construct and execute multi-step attack chains against confirmed vulnerabilities.\n"
        "Actions:\n"
        "- Prioritize exploit attempts by severity and confidence\n"
        "- Chain multiple vulnerabilities for higher impact\n"
        "- Use non-destructive proof-of-concept methods\n"
        "- Record exploitation results with reproduction details\n\n"
        "IMPORTANT: Only use tools and techniques within the authorized scope.\n"
        "Always prefer read-only or confirmatory exploits over destructive ones."
    )

    _report_system_prompt = (
        "You are the Report Generation Agent of an autonomous penetration testing swarm.\n\n"
        "Your role: compile all findings into a professional penetration test report.\n"
        "Structure:\n"
        "- Executive summary with risk overview\n"
        "- Methodology and scope\n"
        "- Detailed findings (CVSS score, description, impact, recommendation)\n"
        "- Attack chain diagrams\n"
        "- Appendix with raw evidence\n\n"
        "Format each finding as:\n"
        "- Title: {vulnerability class} on {target}\n"
        "- Severity: {CVSS score}/{severity level}\n"
        "- Description: clear explanation of the vulnerability\n"
        "- Proof: step-by-step reproduction\n"
        "- Remediation: actionable fix recommendation"
    )


# ---------------------------------------------------------------------------
# Planner: 侦察规划器（源自 planner.go）
# ---------------------------------------------------------------------------
class Planner:
    """
    根据目标类型自动生成里程碑列表。

    对应 Go 源码中的 Planner struct 和 DecomposeObjective 方法：
        - 识别目标类型（RCE / Bug Bounty / CTF / 通用）
        - 返回按优先级排序的里程碑链
        - 每个阶段递进式侦察（DNS → HTTP → Auth → API）

    示例:
        planner = Planner()
        milestones = planner.decompose_objective("perform bug bounty on example.com")
        for ms in milestones:
            print(f"{ms.name}: {ms.description}")
    """

    # ------------------------------------------------------------------
    # 目标类型关键词映射（源自 Go 源码的 switch/case）
    # ------------------------------------------------------------------
    _OBJECTIVE_PATTERNS = [
        # (关键词列表, 里程碑模板)
        (
            ["rce", "remote code execution"],
            [
                Milestone("recon_complete", "Full attack surface discovered"),
                Milestone("rce_candidates_identified", "Potential RCE findings classified"),
                Milestone("rce_exploited_or_exhausted", "RCE exploitation attempted on all candidates"),
                Milestone("report_generated", "Professional report generated"),
            ],
        ),
        (
            ["bug bounty"],
            [
                Milestone("scope_loaded", "Program scope imported from platform"),
                Milestone("recon_complete", "Full attack surface discovered"),
                Milestone("findings_classified", "All findings classified with CVE/CVSS"),
                Milestone("duplicates_checked", "Duplicate detection completed"),
                Milestone("report_formatted", "Bug bounty compliant report generated"),
            ],
        ),
        (
            ["ctf", "flag"],
            [
                Milestone("recon_complete", "Machine enumerated"),
                Milestone("initial_foothold", "Initial access achieved"),
                Milestone("user_flag", "User flag captured"),
                Milestone("privilege_escalation", "Root/admin access achieved"),
                Milestone("root_flag", "Root flag captured"),
            ],
        ),
    ]

    # 通用默认里程碑（对应 Go 源码的 default case）
    DEFAULT_MILESTONES = [
        Milestone("recon_complete", "Full attack surface discovered"),
        Milestone("findings_classified", "All findings classified and scored"),
        Milestone("exploitation_attempted", "Top attack chains tested"),
        Milestone("report_generated", "Professional report generated"),
    ]

    # 递进式侦察阶段（DNS → HTTP → Auth → API）
    RECON_PROGRESSION = [
        Phase.RECON,
        Phase.CLASSIFY,
        Phase.EXPLOIT,
        Phase.REPORT,
    ]

    def decompose_objective(self, objective: str) -> list[Milestone]:
        """
        将目标分解为有序里程碑列表。

        对应 Go 源码的 DecomposeObjective() 方法，忠实地使用关键词匹配。

        Args:
            objective: 目标描述字符串（如 "perform bug bounty on example.com"）

        Returns:
            Milestone 列表，按优先级排序
        """
        lower = objective.lower()

        for keywords, milestones in self._OBJECTIVE_PATTERNS:
            for kw in keywords:
                if kw in lower:
                    return list(milestones)

        # 默认：通用渗透测试
        return list(self.DEFAULT_MILESTONES)

    def get_recon_progression(self) -> list[Phase]:
        """
        获取递进式侦察阶段顺序。

        Returns:
            [RECON, CLASSIFY, EXPLOIT, REPORT]
        """
        return list(self.RECON_PROGRESSION)

    def plan_campaign(
        self,
        targets: list[str],
        objective: str = "find all vulnerabilities",
    ) -> dict[str, Any]:
        """
        为整个蜂群攻击生成完整计划。

        Args:
            targets: 目标列表
            objective: 攻击目标描述

        Returns:
            包含里程碑、阶段顺序和规划元数据的字典
        """
        milestones = self.decompose_objective(objective)
        return {
            "targets": targets,
            "objective": objective,
            "milestones": [m.to_dict() for m in milestones],
            "phase_progression": [p.name for p in self.RECON_PROGRESSION],
            "planner_type": "pentest_swarm_ai",
        }


# ---------------------------------------------------------------------------
# 便捷函数 — 直接运行蜂群攻击（无需手动配置）
# ---------------------------------------------------------------------------
def run_swarm_campaign(
    targets: list[str],
    objective: str = "find all vulnerabilities",
    mode: str = "full",
) -> PhantomState:
    """
    便捷入口函数：一键启动蜂群攻击。

    自动使用默认 LLM 调度（返回 None 表示模拟模式）。
    实际使用时需传入 llm_invoke 回调。

    Args:
        targets: 目标列表
        objective: 攻击目标
        mode: 攻击模式

    Returns:
        PhantomState: 包含所有发现的最终状态
    """
    orchestrator = SwarmOrchestrator(
        llm_invoke=_default_llm_stub,
        max_iterations=50,
    )

    # 注册默认工具
    _register_default_tools(orchestrator)

    return orchestrator.run_campaign(targets, objective, mode)


def run_phased_campaign(
    targets: list[str],
    objective: str = "find all vulnerabilities",
) -> PhantomState:
    """便捷入口函数：按阶段执行蜂群攻击。"""
    orchestrator = SwarmOrchestrator(
        llm_invoke=_default_llm_stub,
        max_iterations=50,
    )
    _register_default_tools(orchestrator)
    return orchestrator.run_phased(targets, objective)


def _default_llm_stub(*args, **kwargs):
    """默认 LLM 存根 — 返回 None 表示未配置真实 LLM。"""
    return None


def _register_default_tools(orchestrator: SwarmOrchestrator) -> None:
    """注册一组默认工具到编排器。"""
    # 这些是蜂群攻击中的标准工具占位符
    default_tools = [
        ToolDefinition(
            name="reconnaissance",
            description="Discover attack surface: subdomains, ports, services, endpoints",
            parameters={"targets": "array of target URLs or hostnames"},
        ),
        ToolDefinition(
            name="classify",
            description="Classify findings: CVE mapping, CVSS scoring, false positive filtering",
            parameters={"findings": "list of raw findings to classify"},
        ),
        ToolDefinition(
            name="exploit",
            description="Execute exploitation against confirmed vulnerabilities",
            parameters={"target": "vulnerability target", "method": "exploit method"},
        ),
        ToolDefinition(
            name="generate_report",
            description="Generate professional penetration test report",
            parameters={"findings": "all confirmed findings", "format": "report format"},
        ),
    ]
    for tool in default_tools:
        orchestrator.register_tool(tool)
