#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google Dorking — Google Hacking 侦察模块。

通过 Google Custom Search API（免费 100 次/天）和公开搜索引擎，
利用 OWASP Google Hacking Database (GHDB) 中的 dorks 进行信息收集。

无需浏览器、无需 Selenium，纯 requests + JSON API。

Usage:
    from scanners.google_dorker import google_dork, get_owasp_ghdb
    result = google_dork("example.com", tags=["crlf", "xss"])
"""

import json
import logging
import time
from typing import Dict, List, Optional
from urllib.parse import quote_plus, urlparse

logger = logging.getLogger('google_dorker')

# OWASP GHDB (Google Hacking Database) 核心 dorks 分类
# https://www.exploit-db.com/google-hacking-database
GHDB_CATEGORIES = {
    "crlf": {
        "name": "CRLF Injection",
        "dorks": [
            'inurl:".php?wp="&page=" ext:php',
            'intext:"CRLE" inurl:".asp?"',
            'site:.com/..%252f..%252fetc/passwd',
        ],
    },
    "xss": {
        "name": "XSS (Cross-Site Scripting)",
        "dorks": [
            'inurl:"=http://*?"?',
            'inurl:?q=http://*',
            '"<script>" inurl:.php',
        ],
    },
    "sensitive_files": {
        "name": "敏感文件/配置泄露",
        "dorks": [
            'ext:env "APP_KEY" OR "DB_PASSWORD"',
            'ext:yml OR ext:yaml "password:" inurl:config',
            'ext:sql OR ext:dump "INSERT INTO"',
            'ext:json "api_key" OR "secret_key"',
            'ext:log "error" OR "traceback"',
            'intitle:"index of" "backup" OR "database" OR "dump"',
        ],
    },
    "sensitive_dirs": {
        "name": "敏感目录暴露",
        "dorks": [
            'inurl:"/admin" OR "/administrator" site:',
            'intitle:"index of" "/wp-admin/"',
            '"index of /" "config.php" OR "settings.py"',
        ],
    },
    "auth_bypass": {
        "name": "认证绕过/登录页面",
        "dorks": [
            'inurl:"login" OR "signin" inurl:".php?id=" site:',
            '"password reset" OR "forgot password" site:',
            'ext:php "remember me" OR "log in"',
        ],
    },
    "api_endpoints": {
        "name": "API 端点暴露",
        "dorks": [
            'inurl:"/api/" ext:json',
            'inurl:"swagger.json" OR "swagger.yaml" OR "openapi"',
            'inurl:"graphql" OR "graphiql" site:',
            '"endpoint" AND ("api-key" OR "apikey" OR "x-api-key") inurl:".yaml" OR ".yml"',
        ],
    },
    "subdomains": {
        "name": "子域名发现",
        "dorks": [
            'site:*.example.com',
            'site:"app.example.com" OR site:"dev.example.com" OR site:"staging.example.com"',
        ],
    },
    "exposed_data": {
        "name": "暴露的数据/用户信息",
        "dorks": [
            '"@gmail.com" OR "@yahoo.com" inurl:".php?"',
            'ext:csv "email" OR "phone" OR "password"',
            'intitle:"index of" "users.csv" OR "credentials.csv"',
            'site:example.com filetype:pdf OR docx OR xlsx',
        ],
    },
    "sql_injection": {
        "name": "SQL 注入点",
        "dorks": [
            'inurl:".php?id=" OR inurl:"?page=" OR inurl:"/search?" site:',
            'intext:"Warning: mysql_fetch" OR "mysql_num_rows"',
            'intitle:"error encountered" OR "SQL syntax" site:',
        ],
    },
    "ssrf": {
        "name": "SSRF 相关端点",
        "dorks": [
            'inurl:"url=" OR inurl:"page=" OR inurl:"path=" ext:php site:',
            'inurl:"proxy" OR inurl:"redirect" OR inurl:"goto" OR inurl:"forward" ext:php',
            'inurl:"load=" OR inurl:"include=" OR inurl:"doc=" ext:php',
        ],
    },
}


def _google_cse_search(query: str, api_key: str, cx: str, num: int = 10) -> List[dict]:
    """Google Custom Search API（免费 tier: 100 QPS/day）

    Args:
        query: dork 查询字符串
        api_key: Google API Key (https://console.cloud.google.com/apis/credentials)
        cx: Google CX/Programmatic Search Engine ID
            (https://programmablesearchengine.google.com/controlpanel/create) → "Only search the web" + site:target
        num: 返回结果数（最大 10）

    Returns:
        [{"title": "...", "url": "...", "snippet": "..."}, ...]
    """
    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "q": query,
        "key": api_key,
        "cx": cx,
        "num": min(num, 10),
    }

    results = []
    try:
        import requests as req
        resp = req.get(url, params=params, timeout=30)
        data = resp.json()

        for item in data.get("items", []):
            results.append({
                "title": item.get("title", ""),
                "url": item.get("link", ""),
                "snippet": (item.get("snippet", "") or "")[:500],
            })
    except Exception as e:
        logger.warning(f"Google CSE API 请求失败: {e}")

    return results


def _google_search_fallback(query: str, max_results: int = 20) -> List[dict]:
    """备用方案：通过 Google 公开搜索页（无 API key，但有 rate limit）。"""
    results = []
    base_url = "https://www.google.com/search"
    params = {"q": query, "num": min(max_results, 20)}

    try:
        import requests as req
        resp = req.get(base_url, params=params, timeout=30, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept-Language": "en-US,en;q=0.9",
        })
        if resp.status_code != 200:
            return []

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "html.parser")
        for a_tag in soup.find_all("a"):
            href = a_tag.get("href", "")
            if href and "/url?q=" in href:
                url = href.split("/url?q=")[1].split("&")[0]
                title = a_tag.get_text(strip=True) or ""
                snippet = a_tag.find_next_sibling("span")
                if snippet:
                    snippet = snippet.get_text(strip=True) or ""
                else:
                    snippet = ""

                results.append({
                    "title": title[:100],
                    "url": url,
                    "snippet": snippet[:500],
                })

    except Exception as e:
        logger.warning(f"Google fallback 搜索失败: {e}")

    return results


def get_owasp_ghdb() -> dict:
    """返回所有可用的 OWASP GHDB dork 分类。"""
    cats = {}
    for key, val in GHDB_CATEGORIES.items():
        cats[key] = {
            "name": val["name"],
            "count": len(val["dorks"]),
            "dorks": val["dorks"],
        }
    return {"ok": True, "categories": cats, "total_dorks": sum(v["count"] for v in cats.values())}


def google_dork(
    domain: str = "",
    tags: List[str] = None,
    api_key: str = "",
    cx: str = "",
    max_per_query: int = 10,
) -> dict:
    """执行 Google Dorking 侦察。

    Args:
        domain: 目标域名（可选，用于 site:限定）
        tags: dork 分类标签列表，如 ["sensitive_files", "api_endpoints"]，默认全部
        api_key: Google API Key（可选，有 key 则用 CSE API；无 key 则 fallback 到公开搜索）
        cx: Google CX ID（与 api_key 配合使用）
        max_per_query: 每个 dork 最多返回结果数

    Returns:
        {
            "ok": True,
            "domain": "example.com",
            "results": [
                {"dork": "...", "category": "sensitive_files", "title": "...", "url": "..."},
            ],
            "total_findings": N,
            "error": ""
        }
    """
    domain = (domain or "").strip()
    if domain and not domain.startswith("site:"):
        parsed = urlparse(f"https://{domain}")
        site_domain = parsed.hostname or domain

    # Filter categories
    if tags:
        cats_to_run = {k: v for k, v in GHDB_CATEGORIES.items() if k in tags}
    else:
        cats_to_run = GHDB_CATEGORIES

    all_results = []

    for tag, cat_data in cats_to_run.items():
        for dork in cat_data["dorks"]:
            # Append site: if domain specified
            full_dork = f"{dork} site:{site_domain}" if domain else dork

            hits = []
            # Try CSE API first if key provided
            if api_key and cx:
                hits = _google_cse_search(full_dork, api_key, cx, num=max_per_query)
                time.sleep(0.15)  # CSE free tier limit: ~1 QPS
            else:
                # Fallback to public search
                hits = _google_search_fallback(full_dork, max_results=max_per_query)

            for h in hits:
                all_results.append({
                    "dork": dork,
                    "category": cat_data["name"],
                    "tag": tag,
                    "title": h.get("title", ""),
                    "url": h.get("url", ""),
                    "snippet": h.get("snippet", ""),
                })

    return {
        "ok": True,
        "domain": domain or "all",
        "results": all_results[:500],
        "total_findings": len(all_results),
        "tags_searched": list(cats_to_run.keys()),
        "dorks_used": sum(len(v["dorks"]) for v in cats_to_run.values()),
        "error": "",
    }


def dork_by_keyword(
    keyword: str = "",
    domain: str = "",
) -> dict:
    """按关键词搜索 Google Dorks（通用侦察）。"""
    results = []
    keywords_to_dorks = {
        "pass": 'ext:txt OR ext:log "password" site:',
        "secret": '"secret" OR "api_key" OR "apikey" filetype:json OR yaml OR yml',
        "key": 'inurl:env OR inurl:config "API_KEY" OR "PRIVATE_KEY"',
    }

    for kw, dork in keywords_to_dorks.items():
        full = f"{dork} {keyword}" if keyword else dork
        hits = _google_search_fallback(full)
        for h in hits[:5]:
            results.append({
                "keyword": kw,
                "title": h.get("title", ""),
                "url": h.get("url", ""),
                "snippet": h.get("snippet", "")[:300],
            })

    return {"ok": True, "results": results, "total": len(results)}
