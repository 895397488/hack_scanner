"""Scan profile management -- Acunetix-like scan-depth presets.

Provides ``ScanProfile`` named presets (quick / basic / thorough / professional)
with module lists, timeout, rate-limit and concurrency settings, a ``ProfileManager``
that loads presets from config.json scan_profiles section and can switch between them,
a convenience ``apply_profile()`` that mutates the global CONFIG['urls'] and
CONFIG['scanner'] in-place, and a ``list_profiles()`` helper for discovery.

Referenced in: Acunetix data/profiles/ design concept.
"""

from __future__ import annotations

import json
import os
import copy
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Defaults used when CONFIG / config.json are not available
# ---------------------------------------------------------------------------

DEFAULT_SCANNER_CONF: Dict[str, Any] = {
    "ssl": False,
    "headers": False,
    "waf_bypass": False,
    "xss": False,
    "sqli": False,
    "lfi": False,
    "rce": False,
    "cors": False,
    "subdomain_scan": False,
    "dir_busting": False,
    "waf_fingerprint": False,
    "ssrf": False,
    "xxe": False,
    "deserialization": False,
    "jwt_attacks": False,
    "graphql": False,
    "oob_tests": False,
    "distributed": False,
}

DEFAULT_URLS_CONF: Dict[str, Any] = {
    "check_ssl": True,
    "check_headers": True,
    "check_cors": True,
    "check_sqli": True,
    "check_xss": True,
    "check_ssrf": True,
    "check_rce": True,
    "check_lfi": True,
    "check_xxe": True,
    "delay_between_requests": 0.5,
}


# ---------------------------------------------------------------------------
# ScanProfile dataclass
# ---------------------------------------------------------------------------

@dataclass
class ScanProfile:
    """A named scan-depth preset mirroring Acunetix profile concepts.

    Attributes:
        name: Short identifier -- one of ``quick``, ``basic``, ``thorough``,
            or ``professional``.
        description: Human-readable summary shown in ``list_profiles()`` output.
        estimated_duration_min: Rough wall-clock minutes for a single target.
        modules: Ordered list of scanner module names that are enabled when this
            profile is applied. Each entry maps to a key in the scanner config.
        timeout_sec: Overall scan timeout in seconds.
        rate_limit_rpm: Maximum requests per minute per target host.
        concurrency: Number of concurrent workers / threads.
    """

    name: str
    description: str
    estimated_duration_min: int
    modules: List[str] = field(default_factory=list)
    timeout_sec: int = 300
    rate_limit_rpm: int = 60
    concurrency: int = 4


# ---------------------------------------------------------------------------
# Built-in presets -- sensibly scoped, sorted by increasing coverage
# ---------------------------------------------------------------------------

_PRESETS: Dict[str, ScanProfile] = {
    "quick": ScanProfile(
        name="quick",
        description="SSL checks, header analysis and WAF detection only (~5 min per target).",
        estimated_duration_min=5,
        modules=["ssl", "headers", "waf_bypass"],
        timeout_sec=300,
        rate_limit_rpm=120,
        concurrency=8,
    ),
    "basic": ScanProfile(
        name="basic",
        description="Quick profile plus XSS, SQLi, LFI, RCE and CORS tests (~20 min per target).",
        estimated_duration_min=20,
        modules=[
            "ssl",
            "headers",
            "waf_bypass",
            "xss",
            "sqli",
            "lfi",
            "rce",
            "cors",
        ],
        timeout_sec=1200,
        rate_limit_rpm=90,
        concurrency=6,
    ),
    "thorough": ScanProfile(
        name="thorough",
        description="Basic profile plus subdomain discovery, directory brute-forcing and WAF fingerprinting (~1 hr per target).",
        estimated_duration_min=60,
        modules=[
            "ssl",
            "headers",
            "waf_bypass",
            "xss",
            "sqli",
            "lfi",
            "rce",
            "cors",
            "subdomain_scan",
            "dir_busting",
            "waf_fingerprint",
        ],
        timeout_sec=3600,
        rate_limit_rpm=60,
        concurrency=4,
    ),
    "professional": ScanProfile(
        name="professional",
        description="All modules: thorough profile plus SSRF, XXE, deserialization, JWT attacks, GraphQL and out-of-band testing.",
        estimated_duration_min=120,
        modules=[
            "ssl",
            "headers",
            "waf_bypass",
            "xss",
            "sqli",
            "lfi",
            "rce",
            "cors",
            "subdomain_scan",
            "dir_busting",
            "waf_fingerprint",
            "ssrf",
            "xxe",
            "deserialization",
            "jwt_attacks",
            "graphql",
            "oob_tests",
            "distributed",
        ],
        timeout_sec=14400,
        rate_limit_rpm=40,
        concurrency=3,
    ),
}


# ---------------------------------------------------------------------------
# ProfileManager
# ---------------------------------------------------------------------------

class ProfileManager:
    """Load presets from config.json scan_profiles section, switch between profiles.

    Typical usage::

        mgr = ProfileManager()               # loads built-ins + config.json
        current = mgr.active_profile          # introspect
        mgr.set_profile("quick")              # switch
        json_blob = mgr.export_json()         # serialise current
    """

    def __init__(self, presets: Optional[Dict[str, ScanProfile]] = None) -> None:
        """Initialise with built-in presets, extended by config.json.

        Args:
            presets: A mapping of ``{name: ScanProfile}`` that replaces the
                built-in set when provided directly.  When ``None`` (default)
                the manager loads from :data:`_PRESETS` and then overlays any
                user-defined presets found in config.json under
                ``scan_profiles.presets``.
        """
        if presets is not None:
            self._profiles: Dict[str, ScanProfile] = copy.deepcopy(presets)
        else:
            self._profiles: Dict[str, ScanProfile] = copy.deepcopy(_PRESETS)

        # Overlay external presets from config.json scan_profiles section.
        self._load_external()

        self._active_name: str = "thorough"  # default profile

    def _load_external(self) -> None:
        """Load user-defined presets from config.json if present.

        Reads the ``scan_profiles.presets`` key and merges each entry into
        the active registry, overriding built-in presets with the same name.
        """
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config.json",
        )
        if not os.path.isfile(config_path):
            return

        try:
            with open(config_path, "r", encoding="utf-8") as fh:
                config = json.load(fh)
        except (json.JSONDecodeError, OSError):
            return

        presets_section = config.get("scan_profiles", {})
        external_presets = presets_section.get("presets", {})
        if not external_presets:
            return

        default_timeout = presets_section.get("default_timeout", 3600)
        default_rpm = presets_section.get("default_rate_limit_rpm", 60)

        for name, raw in external_presets.items():
            if not isinstance(raw, dict):
                continue

            # Map config.json keys to ScanProfile fields.
            raw_modules = raw.get("modules", [])

            # Handle "all_basic" / "all" aliases for convenience.
            expanded: List[str] = []
            for m in raw_modules:
                if m == "all_basic":
                    # Alias -- inline expansion of basic set.
                    expanded.extend(_PRESETS["basic"].modules)
                elif m == "all":
                    # Alias -- all professional modules.
                    expanded.extend(_PRESETS["professional"].modules)
                else:
                    expanded.append(m)

            timeout_sec = raw.get("timeout", default_timeout)
            rate_limit_rpm = raw.get("rate_limit_rpm", default_rpm)
            concurrency = raw.get("concurrency", 4)
            description = raw.get("description", f"Custom preset ({name}).")
            estimated_duration_min = raw.get(
                "duration_min", _PRESETS[name].estimated_duration_min
            ) if name in _PRESETS else raw.get("duration_min", timeout_sec // 60)

            self._profiles[name] = ScanProfile(
                name=name,
                description=description,
                estimated_duration_min=estimated_duration_min,
                modules=expanded,
                timeout_sec=int(timeout_sec),
                rate_limit_rpm=int(rate_limit_rpm),
                concurrency=int(concurrency),
            )

    # -- properties ---------------------------------------------------------

    @property
    def active_profile(self) -> ScanProfile:
        """Return the currently active :class:`ScanProfile`."""
        return self._profiles[self._active_name]

    @property
    def available_profiles(self) -> List[str]:
        """Return names of all registered profiles (built-in + custom)."""
        return list(self._profiles.keys())

    # -- loading / switching ------------------------------------------------

    def load_from_dict(self, presets: Dict[str, ScanProfile]) -> None:
        """Deep-copy *presets* on top of (and potentially overriding) current registry.

        Args:
            presets: Mapping of profile-name to :class:`ScanProfile`.

        Raises:
            ValueError: If any preset has an empty name or is not a ScanProfile.
        """
        for _name, pval in presets.items():
            if not isinstance(pval, ScanProfile):
                raise ValueError(
                    f"Value for '{_name}' must be a ScanProfile, "
                    f"got {type(pval).__name__}"
                )
        self._profiles = copy.deepcopy({**self._profiles, **presets})

    def set_profile(self, name: str) -> None:
        """Switch the active profile by *name*.

        Args:
            name: One of ``'quick'``, ``'basic'``, ``'thorough'``,
                ``'professional'`` or any custom preset added via
                :meth:`load_from_dict` or loaded from config.json.

        Raises:
            KeyError: If *name* is not registered.
        """
        if name not in self._profiles:
            raise KeyError(
                f"Unknown profile '{name}'. Available: {list(self._profiles.keys())}"
            )
        self._active_name = name

    # -- export -------------------------------------------------------------

    def export_json(self, pretty: bool = True) -> str:
        """Serialise the active profile to a JSON string.

        Args:
            pretty: If ``True`` (default), indent the output for readability.

        Returns:
            A JSON string representing the active :class:`ScanProfile`.
        """
        data = asdict(self.active_profile)
        dumps = json.dumps(data, indent=2 if pretty else None)
        return f"// Profile: {self.active_profile.name}\n{dumps}"

    def export_dict(self) -> Dict[str, Any]:
        """Return the active profile as a plain Python dict."""
        return {**asdict(self.active_profile), "name": self.active_profile.name}


# ---------------------------------------------------------------------------
# Convenience: apply_profile -- mutates CONFIG in-place
# ---------------------------------------------------------------------------

def apply_profile(
    name: str,
    config_scanner: Optional[Dict[str, Any]] = None,
    config_urls: Optional[Dict[str, Any]] = None,
) -> ScanProfile:
    """Apply the named profile to CONFIG['urls'] and CONFIG['scanner'] **in-place**.

    This is a thin wrapper around :class:`ProfileManager` that modifies the global
    ``CONFIG`` dict so it can serve as the live scanner configuration. When
    *config_scanner* or *config_urls* are provided they are used directly instead
    of reading from the global CONFIG -- this is useful for testing and for callers
    that keep their config in separate dicts.

    Args:
        name: Profile identifier (e.g. ``'quick'``, ``'basic'``).
        config_scanner: If provided, this dict becomes CONFIG['scanner'] and is
            mutated in-place to enable only the modules from *name*.  When
            ``None`` the global CONFIG is used.
        config_urls: If provided, this dict becomes CONFIG['urls'] and is mutated
            in-place for rate-limit / concurrency tweaks.  When ``None`` the
            global CONFIG is used.

    Returns:
        The :class:`ScanProfile` that was applied (for chaining / inspection).

    Raises:
        KeyError: If *name* is not a registered preset.
        RuntimeError: If CONFIG is not available when neither config_scanner nor
            config_urls is given.
    """
    mgr = ProfileManager()
    mgr.set_profile(name)
    prof = mgr.active_profile

    if config_scanner is not None and config_urls is not None:
        # Caller supplied explicit dicts -- mutate them directly.
        scanner = config_scanner
        urls = config_urls
    else:
        # Locate CONFIG -- look for it as a module-level global on common import
        # paths so this helper is maximally portable across projects.
        config = _get_config()
        if config is None:
            raise RuntimeError(
                "apply_profile(): CONFIG not available in any known import path. "
                "Pass config_scanner / config_urls explicitly for testing."
            )
        scanner = config.setdefault("scanner", {})
        urls = config.setdefault("urls", {})

    # --- scanner modules ---
    # Read the union of all known module keys and disable them first.
    _known_modules = set(DEFAULT_SCANNER_CONF.keys())
    _known_modules.update(scanner.keys())
    for _key in list(_known_modules):
        scanner[_key] = False

    # Then enable only the modules belonging to this profile.
    for _mod in prof.modules:
        scanner[_mod] = True

    # Set top-level scanner knobs that mirror the ScanProfile.
    scanner["timeout"] = prof.timeout_sec
    scanner["concurrent"] = prof.concurrency

    # --- urls / timing knobs ---
    urls["delay_between_requests"] = round(60.0 / prof.rate_limit_rpm, 2)
    urls.setdefault("max_pages", _default_max_pages(prof.name))

    # Also mirror rate-limit into scanner section if it exists there.
    rl = scanner.get("rate_limit", {})
    if isinstance(rl, dict):
        rl["enabled"] = True
        rl["per_domain_sec"] = round(60.0 / prof.rate_limit_rpm, 2)

    return prof


def list_profiles() -> Dict[str, Dict[str, Any]]:
    """Return profile metadata keyed by name.

    Each value is a dict with keys:

    - ``name`` (str) -- short identifier.
    - ``module_count`` (int) -- number of scanner modules enabled.
    - ``estimated_duration_min`` (int) -- rough wall-clock minutes per target.
    - ``description`` (str) -- human-readable summary.

    Returns:
        A dict mapping profile name to its metadata, sorted by name.
    """
    mgr = ProfileManager()
    result: Dict[str, Dict[str, Any]] = {}
    for _name in sorted(mgr.available_profiles):
        prof = mgr._profiles[_name]
        result[_name] = {
            "name": prof.name,
            "module_count": len(prof.modules),
            "estimated_duration_min": prof.estimated_duration_min,
            "description": prof.description,
        }
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_config() -> Optional[Dict[str, Any]]:
    """Locate the global CONFIG dict from common import paths."""
    # Try local module first.
    try:
        import __main__ as main_mod  # type: ignore[import-not-found]
        if hasattr(main_mod, "CONFIG"):
            return main_mod.CONFIG  # type: ignore[attr-defined]
    except Exception:
        pass

    # Walk known package names.
    for mod_name in (
        "__main__",
        "config",
        "settings",
        "hack_scanner.config",
        "hack_scanner.settings",
    ):
        try:
            mod = __import__(mod_name)  # type: ignore[arg-type]
            if hasattr(mod, "CONFIG"):
                return mod.CONFIG
        except (ImportError, ModuleNotFoundError):
            pass

    return None


def _default_max_pages(profile: str) -> int:
    """Return a sensible default max_pages for the given profile."""
    _defaults = {
        "quick": 250,
        "basic": 1000,
        "thorough": 5000,
        "professional": 999999,
    }
    return _defaults.get(profile, 1000)


# ---------------------------------------------------------------------------
# CLI entry-point -- quick preview when run directly
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    print("Available scan profiles:")
    for p_name, p_data in list_profiles().items():
        print(
            f"  {p_name:14s}  modules={p_data['module_count']}"
            f"  ~{p_data['estimated_duration_min']:3d} min"
            f"  -- {p_data['description']}"
        )

    if len(sys.argv) > 1:
        _conf_scanner: Dict[str, Any] = {}
        _conf_urls: Dict[str, Any] = {}
        profile = apply_profile(sys.argv[1])
        print(f"\nApplied profile '{profile.name}':")
        print(json.dumps(_conf_scanner, indent=2))
