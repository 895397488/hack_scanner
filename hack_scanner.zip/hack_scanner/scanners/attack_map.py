#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
attack_map.py — MITRE ATT&CK 映射引擎（A）
=====================================================================

用途
----
把 campaign 的 findings（+ 可选工具历史）映射到 MITRE ATT&CK Enterprise
technique，产出三样东西：

1. AttackReport — 结构化映射结果（tactic/technique/confidence/severity 聚合）
2. Navigator layer JSON — 可直接拖进 https://mitre-attack.github.io/attack-navigator/
3. Markdown 报告段 — 覆盖统计条 + 按 tactic 分组的 technique 清单

参照实现
--------
vulnclaw intel/attack.py（site-packages/vulnclaw/intel/attack.py，1108 行）：
  - TACTICS / TECHNIQUES 数据模型（Tactic / Technique / TechniqueMapping / AttackReport）
  - _FINDING_RULES（正则 → technique+confidence 表）
  - TOOL_TECHNIQUE_MAP（工具名 → technique 表）
  - _build_navigator_layer（置信度 4/3/2 + severity 加分 → Navigator score）
  - format_report / format_summary（Markdown 输出）
本模块照搬算法与数据结构，API 适配 hack_scanner（纯标准库，不 import vulnclaw）。

finding 字段约定
----------------
兼容 hack_scanner 的 finding dict：title / vuln_type / type / evidence /
description / severity。匹配文本 = 上述字段拼接（全小写不敏感正则）。

Navigator score 规则（同 vulnclaw）
-----------------------------------
  high confidence → 4（红）；medium → 3（橙）；low → 2（黄）
  severity 加分：Critical +1.0；High +0.5；其余 +0
  同一 technique 取最高分（max 聚合），comment 聚合所有来源。

零 orchestrator 改动：纯报告层，run_adaptive 收尾时调用
map_findings() + save_attack_artifacts()，非阻塞、异常静默跳过。

纯标准库（Python 3.14），零第三方依赖，零网络。
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

__all__ = [
    "Tactic",
    "Technique",
    "TechniqueMapping",
    "AttackReport",
    "TACTICS",
    "TECHNIQUES",
    "map_findings",
    "build_navigator_layer",
    "navigator_json",
    "format_report",
    "format_summary",
    "save_attack_artifacts",
]

# ── ATT&CK 常量 ─────────────────────────────────────────────────────────────
ATTACK_VERSION = "15"
NAVIGATOR_VERSION = "4.5"
NAV_DOMAIN = "enterprise-attack"


@dataclass(frozen=True)
class Tactic:
    id: str
    name: str
    short_name: str
    description: str = ""

    def to_dict(self) -> Dict[str, str]:
        return {"id": self.id, "name": self.name, "shortName": self.short_name}


@dataclass(frozen=True)
class Technique:
    id: str
    name: str
    tactic_ids: Tuple[str, ...]
    description: str = ""
    is_subtechnique: bool = False
    parent_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "tactic_ids": list(self.tactic_ids),
            "description": self.description,
            "is_subtechnique": self.is_subtechnique,
            "parent_id": self.parent_id,
        }


@dataclass
class TechniqueMapping:
    technique: Technique
    source: str          # "finding" | "tool"
    source_name: str
    confidence: str      # "high" | "medium" | "low"
    notes: str = ""
    severity: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "technique": self.technique.to_dict(),
            "source": self.source,
            "source_name": self.source_name,
            "confidence": self.confidence,
            "notes": self.notes,
            "severity": self.severity,
        }


@dataclass
class AttackReport:
    target: str = ""
    total_findings: int = 0
    total_tools: int = 0
    mappings: List[TechniqueMapping] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        by_tactic: Dict[str, List[Dict[str, Any]]] = {}
        unique_techniques: Set[str] = set()

        for m in self.mappings:
            unique_techniques.add(m.technique.id)
            for tac_id in m.technique.tactic_ids:
                tac = TACTIC_MAP.get(tac_id)
                tac_name = tac.name if tac else tac_id
                by_tactic.setdefault(tac_name, []).append(m.to_dict())

        return {
            "target": self.target,
            "total_findings": self.total_findings,
            "total_tools": self.total_tools,
            "total_mappings": len(self.mappings),
            "unique_techniques": len(unique_techniques),
            "tactics_covered": len(by_tactic),
            "total_tactics": len(TACTICS),
            "by_tactic": by_tactic,
        }


# ── ATT&CK Tactic 全集（Enterprise v15）─────────────────────────────────────
TACTICS: List[Tactic] = [
    Tactic("TA0043", "Reconnaissance", "reconnaissance", "Gathering information to plan future operations."),
    Tactic("TA0042", "Resource Development", "resource-development", "Establishing resources to support operations."),
    Tactic("TA0001", "Initial Access", "initial-access", "Trying to get into your network."),
    Tactic("TA0002", "Execution", "execution", "Trying to run malicious code."),
    Tactic("TA0003", "Persistence", "persistence", "Trying to maintain their foothold."),
    Tactic("TA0004", "Privilege Escalation", "privilege-escalation", "Trying to gain higher-level permissions."),
    Tactic("TA0005", "Defense Evasion", "defense-evasion", "Trying to avoid being detected."),
    Tactic("TA0006", "Credential Access", "credential-access", "Trying to steal account names and passwords."),
    Tactic("TA0007", "Discovery", "discovery", "Trying to figure out your environment."),
    Tactic("TA0008", "Lateral Movement", "lateral-movement", "Trying to move through your environment."),
    Tactic("TA0009", "Collection", "collection", "Trying to gather data of interest."),
    Tactic("TA0011", "Command and Control", "command-and-control", "Trying to communicate with compromised systems."),
    Tactic("TA0010", "Exfiltration", "exfiltration", "Trying to steal data."),
    Tactic("TA0040", "Impact", "impact", "Trying to manipulate, interrupt, or destroy data and systems."),
]

TACTIC_MAP: Dict[str, Tactic] = {t.id: t for t in TACTICS}


# ── ATT&CK Technique（Web 渗透相关精选子集）──────────────────────────────────
def _tech(tid: str, name: str, tactics: List[str], desc: str = "",
          sub: bool = False, parent: str = "") -> Technique:
    return Technique(tid, name, tuple(tactics), desc, sub, parent)


TECHNIQUES: List[Technique] = [
    # Reconnaissance
    _tech("T1595", "Active Scanning", ["TA0043"], "Scanning infrastructure to gather information."),
    _tech("T1595.002", "Vulnerability Scanning", ["TA0043"], "Scanning systems for vulnerabilities.", True, "T1595"),
    _tech("T1592", "Gather Victim Host Information", ["TA0043"], "Gathering information about victim hosts."),
    _tech("T1592.002", "Software", ["TA0043"], "Gathering information about victim host software.", True, "T1592"),
    _tech("T1590", "Gather Victim Network Information", ["TA0043"], "Gathering information about victim networks."),
    _tech("T1590.005", "IP Addresses", ["TA0043"], "Gathering victim IP address information.", True, "T1590"),
    _tech("T1593", "Search Open Websites/Domains", ["TA0043"], "Searching freely available websites and domains."),
    _tech("T1596", "Search Open Technical Databases", ["TA0043"], "Searching freely available technical databases."),
    _tech("T1580", "Client Execution", ["TA0043"], "Gathering information about client endpoints."),
    # Initial Access
    _tech("T1190", "Exploit Public-Facing Application", ["TA0001"], "Exploiting software in public-facing applications to gain initial access."),
    _tech("T1133", "External Remote Services", ["TA0001"], "Interacting with web-based services exposed externally."),
    _tech("T1566", "Phishing", ["TA0001"], "Sending malicious links or attachments to targets."),
    # Execution
    _tech("T1059", "Command and Scripting Interpreter", ["TA0002"], "Abusing system interpreters to execute commands."),
    _tech("T1059.004", "Unix", ["TA0002"], "Abusing the Unix shell to execute commands.", True, "T1059"),
    _tech("T1059.006", "Python", ["TA0002"], "Abusing the Python interpreter.", True, "T1059"),
    _tech("T1203", "Exploitation for Client Execution", ["TA0002"], "Exploiting software to run code on endpoints."),
    _tech("T1189", "Drive-by Compromise", ["TA0001"], "Compromising users through drive-by downloads."),
    # Persistence
    _tech("T1505.003", "Web Shell", ["TA0003"], "Using web shells to maintain access.", True, "T1505"),
    _tech("T1098", "Account Manipulation", ["TA0003"], "Modifying credentials or permissions of accounts."),
    # Privilege Escalation
    _tech("T1068", "Exploitation for Privilege Escalation", ["TA0004"], "Abusing errors in software to escalate privileges."),
    _tech("T1548", "Abuse Elevation Control Mechanism", ["TA0004"], "Abusing elevation control mechanisms."),
    _tech("T1621", "Pipeline Content Manipulation", ["TA0042"], "Abusing CI/CD build pipelines (supply chain)."),
    # Defense Evasion
    _tech("T1070", "Indicator Removal", ["TA0005"], "Removing or obfuscating indicators of compromise."),
    _tech("T1070.004", "File Deletion", ["TA0005"], "Removing files to avoid detection.", True, "T1070"),
    _tech("T1562", "Impair Defenses", ["TA0005"], "Disabling security tools or mechanisms."),
    _tech("T1027", "Obfuscated Files or Information", ["TA0005"], "Obfuscating payloads to evade detection."),
    # Credential Access
    _tech("T1110", "Brute Force", ["TA0006"], "Using combinations of usernames and passwords to gain access."),
    _tech("T1110.003", "Password Spraying", ["TA0006"], "Trying a small number of passwords against many accounts.", True, "T1110"),
    _tech("T1552", "Unsecured Credentials", ["TA0006"], "Accessing credentials stored in cleartext."),
    _tech("T1552.001", "Credentials In Files", ["TA0006"], "Accessing credentials stored in files.", True, "T1552"),
    _tech("T1555", "Credentials from Password Stores", ["TA0006"], "Accessing OS and application password stores."),
    # Discovery
    _tech("T1046", "Network Service Scanning", ["TA0007"], "Scanning local networks for services."),
    _tech("T1082", "System Information Discovery", ["TA0007"], "Querying for system information."),
    _tech("T1083", "File and Directory Discovery", ["TA0007"], "Enumerating files and directories."),
    _tech("T1087", "Account Discovery", ["TA0007"], "Enumerating accounts."),
    _tech("T1087.001", "Local Account", ["TA0007"], "Enumerating local accounts.", True, "T1087"),
    _tech("T1069", "Permission Groups Discovery", ["TA0007"], "Enumerating permission groups."),
    # Lateral Movement
    _tech("T1021", "Remote Services", ["TA0008"], "Using client and server applications to move laterally."),
    _tech("T1021.001", "Remote Desktop Protocol", ["TA0008"], "Using RDP to move laterally.", True, "T1021"),
    _tech("T1021.004", "SSH", ["TA0008"], "Using SSH to move laterally.", True, "T1021"),
    _tech("T1135", "Remote Desktop Protocol", ["TA0008"], "Using RDP against internal systems."),
    # Collection
    _tech("T1005", "Data from Local System", ["TA0009"], "Collecting data from the local file system."),
    _tech("T1005.001", "Clipboard Data", ["TA0009"], "Collecting clipboard data.", True, "T1005"),
    _tech("T1039", "Data from Network Shared Drive", ["TA0009"], "Collecting data from network shares."),
    _tech("T1048", "Exfiltration Over Alternative Protocol", ["TA0010"], "Exfiltrating data via non-standard protocols."),
    _tech("T1567", "Exfiltration Over Web Service", ["TA0010"], "Exfiltrating data via cloud or web services."),
    _tech("T1213", "Data from Information Repositories", ["TA0009"], "Collecting data from wikis and CMMS."),
    # Command and Control
    _tech("T1040", "Network Sniffing", ["TA0011"], "Sniffing network traffic for credentials and data."),
    _tech("T1041", "Exfiltration Over C2 Channel", ["TA0011"], "Exfiltrating data over the C2 channel."),
    _tech("T1572", "Protocol Tunneling", ["TA0011"], "Tunneling C2 traffic."),
    _tech("T1132", "Data Encoding", ["TA0011"], "Encoding data to evade detection."),
    # Exfiltration
    _tech("T1048.002", "Exfiltration to Cloud Storage", ["TA0010"], "Uploading data to cloud storage.", True, "T1048"),
    # Impact
    _tech("T1485", "Data Destruction", ["TA0040"], "Destroying data on systems."),
    _tech("T1486", "Data Encrypted for Impact", ["TA0040"], "Encrypting data to deny access (ransomware)."),
    _tech("T1489", "Service Stop", ["TA0040"], "Stopping or disabling services."),
    _tech("T1499", "Endpoint Encryption", ["TA0040"], "Encrypting endpoints."),
    _tech("T1499.002", "Mass Data Wiper", ["TA0040"], "Wiping large volumes of data.", True, "T1499"),
    # Web 应用专属（ATT&CK v14/v15 真实子技术）
    _tech("T1210", "Exploitation of Remote Services", ["TA0008"], "Exploiting vulnerable remote services."),
    _tech("T1190.001", "Web Application", ["TA0001"], "Exploitation of public-facing web applications.", True, "T1190"),
]

TECHNIQUE_MAP: Dict[str, Technique] = {t.id: t for t in TECHNIQUES}

# ── Finding 规则表（正则 → technique + confidence）─────────────────────────
# 每条: (compiled_regex, [(technique_id, confidence), ...], notes)
# 参照 vulnclaw _FINDING_RULES，补充 hack_scanner 检测器覆盖的 Web 场景。

def _re(pattern: str) -> re.Pattern:
    return re.compile(pattern, re.IGNORECASE)


FINDING_RULES: List[Tuple[re.Pattern, List[Tuple[str, str]], str]] = [
    # SQL Injection
    (_re(r"sql\s*injection|sqli|blind.?sql|union.?select|sqlmap|sql\s*注入"),
     [("T1190", "high"), ("T1059", "medium"), ("T1005", "medium")],
     "SQL 注入 → 应用层初始访问 + 命令执行 + 数据窃取"),

    # XSS
    (_re(r"cross.?site\s*script|xss|reflected\s*xss|stored\s*xss|dom.?xss|跨站脚本"),
     [("T1190", "high"), ("T1189", "medium"), ("T1555", "medium")],
     "XSS → 会话劫持 / 凭据窃取"),

    # Command Injection / RCE
    # BUG_REPORT [10]：裸 `rce` 无词边界会命中 "resou**rce**"（如 "resource
    # exhaustion" 的 DoS finding 被误映射到 RCE 规则）。加 \b。
    (_re(r"command\s*injection|remote\s*code\s*exec|\brce\b|os\s*command|shell\s*inject|命令注入|远程代码执行"),
     [("T1059", "high"), ("T1190", "high"), ("T1203", "high")],
     "命令注入 / RCE → 任意代码执行"),

    # File Inclusion / Path Traversal
    (_re(r"file\s*inclusion|path\s*traversal|directory\s*traversal|lfi|rfi|\.\./|文件包含|路径穿越"),
     [("T1083", "high"), ("T1005", "medium"), ("T1190", "medium")],
     "路径穿越 / 文件包含 → 文件系统访问"),

    # Authentication / weak credentials
    (_re(r"default\s*credential|weak\s*password|default.*password|brute.?forc|credential\s*stuff|password\s*spray|弱口令|默认凭据|暴力破解"),
     [("T1110", "high"), ("T1110.003", "medium"), ("T1552", "medium")],
     "弱认证 → 未授权访问"),

    # SSRF
    (_re(r"ssrf|server.?side\s*request\s*forgery|服务端请求伪造"),
     [("T1190", "high"), ("T1580", "medium"), ("T1048", "medium")],
     "SSRF → 内网探测 / 数据外带"),

    # CSRF
    (_re(r"csrf|cross.?site\s*request\s*forgery|跨站请求伪造"),
     [("T1190", "medium")],
     "CSRF → 未授权操作"),

    # IDOR / Access Control
    (_re(r"idor|insecure.*direct.*object|broken.*access.*control|privilege.*escalat|unauthorized.*access|access.*control|越权|水平越权|垂直越权"),
     [("T1190", "high"), ("T1068", "medium"), ("T1087.001", "medium")],
     "IDOR / 访问控制失效 → 越权数据访问"),

    # JWT
    (_re(r"jwt|json\s*web\s*token|token.*weak|alg.*none|算法混淆"),
     [("T1552", "high"), ("T1190", "medium"), ("T1078", "medium")],
     "JWT 弱密钥 / 算法混淆 → 会话伪造"),

    # Open ports / services
    (_re(r"open\s*port|exposed\s*service|unnecessary\s*service|unneeded\s*port|开放端口|暴露服务"),
     [("T1046", "high"), ("T1133", "medium")],
     "开放端口 → 扩大攻击面"),

    # SSH issues
    (_re(r"ssh.*weak|ssh.*vuln|weak\s*ssh|ssh.*password\s*auth|ssh.*root\s*login|ssh.*misconfig"),
     [("T1021.004", "high"), ("T1078", "medium"), ("T1552", "medium")],
     "SSH 弱配置 → 远程访问"),

    # RDP issues
    (_re(r"\brdp\b|remote\s*desktop|\b3389\b"),
     [("T1021.001", "high"), ("T1133", "high"), ("T1040", "medium")],
     "RDP 暴露 → 横向移动"),

    # SSL/TLS issues
    (_re(r"ssl|tls|certificate|cipher.*weak|heartbleed|poodle|beast|drown|弱加密|证书过期"),
     [("T1040", "medium"), ("T1562", "medium")],
     "弱加密 / 证书问题 → 流量拦截风险"),

    # Information disclosure
    (_re(r"information\s*disclos|info.*leak|server\s*header|version\s*disclos|banner\s*grab|stack\s*trace|error\s*message.*detail|debug.*mode|信息泄露|版本暴露"),
     [("T1592.002", "medium"), ("T1082", "medium"), ("T1046", "medium")],
     "信息泄露 → 辅助侦察"),

    # Directory listing
    (_re(r"directory\s*listing|index\s*of|dir.*listing.*enabled|目录枚举|目录列表"),
     [("T1083", "high"), ("T1213", "medium")],
     "目录列表 → 文件结构暴露"),

    # Subdomain / DNS
    (_re(r"subdomain|dns.*zone.*transfer|dns.*enum|axfr|subdomain.*takeover|子域名|DNS.*区域"),
     [("T1590", "high"), ("T1596", "medium"), ("T1593", "medium")],
     "DNS / 子域名枚举 → 基础设施发现"),

    # Web shell / backdoor
    (_re(r"web.?shell|backdoor|persist.*shell|reverse.*shell|webshell|后门"),
     [("T1505.003", "high"), ("T1059.004", "high"), ("T1027", "medium")],
     "Web shell / 后门 → 持久化访问"),

    # Privilege escalation
    (_re(r"privil.*escal|priv.*esc|setuid|suid|sudo.*vuln|root.*access|local.*root|权限提升"),
     [("T1068", "high"), ("T1548", "high")],
     "权限提升 → 提权"),

    # Misconfiguration
    (_re(r"misconfig|security.*header.*missing|cors.*misconfig|csp.*missing|hsts.*missing|x-frame|clickjack|配置错误|缺失安全头"),
     [("T1190", "medium"), ("T1046", "medium")],
     "配置缺陷 → 安全姿态弱化"),

    # DoS
    # BUG_REPORT [10]：裸 `dos` 无词边界会命中 "dos**age**"/"dos**sier**"。加 \b。
    (_re(r"denial.?of.?service|\bdos\b|ddos|slow.?loris|resource\s*exhaust|拒绝服务"),
     [("T1499", "high"), ("T1489", "medium"), ("T1485", "medium")],
     "DoS → 可用性影响"),

    # LDAP
    (_re(r"ldap.*injection|ldap.*enum|active\s*directory"),
     [("T1087", "medium"), ("T1069", "medium"), ("T1552", "medium")],
     "LDAP 注入 / 枚举 → 目录信息泄露"),

    # SMB / Network shares
    (_re(r"smb.*vuln|smb.*enum|network\s*share|null\s*session|eternalblue|ms17"),
     [("T1135", "high"), ("T1210", "high"), ("T1039", "medium")],
     "SMB 漏洞 → 横向移动 / 数据收集"),

    # SNMP
    (_re(r"snmp.*community|snmp.*public|snmp.*enum"),
     [("T1082", "medium"), ("T1046", "medium")],
     "SNMP 弱配置 → 系统信息暴露"),

    # Phishing
    (_re(r"phish|spear.*phish|social\s*engineer|钓鱼|社工"),
     [("T1566", "high"), ("T1189", "medium")],
     "钓鱼 → 初始访问"),

    # Credential in files
    (_re(r"credential.*file|password.*file|\.env.*exposed|config.*password|hardcoded.*password|api.?key.*exposed|硬编码.*密码|密钥.*暴露"),
     [("T1552.001", "high"), ("T1552", "high")],
     "文件内凭据 → 未授权访问"),

    # Data exfiltration
    (_re(r"data.*exfil|data.*leak|sensitive.*data.*exposed|pii.*exposed|数据外泄|敏感数据.*暴露"),
     [("T1048", "medium"), ("T1567", "medium"), ("T1048.002", "medium")],
     "数据暴露 → 外泄"),

    # Ransomware / encryption
    (_re(r"ransomware|encrypt.*impact|data.*destroy|勒索"),
     [("T1486", "high"), ("T1485", "high")],
     "勒索 / 数据破坏 → 影响"),

    # Account issues
    (_re(r"account.*lockout.*missing|no.*lockout|session.*fixation|session.*hijack|会话固定|会话劫持"),
     [("T1078", "medium"), ("T1110", "medium"), ("T1505.003", "medium")],
     "账户弱点 → 未授权访问"),

    # Log / monitoring
    (_re(r"no.*logging|logging.*disabled|audit.*missing|monitor.*missing|日志.*缺失"),
     [("T1070", "medium"), ("T1562", "medium")],
     "缺失日志 → 防御规避"),

    # Cloud
    (_re(r"s3.*bucket|cloud.*misconfig|azure.*exposed|gcp.*public|aws.*public|bucket.*public"),
     [("T1580", "high"), ("T1190", "medium"), ("T1048.002", "medium")],
     "云配置错误 → 资源暴露"),

    # CORS
    (_re(r"cors|cross.?origin|access.?control.?allow|origin.*wildcard"),
     [("T1190", "medium"), ("T1040", "medium")],
     "CORS 配置错误 → 跨域数据泄露"),

    # XXE
    (_re(r"xxe|xml.*external.*entity|xml.*inject|xml.*parse"),
     [("T1190", "high"), ("T1083", "medium"), ("T1005", "medium")],
     "XXE → 文件读取 / 内网探测"),

    # File upload
    (_re(r"file\s*upload|unrestrict.*upload|malicious.*upload|upload.*vuln|任意文件上传"),
     [("T1505.003", "high"), ("T1059.004", "high"), ("T1027", "medium")],
     "文件上传 → 持久化 / RCE"),

    # Deserialization
    (_re(r"deserializ|pickle|marshal|insecure.*serial|object.*inject|反序列化"),
     [("T1190", "high"), ("T1059.006", "high"), ("T1027", "medium")],
     "反序列化 → RCE"),

    # GraphQL
    (_re(r"graphql|introspection|query.*depth|batch.*query"),
     [("T1190", "medium"), ("T1087", "medium")],
     "GraphQL 注入 → 数据泄露"),

    # CRLF / Open redirect
    (_re(r"crlf|carriage\s*return|open\s*redirect|url.*redirect|重定向"),
     [("T1566", "medium"), ("T1189", "medium")],
     "CRLF / 开放重定向 → 钓鱼 / 会话劫持"),

    # Parameter pollution
    # BUG_REPORT [10]：裸 `hpp` 无词边界，子串误匹配风险。加 \b。
    (_re(r"parameter.*pollution|\bhpp\b|http.*param.*pollution"),
     [("T1190", "medium")],
     "HTTP 参数污染 → WAF 绕过 / 注入"),

    # Admin panel / debug
    (_re(r"admin.*panel|debug.*mode|debug.*endpoint|exposed.*admin|phpinfo|phpmyadmin|management.*console|后台暴露"),
     [("T1133", "high"), ("T1087.001", "medium"), ("T1552", "medium")],
     "后台 / 调试端点暴露 → 未授权访问"),

    # Outdated / unpatched
    (_re(r"outdated|end.?of.?life|eol|unpatched|cve-\d{4}|known.*vuln|update.*required|upgrade.*required|版本.*过期"),
     [("T1190", "high"), ("T1595.002", "medium")],
     "过期组件 → 已知漏洞利用"),
]

# ── 工具 → Technique 映射 ────────────────────────────────────────────────────
TOOL_TECHNIQUE_MAP: Dict[str, List[Tuple[str, str, str]]] = {
    "nmap": [
        ("T1046", "high", "Network service discovery / port scanning"),
        ("T1595.002", "high", "Active scanning of IP blocks"),
        ("T1592.002", "medium", "OS and service version fingerprinting"),
        ("T1082", "medium", "System information via service banners"),
    ],
    "nikto": [
        ("T1595.002", "high", "Web server vulnerability scanning"),
        ("T1190", "medium", "Testing for exploitable web vulnerabilities"),
    ],
    "nuclei": [
        ("T1595.002", "high", "Template-based vulnerability scanning"),
        ("T1190", "medium", "Testing for exploitable vulnerabilities"),
    ],
    "sqlmap": [
        ("T1190", "high", "SQL injection exploitation"),
        ("T1059", "high", "Command execution via SQL injection"),
        ("T1005", "medium", "Data extraction via SQL injection"),
    ],
    "gobuster": [
        ("T1593", "high", "Web directory brute force"),
        ("T1083", "high", "File and directory discovery"),
    ],
    "dirb": [
        ("T1593", "high", "Web directory brute force"),
        ("T1083", "high", "File and directory discovery"),
    ],
    "dirsearch": [
        ("T1593", "high", "Web directory brute force"),
        ("T1083", "high", "File and directory discovery"),
    ],
    "ffuf": [
        ("T1593", "high", "Fuzzing for hidden resources"),
        ("T1083", "medium", "File discovery"),
    ],
    "feroxbuster": [
        ("T1593", "high", "Web directory brute force"),
        ("T1083", "high", "File and directory discovery"),
    ],
    "hakrawler": [
        ("T1593", "high", "Crawling and content discovery"),
        ("T1590", "medium", "Subdomain discovery"),
    ],
    "subfinder": [
        ("T1593", "high", "Subdomain enumeration"),
        ("T1590", "medium", "Network information gathering"),
    ],
    "amass": [
        ("T1593", "high", "Subdomain enumeration"),
        ("T1590", "medium", "Network information gathering"),
        ("T1596", "medium", "Searching technical databases"),
    ],
    "theHarvester": [
        ("T1596", "high", "Searching open technical databases"),
        ("T1593", "medium", "Email and subdomain harvesting"),
    ],
    "hydra": [
        ("T1110", "high", "Brute force credential attacks"),
        ("T1110.003", "medium", "Password spraying"),
    ],
    "john": [
        ("T1110", "medium", "Offline password cracking"),
        ("T1555", "medium", "Credential recovery"),
    ],
    "hashcat": [
        ("T1110", "medium", "Offline password cracking"),
        ("T1555", "medium", "Credential recovery"),
    ],
    "wpscan": [
        ("T1595.002", "high", "WordPress vulnerability scanning"),
        ("T1190", "medium", "Testing for exploitable web vulnerabilities"),
    ],
    "trivy": [
        ("T1595.002", "high", "Container vulnerability scanning"),
    ],
    "checkov": [
        ("T1595.002", "medium", "Infrastructure-as-Code scanning"),
    ],
    "semgrep": [
        ("T1595.002", "medium", "Source code vulnerability scanning"),
    ],
    "trufflehog": [
        ("T1552.001", "high", "Secret discovery in repositories"),
        ("T1552", "medium", "Credential access"),
    ],
    "git-secret-scanner": [
        ("T1552.001", "high", "Secret discovery in git history"),
    ],
    "waf": [
        ("T1562", "medium", "WAF bypass / defense impairment"),
    ],
    "exploit": [
        ("T1190", "high", "Exploitation of public-facing application"),
        ("T1059", "high", "Command and scripting interpreter abuse"),
    ],
    "reconnaissance": [
        ("T1595.002", "high", "Reconnaissance / vulnerability scanning"),
        ("T1593", "medium", "Web discovery"),
    ],
}


# ── 核心：映射 ───────────────────────────────────────────────────────────────
def map_findings(
    findings: List[Dict[str, Any]],
    target: str = "",
    tool_history: Optional[List[Dict[str, Any]]] = None,
) -> AttackReport:
    """把 findings（+ 可选工具历史）映射到 ATT&CK techniques。

    findings: list of dict，字段兼容 title / vuln_type / evidence /
              description / severity（hack_scanner 约定）。
    tool_history: 可选 [{tool, ...}]（从 tool_log 提取工具名即可）。
    """
    report = AttackReport(target=target, total_findings=len(findings or []))
    seen: Set[str] = set()  # 去重: "source:technique_id:source_name"

    # 1) findings 映射
    for finding in (findings or []):
        if not isinstance(finding, dict):
            continue
        text = " ".join([
            str(finding.get("title") or ""),
            str(finding.get("vuln_type") or finding.get("type") or finding.get("type_") or ""),
            str(finding.get("description") or ""),
            str(finding.get("evidence") or ""),
            str(finding.get("recommendation") or ""),
        ]).strip()
        if not text:
            continue

        severity = str(finding.get("severity") or "Info")
        title = str(finding.get("title") or "Unknown")

        for pattern, tech_list, notes in FINDING_RULES:
            if not pattern.search(text):
                continue
            for tech_id, confidence in tech_list:
                technique = TECHNIQUE_MAP.get(tech_id)
                if not technique:
                    continue
                dedup_key = f"finding:{tech_id}:{title}"
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                report.mappings.append(TechniqueMapping(
                    technique=technique,
                    source="finding",
                    source_name=title,
                    confidence=confidence,
                    notes=notes,
                    severity=severity,
                ))

    # 2) 工具历史映射
    if tool_history:
        report.total_tools = len(tool_history)
        for entry in tool_history:
            if not isinstance(entry, dict):
                continue
            tool_name = str(entry.get("tool") or entry.get("name") or "").lower()
            if tool_name not in TOOL_TECHNIQUE_MAP:
                continue
            for tech_id, confidence, notes in TOOL_TECHNIQUE_MAP[tool_name]:
                technique = TECHNIQUE_MAP.get(tech_id)
                if not technique:
                    continue
                dedup_key = f"tool:{tech_id}:{tool_name}"
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                report.mappings.append(TechniqueMapping(
                    technique=technique,
                    source="tool",
                    source_name=tool_name,
                    confidence=confidence,
                    notes=notes,
                ))

    return report


# ── Navigator Layer JSON ─────────────────────────────────────────────────────
def build_navigator_layer(
    report: AttackReport,
    name: str = "",
    description: str = "",
) -> Dict[str, Any]:
    """生成 ATT&CK Navigator layer v4.5 JSON（可拖入 attack-navigator）。

    score 规则：
      high confidence → 4（红）；medium → 3（橙）；low → 2（黄）
      severity 加分：Critical +1.0；High +0.5
      同一 technique 取最高分（max 聚合）。
    """
    confidence_score = {"high": 4, "medium": 3, "low": 2}
    severity_bonus = {"critical": 1.0, "high": 0.5, "medium": 0.0, "low": 0.0, "info": 0.0}

    tech_scores: Dict[str, float] = {}
    tech_comments: Dict[str, List[str]] = {}

    for m in report.mappings:
        tid = m.technique.id
        base = confidence_score.get(m.confidence, 2)
        bonus = severity_bonus.get((m.severity or "").lower(), 0.0)
        score = base + bonus
        tech_scores[tid] = max(tech_scores.get(tid, 0.0), score)

        comment = f"[{m.source}] {m.source_name}"
        if m.notes:
            comment += f" — {m.notes}"
        tech_comments.setdefault(tid, []).append(comment)

    techniques: List[Dict[str, Any]] = []
    for tid, score in sorted(tech_scores.items()):
        tech = TECHNIQUE_MAP.get(tid)
        if not tech:
            continue
        tactic_refs: List[Dict[str, str]] = []
        for tac_id in tech.tactic_ids:
            tac = TACTIC_MAP.get(tac_id)
            if tac:
                tactic_refs.append({"tacticName": tac.short_name.replace("-", " ")})
        entry: Dict[str, Any] = {
            "techniqueID": tid,
            "score": score,
            "comment": "\n".join(tech_comments.get(tid, [])),
            "enabled": True,
        }
        if tactic_refs:
            entry["tacticReferences"] = tactic_refs
        techniques.append(entry)

    layer: Dict[str, Any] = {
        "name": name or (f"hack_scanner: {report.target}" if report.target else "hack_scanner Assessment"),
        "description": description or (
            f"Assessment of {report.target} — "
            f"{len(report.mappings)} technique mappings from "
            f"{report.total_findings} findings and {report.total_tools} tool executions"
        ),
        "domain": NAV_DOMAIN,
        "version": NAVIGATOR_VERSION,
        "attackVersion": ATTACK_VERSION,
        "techniques": techniques,
        "gradient": {"colors": ["#ffffff", "#ffffff", "#ffffff"],
                     "minValue": 0, "maxValue": 5},
        "showLegend": True,
    }
    return layer


def navigator_json(report: AttackReport, name: str = "", description: str = "") -> str:
    """Navigator layer JSON 字符串。"""
    layer = build_navigator_layer(report, name, description)
    return json.dumps(layer, indent=2, ensure_ascii=False)


# ── Markdown 报告 ────────────────────────────────────────────────────────────
def format_report(report: AttackReport) -> str:
    """把 ATT&CK 映射格式化为 Markdown 段。"""
    data = report.to_dict()
    lines = [
        "# MITRE ATT&CK Mapping\n",
        f"**Target:** {data['target'] or 'N/A'}",
        f"**Findings analysed:** {data['total_findings']}",
        f"**Tool executions:** {data['total_tools']}",
        f"**Technique mappings:** {data['total_mappings']}",
        f"**Unique techniques:** {data['unique_techniques']}",
        f"**Tactics covered:** {data['tactics_covered']}/{data['total_tactics']}",
        "",
    ]

    # 覆盖率条
    covered = data["tactics_covered"]
    total = data["total_tactics"]
    bar_filled = int((covered / max(total, 1)) * 20)
    bar = "█" * bar_filled + "░" * (20 - bar_filled)
    lines.append(f"**Coverage:** [{bar}] {covered}/{total} tactics\n")

    # 按 tactic 分组
    for tactic in TACTICS:
        tactic_mappings = data["by_tactic"].get(tactic.name, [])
        if not tactic_mappings:
            continue
        lines.append(f"\n## {tactic.name} ({tactic.id})\n")
        if tactic.description:
            lines.append(f"*{tactic.description}*\n")
        seen_techs: Set[str] = set()
        for m in tactic_mappings:
            tech = m["technique"]
            if tech["id"] in seen_techs:
                continue
            seen_techs.add(tech["id"])
            conf_icon = {"high": "🔴", "medium": "🟠", "low": "🟡"}.get(m["confidence"], "⚪")
            sev_str = f" [{m['severity']}]" if m.get("severity") else ""
            source_icon = "🔍" if m["source"] == "finding" else "🔧"
            lines.append(
                f"- {conf_icon} **{tech['id']}** — {tech['name']}"
                f"{sev_str} ({source_icon} {m['source_name']})"
            )
            if m.get("notes"):
                lines.append(f"  *{m['notes']}*")
        lines.append("")

    # 图例
    lines.extend([
        "\n---",
        "**Confidence:** 🔴 High | 🟠 Medium | 🟡 Low",
        "**Source:** 🔍 Finding | 🔧 Tool",
        "\n*Generated by hack_scanner*",
    ])
    return "\n".join(lines)


def format_summary(report: AttackReport) -> str:
    """ATT&CK 映射的简短摘要（1–3 行）。"""
    data = report.to_dict()
    tactics = list(data["by_tactic"].keys())

    lines = [
        f"📊 **ATT&CK Coverage:** {data['unique_techniques']} techniques, "
        f"{data['tactics_covered']}/{data['total_tactics']} tactics",
    ]
    if tactics:
        lines.append(f"**Tactics:** {', '.join(tactics[:6])}"
                     + ("…" if len(tactics) > 6 else ""))

    conf_counts: Dict[str, int] = {"high": 0, "medium": 0, "low": 0}
    for m in report.mappings:
        conf_counts[m.confidence] = conf_counts.get(m.confidence, 0) + 1
    parts = []
    if conf_counts.get("high"):
        parts.append(f"🔴 {conf_counts['high']} high")
    if conf_counts.get("medium"):
        parts.append(f"🟠 {conf_counts['medium']} medium")
    if conf_counts.get("low"):
        parts.append(f"🟡 {conf_counts['low']} low")
    if parts:
        lines.append(f"**Confidence:** {' | '.join(parts)}")
    return "\n".join(lines)


# ── 落盘 ─────────────────────────────────────────────────────────────────────
def save_attack_artifacts(
    report: AttackReport,
    out_dir: str,
    name: str = "",
) -> Tuple[str, str]:
    """把 ATT&CK 映射落到 out_dir：attack_map.md + attack_navigator.json。

    返回 (md_path, json_path)。任何异常向上抛（调用方决定是否吞）。
    """
    os.makedirs(out_dir, exist_ok=True)
    md_path = os.path.join(out_dir, "attack_map.md")
    json_path = os.path.join(out_dir, "attack_navigator.json")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(format_report(report))

    with open(json_path, "w", encoding="utf-8") as f:
        f.write(navigator_json(report, name=name))

    return md_path, json_path


# ── self-test（python scanners/attack_map.py）────────────────────────────────
if __name__ == "__main__":
    _findings = [
        {
            "title": "SQL Injection in /api/login",
            "vuln_type": "sqli",
            "severity": "Critical",
            "evidence": "UNION SELECT 1,2,3,4,5 --",
        },
        {
            "title": "Stored XSS in comment field",
            "vuln_type": "xss",
            "severity": "High",
            "evidence": "<script>alert(1)</script> reflected in <div>",
        },
        {
            "title": "IDOR: access other user's profile",
            "vuln_type": "idor",
            "severity": "High",
            "evidence": "GET /api/user/1 vs /api/user/2 both 200",
        },
        {
            "title": "Open RDP port 3389",
            "vuln_type": "port",
            "severity": "Medium",
            "evidence": "3389/tcp open ms-wbt-server",
        },
        {
            "title": "JWT alg=none accepted",
            "vuln_type": "jwt",
            "severity": "Critical",
            "evidence": "header alg:none → 200 OK",
        },
    ]
    _tools = [
        {"tool": "nmap"},
        {"tool": "nikto"},
        {"tool": "sqlmap"},
        {"tool": "reconnaissance"},
        {"tool": "exploit"},
    ]
    rep = map_findings(_findings, target="http://10.0.0.1", tool_history=_tools)

    assert rep.total_findings == 5, rep.total_findings
    assert rep.total_tools == 5, rep.total_tools
    assert len(rep.mappings) > 10, len(rep.mappings)

    # 关键 technique 命中
    mapped_ids = {m.technique.id for m in rep.mappings}
    assert "T1190" in mapped_ids, "SQLi/XSS/IDOR 都应映射到 T1190"
    assert "T1110" in mapped_ids or "T1552" in mapped_ids, "弱认证/JWT 应命中"
    assert "T1021.001" in mapped_ids, "RDP 应映射到 T1021.001"
    assert "T1059" in mapped_ids, "SQLi/RCE 应映射到 T1059"

    # Navigator layer 结构
    layer = build_navigator_layer(rep, name="self-test")
    assert layer["version"] == NAVIGATOR_VERSION, layer["version"]
    assert layer["domain"] == NAV_DOMAIN, layer["domain"]
    assert isinstance(layer["techniques"], list) and len(layer["techniques"]) > 5
    for t in layer["techniques"]:
        assert 0 < t["score"] <= 5.0, t
        assert "techniqueID" in t and "comment" in t and t["enabled"] is True

    # Navigator JSON 可解析
    nj = navigator_json(rep)
    parsed = json.loads(nj)
    assert parsed["version"] == NAVIGATOR_VERSION

    # Markdown 报告
    md = format_report(rep)
    assert "MITRE ATT&CK Mapping" in md
    assert "T1190" in md
    assert "Coverage:" in md

    # 摘要
    summary = format_summary(rep)
    assert "ATT&CK Coverage" in summary

    # 落盘
    import tempfile
    with tempfile.TemporaryDirectory() as _td:
        md_p, json_p = save_attack_artifacts(rep, _td, name="self-test")
        assert os.path.isfile(md_p) and os.path.getsize(md_p) > 200
        assert os.path.isfile(json_p) and os.path.getsize(json_p) > 200
        with open(json_p, encoding="utf-8") as _f:
            _pj = json.load(_f)
        assert _pj["name"] == "self-test"

    # 边界：空 findings
    empty = map_findings([], target="x")
    assert empty.total_findings == 0
    assert len(empty.mappings) == 0
    assert format_summary(empty).startswith("📊")

    # 边界：非 dict finding 不崩
    mixed = map_findings([None, "str", 42, {"title": "RCE via os.system"}], target="x")
    assert mixed.total_findings == 4
    assert len(mixed.mappings) > 0

    # 边界：finding 全空字段
    blank = map_findings([{"title": "", "vuln_type": ""}], target="x")
    assert len(blank.mappings) == 0

    print("attack_map self-test OK")
