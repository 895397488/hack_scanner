#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm 攻击策略注入层 — 把"零日导向"的打法变成首轮强提示
=====================================================================

背景（2026-09-14 vuln-sentinel 实战复盘）:
    20 轮 campaign 全部烧在 http_probe×14 / exploit×3 / run_detector×2 上，
    产出只有 info/low 级"垃圾漏洞"。根因不是迭代太少，而是【模型手里
    没有任何攻击先验】——系统提示只有生命周期纪律（别轮询、别空转），
    27b 级本地模型拿到"find all vulnerabilities"就退化成"GET 几个 URL、
    看看状态码、写报告"。

    而项目里其实有两件战略资产从未接进自适应循环:
      - scanners/swarm_prompt_examples.py  — IDOR / JWT / GraphQL BOLA
        few-shot 场景（自带 to_few_shot_messages()，为注入而生）
      - scanners/swarm_playbooks.py        — 7 个 playbook 的阶段清单
        （经 M12 的 consult_playbook 工具暴露）

本模块提供:
    STRATEGY_BLOCK   紧凑英文策略块（模型提示词是英文；小模型读长文会漏，
                     这里控制在 ~450 token，全部是硬纪律）
    build_injection() 构建首轮注入消息序列:
                     [user: 策略块, assistant: 确认, user: 场景Q, assistant: 场景A]
                     —— 合法 role 交替，可前置到 campaign 启动消息之前

设计纪律（沿用 M6/M7/M11 入口层模式）:
    - orchestrator 零改动：本模块只产出消息列表，由 run_adaptive 的
      install_strategy_coach 包装 llm_invoke 在【首轮调用前】前置
    - 纯函数、无副作用、无网络；import 失败不影响核心循环
    - 注入总量硬上限（MAX_INJECTION_CHARS），超预算的场景文本截断
"""

import os
import sys
from typing import Any, Dict, List, Optional

# 直接运行本文件时保证项目根目录在 sys.path（与 swarm_aux_tools 同一模式）
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# 注入总量上限（字符）。策略块 ~3k + 2 个场景 ~3k ≈ 6k，
# 27b 本地模型上下文吃得下，但再大就该砍场景而不是砍策略。
MAX_INJECTION_CHARS = 12000

# 单个场景 assistant 回复的截断上限（完整场景 ~1.6k，留 1.2k 足够表达打法）
_SCENARIO_ASSISTANT_MAX = 1200

# few-shot 场景选择（按"零日导向"价值排序：逻辑缺陷 > token 伪造 > API 面暴露）
_SCENARIO_ORDER = ["idor", "jwt", "graphql"]


# ---------------------------------------------------------------------------
# 策略块 — 硬纪律，不是建议
# ---------------------------------------------------------------------------
STRATEGY_BLOCK = """STRATEGY DIRECTIVE (higher priority than general scanning habits):

OBJECTIVE CLASS. The goal is a CONFIRMED high-impact chain, not a long list of minor findings:
- tier 1 (worth burning iterations): authz/BOLA/IDOR to other tenants' or admins' data; SSRF to cloud metadata or internal services; auth bypass; injection with real data exfiltration or command execution; business-logic abuse (step-skipping, enum/brute via rate limits, price/quantity tampering); deserialization; token/session forgery.
- tier 2 (byproduct — record if you already saw it, NEVER spend a probe on it): missing security headers, CORS misconfig, version disclosure, TLS/HTTP2 quirks, informational endpoints.

DEPTH OVER BREADTH.
- Work ONE hypothesis at a time. A hypothesis ends in exactly two states: CONFIRMED (show the diff/evidence) or RULED_OUT (state the specific control that blocks it). Then move on.
- Every request you send must falsify something. A 200/403 whose body is indistinguishable from a baseline you already saw is a null result — do not re-send it (that is polling, and it wastes the budget).

DIFFERENTIAL PROBING (the zero-day-class technique).
- Establish a baseline request, then a MODIFIED request: change one variable at a time — resource ID (try neighbor IDs, UUID swap, numeric ±1), tenant/org header or param, role/permission header, HTTP method, missing auth, parameter ordering, duplicate parameters (HPP), Content-Type switch.
- Anomalous DIFF = signal. Different status, different body length, an error naming an internal table/field, a field present in one tenant's response but 403 in another — dig 2-3 rounds deep on the diff before anything else.

HIGH-VALUE CHAINS FOR A CLOUD-HOSTED WEB APP (try in this order once surface is known):
1. IDOR/BOLA: any /api/* or object endpoint taking an id → baseline with your id, then another id / another tenant.
2. SSRF → cloud metadata: any parameter that fetches a URL (webhook/import/avatar/render) → try 169.254.169.254/latest/meta-data/ (AWS), 169.254.170.2 (GCP), internal hostnames.
3. Auth boundary: unauthenticated vs authenticated on the same endpoint; admin role header vs user; method swap (GET→POST→DELETE) on state-changing routes.
4. Token/session: JWT alg confusion / weak secret on any exposed token; session fixation; password-reset flow tampering.
5. Logic: multi-step flows (checkout, verification, approval) → skip a step, reorder, replay an earlier step.

BUDGET DISCIPLINE.
- Recon budget: max 2-3 calls. Once you have endpoints + tech, STOP enumerating and START attacking the top hypothesis above.
- Reserve the final 3 iterations for classify → generate_report → finish_scan.
- If stuck after 2 null results on a hypothesis: RULED_OUT it explicitly and move to the next chain. Silence is not a state."""


# ---------------------------------------------------------------------------
# 注入构建
# ---------------------------------------------------------------------------
def _scenario_pair(scenario_key: str) -> Optional[List[Dict[str, str]]]:
    """取一个 few-shot 场景并转成 user/assistant 消息对（assistant 截断保护）。"""
    try:
        from scanners.swarm_prompt_examples import SCENARIO_DATABASE
    except Exception:
        return None
    sc = SCENARIO_DATABASE.get(scenario_key)
    if sc is None:
        return None
    assistant = sc.assistant or ""
    if len(assistant) > _SCENARIO_ASSISTANT_MAX:
        assistant = assistant[:_SCENARIO_ASSISTANT_MAX] + " …[truncated]"
    return [
        {"role": "user", "content": (
            "SCENARIO (study the method, then apply it to the real campaign target):\n"
            + (sc.user or "")
        )},
        {"role": "assistant", "content": assistant},
    ]


def build_injection(scenarios: Optional[List[str]] = None) -> List[Dict[str, str]]:
    """构建首轮注入消息序列（合法 role 交替，可直接前置到 messages 头部）。

    结构:
        [user: 策略块] [assistant: 确认]
        [user: 场景Q]  [assistant: 场景A]   × N（默认 idor, jwt）

    scenarios 传空列表则只注入策略块（few-shot 全关）。
    返回 [] 表示注入被整体禁用（调用方应跳过包装）。
    """
    msgs: List[Dict[str, str]] = [
        {"role": "user", "content": STRATEGY_BLOCK},
        {"role": "assistant", "content": (
            "Understood. I will work depth-first on one high-impact hypothesis at a time, "
            "use differential probing to confirm or rule it out with evidence, and keep "
            "tier-2 findings as byproducts. Recon capped at 2-3 calls; final 3 iterations "
            "reserved for classify → report → finish."
        )},
    ]
    for key in (scenarios if scenarios is not None else _SCENARIO_ORDER[:2]):
        pair = _scenario_pair(key)
        if pair:
            msgs.extend(pair)
        # 总量保护：超上限即停（策略块本身必须完整保留）
        total = sum(len(m.get("content", "")) for m in msgs)
        if total > MAX_INJECTION_CHARS:
            break
    return msgs


def injection_char_count(scenarios: Optional[List[str]] = None) -> int:
    """注入总字符数（测试/日志用）。"""
    return sum(len(m.get("content", "")) for m in build_injection(scenarios))


if __name__ == "__main__":
    # 自测: 打印注入序列的结构与体积
    inj = build_injection()
    print(f"injection: {len(inj)} messages, "
          f"{sum(len(m['content']) for m in inj)} chars")
    for m in inj:
        print(f"  [{m['role']:9}] {m['content'][:70].replace(chr(10), ' ')} …")
