#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JWT Vulnerability Detector
===========================
借鉴 Pentest-Swarm-AI jwt_tool 适配器。
检测 JWT alg 混淆、none-alg 攻击、弱密钥、kid 注入等漏洞。
"""

import re
import base64
import hashlib
import hmac
import logging
from typing import List, Dict, Optional

logger = logging.getLogger('jwt_detector')


# Common weak JWT secrets (借鉴 jwt_tool default wordlist)
WEAK_SECRETS = [
    'secret', 'password', 'admin', 'key', 'token', 'jwt', 'auth',
    'changeme', 'default', 'test', '123456', 'abc123', 'privatekey',
    'your-secret-key', 'supersecret', 'topsecret', 'mysecret',
    'hmac-secret', ' signing-secret', 'jwt-secret', 'api-secret',
    'access-token', 'refresh-token', 'session', 'cookie',
]


def _b64url_decode(s: str) -> bytes:
    """Base64URL decode with padding fix"""
    s += '=' * (4 - s.count('=') % 4)
    return base64.urlsafe_b64decode(s.encode())


def _b64url_encode(data: bytes) -> str:
    """Base64URL encode without padding"""
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()


class JWTAnalyzer:
    """JWT 漏洞分析器 — 检测多种常见攻击面"""

    # Known JWT alg values to test
    ALG_CONFIGS = {
        'none': {'alg': 'none'},
        'HS256_fake_RSA': {'alg': 'RS256', 'key': 'dummy'},  # alg confusion
        'HS384_weak': {'alg': 'HS384', 'key': 'secret'},
        'HS512_weak': {'alg': 'HS512', 'key': 'secret'},
    }

    @staticmethod
    def detect(url: str, response_body: str = "") -> List[Dict]:
        """检测 JWT 相关漏洞"""
        findings = []

        # Step 1: Extract JWT tokens from URL and response
        tokens = JWTAnalyzer._extract_tokens(url, response_body)

        if not tokens:
            return findings

        logger.info(f"  JWT: Found {len(tokens)} token(s)")

        for i, token_info in enumerate(tokens):
            token = token_info['token']
            location = token_info['location']
            parts = token.split('.')

            # Must have 3 parts (header.payload.signature)
            if len(parts) != 3:
                continue

            findings.extend(JWTAnalyzer._analyze_token(token, parts, location))

        return findings

    @staticmethod
    def _extract_tokens(url: str, response_body: str = "") -> List[Dict]:
        """从 URL 和响应体中提取 JWT token"""
        tokens = []

        # Pattern for JWT in URL (query params or path)
        jwt_patterns = [
            r'(?<=[&?]token=)([A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})',
            r'(?<=[&?]jwt=)([A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})',
            r'(?<=[&?]access_token=)([A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})',
        ]

        for pattern in jwt_patterns:
            match = re.search(pattern, url)
            if match:
                tokens.append({'token': match.group(1), 'location': f'url param (match pattern {pattern})'})

        # Pattern for JWT in response body
        token_pattern = r'[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}'
        for match in re.finditer(token_pattern, response_body):
            tokens.append({'token': match.group(0), 'location': 'response body'})

        return tokens

    @staticmethod
    def _analyze_token(token: str, parts: List[str], location: str) -> List[Dict]:
        """分析单个 JWT token 的多种漏洞"""
        findings = []
        header_raw = parts[0]
        payload_raw = parts[1]
        signature_raw = parts[2]

        # Decode header
        try:
            header = _b64url_decode(header_raw)
            header_json = header.decode('utf-8', errors='replace')
            alg = None
            kid = None
            try:
                import json
                header_data = json.loads(header_json)
                alg = header_data.get('alg')
                kid = header_data.get('kid')
            except Exception:
                pass
        except Exception:
            return findings

        # ===== 1. none-alg attack (最关键漏洞) =====
        if alg and alg.lower() != 'none':
            # Try to verify with alg=none signature validation bypass
            none_alg_token = f"{header_raw}.{payload_raw}."  # empty signature
            findings.append({
                'id': 'JWT_NONE_ALG_ATTACK',
                'severity': 'critical',
                'title': 'JWT none-alg 认证绕过攻击面',
                'description': (
                    f'JWT token 使用 {alg} 算法签名，但存在被降维到 alg=none 的风险。'
                    f'Payload: {header_json[:200]}'
                ),
                'url': location,
                'evidence': (
                    f'原始 alg={alg}, token header: {header_json[:200]}\n'
                    f'攻击 payload: {none_alg_token[:150]}...'
                ),
                'recommendation': (
                    '服务端验证 JWT 时，强制检查 alg 字段不允许为 "none" 或 null；'
                    '使用白名单校验允许的算法列表（如 RS256/ES256）；'
                    '不要信任客户端提供的 alg 值'
                ),
                'cwe': 'CWE-327',
                'cvss': 9.8,
            })

        # ===== 2. Weak secret detection (HMAC 系列) =====
        if alg and alg.startswith('HS'):
            findings.extend(JWTAnalyzer._check_weak_secret(token, parts, location))

        # ===== 3. kid injection / path traversal =====
        if kid:
            # Check for suspicious kid values
            if '..' in kid or '/' in kid or '\\' in kid or ';' in kid or '&' in kid:
                findings.append({
                    'id': 'JWT_KID_INJECTION',
                    'severity': 'high',
                    'title': 'JWT kid 参数注入（可能路径遍历）',
                    'description': f'JWT header 中 kid 字段包含可疑字符: {kid[:100]}',
                    'url': location,
                    'evidence': f'kid={kid}',
                    'recommendation': '对 kid 参数进行白名单校验，禁止文件路径操作字符',
                    'cwe': 'CWE-20',
                    'cvss': 7.5,
                })

        # ===== 4. JWT in URL (information disclosure risk) =====
        if 'url' in location.lower():
            findings.append({
                'id': 'JWT_IN_URL',
                'severity': 'medium',
                'title': 'JWT Token 暴露于 URL（信息泄露风险）',
                'description': 'JWT Token 出现在 URL 中，可能被记录在服务器日志、浏览器历史、Referer 头中',
                'url': location,
                'evidence': f'Token found in URL parameter (location: {location})',
                'recommendation': '将 JWT Token 放在 Authorization header 的 Bearer scheme 中：\nAuthorization: Bearer <token>',
                'cwe': 'CWE-522',
                'cvss': 5.3,
            })

        # ===== 5. Unnecessary sensitive data in payload =====
        try:
            import json
            payload_json = _b64url_decode(payload_raw).decode('utf-8', errors='replace')
            payload_data = json.loads(payload_json)

            sensitive_fields = ['password', 'passwd', 'crypt', 'ssn', 'credit_card',
                              'cvv', 'cvc', 'exp_number', 'bank_account']
            found_sensitive = [f for f in sensitive_fields if f in str(payload_data).lower()]

            if found_sensitive:
                findings.append({
                    'id': 'JWT_SENSITIVE_DATA',
                    'severity': 'medium',
                    'title': 'JWT Payload 包含敏感数据',
                    'description': (
                        f'JWT payload 中包含明文敏感字段（Base64url 可逆编码，非加密）：'
                        f'{", ".join(found_sensitive)}'
                    ),
                    'url': location,
                    'evidence': f'Sensitive fields in payload: {found_sensitive}',
                    'recommendation': (
                        'JWT payload 仅供数据传输而非存储敏感数据。密码/银行卡/CVV 等应加密存储。\n'
                        'Base64 不是加密，任何持有 token 的人都可以解码查看内容。'
                    ),
                    'cwe': 'CWE-312',
                    'cvss': 5.9,
                })

            # ===== 6. Excessive token lifetime =====
            exp = payload_data.get('exp', 0)
            iat = payload_data.get('iat', 0)
            if isinstance(exp, int) and isinstance(iat, int) and exp > iat:
                lifetime_hours = (exp - iat) / 3600
                if lifetime_hours > 24 * 7:  # > 1 week
                    findings.append({
                        'id': 'JWT_EXPIRATION_LONG',
                        'severity': 'low' if lifetime_hours < 30 else 'medium',
                        'title': f'JWT Token 有效期过长 ({lifetime_hours:.0f} 小时)',
                        'description': f'Token 有效期为 {lifetime_hours:.0f} 小时（>7天），增加 token 被盗用风险窗口',
                        'url': location,
                        'evidence': f'exp={exp}, iat={iat}, lifetime={lifetime_hours:.0f}h',
                        'recommendation': '将 JWT 有效期缩短至 1-24 小时；配合 refresh token 机制使用',
                        'cwe': 'CWE-613',
                        'cvss': 3.7,
                    })

        except Exception:
            pass

        return findings

    @staticmethod
    def _check_weak_secret(token: str, parts: List[str], location: str) -> List[Dict]:
        """检查 JWT 是否使用弱密钥（HMAC 系列）"""
        findings = []
        alg = None
        try:
            import json
            header_json = base64.urlsafe_b64decode(parts[0] + '==').decode()
            header_data = json.loads(header_json)
            alg = header_data.get('alg', '')
        except Exception:
            return findings

        # Check against weak secrets
        signature = parts[2]
        signed_content = f"{parts[0]}.{parts[1]}".encode()

        for weak_secret in WEAK_SECRETS:
            expected_sig = _b64url_encode(
                hmac.new(weak_secret.encode(), signed_content, hashlib.sha256).digest()
            )
            if signature == expected_sig:
                findings.append({
                    'id': 'JWT_WEAK_SECRET',
                    'severity': 'critical',
                    'title': f'JWT 使用弱密钥 ({alg})',
                    'description': f'JWT token 的 HMAC 签名密钥为已知弱密钥: "{weak_secret}"',
                    'url': location,
                    'evidence': (
                        f'算法: {alg}\n'
                        f'发现弱密钥: {weak_secret}\n'
                        f'Token: {token[:100]}...\n\n'
                        f'攻击者可使用相同密钥伪造任意用户的 JWT token。\n'
                        f'测试过的弱密钥列表包含 {len(WEAK_SECRETS)} 个常见值。'
                    ),
                    'recommendation': (
                        '使用至少 256-bit 的强随机密钥（如: secrets.token_hex(32)）\n'
                        '不要使用字典词汇、固定字符串作为 JWT 签名密钥\n'
                        f'当前使用的 {len(WEAK_SECRETS)} 个弱密钥均已知，建议立即轮换所有 token 密钥。'
                    ),
                    'cwe': 'CWE-798',
                    'cvss': 9.8,
                })
                break  # Only report once per token

        return findings
