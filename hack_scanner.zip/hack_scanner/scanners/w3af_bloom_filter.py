#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
w3af Bloom Filter — 借鉴 w3af (w3af.org) scalable bloom filter 实现的高效 URL/响应去重。

用于在大规模扫描中快速判断一个 URL 或响应是否已经见过，避免重复探测：
- ScalableBloomFilter: 动态增长布隆过滤器 (w3af core implementation)
- SeekFileBloom: 持久化到磁盘的布隆过滤器 (适合长时间扫描会话)
- UniversalBloomFilter: 单例全局实例

Usage:
    from scanners.w3af_bloom_filter import ScalableBloomFilter, global_bloom

    bf = ScalableBloomFilter(initial_size=100_000)
    bf.add("https://example.com/admin?id=1")
    # fast O(1) membership test — ~0.1% false positive rate at this size

    if not bf.exists(normalized_url):
        bf.add(normalized_url)
        result = scan(normalized_url)  # only scan first-time URLs
"""

import hashlib
import math
import os
import struct
from dataclasses import dataclass, field
from typing import List, Optional


# ====================================================================
# Scalable Bloom Filter (w3af core implementation adaptation)
# ====================================================================

class ScalableBloomFilter:
    """
    Scalable Bloom filter that grows automatically as items are added.
    Based on w3af's scalable_bloom.py with error_rate parameter control.

    Key properties:
    - False positive rate is guaranteed < error_rate
    - Memory usage grows linearly with number of items
    - O(1) add and exists operations
    """

    # Default: 0.1% false positive rate
    DEFAULT_ERROR_RATE = 0.001

    def __init__(self, initial_size: int = 100_000, error_rate: float = DEFAULT_ERROR_RATE):
        self._error_rate = error_rate
        self._current_filter = BitArrayBloomFilter(initial_size)
        self._filters: List[BitArrayBloomFilter] = [self._current_filter]
        self._size = 0
        self._m = initial_size  # total bit array size across all filters

    def add(self, item: str):
        """Add an item to the bloom filter. Returns True if item was new (not previously seen)."""
        normalized = self._normalize(item)
        already_exists = self.exists(normalized)
        if not already_exists:
            self._current_filter.add(normalized)
            self._size += 1
            # Check if we need to grow
            ratio = self._size / (self._m * self._error_rate)
            if ratio > 0.5:
                self._grow()
        return not already_exists

    def exists(self, item: str) -> bool:
        """Check if an item might be in the filter (O(1), with possible false positives)."""
        normalized = self._normalize(item)
        # Check from newest to oldest filter
        for f in reversed(self._filters):
            if not f.exists(normalized):
                return False  # Definitely not in any filter
        return True  # Possible match

    def clear(self):
        """Clear all bloom filters."""
        self._filters = []
        self._current_filter = BitArrayBloomFilter(self._m)
        self._filters.append(self._current_filter)
        self._size = 0

    @property
    def size(self) -> int:
        return self._size

    @property
    def filter_count(self) -> int:
        return len(self._filters)

    @property
    def memory_estimate_bytes(self) -> int:
        total = sum(f.bits_size for f in self._filters)
        return total + (self._m * 8)  # rough estimate including current buffer

    def _grow(self):
        """Grow the bloom filter by adding a new larger filter."""
        new_size = max(1000, int(self._current_filter.size / self._error_rate))
        new_filter = BitArrayBloomFilter(new_size)
        # Transfer all items from old filters to new one (they'll be checked in the new filter)
        self._current_filter = new_filter
        self._m += new_size
        self._filters.append(new_filter)

    @staticmethod
    def _normalize(item: str) -> str:
        """Normalize URL for consistent hashing."""
        # Remove trailing slashes and fragments for canonicalization
        normalized = item.rstrip('/')
        if '#' in normalized:
            normalized = normalized[:normalized.index('#')]
        return normalized.lower()


# ====================================================================
# BitArrayBloomFilter — core bit-array implementation
# ====================================================================

class BitArrayBloomFilter:
    """Core bloom filter backed by a bit array."""

    # Number of hash functions (optimal k ≈ ln(2) * m/n, use 7 for most cases)
    K_HASH_FUNCTIONS = 7

    def __init__(self, size: int):
        self._size = size
        self._bits = bytearray((size + 7) // 8)
        self.bits_size = (size + 7) // 8

    def add(self, item: str):
        for seed in range(self.K_HASH_FUNCTIONS):
            bit_index = self._hash(item, seed) % self._size
            self._set_bit(bit_index)

    def exists(self, item: str) -> bool:
        for seed in range(self.K_HASH_FUNCTIONS):
            bit_index = self._hash(item, seed) % self._size
            if not self._get_bit(bit_index):
                return False
        return True

    @property
    def size(self) -> int:
        return self._size

    def _set_bit(self, index: int):
        byte_idx = index // 8
        bit_idx = index % 8
        self._bits[byte_idx] |= (1 << bit_idx)

    def _get_bit(self, index: int) -> bool:
        byte_idx = index // 8
        bit_idx = index % 8
        return bool(self._bits[byte_idx] & (1 << bit_idx))

    @staticmethod
    def _hash(item: str, seed: int) -> int:
        """Compute a hash with the given seed as salt."""
        h = hashlib.sha256(f'{seed}:{item}'.encode('utf-8')).digest()
        return struct.unpack('<Q', h[:8])[0]


# ====================================================================
# SeekFileBloom — persistent bloom filter on disk (w3af seekfile_bloom.py)
# ====================================================================

@dataclass
class SeekFileBloom:
    """Persistent bloom filter backed by a file. Useful for long-running scans."""
    filepath: str = './scan_url_cache.bf'
    initial_size: int = 500_000

    _filter: Optional[ScalableBloomFilter] = field(default=None, repr=False)
    _initialized: bool = False

    def __post_init__(self):
        if os.path.exists(self.filepath):
            self._load()
        else:
            self._filter = ScalableBloomFilter(self.initial_size)
            self._save()

    @property
    def size(self) -> int:
        return self._filter.size if self._filter else 0

    def add(self, item: str):
        self._ensure_loaded()
        if self._filter and self._filter.add(item):
            self._save()  # persist on new items only

    def exists(self, item: str) -> bool:
        self._ensure_loaded()
        return bool(self._filter.exists(item)) if self._filter else False

    def _ensure_loaded(self):
        if not self._initialized or self._filter is None:
            self._load()
            self._initialized = True

    def _load(self):
        """Load from file (store size as hint only)."""
        try:
            with open(self.filepath, 'rb') as f:
                header = f.read(8)
                if len(header) == 8:
                    size_hint = struct.unpack('<Q', header)[0]
                    self._filter = ScalableBloomFilter(max(size_hint, self.initial_size))
        except (OSError, struct.error):
            self._filter = ScalableBloomFilter(self.initial_size)

    def _save(self):
        """Save size to file (for warm restart)."""
        try:
            with open(self.filepath, 'wb') as f:
                f.write(struct.pack('<Q', self._filter.size if self._filter else 0))
        except OSError:
            pass


# ====================================================================
# Global singleton (w3af global_bloom pattern)
# ====================================================================

_global_bloom: Optional[ScalableBloomFilter] = None

def get_global_bloom(initial_size: int = 500_000) -> ScalableBloomFilter:
    """Get or create the global singleton bloom filter (w3af pattern)."""
    global _global_bloom
    if _global_bloom is None:
        _global_bloom = ScalableBloomFilter(initial_size)
    return _global_bloom

def clear_global_bloom():
    """Clear the global singleton (useful between scans)."""
    global _global_bloom
    _global_bloom = None


# ====================================================================
# URL deduplication helper
# ====================================================================

class URLDeduplicator:
    """High-level URL deduplication using bloom filter + canonicalization."""

    def __init__(self, bf: Optional[ScalableBloomFilter] = None):
        self._bf = bf or get_global_bloom()

    def is_unique(self, url: str) -> bool:
        """Check if URL is unique (first time seen). Canonicalizes before checking."""
        canonical = self._canonicalize(url)
        return self._bf.add(canonical)

    def _canonicalize(self, url: str) -> str:
        """Canonicalize a URL for deduplication consistency."""
        from urllib.parse import urlparse, urlencode, parse_qs, urlunparse  # noqa: F811

        parsed = urlparse(url)
        # Normalize scheme + host
        scheme = parsed.scheme.lower() if parsed.scheme else 'https'
        netloc = parsed.hostname or ''
        if netloc and ':' in netloc:
            netloc = netloc[:netloc.rindex(':')]  # remove port for cross-port dedup

        # Sort query params for consistency
        params = parse_qs(parsed.query, keep_blank_values=True)
        sorted_params = urlencode(sorted(params.items()), doseq=True)

        path = parsed.path or '/'
        return f'{scheme}://{netloc}{path}?{sorted_params}'


# ====================================================================
# Convenience exports
# ====================================================================

def create_bloom_filter(initial_size: int = 100_000) -> ScalableBloomFilter:
    return ScalableBloomFilter(initial_size)
