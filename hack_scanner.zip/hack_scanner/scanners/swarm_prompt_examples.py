# from-source-of: Pentest-Swarm-AI
#
# 攻击场景示例数据库
# 源自 Pentest-Swarm-AI/internal/agent/prompts/examples/
#          api/01_graphql_introspection.json
#          auth/01_jwt_alg_confusion.json
#          web/01_idor.json
#
# 将 Go 源码中的 JSON examples 内嵌为 Python 数据结构，
# 提供 get_scenario_prompt() 查询接口。

"""
攻击场景示例数据库 -- Attack Scenario Database

将 Pentest-Swarm-AI 中的 few-shot 示例从 JSON 文件翻译为 Python 数据结构。
支持按 attack_type 快速检索对应的详细 prompt。

数据来源:
    examples/api/01_graphql_introspection.json
    examples/auth/01_jwt_alg_confusion.json
    examples/web/01_idor.json

使用方式:
    from scanners.swarm_prompt_examples import get_scenario_prompt, SCENARIO_DATABASE

    # 获取 IDOR 攻击场景的详细 prompt
    scenario = get_scenario_prompt("idor")
    print(scenario["user"])
    print(scenario["assistant"])

    # 浏览所有可用场景
    for attack_type, data in SCENARIO_DATABASE.items():
        print(f"{attack_type}: {data['vuln_class']} -- {data['title']}")
"""

from typing import Any


# ---------------------------------------------------------------------------
# AttackScenario: 单个攻击场景的完整数据（对应 JSON example 结构）
# ---------------------------------------------------------------------------
class AttackScenario:
    """
    单个攻击场景的数据载体。

    对应 Go 源码中的 example struct:
        Category  string `json:"category"`
        VulnClass string `json:"vuln_class"`
        Title     string `json:"title"`
        User      string `json:"user"`
        Assistant string `json:"assistant"`
    """

    def __init__(self, category: str, vuln_class: str, title: str, user: str, assistant: str):
        self.category = category
        self.vuln_class = vuln_class
        self.title = title
        self.user = user
        self.assistant = assistant

    def to_dict(self) -> dict[str, Any]:
        """导出为字典（对应 JSON 序列化）。"""
        return {
            "category": self.category,
            "vuln_class": self.vuln_class,
            "title": self.title,
            "user": self.user,
            "assistant": self.assistant,
        }

    def to_few_shot_messages(self) -> list[dict[str, str]]:
        """导出为 few-shot 消息对（可直接注入 LLM prompt）。"""
        return [
            {"role": "user", "content": self.user},
            {"role": "assistant", "content": self.assistant},
        ]


# ---------------------------------------------------------------------------
# SCENARIO_DATABASE: 内嵌的攻击场景数据库
# ---------------------------------------------------------------------------
SCENARIO_DATABASE: dict[str, AttackScenario] = {
    # ---------------------------------------------------------------
    # graphql : GraphQL 端点探测 + BOLA
    # 对应 examples/api/01_graphql_introspection.json
    # ---------------------------------------------------------------
    "graphql": AttackScenario(
        category="api",
        vuln_class="GraphQL introspection + BOLA",
        title="Introspection-leaked schema reveals admin-only fields callable by regular user",
        user=(
            "Discovered /graphql endpoint accepts POST application/json. Sent the standard introspection query and received the full schema. "
            "Among the surfaced types: a `User` type with fields `email`, `phoneNumber`, `internalNotes`, and a `Query.user(id: ID!): User` "
            "resolver that takes any user ID."
        ),
        assistant=(
            "RECON: introspection is enabled in what appears to be production. The schema exposes a Query.user(id: ID!) resolver "
            "that takes any ID and returns the User type -- including fields that look administrative (internalNotes) or PII-grade (email, phoneNumber).\n\n"

            "HYPOTHESIS: two compounding issues.\n"
            "(a) Introspection-in-production is information disclosure (medium).\n"
            "(b) The real bug, likely worth the bounty: Query.user(id: $id) probably lacks authorization. "
            "The schema lets any authenticated caller request any user by ID. If the resolver enforces no per-field auth, "
            "this is BOLA + PII exposure.\n\n"

            "TEST:\n"
            "1. With user_A's session, POST { query: \"{ user(id: \\\"<user_B's id>\\\") { email phoneNumber internalNotes } }\" }.\n"
            "2. If the response returns user_B's email/phone/notes, BOLA is confirmed.\n"
            "3. Try a tenant-boundary jump too: enumerate IDs across a known organizational gap to see if cross-tenant access is also possible.\n\n"

            "INDICATOR: response data contains another user's PII without an authorization error.\n\n"

            "Notes for follow-up exploration triggered by the schema:\n"
            "- Look for mutations like updateUser / deleteUser that may also be unauthorized.\n"
            "- Field-suggestion leak: send malformed queries to see if the error includes \"did you mean...\" hints that reveal more fields than introspection showed.\n"
            "- Test alias-based BOLA: ask for many users in one query via aliases -- sometimes per-call rate-limits don't apply to aliased fields in a single document.\n"
            "- GraphQL depth/complexity DoS is a separate ticket -- record but don't trigger.\n\n"

            "Report the introspection-in-prod finding regardless (low/medium), and the BOLA separately as critical if confirmed."
        ),
    ),

    # ---------------------------------------------------------------
    # jwt : JWT 算法混淆攻击
    # 对应 examples/auth/01_jwt_alg_confusion.json
    # ---------------------------------------------------------------
    "jwt": AttackScenario(
        category="auth",
        vuln_class="JWT algorithm confusion",
        title="RS256 -> HS256 algorithm confusion via public key as secret",
        user=(
            "Login flow returns a JWT in the Authorization header. Decoded header: {\"alg\":\"RS256\",\"typ\":\"JWT\"}. "
            "The /.well-known/jwks.json endpoint is publicly accessible and returns the RSA public key. Logged-in actions are "
            "authenticated by sending this JWT back."
        ),
        assistant=(
            "RECON: server signs JWTs with RS256 (asymmetric: private key signs, public key verifies). The public key is exposed at /.well-known/jwks.json -- "
            "this is normal and expected. The risk is whether the server's JWT library accepts an algorithm-switched token.\n\n"

            "HYPOTHESIS: JWT algorithm confusion. If the JWT verification code naively passes the token's alg header to the verifier function, "
            "an attacker can forge a token signed with HS256 (symmetric) using the PUBLIC KEY as the HMAC secret. The verifier will use the public key "
            "(which it knows) to verify the HMAC, and the signature will validate.\n\n"

            "TEST: minimal probe:\n"
            "1. Fetch the public key from /.well-known/jwks.json.\n"
            "2. Take an existing valid JWT, modify the payload (e.g. set `sub` to an admin user's identifier, or extend `exp`).\n"
            "3. Change the alg header to HS256.\n"
            "4. Sign the new token with HMAC-SHA256 using the public key PEM bytes as the secret.\n"
            "5. Send the forged JWT to a protected endpoint.\n\n"

            "INDICATOR: if the server accepts the forged token and returns the admin user's data (or honors the elevated claims), "
            "algorithm confusion is confirmed.\n\n"

            "Secondary checks to queue:\n"
            "- alg=none acceptance (set header alg=none, remove signature)\n"
            "- weak HS256 secret (offline crack with hashcat against common secrets)\n"
            "- kid (key ID) injection -- SQL injection or path traversal in the kid header"
        ),
    ),

    # ---------------------------------------------------------------
    # idor : 不安全的直接对象引用
    # 对应 examples/web/01_idor.json
    # ---------------------------------------------------------------
    "idor": AttackScenario(
        category="web",
        vuln_class="IDOR",
        title="Sequential order ID enumeration with second-user auth state",
        user=(
            "Recon surfaced: GET /api/orders/12345 returns the full order object (line items, shipping address, payment-method last-4) when "
            "authenticated with the current user's Bearer token. The ID 12345 is sequential -- adjacent orders likely belong to other users. "
            "Two authenticated sessions (user_A, user_B) are held on the blackboard."
        ),
        assistant=(
            "RECON: endpoint /api/orders/{id} returns sensitive PII (shipping address, payment last-4). ID is sequential. The risk pattern is classic IDOR -- "
            "the backend likely authenticates the request (Bearer token valid) but does not authorize (does not check that the order belongs to the token's user).\n\n"

            "HYPOTHESIS: IDOR / BOLA. The endpoint trusts the URL-supplied ID without checking it against the authenticated user's order list. OWASP API #1.\n\n"

            "TEST: minimum probe is to replay the same endpoint with user_A's Bearer token but a different order ID -- specifically an order ID known to belong to user_B "
            "(or simply an adjacent ID like 12344 / 12346). If the response body returns valid order data (not 403 / 404 / empty), IDOR is confirmed.\n\n"

            "If the indicator is a 200 with PII for an order that user_A did not place, that is the confirmation. I will:\n"
            "1. Issue GET /api/orders/12344 with user_A's token.\n"
            "2. Compare the response's owner identity against user_A's known order list.\n"
            "3. If different owner -> record finding with status, body fragment, and reproduction request."
        ),
    ),
}


# ---------------------------------------------------------------------------
# get_scenario_prompt: 按攻击类型查询场景 prompt
# ---------------------------------------------------------------------------
def get_scenario_prompt(attack_type: str) -> dict[str, Any]:
    """
    根据攻击类型获取对应的详细场景 prompt。

    对应 Go 源码的 FewShot(category, n) + loadExample():
        - 按 category（即 attack_type）检索示例
        - 返回 user/assistant 消息对

    Args:
        attack_type: 攻击类型（graphql/jwt/idor/sqlxss/ssrf/general 等）

    Returns:
        {"user": str, "assistant": str, "category": str, "vuln_class": str, "title": str}
        如果找不到匹配的 attack_type，返回 None。
    """
    scenario = SCENARIO_DATABASE.get(attack_type)
    if scenario is None:
        return None

    return {
        "user": scenario.user,
        "assistant": scenario.assistant,
        "category": scenario.category,
        "vuln_class": scenario.vuln_class,
        "title": scenario.title,
    }


# ---------------------------------------------------------------------------
# get_all_scenarios: 获取所有可用攻击场景
# ---------------------------------------------------------------------------
def get_all_scenarios() -> dict[str, dict[str, Any]]:
    """
    返回所有可用的攻击场景（按 attack_type 索引）。

    Returns:
        {attack_type: {"user": ..., "assistant": ..., ...}}
    """
    return {k: v.to_dict() for k, v in SCENARIO_DATABASE.items()}


# ---------------------------------------------------------------------------
# get_scenarios_by_category: 按分类检索攻击场景
# ---------------------------------------------------------------------------
def get_scenarios_by_category(category: str) -> list[dict[str, Any]]:
    """
    按漏洞分类检索所有攻击场景。

    Args:
        category: 分类名称（api/auth/web/crypto/pwn/rev/forensics/cloud）

    Returns:
        匹配的分类列表
    """
    return [v.to_dict() for v in SCENARIO_DATABASE.values() if v.category == category]


# ---------------------------------------------------------------------------
# get_scenario_for_hypothesis: 根据假设自动推荐攻击场景
# ---------------------------------------------------------------------------
def get_scenario_for_hypothesis(hypothesis: str) -> dict[str, Any]:
    """
    根据发现的线索（假设）自动推荐最匹配的攻击场景。

    Args:
        hypothesis: 从侦察中发现的线索字符串

    Returns:
        最匹配的场景，如果找不到则返回 None
    """
    lower = hypothesis.lower()

    # 关键词 -> attack_type 映射
    keyword_map = [
        (["graphql", "gql", "apollo"], "graphql"),
        (["jwt", "token", "bearer", "oauth", "sso"], "jwt"),
        (["id.", "order/", "/users/", "/profile/", "account"], "idor"),
        (["sql", "query", "database", "mysql", "postgres"], "sqli"),
        (["xss", "script", "<script>", "dom manipulation"], "xss"),
        (["ssrf", "url fetch", "webhook", "callback", "metadata"], "ssrf"),
    ]

    for keywords, attack_type in keyword_map:
        for kw in keywords:
            if kw in lower:
                scenario = SCENARIO_DATABASE.get(attack_type)
                if scenario:
                    return scenario.to_dict()

    return None


# ---------------------------------------------------------------------------
# build_few_shot_chain: 构建完整的 few-shot 消息链
# ---------------------------------------------------------------------------
def build_few_shot_chain(*attack_types: str, max_count: int = 3) -> list[dict[str, str]]:
    """
    构建多个攻击场景的 few-shot 消息链。

    对应 Go 源码 FewShot(category, n):
        - 取最多 n 个示例
        - 按 user->assistant 交替顺序排列
        - 直接注入到 LLM prompt 中

    Args:
        attack_types: 攻击类型列表
        max_count: 最多包含的示例数量

    Returns:
        [{"role": "user/assistant", "content": "..."}, ...]
    """
    messages = []
    count = 0

    for attack_type in attack_types:
        if count >= max_count:
            break

        scenario = get_scenario_prompt(attack_type)
        if scenario is None:
            continue

        messages.append({"role": "user", "content": scenario["user"]})
        messages.append({"role": "assistant", "content": scenario["assistant"]})
        count += 1

    return messages


# ---------------------------------------------------------------------------
# get_available_attack_types: 获取所有支持的攻击类型列表
# ---------------------------------------------------------------------------
def get_available_attack_types() -> list[str]:
    """返回所有支持的攻击类型。"""
    return list(SCENARIO_DATABASE.keys())
