#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Continuous Scan + Regression Framework -- periodic scan with result comparison and regression detection.

Mirrors Acunetix continuous_scan API endpoint. Supports:
  - Target list management (add/remove/list targets)
  - Cron-like schedule configuration
  - Incremental scanning (only changed pages / new endpoints)
  - Vulnerability regression tracking (new/old/dismissed)
  - Scan history and trend analysis
  - Integration with existing playbooks

Usage:
    from scanners.continuous_scan import ContinuousScanManager, Target

    manager = ContinuousScanManager(storage_dir='./scan_history')

    # Add targets
    manager.add_target(Target(url="https://example.com", schedule="daily", name="prod"))
    manager.add_target(Target(url="https://staging.example.com", schedule="weekly", name="staging"))

    # Run scans (manual or automatic)
    results = manager.scan_all()

    # Check regressions
    regressions = manager.get_regressions("prod")
    for vuln in regressions['new']:
        print(f"New vulnerability: {vuln.title}")
"""

import json
import logging
import os
import shutil
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse

logger = logging.getLogger('continuous_scan')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class Target:
    """A scan target with configuration."""
    url: str
    name: str = ''
    schedule: str = 'weekly'           # 'hourly', 'daily', 'weekly', 'monthly', 'manual'
    scan_interval_hours: int = 168     # default: weekly (168 hours)
    enabled: bool = True
    scan_profile: str = 'basic'        # 'quick', 'basic', 'thorough', 'professional'
    tags: List[str] = field(default_factory=list)
    categories: List[str] = field(default_factory=lambda: ['owasp_top10'])
    max_pages: int = 100
    max_depth: int = 3

    def __post_init__(self):
        if not self.name:
            self.name = urlparse(self.url).hostname or 'unnamed_target'
        # Parse schedule to interval
        schedule_map = {'hourly': 1, 'daily': 24, 'weekly': 168, 'monthly': 720}
        if self.schedule in schedule_map:
            self.scan_interval_hours = schedule_map[self.schedule]


@dataclass
class ScanRecord:
    """Result of a single scan run."""
    target_name: str
    timestamp: str = ''
    duration_seconds: float = 0.0
    status: str = 'unknown'            # 'success', 'partial', 'failed'
    pages_scanned: int = 0
    total_findings: int = 0
    severity_breakdown: Dict[str, int] = field(default_factory=dict)
    url_findings_ids: List[int] = field(default_factory=list)   # IDs of findings for regression
    file_findings_ids: List[int] = field(default_factory=list)
    raw_results: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ScanRecord':
        return cls(**{k: v for k, v in data.items() if k in [f.name for f in cls.__dataclass_fields__.values()]})


@dataclass
class RegressionReport:
    """Regression analysis between two scan runs."""
    target_name: str
    baseline_timestamp: str = ''
    current_timestamp: str = ''
    new_findings: List[Dict[str, Any]] = field(default_factory=list)
    disappeared_findings: List[Dict[str, Any]] = field(default_factory=list)
    persistent_findings: int = 0
    severity_change_up: List[Dict[str, Any]] = field(default_factory=list)
    severity_change_down: List[Dict[str, Any]] = field(default_factory=list)
    total_new_severity: Dict[str, int] = field(default_factory=dict)
    regression_score: float = 0.0      # 0=perfect, higher=worse

    @property
    def is_regression(self) -> bool:
        return len(self.new_findings) > 0 or any(
            f.get('severity', '') in ('CRITICAL', 'HIGH') for f in self.severity_change_up)


# ====================================================================
# Continuous Scan Manager
# ====================================================================

class ContinuousScanManager:
    """Manage continuous scanning of target lists with regression detection."""

    def __init__(self, storage_dir: str = './scan_history'):
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)
        self._targets: Dict[str, Target] = {}
        self._last_scan_times: Dict[str, datetime] = {}
        self._load_targets()

    @property
    def targets(self) -> Dict[str, Target]:
        return dict(self._targets)

    # ------------------------------------------------------------------
    # Target Management
    # ------------------------------------------------------------------

    def add_target(self, target: Target):
        """Add a new scan target."""
        self._targets[target.name] = target
        self._save_targets()
        logger.info('Target added: %s (%s, schedule=%s)', target.name, target.url, target.schedule)

    def remove_target(self, name: str):
        """Remove a scan target and its history."""
        if name in self._targets:
            del self._targets[name]
            # Clean up scan history
            history_dir = os.path.join(self.storage_dir, name)
            if os.path.exists(history_dir):
                shutil.rmtree(history_dir)
            logger.info('Target removed: %s', name)

    def list_targets(self, enabled_only: bool = False) -> List[Target]:
        """List all targets, optionally filtering to enabled ones."""
        targets = list(self._targets.values())
        if enabled_only:
            targets = [t for t in targets if t.enabled]
        return targets

    def get_target(self, name: str) -> Optional[Target]:
        return self._targets.get(name)

    # ------------------------------------------------------------------
    # Scan Execution
    # ------------------------------------------------------------------

    async def scan_all(self) -> Dict[str, ScanRecord]:
        """Execute scans for all eligible targets (based on schedule)."""
        now = datetime.now()
        results: Dict[str, ScanRecord] = {}

        for name, target in self._targets.items():
            if not target.enabled:
                continue

            # Check if scan is due
            last_scan = self._last_scan_times.get(name)
            if last_scan and (now - last_scan).total_seconds() < target.scan_interval_hours * 3600:
                logger.debug('Target %s not due for scan yet (interval=%dh, last=%s)',
                            name, target.scan_interval_hours, last_scan.isoformat())
                continue

            # Execute scan
            record = await self._execute_single_scan(name, target)
            results[name] = record

            # Update last scan time
            self._last_scan_times[name] = now

        logger.info('Scanned %d targets, %d had results', len(self._targets), len(results))
        return results

    async def scan_target(self, name: str) -> Optional[ScanRecord]:
        """Manually trigger a scan for a specific target."""
        target = self._targets.get(name)
        if not target:
            logger.error('Target not found: %s', name)
            return None
        record = await self._execute_single_scan(name, target)
        self._last_scan_times[name] = datetime.now()
        return record

    async def _execute_single_scan(self, name: str, target: Target) -> ScanRecord:
        """Execute a single scan and persist results."""
        logger.info('Starting scan for target %s (%s)', name, target.url)
        start_time = time.time()

        try:
            # Import scanner dynamically to avoid hard dependency
            from scanners.crawler import DeepScanCrawler, CrawlConfig  # type: ignore
            config = CrawlConfig(
                target_url=target.url,
                max_depth=target.max_depth,
                max_pages=target.max_pages,
            )
            crawler = DeepScanCrawler(config=config)
            scan_result = await crawler.crawl()

            duration = round(time.time() - start_time, 2)

            # Build findings from crawl results for regression tracking
            url_findings: List[Dict[str, Any]] = []
            for result in scan_result.get('results', []):
                finding_id = hash(result.get('url', '') + result.get('title', '')) % 10**8
                url_findings.append({
                    'id': abs(finding_id),
                    'url': result.get('url', ''),
                    'title': result.get('title', ''),
                    'status_code': result.get('status_code', 0),
                    'content_type': result.get('content_type', ''),
                })

            severity_breakdown = self._count_severities(url_findings)

            record = ScanRecord(
                target_name=name,
                duration_seconds=duration,
                status=scan_result.get('status', 'success'),
                pages_scanned=len(scan_result.get('visited', [])),
                total_findings=len(url_findings),
                severity_breakdown=severity_breakdown,
                url_findings_ids=[f['id'] for f in url_findings],
            )

            # Persist scan record
            self._persist_scan_record(name, target.url, record, scan_result)
            logger.info('Scan complete for %s: %d pages, %d findings, %.1fs',
                       name, record.pages_scanned, record.total_findings, duration)

        except Exception as exc:
            duration = round(time.time() - start_time, 2)
            record = ScanRecord(
                target_name=name, duration_seconds=duration,
                status='failed', total_findings=0,
                severity_breakdown={'error': 1},
            )
            self._persist_scan_record(name, target.url, record, {'error': str(exc)})
            logger.error('Scan failed for %s: %s', name, exc)

        return record

    # ------------------------------------------------------------------
    # Regression Detection
    # ------------------------------------------------------------------

    def get_regressions(self, target_name: str, n_comparisons: int = 2) -> RegressionReport:
        """Compare the latest scan results for a target to detect regressions."""
        history = self._get_scan_history(target_name, n_comparisons)

        if len(history) < 2:
            return RegressionReport(
                target_name=target_name,
                regression_score=0.0,
            )

        # Use most recent as baseline
        baseline = history[-1]
        current = history[0]

        # Compare findings
        baseline_ids = set(baseline.url_findings_ids + baseline.file_findings_ids)
        current_ids = set(current.url_findings_ids + current.file_findings_ids)

        new_ids = current_ids - baseline_ids
        old_ids = baseline_ids - current_ids  # disappeared

        report = RegressionReport(
            target_name=target_name,
            baseline_timestamp=baseline.timestamp,
            current_timestamp=current.timestamp,
            new_findings=[],
            disappeared_findings=[],
            persistent_findings=len(baseline_ids & current_ids),
        )

        # Count severity changes
        if baseline.raw_results and current.raw_results:
            prev_breakdown = baseline.severity_breakdown or {}
            curr_breakdown = current.severity_breakdown or {}

            for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
                prev_count = prev_breakdown.get(sev, 0)
                curr_count = curr_breakdown.get(sev, 0)
                if curr_count > prev_count:
                    report.severity_change_up.append({
                        'severity': sev,
                        'previous': prev_count,
                        'current': curr_count,
                        'delta': curr_count - prev_count,
                    })
                elif curr_count < prev_count:
                    report.severity_change_down.append({
                        'severity': sev,
                        'previous': prev_count,
                        'current': curr_count,
                        'delta': curr_count - prev_count,
                    })

            # Calculate regression score (weighted)
            weights = {'CRITICAL': 10, 'HIGH': 5, 'MEDIUM': 2, 'LOW': 1}
            report.regression_score = sum(
                item.get('delta', 0) * weights.get(item['severity'], 1)
                for item in report.severity_change_up
            )
        else:
            # Fallback: use finding ID count as proxy
            report.new_findings_count = len(new_ids) if hasattr(current, 'url_findings_ids') else 0

        return report

    def get_trend(self, target_name: str, window: int = 10) -> Dict[str, Any]:
        """Get vulnerability trend over time for a target."""
        history = self._get_scan_history(target_name, window)
        if not history:
            return {'target': target_name, 'data_points': 0}

        trend_data: Dict[str, List] = {
            'timestamps': [],
            'total_findings': [],
            'severity_breakdown': defaultdict(list),
        }

        for record in history:
            trend_data['timestamps'].append(record.timestamp)
            trend_data['total_findings'].append(record.total_findings)
            for sev, count in (record.severity_breakdown or {}).items():
                trend_data['severity_breakdown'][sev].append(count)

        # Calculate trend direction
        findings = trend_data['total_findings']
        if len(findings) >= 2:
            trend_data['direction'] = 'increasing' if findings[-1] > findings[0] else (
                'decreasing' if findings[-1] < findings[0] else 'stable')
            trend_data['delta'] = findings[-1] - findings[0]

        return trend_data

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _persist_scan_record(self, name: str, url: str, record: ScanRecord, raw_results: Dict):
        """Persist a scan record to disk."""
        history_dir = os.path.join(self.storage_dir, name)
        os.makedirs(history_dir, exist_ok=True)
        timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
        filepath = os.path.join(history_dir, f'{timestamp_str}_{urlparse(url).hostname}.json')

        data = record.to_dict()
        data['_raw_results'] = raw_results  # store full results alongside metadata
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _get_scan_history(self, target_name: str, limit: int = 10) -> List[ScanRecord]:
        """Load scan history for a target (newest first)."""
        history_dir = os.path.join(self.storage_dir, target_name)
        if not os.path.exists(history_dir):
            return []

        records: List[ScanRecord] = []
        files = sorted(os.listdir(history_dir), reverse=True)[:limit]

        for filename in files:
            if not filename.endswith('.json'):
                continue
            filepath = os.path.join(history_dir, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                record_data = {k: v for k, v in data.items() if k != '_raw_results'}
                records.append(ScanRecord(**record_data))
            except (json.JSONDecodeError, KeyError) as exc:
                logger.warning('Failed to load scan record %s: %s', filepath, exc)

        return records

    def _count_severities(self, findings: List[Dict[str, Any]]) -> Dict[str, int]:
        """Count findings by severity (from crawl results)."""
        breakdown: Dict[str, int] = defaultdict(int)
        for f in findings:
            sev = str(f.get('severity', 'INFO')).upper()
            breakdown[sev] += 1
        return dict(breakdown)

    def _load_targets(self):
        """Load saved target list from disk."""
        targets_file = os.path.join(self.storage_dir, '_targets.json')
        if not os.path.exists(targets_file):
            return
        try:
            with open(targets_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for name, target_data in data.items():
                self._targets[name] = Target(**target_data)
        except Exception as exc:
            logger.warning('Failed to load targets: %s', exc)

    def _save_targets(self):
        """Persist target list to disk."""
        targets_file = os.path.join(self.storage_dir, '_targets.json')
        data = {name: asdict(t) for name, t in self._targets.items()}
        with open(targets_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)


# ====================================================================
# Convenience functions
# ====================================================================

def create_continuous_manager(storage_dir: str = './scan_history') -> ContinuousScanManager:
    return ContinuousScanManager(storage_dir)


def add_target(manager: ContinuousScanManager, url: str, name: str = '', schedule: str = 'weekly', **kwargs) -> Target:
    target = Target(url=url, name=name or urlparse(url).hostname, schedule=schedule, **kwargs)
    manager.add_target(target)
    return target
