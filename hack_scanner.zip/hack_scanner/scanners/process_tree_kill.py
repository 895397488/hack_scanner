#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Process Tree Force-Kill — 文件/目录路径相关程序的进程树强行终止（事件响应 / 授权渗透场景）。

背景（Windows 11 实测，Edge 版本目录案例）：
    ownership_take.kill_locking_processes() 只能靠"打开文件句柄"
    （proc.open_files()）定位锁定者；但像
    C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\152.0.4191.66
    这类"被写入保护"的目录，其 exe/DLL 是被正在运行的进程**以映像方式加载**的，
    根本不出现在句柄表里 → 锁定者列表为空、杀无可杀，文件依旧动不了。

    本模块补三通道识别 + 整棵进程树强杀：
        1. exe     — 进程映像路径（proc.exe()）位于目标下（如 msedge.exe 本体）
        2. module  — 加载模块/映射文件（memory_maps()，旧版 psutil 用 modules()）位于目标下
        3. handle  — 打开文件句柄（proc.open_files()）位于目标下（与 ownership_take 同口径）
    命中进程收整棵进程树（自身 → 递归子孙），分级强杀：
        taskkill /F /T  →  psutil kill  →  (sc stop 相关服务后重试)  →  最终逐一校验
    先停服务再杀进程，防止服务管理器把被杀进程自动拉起。

安全门控（宁可不杀，不可误杀）：
    - 绝不杀 PID 0/4（System/Idle）、当前进程及其祖先进程（本终端/父链）、
      关键系统进程黑名单（csrss/lsass/services/svchost 等）。
    - 所有结果按实际存活状态判定，不伪造成功。

已知限制（诚实报告）：
    - 受保护进程 PPL（Protected Process Light，如新版 Edge 浏览器主进程 msedge.exe）
      即使管理员也无法用 NtTerminateProcess 直接终止（内核校验 PROCESS_PROTECTED_TYPE，
      SeDebugPrivilege 也绕不过）。此类进程会如实报"无法终止"并给出替代路径：
      ① 任务栏/程序界面优雅退出；② 安全模式 / WinPE 离线启动；③ 关掉其后台常驻设置。
    - 子进程隔离枚举防原生崩溃（WUDFHost 等受保护进程会使 psutil 触发访问违例、
      连累宿主进程——ownership_take 同款手法）。本模块进一步按**通道分拆子进程**
      （exe/files/maps 各一个）：实测 open_files() 枚举 WUDFHost 时原生崩溃
      （0xC0000005，Python try/except 拦不住），通道分拆后崩溃只损失该通道，
      exe 通道仍能命中 msedge/msedgewebview2 本体。单通道超时/崩溃时 partial=True。
    - 需要管理员权限才能看到受保护进程的映像/模块、停止受保护服务。

Usage:
    from scanners.process_tree_kill import (
        find_related_processes, kill_process_tree, find_services_under,
    )
    # 谁在用它？（只读，不杀）
    r = find_related_processes(r"C:\\Program Files (x86)\\Microsoft\\Edge\\Application")
    # {"ok": true, "related": [{pid,name,via,exe}], "tree": [{pid,name,protected}]}

    # 强杀整棵进程树（破坏性，先看清 related/tree 再调用）
    k = kill_process_tree(r"C:\\...\\Edge\\Application\\152.0.4191.66")
    # {"ok": true, "killed": [...], "failed": [...], "services_stopped": [...]}

    # CLI
    python -m scanners.process_tree_kill "C:\\path"                  # 只识别（默认，不杀）
    python -m scanners.process_tree_kill "C:\\path" --kill           # 识别 + 强杀进程树
    python -m scanners.process_tree_kill "C:\\path" --kill --no-stop-services
"""

import argparse
import csv
import io
import json
import locale
import logging
import os
import subprocess
import sys
import time
from typing import Dict, List, Optional

logger = logging.getLogger('process_tree_kill')

# 关键系统进程黑名单：即使命中目标路径也绝不终止（杀了会蓝屏/系统瘫痪/误伤大量服务）
_PROTECTED_NAMES = {
    'system', 'idle',
    'smss.exe', 'csrss.exe', 'wininit.exe', 'lsass.exe', 'services.exe',
    'svchost.exe', 'winlogon.exe', 'dwm.exe', 'fontdrvhost.exe',
}


def _decode(b: bytes) -> str:
    """子进程输出按系统首选编码解码（中文 Windows 为 GBK），失败回退 utf-8/replace。"""
    if not b:
        return ''
    try:
        pref = locale.getpreferredencoding(False) or 'utf-8'
        return b.decode(pref)
    except (UnicodeDecodeError, LookupError):
        pass
    return b.decode('utf-8', errors='replace')


def _run(cmd: List[str], timeout: int = 120) -> Dict:
    """执行外部命令，返回 {rc, stdout, stderr, error}。"""
    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout, shell=False)
        return {
            'rc': proc.returncode,
            'stdout': _decode(proc.stdout),
            'stderr': _decode(proc.stderr),
            'error': '',
        }
    except subprocess.TimeoutExpired:
        return {'rc': -1, 'stdout': '', 'stderr': '', 'error': f'命令超时 ({timeout}s): {" ".join(cmd)}'}
    except FileNotFoundError:
        return {'rc': -2, 'stdout': '', 'stderr': '', 'error': f'找不到命令: {cmd[0]}'}
    except Exception as e:  # noqa: BLE001
        return {'rc': -3, 'stdout': '', 'stderr': '', 'error': f'执行异常: {e}'}


def _winpath(path: str) -> str:
    """路径规范化为正斜杠 → 反斜杠（takeown 等工具不识别正斜杠；PowerShell 两者皆可，统一最稳）。"""
    if os.name == 'nt' and path:
        return os.path.normpath(path)
    return path


def _norm(p: Optional[str]) -> str:
    """统一路径比对形式：绝对化、小写、反斜杠、去尾部斜杠。"""
    if not p:
        return ''
    p = os.path.normpath(os.path.abspath(p)).replace('/', '\\').lower()
    return p[:-1] if len(p) > 1 and p.endswith('\\') else p


def _hit(p: Optional[str], target_norm: str) -> bool:
    """路径是否命中目标（=目标，或位于目标目录之下）。"""
    if not p:
        return False
    p = _norm(p)
    return p == target_norm or p.startswith(target_norm + '\\')


# 子进程隔离枚举（防 WUDFHost 等受保护进程引发的原生崩溃，ownership_take 同款）：
# 按通道分拆（argv[1]=exe|files|maps），每通道独立子进程——实测 files 通道
# （open_files 枚举 WUDFHost）会 0xC0000005 原生崩溃且 try/except 拦不住，
# 分拆后该通道崩溃只损失自身，exe 通道仍能命中程序本体（msedge/webview2）。
# 命中即输出一行 JSON 并 flush —— 单通道中途崩溃时父进程仍收部分结果。
# 路径经 argv 传入，不拼进代码。
_PROBE_CODE = r"""
import json, os, sys
try:
    import psutil
except ImportError:
    sys.exit(0)

channel = sys.argv[1]

def norm(p):
    if not p:
        return ''
    p = os.path.normpath(os.path.abspath(p)).replace('/', '\\').lower()
    return p[:-1] if len(p) > 1 and p.endswith('\\') else p

target = norm(sys.argv[2])

def hit(p):
    if not p:
        return False
    p = norm(p)
    return p == target or p.startswith(target + '\\')

# 实测崩溃源：open_files() 枚举 WUDFHost 时触发原生访问违例（files 通道跳过）
WUDF = {'wudfhost.exe'}

for proc in psutil.process_iter():
    try:
        pid = proc.pid
        if pid in (0, 4):
            continue
        name = (proc.name() or '').lower()
        via = []
        exe = ''
        if channel == 'exe':
            try:
                exe = proc.exe() or ''
            except Exception:
                exe = ''
            if hit(exe):
                via.append('exe')
        elif channel == 'files':
            if name in WUDF:
                continue
            n = 0
            try:
                for f in proc.open_files():
                    if hit(f.path):
                        n += 1
            except Exception:
                pass
            if not n:
                continue
            via.append('handle x%d' % n)
        elif channel == 'maps':
            if name in WUDF:
                continue
            m = 0
            try:
                # psutil 7.x 移除了 modules()；memory_maps() 同源于 NtQueryVirtualMemory
                if hasattr(proc, 'memory_maps'):
                    for mm in proc.memory_maps():
                        if hit(getattr(mm, 'path', '')):
                            m += 1
                else:
                    for mod in proc.modules():
                        if hit(mod.path):
                            m += 1
            except Exception:
                pass
            if not m:
                continue
            via.append('module x%d' % m)
        else:
            continue
        if via:
            print(json.dumps({'pid': pid, 'name': proc.name(), 'via': via, 'exe': exe},
                             ensure_ascii=False), flush=True)
    except Exception:
        continue
"""

# 枚举通道（顺序 = via 列表里的出现顺序）
_PROBE_CHANNELS = ('exe', 'files', 'maps')


def _run_probe_channel(path: str, channel: str):
    """单通道子进程枚举，返回 (matches, crashed)。通道互不影响。"""
    try:
        r = subprocess.run(
            [sys.executable, '-c', _PROBE_CODE, channel, _winpath(path)],
            capture_output=True, text=True, timeout=180,
        )
    except subprocess.TimeoutExpired:
        return [], True
    except Exception:  # noqa: BLE001
        return [], True
    matches: List[Dict] = []
    for line in (r.stdout or '').splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            d = json.loads(line)
        except ValueError:
            continue
        if isinstance(d, dict) and 'pid' in d:
            matches.append(d)
    return matches, r.returncode != 0


def _self_and_ancestors() -> set:
    """当前进程 + 全部祖先进程（终端/父链）——杀了会断掉自己的会话。"""
    pids = {os.getpid()}
    try:
        import psutil
        for anc in psutil.Process(os.getpid()).parents():
            pids.add(anc.pid)
    except Exception:  # noqa: BLE001
        pass
    return pids


def _collect_tree(root_pids: List[int]) -> List[Dict]:
    """按 ppid 链 BFS 收集完整进程树（含 roots 自身），返回 [{pid, ppid, name}]。

    不依赖 Process.children()（psutil 7.x API 变动频繁，ppid 表最稳）。
    """
    try:
        import psutil
    except ImportError:
        return [{'pid': pid, 'ppid': 0, 'name': ''} for pid in root_pids]
    info: Dict[int, Dict] = {}
    children: Dict[int, List[int]] = {}
    for p in psutil.process_iter(['pid', 'ppid', 'name']):
        info[p.pid] = {'pid': p.pid, 'ppid': p.info['ppid'], 'name': p.info['name']}
        children.setdefault(p.info['ppid'], []).append(p.pid)
    tree: List[Dict] = []
    seen = set()
    stack = list(root_pids)
    while stack:
        pid = stack.pop()
        if pid in seen:
            continue
        seen.add(pid)
        d = info.get(pid)
        if d is None:
            continue
        tree.append(d)
        stack.extend(children.get(pid, []))
    return tree


def _mark_protected(tree: List[Dict]) -> None:
    """就地给树内每个进程打 protected 标记（黑名单 / 自身进程树 / PID 0/4）。"""
    self_pids = _self_and_ancestors()
    for d in tree:
        name = (d.get('name') or '').lower()
        if d['pid'] in (0, 4):
            d['protected'] = True
            d['reason'] = 'System/Idle 系统进程，拒绝终止'
        elif d['pid'] in self_pids:
            d['protected'] = True
            d['reason'] = '当前进程或其祖先（本终端/父进程链），拒绝终止'
        elif name in _PROTECTED_NAMES:
            d['protected'] = True
            d['reason'] = '关键系统进程（黑名单），拒绝终止'
        else:
            d['protected'] = False


def find_related_processes(path: str) -> Dict:
    """识别与目标文件/目录路径"相关"的进程（三通道），并给出完整进程树。

    通道：
        exe    — 进程映像位于目标下（程序本体，如 msedge.exe）
        module — 加载模块/映射文件位于目标下（memory_maps / modules）
        handle — 打开句柄位于目标下（与 ownership_take 同口径）

    枚举在**子进程**执行以隔离原生崩溃；每命中一个进程输出一行 JSON。

    Returns:
        {"ok": bool, "path": str,
         "related": [{pid, name, via: [..], exe}],
         "tree": [{pid, ppid, name, protected, reason?}],
         "partial": bool, "error": str, "note"?: str}
    """
    result = {
        'ok': False, 'path': path,
        'related': [], 'tree': [],
        'partial': False, 'error': '',
    }
    if os.name != 'nt':
        result['error'] = '仅支持 Windows'
        return result
    if not path or not os.path.exists(path):
        result['error'] = f'路径不存在: {path}'
        return result
    try:
        import psutil  # noqa: F401  预检：子进程需要同一解释器可用 psutil
    except ImportError:
        result['error'] = '需要 psutil 才能枚举相关进程（pip install psutil）'
        return result

    tpath = _winpath(path)
    by_pid: Dict[int, Dict] = {}
    partial = False
    for channel in _PROBE_CHANNELS:
        matches, ch_crashed = _run_probe_channel(tpath, channel)
        partial = partial or ch_crashed
        for m in matches:
            cur = by_pid.setdefault(
                m['pid'],
                {'pid': m['pid'], 'name': m.get('name', ''), 'via': [], 'exe': ''},
            )
            if m.get('name') and not cur['name']:
                cur['name'] = m['name']
            if m.get('exe') and not cur['exe']:
                cur['exe'] = m['exe']
            for v in m.get('via', []):
                if v not in cur['via']:
                    cur['via'].append(v)

    related = sorted(by_pid.values(), key=lambda x: x['pid'])
    result['related'] = related
    result['partial'] = partial
    if partial:
        result['note'] = '个别通道枚举被中断（某受保护进程使子进程崩溃），相关进程列表可能不完整'

    if related:
        tree = _collect_tree([d['pid'] for d in related])
        _mark_protected(tree)
        result['tree'] = tree
    result['ok'] = True
    return result


def find_services_under(path: str) -> Dict:
    """查"服务可执行文件位于目标路径下"的 Windows 服务（CIM Win32_Service）。

    Returns:
        {"ok": bool, "services": [{name, display, state, start_mode, path}], "error": str}
    """
    result = {'ok': False, 'services': [], 'error': ''}
    if os.name != 'nt':
        result['error'] = '仅支持 Windows'
        return result
    t = _winpath(path).replace("'", "''")  # PowerShell 单引号转义
    ps = (
        "$t='%s'; "
        "(Get-CimInstance Win32_Service | "
        "Where-Object { $_.PathName -and $_.PathName.ToLower().StartsWith($t.ToLower() + '\\') } | "
        "Select-Object Name, DisplayName, State, StartMode, PathName | "
        "ConvertTo-Csv -NoTypeInformation)" % t
    )
    out = _run(['powershell', '-NoProfile', '-NonInteractive', '-Command', ps], timeout=90)
    if out['error']:
        result['error'] = out['error']
        return result
    text = (out['stdout'] or '').strip()
    if not text:
        result['ok'] = True
        return result
    try:
        for row in csv.DictReader(io.StringIO(text)):
            result['services'].append({
                'name': (row.get('Name') or '').strip(),
                'display': (row.get('DisplayName') or '').strip(),
                'state': (row.get('State') or '').strip(),
                'start_mode': (row.get('StartMode') or '').strip(),
                'path': (row.get('PathName') or '').strip(),
            })
    except Exception as e:  # noqa: BLE001
        result['error'] = f'解析服务列表失败: {e}'
        return result
    result['ok'] = True
    return result


def _stop_service(name: str) -> Dict:
    """sc stop 停服务。rc=0 成功；1062/未启动 视为"已是停止态"（无害）。"""
    out = _run(['sc.exe', 'stop', name], timeout=60)
    detail = ' '.join((out['stdout'] + ' ' + out['stderr']).split())
    if out['rc'] == 0:
        return {'name': name, 'ok': True, 'detail': detail}
    low = detail.lower()
    if '1062' in detail or 'not been started' in low or '尚未启动' in detail:
        return {'name': name, 'ok': True, 'detail': detail + '（服务未运行，视为已停止）'}
    return {'name': name, 'ok': False, 'detail': detail, 'error': out['error']}


def _is_alive(pid: int) -> bool:
    """进程是否仍存活（无法判定时按"存活"保守处理，避免假成功）。"""
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:  # noqa: BLE001
        return True


def kill_process_tree(path: str, stop_services: bool = True) -> Dict:
    """强杀与目标路径相关的进程整棵进程树（事件响应 / 授权渗透，破坏性操作）。

    流程（分级升级，每级后按实际存活校验，不伪造成功）：
        0. 识别相关进程 + 收集进程树 + 安全过滤（黑名单/自身进程树/0/4 跳过）
        1. 先 sc stop 相关服务（防服务管理器把被杀进程拉起），再杀进程
        2. taskkill /F /T /PID（按根进程连子树一起杀）
        3. 仍存活 → psutil kill
        4. 仍存活且有关联服务 → 再停服务 + 单进程 taskkill 重试
        5. 终验：仍存活者记 failed 并给出诊断（PPL 受保护进程等）

    Returns:
        {"ok": bool, "path": str,
         "related": [...], "tree": [...],
         "services": [...], "services_stopped": [...], "services_failed": [...],
         "killed": [{pid, name, method}],
         "failed": [{pid, name, reason}],
         "skipped": [{pid, name, reason}],
         "note": str, "error"?: str}
    """
    result: Dict = {
        'ok': False, 'path': path,
        'related': [], 'tree': [],
        'services': [], 'services_stopped': [], 'services_failed': [],
        'killed': [], 'failed': [], 'skipped': [],
        'note': '',
    }
    if os.name != 'nt':
        result['error'] = '仅支持 Windows'
        return result
    if not path or not os.path.exists(path):
        result['error'] = f'路径不存在: {path}'
        return result

    rel = find_related_processes(path)
    if not rel.get('ok'):
        result['error'] = rel.get('error')
        return result
    related = rel.get('related', [])
    tree = rel.get('tree', [])
    result['related'] = related
    result['tree'] = tree
    if rel.get('partial'):
        result['note'] = rel.get('note', '')
    if not related:
        result['ok'] = True
        result['note'] = (result['note'] + ' ' if result['note'] else '') + \
                         '未发现与目标路径相关的进程（程序可能未运行，或运行于受保护进程内不可见）'
        return result

    kill_list = [d for d in tree if not d.get('protected')]
    result['skipped'] = [
        {'pid': d['pid'], 'name': d.get('name'), 'reason': d.get('reason', '受保护')}
        for d in tree if d.get('protected')
    ]
    if not kill_list:
        result['error'] = '目标相关进程全部属于受保护进程，拒绝终止'
        return result
    skip_pids = {d['pid'] for d in tree if d.get('protected')}
    roots = [r['pid'] for r in related if r['pid'] not in skip_pids]
    if not roots:
        # related 命中者全受保护，但树里还有可杀子孙（理论上少见，兜底）
        roots = [d['pid'] for d in kill_list]

    # ── 1) 相关服务：先停，防止服务管理器自动拉起被杀进程 ──
    if stop_services:
        sv = find_services_under(path)
        result['services'] = sv.get('services', [])
        if sv.get('error'):
            result['note'] = (result['note'] + ' ' if result['note'] else '') + \
                             f'服务查询失败: {sv["error"]}'
        for s in sv.get('services', []):
            if s.get('state', '').lower() in ('running', 'start_pending', 'pending'):
                r = _stop_service(s['name'])
                r['display'] = s.get('display', '')
                (result['services_stopped'] if r['ok'] else result['services_failed']).append(r)
            # 已 STOPPED 的服务不动（避免无谓的状态变更）
        if result['services_stopped']:
            time.sleep(1.0)

    # ── 2) taskkill /F /T（按根进程，子树随 /T 一起终止）──
    last_err: Dict[int, str] = {}
    for pid in roots:
        out = _run(['taskkill', '/F', '/T', '/PID', str(pid)], timeout=30)
        if out['rc'] != 0:
            last_err[pid] = ' '.join((out['stderr'] or out['error']).split())[:160]
    time.sleep(1.0)

    for d in kill_list:
        if not _is_alive(d['pid']):
            result['killed'].append({'pid': d['pid'], 'name': d.get('name'),
                                     'method': 'taskkill /F /T'})
    alive = [d for d in kill_list if _is_alive(d['pid'])]

    # ── 3) 仍存活 → psutil kill ──
    if alive:
        try:
            import psutil
            for d in alive:
                try:
                    p = psutil.Process(d['pid'])
                    p.kill()
                except Exception:  # noqa: BLE001
                    pass
        except ImportError:
            pass
        time.sleep(1.0)
        still = []
        for d in alive:
            if not _is_alive(d['pid']):
                result['killed'].append({'pid': d['pid'], 'name': d.get('name'),
                                         'method': 'psutil kill'})
            else:
                still.append(d)
        alive = still

    # ── 4) 仍存活且有关联服务 → 再停服务 + 单进程 taskkill 重试 ──
    if alive and result['services']:
        for s in result['services']:
            if not any(x.get('name') == s.get('name') for x in result['services_stopped']):
                r = _stop_service(s['name'])
                r['display'] = s.get('display', '')
                (result['services_stopped'] if r['ok'] else result['services_failed']).append(r)
        time.sleep(1.0)
        retry = []
        for d in alive:
            if not _is_alive(d['pid']):
                result['killed'].append({'pid': d['pid'], 'name': d.get('name'),
                                         'method': 'sc stop 后确认已退出'})
                continue
            out = _run(['taskkill', '/F', '/PID', str(d['pid'])], timeout=30)
            if out['rc'] != 0:
                last_err[d['pid']] = ' '.join((out['stderr'] or out['error']).split())[:160]
            time.sleep(0.5)
            if not _is_alive(d['pid']):
                result['killed'].append({'pid': d['pid'], 'name': d.get('name'),
                                         'method': 'taskkill（停服务后重试）'})
            else:
                retry.append(d)
        alive = retry

    # ── 5) 终验：仍存活 → failed + 诊断 ──
    for d in alive:
        err = last_err.get(d['pid'], '')
        reason = '无法终止'
        if 'denied' in err.lower() or '拒绝' in err or 'access' in err.lower():
            reason += f'（taskkill: {err}）— 疑似受保护进程 PPL，管理员权限也无法直接终止'
        else:
            reason += '（未知原因，可能为受保护进程 PPL）'
        result['failed'].append({'pid': d['pid'], 'name': d.get('name'), 'reason': reason})

    result['ok'] = bool(result['killed']) and not result['failed']
    if result['failed']:
        hint = ('有进程无法终止：通常是被系统标记为 PPL 受保护的进程（如 Edge 浏览器主进程），'
                '管理员也无法直接杀。替代路径：'
                '① 从任务栏/程序界面优雅退出；'
                '② 停止并禁用其相关服务后重启；'
                '③ 安全模式 / WinPE 离线启动后再终止、删除。')
        result['note'] = (result['note'] + ' ' if result['note'] else '') + hint
    return result


def main():
    parser = argparse.ArgumentParser(
        description='文件/目录路径相关程序的进程树强行终止（事件响应/授权渗透；默认只识别不杀）',
    )
    parser.add_argument('path', help='目标文件或目录路径')
    parser.add_argument('--kill', action='store_true',
                        help='实际执行强杀（默认只识别、不杀；破坏性操作，慎用）')
    parser.add_argument('--no-stop-services', dest='stop_services', action='store_false',
                        default=True, help='不自动停止目标路径下的 Windows 服务')
    args = parser.parse_args()

    if args.kill:
        result = kill_process_tree(args.path, stop_services=args.stop_services)
    else:
        result = find_related_processes(args.path)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result.get('ok') else 1)


if __name__ == '__main__':
    main()
