#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Pheromones — 蜂群行为配置加载器。

源自: Pentest-Swarm-AI (https://github.com/Armur-Ai/Pentest-Swarm-AI)
from-source-of: Pentest-Swarm-AI

从 Go 源码 config/pheromones.yaml 移植。

Pheromone（费洛蒙）是蜂群智能(stigmergy)的核心机制：
每种发现类型都有 base 权重和半衰期，下游 Agent 通过 Predicate.MinPheromone
过滤器自动淘汰衰减的发现。

核心概念:
  - higher base    => 下游 Agent 更积极地响应此类发现
  - shorter half_life   => 过时信息更快衰减（适用于 session、token 等易变状态）
  - longer half_life    => 保持持久发现的热度（如 open port、技术栈、CVE 匹配）
  - --exploration-bias 控制 base 倍率: low=0.7, med=1.0(high), high=1.3

Usage:
    from scanners.swarm_pheromones import PheromoneConfig, get_default_config

    config = get_default_config()
    pheromone = config.get("CVE_MATCH")
    print(pheromone.base, pheromone.half_life_sec)  # 1.0, 10800
"""

import time
from dataclasses import dataclass, field
from typing import Dict, Optional


# ============================================================
# Pheromone 配置结构
# ============================================================

@dataclass
class Pheromone:
    """单个发现类型的费洛蒙配置。

    Attributes:
        base: 初始费洛蒙权重（越高 => Agent 越优先处理）
        half_life_sec: 半衰期秒数（经过此时间后权重降为一半）
        bias_multiplier: 探索偏置倍率（1.0 = 默认, 可被 --exploration-bias CLI 标记覆盖）
    """
    base: float = 0.5
    half_life_sec: int = 3600
    bias_multiplier: float = 1.0

    def effective_base(self) -> float:
        """计算实际基础权重（base * bias_multiplier）。"""
        return round(self.base * self.bias_multiplier, 4)

    def decayed_pheromone(self, age_seconds: float = 0.0) -> float:
        """计算经过 age_seconds 后的衰减费洛蒙值。

        衰减公式: pheromone = effective_base * (0.5 ** (age / half_life))
        """
        eff = self.effective_base()
        if age_seconds <= 0:
            return eff
        return eff * (0.5 ** (age_seconds / self.half_life_sec))

    def is_stale(self, age_seconds: float) -> bool:
        """判断费洛蒙是否已过期（低于有效阈值的定义：衰减到 1%）。"""
        decay = self.decayed_pheromone(age_seconds)
        return decay < (self.effective_base() * 0.01)


# ============================================================
# PheromoneConfig — 蜂群配置管理器
# ============================================================

class PheromoneConfig:
    """蜂群费洛蒙配置加载器和运行时管理器。

    从 YAML 文件加载类型配置，提供查询、衰减计算、过期判断等功能。
    """

    def __init__(self, type_configs: Optional[Dict[str, dict]] = None):
        """初始化配置。

        Args:
            type_configs: {"TYPE_NAME": {"base": float, "half_life_sec": int}, ...}
                         传入 None 则使用内置默认配置
        """
        if type_configs is not None:
            self._types: Dict[str, Pheromone] = {}
            for name, cfg in type_configs.items():
                self._types[name] = Pheromone(
                    base=cfg.get("base", 0.5),
                    half_life_sec=cfg.get("half_life_sec", 3600),
                )
        else:
            self._types = {}
        self._default = None

    @property
    def default(self) -> Pheromone:
        """获取默认费洛蒙配置（未知类型的回退）。"""
        return self._default

    @default.setter
    def default(self, value: Pheromone):
        self._default = value

    def get(self, type_name: str) -> Pheromone:
        """获取指定类型的费洛蒙配置。如果类型不存在，回退到默认值。"""
        if type_name in self._types:
            return self._types[type_name]
        if self._default is not None:
            return self._default
        # 最终回退到内置默认
        return Pheromone(base=0.5, half_life_sec=3600)

    def set(self, type_name: str, base: float, half_life_sec: int):
        """设置指定类型的费洛蒙配置。"""
        self._types[type_name] = Pheromone(base=base, half_life_sec=half_life_sec)

    def apply_bias(self, multiplier: float):
        """对已加载的类型统一应用探索偏置倍率（--exploration-bias 效果）。

        Args:
            multiplier: 0.7 (低探索) / 1.0 (默认) / 1.3 (高探索)
        """
        for pheromone in self._types.values():
            pheromone.bias_multiplier = multiplier

    def type_names(self) -> list:
        """返回所有已配置的类型名称列表。"""
        return list(self._types.keys())

    def summary(self) -> Dict[str, dict]:
        """获取配置摘要。"""
        result = {}
        for name, pheromone in self._types.items():
            result[name] = {
                "base": pheromone.base,
                "effective_base": pheromone.effective_base(),
                "half_life_sec": pheromone.half_life_sec,
                "bias_multiplier": pheromone.bias_multiplier,
            }
        return result


# ============================================================
# 内置默认配置 (来自 config/pheromones.yaml)
# ============================================================

_DEFAULT_TYPE_CONFIGS = {
    # ========== 目标注册 ==========
    "TARGET_REGISTERED": {
        "base": 1.0,
        "half_life_sec": 86400,       # 24h — 根目标在整个渗透周期保持热度
    },
    "SUBDOMAIN": {
        "base": 0.7,
        "half_life_sec": 7200,         # 2h — 新发现子域名有趣但不紧急
    },

    # ========== 扫描发现 ==========
    "PORT_OPEN": {
        "base": 0.8,
        "half_life_sec": 3600,         # 1h
    },
    "SERVICE": {
        "base": 0.8,
        "half_life_sec": 3600,         # 1h
    },
    "HTTP_ENDPOINT": {
        "base": 0.6,
        "half_life_sec": 7200,         # 2h
    },
    "HTTP_ENDPOINT_INTERESTING": {
        "base": 0.9,                 # katana heuristics 标记的有趣端点
        "half_life_sec": 7200,
    },

    # ========== 技术指纹 ==========
    "TECHNOLOGY": {
        "base": 0.5,
        "half_life_sec": 7200,         # 持久但低优先级
    },

    # ========== Classifier 输出 — 按严重性感知 ==========
    "CVE_MATCH": {
        "base": 1.0,                 # 可被 ClassifierAgent 根据严重性覆盖
        "half_life_sec": 10800,        # 3h 默认
    },
    "MISCONFIGURATION": {
        "base": 0.6,
        "half_life_sec": 3600,
    },

    # ========== Exploit 输出 ==========
    "EXPLOIT_CHAIN": {
        "base": 0.9,
        "half_life_sec": 3600,
    },
    "EXPLOIT_RESULT": {
        "base": 0.7,                 # exploit agent 内成功时提升到 1.0
        "half_life_sec": 1800,         # 30m
    },

    # ========== 会话与会话相关 ==========
    "SESSION": {
        "base": 0.8,
        "half_life_sec": 900,          # 15m — session token 快速过期
    },

    # ========== Agent Error ==========
    "AGENT_ERROR": {
        "base": 0.3,                 # 短暂暴露后衰减
        "half_life_sec": 600,          # 10m
    },

    # ========== 行动完成 ==========
    "CAMPAIGN_COMPLETE": {
        "base": 1.0,
        "half_life_sec": 300,          # 5m
    },

    # ========== Nuclei 模板 ==========
    "NUCLEI_TEMPLATE_DRAFT": {
        "base": 0.8,
        "half_life_sec": 43200,        # 12h — 草稿在审阅工作日内保持兴趣度
    },
}

_DEFAULT_PHEROMONE_CONFIG = Pheromone(base=0.5, half_life_sec=3600)


def get_default_config() -> PheromoneConfig:
    """获取默认蜂群费洛蒙配置（对应 pheromones.yaml）。"""
    config = PheromoneConfig(_DEFAULT_TYPE_CONFIGS.copy())
    config.default = _DEFAULT_PHEROMONE_CONFIG
    return config


def load_pheromones_from_yaml(yaml_text: str) -> PheromoneConfig:
    """从 YAML 文本加载费洛蒙配置。

    如果 pyyaml 可用则使用，否则 fallback 到内置默认配置。

    Args:
        yaml_text: YAML 格式的费洛蒙配置字符串

    Returns:
        PheromoneConfig 实例
    """
    try:
        import yaml as _yaml
        data = _yaml.safe_load(yaml_text)
        if data is None:
            return get_default_config()
        types = data.get("types", {})
        default_cfg = data.get("default", {"base": 0.5, "half_life_sec": 3600})
        config = PheromoneConfig(types.copy())
        config.default = Pheromone(
            base=default_cfg.get("base", 0.5),
            half_life_sec=default_cfg.get("half_life_sec", 3600),
        )
        return config
    except ImportError:
        # pyyaml 未安装时 fallback 到内置配置
        print("[warning] pyyaml not available, using built-in default pheromone config")
        return get_default_config()


# ============================================================
# Phreomone Decay Calculator — 衰减计算器（独立工具类）
# ============================================================

class PheromoneDecay:
    """费洛蒙衰变计算器。

    用于在运行时评估发现的当前费洛蒙值，并决定是否过滤已过期的发现。
    对应 Go 中 downstream agents' Predicate.MinPheromone 过滤逻辑。
    """

    # 最小费洛蒙阈值 — 低于此值的发现被过滤掉
    MIN_PHEROMONE = 0.01

    @classmethod
    def compute_current(cls, pheromone: Pheromone, created_at_timestamp: float) -> float:
        """计算发现的当前费洛蒙值（考虑时间衰减）。"""
        age = time.time() - created_at_timestamp
        if age < 0:
            return pheromone.effective_base()
        decayed = pheromone.decayed_pheromone(age)
        return max(decayed, cls.MIN_PHEROMONE)

    @classmethod
    def is_below_threshold(cls, current: float) -> bool:
        """判断当前费洛蒙值是否低于最小阈值。"""
        return current < cls.MIN_PHEROMONE


# ============================================================
# 快速验证
# ============================================================

if __name__ == "__main__":
    config = get_default_config()

    print("=== 默认 Pheromone 配置 ===\n")
    summary = config.summary()
    for name, cfg in sorted(summary.items()):
        half_min = cfg["half_life_sec"] / 60
        if half_min >= 60:
            half_str = f"{half_min/60:.0f}h"
        else:
            half_str = f"{half_min:.0f}min"
        print(f"  {name:35s}  base={cfg['base']:5.1f}  effective={cfg['effective_base']:5.2f}  half-life={half_str}")

    # 测试费洛蒙衰减
    print("\n=== 费洛蒙衰减测试 ===")
    session_phero = config.get("SESSION")          # base=0.8, half_life=900s
    cve_phero = config.get("CVE_MATCH")            # base=1.0, half_life=10800s

    now = time.time()
    for age_name, age_sec in [("刚创建", 0), ("15分钟后", 900), ("1小时后", 3600), ("6小时后", 21600)]:
        session_val = PheromoneDecay.compute_current(session_phero, now - age_sec)
        cve_val = PheromoneDecay.compute_current(cve_phero, now - age_sec)
        session_stale = PheromoneDecay.is_below_threshold(session_val)
        cve_stale = PheromoneDecay.is_below_threshold(cve_val)
        print(f"  {age_name:15s}  SESSION={session_val:.3f} {'(stale)' if session_stale else ''}")
        print(f"                    CVE_MATCH={cve_val:.3f} {'(stale)' if cve_stale else ''}")

    # 测试探索偏置
    print("\n=== 探索偏置测试 ===")
    test_config = get_default_config()
    for bias_name, mult in [("low", 0.7), ("med", 1.0), ("high", 1.3)]:
        test_bias = get_default_config()
        test_bias.apply_bias(mult)
        cve_eff = test_bias.get("CVE_MATCH").effective_base()
        sub_eff = test_bias.get("SUBDOMAIN").effective_base()
        print(f"  bias={bias_name:4s} (×{mult}): CVE_MATCH base→{cve_eff:.2f}, SUBDOMAIN base→{sub_eff:.2f}")
