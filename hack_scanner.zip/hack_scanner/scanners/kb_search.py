#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
知识库检索 — 漏洞模式卡 + 战报案例库的 BM25 检索
=====================================================================

背景（整合 vulnclaw 优势 ⑤，参照 vulnclaw/kb/ranking.py + store.py + retriever.py）:
    LLM 手里没有"漏洞模式 → 症状 → 绕过 → payload 提示 → 参考"的先验，
    每撞一次 WAF / 新技术栈都从零试错、反复烧迭代。vulnclaw 用可检索的
    知识库补这块：漏洞模式卡 + 战报案例库（完整攻击链 + 弯路 + 方法论）。

    本模块是 vulnclaw/kb 核心的纯标准库轻量重写：
    - bigram_tokenize + BM25（vulnclaw 原算法，中英兼容、无需分词库）
    - 数据文件: data/kb/vuln_kb.json（漏洞模式卡）+ data/kb/warstories/*.md（战报）
    - LLM 工具 consult_kb(query, kind="vuln|story")：经 orch.register_tool
      公开方法注册（orchestrator 零改动）
    - 报告钩子: cards_for_vuln_type(vuln_type) → references[]（⑥ 引用来源）

    CrossEncoderReranker 不移植（依赖 bge 模型，超出依赖边界）。
    数据缺失/损坏时静默降级为空库（核心循环不受影响）。
"""

import json
import math
import os
import re
import sys
from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from scanners.swarm_orchestrator import ToolDefinition
from scanners.swarm_tool_binders import _json_safe_dumps

KB_MAX_OUTPUT_CHARS = 4096

# ---------------------------------------------------------------------------
# 检索原语（vulnclaw kb/ranking.py 原算法移植：bigram 分词 + Okapi BM25）
# ---------------------------------------------------------------------------
_RUN_RE = re.compile(r"[a-z0-9]+|[一-鿿]+")


def bigram_tokenize(text: str) -> List[str]:
    """拉丁字母/数字串整体成 token（小写），CJK 串切重叠字符 bigram。

    "SQL" -> ["sql"]；"注入绕过" -> ["注入", "入绕", "绕过"]。
    其余字符作为分隔符——无需分词字典即可中英混检。
    """
    tokens: List[str] = []
    for match in _RUN_RE.finditer(str(text or "").lower()):
        run = match.group()
        if run.isascii() or len(run) == 1:
            tokens.append(run)
        else:
            tokens.extend(run[i:i + 2] for i in range(len(run) - 1))
    return tokens


class BM25:
    """无依赖 Okapi BM25（vulnclaw 原实现，k1=1.5 / b=0.75 默认）。"""

    def __init__(self, docs: List[str], k1: float = 1.5, b: float = 0.75):
        self.k1 = float(k1)
        self.b = float(b)
        tokenized = [bigram_tokenize(d) for d in docs]
        self._doc_counts = [Counter(t) for t in tokenized]
        self._doc_len = [len(t) for t in tokenized]
        count = len(tokenized)
        self._avg_len = (sum(self._doc_len) / count) if count else 0.0
        document_frequency: Counter = Counter()
        for doc_counts in self._doc_counts:
            document_frequency.update(doc_counts.keys())
        self._idf = {
            token: math.log((count - freq + 0.5) / (freq + 0.5) + 1.0)
            for token, freq in document_frequency.items()
        }
        self._norm = [
            (1.0 - self.b + self.b * (length / self._avg_len)) if self._avg_len > 0 else 1.0
            for length in self._doc_len
        ]

    def search(self, query: str, top_k: int) -> List[Tuple[int, float]]:
        """返回按 BM25 降序的 (doc_index, score)；只含正分，最多 top_k 条。"""
        if not query or not self._doc_counts:
            return []
        query_counts = Counter(bigram_tokenize(query))
        if not query_counts:
            return []
        scored: List[Tuple[int, float]] = []
        for index, doc_counts in enumerate(self._doc_counts):
            score = 0.0
            norm = self._norm[index]
            for token, query_tf in query_counts.items():
                doc_tf = doc_counts.get(token, 0)
                if doc_tf <= 0:
                    continue
                idf = self._idf.get(token, 0.0)
                if idf <= 0.0:
                    continue
                tf = doc_tf * (self.k1 + 1.0) / (doc_tf + self.k1 * norm)
                score += idf * tf * float(query_tf)
            if score > 0.0:
                scored.append((index, score))
        scored.sort(key=lambda pair: pair[1], reverse=True)
        return scored[: max(0, int(top_k))]


# ---------------------------------------------------------------------------
# 知识库（数据文件驱动）
# ---------------------------------------------------------------------------
def _default_kb_dir() -> str:
    return os.path.join(_PROJECT_ROOT, "data", "kb")


def _card_text(card: dict) -> str:
    """把模式卡拍平为检索文本（字段值拼接，中英混合）。"""
    parts = [
        card.get("id", ""), card.get("title", ""), card.get("vuln_type", ""),
    ]
    for key in ("tech", "symptoms", "bypasses", "payload_hints"):
        val = card.get(key) or []
        if isinstance(val, list):
            parts.extend(str(v) for v in val)
        else:
            parts.append(str(val))
    return " ".join(p for p in parts if p)


def _story_text(name: str, body: str) -> str:
    return f"{name} {body}"


class KnowledgeBase:
    """漏洞模式卡 + 战报库的内存检索索引（启动时加载，纯只读）。

    - vuln_kb.json: [{id, title, vuln_type, tech[], symptoms[],
      bypasses[], references[], payload_hints[]}]
    - warstories/*.md: 每篇战报一个文档（README 索引除外）
    """

    def __init__(self, kb_dir: Optional[str] = None):
        self.kb_dir = kb_dir or _default_kb_dir()
        self.cards: List[dict] = []
        self.stories: List[dict] = []   # [{id, title, path, text}]
        self._card_index: Optional[BM25] = None
        self._story_index: Optional[BM25] = None
        self.load()

    def load(self) -> None:
        """加载数据文件；缺失/损坏静默降级为空库。"""
        self.cards = []
        self.stories = []
        self._card_index = None
        self._story_index = None

        kb_path = os.path.join(self.kb_dir, "vuln_kb.json")
        try:
            with open(kb_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            cards = data if isinstance(data, list) else data.get("cards") or []
            self.cards = [c for c in cards if isinstance(c, dict) and c.get("id")]
        except (OSError, json.JSONDecodeError, ValueError, AttributeError):
            self.cards = []

        story_dir = os.path.join(self.kb_dir, "warstories")
        try:
            for name in sorted(os.listdir(story_dir)):
                if not name.endswith(".md") or name.upper().startswith("README"):
                    continue
                path = os.path.join(story_dir, name)
                try:
                    with open(path, "r", encoding="utf-8", errors="replace") as f:
                        body = f.read()
                except OSError:
                    continue
                title = name[:-3]
                self.stories.append({"id": title, "title": title,
                                     "path": path, "text": body})
        except OSError:
            self.stories = []

        if self.cards:
            self._card_index = BM25([_card_text(c) for c in self.cards])
        if self.stories:
            self._story_index = BM25(
                [_story_text(s["id"], s["text"][:2000]) for s in self.stories])

    # -- 检索 ----------------------------------------------------------------
    def search_cards(self, query: str, top_k: int = 5) -> List[dict]:
        if not self._card_index or not query:
            return []
        out = []
        for idx, score in self._card_index.search(query, top_k):
            card = dict(self.cards[idx])
            card["_score"] = round(score, 3)
            out.append(card)
        return out

    def search_stories(self, query: str, top_k: int = 3) -> List[dict]:
        if not self._story_index or not query:
            return []
        out = []
        for idx, score in self._story_index.search(query, top_k):
            story = {k: v for k, v in self.stories[idx].items() if k != "text"}
            story["_score"] = round(score, 3)
            out.append(story)
        return out

    def search(self, query: str, kind: Optional[str] = None, top_k: int = 5) -> List[dict]:
        """kind: 'vuln'（默认，模式卡）/ 'story'（战报）/ None（两者合并）。"""
        if kind == "vuln":
            return self.search_cards(query, top_k)
        if kind == "story":
            return self.search_stories(query, top_k)
        merged = [{**c, "_kind": "vuln"} for c in self.search_cards(query, top_k)]
        merged += [{**s, "_kind": "story"} for s in self.search_stories(query, top_k)]
        merged.sort(key=lambda x: x.get("_score", 0), reverse=True)
        return merged[:top_k]

    def cards_for_vuln_type(self, vuln_type: str) -> List[dict]:
        """报告钩子：按 vuln_type 精确命中模式卡（取 references 供报告引用）。"""
        vt = (vuln_type or "").strip().lower()
        if not vt:
            return []
        return [c for c in self.cards if (c.get("vuln_type") or "").lower() == vt][:5]

    def summary(self) -> dict:
        return {"cards": len(self.cards), "stories": len(self.stories),
                "kb_dir": self.kb_dir}


# ---------------------------------------------------------------------------
# LLM 工具（经 orch.register_tool 注册，orchestrator 零改动）
# ---------------------------------------------------------------------------
def make_consult_kb_tool(kb: Optional[KnowledgeBase] = None) -> ToolDefinition:
    """构造 consult_kb 工具。

    参数: {"query": "sqli waf bypass", "kind": "vuln|story"}
    输出: JSON（模式卡/战报命中列表），走 _json_safe_dumps 保证合法 JSON。
    """
    kb = kb or KnowledgeBase()

    def execute(args_string: str) -> Tuple[str, Optional[str]]:
        try:
            obj = json.loads(args_string) if isinstance(args_string, str) else dict(args_string or {})
            if not isinstance(obj, dict):
                obj = {}
        except (json.JSONDecodeError, TypeError):
            obj = {}
        query = str(obj.get("query") or "").strip()
        if not query:
            return _json_safe_dumps(
                {"error": "query is required", "hint": "e.g. consult_kb(query=\"sqli waf bypass\")"},
                KB_MAX_OUTPUT_CHARS), None
        kind = str(obj.get("kind") or "vuln").strip().lower()
        if kind not in ("vuln", "story"):
            kind = "vuln"
        top_k = int(obj.get("top_k") or 5) if str(obj.get("top_k") or "").isdigit() else 5
        hits = kb.search(query, kind=kind, top_k=max(1, min(top_k, 10)))
        if not hits:
            return _json_safe_dumps(
                {"results": [], "note": f"no {kind} knowledge matched; try broader terms "
                                        "(vuln_type / tech / symptom)"},
                KB_MAX_OUTPUT_CHARS), None
        payload = {"results": hits, "kb_summary": kb.summary()}
        return _json_safe_dumps(payload, KB_MAX_OUTPUT_CHARS), None

    return ToolDefinition(
        name="consult_kb",
        description=(
            "Consult the built-in security knowledge base (vulnerability pattern cards: "
            "symptoms / WAF bypass techniques / payload hints / references, or full war-story "
            "attack chains). Call BEFORE retrying a blocked/failed attack path, or when facing "
            "an unfamiliar tech stack. "
            "Parameters: query (keywords, e.g. 'sqli waf bypass' or 'idor jwt'), "
            "kind ('vuln' for pattern cards, 'story' for full war stories)."),
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string",
                          "description": "Search keywords (vuln type, tech, symptom, bypass need)"},
                "kind": {"type": "string", "enum": ["vuln", "story"],
                         "description": "vuln = pattern cards (default); story = full war stories"},
                "top_k": {"type": "integer", "description": "Max results (default 5, max 10)"},
            },
            "required": ["query"],
        },
        execute=execute,
    )


if __name__ == "__main__":
    # 自测：分词/BM25 排序/空库降级/工具输出合法 JSON
    assert bigram_tokenize("SQL 注入绕过") == ["sql", "注入", "入绕", "绕过"]
    docs = ["sql injection union select bypass waf", "xss reflected script tag", "ssrf internal network"]
    idx = BM25(docs)
    r = idx.search("waf bypass sqli", 2)
    assert r and r[0][0] == 0, "SQLi 卡应排第一"
    # 空库降级
    kb_empty = KnowledgeBase(kb_dir=os.path.join(_PROJECT_ROOT, "data", "kb", "__nonexistent__"))
    assert kb_empty.search("sqli") == []
    # 工具构造（无数据也能构造，输出合法 JSON）
    tool = make_consult_kb_tool(kb_empty)
    res, err = tool.execute(json.dumps({"query": "sqli"}))
    assert err is None and json.loads(res).get("results") == []
    print("self-test OK")
