#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TruffleHog Wrapper — trufflehog CLI wrapper，密钥/凭证泄露检测引擎。

作为 git_secret_scanner.py(gitleaks) 的双引擎备选：
  - gitleaks   → 正则 pattern 匹配，轻量
  - trufflehog→ 高置信度验证（会实际调用 API 验证凭证有效性）

集成方式：需要安装 trufflehog
  - Windows: choco install trufflehog  或  https://github.com/trufflesecurity/trufflehog/releases
  - Linux:   见 release 页面
本模块只负责 CLI 调用和结果解析。config.json → tools.trufflehog_path 可指定路径。

Usage:
    from scanners.trufflehog_wrapper import trufflehog_scan
    result = trufflehog_scan("./repo", scan_type="git")
"""

import json
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger('trufflehog_scanner')


def _find_trufflehog() -> Optional[str]:
    """查找 trufflehog 可执行文件：先 config.json → tools.trufflehog_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("trufflehog_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["trufflehog", "trufflehog.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def trufflehog_scan(target: str, scan_type: str = "filesystem", max_time: int = 600) -> dict:
    """运行 trufflehog 密钥泄露检测。

    Args:
        target: git 仓库路径或文件/目录路径
        scan_type: filesystem | git | directory
        max_time: 最大运行时间秒

    Returns:
        {"ok": bool, "findings": [...], "findings_count": N, "error": ...}
    """
    if not target or not os.path.exists(target):
        return {"ok": False, "findings": [], "findings_count": 0, "error": f"路径不存在: {target}"}

    th = _find_trufflehog()
    if not th:
        return {"ok": False, "findings": [], "findings_count": 0,
                "error": "trufflehog 未找到，请安装: choco install trufflehog (Windows) 或见 github.com/trufflesecurity/trufflehog"}

    # scan_type → trufflehog 子命令
    type_map = {
        "filesystem": "filesystem",
        "git": "git",
        "directory": "directory",
        "fs": "filesystem",
    }
    sub = type_map.get(scan_type.lower(), "filesystem")

    cmd = [th, sub, target, "--json", "--no-update", "--only-verified"]
    logger.info(f"trufflehog {sub}: {target}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = proc.stdout or ""
        # trufflehog --json 输出为 JSON 数组（可能逐行）
        findings = []
        # 尝试整体解析
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                items = data
            else:
                items = [data]
        except json.JSONDecodeError:
            # 逐行 JSONL
            items = []
            for line in raw.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    items.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        for it in items:
            if not isinstance(it, dict):
                continue
            detector = it.get("detector_name", "")
            # 跳过无 detector 的噪声行
            if not detector:
                continue
            findings.append({
                "detector": detector,
                "source_id": it.get("source_id", ""),
                "raw_secret": (it.get("raw", "") or "")[:80] + ("..." if len(it.get("raw", "") or "") > 80 else ""),
                "verified": it.get("verified", False),
                "file": it.get("source_metadata", {}).get("data", {}).get("file", "") if isinstance(it.get("source_metadata"), dict) else "",
            })

        return {
            "ok": True,
            "target": target,
            "findings": findings[:500],
            "findings_count": len(findings),
            "error": "",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "findings": [], "findings_count": 0, "error": "trufflehog 超时"}
