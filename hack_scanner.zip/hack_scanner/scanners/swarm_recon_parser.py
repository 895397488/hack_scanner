# from-source-of: Pentest-Swarm-AI (internal/agent/recon/)
# 侦察解析模块 — 从安全工具输出中解析发现结果
"""
从 nmap、Gobuster、httprobe 等扫描工具的输出中解析发现结果的模块。
核心算法源自 Pentest-Swarm-AI 的 recon/parser.go 和 recon/agent.go。
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ---------------------------------------------------------------------------
# 数据类型定义
# ---------------------------------------------------------------------------

class FindingCategory(str, Enum):
    """发现结果的分类类型"""
    OPEN_PORT = "open_port"
    DIRECTORY = "directory"
    SUBDOMAIN = "subdomain"
    SERVICE = "service"
    HTTP_ENDPOINT = "http_endpoint"
    TECHNOLOGY = "technology"
    HOST = "host"
    DNS_RECORD = "dns_record"
    UNKNOWN = "unknown"


@dataclass
class Finding:
    """一条扫描发现的记录"""
    category: FindingCategory
    target: str          # 被扫描的目标地址
    detail: str          # 详情（端口号、路径、域名等）
    tool: str            # 来源工具名 (nmap, gobuster, httprobe, ...)
    severity: str = "info"  # 严重性级别
    raw_output: str = "" # 原始输出行
    metadata: dict = field(default_factory=dict)  # 附加元数据

    @property
    def summary(self) -> str:
        return f"[{self.tool}] {self.category.value}: {self.target} -> {self.detail}"


@dataclass
class AttackSurface:
    """攻击面模型 — 对应 pipeline.AttackSurface"""
    target: str = ""
    campaign_id: str = ""
    subdomains: list = field(default_factory=list)      # SubdomainRecord
    hosts: list = field(default_factory=list)           # HostRecord
    endpoints: list = field(default_factory=list)       # EndpointRecord
    technologies: dict = field(default_factory=dict)    # tech -> version
    created_at: str = ""


@dataclass
class SubdomainRecord:
    domain: str = ""
    ip: str = ""
    source: str = "unknown"


@dataclass
class HostRecord:
    ip: str = ""
    hostnames: list = field(default_factory=list)
    open_ports: list = field(default_factory=list)
    services: dict = field(default_factory=dict)
    os: str = ""


@dataclass
class EndpointRecord:
    url: str = ""
    method: str = "GET"
    status_code: int = 0
    interesting: bool = False


# ---------------------------------------------------------------------------
# nmap 输出解析
# ---------------------------------------------------------------------------

# nmap 标准端口扫描输出格式：
#   Host is up (0.0023s latency).
#   Not shown: 994 closed ports
#   PORT     STATE SERVICE     VERSION
#   22/tcp   open  ssh         OpenSSH 8.2p1
#   80/tcp   open  http        Apache httpd 2.4.41
_NMAP_HOST_RE = re.compile(r'^Host:\s+(\S+)\s+[\((]ports?:\s*(\d+.*?)\)')
_NMAP_PORT_RE = re.compile(
    r'^(?P<port>\d+)/(?P<proto>\w+)\s+'
    r'(?P<state>\w+)\s+'
    r'(?P<service>\S+)\s*'
    r'(?P<version>.*)$'
)


def parse_nmap_output(text: str) -> list[Finding]:
    """
    解析 nmap 端口扫描结果输出。

    支持以下格式：
      - 标准文本输出（Host up / PORT STATE SERVICE VERSION）
      - XML 输出的简化提取（grep-able 片段）
      - 每行一条的机器可读格式（--open）

    Args:
        text: nmap 命令的 stdout/stderr 文本内容

    Returns:
        Finding 列表，按扫描过程中遇到的顺序排列
    """
    findings: list[Finding] = []
    current_host = ""
    current_ports_open: list[dict] = []

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue

        # 检测新主机开始
        host_match = _NMAP_HOST_RE.search(line)
        if host_match:
            # 如果之前有主机在积累端口，先提交之前的发现
            if current_host and current_ports_open:
                findings.extend(
                    _build_nmap_findings(current_host, current_ports_open)
                )
            current_host = host_match.group(1)
            current_ports_open = []
            continue

        # 解析端口行（必须在 Host 之后）
        port_match = _NMAP_PORT_RE.match(line)
        if port_match and current_host:
            port_entry = {
                "port": int(port_match.group("port")),
                "proto": port_match.group("proto"),
                "state": port_match.group("state").lower(),
                "service": port_match.group("service"),
                "version": port_match.group("version").strip(),
            }
            current_ports_open.append(port_entry)
            continue

    # 处理最后一台主机
    if current_host and current_ports_open:
        findings.extend(_build_nmap_findings(current_host, current_ports_open))

    # 如果没有检测到 Host 行，尝试作为每行一条的端口输出解析
    if not findings:
        for line in text.splitlines():
            line = line.strip()
            port_match = _NMAP_PORT_RE.match(line)
            if port_match:
                current_host = "<unknown>"
                findings.extend(
                    _build_nmap_findings(current_host, [dict(port_match.groups())])
                )

    return findings


def _build_nmap_findings(host: str, ports: list[dict]) -> list[Finding]:
    """从积累的主机和端口数据构建 Finding 列表"""
    findings = []

    # 主机发现
    findings.append(Finding(
        category=FindingCategory.HOST,
        target=host,
        detail=f"up (detected via nmap)",
        tool="nmap",
        severity="info",
        metadata={"ip": host},
    ))

    for p in ports:
        state = p.get("state", "")
        # 根据端口状态设置严重性
        if state == "open":
            sev = "high" if int(p.get("port", 0)) in (22, 443, 80, 8080, 3306, 5432) else "medium"
        elif state == "filtered":
            sev = "low"
        else:
            sev = "info"

        findings.append(Finding(
            category=FindingCategory.OPEN_PORT,
            target=host,
            detail=f"{p.get('port','')}/{p.get('proto','')}  [{state}] {p.get('service','')}",
            tool="nmap",
            severity=sev,
            raw_output=f"{p.get('port','')}/{p.get('proto','')} {state} {p.get('service','')}",
            metadata={
                "ip": host,
                "port": p.get("port"),
                "proto": p.get("proto"),
                "state": state,
                "service": p.get("service"),
                "version": p.get("version", ""),
            },
        ))

    return findings


# ---------------------------------------------------------------------------
# Gobuster 输出解析
# ---------------------------------------------------------------------------

# Gobuster 标准文本输出（-s 显示状态码）:
#   /admin             (Status: 200) [Size: 1234]
#   /wp-login.php      (Status: 302) [Size: 0]
# 兼容 Gobuster 标准输出格式:
#   /admin             (Status: 200) [Size: 1234]
#   /wp-login.php      (Status: 302)
# 注意：[Size...] 可能在 ) 之前（作为子匹配）或在 ) 之后独立出现
_GOBUSTER_RE = re.compile(
    r'^(/\S+).*?\(Status:\s*(?P<status>\d+)'
    r'(?:\s*\[Size:\s*(?P<size>\d+)\])?'
    r'\)\s*'
    r'(?:\[Size:\s*(?P<size2>\d+)\]\s*)?'  # 兼容 ) 之后的 [Size]
    r'$'
)


def parse_gobuster_output(text: str, base_url: str = "") -> list[Finding]:
    """
    解析 Gobuster 目录/文件爆破结果。

    Args:
        text:   gobuster dir/fs 命令的 stdout 文本
        base_url: 基础 URL（如果输出是相对路径时需要）

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        match = _GOBUSTER_RE.search(line)
        if match:
            path = match.group(1)
            status = int(match.group("status"))
            size = int(match.group("size") or "0")

            # 根据 HTTP 状态码判断严重性
            severity = "info"
            category = FindingCategory.DIRECTORY

            if status in (200,):
                severity = "medium"
                category = FindingCategory.DIRECTORY
            elif status in (301, 302):
                severity = "low"
            elif status in (403,):
                severity = "info"  # 权限拒绝，可能有敏感目录
            elif status in (500,):
                severity = "medium"

            url = f"{base_url}{path}" if base_url else path

            findings.append(Finding(
                category=category,
                target=url,
                detail=f"HTTP {status} [Size: {size}] 路径: {path}",
                tool="gobuster",
                severity=severity,
                raw_output=line,
                metadata={
                    "path": path,
                    "status_code": status,
                    "size": size,
                    "full_url": url,
                },
            ))

    return findings


# ---------------------------------------------------------------------------
# httprobe / httpx 输出解析
# ---------------------------------------------------------------------------

_HTTPX_RE = re.compile(
    r'^(?P<url>https?://\S+)\s+'
    r'(?:\[?(?P<status>\d{3})'
    r'(?:/\d+\s*bytes)?'
    r'\]?)?'
    r'(?:\s+\[(?P<tech>[^\]]+)\])?'
    r'(?:\s+(?P<extra>.*))?$'
)


def parse_httpprobe_output(text: str, tool: str = "httpx") -> list[Finding]:
    """
    解析 httprobe / httpx HTTP 探测结果。

    支持格式:
      https://example.com [200] [nginx/1.18.0]
      https://example.com:443

    Args:
        text: httprobe/httpx 命令的输出文本
        tool: 源工具名（"httprobe" 或 "httpx"）

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        url_match = _http_url_re(line)
        if not url_match:
            # 没有状态码，就是简单的 URL 列表输出 (httprobe)
            findings.append(Finding(
                category=FindingCategory.HTTP_ENDPOINT,
                target=line,
                detail="HTTP service detected",
                tool=tool,
                severity="info",
                raw_output=line,
                metadata={"url": line, "probe_result": "alive"},
            ))
            continue

        url = url_match.group("url")
        status = int(url_match.group("status")) if url_match.group("status") else 0
        tech = url_match.group("tech") or ""

        severity = "info"
        if status == 0:
            severity = "info"
        elif status >= 400 and status < 500:
            severity = "low"
        elif status >= 500:
            severity = "medium"

        meta: dict = {"url": url, "status_code": status}
        if tech:
            meta["technology"] = tech

        findings.append(Finding(
            category=FindingCategory.HTTP_ENDPOINT,
            target=url,
            detail=f"HTTP {status}" + (f" [{tech}]" if tech else ""),
            tool=tool,
            severity=severity,
            raw_output=line,
            metadata=meta,
        ))

    return findings


def _http_url_re(line: str):
    """辅助函数：检测 httpx 样式的输出行"""
    match = re.match(
        r'^(?P<url>https?://\S+)\s+'
        r'(?:\[?(?P<status>\d{3})'
        r'(?:/\d+\s*bytes)?'
        r'\]?)?'
        r'(?:\s+\[(?P<tech>[^\]]+)\])?'
        r'(?:\s+(?P<extra>.*))?$',
        line,
    )
    return match


# ---------------------------------------------------------------------------
# 子域名枚举结果解析 (subfinder / subdomain-enumeration)
# ---------------------------------------------------------------------------

_SUBDOMAIN_RE = re.compile(r'^[a-zA-Z0-9][-a-zA-Z0-9.]*\.[a-zA-Z]{2,}$')


def parse_subdomain_output(text: str, source: str = "manual") -> list[Finding]:
    """
    解析子域名枚举工具的输出（subfinder, subdomain-enumeration 等）。

    Args:
        text:   每行一个子域名的输出文本
        source: 工具来源名称

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        domain = line.strip()
        if not domain or domain.startswith("#"):
            continue
        # 基本域名格式验证
        if _SUBDOMAIN_RE.match(domain):
            findings.append(Finding(
                category=FindingCategory.SUBDOMAIN,
                target=domain,
                detail=f"子域名 (来源: {source})",
                tool=source,
                severity="info",
                raw_output=domain,
                metadata={"subdomain": domain, "source": source},
            ))

    return findings


# ---------------------------------------------------------------------------
# DNS 记录解析 (dnsx)
# ---------------------------------------------------------------------------

_DNS_RE = re.compile(
    r'^(?P<domain>\S+)\s+(?P<rtype>A|AAAA|CNAME|MX|NS|TXT|PTR)\s+(?P<value>\S+)$'
)


def parse_dns_output(text: str, source: str = "dnsx") -> list[Finding]:
    """
    解析 DNS 查询工具的输出（dnsx）。

    Args:
        text:   DNS 记录输出文本
        source: 工具来源名称

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        match = _DNS_RE.match(line)
        if match:
            findings.append(Finding(
                category=FindingCategory.DNS_RECORD,
                target=match.group("domain"),
                detail=f"{match.group('rtype')}: {match.group('value')}",
                tool=source,
                severity="info",
                raw_output=line,
                metadata={
                    "domain": match.group("domain"),
                    "record_type": match.group("rtype"),
                    "value": match.group("value"),
                    "source": source,
                },
            ))

    return findings


# ---------------------------------------------------------------------------
# Katana / 爬虫输出解析
# ---------------------------------------------------------------------------

_KATANA_URL_RE = re.compile(r'^(?P<url>https?://\S+)\s+status=(?P<status>\d+)')


def parse_katana_output(text: str) -> list[Finding]:
    """
    解析 Katana 爬虫发现的端点。

    Args:
        text: katana 命令输出（每行: URL status=CODE）

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        match = _KATANA_URL_RE.search(line)
        if match:
            url = match.group("url")
            status = int(match.group("status"))
            findings.append(Finding(
                category=FindingCategory.HTTP_ENDPOINT,
                target=url,
                detail=f"爬虫发现, HTTP {status}",
                tool="katana",
                severity="medium" if status >= 400 else "info",
                raw_output=line,
                metadata={"url": url, "status_code": status},
            ))

    return findings


# ---------------------------------------------------------------------------
# Gau / URL 历史结果解析 (waybackurls / gau)
# ---------------------------------------------------------------------------

_GAU_RE = re.compile(r'^https?://\S+$')


def parse_gau_output(text: str) -> list[Finding]:
    """
    解析 Gau/WaybackMachine/URLHunter 的历史 URL 发现。

    Args:
        text: 每行一个 URL 的输出文本

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        url = line.strip()
        if not url or url.startswith("#"):
            continue
        if _GAU_RE.match(url):
            findings.append(Finding(
                category=FindingCategory.HTTP_ENDPOINT,
                target=url,
                detail="历史 URL (Gau/Wayback)",
                tool="gau",
                severity="info",
                raw_output=url,
                metadata={"url": url, "source": "gau"},
            ))

    return findings


# ---------------------------------------------------------------------------
# 技术检测解析
# ---------------------------------------------------------------------------

_TECH_DETECTION_RE = re.compile(r'^([a-zA-Z][\w-]*)(?:/\s*([\d.]+))?$', re.IGNORECASE)


def parse_technology_output(text: str, source: str = "whatweb") -> list[Finding]:
    """
    解析技术检测工具的输出（whatweb, wappalyzer 等）。

    Args:
        text: 技术检测结果文本（每行: tech_name/version）
        source: 检测工具名

    Returns:
        Finding 列表
    """
    findings: list[Finding] = []

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        match = _TECH_DETECTION_RE.match(line)
        if match:
            tech_name = match.group(1)
            version = match.group(2) or ""
            findings.append(Finding(
                category=FindingCategory.TECHNOLOGY,
                target=tech_name,
                detail=f"{tech_name}{f'/{version}' if version else ''}",
                tool=source,
                severity="info",
                raw_output=line,
                metadata={"technology": tech_name, "version": version, "source": source},
            ))

    return findings


# ---------------------------------------------------------------------------
# 结果合并 — 对应 recon/parser.go 中的 MergeToolResults
# ---------------------------------------------------------------------------

def merge_tool_results(findings_list: list[list[Finding]]) -> dict:
    """
    从多个工具的输出中合并并去重发现。

    对应 Go 源码中的 MergeToolResults() — 按子域名/主机/URL 做字典去重，
    同时保留所有工具的原始数据用于后续分析。

    Args:
        findings_list: 每个元素的元素是同一工具发现的列表

    Returns:
        MergedData 样式的字典：
        {
            "subdomains": dict[domain->Finding],
            "hosts": dict[ip -> Finding],
            "endpoints": dict[url -> Finding],
        }
    """
    merged = {
        "subdomains": {},
        "hosts": {},
        "endpoints": {},
        "all_findings": [],
    }

    for batch in findings_list:
        for finding in batch:
            merged["all_findings"].append(finding)

            cat = finding.category
            target_key = finding.target

            if cat == FindingCategory.SUBDOMAIN:
                merged["subdomains"][target_key] = finding
            elif cat == FindingCategory.HOST:
                merged["hosts"][target_key] = finding
            elif cat in (FindingCategory.HTTP_ENDPOINT, FindingCategory.DIRECTORY):
                merged["endpoints"][target_key] = finding

    return merged


# ---------------------------------------------------------------------------
# 分类函数 — 对应 classify_recon_finding
# ---------------------------------------------------------------------------

def classify_recon_finding(finding: Finding) -> str:
    """
    将一条发现归类为侦察活动的类别。

    对应 Go recon agent 中的 LLM-driven classification，此处用规则引擎实现：
      - open_port:   端口扫描发现
      - directory:   目录爆破发现
      - subdomain:   子域名枚举
      - service:     服务识别
      - endpoint:    HTTP 端点（爬虫/历史）
      - technology:  技术栈检测
      - host:        主机发现

    Args:
        finding: Finding 对象

    Returns:
        分类字符串
    """
    cat = finding.category
    if cat == FindingCategory.OPEN_PORT:
        return "open_port"
    elif cat == FindingCategory.DIRECTORY:
        return "directory"
    elif cat == FindingCategory.SUBDOMAIN:
        return "subdomain"
    elif cat in (FindingCategory.SERVICE, FindingCategory.HOST):
        return "service" if cat == FindingCategory.SERVICE else "host"
    elif cat == FindingCategory.HTTP_ENDPOINT:
        return "endpoint"
    elif cat == FindingCategory.TECHNOLOGY:
        return "technology"
    elif cat == FindingCategory.DNS_RECORD:
        return "dns_record"
    return "unknown"


# ---------------------------------------------------------------------------
# AttackSurface JSON 解析 — 对应 ParseAttackSurface + fallback shapes
# ---------------------------------------------------------------------------

import json as _json


def strip_code_fence(raw_json: str) -> str:
    """移除 markdown ```json ... ``` 代码块包装"""
    raw_json = raw_json.strip()
    if raw_json.startswith("```json"):
        raw_json = raw_json[7:]
    elif raw_json.startswith("```"):
        raw_json = raw_json[3:]
    if raw_json.endswith("```"):
        raw_json = raw_json[:-3]
    return raw_json.strip()


def _is_empty(raw: str) -> bool:
    """检查 JSON 原始消息是否为空/null"""
    s = raw.strip()
    return s == "" or s == "null"


def _parse_polymorphic_list(raw: str):
    """解析多态字段：尝试严格对象数组 > 扁平字符串数组 > 单对象"""
    if _is_empty(raw):
        return None

    # 尝试 1: 严格对象数组
    try:
        parsed = _json.loads(raw)
        if isinstance(parsed, list):
            return parsed
    except (json.JSONDecodeError, ValueError):
        pass

    # 尝试 2: 扁平字符串列表
    try:
        parsed = _json.loads(raw)
        if isinstance(parsed, list) and all(isinstance(x, str) for x in parsed):
            return [{"value": s} for s in parsed if s]
    except (json.JSONDecodeError, ValueError):
        pass

    # 尝试 3: 单个对象
    try:
        parsed = _json.loads(raw)
        if isinstance(parsed, dict):
            return [parsed]
    except (json.JSONDecodeError, ValueError):
        pass

    return None


def parse_attack_surface(raw_json: str) -> tuple[AttackSurface, Optional[str]]:
    """
    解析 LLM 响应或 JSON 字符串为 AttackSurface。

    核心算法源自 Pentest-Swarm-AI recon/parser.go:ParseAttackSurface()，
    容忍三种常见形状漂移（对象数组 / 扁平字符串数组 / 单个对象）。

    Args:
        raw_json: LLM 返回的 JSON 文本（可能包含 markdown 代码块包装）

    Returns:
        (AttackSurface, error_string) — 成功时 error 为 None，失败时为错误信息
    """
    raw_json = strip_code_fence(raw_json).strip()
    if not raw_json:
        return AttackSurface(), "来自 LLM 的响应为空"

    try:
        data = _json.loads(raw_json)
    except (json.JSONDecodeError, ValueError) as e:
        return AttackSurface(), f"解析攻击面 JSON 失败: {e}"

    if not isinstance(data, dict):
        return AttackSurface(), "JSON 根元素必须是对象"

    surface = AttackSurface()

    # target
    surface.target = data.get("target", "")
    surface.campaign_id = data.get("campaign_id", data.get("campaignId", ""))

    # created_at
    surface.created_at = data.get("created_at", data.get("createdAt", ""))

    # subdomains — 多态解析
    raw_subs = _json.dumps(data.get("subdomains", "") or "")
    subs_parsed = _parse_polymorphic_list(raw_subs)
    if subs_parsed:
        for item in subs_parsed:
            if isinstance(item, str):
                surface.subdomains.append(SubdomainRecord(domain=item, source="llm-flat"))
            elif isinstance(item, dict):
                rec = SubdomainRecord()
                rec.domain = item.get("domain", "")
                rec.ip = item.get("ip", "")
                rec.source = item.get("source", "llm-flat")
                surface.subdomains.append(rec)

    # hosts — 多态解析
    raw_hosts = _json.dumps(data.get("hosts", "") or "")
    hosts_parsed = _parse_polymorphic_list(raw_hosts)
    if hosts_parsed:
        for item in hosts_parsed:
            if isinstance(item, str):
                surface.hosts.append(HostRecord(ip=item))
            elif isinstance(item, dict):
                rec = HostRecord()
                rec.ip = item.get("ip", "")
                rec.hostnames = item.get("hostnames", [])
                rec.open_ports = item.get("open_ports", [])
                rec.services = item.get("services", {})
                rec.os = item.get("os", "")
                surface.hosts.append(rec)

    # endpoints — 多态解析
    raw_eps = _json.dumps(data.get("endpoints", "") or "")
    eps_parsed = _parse_polymorphic_list(raw_eps)
    if eps_parsed:
        for item in eps_parsed:
            if isinstance(item, str):
                surface.endpoints.append(EndpointRecord(url=item))
            elif isinstance(item, dict):
                rec = EndpointRecord()
                rec.url = item.get("url", "")
                rec.method = item.get("method", "GET")
                rec.status_code = item.get("status_code", 0)
                rec.interesting = item.get("interesting", False)
                surface.endpoints.append(rec)

    # technologies — map[name]version OR flat string array
    raw_tech = data.get("technologies", "")
    if raw_tech and _is_empty(_json.dumps(raw_tech)):
        surface.technologies = {}
    elif isinstance(raw_tech, dict):
        surface.technologies = {str(k): str(v) for k, v in raw_tech.items()}
    elif isinstance(raw_tech, list):
        surface.technologies = {str(t): "" for t in raw_tech if t}

    return surface, None


# ---------------------------------------------------------------------------
# Recon 规划 — 对应 PlanRecon（确定目标类型和工具链）
# ---------------------------------------------------------------------------

def _is_ip_target(target: str) -> bool:
    """判断目标是否为 IP 地址"""
    parts = target.split(".")
    if len(parts) != 4:
        return False
    for p in parts:
        if not p.isdigit():
            return False
    return True


def _is_url_target(target: str) -> bool:
    """判断目标是否为 URL"""
    return target.startswith("http://") or target.startswith("https://")


# Recon 工具链定义 — 对应 Go PlanRecon 中的 ToolOrder
RECON_TOOL_CHAINS = {
    # IP 目标: 端口扫描 → HTTP探测 → 漏洞扫描
    "ip": ["naabu", "httprobe", "nuclei"],
    # URL 目标: HTTP探测 → 爬虫 → 历史URL → 漏洞扫描
    "url": ["httpx", "katana", "gau", "nuclei"],
    # 域名目标: 完整侦察管线
    "domain": ["subfinder", "dnsx", "naabu", "httprobe", "katana", "gau", "nuclei"],
}


def plan_recon(target: str) -> dict:
    """
    根据目标类型确定侦察工具链。

    核心算法源自 Pentest-Swarm-AI recon/agent.go:PlanRecon()。

    Args:
        target: 扫描目标 (IP / URL / 域名)

    Returns:
        {"target": str, "tool_order": list[str]}
    """
    if _is_ip_target(target):
        tool_order = RECON_TOOL_CHAINS["ip"]
    elif _is_url_target(target):
        tool_order = RECON_TOOL_CHAINS["url"]
    else:
        tool_order = RECON_TOOL_CHAINS["domain"]

    return {"target": target, "tool_order": tool_order}


# ---------------------------------------------------------------------------
# 便捷函数 — 从工具名称推断解析器
# ---------------------------------------------------------------------------

def parse_tool_output(tool_name: str, text: str, **kwargs) -> list[Finding]:
    """
    根据工具名称自动选择对应的解析函数。

    Args:
        tool_name: 工具名 (nmap, gobuster, httprobe, httpx, subfinder, dnsx, katana, gau, whatweb)
        text:      工具的原始输出文本
        **kwargs:   传递给具体解析函数的额外参数

    Returns:
        Finding 列表
    """
    tool = tool_name.lower().strip()
    parsers = {
        "nmap": parse_nmap_output,
        "gobuster": lambda t, **kw: parse_gobuster_output(t),
        "httprobe": lambda t, **kw: parse_httpprobe_output(t, "httprobe"),
        "httpx": lambda t, **kw: parse_httpprobe_output(t, "httpx"),
        "subfinder": lambda t, **kw: parse_subdomain_output(t, "subfinder"),
        "dnsx": lambda t, **kw: parse_dns_output(t, "dnsx"),
        "katana": parse_katana_output,
        "gau": parse_gau_output,
        "waybackurls": parse_gau_output,
        "whatweb": lambda t, **kw: parse_technology_output(t, "whatweb"),
        "nuclei": lambda t, **kw: parse_nuclei_output(t),
    }
    parser = parsers.get(tool)
    if parser is None:
        return [Finding(
            category=FindingCategory.UNKNOWN,
            target="<unknown>",
            detail=f"未知工具输出: {tool}",
            tool=tool_name,
            severity="info",
            raw_output=text[:200],
        )]
    return parser(text, **kwargs)


def parse_nuclei_output(text: str) -> list[Finding]:
    """
    解析 Nuclei 漏洞扫描结果输出。

    支持 Nuclei YAML/JSON 样式的文本输出格式。

    Args:
        text: nuclei 命令的输出文本

    Returns:
        Finding 列表
    """
    findings = []

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("["):
            continue

        # Nuclei JSON 格式输出
        if line.startswith("{"):
            try:
                data = _json.loads(line)
                info = data.get("info", {})
                host = data.get("host", "")
                severity = info.get("severity", "info")
                name = info.get("name", "unknown-template")

                # Nuclei 严重性映射到我们的标准
                sev_map = {"critical": "critical", "high": "high", "medium": "medium", "low": "low"}
                mapped_sev = sev_map.get(severity, "info")

                findings.append(Finding(
                    category=FindingCategory.HTTP_ENDPOINT,
                    target=host,
                    detail=f"[{severity.upper()}] {name}",
                    tool="nuclei",
                    severity=mapped_sev,
                    raw_output=line,
                    metadata={
                        "template": info.get("template_id", ""),
                        "template_url": info.get("template_url", ""),
                        "host": host,
                        "info": info,
                    },
                ))
            except (json.JSONDecodeError, ValueError):
                pass
            continue

        # 文本格式输出: [INFO] ... [https://...] matched ...
        url_match = re.search(r'https?://\S+', line)
        if url_match:
            findings.append(Finding(
                category=FindingCategory.HTTP_ENDPOINT,
                target=url_match.group(),
                detail=line[:100],
                tool="nuclei",
                severity="medium",
                raw_output=line,
            ))

    return findings
