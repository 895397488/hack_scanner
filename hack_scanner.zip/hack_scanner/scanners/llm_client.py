#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM 适配器 — 为 swarm_orchestrator 提供 llm_invoke 契约实现
=====================================================================

契约（swarm_orchestrator.py:225, 318-324）:
    llm_invoke(system_prompt, messages, tools, max_tokens, temperature) -> {
        "content": str,                      # 可为 ""
        "stop_reason": "end_turn" | None,    # 无工具调用的正常结束 = "end_turn"
        "tool_calls": [                      # arguments 必须是 JSON 字符串
            {"name": str, "arguments": "<json string>", "id": str},
        ],
    }
    失败时返回 None（orchestrator 有现成的干净终止分支）。

实现决策（为什么是 JSON 文本协议而不是原生 function calling）:
    orchestrator 的消息历史是自定义格式 — assistant 轮只存 content、
    工具结果用 role="tool"（swarm_orchestrator.py:337, 414-418），
    不含 tool_calls 字段。这种历史无法无损重构成 OpenAI/Anthropic
    原生多轮 tool 消息（原生要求 assistant 消息携带 tool_calls 且
    tool 消息的 tool_call_id 与之对应）。因此采用 JSON 文本协议：
    纯文本进/出，openai_compatible / anthropic / ollama 三协议通用，
    复用 ai_analyzer 已验证的调用路径。原生 tool 调用留作后续扩展
    （需改 orchestrator 消息格式，超出本次"零改动"约束）。

依赖:
    - ai_analyzer.PROVIDER_DB      provider 元信息矩阵
    - ai_analyzer.pick_ollama_model  Ollama 本地模型挑选
    - config.json ai 段             provider/model/base_url/api_key
"""

import json
import logging
import os
import re
import time
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger('llm_client')

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 从 ai_analyzer 复用 provider 矩阵与 Ollama 模型挑选（避免重复维护 11 家配置）
try:
    import sys
    if _PROJECT_ROOT not in sys.path:
        sys.path.insert(0, _PROJECT_ROOT)
    from ai_analyzer import PROVIDER_DB, pick_ollama_model
    _HAS_AI_ANALYZER = True
except Exception as _exc:  # pragma: no cover - 环境异常兜底
    PROVIDER_DB = {"providers": {}}
    pick_ollama_model = None
    _HAS_AI_ANALYZER = False
    logger.warning(f"ai_analyzer 导入失败，provider 矩阵降级为空: {_exc!r}")

MAX_RETRIES = 2          # 传输错误重试次数（不含首次）
RETRY_BASE_DELAY = 2.0   # 秒，指数退避基数
CONTEXT_WINDOW_TOKENS = 65536  # 模型上下文长度 64k（Ollama num_ctx，2026-09-14 用户指定）
TRANSCRIPT_TAIL_CHARS = 120000  # 历史转录长度上限（保留尾部，最新上下文最重要；
                                # 120k 字符 ≈ 35-45k token 混合内容，装得进 64k 窗口）
TOOL_RESULT_RENDER_CHARS = 2000  # 单条工具结果渲染截断


# ---------------------------------------------------------------------------
# 配置加载
# ---------------------------------------------------------------------------
def load_ai_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """加载 config.json ai 段 + PROVIDER_DB 元信息，返回解析后的配置。

    返回: {
        enabled, provider, model, base_url, api_key, api_type,
        temperature, max_tokens, display_name
    }
    """
    if config_path is None:
        config_path = os.path.join(_PROJECT_ROOT, "config.json")

    ai_conf: Dict[str, Any] = {}
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            ai_conf = (json.load(f) or {}).get("ai", {}) or {}
    except FileNotFoundError:
        logger.warning(f"config.json 不存在: {config_path}")
    except json.JSONDecodeError as exc:
        logger.warning(f"config.json 解析失败: {exc}")

    provider = ai_conf.get("provider", "ollama")
    info = PROVIDER_DB.get("providers", {}).get(provider, {})
    api_type = info.get("api_type", "openai_compatible") if info else "ollama"

    model = ai_conf.get("model", "") or ""
    if not model and info.get("default_model") and api_type != "ollama":
        model = info["default_model"]

    base_url = ai_conf.get("base_url", "") or (info.get("default_base_url", "") if info else "")
    if not base_url:
        base_url = "http://127.0.0.1:11434" if api_type == "ollama" else ""

    api_key = ai_conf.get("api_key", "") or ""
    env_key = info.get("env_api_key") if info else None
    if not api_key and env_key:
        api_key = os.environ.get(env_key, "")

    return {
        "enabled": bool(ai_conf.get("enabled", False)),
        "provider": provider,
        "model": model,
        "base_url": base_url,
        "api_key": api_key,
        "api_type": api_type,
        "temperature": ai_conf.get("temperature", 0.2),
        "max_tokens": ai_conf.get("max_tokens", 4096),
        "display_name": info.get("display_name", provider) if info else provider,
    }


# ---------------------------------------------------------------------------
# JSON 协议提示构建
# ---------------------------------------------------------------------------
def _render_tool(t: Dict[str, Any]) -> str:
    """把 orchestrator 的工具定义（{name, description, parameters}）渲染成协议说明。"""
    lines = [f"- {t.get('name', '?')}: {t.get('description', '').strip()}"]
    params = t.get("parameters") or {}
    if isinstance(params, dict) and params:
        for k, v in params.items():
            if isinstance(v, dict):  # 已经是 schema 片段
                desc = v.get("description", "")
            else:
                desc = str(v)
            lines.append(f"    * {k}: {desc}")
    return "\n".join(lines)


def build_protocol_system(system_prompt: str, tools: List[Dict[str, Any]]) -> str:
    """原始 system prompt + 严格 JSON 工具调用协议。"""
    tool_block = "\n".join(_render_tool(t) for t in tools) if tools else "(no tools available)"
    return (
        system_prompt
        + "\n\n"
        + "=== TOOL CALLING PROTOCOL (STRICT) ===\n"
        + "You may accomplish the task by calling tools. Available tools:\n"
        + tool_block
        + "\n\nOn EACH turn, respond with EXACTLY ONE JSON object — no markdown fences, "
        + "no commentary before or after. Two allowed shapes:\n"
        + '1) Calling a tool: {"thought": "<brief reasoning>", "tool": "<tool name>", "args": {<parameters>}}\n'
        + '2) No tool (final answer / campaign complete): {"thought": "<your message>", "tool": null, "args": null}\n'
        + 'Rules: "tool" must be one of the names listed above (or null). "args" must be a JSON object '
        + "with only that tool's parameters (or null). Output the JSON object and nothing else."
    )


def build_transcript(messages: List[Dict[str, str]]) -> str:
    """把 orchestrator 的自定义消息历史渲染成线性文本转录（保留尾部）。"""
    parts: List[str] = []
    for m in messages:
        role = m.get("role", "user")
        content = str(m.get("content", "") or "")
        if role == "user":
            parts.append(f"[USER] {content}")
        elif role == "assistant":
            parts.append(f"[ASSISTANT] {content}")
        elif role == "tool":
            parts.append(f"[TOOL_RESULT] {content[:TOOL_RESULT_RENDER_CHARS]}")
        else:
            parts.append(f"[{role.upper()}] {content}")
    text = "\n\n".join(parts)
    if len(text) > TRANSCRIPT_TAIL_CHARS:
        text = text[-TRANSCRIPT_TAIL_CHARS:]
    return text


# ---------------------------------------------------------------------------
# 响应解析
# ---------------------------------------------------------------------------
def _extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    """从可能含前后杂音的文本中提取第一个平衡的 JSON 对象。

    依次尝试: 直接 parse → 首个 '{' 起的花括号配对扫描（感知字符串/转义）
    → 首个 '{' 到末个 '}' 的切片。全部失败返回 None。
    """
    if not text:
        return None

    candidates: List[str] = []

    # 直接整个 parse
    candidates.append(text.strip())

    # 花括号配对扫描
    start = text.find("{")
    if start >= 0:
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidates.append(text[start:i + 1])
                    break

    # 兜底: 首 '{' 到末 '}'
    end = text.rfind("}")
    if start >= 0 and end > start and len(candidates) == 1:
        candidates.append(text[start:end + 1])

    for cand in candidates:
        try:
            obj = json.loads(cand)
            if isinstance(obj, dict):
                return obj
        except (json.JSONDecodeError, TypeError, ValueError):
            continue
    return None


def parse_llm_response(text: str, tc_counter: List[int]) -> Dict[str, Any]:
    """把 LLM 的文本响应解析成 llm_invoke 契约 dict。

    解析失败时安全降级为"无工具调用 + 原文本"（orchestrator 会 nudge 继续，
    不会崩溃）。
    """
    obj = _extract_json_object(text or "")
    if obj is None:
        # 安全降级：整段当思考文本，不触发工具调用
        return {
            "content": (text or "")[:4000],
            "stop_reason": "end_turn",
            "tool_calls": [],
        }

    thought = str(obj.get("thought", "") or "")
    tool = obj.get("tool")
    args = obj.get("args")

    if not tool or tool in ("null", "none", "None"):
        return {
            "content": thought,
            "stop_reason": "end_turn",
            "tool_calls": [],
        }

    # args 必须是 JSON 对象；模型若给了 JSON 字符串则尝试解析
    if args is None:
        args_obj: Dict[str, Any] = {}
    elif isinstance(args, dict):
        args_obj = args
    elif isinstance(args, str):
        try:
            parsed = json.loads(args)
            args_obj = parsed if isinstance(parsed, dict) else {}
        except (json.JSONDecodeError, TypeError):
            args_obj = {}
    else:
        args_obj = {}

    tc_counter[0] += 1
    return {
        "content": thought,
        "stop_reason": None,
        "tool_calls": [{
            "name": str(tool),
            "arguments": json.dumps(args_obj, ensure_ascii=False),
            "id": f"tc-{tc_counter[0]}",
        }],
    }


# ---------------------------------------------------------------------------
# LLMClient
# ---------------------------------------------------------------------------
class LLMClient:
    """多 provider LLM 客户端 — 输出统一的 llm_invoke 契约 dict。"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.cfg = config or load_ai_config()
        self._tc_counter = [0]  # 可变容器，供 parse_llm_response 生成稳定递增 id
        self.usage = {"calls": 0, "prompt_tokens": 0, "completion_tokens": 0}
        self._ollama_model_cache: Optional[str] = None

    # ---------------- 主入口 ----------------
    def invoke(
        self,
        system_prompt: str,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]],
        max_tokens: int = 4096,
        temperature: float = 0.1,
    ) -> Optional[Dict[str, Any]]:
        """llm_invoke 契约实现。成功返回 dict，重试耗尽返回 None。"""
        if not self.cfg.get("enabled", False):
            logger.error("AI 未启用 (config.json ai.enabled != true)")
            return None

        full_system = build_protocol_system(system_prompt, tools or [])
        user_text = (
            build_transcript(messages)
            + "\n\nRespond now: output the single JSON object per the protocol."
        )

        last_err = ""
        for attempt in range(MAX_RETRIES + 1):
            if attempt > 0:
                delay = RETRY_BASE_DELAY * attempt
                logger.warning(f"LLM 调用失败，{delay:.0f}s 后重试 ({attempt}/{MAX_RETRIES}): {last_err[:160]}")
                time.sleep(delay)
                if self.cfg["api_type"] == "ollama":
                    self._ollama_model_cache = None  # 重试前重查本机模型

            content, err, usage = self._post(full_system, user_text, max_tokens, temperature)
            if err is not None:
                last_err = err
                continue

            self.usage["calls"] += 1
            self.usage["prompt_tokens"] += usage.get("prompt", 0)
            self.usage["completion_tokens"] += usage.get("completion", 0)

            return parse_llm_response(content, self._tc_counter)

        logger.error(f"LLM 调用重试耗尽: {last_err[:300]}")
        return None

    # ---------------- provider 分发 ----------------
    def _post(self, system: str, user: str, max_tokens: int, temperature: float):
        """按 api_type 分发。返回 (content_text, error_or_None, usage_dict)。"""
        api_type = self.cfg["api_type"]
        if api_type == "ollama":
            return self._post_ollama(system, user, max_tokens, temperature)
        if api_type == "anthropic":
            return self._post_anthropic(system, user, max_tokens, temperature)
        return self._post_openai_compatible(system, user, max_tokens, temperature)

    def _resolve_ollama_model(self) -> Optional[str]:
        """model 为空时查询 Ollama /api/tags 自动挑选（缓存结果）。"""
        if self.cfg.get("model"):
            return self.cfg["model"]
        if self._ollama_model_cache:
            return self._ollama_model_cache
        try:
            import requests as req
            base = self.cfg.get("base_url") or "http://127.0.0.1:11434"
            resp = req.get(f"{base.rstrip('/')}/api/tags", timeout=5)
            resp.raise_for_status()
            names = [m.get("name", "") for m in resp.json().get("models", []) if m.get("name")]
            if pick_ollama_model is not None:
                picked = pick_ollama_model(names, preferred=None)
            else:
                picked = sorted(names)[-1] if names else None
            if picked:
                self._ollama_model_cache = picked
                logger.info(f"🔍 Ollama 自动选用本机模型: {picked}")
            else:
                logger.error("Ollama 未安装任何模型 — 请先 `ollama pull <model>`")
            return picked
        except Exception as exc:
            logger.error(f"Ollama /api/tags 查询失败: {exc}")
            return None

    def _post_ollama(self, system: str, user: str, max_tokens: int, temperature: float):
        model = self._resolve_ollama_model()
        if not model:
            return None, "Ollama 无可用模型", {}
        url = (self.cfg.get("base_url") or "http://127.0.0.1:11434").rstrip("/") + "/api/chat"
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens,
                        "num_ctx": CONTEXT_WINDOW_TOKENS},
        }
        headers = {"Content-Type": "application/json"}

        try:
            # ai_analyzer 同款修法: Ollama 对 HTTP/2 连接返回 404，强制 HTTP/1.1
            import urllib3
            http = urllib3.PoolManager()
            raw = http.request(
                "POST", url,
                body=json.dumps(payload).encode("utf-8"),
                headers=headers,
                timeout=300,
            )
            text = raw.data.decode("utf-8", errors="replace")
            if raw.status != 200:
                return None, f"HTTP {raw.status}: {text[:300]}", {}
            data = json.loads(text)
            content = (data.get("message") or {}).get("content", "") or ""
            usage = {
                "prompt": int(data.get("prompt_eval_count") or 0),
                "completion": int(data.get("eval_count") or 0),
            }
            return content, None, usage
        except Exception as exc:
            return None, f"{type(exc).__name__}: {exc}", {}

    def _post_openai_compatible(self, system: str, user: str, max_tokens: int, temperature: float):
        import requests as req

        url = self.cfg["base_url"].rstrip("/")
        api_path = "/v1/chat/completions"
        if not url.endswith(api_path) and not url.endswith("/chat/completions"):
            url += api_path

        headers = {"Content-Type": "application/json"}
        if self.cfg.get("api_key"):
            headers["Authorization"] = f"Bearer {self.cfg['api_key']}"
        payload = {
            "model": self.cfg.get("model") or "default",
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            resp = req.post(url, json=payload, headers=headers, timeout=300)
            resp.encoding = "utf-8"
            if resp.status_code != 200:
                return None, f"HTTP {resp.status_code}: {resp.text[:300]}", {}
            data = resp.json()
            content = (data.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""
            u = data.get("usage") or {}
            usage = {
                "prompt": int(u.get("prompt_tokens") or 0),
                "completion": int(u.get("completion_tokens") or 0),
            }
            return content, None, usage
        except Exception as exc:
            return None, f"{type(exc).__name__}: {exc}", {}

    def _post_anthropic(self, system: str, user: str, max_tokens: int, temperature: float):
        import requests as req

        url = (self.cfg.get("base_url") or "https://api.anthropic.com").rstrip("/")
        if not url.endswith("/v1/messages"):
            url += "/v1/messages"

        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.cfg.get("api_key") or "",
            "anthropic-version": "2023-06-01",
        }
        payload = {
            "model": self.cfg.get("model") or "claude-sonnet-4-20250514",
            "system": system,
            "messages": [{"role": "user", "content": user}],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            resp = req.post(url, json=payload, headers=headers, timeout=300)
            resp.encoding = "utf-8"
            if resp.status_code != 200:
                return None, f"HTTP {resp.status_code}: {resp.text[:300]}", {}
            data = resp.json()
            content = "".join(
                c.get("text", "") for c in (data.get("content") or [])
                if isinstance(c, dict) and c.get("type") == "text"
            )
            u = data.get("usage") or {}
            usage = {
                "prompt": int(u.get("input_tokens") or 0),
                "completion": int(u.get("output_tokens") or 0),
            }
            return content, None, usage
        except Exception as exc:
            return None, f"{type(exc).__name__}: {exc}", {}


# ---------------------------------------------------------------------------
# 便捷入口
# ---------------------------------------------------------------------------
def build_llm_invoke(config_path: Optional[str] = None) -> Callable[..., Optional[Dict[str, Any]]]:
    """返回匹配 SwarmOrchestrator(llm_invoke=...) 签名的绑定函数。"""
    cfg = load_ai_config(config_path) if config_path else load_ai_config()
    client = LLMClient(cfg)

    def invoke(system_prompt: str, messages: List[Dict[str, str]],
               tools: List[Dict[str, Any]], max_tokens: int = 4096,
               temperature: float = 0.1) -> Optional[Dict[str, Any]]:
        return client.invoke(system_prompt, messages, tools, max_tokens, temperature)

    invoke.client = client  # 供入口层读 usage（绑定方法不能挂属性，用闭包）
    return invoke


def llm_smoke_test(max_tokens: int = 512) -> Dict[str, Any]:
    """LLM 链路冒烟测试: 用假工具发一次请求，验证契约三字段齐全。

    返回: {ok, provider, model, tool_calls, content_preview, usage, error?}
    """
    cfg = load_ai_config()
    client = LLMClient(cfg)
    fake_tools = [{
        "name": "echo_probe",
        "description": "Echo back the given word for testing",
        "parameters": {"word": "the word to echo"},
    }]
    resp = client.invoke(
        system_prompt="You are a test agent. Call the echo_probe tool with word=ping.",
        messages=[{"role": "user", "content": "Begin."}],
        tools=fake_tools,
        max_tokens=max_tokens,
        temperature=0.0,
    )
    result: Dict[str, Any] = {
        "ok": resp is not None and len(resp.get("tool_calls", [])) == 1,
        "provider": cfg.get("provider"),
        "model": cfg.get("model") or client._ollama_model_cache or "(auto)",
        "usage": dict(client.usage),
    }
    if resp is None:
        result["error"] = "LLM invoke 返回 None（链路失败，见日志）"
        return result
    result["tool_calls"] = resp.get("tool_calls")
    result["content_preview"] = resp.get("content", "")[:200]
    return result


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    out = llm_smoke_test()
    print(json.dumps(out, ensure_ascii=False, indent=2))
    sys.exit(0 if out.get("ok") else 1)
