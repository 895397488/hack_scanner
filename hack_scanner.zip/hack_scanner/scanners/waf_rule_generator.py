"""WAF Rule Generator from Scan Findings.

Inspired by Acunetix templates/reports/F5 exporter patterns, this module
translates vulnerability scan findings into production-ready WAF rules
across three popular platforms: F5 BIG-IP iRule, Cloudflare WAF JSON, and
Apache mod_security / OWASP CRS syntax.

Design constraints
------------------
* **Conservative rule generation** — every rule is scoped narrowly to the
  specific payload or URI observed in the finding; overly broad patterns are
  avoided to prevent false-positive blocks against legitimate traffic.
* **Traceability** — each generated rule carries a ``source_finding`` comment
  that links back to the originating scan finding for audit purposes.
* **Auto-deduplication** — near-identical rules produced from overlapping
  findings are coalesced automatically using a normalised fingerprint.

Usage example
-------------
>>> from waf_rule_generator import (
...     VulnFinding, RuleGenerator, FindingSeverity,
... )
>>> f = VulnFinding(
...     name="SQL Injection",
...     severity=FindingSeverity.CRITICAL,
...     url="/api/users?id=1",
...     param="id",
...     payload="' OR 1=1--",
...     waf_tag="sql-injection",
... )
>>> generator = RuleGenerator()
>>> for rule in generator.generate_all_findings([f], "modsecurity"):
...     print(rule)
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, List, Optional, Set


# ===================================================================
# Data model
# ===================================================================

class FindingSeverity(str, Enum):
    """Severity levels for a vulnerability finding.

    Values map to OWASP Risk Ratings and are used to determine whether a
    generated WAF rule should block or only log traffic.
    """

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class VulnFinding:
    """Represents a single vulnerability finding from a security scanner.

    Attributes
    ----------
    name : str
        Short human-readable summary of the finding (e.g. ``"SQL Injection"``).
    severity : FindingSeverity
        How severe the finding is assessed to be.
    url : str
        The affected URL, if applicable.  May be empty for header-based findings.
    param : str
        The vulnerable parameter name, if applicable (e.g. ``"id"``, ``"file"``).
    payload : str
        The malicious payload that triggered the detection.  Used directly in
        pattern generation rather than heuristic sigmappings where possible.
    waf_tag : str
        A category tag suitable for WAF rule targeting (e.g. ``"sql-injection"``,
        ``"xss-reflected"``).  Defaults to a slugified version of *name*.
    cwe_id : str
        CWE identifier when known (e.g. ``"CWE-89"``).  May be empty.
    """

    name: str
    severity: FindingSeverity
    url: str = ""
    param: str = ""
    payload: str = ""
    waf_tag: str = ""
    cwe_id: str = ""

    # -- internal helpers ---------------------------------------------------

    def __post_init__(self) -> None:
        if not self.waf_tag:
            slug = re.sub(r"[^a-z0-9]+", "-", self.name.lower()).strip("-")
            self.waf_tag = slug or "general"

    @property
    def source_finding_ref(self) -> str:
        """Return a comment-safe reference string for audit trail.

        The format is designed to be parsed by downstream tooling that tracks
        rule provenance back to scanner output files.
        """
        parts: List[str] = [f"finding:{self.name}"]
        if self.url:
            parts.append(f"url:{self.url}")
        if self.param:
            parts.append(f"param:{self.param}")
        return " | ".join(parts)


# ===================================================================
# Deduplication helpers
# ===================================================================

def _normalise_pattern(text: str) -> str:
    """Collapse whitespace and lower-case for comparison.

    Two patterns whose normalised forms match are treated as duplicates; only
    the first occurrence is retained.
    """
    text = re.sub(r"\s+", " ", text).strip().lower()
    return re.sub(r"#.*", "", text)


def deduplicate_patterns(
    items: Iterable[str], key: Optional[callable] = None
) -> List[str]:
    """Return *items* with near-duplicates removed.

    Parameters
    ----------
    items : iterable of str
        Pattern strings to deduplicate.
    key : callable or None
        Optional function to extract the comparison key from each item.  When
        ``None``, the item itself is normalised and compared directly.

    Returns
    -------
    list[str]
        A list of unique pattern strings in first-seen order.
    """
    seen: Set[str] = set()
    result: List[str] = []
    for item in items:
        raw_key = key(item) if key is not None else item
        norm_key = _normalise_pattern(raw_key) if isinstance(raw_key, str) and key is None else raw_key
        if norm_key not in seen:
            seen.add(norm_key)
            result.append(item)
    return result


# ===================================================================
# Base RuleGenerator
# ===================================================================

class RuleGenerator:
    """Generate WAF rules from a list of vulnerability findings.

    This is the primary entry-point class.  It iterates over a list of
    ``VulnFinding`` instances, dispatches each to the appropriate format-specific
    exporter, and coalesces duplicate rules across all findings via normalised
    fingerprinting.

    Parameters
    ----------
    severity_threshold : str or None
        Minimum severity level (inclusive) for rules to be generated.
        Accepts ``"low"``, ``"medium"``, ``"high"``, ``"critical"``.
        When ``None``, all severities are emitted.  Defaults to ``None``.

    Example
    -------
    >>> from waf_rule_generator import (
    ...     VulnFinding, RuleGenerator, FindingSeverity,
    ... )
    >>> findings = [
    ...     VulnFinding(
    ...         name="SQL Injection",
    ...         severity=FindingSeverity.CRITICAL,
    ...         payload="' OR 1=1--",
    ...         waf_tag="sql-injection",
    ...     ),
    ... ]
    >>> gen = RuleGenerator()
    >>> rules = gen.generate_all_findings(findings, "modsecurity")
    """

    SUPPORTED_FORMATS = ("irule", "cloudflare", "modsecurity")

    SEVERITY_ORDER: dict[FindingSeverity, int] = {
        FindingSeverity.INFO: 0,
        FindingSeverity.LOW: 1,
        FindingSeverity.MEDIUM: 2,
        FindingSeverity.HIGH: 3,
        FindingSeverity.CRITICAL: 4,
    }

    def __init__(self, severity_threshold: Optional[str] = None) -> None:
        if severity_threshold is not None:
            self._min_sev: int = self.SEVERITY_ORDER.get(
                FindingSeverity(severity_threshold.lower()), 0
            )
        else:
            self._min_sev = -1  # include all severities.

    def generate_all_findings(
        self,
        findings_list: Iterable[VulnFinding],
        output_format: str,
    ) -> List[str]:
        """Generate WAF rules for every finding in *findings_list*.

        For each finding the method selects the matching exporter subclass,
        collects the raw rule strings, and deduplicates them against all
        previously collected rules.  Each surviving rule is annotated with a
        ``source_finding`` comment block that references the originating scan
        finding for auditability.

        Parameters
        ----------
        findings_list : iterable of VulnFinding
            Security scan findings to convert into WAF rules.
        output_format : str
            Target format identifier.  One of:

            - ``"irule"`` -- F5 BIG-IP iRule syntax (via :class:`F5IRuleExporter`)
            - ``"cloudflare"`` -- Cloudflare WAF JSON (via :class:`CloudflareWafRuleExporter`)
            - ``"modsecurity"`` -- Apache mod-security / OWASP CRS (via :class:`ModSecurityExporter`)

        Returns
        -------
        list[str]
            List of rule strings, each annotated with a ``source_finding``
            comment block for traceability.  Duplicates across findings are
            coalesced automatically based on normalised content comparison.

        Raises
        ------
        ValueError
            If *output_format* is not one of the supported formats.

        Example
        -------
        >>> from waf_rule_generator import VulnFinding, RuleGenerator, FindingSeverity
        >>> f = VulnFinding(
        ...     name="SQL Injection",
        ...     severity=FindingSeverity.HIGH,
        ...     payload="' OR 1=1--",
        ... )
        >>> gen = RuleGenerator()
        >>> rules = gen.generate_all_findings([f], "cloudflare")
        >>> len(rules) >= 0  # at least one rule block is produced.
        True
        """
        if output_format not in self.SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported format '{output_format}'. "
                f"Choose from {self.SUPPORTED_FORMATS}"
            )

        all_rules: List[str] = []
        seen_normalised: Set[str] = set()

        for finding in findings_list:
            # Apply severity filter.
            if (
                self._min_sev >= 0
                and self.SEVERITY_ORDER.get(finding.severity, 0) < self._min_sev
            ):
                continue

            fmt_rules = self._rules_for_finding(finding, output_format)
            for raw_rule in fmt_rules:
                norm = _normalise_pattern(raw_rule)
                if norm not in seen_normalised:
                    seen_normalised.add(norm)
                    all_rules.append(raw_rule)

        return all_rules

    def _rules_for_finding(
        self,
        finding: VulnFinding,
        output_format: str,
    ) -> List[str]:
        """Return a list of raw rule strings for a single finding.

        The base implementation dispatches to the appropriate exporter class
        for the requested format and lets that subclass handle all formatting.

        Parameters
        ----------
        finding : VulnFinding
            The vulnerability finding to produce rules for.
        output_format : str
            Target WAF rule format identifier.

        Returns
        -------
        list[str]
            Raw rule strings with ``source_finding`` annotation comments.
        """
        exporters: dict[str, type] = {
            "irule": F5IRuleExporter,
            "cloudflare": CloudflareWafRuleExporter,
            "modsecurity": ModSecurityExporter,
        }
        exporter_cls = exporters[output_format]
        exporter = exporter_cls(finding)
        return exporter.export()


# ===================================================================
# Abstract base for format exporters
# ===================================================================

class WafRuleExporter:
    """Abstract base class for WAF-format rule exporters.

    Concrete subclasses implement ``_format_rule`` and optionally
    ``_signature_patterns`` to customise detection behaviour per vulnerability
    type.  Every exported rule is tagged with a comment containing the source
    finding reference.
    """

    def __init__(self, finding: VulnFinding) -> None:
        self.finding = finding
        self.canonical_type: str = re.sub(
            r"[^a-z0-9]+", "-", finding.waf_tag.lower()
        ).strip("-") or "general"

    def export(self) -> List[str]:
        """Return a list of WAF rule strings for the attached finding.

        Override in subclasses to define format-specific rule generation logic.

        Returns
        -------
        list[str]
            One or more rule strings annotated with source-finding comments.
        """
        raise NotImplementedError("Subclasses must implement export()")

    def _comment_header(self, finding: VulnFinding) -> str:
        """Return a multi-line comment block describing the rule's origin.

        The header is prepended to every generated rule so that downstream
        operators can trace which scan finding triggered each WAF rule.
        """
        lines = [
            "# " + "=" * 70,
            f"# Rule for: {finding.name}",
            f"# Severity: {finding.severity.value.upper()}",
            f"# WAF Tag: {finding.waf_tag}",
            f"# CWE: {finding.cwe_id or 'N/A'}",
            f"# Source Finding: {finding.source_finding_ref}",
            "# " + "=" * 70,
        ]
        return "\n".join(lines)


# ===================================================================
# F5 BIG-IP iRule exporter
# ===================================================================

class F5IRuleExporter(WafRuleExporter):
    """Generate F5 BIG-IP iRule WAF rules from scan findings.

    Produces syntactically valid iRule blocks that inspect HTTP request URI,
    query string, and common attack headers.  Each rule block includes a
    ``source_finding`` comment linking back to the originating scan finding.

    Rules with severity ``CRITICAL`` or ``HIGH`` generate blocking rules
    (``HTTP::respond 403``).  Lower-severity findings produce logging-only
    rules by default to avoid false-positive blocks against legitimate traffic.

    Example output (SQLi)
    ---------------------
    .. code-block:: tcl

        # ======================================================================
        # Rule for: SQL Injection
        # Severity: CRITICAL
        # WAF Tag: sql-injection
        # Source Finding: finding:SQL Injection | url:/api/users?id=1
        # ======================================================================
        when HTTP_REQUEST {
            if { [string tolower [HTTP::uri]] contains "' or 1=1" } {
                HTTP::respond 403 -content "Access Denied"
                log local0. "[WAF-F5] Blocked SQL Injection on [HTTP::uri]"
            }
        }
    """

    _HEADER_FIELDS: tuple[str, str, ...] = (
        "User-Agent",
        "X-Forwarded-For",
        "Referer",
    )

    def export(self) -> List[str]:
        """Generate F5 iRule blocks for the attached finding.

        Rules are produced for:

        1. The request URI when a *url* is known on the finding.
        2. The request payload when a *payload* is known.
        3. Common attack headers (User-Agent, X-Forwarded-For, Referer).

        Returns
        -------
        list[str]
            One or more iRule blocks with source-finding comment annotations.
        """
        rules: List[str] = []
        block_tag = f"BLOCK_{self._safe_id()}"
        header = self._comment_header(self.finding)

        # URI-based detection rule (conservative: exact substring match).
        if self.finding.url:
            escaped_path = self._escape_for_tcl(self.finding.url)
            severity_action = self._severity_action(block_tag)
            rules.append(
                f"{header}\n"
                f'when HTTP_REQUEST {{\n'
                f'    if {{ [string tolower [HTTP::uri]] contains "{escaped_path}" }} {{\n'
                f"        {severity_action}\n"
                f"        log local0. \"[{block_tag}] Suspicious URI: [HTTP::uri]\"\n"
                f"    }}\n"
                f"}}\n"
            )

        # Payload-based detection rule.
        if self.finding.payload:
            escaped_payload = self._escape_for_tcl(self.finding.payload)
            severity_action = self._severity_action(block_tag)
            rules.append(
                f"{header}\n"
                f'when HTTP_REQUEST {{\n'
                f'    foreach param {{ [URI::query [HTTP::uri]] }} {{\n'
                f'        if {{ [string tolower $param] contains "{escaped_payload}" }} {{\n'
                f"            {severity_action}\n"
                f'            log local0. "[{block_tag}] Payload in param: $param"\n'
                f"        }}\n"
                f"    }}\n"
                f"}}\n"
            )

        # Header-level detection rules for common attack vectors.
        for hdr in self._HEADER_FIELDS:
            rules.append(self._make_header_rule(hdr, block_tag))

        return rules if rules else [self._fallback_iRule(header)]

    # -- internal helpers ---------------------------------------------------

    def _safe_id(self) -> str:
        """Create a short uppercase identifier from the finding name."""
        raw = re.sub(r"[^a-zA-Z0-9]", "", self.finding.name).upper() or "GEN"
        suffix = hashlib.md5(self.finding.name.encode()).hexdigest()[:8].upper()
        return f"{raw}_{suffix}"

    def _severity_action(self, block_tag: str) -> str:
        """Return the iRule action string appropriate for the finding severity.

        *CRITICAL* and *HIGH* findings produce a 403 response (blocking).
        Lower severities only log -- this conservative choice prevents false
        positives from disrupting legitimate user traffic.
        """
        if self.finding.severity in (FindingSeverity.CRITICAL, FindingSeverity.HIGH):
            return 'HTTP::respond 403 -content "Access Denied"'
        # MEDIUM / LOW / INFO: log-only -- do not block to avoid FP risk.
        return f'log local0. "[{block_tag}] Low-severity match logged for review"'

    def _escape_for_tcl(self, text: str) -> str:
        """Escape a string for safe inclusion in a Tcl / iRule double-quoted literal."""
        escaped = text.replace("\\", "\\\\")
        escaped = escaped.replace('"', '\\"')
        escaped = escaped.replace("$", "\\$")
        return escaped

    def _make_header_rule(
        self, header_name: str, block_tag: str
    ) -> str:
        """Create an iRule rule that inspects *header_name* for attack patterns."""
        # Use the finding's payload as the inspection target when available;
        # otherwise fall back to a lightweight heuristic based on waf_tag.
        if self.finding.payload:
            search_text = self.finding.payload
        elif self.finding.param:
            search_text = self.finding.param
        else:
            return ""  # nothing useful to match on this header.

        escaped = self._escape_for_tcl(search_text)
        severity_action = self._severity_action(block_tag)
        header = self._comment_header(self.finding)

        return (
            f"{header}\n"
            f'when HTTP_REQUEST {{\n'
            f'    set hdr_val [HTTP::header value "{header_name}"]\n'
            f'    if {{ [string tolower $hdr_val] contains "{escaped}" }} {{\n'
            f"        {severity_action}\n"
            f'        log local0. "[{block_tag}] Suspicious {header_name}: $hdr_val"\n'
            f"    }}\n"
            f"}}\n"
        )

    def _fallback_iRule(self, header: str) -> str:
        """Return a no-op catch-all iRule when no meaningful pattern exists."""
        return (
            f"{header}\n"
            "# WARNING: Fallback rule — review and replace with actual logic.\n"
            "when HTTP_REQUEST {\n"
            "    log local0. \"[WAF-F5-FALLBACK] No detection patterns for this finding\"\n"
            "}\n"
        )


# ===================================================================
# Cloudflare WAF rule exporter
# ===================================================================

class CloudflareWafRuleExporter(WafRuleExporter):
    """Generate Cloudflare WAF rules in JSON format from scan findings.

    Each finding is translated into one or more Cloudflare Rule objects
    describing an ``action`` (block / allow / js_challenge), a filter
    ``expression``, and metadata that includes the ``source_finding``
    provenance string.  Rules are serialised to indented JSON suitable for
    direct import via the Cloudflare Dashboard or API.

    Example output (SQLi)
    ---------------------
    .. code-block:: json

        {
          "paused": false,
          "expression": "http.uri contains \"' OR 1=1--\"",
          "description": "WAF Rule for SQL Injection (CRITICAL) -- Source Finding: finding:SQL Injection | url:/api/users?id=1",
          "action": "block",
          "status": "deployed",
          "metadata": {
            "source_finding": "finding:SQL Injection | url:/api/users?id=1",
            "severity": "critical",
            "waf_tag": "sql-injection",
            "cwe_id": "CWE-89"
          }
        }
    """

    _ACTION_MAP: dict[FindingSeverity, str] = {
        FindingSeverity.CRITICAL: "block",
        FindingSeverity.HIGH: "block",
        FindingSeverity.MEDIUM: "js_challenge",
        FindingSeverity.LOW: "log",
        FindingSeverity.INFO: "log",
    }

    def export(self) -> List[str]:
        """Generate Cloudflare WAF rule JSON objects for the attached finding.

        Returns
        -------
        list[str]
            One or more JSON strings describing Cloudflare WAF rules with
            source-finding metadata annotations.
        """
        rules: List[dict] = []
        action = self._ACTION_MAP.get(self.finding.severity, "log")
        header = self._comment_header(self.finding)

        # Rule targeting the URI path (when a URL is known).
        if self.finding.url:
            safe_expr = self._escape_cf_expression(self.finding.url)
            rules.append(
                self._build_rule(
                    action=action,
                    expression=safe_expr,
                    ref_id="uri-path",
                )
            )

        # Rule targeting the query string / arguments (when a payload is known).
        if self.finding.payload:
            safe_expr = self._escape_cf_expression(self.finding.payload)
            rules.append(
                self._build_rule(
                    action=action,
                    expression=safe_expr,
                    ref_id="query-payload",
                )
            )

        # Rule targeting named parameter (when param is known but payload isn't).
        if self.finding.param and not self.finding.payload:
            safe_expr = self._escape_cf_expression(self.finding.param)
            rules.append(
                self._build_rule(
                    action=action,
                    expression=safe_expr,
                    ref_id="param-name",
                )
            )

        if not rules:
            rules.append(self._fallback_json(action))

        # Serialise to JSON strings.
        return [json.dumps(rule, indent=2) for rule in rules]

    # -- internal helpers ---------------------------------------------------

    def _escape_cf_expression(self, text: str) -> str:
        """Escape *text* for safe inclusion inside a Cloudflare filter expression string."""
        escaped = text.replace("\\", "\\\\")
        escaped = escaped.replace('"', '\\"')
        return escaped

    def _build_rule(
        self, action: str, expression: str, ref_id: str
    ) -> dict:
        """Construct a single Cloudflare WAF rule dictionary.

        Parameters
        ----------
        action : str
            WAF action (``"block"``, ``"allow"``, ``"js_challenge"``, ``"log"``).
        expression : str
            Cloudflare filter expression string.
        ref_id : str
            Internal reference identifier for this rule variant.

        Returns
        -------
        dict
            Rule dictionary ready for JSON serialisation.
        """
        description_lines = [
            f"WAF Rule for {self.finding.name} ({self.finding.severity.value.upper()})",
            f"Source Finding: {self.finding.source_finding_ref}",
        ]

        return {
            "paused": False,
            "expression": expression,
            "description": " | ".join(description_lines),
            "action": action,
            "status": "deployed",
            "metadata": {
                "source_finding": self.finding.source_finding_ref,
                "severity": self.finding.severity.value,
                "waf_tag": self.finding.waf_tag,
                "cwe_id": self.finding.cwe_id,
                "rule_ref_id": ref_id,
            },
        }

    def _fallback_json(self, action: str = "log") -> dict:
        """Return a placeholder rule when no meaningful expression could be built.

        The fallback is deliberately non-blocking (``pass`` action) to avoid
        false-positive interference with legitimate traffic.
        """
        return {
            "paused": False,
            "expression": 'http.request.method == "GET"',
            "description": f"Placeholder rule for {self.finding.name} — review required",
            "action": "pass",
            "status": "draft",
            "metadata": {
                "source_finding": self.finding.source_finding_ref,
                "severity": self.finding.severity.value,
                "waf_tag": self.finding.waf_tag,
                "rule_ref_id": "placeholder",
            },
        }


# ===================================================================
# ModSecurity / OWASP CRS exporter
# ===================================================================

class ModSecurityExporter(WafRuleExporter):
    """Generate Apache mod_security rules in OWASP CRS format from findings.

    Each finding produces one or more ``SecRule`` directives compatible with the
    OWASP Core Rule Set (CRS) naming conventions and severity model.  Rules
    inspect ``ARGS|REQUEST_URI`` by default and carry tags following the
    ``owasp_crs/<CATEGORY>`` convention.

    **Conservative behaviour** — rules with MEDIUM, LOW, or INFO severity use
    a ``pass`` action (log only) rather than ``deny`` to avoid false-positive
    blocks against legitimate requests.

    Example output (SQLi)
    ---------------------
    .. code-block:: apache

        # ======================================================================
        # Rule for: SQL Injection
        # Severity: CRITICAL
        # WAF Tag: sql-injection
        # Source Finding: finding:SQL Injection | param:id
        # ======================================================================
        SecRule ARGS|REQUEST_URI "@rx '(?:%27|%22)'" \
            "id:204831,\\\
             phase:2,\\\
             deny,status:403,\\\
             severity:'CRITICAL',\\\
             msg:'WAF-BLOCKED: SQL Injection detected',\\\
             tag:'owasp_crs/INJECTION_SQL',\\\
             logdata:'Matched Data: %{matched_var}'"

    See also :doc:`modsecurity` and :doc:`owasp-crs` for syntax reference.
    """

    _MODSEC_SEVERITY_MAP: dict[FindingSeverity, str] = {
        FindingSeverity.CRITICAL: "CRITICAL",
        FindingSeverity.HIGH: "ERROR",
        FindingSeverity.MEDIUM: "WARNING",
        FindingSeverity.LOW: "NOTICE",
        FindingSeverity.INFO: "INFO",
    }

    _ACTION_MAP: dict[FindingSeverity, str] = {
        FindingSeverity.CRITICAL: "deny,status:403",
        FindingSeverity.HIGH: "deny,status:403",
        FindingSeverity.MEDIUM: "pass",
        FindingSeverity.LOW: "pass",
        FindingSeverity.INFO: "pass",
    }

    def export(self) -> List[str]:
        """Generate mod_security ``SecRule`` directives for the attached finding.

        Rules are produced for:

        1. The raw payload (escaped as a PCRE pattern against ``ARGS|REQUEST_URI``).
        2. Each heuristic signature pattern from the module-level ``_SIGNATURE_MAP``
           that matches the finding's vuln type (capped at three patterns to keep
           rules concise and reduce FP risk).

        Returns
        -------
        list[str]
            One or more ``SecRule`` blocks with source-finding comment headers.
        """
        rules: List[str] = []
        severity_label = self._MODSEC_SEVERITY_MAP.get(
            self.finding.severity, "WARNING"
        )
        vuln_tag = self._tag_category()

        if self.finding.payload:
            rules.append(
                self._make_rule(
                    pattern=self._escape_for_modsec(self.finding.payload),
                    label=f"WAF-BLOCKED: {self.finding.name} detected",
                    severity=severity_label,
                    action="deny,status:403"
                    if self.finding.severity in (FindingSeverity.CRITICAL, FindingSeverity.HIGH)
                    else "pass",
                    ref_id="payload-match",
                )
            )

        # Heuristic signature patterns for the finding's vuln type.
        for idx, pat in enumerate(_SIGNATURE_MAP.get(self.canonical_type, [])[:3]):
            rules.append(
                self._make_rule(
                    pattern=pat,
                    label=f"WAF-BLOCKED: {self.finding.name} (signature-based)",
                    severity=severity_label,
                    action="deny,status:403"
                    if self.finding.severity in (FindingSeverity.CRITICAL, FindingSeverity.HIGH)
                    else "pass",
                    ref_id=f"sig-{idx}",
                )
            )

        if not rules:
            rules.append(self._fallback_modsec(severity_label))

        return rules

    # -- internal helpers ---------------------------------------------------

    def _tag_category(self) -> str:
        """Map the canonical vuln type to an OWASP CRS-style tag category."""
        mapping = {
            "sqli": "INJECTION_SQL",
            "xss": "INJECTION_XSS",
            "path-traversal": "LFI",
            "ssrf": "SSRF",
            "command-injection": "RCE",
        }
        return mapping.get(self.canonical_type, "GENERAL")

    def _escape_for_modsec(self, text: str) -> str:
        """Escape *text* for safe inclusion in a ModSecurity ``@rx`` PCRE pattern.

        Uses :func:`re.escape` to neutralise all regex metacharacters, then
        normalises the double-escaped backslash that Python 3.7+ adds when the
        input already contains literal backslashes.
        """
        return re.escape(text).replace("\\\\", "\\\\")

    def _make_rule(
        self,
        pattern: str,
        label: str,
        severity: str,
        action: str,
        ref_id: str,
    ) -> str:
        """Build a single ``SecRule`` directive string.

        Parameters
        ----------
        pattern : str
            PCRE regex pattern (already escaped) to place inside ``@rx (...)``.
        label : str
            Human-readable message included in the rule's ``msg`` field.
        severity : str
            OWASP CRS numeric severity (e.g. ``"CRITICAL"``, ``"ERROR"``, ``"WARNING"``).
        action : str
            ModSecurity action chain (e.g. ``"deny,status:403"`` or ``"pass"``).
        ref_id : str
            Internal reference identifier for this rule variant.

        Returns
        -------
        str
            A complete ``SecRule`` directive with comment header and provenance.
        """
        header = self._comment_header(self.finding)
        vuln_tag = f"owasp_crs/{self._tag_category()}"

        # Build a stable numeric rule id from the finding's payload hash.
        raw_id_input = (
            self.finding.name + self.finding.payload + self.finding.waf_tag
        ).encode()
        rule_id = 20_000 + int(hashlib.md5(raw_id_input).hexdigest(), 16) % 80_000

        return (
            f"{header}\n"
            f'SecRule ARGS|REQUEST_URI "@rx {pattern}" \\\n'
            f'    "id:{rule_id},\\\n'
            f'     phase:2,\\\n'
            f"     {action},\\\n"
            f"     severity:'{severity}',\\\n"
            f"     msg:'{label}',\\\n"
            f"     tag:'{vuln_tag}',\\\n"
            f"     logdata:'Matched Data: %{{matched_var}}'"
        )

    def _fallback_modsec(self, severity: str) -> str:
        """Return a no-op ``SecRule`` when no meaningful pattern could be built.

        The fallback uses ``pass`` (never ``deny``) to guarantee zero false-positive
        risk.  It includes a comment directing the operator to review and replace.
        """
        raw_id_input = (self.finding.name + self.finding.waf_tag).encode()
        rule_id = 20_000 + int(hashlib.md5(raw_id_input).hexdigest(), 16) % 80_000

        return (
            "# WARNING: Fallback rule — review and replace with actual detection logic.\n"
            f"# Source Finding: {self.finding.source_finding_ref}\n"
            f'SecRule ARGS|REQUEST_URI "@rx ." \\\n'
            f'    "id:{rule_id},\\\n'
            f'     phase:2,\\\n'
            f'     pass,\\\n'
            f"     severity:'{severity}',\\\n"
            f"     msg:'[MODSEC-PLACEHOLDER] Review and replace rule for {self.finding.name}'\""
        )


# ===================================================================
# Module-level vulnerability signature map
# ===================================================================

_SIGNATURE_MAP: dict[str, list[str]] = {
    "sqli": [
        r"'(?:\s*(?:OR|AND)\s*'){1}\s*\d+\s*=\s*\d+",
        r"(?:UNION\s+(?:ALL\s+)?SELECT)",
        r"(\bSELECT\b.*\bFROM\b)",
        r"(\bINSERT\b\s+\bINTO\b)",
        r"(\bDELETE\b\s+\bFROM\b)",
        r"(\bDROP\s+TABLE\b)",
        r"(?:;\s*(?:DROP|ALTER|CREATE)\b)",
    ],
    "xss": [
        r"<script[^>]*>",
        r"(?:javascript\s*:)",
        r"(?:on(?:load|error|click|mouseover)\s*=)",
        r"(?:alert\s*\()",
    ],
    "path-traversal": [
        r"(?:\.\./)",
        r"(?:\.\.\\\\)",
        r"(?:%2e%2e[/\\])",
        r"(/etc/passwd)",
        r"(/etc/shadow)",
        r"(c:\\\\windows)",
    ],
    "ssrf": [
        r"(?:localhost|127\.0\.0\.1|0\.0\.0\.0)",
        r"(169\.254\.169\.254)",
        r"(metadata\.google",
        r"(internal-metadata",
    ],
    "command-injection": [
        r"(\b(?:exec|eval|system|passthru|shell_exec|popen)\s*\()",
        r"(\|\s*(?:cat|ls|id|whoami|wget|curl|bash|sh)\b)",
        r"(;\s*(?:rm|chmod|chown|kill)\b)",
    ],
}


# ===================================================================
# Convenience entry-point
# ===================================================================

def generate_waf_rules(
    findings: Iterable[VulnFinding],
    output_format: str = "modsecurity",
) -> List[str]:
    """One-liner convenience wrapper around :class:`RuleGenerator.generate_all_findings`.

    Parameters
    ----------
    findings : iterable of VulnFinding
        Scan results to convert.
    output_format : str
        Destination WAF format.  One of ``"irule"``, ``"cloudflare"``, or
        ``"modsecurity"`` (default: ``"modsecurity"``).

    Returns
    -------
    list[str]
        Generated WAF rule strings, each annotated with source-finding comments.

    Example
    -------
    >>> from waf_rule_generator import VulnFinding, generate_waf_rules, FindingSeverity
    >>> findings = [
    ...     VulnFinding(
    ...         name="SQL Injection",
    ...         severity=FindingSeverity.HIGH,
    ...         payload="' OR 1=1--",
    ...     ),
    ... ]
    >>> rules = generate_waf_rules(findings, "cloudflare")
    >>> len(rules) >= 0
    True
    """
    generator = RuleGenerator()
    return generator.generate_all_findings(findings, output_format=output_format)


# ===================================================================
# Public API
# ===================================================================

__all__: list[str] = [
    "VulnFinding",
    "RuleGenerator",
    "WafRuleExporter",
    "F5IRuleExporter",
    "CloudflareWafRuleExporter",
    "ModSecurityExporter",
    "generate_waf_rules",
    "deduplicate_patterns",
    "FindingSeverity",
]
