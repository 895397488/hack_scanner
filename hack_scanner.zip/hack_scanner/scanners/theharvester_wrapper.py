#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
theHarvester Wrapper — theHarvester CLI wrapper，OSINT 公开情报收集。

osint_recon.py 的直接扩展点：补充 邮箱 / hostname / 子域 / 图片 / PDF
从搜索引擎（Google/Bing/DuckDuckGo/Pastebin/Shodan 等）的被动收集。

集成方式：需要安装 theHarvester
  - pip install "theHarvester @ git+https://github.com/laramies/theHarvester@4.11.1"
    (推荐；注意 PyPI 上仅有 0.0.1，4.x 系列只在 GitHub 发布)
  - 或 git clone https://github.com/laramies/theHarvester && pip install .
本模块只负责 CLI 调用和结果解析。config.json → tools.theharvester_path 可指定路径。

Usage:
    from scanners.theharvester_wrapper import theharvester_recon
    result = theharvester_recon("example.com")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('theharvester_scanner')


def _find_theharvester() -> Optional[str]:
    """查找 theHarvester 可执行文件：先 config.json → tools.theharvester_path，再 PATH"""
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("theharvester_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    for name in ["theHarvester", "theharvester", "theHarvester.exe", "theharvester.exe", "theHarvester.py"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def theharvester_recon(domain: str, sources: str = "", max_time: int = 300) -> dict:
    """运行 theHarvester OSINT 收集。

    Args:
        domain:  目标域名
        sources: 指定来源（空=全部；如 google,bing,pastebin,shodan）
        max_time: 最大运行时间秒

    Returns:
        {"ok": bool, "emails": [...], "hostnames": [...], "subdomains": [...],
         "pdfs": [...], "error": ...}
    """
    if not domain:
        return {"ok": False, "emails": [], "hostnames": [], "subdomains": [], "pdfs": [], "error": "缺少域名参数"}

    th = _find_theharvester()
    if not th:
        return {"ok": False, "emails": [], "hostnames": [], "subdomains": [], "pdfs": [],
                "error": "theHarvester 未找到，请安装: pip install \"theHarvester @ git+https://github.com/laramies/theHarvester@4.11.1\"（PyPI 仅有 0.0.1）"}

    cmd = [th, "-d", domain]
    if sources:
        # 4.x 中来源列表参数为 -b（-s 已变为 "Use Shodan" 布尔开关）
        cmd.extend(["-b", sources])
    # -l 限制每来源返回数（避免超时）
    # 注意: 4.x 中 -n=开启DNS查询、-f=把报告写成 <name>.json/.xml 文件到当前目录，
    # 两者均非旧版含义，故不使用；结果直接从 stdout 解析
    cmd.extend(["-l", "200"])
    logger.info(f"theHarvester: {domain} (sources={sources or 'all'})")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time)
        raw = (proc.stdout or "") + "\n" + (proc.stderr or "")

        # theHarvester -f json 输出为 dict: {"<domain>": {"emails": [...], "hostnames": [...]}}
        data = None
        brace = raw.find("{")
        if brace >= 0:
            try:
                data = json.loads(raw[brace:])
            except json.JSONDecodeError:
                data = None

        if isinstance(data, dict):
            # 取第一个域名 key
            for dkey, val in data.items():
                if isinstance(val, dict):
                    return {
                        "ok": True,
                        "domain": domain,
                        "emails": val.get("emails", [])[:500],
                        "hostnames": val.get("hostnames", [])[:500],
                        "subdomains": val.get("subdomains", val.get("hostnames", []))[:500],
                        "pdfs": val.get("pdfs", [])[:100],
                        "error": "",
                    }

        # JSON 解析失败时回退正则提取
        emails = sorted(set(re.findall(r'[\w.+-]+@[\w-]+\.[\w.-]+', raw)))
        hostnames = sorted(set(re.findall(r'\b(?:[a-z0-9-]+\.)+' + re.escape(domain.split('.')[-1]) + r'\b', raw.lower())))
        return {
            "ok": True,
            "domain": domain,
            "emails": emails[:500],
            "hostnames": hostnames[:500],
            "subdomains": hostnames[:500],
            "pdfs": [],
            "error": "theHarvester JSON 输出解析失败，已回退正则提取",
        }
    except subprocess.TimeoutExpired:
        return {"ok": False, "emails": [], "hostnames": [], "subdomains": [], "pdfs": [], "error": "theHarvester 超时"}
