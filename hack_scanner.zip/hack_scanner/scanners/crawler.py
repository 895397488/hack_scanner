#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DeepScan Crawler -- recursive web crawler engine modeled after Acunetix DeepScan.

Three crawling modes:
  HTTP-only (default), Selenium, Playwright.

Core capabilities:
  - Recursive URL discovery with depth-first traversal
  - Domain scope enforcement via public_suffix_list.dat
  - Robots.txt compliance
  - SPA framework detection + XHR/Fetch interception
  - Form extraction and structure parsing
  - Technology stack fingerprinting
  - Rate limiting to prevent DoS

Usage:
    from scanners.crawler import DeepScanCrawler, CrawlConfig

    config = CrawlConfig(target_url="https://example.com", max_depth=3, max_pages=50)
    crawler = DeepScanCrawler(config=config, engine='http')
    result = await crawler.crawl()
"""

import asyncio
import logging
import os
import re
import socket
import time
import urllib.robotparser
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger('crawler')

# ---- optional deps ----
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options as SeleniumChromeOptions
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    HAS_SELENIUM = True
except ImportError:
    HAS_SELENIUM = False

try:
    import playwright.async_api as playwright_async  # noqa: F401
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False

# ---- TLD data path ----
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_TLD_PATH = os.path.join(_BASE_DIR, '..', 'data', 'tld', 'public_suffix_list.dat')


# ====================================================================
# Data classes
# ====================================================================

@dataclass
class CrawlConfig:
    """Crawler configuration."""
    target_url: str
    max_depth: int = 3
    max_pages: int = 100
    follow_redirects: bool = True
    domain_scope: Optional[str] = None
    exclude_patterns: List[str] = field(default_factory=lambda: [
        r'\.(jpg|jpeg|png|gif|webp|svg|ico|pdf|zip|tar\.gz|css)(\?.*)?$',
        r'^javascript:',
        r'^mailto:',
        r'^tel:',
        r'^#',
    ])
    include_scripts: List[str] = field(default_factory=list)
    timeout: int = 30
    concurrent_workers: int = 5
    rate_limit_sec: float = 1.0
    user_agent: str = (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    )
    respect_robots: bool = True


@dataclass
class CrawlResult:
    """Single-page crawl result."""
    url: str
    status_code: int = 0
    content_type: str = ''
    title: str = ''
    links_found: List[str] = field(default_factory=list)
    forms_found: List[Dict[str, Any]] = field(default_factory=list)
    ajax_calls: List[Dict[str, Any]] = field(default_factory=list)
    scripts: List[str] = field(default_factory=list)
    meta_tags: Dict[str, str] = field(default_factory=dict)
    technologies: Dict[str, str] = field(default_factory=dict)
    html_length: int = 0
    error: Optional[str] = None


# ====================================================================
# Public suffix list parser
# ====================================================================

def _load_psl(path: str = _TLD_PATH) -> List[str]:
    """Load public_suffix_list.dat and return valid suffix rules."""
    rules: List[str] = []
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith('//'):
                    continue
                rules.append(line)
    except FileNotFoundError:
        logger.warning("public_suffix_list.dat not found at %s", path)
    return rules


def _registrable_domain(url: str, psl_rules: List[str]) -> Optional[str]:
    """Extract registrable domain (e.g. www.example.co.uk -> example.co.uk)."""
    parsed = urlparse(url)
    hostname = parsed.hostname or ''
    parts = hostname.split('.')
    if len(parts) < 2:
        return None

    best = '.'.join(parts[-2:])  # fallback: last two parts
    for rule in psl_rules:
        if rule.startswith('*.'):
            base = rule[2:]
            if hostname.endswith('.' + base) and len(parts) >= base.count('.') + 2:
                best = '.'.join(parts[-(base.count('.') + 2):])
        elif rule.startswith('!'):
            continue
        else:
            suffix_parts = rule.split('.')
            n = len(suffix_parts) + 1
            if len(parts) >= n:
                candidate = '.'.join(parts[-n:])
                best = candidate
    return best


# ====================================================================
# Robots.txt cache
# ====================================================================

class _RobotsCache:
    """Singleton cache for robots.txt parsing."""

    def __init__(self):
        self._cache: Dict[str, urllib.robotparser.RobotFileParser] = {}

    def can_fetch(self, url: str, ua: str = '*') -> bool:
        parsed = urlparse(url)
        robots_url = f'{parsed.scheme}://{parsed.netloc}/robots.txt'
        if robots_url not in self._cache:
            rp = urllib.robotparser.RobotFileParser()
            try:
                resp = requests.get(robots_url, timeout=5, headers={'User-Agent': ua})
                if resp.status_code == 200:
                    rp.parse(resp.text.splitlines())
                else:
                    rp.set_url(robots_url)
                    rp.read()
            except Exception:
                rp = urllib.robotparser.RobotFileParser()
            self._cache[robots_url] = rp
        return self._cache[robots_url].can_fetch(ua, url)


ROBOTS_CACHE = _RobotsCache()


# ====================================================================
# DeepScan Crawler -- main class
# ====================================================================

class DeepScanCrawler:
    """Recursive web-site crawler engine (DeepScan-style)."""

    def __init__(self, config: Optional[CrawlConfig] = None, engine: str = 'http'):
        self.config = config or CrawlConfig(target_url='https://example.com')
        if not self.config.target_url.startswith(('http://', 'https://')):
            self.config.target_url = 'https://' + self.config.target_url

        # Resolve engine
        eng = engine.lower()
        if eng == 'selenium' and not HAS_SELENIUM:
            logger.warning('Selenium unavailable, falling back to HTTP-only')
            eng = 'http'
        elif eng == 'playwright' and not HAS_PLAYWRIGHT:
            logger.warning('Playwright unavailable, falling back to Selenium/HTTP')
            eng = 'selenium' if HAS_SELENIUM else 'http'
        self._engine = eng

        # State
        self._rate_limit: Dict[str, float] = {}
        self._visited_urls: Set[str] = set()
        self._pending: deque = deque()

        # Results
        self._results: List[CrawlResult] = []
        self._all_links: Set[str] = set()
        self._all_forms: List[Dict[str, Any]] = []
        self._techs: Dict[str, str] = {}
        self._errors: List[str] = []

        # Domain scope
        psl_rules = _load_psl()
        raw_scope = self.config.domain_scope or urlparse(self.config.target_url).hostname or ''
        self._reg_domain = _registrable_domain(f'http://{raw_scope}', psl_rules)
        logger.info(
            'Crawler scope: reg_domain=%s engine=%s max_depth=%d max_pages=%d',
            self._reg_domain, self._engine,
            self.config.max_depth, self.config.max_pages,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def crawl(self) -> Dict[str, Any]:
        """Execute full recursive crawl and return results."""
        t0 = time.time()
        try:
            if self._engine == 'http':
                await self._crawl_http()
            else:
                await self._crawl_browser()
        except Exception as exc:
            self._errors.append(f'Crawl error: {exc}')

        elapsed = round(time.time() - t0, 2)
        status = 'success' if self._results else 'failed'
        return {
            'visited': sorted(self._visited_urls),
            'results': [self._result_to_dict(r) for r in self._results],
            'forms': self._all_forms,
            'links': sorted(self._all_links),
            'technologies': self._techs,
            'total_time': elapsed,
            'errors': self._errors,
            'status': status,
        }

    # ------------------------------------------------------------------
    # HTTP crawling mode
    # ------------------------------------------------------------------

    async def _crawl_http(self):
        """HTTP-only recursive crawl with concurrency."""
        executor = ThreadPoolExecutor(max_workers=self.config.concurrent_workers)
        loop = asyncio.get_event_loop()

        while self._pending and len(self._visited_urls) < self.config.max_pages:
            url, depth = self._pending.popleft()
            if url in self._visited_urls or depth > self.config.max_depth:
                continue

            await self._throttle(url)

            future = loop.run_in_executor(executor, self._fetch_page, url)
            result = await future  # CrawlResult

            if result.error:
                self._errors.append(f'{url}: {result.error}')
                continue

            self._visited_urls.add(url)
            self._results.append(result)
            self._merge_techs(result.technologies)
            self._all_forms.extend(result.forms_found)

            new_links = []
            for href in result.links_found:
                abs_url = urljoin(url, href)
                if not abs_url.startswith(('http://', 'https://')):
                    continue
                if self._is_excluded(abs_url):
                    continue
                if not self._in_scope(abs_url):
                    continue
                if abs_url in self._visited_urls:
                    continue
                new_links.append((abs_url, depth + 1))

            fanout = min(20, len(new_links))
            for link, d in new_links[:fanout]:
                self._pending.append((link, d))
                self._all_links.add(link)
            if len(new_links) > fanout:
                logger.info('%s: %d links found, queued %d (fanout limited)', url, len(new_links), fanout)

    async def _throttle(self, url: str):
        """Per-domain rate limiting."""
        netloc = urlparse(url).netloc
        now = time.time()
        last = self._rate_limit.get(netloc, 0)
        delay = max(0, self.config.rate_limit_sec - (now - last))
        if delay > 0:
            await asyncio.sleep(delay)
        self._rate_limit[netloc] = time.time()

    def _fetch_page(self, url: str) -> CrawlResult:
        """Fetch and parse a single HTTP page."""
        headers = {'User-Agent': self.config.user_agent}
        try:
            resp = requests.get(
                url, headers=headers, timeout=self.config.timeout,
                allow_redirects=self.config.follow_redirects, verify=False,
            )
            ct = resp.headers.get('Content-Type', '')
            if 'text/html' not in ct and 'application/xhtml' not in ct:
                return CrawlResult(url=url, status_code=resp.status_code,
                                   error='non-HTML content skipped')

            soup = BeautifulSoup(resp.text, 'html.parser')
            title = ''
            if soup.title and soup.title.string:
                title = soup.title.string.strip()[:200]

            links = [a['href'] for a in soup.find_all('a', href=True)]
            forms = self._extract_forms(soup, url)
            scripts = [s.get('src', '') for s in soup.find_all('script', src=True)]
            meta: Dict[str, str] = {}
            for tag in soup.find_all('meta'):
                name_ = tag.get('name') or tag.get('http-equiv') or ''
                content_ = tag.get('content') or ''
                if name_ and content_:
                    meta[name_.lower()] = content_

            techs = self._fingerprint(soup, resp.headers)

            return CrawlResult(
                url=url, status_code=resp.status_code,
                content_type=ct.split(';')[0], title=title,
                links_found=links, forms_found=forms, scripts=scripts,
                meta_tags=meta, technologies=techs, html_length=len(resp.text),
            )
        except requests.RequestException as exc:
            return CrawlResult(url=url, error=f'HTTP error: {exc}')
        except socket.timeout:
            return CrawlResult(url=url, error='timeout')
        except Exception as exc:
            return CrawlResult(url=url, error=f'unknown: {exc}')

    @staticmethod
    def _extract_forms(soup: BeautifulSoup, base_url: str) -> List[Dict[str, Any]]:
        """Parse <form> elements into structured data."""
        forms = []
        for form in soup.find_all('form'):
            method_ = (form.get('method', 'GET') or 'GET').upper()
            action = urljoin(base_url, form.get('action', '') or '')
            inputs = []
            for inp in form.find_all(['input', 'select', 'textarea']):
                nm = inp.get('name', '')
                if not nm:
                    continue
                inputs.append({
                    'name': nm, 'type': inp.get('type', 'text'),
                    'value': inp.get('value', ''), 'required': inp.has_attr('required'),
                })
            forms.append({'method': method_, 'action': action, 'inputs': inputs})
        return forms

    def _fingerprint(self, soup: BeautifulSoup, headers: dict) -> Dict[str, str]:
        """Technology stack fingerprinting from HTML + HTTP headers."""
        techs: Dict[str, str] = {}
        html_body = str(soup) + ' '.join(
            s.get('src', '') for s in soup.find_all('script', src=True))

        server = (headers.get('Server') or headers.get('X-Powered-By') or '').lower()
        if 'nginx' in server:
            techs['web_server'] = 'Nginx'
        elif 'apache' in server:
            techs['web_server'] = 'Apache'
        elif 'iis' in server:
            techs['web_server'] = 'IIS'

        for kw, name in [('wp-content', 'WordPress'), ('joomla', 'Joomla'),
                          ('drupal', 'Drupal'), ('TYPO3', 'TYPO3')]:
            if kw in html_body.lower():
                techs['cms'] = name

        for kw, name in [('angular', 'Angular'), ('react-dom', 'React'),
                          ('next.js', 'Next.js'), ('nuxt', 'Nuxt')]:
            if kw in html_body.lower():
                techs['framework'] = name

        x_cache = headers.get('X-Cache', '') or headers.get('CDN-Loop', '')
        if 'cloudflare' in x_cache.lower() or 'cf-ray' in headers:
            techs['cdn'] = 'Cloudflare'
        elif 'akamai' in (headers.get('X-Akamai-ASN') or '').lower():
            techs['cdn'] = 'Akamai'

        return techs

    # ------------------------------------------------------------------
    # Browser crawling mode
    # ------------------------------------------------------------------

    async def _crawl_browser(self):
        """Browser-based recursive crawl."""
        page = None  # either Selenium WebDriver or Playwright Page
        browser = None
        pw_ctx = None

        if self._engine == 'playwright':
            from playwright.async_api import async_playwright
            pw = await async_playwright().start()
            browser = await pw.chromium.launch(headless=True)
            ctx = await browser.new_context(
                user_agent=self.config.user_agent, viewport={'width': 1920, 'height': 1080})
            page = await ctx.new_page()

            xhr_urls: List[Dict[str, Any]] = []
            async def _on_response(resp):
                if resp.request.resource_type in ('xhr', 'fetch'):
                    xhr_urls.append({
                        'url': resp.request.url, 'method': resp.request.method,
                        'status': resp.status})
            page.on('response', _on_response)

        elif HAS_SELENIUM:
            opts = SeleniumChromeOptions()
            opts.add_argument('--headless=new')
            opts.add_argument('--no-sandbox')
            opts.add_argument('--disable-dev-shm-usage')
            opts.add_argument(f'--user-agent={self.config.user_agent}')
            page = webdriver.Chrome(options=opts)

        try:
            while self._pending and len(self._visited_urls) < self.config.max_pages:
                url, depth = self._pending.popleft()
                if url in self._visited_urls or depth > self.config.max_depth:
                    continue

                await self._throttle(url)
                result = None

                if page is not None and hasattr(page, 'goto'):
                    # Playwright page
                    try:
                        await page.goto(url, wait_until='networkidle', timeout=self.config.timeout * 1000)
                        await asyncio.sleep(2)
                        raw = await page.evaluate('''() => {
                            const links = Array.from(document.querySelectorAll('a[href]')).map(a => a.href);
                            const forms = Array.from(document.querySelectorAll('form')).map(f => ({
                                method: f.method, action: f.action,
                                inputs: Array.from(f.querySelectorAll(
                                    'input[name], select[name], textarea[name]'))
                                    .map(i => ({name: i.name, type: i.type, value: i.value || ''}))}));
                            const scripts = Array.from(document.querySelectorAll('script[src]')).map(s => s.src);
                            return {links, forms, scripts, title: document.title};
                        }''')
                        result = CrawlResult(
                            url=url, title=raw.get('title', '')[:200] or '',
                            links_found=[l for l in raw.get('links', []) if l],
                            forms_found=raw.get('forms', []), scripts=raw.get('scripts', []),
                            ajax_calls=xhr_urls)
                    except Exception as exc:
                        self._errors.append(f'Playwright {url}: {exc}')

                elif page is not None and hasattr(page, 'get'):
                    # Selenium WebDriver
                    try:
                        page.get(url)
                        WebDriverWait(page, self.config.timeout).until(
                            EC.presence_of_element_located(('body', '')))
                        await asyncio.sleep(2)
                        raw = {
                            'links': [a for a in page.find_elements('css selector', 'a[href]')
                                      if (v := a.get_attribute('href'))],
                            'forms': [{'method': f.get_attribute('method') or 'GET',
                                       'action': f.get_attribute('action'),
                                       'inputs': [{'name': i.get_attribute('name'),
                                                   'type': i.get_attribute('type') or 'text'}
                                                  for i in f.find_elements(
                                                      'css selector', 'input[name],select[name],textarea[name]')]}
                                      for f in page.find_elements('css selector', 'form')],
                            'scripts': [s for s in page.find_elements('css selector', 'script[src]')
                                        if (v := s.get_attribute('src'))],
                            'title': page.title,
                        }
                        result = CrawlResult(
                            url=url, title=raw.get('title', '')[:200] or '',
                            links_found=raw.get('links', []), forms_found=raw.get('forms', []),
                            scripts=raw.get('scripts', []))
                    except Exception as exc:
                        self._errors.append(f'Selenium {url}: {exc}')

                if result is None:
                    continue

                self._visited_urls.add(url)
                self._results.append(result)
                techs = self._fingerprint(BeautifulSoup('', 'html.parser'), {})
                techs.update(self._spa_detect(raw))
                self._merge_techs(techs)
                self._all_forms.extend(result.forms_found)

                new_links: List[tuple] = []
                for href in result.links_found:
                    abs_url = urljoin(url, href)
                    if not abs_url.startswith(('http://', 'https://')):
                        continue
                    if self._is_excluded(abs_url):
                        continue
                    if not self._in_scope(abs_url):
                        continue
                    if abs_url in self._visited_urls:
                        continue
                    new_links.append((abs_url, depth + 1))

                fanout = min(20, len(new_links))
                for link, d in new_links[:fanout]:
                    self._pending.append((link, d))
                    self._all_links.add(link)

        finally:
            if hasattr(page, 'quit'):
                page.quit()
            elif browser:
                try:
                    await browser.close()
                except Exception:
                    pass

    def _spa_detect(self, raw: dict) -> Dict[str, str]:
        """Detect SPA frameworks from browser context data."""
        techs: Dict[str, str] = {}
        scripts = ' '.join(raw.get('scripts', [])).lower()
        if 'angular' in scripts or 'ng-app' in str(raw):
            techs['spa_framework'] = 'Angular'
        elif '__NEXT_DATA__' in str(raw) or 'next.js' in scripts:
            techs['spa_framework'] = 'Next.js'
        elif 'react-dom' in scripts:
            techs['spa_framework'] = 'React'
        elif '/vue.' in scripts or 'nuxt' in scripts:
            techs['spa_framework'] = 'Vue/Nuxt'
        return techs

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _is_excluded(self, url: str) -> bool:
        for pat in self.config.exclude_patterns:
            if re.search(pat, url, re.IGNORECASE):
                return True
        return False

    def _in_scope(self, url: str) -> bool:
        """Check whether URL falls within the registered domain scope."""
        parsed = urlparse(url)
        host = parsed.hostname or ''
        if not self._reg_domain:
            target_netloc = urlparse(self.config.target_url).netloc
            return host.endswith(target_netloc) or target_netloc.endswith(host)
        url_reg = _registrable_domain(f'http://{host}', _load_psl())
        return url_reg is not None and url_reg == self._reg_domain

    def _merge_techs(self, techs: Dict[str, str]):
        for k, v in techs.items():
            if k not in self._techs:
                self._techs[k] = v

    @staticmethod
    def _result_to_dict(r: CrawlResult) -> Dict[str, Any]:
        return {
            'url': r.url, 'status_code': r.status_code,
            'content_type': r.content_type, 'title': r.title,
            'links_found_count': len(r.links_found),
            'forms_found_count': len(r.forms_found),
            'technologies': r.technologies, 'html_length': r.html_length,
        }


# ====================================================================
# Convenience function
# ====================================================================

async def crawl_url(url: str, **kwargs) -> Dict[str, Any]:
    """Quick convenience crawler: ``crawl_url("https://example.com")``."""
    cfg = CrawlConfig(target_url=url, **{k: v for k, v in kwargs.items() if v is not None})
    return await DeepScanCrawler(config=cfg).crawl()
