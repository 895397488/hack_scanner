#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Amass Wrapper — amass CLI wrapper，重火力子域名枚举（OWASP 官方工具）。

与现有 subdomain_takeover + 原生子域扫描互补：amass 聚合 40+ 被动源
（VirusTotal、Shodan、Crt.sh、DuckDuckGo...）+ 主动 DNS 探测 + 字典爆破。

三种模式：
  passive — 仅被动源，零目标流量（推荐默认，安全）
  active  — 被动 + 主动 DNS 探测
  brute   — 字典暴力枚举（需 amass 配置 + 较长时间）

集成方式：需要安装 amass
  - Windows: choco install amass  或  https://github.com/owasp-amass/amass/releases
  - Linux:   手动安装（见 release 页面）
本模块只负责 CLI 调用和结果解析。config.json → tools.amass_path 可指定路径。

Usage:
    from scanners.amass_wrapper import amass_enum
    result = amass_enum("example.com", mode="passive")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('amass_scanner')


def _find_amass() -> Optional[str]:
    """查找 amass 可执行文件：先 config.json → tools.amass_path，再 PATH"""
    # 1) config.json tools.amass_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("amass_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["amass", "amass.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_amass_output(output: str, domain: str) -> list:
    """解析 amass -o general 输出（每行一个子域名）"""
    subdomains = set()
    for line in output.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("=="):
            continue
        # 子域名格式: api.example.com
        if re.match(r'^[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$', line) and line.endswith(domain):
            subdomains.add(line.lower())
    return sorted(subdomains)


def amass_enum(
    domain: str,
    mode: str = "passive",
    wordlist: str = "",
    max_time: int = 600,
) -> dict:
    """运行 amass 子域名枚举。

    Args:
        domain: 根域名（如 example.com）
        mode: passive / active / brute
        wordlist: brute 模式用的 DNS 字典（可选）
        max_time: 最大运行时间秒（brute 模式建议调大）

    Returns:
        {"ok": True, "subdomains": [...], "total": N, "error": ""}
    """
    amass_path = _find_amass()
    if not amass_path:
        return {
            "ok": False,
            "domain": domain,
            "subdomains": [],
            "total": 0,
            "error": "amass 未找到，请安装: choco install amass (Windows) 或见 https://github.com/owasp-amass/amass/releases",
        }

    if mode == "passive":
        cmd = [amass_path, "enum", "-passive", "-d", domain, "-o", "general"]
    elif mode == "active":
        cmd = [amass_path, "enum", "-active", "-d", domain, "-o", "general"]
    elif mode == "brute":
        cmd = [amass_path, "enum", "-brute", "-d", domain, "-o", "general"]
        if wordlist and os.path.isfile(wordlist):
            cmd.extend(["-wordlist", wordlist])
    else:
        return {"ok": False, "domain": domain, "subdomains": [], "total": 0,
                "error": f"未知模式: {mode}，支持 passive/active/brute"}

    logger.info(f"amass enum: {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 30)
        output = proc.stdout or proc.stderr or ""
        subdomains = _parse_amass_output(output, domain)

        return {
            "ok": True,
            "domain": domain,
            "mode": mode,
            "subdomains": subdomains[:1000],
            "total": len(subdomains),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "domain": domain, "subdomains": [], "total": 0,
                "error": f"amass 超时（最大时间 {max_time}s）"}
