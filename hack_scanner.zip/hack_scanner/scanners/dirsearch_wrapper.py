#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dirsearch Wrapper — dirsearch CLI wrapper，纯 Python 目录爆破（Windows 最易装）。

dirsearch 用 Python 实现，带 JS 模块生态（动态字典），
在 Windows 环境安装最简单（pip install dirsearch），是 gobuster/ffuf 的备用引擎。

集成方式：需要安装 dirsearch
  - Windows/Linux: pip install dirsearch
本模块只负责 CLI 调用和结果解析。config.json → tools.dirsearch_path 可指定路径。

Usage:
    from scanners.dirsearch_wrapper import dirsearch_scan
    result = dirsearch_scan("https://example.com")
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('dirsearch_scanner')


def _find_dirsearch() -> Optional[str]:
    """查找 dirsearch 可执行文件：先 config.json → tools.dirsearch_path，再 PATH"""
    # 1) config.json tools.dirsearch_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("dirsearch_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["dirsearch", "dirsearch.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def _parse_dirsearch_output(output: str, base_url: str = "") -> list:
    """解析 dirsearch 输出。

    dirsearch 关键行格式:
      /                           HTTP Status: 200, Length: 1234
      /admin/                     HTTP Status: 301, Length: 0
      !!! Interesting !!!
    也兼容 --output-json 的 JSON 行（若启用）。
    """
    findings = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue

        # JSON 行（--output-json 模式）
        if line.startswith("{"):
            try:
                entry = json.loads(line)
                if isinstance(entry, dict) and "path" in entry:
                    findings.append({
                        "path": entry.get("path", ""),
                        "url": entry.get("url", ""),
                        "status": entry.get("status", ""),
                        "size": entry.get("length", 0),
                        "severity": "medium" if entry.get("status") in ("200", "403", "401", "500") else "info",
                    })
            except json.JSONDecodeError:
                pass
            continue

        # 文本行: /path   HTTP Status: 200, Length: 1234
        m = re.match(r'^(/\S*)\s+HTTP Status:\s*(\d+)(?:,\s*Length:\s*(\d+))?', line)
        if m:
            path, status = m.group(1), m.group(2)
            size = int(m.group(3)) if m.group(3) else 0
            code = int(status)
            severity = "medium" if code in (200, 403, 401, 500) else "info"
            url = path if path.startswith("http") else f"{base_url.rstrip('/')}{path}"
            findings.append({
                "path": path,
                "url": url,
                "status": status,
                "size": size,
                "severity": severity,
            })
            continue

        # !!! Interesting !!! 标记行
        if line.startswith("!!!"):
            findings.append({
                "path": "",
                "url": base_url,
                "status": "",
                "size": 0,
                "severity": "medium",
                "interesting": True,
            })

    return findings


def dirsearch_scan(
    target: str,
    wordlist: str = "",
    extensions: str = "",
    max_time: int = 300,
) -> dict:
    """运行 dirsearch 目录爆破。

    Args:
        target: 目标 URL（如 https://example.com/）
        wordlist: 字典文件路径（不传用内置 common.txt）
        extensions: 扩展名（如 php,html,jsp）
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "findings": [...], "findings_count": N, "interesting_count": N, "error": ""}
    """
    dirsearch_path = _find_dirsearch()
    if not dirsearch_path:
        return {
            "ok": False,
            "target": target,
            "findings": [],
            "findings_count": 0,
            "error": "dirsearch 未找到，请安装: pip install dirsearch",
        }

    cmd = [
        dirsearch_path,
        "--url", target.rstrip("/"),
        "--timeout", "10",
    ]

    if wordlist and os.path.isfile(wordlist):
        cmd.extend(["--wordlist", wordlist])
    if extensions:
        cmd.extend(["--extensions", extensions])

    logger.info(f"dirsearch scan: {' '.join(cmd[:5])}...")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""
        findings = _parse_dirsearch_output(output, target)

        interesting = [f for f in findings if f.get("interesting")]
        return {
            "ok": True,
            "target": target,
            "findings": findings[:500],
            "findings_count": len(findings),
            "interesting_count": len(interesting),
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target": target, "findings": [], "findings_count": 0, "error": "dirsearch 超时"}
