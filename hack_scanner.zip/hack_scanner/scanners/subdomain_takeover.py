#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Subdomain Takeover Detector
=============================
借鉴 Pentest-Swarm-AI Phase 5.6.1 (dangling CNAME → 40+ services).
检测 DNS CNAME 指向已注销第三方服务导致的子域名接管漏洞。
"""

import re
import json
import logging
from typing import List, Dict, Optional
from urllib.parse import urlparse

logger = logging.getLogger('subdomain_takeover')

try:
    import dns.resolver
    HAS_DNS = True
except ImportError:
    HAS_DNS = False


# Dangling CNAME indicators for 40+ services
DANGLING_INDICATORS = {
    # GitHub Pages (most common)
    'cannot find server with name': ('GitHub Pages', 'high'),
    'no site at that address': ('GitHub Pages', 'high'),
    'there\'s nothing here yet': ('GitHub Pages', 'high'),

    # Shopify
    'shopifycdn': ('Shopify', 'high'),
    'myshopify.com': ('Shopify (subdomain takeover)', 'medium'),

    # Heroku
    'herokudns': ('Heroku', 'high'),
    'no-slug': ('Heroku', 'high'),
    'herokuapp.com': ('Heroku (potential takeover)', 'medium'),

    # Wix
    'wixpress': ('Wix', 'high'),
    'wixpress.com': ('Wix (dangling CNAME)', 'high'),

    # AWS S3/CloudFront
    'no such bucket': ('AWS S3', 'critical'),
    'bucket does not exist': ('AWS S3', 'critical'),
    'ensure the hostname entered is a valid domain name': ('AWS CloudFront', 'critical'),
    'cloudfront.net': ('AWS CloudFront', 'high'),

    # Azure
    'azurewebsites': ('Azure Web Apps', 'high'),
    'site not found': ('Azure', 'high'),
    'does not exist': ('Azure blob/storage', 'high'),

    # Google/G Suite
    'gsu.te': ('Google Sites', 'high'),
    'no such item': ('Google Cloud Storage', 'critical'),

    # WordPress.com
    'wordpress.com': ('WordPress.com', 'high'),
    'do you want to register': ('WordPress.com', 'high'),

    # DreamHost
    'dreamhost': ('DreamHost', 'high'),

    # Ghost
    'ghost.io': ('Ghost (dangling)', 'medium'),

    # Netlify
    'netlify.app': ('Netlify', 'high'),
    'not found': ('Netlify/General', 'medium'),

    # Pantheistic
    'pantheon.io': ('Pantheon', 'high'),

    # Firebase
    'firebaseio.com': ('Firebase (dangling CNAME)', 'high'),

    # Cloudflare Pages
    'cloudflarepages.com': ('Cloudflare Pages', 'medium'),

    # Tilda
    'tildacdn.com': ('Tilda', 'high'),

    # Distriq
    'distriq': ('Distriq', 'high'),

    # ReadTheDocs
    'readthedocs.io': ('ReadTheDocs (dangling)', 'medium'),

    # Surge.sh
    'surge.sh': ('Surge.sh', 'medium'),

    # Vercel
    'vercel.app': ('Vercel (potential takeover)', 'medium'),

    # GitBook
    'gitbook.com': ('GitBook', 'medium'),

    # Carrier
    'carrier': ('Carrier (dangling)', 'high'),
}


class SubdomainTakeoverDetector:
    """子域名接管漏洞检测器"""

    @staticmethod
    def detect(subdomains: List[str]) -> List[Dict]:
        """检测子域名接管风险"""
        findings = []

        if not subdomains or not HAS_DNS:
            logger.warning("  Subdomain Takeover: 需要 python3-dns 库 (pip install dnspython)")
            return findings

        seen_domains = set()

        for subdomain in subdomains:
            # Check DNS CNAME records
            cname = SubdomainTakeoverDetector._get_cname(subdomain)
            if not cname:
                continue

            cname_target = cname.lower().strip('.')

            # Skip self-referencing or internal CNAMEs
            if cname_target == subdomain.lower() or cname_target.startswith(('_', 'localhost')):
                continue

            domain_key = f"{subdomain}->{cname_target}"
            if domain_key in seen_domains:
                continue
            seen_domains.add(domain_key)

            # Check for dangling indicators via HTTP probe
            takeover_info = SubdomainTakeoverDetector._check_takeover_probe(cname_target, subdomain)
            if takeover_info:
                findings.append(takeover_info)

        return findings

    @staticmethod
    def _get_cname(domain: str) -> Optional[str]:
        """获取 CNAME 记录"""
        try:
            resolver = dns.resolver.Resolver()
            resolver.timeout = 5
            resolver.lifetime = 5
            answers = resolver.resolve(domain, 'CNAME')
            for rdata in answers:
                cname = str(rdata.target).rstrip('.')
                if cname:
                    return cname
        except Exception:
            pass
        return None

    @staticmethod
    def _check_takeover_probe(cname_target: str, original_domain: str) -> Optional[Dict]:
        """通过 HTTP 探测判断 CNAME 是否 dangling"""
        import requests as req

        probe_url = f"http://{original_domain}"
        try:
            resp = req.get(
                probe_url,
                timeout=10,
                allow_redirects=False,
                headers={'User-Agent': 'Mozilla/5.0 (compatible; takeover-checker/1.0)'},
            )

            body_lower = resp.text.lower() if resp.text else ''
            status = resp.status_code

            # Check each indicator
            for indicator, (service, severity) in DANGLING_INDICATORS.items():
                if indicator.lower() in body_lower:
                    return {
                        'id': 'SUBDOMAIN_TAKEOVER',
                        'severity': severity,
                        'title': f'子域名接管风险 ({service}): {original_domain}',
                        'description': (
                            f'{original_domain} 的 DNS CNAME 指向 {cname_target}，'
                            f'HTTP 响应显示目标服务已不再解析该子域名。\n'
                            f'攻击者可以注册对应的第三方服务账号并将 CNAME 指向自己的服务器，'
                            f'从而接管该子域名的流量。'
                        ),
                        'url': probe_url,
                        'evidence': (
                            f'DNS CNAME: {cname_target}\n'
                            f'Status: {status}\n'
                            f'Target service: {service}\n'
                            f'Response indicator: "{indicator}" found in body'
                        ),
                        'recommendation': (
                            f'1. 如果不再需要此子域名，删除 DNS CNAME 记录\n'
                            f'2. 如果需要保留，确保在对应的 {service} 服务中正确配置了该子域名\n'
                            f'3. 立即检查是否有人已接管（检查服务器访问日志异常流量）\n'
                            f'4. 使用 DNS TXT CAA 记录或 DANE 保护 DNS 安全'
                        ),
                        'cwe': 'CWE-441',
                        'cvss': 9.1,
                    }

        except req.RequestException:
            pass

        return None


class CloudBucketEnumerator:
    """云存储桶枚举器 - S3/GCS/Azure Blob (Phase 5.6.2)"""

    @staticmethod
    def detect(base_domain: str, subdomains: List[str]) -> List[Dict]:
        """检测暴露的云存储桶"""
        findings = []
        import requests as req

        # Try common bucket name patterns
        bucket_candidates = [
            base_domain.replace('.', '-'),       # example-com
            base_domain.replace('.', ''),        # examplecom
            base_domain.replace('.', '_'),       # example_com
            base_domain,                          # example.com (GCS style)
        ]

        # Also try subdomains as potential bucket names
        for sub in subdomains:
            candidate = sub.split('.')[0]  # first label
            if len(candidate) < 3:
                continue
            bucket_candidates.extend([
                f"{candidate}-prod",
                f"{candidate}-staging",
                f"{candidate}-dev",
                f"{candidate}-backup",
                f"{candidate}-data",
                f"{candidate}-files",
                f"{candidate}-static",
                f"{candidate}-uploads",
            ])

        seen = set()
        for bucket in bucket_candidates:
            if bucket in seen or len(bucket) < 3:
                continue
            seen.add(bucket)

            # S3 style
            s3_urls = [
                f"http://{bucket}.s3.amazonaws.com",
                f"http://{bucket}.s3.us-east-1.amazonaws.com",
                f"https://{bucket}.azurewebsites.net",
                f"https://{bucket}.blob.core.windows.net",
                f"https://{bucket}.storage.googleapis.com",
            ]

            for s3_url in s3_urls:
                if s3_url in seen:
                    continue
                seen.add(s3_url)
                try:
                    resp = req.get(s3_url, timeout=8, allow_redirects=False)
                    # 200 with XML/list or public listing = finding
                    if resp.status_code == 200 and ('<ListBucketResult' in resp.text or
                                                    '<Contents>' in resp.text or
                                                    'public' in resp.text.lower()[:500]):
                        findings.append({
                            'id': 'CLOUD_BUCKET_EXPOSED',
                            'severity': 'critical',
                            'title': f'暴露的云存储桶: {bucket}',
                            'description': (
                                f'云存储桶 "{bucket}" 公开可访问，返回了文件列表或公共数据。'
                                f'可能泄露敏感文件和用户数据。'
                            ),
                            'url': s3_url,
                            'evidence': (
                                f'Status: {resp.status_code}\n'
                                f'Response starts with: {resp.text[:300]}\n'
                                f'Storage type: cloud bucket enumeration probe'
                            ),
                            'recommendation': (
                                '1. 立即将存储桶设置为私有\n'
                                '2. 检查是否有任何敏感数据已公开\n'
                                '3. 配置 Bucket Policy / ACL 限制访问\n'
                                '4. 启用访问日志以追踪谁曾经访问过'
                            ),
                            'cwe': 'CWE-284',
                            'cvss': 9.1,
                        })
                except req.RequestException:
                    continue

        return findings
