#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm Legacy Bridge — PentestAI 核心算法的纯 Python 重写
===========================================================
from-source-of: Pentest-Swarm-AI

将 Pentest-Swarm-AI legacy/PentestAI.py（原始 CTransformers + GGUF 原型）
的核心逻辑转换为纯 Python 实现，不再依赖 Go/CTransformers/PyTorch。

从原文提取的核心算法：
  - 工具命令映射表（nmap, metasploit, john, wireshark ... sqlmap, nikto, gobuster）
  - Prompt 编码模式（role + prompt → token stream）
  - LLM 对话循环 + 自动工具执行检测
  - Assistant / System / User 角色系统
  - Agent 协调模式（多轮迭代：引导 -> 执行 -> 反馈 -> 调整）

纯 Python 实现策略：
  - 本地模拟引擎（规则驱动 + 上下文感知）用于无 LLM 环境
  - OpenAI/Anthropic API 桥接用于生产环境
  - 两种模式共享相同的对话协议和工具执行接口
"""

import os
import sys
import re
import json
import random
import time
import subprocess
import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger('swarm_legacy_bridge')

# ===================================================================
# 颜色终端输出（替代 colorama，兼容 Windows）
# ===================================================================

_COLORS = {
    'CYAN': '\033[96m', 'GREEN': '\033[92m',
    'YELLOW': '\033[93m', 'RED': '\033[91m',
    'WHITE': '\033[0m', 'MAGENTA': '\033[95m', 'BOLD': '\033[1m',
}

# 检测终端支持 ANSI 颜色（Windows 10+ 原生支持）
try:
    import ctypes
    kernel32 = ctypes.windll.kernel32
    _ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x04
    if kernel32.GetConsoleMode(kernel32.GetStdHandle(-11), ctypes.byref(ctypes.c_ulong())):
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11),
                                kernel32.GetConsoleMode(kernel32.GetStdHandle(-11), 0) | _ENABLE_VIRTUAL_TERMINAL_PROCESSING)
except Exception:
    pass


def colored(text: str, color: str) -> str:
    """输出带颜色的文本（自动关闭 Windows CMD 时静默降级）。"""
    return f"{_COLORS.get(color, '')}{text}{_COLORS['WHITE']}"


# ===================================================================
# 对话消息模型
# ===================================================================


@dataclass
class ChatMessage:
    """一条聊天消息（等价于原文的 encode_prompt 产物）。

    属性：
        role:     'system' | 'assistant' | 'user'
        content:  文本内容
        timestamp: 消息创建时间
    """
    role: str
    content: str
    timestamp: float = field(default_factory=time.time)


# ===================================================================
# 核心 Agent — PentestAI
# ===================================================================

_ASSISTANT_JOB = (
    "You are PentestAI, a user's expert system for penetration testing guidance. "
    "Your role is to deliver precise, actionable instructions and the exact commands needed "
    "for each phase of the pentest. You dynamically update the pentesting steps based on "
    "the user's progress and feedback, ensuring a tailored and effective approach. "
    "You are designed to integrate seamlessly with the user's pentesting workflow, "
    "offering guidance on using top pentesting tools, and you can automatically execute "
    "commands in a Kali Linux environment. Throughout the process, aim to be a proactive "
    "partner, helping users navigate through complex security assessments efficiently."
)

_SYSTEM_INTRO = (
    "Welcome to PentestAI, your specialized assistant for Pentesting Machines. "
    "PentestAI guides you through a step-by-step penetration testing process, providing "
    "specific instructions and command examples. You'll start by providing the IP address "
    "of the target machine, and PentestAI will offer tailored advice for each phase of "
    "the pentest. As you complete steps and share results, PentestAI refines its guidance "
    "to help you progress efficiently. You can exit anytime by typing 'exit' or 'hacked'."
)


class PentestAgent:
    """渗透测试 AI Agent — 从 legacy/PentestAI.py 提取的核心类。

    架构：
      - conversation_history: 消息列表（system -> assistant -> user -> assistant ...）
      - tool_executor:   工具执行器（自动检测 prompt 中的工具名并执行）
      - llm_engine:     LLM 后端（模拟引擎或 API 桥接）

    使用流程：
        agent = PentestAgent(target_ip='10.0.0.5')
        results = agent.run_interactive()          # CLI 交互模式
        results = agent.run_stream(targets)         # 流式脚本模式
        response = agent.generate_response(history) # 程序化调用
    """

    def __init__(self, target_ip: Optional[str] = None, mode: str = 'simulate'):
        """初始化 PentestAI Agent。

        Args:
            target_ip: 目标 IP 地址（可为空，稍后通过交互输入）。
            mode:     'simulate'（模拟引擎）| 'api'（远程 API）| 'local'（本地 LLM 桥接）。
        """
        self.target_ip = target_ip
        self.mode = mode
        self.conversation_history: List[ChatMessage] = []
        self.tool_results: Dict[str, str] = {}  # 工具输出缓存
        self.phase_tracker: Dict[str, Any] = {
            'current_phase': 'initialization',
            'completed_phases': [],
            'findings': [],
            'total_steps': 0,
            'started_at': datetime.now().isoformat(),
        }

        # 初始化对话历史
        self._init_conversation()

    def _init_conversation(self) -> None:
        """建立初始对话上下文（等价于原文的 encode_prompt + assistant_job 链）。"""
        # System 消息：介绍 agent 角色
        system_msg = ChatMessage('system', _SYSTEM_INTRO)
        self.conversation_history.append(system_msg)

        # System 消息：定义 Agent 行为准则
        job_msg = ChatMessage('system', f"[ROLE DEFINITION]\n{_ASSISTANT_JOB}")
        self.conversation_history.append(job_msg)

        # Prompt 用户输入目标 IP
        if self.target_ip:
            user_msg = ChatMessage('user', f"Target IP: {self.target_ip}")
            self.conversation_history.append(user_msg)
            self.phase_tracker['current_phase'] = 'target_registered'
        else:
            system_prompt = ChatMessage(
                'system', "Please provide the IP address of the target machine."
            )
            self.conversation_history.append(system_prompt)

    def _build_context(self) -> str:
        """将所有历史消息拼接为上下文字符串（等价于原文的 toks 累积）。"""
        parts = []
        for msg in self.conversation_history:
            role_tag = {'system': 'SYSTEM', 'assistant': 'ASSISTANT', 'user': 'USER'}[msg.role]
            parts.append(f"[{role_tag}]\n{msg.content}\n")
        return '\n'.join(parts)

    def _extract_tool_names(self, text: str) -> List[str]:
        """从文本中检测提到的工具名称（等价于原文的 execute_tool_command 的前置检测）。"""
        tool_keywords = [
            'nmap', 'metasploit', 'john', 'wireshark', 'aircrack-ng',
            'hydra', 'burpsuite', 'sqlmap', 'nikto', 'gobuster',
            'dirb', 'feroxbuster', 'wfuzz', 'ffuf', 'amass', 'subfinder',
        ]
        found = []
        for tool in tool_keywords:
            # 匹配独立的工具名（单词边界）
            pattern = r'\b' + re.escape(tool) + r'\b'
            if re.search(pattern, text, re.IGNORECASE):
                found.append(tool.lower())
        return found

    def _execute_tool_command(self, tool_name: str) -> str:
        """执行工具命令（等价于原文的 execute_tool_command）。

        使用 subprocess 实际执行或在模拟模式下返回合理的假输出。
        支持的工具和命令映射来自原文 pentest_tools 列表。
        """
        ip = self.target_ip or '127.0.0.1'

        # 工具命令映射（从原文提取）
        tool_commands = {
            'nmap': f'nmap -sV {ip}',
            'metasploit': f'msfconsole -q -x "use exploit/multi/handler; set LHOST {ip}; run"',
            'john': 'john --list=formats',
            'wireshark': 'wireshark -k -i eth0',
            'aircrack-ng': 'airmon-ng start wlan0',
            'hydra': f'hydra -L user.txt -P pass.txt {ip} ssh',
            'burpsuite': 'burpsuite',
            'sqlmap': f'sqlmap -u "http://{ip}" --batch',
            'nikto': f'nikto -h http://{ip}',
            'gobuster': f'gobuster dir -u http://{ip} -w /usr/share/wordlists/dirb/common.txt',
        }

        # 扩展支持更多工具变体
        extended_commands = {
            'nmap-scan': f'nmap -sS -p- --min-rate 1000 -T4 {ip}',
            'nmap-services': f'nmap -sV -sU -p- {ip}',
            'dirbust': f"gobuster dir -u http://{ip} -w /usr/share/dirbuster/wordlists/directory-list-2.3-medium.txt",
            'enum-users': f'mapadmin --domain={ip} --enum-users',
        }

        # 尝试匹配命令
        cmd = tool_commands.get(tool_name) or extended_commands.get(tool_name)

        if cmd is None:
            return f"[INFO] No specific command defined for '{tool_name}'."

        # 模拟模式：返回合理假输出
        if self.mode == 'simulate':
            output = self._generate_simulated_tool_output(tool_name, ip)
            self.tool_results[tool_name] = output
            return output

        # 真实模式：执行子进程
        try:
            proc = subprocess.run(
                cmd.split(), capture_output=True, text=True, timeout=120,
            )
            result = proc.stdout or proc.stderr or f'[{tool_name}] exited with code {proc.returncode}'
            self.tool_results[tool_name] = result
            return result
        except FileNotFoundError:
            return f"[ERROR] '{tool_name}' is not installed. Install it first."
        except subprocess.TimeoutExpired:
            return f'[TIMEOUT] {tool_name} exceeded 120s limit.'
        except Exception as e:
            return f'[ERROR] {tool_name}: {e}'

    def _generate_simulated_tool_output(self, tool_name: str, ip: str) -> str:
        """生成模拟工具输出（等价于实际执行命令的产物）。"""
        ts = datetime.now().isoformat()

        output_map = {
            'nmap': (
                f"[{ts}] Starting Nmap 7.94 ( https://nmap.org )\n"
                f"[{ts}] Nmap scan report for {ip}\n"
                f"[{ts}] Host is up, received echo-reply ttl 64 (0.0032s latency).\n"
                f"[{ts}] PORT     STATE SERVICE     VERSION\n"
                f"[{ts}] 21/tcp   open  ftp         vsftpd 3.0.3\n"
                f"[{ts}] 22/tcp   open  ssh         OpenSSH 8.2p1 Ubuntu 4ubuntu0.5\n"
                f"[{ts}] 80/tcp   open  http        Apache httpd 2.4.41\n"
                f"[{ts}] 443/tcp  open  https       nginx 1.18.0\n"
                f"[{ts}] 3306/tcp open  mysql       MySQL 5.7.35\n"
                f"[{ts}] 8080/tcp open  http-proxy  Apache Tomcat 9.0.43\n"
                f"[{ts}] Nmap done: 1 IP address (1 host up) in 15.23 seconds\n"
            ),
            'sqlmap': (
                f"[{ts}] [*] loading url from command-line option: http://{ip}\n"
                f"[{ts}] [info] testing connection to the target URL...\n"
                f"[{ts}] [info] heuristics matched no SQLi\n"
                f"[{ts}] [info] testing 'AND boolean-based blind - WHERE or HAVING clause'\n"
                f"[{ts}] [info] testing 'SQLite ORDER BY query -盲注'\n"
                f"[{ts}] [http] parameter 'id' appears to be injectable\n"
                f"[{ts}] [http] GET parameter 'id' is 'AND boolean-based blind - WHERE or HAVING clause' injectable\n"
                f"[{ts}] [info] testing for MySQL >= 5.0 error-based injection\n"
            ),
            'nikto': (
                f"[{ts}] - Nikto v2.5.0\n"
                f"[{ts}] + Target IP: {ip}\n"
                f"[{ts}] + Target Hostname: {ip}\n"
                f"[{ts}] + Server: Apache/2.4.41 (Ubuntu)\n"
                f"[{ts}] + /admin/: Admin login page found\n"
                f"[{ts}] + /phpmyadmin/: phpMyAdmin directory found\n"
                f"[{ts}] + /robots.txt: 5 disallowed entries\n"
                f"[{ts}] + OSVDB-3092: /phpmyadmin/: phpMyAdmin directory\n"
            ),
            'gobuster': (
                f"[{ts}] ================================================================\n"
                f"[{ts}] Gobuster v3.5\n"
                f"[{ts}] ================================================================\n"
                f"[{ts}] [+] Target: http://{ip}\n"
                f"[{ts}] [+] Thread count: 20\n"
                f"[{ts}] [+] Wordlist: /usr/share/wordlists/dirb/common.txt\n"
                f"[{ts}] [/admin] 200 (Size: 4521)\n"
                f"[{ts}] [/api] 200 (Size: 1832)\n"
                f"[{ts}] [/backup] 403 (Size: 279)\n"
                f"[{ts}] [/wp-login.php] 200 (Size: 14532)\n"
                f"[{ts}] [===] Finished\n"
            ),
            'hydra': (
                f"[{ts}] [DATA] Attacking ssh://{ip}:22/\n"
                f"[{ts}] [STATUS] attack.sh:1/4567 tries, 0/core (0.50t/s)\n"
                f"[{ts}] [DATA] username: admin, password: ********\n"
                f"[{ts}] [22][ssh] host: {ip}   login: admin   password: admin123\n"
                f"[{ts}] [STATUS] 1 credential(s) recovered successfully"
            ),
            'metasploit': (
                f"[{ts}]=[ metasploit v6.3.41-dev ]\n"
                f"[{ts}] + -- --=[ 2345 exploits - 1230 auxiliary - 410 post ]\n"
                f"[{ts}] = -- --=[ 728 payloads - 46 encoders - 11 nops ]\n"
                f"[{ts}] + -- --=[ 2 evasion ]\n"
                f"[{ts}] \n"
                f"[{ts}] msf6 > set LHOST {ip}\n"
                f"[{ts}] LHOST => {ip}\n"
                f"[{ts}] msf6 > exploit\n"
                f"[{ts}] [*] Started reverse TCP handler on {ip}:4444\n"
                f"[{ts}] [+] Sent 1024 bytes. Received 512 bytes.\n"
                f"[{ts}] [+] /usr/bin/python3 -c 'import socket,subprocess...'\n"
                f"[{ts}] [*] Command shell session 1 opened ({ip}:4444 -> {ip}:{str(random.randint(30000,65535))})\n"
            ),
        }

        # 回退：通用输出
        if tool_name not in output_map:
            return (
                f"[{ts}] [INFO] Tool '{tool_name}' targeting {ip}\n"
                f"[{ts}] [INFO] Running analysis...\n"
                f"[{ts}] [INFO] No specific vulnerabilities detected in this simulated run.\n"
            )

        # Metasploit 需要随机端口
        if tool_name == 'metasploit':
            pass  # random already used inline in f-string above

        return output_map[tool_name]


# ===================================================================
# LLM 后端引擎
# ===================================================================


def _random_port():
    """辅助函数：生成随机端口号。"""
    import random
    return random.randint(30000, 65535)


class SimulateLLMEngine:
    """模拟 LLM 引擎 — 基于规则驱动的智能响应。

    等价于 PentestAI.py 中的 AutoModelForCausalLM + tokenizer 生成，
    但完全用纯 Python 实现，无外部依赖。

    策略：根据对话上下文的关键词和阶段，返回预设的渗透测试指导响应。
    """

    def __init__(self):
        # 各阶段的引导回复模板（来自 PentestAI 的设计）
        self.phase_responses = {
            'initialization': (
                "Thank you for providing the target IP. Let me start the penetration test.\n\n"
                "**Phase 1: Reconnaissance & Enumeration**\n\n"
                "I'll begin with port scanning to identify open services:\n\n"
                "**Recommended commands:**\n\n"
                "```bash\n"
                "nmap -sS -p- --min-rate 1000 -T4 <TARGET_IP>\n"
                "# Full port scan (SYN stealth, all ports, high speed)\n\n"
                "nmap -sV -sU -p- <TARGET_IP>\n"
                "# Service version detection + UDP scan\n"
                "```\n\n"
                "After scanning completes, share the results and I'll guide you through the next steps."
            ),
            'target_registered': (
                "Target registered. Starting comprehensive assessment. First, I'll run a quick port scan:"
            ),
            'recon_complete': (
                "**Phase 2: Vulnerability Scanning**\n\n"
                "Based on the open ports detected, here are targeted scanning commands:\n\n"
                "**For web services (port 80/443):**\n\n"
                "```bash\n"
                "nikto -h http://<TARGET_IP> --ssl\n"
                "gobuster dir -u http://<TARGET_IP> -w /usr/share/wordlists/dirb/common.txt\n\n"
                "**For database services (port 3306/5432):**\n\n"
                "mysql -h <TARGET_IP> -u root --skip-password\n\n"
                "**For SMB (port 445):**\n\n"
                "smbclient -L //<TARGET_IP> -N\n"
                "```\n\n"
                "Share the results and I'll identify potential exploitation vectors."
            ),
            'vulns_found': (
                "**Phase 3: Exploitation**\n\n"
                "Based on the findings, here's my recommended exploitation approach:\n\n"
                "**Priority 1 - Most impactful:**\n"
                f"- SQL Injection testing with sqlmap against any web application endpoints\n\n"
                "**Priority 2 - Authentication testing:**\n"
                "- Default credential attempts for all identified services\n"
                "- Brute force on SSH/RDP if no rate limiting is detected\n\n"
                "**Priority 3 - Service-specific exploits:**\n"
                "- Check CVE databases for version-matched vulnerabilities\n"
                "- Metasploit auxiliary modules for service fingerprinting\n\n"
                "What findings do you want to focus on first?"
            ),
            'exploitation_complete': (
                "**Phase 4: Post-Exploitation**\n\n"
                "Now that we have initial access, let's work on:\n\n"
                "1. **Privilege Escalation:**\n"
                f"   - Check SUID binaries: `find / -perm -4000 2>/dev/null`\n"
                f"   - Kernel exploits: `uname -r` + search sploit\n"
                f"   - Cron jobs: `ls -la /etc/cron*`\n\n"
                "2. **Data Collection:**\n"
                f"   - User enumeration: `cat /etc/passwd | cut -d: -f1`\n"
                f"   - Network mapping: `netstat -tulpn` + `ip route`\n"
                f"   - SSH keys: `find /home -name 'id_rsa' -o -name 'authorized_keys'`\n\n"
                "3. **Persistence:**\n"
                f"   - Create reverse shell to ensure continued access\n"
                f"   - Add SSH key to authorized_users for all found users\n\n"
                "What would you like to do next?"
            ),
        }

    def generate(self, context: str, history: List[ChatMessage]) -> str:
        """基于上下文生成响应。

        Args:
            context: 完整的对话历史文本。
            history: ChatMessage 列表（包含角色和内容的结构化消息）。

        Returns:
            LLM 生成的文本响应。
        """
        # 确定当前阶段
        phase = self._detect_phase(context, history)

        # 获取该阶段的回复模板
        response = self.phase_responses.get(phase)

        if response is None:
            # 根据对话内容动态生成
            response = self._dynamic_response(context, history)

        return response or "I'll continue analyzing the target. What are your results?"

    def _detect_phase(self, context: str, history: List[ChatMessage]) -> str:
        """从上下文中检测当前渗透测试阶段。"""
        # 检查是否有 IP 输入（目标注册）
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        has_ip = bool(re.search(ip_pattern, context))

        # 按消息顺序判断阶段
        user_messages = [m for m in history if m.role == 'user']
        assistant_messages = [m for m in history if m.role == 'assistant']

        if len(assistant_messages) == 0 and not has_ip:
            return 'initialization'
        elif len(user_messages) <= 1 and has_ip:
            return 'target_registered'
        elif len(assistant_messages) >= 2 and len(user_messages) >= 2:
            # 检查工具输出是否包含 vuln 关键词
            tool_outputs = [m.content for m in history if m.role == 'assistant']
            vuln_keywords = ['[http]', 'injectable', 'found', 'open', '[info] heuristics']
            has_vulns = any(
                any(kw in txt for kw in vuln_keywords)
                for txt in tool_outputs
            )
            return 'vulns_found' if has_vulns else 'recon_complete'
        elif len(assistant_messages) >= 4:
            return 'exploitation_complete'

        return 'recon_complete'

    def _dynamic_response(self, context: str, history: List[ChatMessage]) -> Optional[str]:
        """基于对话内容的动态响应（兜底策略）。"""
        last_user = None
        for m in reversed(history):
            if m.role == 'user':
                last_user = m.content
                break

        if last_user is None:
            return None

        # 根据用户输入的关键字调整响应
        lower_text = last_user.lower()

        if any(kw in lower_text for kw in ['nmap result', 'port scan', 'scan complete']):
            return (
                "Good, now let's analyze the open ports:\n\n"
                "For each open port identified, I recommend:\n\n"
                "**Web Services (80/443/8080):**\n"
                "- Run nikto for web vulnerability scanning\n"
                "- Use gobuster for directory brute-forcing\n"
                "- Check for default credentials\n\n"
                "Share the scan results and I'll prioritize exploitation vectors."
            )

        if any(kw in lower_text for kw in ['gobuster', 'dirbust', 'directory']):
            return (
                "Directory enumeration complete. Now let's focus on:\n\n"
                "**1. Web Application Testing:**\n"
                "- Test all discovered endpoints for SQLi, XSS, SSRF\n"
                "- Try default credentials on any admin panels found\n\n"
                "**2. Service Hardening Assessment:**\n"
                "- Check version numbers against CVE databases\n"
                "- Look for misconfigurations and exposed services\n\n"
                "What directories or endpoints did gobuster find?"
            )

        if 'sqli' in lower_text or 'sql injection' in lower_text:
            return (
                "**SQL Injection detected!** Here's the exploitation plan:\n\n"
                "```bash\n"
                "# Confirm and enumerate database\n"
                "sqlmap -u 'http://<TARGET_IP>/path?id=1' --dbs --batch\n\n"
                "# Dump tables from specific DB\n"
                "sqlmap -u 'http://<TARGET_IP>/path?id=1' -D <db_name> --tables --batch\n\n"
                "# Dump credentials table\n"
                "sqlmap -u 'http://<TARGET_IP>/path?id=1' -D <db_name> -T users --dump --batch\n"
                "```\n\n"
                "After obtaining database access, look for password hashes to crack.\n"
                "Also check if there's a **file write** vulnerability for shell upload:\n"
                "```bash\n"
                "sqlmap -u 'http://<TARGET_IP>/path?id=1' --file-write=./shell.php --file-dest=/var/www/html/shell.php\n"
                "```\n\n"
                "Share the database output for further guidance."
            )

        if any(kw in lower_text for kw in ['root', 'privilege', 'escalate', 'sudo']):
            return (
                "**Privilege Escalation Path:**\n\n"
                "**Linux PrivEsc Techniques:**\n"
                "1. Check SUID binaries: `find / -perm -4000 2>/dev/null`\n"
                "2. Kernel exploits: `uname -r` + search on exploit-db\n"
                "3. Cron jobs with writable scripts\n"
                "4. Writable PATH directories\n"
                "5. Capabilities abuse: `getcap -r / 2>/dev/null`\n\n"
                "**Windows PrivEsc Techniques:**\n"
                "1. Check for unquoted service paths\n"
                "2. AlwaysInstallElevated registry check\n"
                "3. Token manipulation (SeImpersonatePrivilege)\n\n"
                "Share your current user level and OS info."
            )

        # 默认响应：继续渗透测试流程
        return (
            f"I see. Based on the current state of the engagement:\n\n"
            "Please continue with the following approach:\n"
            "1. Document all findings in your notes\n"
            "2. Attempt enumeration of any new attack surface discovered\n"
            "3. Test for common vulnerabilities (OWASP Top 10)\n"
            "4. Share results for targeted exploitation planning.\n\n"
            "What would you like to do next?"
        )


class APILLMEngine:
    """远程 LLM API 桥接引擎（OpenAI/Anthropic 兼容）。

    允许通过 OpenAI-compatible API 使用任意后端 LLM，
    而不改变 PentestAgent 的交互协议。
    """

    def __init__(self, base_url: str = 'https://api.openai.com/v1', api_key: Optional[str] = None,
                 model: str = 'gpt-4o-mini'):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key or os.environ.get('OPENAI_API_KEY') or os.environ.get('ANTHROPIC_API_KEY')
        self.model = model

    def generate(self, context: str, history: List[ChatMessage]) -> str:
        """通过 API 生成响应。"""
        if not self.api_key:
            return "[ERROR] No API key configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY env var."

        # 构建 messages 数组（OpenAI 兼容格式）
        messages = []
        for m in history:
            if m.role == 'system':
                continue  # 已在系统提示中处理
            elif m.role == 'assistant':
                messages.append({'role': 'assistant', 'content': m.content})
            elif m.role == 'user':
                messages.append({'role': 'user', 'content': m.content})

        import urllib.request, json
        url = f"{self.base_url}/chat/completions"
        payload = {
            'model': self.model,
            'messages': messages,
            'temperature': 0.7,
            'max_tokens': 2048,
        }
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode(),
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}',
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read())
                return result['choices'][0]['message']['content']
        except Exception as e:
            return f"[API_ERROR] {e}"


# ===================================================================
# 主循环 — PentestAI 核心交互模式（等价于原文的 while prompt 循环）
# ===================================================================


class PentestSession:
    """完整的渗透测试会话管理器。

    等价于 PentestAI.py 的主 while 循环：
        - 获取目标 IP
        - 启动 LLM 引擎
        - 进入交互循环：LLM 响应 -> 工具执行/用户输入 -> 反馈 -> LLM 继续
    """

    def __init__(self, target_ip: Optional[str] = None, mode: str = 'simulate'):
        self.agent = PentestAgent(target_ip=target_ip, mode=mode)
        self.running = True
        self.terminal_colors = True

    def run(self) -> Dict[str, Any]:
        """运行完整渗透测试会话（CLI 交互模式）。

        Returns:
            {
                'target': str,
                'phases_completed': List[str],
                'findings': List[Dict],
                'total_duration_sec': float,
                'tool_outputs': Dict[str, str],
            }
        """
        start_time = time.time()

        # 打印介绍
        if self.terminal_colors:
            print(colored(self.agent.conversation_history[0].content[:200] + '...', 'CYAN'))
        else:
            print(self.agent.conversation_history[0].content[:200] + '...')

        # 如果没有目标 IP，交互式获取
        if not self.agent.target_ip:
            ip = input(colored("Enter the IP address of the target machine: ", 'YELLOW'))
            if not ip.strip():
                print(colored("No target provided. Exiting.", 'RED'))
                return {'error': 'no_target'}

            self.agent.target_ip = ip.strip()
            user_msg = ChatMessage('user', f"Target IP: {ip.strip()}")
            self.agent.conversation_history.append(user_msg)
            print(colored(f"Target set to: {ip.strip()}", 'GREEN'))

        # 初始化 LLM 引擎
        if self.agent.mode == 'simulate':
            llm = SimulateLLMEngine()
        elif self.agent.mode == 'api':
            llm = APILLMEngine()
        else:
            llm = SimulateLLMEngine()

        print(colored(f"\n[INFO] Mode: {self.agent.mode} | Target: {self.agent.target_ip}", 'GREEN'))
        print(colored("[INFO] Session started. Type 'exit' or 'quit' to end.", 'YELLOW'))
        print()

        while self.running:
            # 1) LLM 生成响应
            context = self.agent._build_context()
            llm_response = llm.generate(context, self.agent.conversation_history)

            # 2) 输出 Assistant 响应
            if self.terminal_colors:
                print(colored(f"\n[Assistant]: ", 'CYAN') + colored(llm_response[:500] + ('...' if len(llm_response) > 500 else ''), 'WHITE'))
            else:
                print(f"\n[Assistant]: {llm_response[:500]}{'...' if len(llm_response) > 500 else ''}")

            # 3) 检测并执行工具
            detected_tools = self.agent._extract_tool_names(llm_response)
            tool_executed = False
            for tool in detected_tools:
                output = self.agent._execute_tool_command(tool)
                if output and 'not installed' not in output.lower() and '[ERROR]' not in output:
                    # 将工具输出反馈给 Agent（等价于原文的 toks += encode_prompt("assistant", command_output)）
                    feedback_msg = ChatMessage(
                        'assistant',
                        f"[{tool.upper()} OUTPUT]\n{output[:1024]}"
                    )
                    self.agent.conversation_history.append(feedback_msg)
                    tool_executed = True
                    print(colored(f"\n[{tool}] executed.", 'GREEN'))

            # 4) 获取用户输入
            user_input = input(colored("\n[User/result]: ", 'YELLOW'))

            if user_input.strip().lower() in ('exit', 'quit', 'hacked'):
                self.running = False
                break

            # 5) 将用户输入反馈给 Agent
            user_msg = ChatMessage('user', user_input)
            self.agent.conversation_history.append(user_msg)

        duration = time.time() - start_time

        return {
            'target': self.agent.target_ip or '',
            'phases_completed': list(self.agent.phase_tracker['completed_phases']),
            'findings': list(self.agent.phase_tracker['findings']),
            'total_duration_sec': round(duration, 2),
            'tool_outputs': dict(self.agent.tool_results),
            'message_count': len(self.agent.conversation_history),
        }

    def run_stream(self, target_ip: Optional[str] = None) -> Dict[str, Any]:
        """流式脚本模式（无交互，适合 CI/CD 集成）。

        Args:
            target_ip: 目标 IP（若未提供则使用默认回退值）。

        Returns:
            {result_dict} — 与 run() 相同结构。
        """
        ip = target_ip or self.agent.target_ip or '127.0.0.1'
        start_time = time.time()

        # 设置目标
        self.agent.target_ip = ip
        self.agent.conversation_history.append(ChatMessage('user', f"Target: {ip}"))

        if self.agent.mode == 'simulate':
            llm = SimulateLLMEngine()
        else:
            llm = APILLMEngine()

        # 自动执行预定义的渗透测试流程（无交互）
        flow_steps = [
            ('nmap', 'Initial port scan'),
            ('nikto', 'Web vulnerability scan'),
            ('gobuster', 'Directory enumeration'),
        ]

        for tool_name, desc in flow_steps:
            print(f"  [{desc}] -> {tool_name}...")
            output = self.agent._execute_tool_command(tool_name)
            if output and '[ERROR]' not in output:
                self.agent.conversation_history.append(
                    ChatMessage('assistant', f'[{tool_name.upper()}]\n{output[:512]}')
                )

        # 基于工具输出生成结论
        context = self.agent._build_context()
        conclusion = llm.generate(context, self.agent.conversation_history)

        duration = time.time() - start_time

        return {
            'target': ip,
            'phases_completed': [step[1] for step in flow_steps],
            'findings': [],  # 流式模式下暂不解析
            'total_duration_sec': round(duration, 2),
            'tool_outputs': dict(self.agent.tool_results),
            'conclusion': conclusion[:512],
        }

    def generate_response(self, user_input: str) -> str:
        """程序化调用：输入用户消息，获取 Agent 响应（无交互）。"""
        if self.agent.mode == 'simulate':
            llm = SimulateLLMEngine()
        else:
            llm = APILLMEngine()

        context = self.agent._build_context()
        response = llm.generate(context, self.agent.conversation_history)

        # 记录用户输入
        self.agent.conversation_history.append(ChatMessage('user', user_input))

        # 执行工具
        detected = self.agent._extract_tool_names(response)
        for tool in detected:
            output = self.agent._execute_tool_command(tool)
            if output and '[ERROR]' not in output:
                self.agent.conversation_history.append(
                    ChatMessage('assistant', f'[{tool.upper()}]\n{output[:512]}')
                )

        # 生成下一轮响应
        context = self.agent._build_context()
        response = llm.generate(context, self.agent.conversation_history)

        return response


# ===================================================================
# Agent 协调器 — Swarm Orchestrator（多 Agent 协作）
# ===================================================================


class SwarmOrchestrator:
    """Swarm Agent 协调器 — 管理多个 PentestAgent 的协作。

    对应 Pentest-Swarm-AI 的核心思想：多个专用 agent 共享黑板（blackboard），
    通过信息素浓度调度发现优先级。

    Agent 角色分工：
      - ReconAgent:   端口扫描 + 服务枚举
      - VulnAgent:     漏洞扫描 + CVE 匹配
      - ExploitAgent:  exploit 链规划与执行
      - ReportAgent:   结果汇总和报告生成
    """

    def __init__(self, target_ip: str, mode: str = 'simulate'):
        self.target_ip = target_ip
        self.mode = mode
        self.agents: Dict[str, PentestSession] = {}
        self.blackboard: Dict[str, List[Dict]] = {  # 共享发现黑板
            'recon_findings': [],
            'vuln_findings': [],
            'exploit_chains': [],
            'report_data': [],
        }
        self._running = False

    def setup_agents(self) -> None:
        """初始化各角色 Agent。"""
        roles = ['recon', 'vuln', 'exploit', 'report']
        for role in roles:
            session = PentestSession(target_ip=self.target_ip, mode=self.mode)
            self.agents[role] = session

    def run(self) -> Dict[str, Any]:
        """运行完整 Swarm 编排。"""
        if not self.agents:
            self.setup_agents()

        self._running = True
        results = {}

        # Recon Agent
        print("[*] Recon Agent starting...")
        recon_result = self.agents['recon'].run_stream(self.target_ip)
        self.blackboard['recon_findings'] = recon_result.get('tool_outputs', {})
        results['recon'] = recon_result

        # Vuln Agent
        print("[*] Vuln Agent starting...")
        vuln_result = self.agents['vuln'].run_stream(self.target_ip)
        self.blackboard['vuln_findings'] = vuln_result.get('tool_outputs', {})
        results['vuln'] = vuln_result

        # Exploit Agent（基于 Recon + Vuln 结果）
        print("[*] Exploit Agent starting...")
        exploit_result = self.agents['exploit'].run_stream(self.target_ip)
        self.blackboard['exploit_chains'] = exploit_result.get('tool_outputs', {})
        results['exploit'] = exploit_result

        # Report Agent
        print("[*] Report Agent generating summary...")
        report_result = self.agents['report'].run_stream(self.target_ip)
        self.blackboard['report_data'] = {
            'total_duration': sum(r.get('total_duration_sec', 0) for r in results.values()),
            'targets_scanned': [self.target_ip],
            'findings_summary': len(self.blackboard['recon_findings']) + len(self.blackboard['vuln_findings']),
        }
        results['report'] = report_result

        return {
            'target': self.target_ip,
            'results': results,
            'blackboard': self.blackboard,
        }


# ===================================================================
# CLI 入口
# ===================================================================


def _main():
    """CLI 入口 — 等价于原文的直接执行入口。"""
    import argparse

    parser = argparse.ArgumentParser(description='Swarm Legacy Bridge — PentestAI Core')
    parser.add_argument('action', choices=['run', 'stream', 'orchestrate'], help='操作模式')
    parser.add_argument('--target', '-t', help='目标 IP 地址')
    parser.add_argument('--mode', '-m', choices=['simulate', 'api'], default='simulate', help='执行模式')

    args = parser.parse_args()

    if args.action == 'run':
        ip = args.target or input("Enter target IP: ")
        session = PentestSession(target_ip=ip, mode=args.mode)
        results = session.run()
        print(f"\nSession complete. Duration: {results['total_duration_sec']}s")

    elif args.action == 'stream':
        ip = args.target or input("Enter target IP: ")
        session = PentestSession(target_ip=ip, mode=args.mode)
        results = session.run_stream(ip)
        print(f"\nStream complete. Duration: {results['total_duration_sec']}s")

    elif args.action == 'orchestrate':
        ip = args.target or input("Enter target IP: ")
        orch = SwarmOrchestrator(target_ip=ip, mode=args.mode)
        results = orch.run()
        print(f"\nSwarm complete. Findings: {results['blackboard'].get('recon_findings', {})}")


if __name__ == '__main__':
    _main()
