#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTTP Parameter Pollution & Discovery Detector
==============================================
借鉴 Pentest-Swarm-AI arjun 适配器（参数发现）+ Phase 5.11.8 (HPP).
检测 HTTP 参数污染、隐藏/调试参数暴露等漏洞。
"""

import re
import json
import logging
from typing import List, Dict, Optional, Set
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

logger = logging.getLogger('hpp_detector')


# Common hidden/debug parameters that should not be in production
HIDDEN_PARAM_KEYWORDS = [
    'debug', 'test', 'tmp', 'temp', '_test', '__debug__',
    'dev', 'staging', 'local', 'sandbox', 'scratch',
    'x-debug', 'x-powered-by', 'x-env', 'x-request-id',
    '__proto__', '__esModule', '_headers', '_query',
]

# Dangerous parameter patterns that may expose internal state
SENSITIVE_PARAM_NAMES = [
    'role', 'isAdmin', 'is_admin', 'admin', 'user_id', 'userId',
    'permission', 'permissions', 'privilege', 'auth',
    'internal', 'hidden', 'override', 'modify', 'change',
    'redirect', 'url', 'dest', 'next', 'return', 'callback',
    'continue', 'origURL', 'originalUrl', 'forward',
]


class HTTPParamPollutionDetector:
    """HTTP Parameter Pollution (HPP) 检测器
    当同一参数在请求中出现多次时，不同后端处理方式可能导致 HPP 漏洞。
    """

    @staticmethod
    def detect(url: str, response_text: str = "") -> List[Dict]:
        """检测 HPP 漏洞"""
        findings = []
        parsed = urlparse(url)

        if not parsed.query:
            return findings

        # Parse existing parameters
        existing_params = parse_qs(parsed.query, keep_blank_values=True)

        for param_name in list(existing_params.keys()):
            # 1. Test HPP by sending duplicate parameter with different values
            hpp_finding = HTTPParamPollutionDetector._test_hpp(url, param_name)
            if hpp_finding:
                findings.append(hpp_finding)

        # 2. Check for hidden/debug parameters in response body
        if response_text:
            findings.extend(HTTPParamPollutionDetector._find_hidden_params(response_text))

        return findings

    @staticmethod
    def _test_hpp(url: str, param_name: str) -> Optional[Dict]:
        """测试 HPP — 发送同名参数多次"""
        parsed = urlparse(url)
        params = parse_qs(parsed.query, keep_blank_values=True)

        if param_name not in params:
            return None

        original_value = params[param_name][0]
        hpp_value = "HPP_test_12345"

        # Build HPP URL with duplicate parameter
        new_params = list(params.items())
        # Replace the target param with two copies
        new_params = [(k, [v]) for k, v in new_params if k != param_name]
        new_params.append((param_name, [original_value, hpp_value]))

        query = '&'.join(f"{k}={v[0]}" if isinstance(v, list) else f"{k}={v}" for k, v in new_params)
        hpp_url = urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, query, ''))

        try:
            import requests as req
            timeout = 30  # fallback since CONFIG not available here
            resp_orig = req.get(url, timeout=timeout, allow_redirects=False)
            resp_hpp = req.get(hpp_url, timeout=timeout, allow_redirects=False)

            # Compare responses - if HPP changes behavior, potential vulnerability
            orig_body = resp_orig.text
            hpp_body = resp_hpp.text

            # Check if HPP value appears in response (parameter reflection + processing change)
            if hpp_value in hpp_body and hpp_body != orig_body:
                return {
                    'id': 'HPP_PARAMETER_REFLECTION',
                    'severity': 'medium',
                    'title': f'HTTP 参数污染 (HPP): {param_name}',
                    'description': (
                        f'参数 {param_name} 支持重复发送。后端将多个值以某种方式合并处理，'
                        f'HPP value "{hpp_value}" 出现在响应中且响应内容发生变化。\n\n'
                        f'这可能导致：\n'
                        f'- 绕过安全过滤（前端过滤器仅检查第一个值）\n'
                        f'- 权限提升（如 admin, role 等参数被 HPP 覆盖）\n'
                        f'- Cache poisoning（缓存键生成不一致）'
                    ),
                    'url': hpp_url,
                    'evidence': (
                        f'原始响应长度: {len(orig_body)}\n'
                        f'HPP 响应长度: {len(hpp_body)}\n'
                        f'HPP value in response: {"Yes" if hpp_value in hpp_body else "No"}\n'
                        f'Responses differ: {orig_body != hpp_body}'
                    ),
                    'recommendation': (
                        '1. 后端对重复参数应只取第一个值或明确定义合并行为\n'
                        '2. 使用严格白名单校验所有参数名和参数数量\n'
                        '3. 对数组型参数做类型强制校验（非字符串时拒绝）'
                    ),
                    'cwe': 'CWE-76',
                    'cvss': 6.5,
                }

        except req.RequestException:
            pass

        return None

    @staticmethod
    def _find_hidden_params(response_text: str) -> List[Dict]:
        """从 HTML 响应体中寻找暴露的隐藏/调试参数"""
        findings = []

        # Look for hidden form fields with sensitive names
        hidden_pattern = r'<input[^>]*type=["\']hidden["\'][^>]*name=["\']([^"\']+)["\'][^>]*value=["\']([^"\']*)["\']'
        for match in re.finditer(hidden_pattern, response_text):
            name, value = match.group(1), match.group(2)

            # Check if hidden field name matches suspicious patterns
            if any(kw in name.lower() for kw in HIDDEN_PARAM_KEYWORDS + SENSITIVE_PARAM_NAMES):
                findings.append({
                    'id': 'HIDDEN_PARAM_EXPOSED',
                    'severity': 'medium',
                    'title': f'隐藏表单参数暴露: {name}',
                    'description': (
                        f'HTML 页面中包含名为 "{name}" 的隐藏 input 字段，'
                        f'其值 "{value[:100]}"{"" if len(value) > 100 else ""}'
                        f'可能包含敏感的内部状态信息。'
                    ),
                    'url': '',
                    'evidence': f'<input type="hidden" name="{name}" value="{value}">',
                    'recommendation': (
                        '1. 不要在前端暴露敏感内部参数\n'
                        '2. 如需传输状态信息，使用服务端 Session 或加密 token\n'
                        '3. 移除不需要的隐藏表单字段'
                    ),
                    'cwe': 'CWE-359',
                    'cvss': 5.3,
                })

        # Look for debug parameters in comments (dev artifacts)
        comment_pattern = r'<!--.*?debug.*?-->|<!--.*?test.*?-->|<!--[^\n]*?tmp[^\n]*-->'
        for match in re.finditer(comment_pattern, response_text, re.IGNORECASE):
            if len(match.group(0)) < 200:  # Only flag short debug comments (likely intentional)
                findings.append({
                    'id': 'DEBUG_COMMENT_EXPOSED',
                    'severity': 'low',
                    'title': 'Debug/Test HTML 注释暴露于生产页面',
                    'description': f'页面包含调试/测试相关的 HTML 注释: {match.group(0)[:200]}',
                    'url': '',
                    'evidence': match.group(0),
                    'recommendation': '移除生产环境中的调试注释',
                    'cwe': 'CWE-615',
                    'cvss': 3.7,
                })

        return findings


class ParamDiscoveryHelper:
    """参数发现辅助工具 — 类似 Pentest-Swarm-AI arjun"""

    # Common hidden parameter names to try even if not in URL
    PROBE_PARAMS = [
        'id', 'user_id', 'userId', 'username', 'email', 'token',
        'api_key', 'apiKey', 'key', 'type', 'action', 'page',
        'file', 'path', 'dir', 'folder', 'name', 'lang',
        'redirect', 'url', 'dest', 'next', 'return', 'callback',
        'continue', 'origURL', 'originalUrl', 'forward',
        '_method', '__debug__', '_test', '__proto__',
    ]

    @staticmethod
    def find_additional_params(url: str, page_content: str = "") -> List[Dict]:
        """发现潜在的隐藏参数"""
        findings = []
        parsed = urlparse(url)

        # 1. Look for parameter hints in JavaScript
        if page_content:
            js_param_patterns = [
                r'["\'](\w+?)["\']\s*[:=]\s*["\'][^"\']*param[^"\']*["\']',
                r'(?:param|arg|query|search)[_a-zA-Z0-9]*["\']?\s*[:=]\s*["\']([^"\']+)',
            ]

        # 2. Look for parameter hints in form actions/methods
        if page_content:
            try:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(page_content, 'lxml')
                for form in soup.find_all('form'):
                    action = form.get('action', '')
                    method = form.get('method', 'GET').upper()
                    # Find hidden inputs as potential additional parameters
                    for hidden_input in form.find_all('input', type='hidden'):
                        name = hidden_input.get('name', '')
                        value = hidden_input.get('value', '')
                        if name and any(kw in name.lower() for kw in ['_method', '__', 'csrf', 'token']):
                            findings.append({
                                'id': 'FORM_HIDDEN_PARAM_DISCOVERED',
                                'severity': 'info',
                                'title': f'发现隐藏表单参数: {name}',
                                'description': f'HTML 表单中包含隐藏参数 {name}，可能在所有提交中自动携带。',
                                'url': url,
                                'evidence': f'<input type="hidden" name="{name}" value="{"*" * min(len(value), 50)}">... (total {len(value)} chars)',
                                'recommendation': '确认所有隐藏参数的必要性；移除不需要的参数',
                                'cwe': '',
                                'cvss': 0.0,
                            })

            except Exception:
                pass

        # 3. Look for parameter patterns in URL fragments and JS code
        if page_content:
            js_url_patterns = [
                r'(?:"|\'|`)(\/[^\"]*?\{[^}]*\}[^\"]*?)(?:\"|\'|`)',
            ]

        return findings
