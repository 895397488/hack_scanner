#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hakrawler Wrapper — hakrawler CLI wrapper，爬虫备选引擎（与原生 crawler.py 对照）。

hakrawler 基于 headless-browser 的链接爬取器，输出每行一个 URL/链接，
适合发现隐藏端点、API 路径、JS 资源引用。与现有 crawler.py 互为对照引擎。

集成方式：需要安装 hakrawler
  - Windows: choco install hakrawler  或  https://github.com/hakluke/hakrawler/releases
  - Linux:   手动安装（见 release 页面）
本模块只负责 CLI 调用和结果解析。config.json → tools.hakrawler_path 可指定路径。

Usage:
    from scanners.hakrawler_wrapper import hakrawler_crawl
    result = hakrawler_crawl("https://example.com", depth=2)
"""

import json
import logging
import os
import re
import subprocess
from typing import Optional

logger = logging.getLogger('hakrawler_scanner')


def _find_hakrawler() -> Optional[str]:
    """查找 hakrawler 可执行文件：先 config.json → tools.hakrawler_path，再 PATH"""
    # 1) config.json tools.hakrawler_path
    try:
        cfg_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config.json"))
        if os.path.isfile(cfg_path):
            with open(cfg_path, "r", encoding="utf-8") as f:
                p = (json.load(f).get("tools", {}) or {}).get("hakrawler_path", "")
            if p and os.path.isfile(p):
                return p
    except Exception:
        pass
    # 2) PATH
    for name in ["hakrawler", "hakrawler.exe"]:
        path = None
        if os.name != 'nt':
            import shutil
            path = shutil.which(name)
        else:
            try:
                out = subprocess.run(["where", name], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=5)
                if out.returncode == 0:
                    path = out.stdout.strip().split('\n')[0]
            except Exception:
                pass
        if path and os.path.isfile(path):
            return path
    return None


def hakrawler_crawl(
    target: str,
    depth: int = 1,
    max_time: int = 300,
) -> dict:
    """运行 hakrawler 爬取，返回发现的链接/端点。

    Args:
        target: 目标 URL（如 https://example.com）
        depth: 爬取深度
        max_time: 最大运行时间秒

    Returns:
        {"ok": True, "urls": [...], "total": N, "endpoints": [...], "error": ""}
    """
    hak_path = _find_hakrawler()
    if not hak_path:
        return {
            "ok": False,
            "target": target,
            "urls": [],
            "total": 0,
            "error": "hakrawler 未找到，请安装: choco install hakrawler (Windows) 或见 https://github.com/hakluke/hakrawler/releases",
        }

    cmd = [hak_path, "-url", target, "-depth", str(depth)]

    logger.info(f"hakrawler crawl: {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=max_time + 10)
        output = proc.stdout or proc.stderr or ""

        urls = []
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            # 完整 URL
            if line.startswith("http://") or line.startswith("https://"):
                urls.append(line)
            # 相对路径
            elif line.startswith("/") and " " not in line:
                base = target.rstrip("/")
                urls.append(f"{base}{line}")

        # 提取端点（去重路径部分）
        endpoints = []
        seen = set()
        for u in urls:
            try:
                m = re.search(r'://[^/]+(/[^?#]*)', u)
                ep = m.group(1) if m else u
                if ep and ep not in seen:
                    seen.add(ep)
                    endpoints.append(ep)
            except Exception:
                pass

        return {
            "ok": True,
            "target": target,
            "urls": urls[:1000],
            "total": len(urls),
            "endpoints": endpoints[:500],
            "error": "",
        }

    except subprocess.TimeoutExpired:
        return {"ok": False, "target": target, "urls": [], "total": 0, "error": "hakrawler 超时"}
