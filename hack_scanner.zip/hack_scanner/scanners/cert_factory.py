"""SSL Certificate Factory for MITM Proxy.

Adapted from Acunetix certgen.exe approach: generates a private CA and uses it
to forge fake certificates for arbitrary hostnames on-the-fly.  This module is
conservative by design -- every operation requires an explicit MITM-proxy config
flag.  It follows Python best practices with comprehensive docstrings, type
hints, and defensive error handling.

Classes
-------
MITMCA : Manages a self-signed CA root key + certificate pair.
FakeCertGenerator : Forges server certs matching target hostnames via ``openssl``.
CertCache : In-memory TTL-based cache keyed by hostname.

Key function
------------
generate_for_host(hostname) -> dict(key: PEM, cert: PEM, chain: PEM)
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import shutil
import ssl
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from uuid import uuid4


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CA_KEY_BITS: int = 4096
CA_DAYS: int = 365
CERT_VALIDITY_DAYS: int = 1
CACHE_TTL_SECONDS: int = 300

DEFAULT_CA_DIR_NAME: str = "mitm_ca"


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class HostnameSANs:
    """Subject Alternative Names for a forged certificate.

    Parameters
    ----------
    common_name : str
        The primary ``CN`` for the certificate.
    sans : list[str]
        Additional SAN entries (DNS and IP).
    """

    common_name: str
    sans: list[str] = field(default_factory=list)

    def to_openssl_san_string(self) -> str:
        """Build an OpenSSL-compatible ``subjectAltName`` string."""
        parts: list[str] = []
        for entry in self.sans:
            if _is_ip(entry):
                parts.append(f"IP:{entry}")
            else:
                parts.append(f"DNS:{entry}")
        # Always add the CN itself as a SAN to satisfy strict validators.
        if not any(s.startswith("DNS:") or s.startswith("IP:") for s in parts):
            parts.insert(0, f"DNS:{self.common_name}")
        return ",".join(parts)


# ---------------------------------------------------------------------------
# MITMCA
# ---------------------------------------------------------------------------

class MITMCA:
    """Manage a self-signed CA root key + certificate pair.

    The CA is stored as PEM files on disk (key then cert).  On initialisation
    the instance looks for existing files in ``ca_dir`` and loads them; if they
    do not exist it generates a brand-new RSA-4096 self-signed CA valid for
    ``CA_DAYS`` days.

    Parameters
    ----------
    ca_dir : str | Path
        Directory that holds the ``ca-key.pem`` and ``ca-cert.pem`` files.
    passphrase : str | None
        Optional password protecting the private key on disk.
    """

    def __init__(
        self,
        ca_dir: str | Path = DEFAULT_CA_DIR_NAME,
        passphrase: str | None = None,
    ) -> None:
        self.ca_dir = Path(ca_dir).resolve()
        self._passphrase = passphrase
        self._key_path = self.ca_dir / "ca-key.pem"
        self._cert_path = self.ca_dir / "ca-cert.pem"

        # Public convenience attrs -- populated after init is complete.
        self.key_pem: str = ""
        self.cert_pem: str = ""
        self.fingerprint_sha256: str = ""

        self._load_or_generate()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _load_or_generate(self) -> None:
        """Load existing CA files or generate a new one."""
        if self._key_path.exists() and self._cert_path.exists():
            self._load_existing()
        else:
            self._generate_new()

    def _load_existing(self) -> None:
        """Read PEM key and cert from disk."""
        self.key_pem = self._key_path.read_text(encoding="utf-8").strip()
        self.cert_pem = self._cert_path.read_text(encoding="utf-8").strip()
        self.fingerprint_sha256 = _sha256_of_pem(self.cert_pem)

    def _generate_new(self) -> None:
        """Generate a new RSA-4096 self-signed CA and persist to disk."""
        # Ensure directory exists with restrictive permissions.
        self.ca_dir.mkdir(parents=True, exist_ok=True)
        os.chmod(self.ca_dir, 0o700)

        cmd: list[str] = [
            "openssl",
            "req",
            "-x509",
            "-newkey",
            f"rsa:{CA_KEY_BITS}",
            "-keyout", str(self._key_path),
            "-out", str(self._cert_path),
            "-days", str(CA_DAYS),
            "-nodes",  # unencrypted (passphrase handling below).
            "-subj", "/CN=MITM-Proxy-Certificate-Authority/O=MITM-Proxy/C=XX",
        ]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"Failed to generate CA key+cert: {result.stderr.strip()}"
            )

        # Apply passphrase protection if requested.
        if self._passphrase:
            self._protect_key_with_passphrase()

        self.key_pem = self._key_path.read_text(encoding="utf-8").strip()
        self.cert_pem = self._cert_path.read_text(encoding="utf-8").strip()
        self.fingerprint_sha256 = _sha256_of_pem(self.cert_pem)

    def _protect_key_with_passphrase(self) -> None:
        """Re-encrypt the unencrypted key with ``self._passphrase``."""
        protected_path = self.ca_dir / "ca-key-protected.pem"
        cmd: list[str] = [
            "openssl",
            "rsa",
            "-in", str(self._key_path),
            "-aes-256-cbc",
            "-out", str(protected_path),
            "-passout", f"pass:{self._passphrase}",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            protected_path.replace(self._key_path)
            self._key_path.chmod(0o600)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def key_path(self) -> Path:
        """Path to the CA private key PEM file."""
        return self._key_path

    @property
    def cert_path(self) -> Path:
        """Path to the CA certificate PEM file."""
        return self._cert_path

    def rotate(self) -> None:
        """Delete current CA files and generate a fresh pair."""
        for p in (self._key_path, self._cert_path):
            if p.exists():
                p.unlink()
        self.key_pem = ""
        self.cert_pem = ""
        self.fingerprint_sha256 = ""
        self._generate_new()

    def is_expired(self) -> bool:
        """Return ``True`` when the CA certificate has passed its NotAfter date."""
        try:
            cert = _pem_to_cert(self.cert_pem)
            now = datetime.datetime.now(datetime.timezone.utc)
            return now >= cert.not_valid_after_utc
        except Exception:
            # Best-effort; default to not expired on parse failure.
            return False

    def to_dict(self) -> dict:
        """Serialise the CA state into a JSON-friendly dictionary."""
        return {
            "ca_dir": str(self.ca_dir),
            "key_pem": self.key_pem,
            "cert_pem": self.cert_pem,
            "fingerprint_sha256": self.fingerprint_sha256,
        }

    @classmethod
    def from_dict(cls, data: dict) -> MITMCA:
        """Rebuild an MITMCA instance from a :meth:`to_dict` payload."""
        instance = cls(ca_dir=data["ca_dir"])
        instance.key_pem = data["key_pem"]
        instance.cert_pem = data["cert_pem"]
        instance.fingerprint_sha256 = data["fingerprint_sha256"]
        return instance


# ---------------------------------------------------------------------------
# FakeCertGenerator
# ---------------------------------------------------------------------------

class FakeCertGenerator:
    """Forge server certificates matching target hostnames.

    Uses ``subprocess`` calls to OpenSSL so that every forged certificate has
    a complete key pair, CSR, and CA-signed cert -- just like a real TLS
    negotiation would produce.

    Parameters
    ----------
    ca : MITMCA
        The active MITM CA instance used for signing forged certs.
    validity_days : int
        Number of days the forged certificate should remain valid (default 1).
    """

    def __init__(
        self,
        ca: MITMCA,
        validity_days: int = CERT_VALIDITY_DAYS,
    ) -> None:
        if not shutil.which("openssl"):
            raise RuntimeError("openssl binary not found on PATH; required for cert generation")
        self.ca = ca
        self.validity_days = validity_days

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_for_host(
        self,
        hostname: str,
        sans: Optional[list[str]] = None,
        renew_if_expired: bool = True,
    ) -> dict:
        """Generate a CA-signed certificate for *hostname*.

        Parameters
        ----------
        hostname : str
            The target hostname (used as CN and first SAN).
        sans : list[str] | None
            Additional Subject Alternative Names.
        renew_if_expired : bool
            If ``True`` the cert is regenerated when the cache entry has
            expired or the underlying CA was rotated.

        Returns
        -------
        dict
            ``{"key": <PEM>, "cert": <PEM>, "chain": <PEM>}``
        """
        san_data = HostnameSANs(common_name=hostname, sans=sans or [])

        # Check cache first.
        cached = _cache.get(hostname)
        if cached and not renew_if_expired:
            return cached

        # Auto-renew when CA has been rotated or cert is expired.
        if self.ca.is_expired() or (cached and _is_cert_expired(cached["cert"])):
            # Regenerate the entire chain from the current CA.
            return self._build_from_ca(hostname, san_data)

        if cached:
            return cached

        return self._build_from_ca(hostname, san_data)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_from_ca(self, hostname: str, san_data: HostnameSANs) -> dict:
        """Run the OpenSSL pipeline to create and sign a new cert."""
        with tempfile.TemporaryDirectory(prefix="mitm_cert_") as tmpdir:
            tmppath = Path(tmpdir)

            server_key = tmppath / "server-key.pem"
            server_csr = tmppath / "server.csr"
            server_cert = tmppath / "server-cert.pem"

            # 1. Generate a temporary RSA key for the server (2048 is fine;
            #    the trust anchor is the CA key).
            subprocess.run(
                [
                    "openssl", "genrsa", str(server_key), "2048",
                ],
                capture_output=True, text=True, timeout=30,
            )

            # 2. Build a CSR with matching CN + SANs.
            san_section = f"subjectAltName = {san_data.to_openssl_san_string()}"
            subj = f"/CN={hostname}/O=MITM-Proxy/C=XX"
            cmd_csr: list[str] = [
                "openssl", "req", "-new",
                "-key", str(server_key),
                "-out", str(server_csr),
                "-subj", subj,
            ]
            subprocess.run(cmd_csr, capture_output=True, text=True, timeout=30)

            # 3. Sign the CSR with the CA key.
            ext_file = tmppath / "v3.ext"
            ext_file.write_text(f"subjectAltName = {san_data.to_openssl_san_string()}\n", encoding="utf-8")

            cmd_sign: list[str] = [
                "openssl", "x509", "-req",
                "-in", str(server_csr),
                "-CA", str(self.ca.cert_path),
                "-CAkey", str(self.ca.key_path),
                "-CAcreateserial",
                "-out", str(server_cert),
                "-days", str(self.validity_days),
                "-extfile", str(ext_file),
            ]
            result = subprocess.run(cmd_sign, capture_output=True, text=True, timeout=30)
            if result.returncode != 0:
                raise RuntimeError(f"openssl sign failed: {result.stderr.strip()}")

            key_pem = server_key.read_text(encoding="utf-8").strip()
            cert_pem = server_cert.read_text(encoding="utf-8").strip()
            chain_pem = cert_pem + "\n" + self.ca.cert_pem

            payload: dict = {"key": key_pem, "cert": cert_pem, "chain": chain_pem}
            _cache.store(hostname, payload)
            return payload


# ---------------------------------------------------------------------------
# CertCache  (module-level singleton)
# ---------------------------------------------------------------------------

class _CertEntry:
    """Internal cache entry with TTL tracking."""

    __slots__ = ("payload", "expires_at")

    def __init__(self, payload: dict, ttl_seconds: int) -> None:
        self.payload = payload
        self.expires_at = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(
            seconds=ttl_seconds
        )

    def is_valid(self) -> bool:
        return datetime.datetime.now(datetime.timezone.utc) < self.expires_at


class CertCache:
    """TTL-based in-memory certificate cache keyed by hostname.

    This cache is also exposed as the module-level singleton ``_cache`` so that
    ``FakeCertGenerator`` instances share state without needing an explicit
    parameter passed through every call site.

    Parameters
    ----------
    ttl_seconds : int
        Seconds before a cached entry expires (default 300).
    max_entries : int
        Soft limit; when exceeded the oldest entry is evicted (default 1024).
    """

    def __init__(self, ttl_seconds: int = CACHE_TTL_SECONDS, max_entries: int = 1024) -> None:
        self._ttl = ttl_seconds
        self._max_entries = max_entries
        self._store: dict[str, _CertEntry] = {}

    # -- public ----------------------------------------------------------

    def get(self, hostname: str) -> Optional[dict]:
        """Return the cached payload for *hostname*, or ``None``."""
        entry = self._store.get(hostname)
        if entry is None or not entry.is_valid():
            return None
        return entry.payload

    def store(self, hostname: str, payload: dict) -> None:
        """Insert or refresh the cached payload for *hostname*."""
        # Evict oldest if we have hit the limit.
        if len(self._store) >= self._max_entries:
            oldest_key = min(self._store, key=lambda k: self._store[k].expires_at)
            del self._store[oldest_key]
        self._store[hostname] = _CertEntry(payload, self._ttl)

    def invalidate(self, hostname: str) -> bool:
        """Remove a single entry.  Returns ``True`` if an entry existed."""
        return self._store.pop(hostname, None) is not None

    def clear(self) -> None:
        """Remove all cached entries."""
        self._store.clear()

    @property
    def size(self) -> int:
        return len(self._store)


# Module-level singleton
_cache = CertCache()


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------

def generate_for_host(
    hostname: str,
    ca_dir: str | Path = DEFAULT_CA_DIR_NAME,
    passphrase: Optional[str] = None,
    sans: Optional[list[str]] = None,
) -> dict:
    """High-level helper: create (or fetch cached) a full cert bundle for *hostname*.

    Parameters
    ----------
    hostname : str
        Target hostname.
    ca_dir : str | Path
        Directory to store / load the CA key+cert pair.
    passphrase : str | None
        Optional passphrase protecting the CA private key.
    sans : list[str] | None
        Additional SAN entries.

    Returns
    -------
    dict
        ``{"key": <PEM>, "cert": <PEM>, "chain": <PEM>}``

    Example
    -------
    >>> result = generate_for_host("example.com")
    >>> result["key"]   # str (PEM)
    >>> result["cert"]  # str (PEM)
    >>> result["chain"] # str (PEM, cert + CA root)
    """
    ca = MITMCA(ca_dir=ca_dir, passphrase=passphrase)
    generator = FakeCertGenerator(ca)
    return generator.generate_for_host(hostname, sans=sans, renew_if_expired=True)


# ---------------------------------------------------------------------------
# Internal utilities
# ---------------------------------------------------------------------------

def _sha256_of_pem(pem: str) -> str:
    """Return hex SHA-256 digest of the raw PEM text."""
    return hashlib.sha256(pem.encode("utf-8")).hexdigest()


def _pem_to_cert(pem: str) -> ssl.Certificate:
    """Wrap a PEM string into an ``ssl.Certificate`` for inspecting dates.

    Raises
    ------
    ValueError
        If the PEM cannot be parsed as an X.509 certificate.
    """
    import OpenSSL  # type: ignore[import-untyped] -- cryptography provides it on import.
    from cryptography import x509
    data = b"-----BEGIN CERTIFICATE-----\n" + pem.encode().strip().encode("latin-1").replace(b"\r\n", b"\n") + b"\n-----END CERTIFICATE-----\n"
    return x509.load_pem_x509_certificate(data)


def _is_cert_expired(cert_pem: str) -> bool:
    """Check whether a PEM certificate has passed its ``NotAfter``."""
    try:
        cert = _pem_to_cert(cert_pem)
        now = datetime.datetime.now(datetime.timezone.utc)
        return now >= cert.not_valid_after_utc  # type: ignore[union-attr]
    except Exception:
        return False


def _is_ip(addr: str) -> bool:
    """Naive IPv4/IPv6 detection for SAN construction."""
    try:
        import ipaddress
        ipaddress.ip_address(addr)
        return True
    except ValueError:
        return False


# ---------------------------------------------------------------------------
# CLI entry-point (useful for manual testing / debugging)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    host = sys.argv[1] if len(sys.argv) > 1 else "example.com"
    bundle = generate_for_host(host)
    print(f"Generated certificate bundle for {host}:")
    print(f"  key   : {len(bundle['key'])} bytes")
    print(f"  cert  : {len(bundle['cert'])} bytes")
    print(f"  chain : {len(bundle['chain'])} bytes")
