#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Swarm 辅助工具箱 — 把项目成熟检测模块暴露给 LLM 按需调用
=====================================================================

swarm_tool_binders 的 6 个核心工具是"通用积木"（探测/分类/报告），
本模块把 hack_scanner 里已经调教好的**专用检测器**再包一层工具，
让自适应模式的 LLM 可以指名调用，而不必自己用裸 HTTP 从零猜方法：

    run_detector   对指定端点跑单个成熟检测器（url_scanner 21 个检测器
                   + jwt/graphql 检测器，共 24 个，按名字指名）
    scan_endpoint  对单端点跑 URLScanner 全流程（重火力，300s 墙钟上限）
    dir_bust       纯 Python 目录爆破（DirBuster 内置 ~90 路径，无需外部工具）
    ext_scan       外部工具 wrapper（dirsearch/gobuster/dirb/nikto/ffuf/hakrawler，
                   本机未安装时返回安装提示并建议替代工具）
    consult_playbook  读取内置 playbook 库（OWASP/Bug Bounty/API/CTF/…）的
                   阶段战略清单（纯数据读取，不执行；LLM 拿清单后用自有工具落地）

设计原则（对应用户诉求"模块达到辅助作用，不强制按扫描器步骤"）:
    - 全部是【可选工具】：LLM 自主决定何时用、用哪个；不用则与之前行为一致
    - 不改变模板扫描主链路：只 import url_scanner 的类做调用，零修改
    - 沿用核心工具同一套安全策略：scope 白名单硬拒（回灌解释）、
      限速（检测器内部 _safe_request / 限速器）、输出 JSON 安全截断
    - 重型操作（scan_endpoint / dir_bust）加墙钟上限：orchestrator 是
      同步执行工具且无超时，跑飞会卡死整个 ReAct 循环

execute 契约（swarm_orchestrator.py:133）:
    execute(args_string) -> (result_string, error_or_None)
"""

import logging
import os
import sys
import threading
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger('swarm_aux_tools')

# 直接运行本文件时保证项目根目录在 sys.path（包导入场景下无副作用）
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# 复用核心工具层的上下文与辅助函数（无循环 import 风险：
# swarm_tool_binders 在 register_campaign_tools 函数内部才 import 本模块）
from scanners.swarm_tool_binders import (
    CampaignContext,
    _err,
    _host_from_url,
    _in_scope,
    _json_safe_dumps,
    _parse_args,
)

# ---------------------------------------------------------------------------
# 截断 / 超时参数
# ---------------------------------------------------------------------------
DETECTOR_MAX_CHARS = 8192      # run_detector 输出上限
SCAN_MAX_CHARS = 16384         # scan_endpoint 输出上限（全流程结果更多）
DIRBUST_MAX_CHARS = 8192
EXT_MAX_CHARS = 8192

# 墙钟上限需覆盖项目限速（config rate_limit per_domain_sec=1.0 → 每域 ~1 req/s）：
# dir_bust 内置 ~90 路径 ≈ 100s；全流程 ≈ 150-300s。上限低于实际耗时 = 工具必超时降级。
_SCAN_TIMEOUT = 300            # scan_endpoint 墙钟上限（秒）
_DIRBUST_TIMEOUT = 180         # dir_bust 墙钟上限（秒）
_EXT_MAX_TIME_CAP = 180        # ext_scan 传给外部 wrapper 的 max_time 上限（秒）
_HTTP_FETCH_TIMEOUT = 15       # 为 resp 类检测器抓取页面的单请求超时


# ---------------------------------------------------------------------------
# 检测器注册表
# ---------------------------------------------------------------------------
# kind 含义（决定如何取响应、如何调用）:
#   "url"       Cls.method(url)            — 纯 URL 驱动（内部自己发请求/限速）
#   "resp"      Cls.method(url, resp)      — 需要一个基础 GET 响应
#   "headers"   Cls.method(resp.headers)   — 只用响应头
#   "content"   Cls.method(resp.text)      — 用响应体
#   "content2"  Cls.method(resp.text, url) — 用响应体 + URL
#   "ssl"       Cls.check(url) -> dict     — 返回 dict 而非 List[VulnFinding]
#   "ext"       scanners 包内函数 (url, "")— 自带限速的独立检测器
DETECTOR_REGISTRY: Dict[str, Tuple[str, str, str]] = {
    # --- 注入类（url 驱动） ---
    "sqli":            ("url", "SQLiDetector", "detect"),
    "sqli_blind":      ("url", "SQLiBlindDetector", "detect"),
    "xss":             ("url", "XSSDetector", "detect"),
    "ssrf":            ("url", "SSRFDetector", "detect"),
    "ssrf_enhanced":   ("url", "SSRFDetectorEnhanced", "detect"),
    "lfi":             ("url", "LFIDetector", "detect"),
    "xxe":             ("url", "XXEDetector", "detect"),
    "deserialization": ("url", "DeserializationDetector", "detect"),
    # --- 配置/逻辑类（resp 驱动） ---
    "cors":            ("resp", "CORSChecker", "check"),
    "unauthorized":    ("resp", "UnauthorizedAccessChecker", "check"),
    "auth_bypass":     ("resp", "AuthorizationBypassChecker", "check"),
    "csrf":            ("resp", "CSRFTokenChecker", "check"),
    "password_reset":  ("resp", "PasswordResetVulnerabilityDetector", "check"),
    "business_logic":  ("resp", "BusinessLogicChecker", "check"),
    # --- 头/内容类 ---
    "headers":         ("headers", None, None),          # HeaderChecker + ExtendedHeaderChecker
    "sensitive_data":  ("content", "SensitiveDataDetector", "detect"),
    "cms_enum":        ("content2", "CMSEnumDetector", "detect"),
    "ssl":             ("ssl", "SSLChecker", "check"),
    # --- 端点/指纹类（url 驱动） ---
    "http_methods":    ("url", "HTTPMethodsChecker", "check"),
    "dvcs_leak":       ("url", "DVCSLeakDetector", "detect"),
    "openapi":         ("url", "OpenAPIDiscovery", "detect"),
    "file_upload":     ("url", "FileUploadDetector", "detect"),
    # --- scanners/ 包独立检测器 ---
    "jwt":             ("ext", "scanners.jwt_detector", "JWTAnalyzer.detect"),
    "graphql":         ("ext", "scanners.graphql_detector", "GraphQLSecurityDetector.detect"),
}

DETECTOR_NAMES = ", ".join(sorted(DETECTOR_REGISTRY.keys()))


def _fetch_base(url: str):
    """为 resp 类检测器抓一个基础 GET 响应（走 url_scanner 的全局限速包裹器）。"""
    import url_scanner
    resp = url_scanner._safe_request(url, timeout=_HTTP_FETCH_TIMEOUT, allow_redirects=True)
    if resp is None:
        # 限速器缺失或配额拦截 → 退回裸 requests（仍受 import 时的全局包裹器约束）
        import requests as req
        resp = req.get(url, timeout=_HTTP_FETCH_TIMEOUT, allow_redirects=True,
                       headers={"User-Agent": "Mozilla/5.0 (hack-scanner-aux)"})
    return resp


def _normalize_findings(obj: Any) -> list:
    """把 List[VulnFinding] / List[dict] 统一成 dict 列表（截断到 40 条）。"""
    out = []
    for f in (obj or [])[:40]:
        if hasattr(f, "to_dict"):
            d = f.to_dict()
        elif isinstance(f, dict):
            d = f
        else:
            d = {"raw": str(f)[:300]}
        # 防超大证据字段撑爆上下文
        for k in ("evidence", "description", "detail", "raw_output"):
            v = d.get(k)
            if isinstance(v, str) and len(v) > 1500:
                d[k] = v[:1500] + "…[truncated]"
        out.append(d)
    return out


# ---------------------------------------------------------------------------
# 墙钟上限执行器
# ---------------------------------------------------------------------------
def _bounded_run(fn, timeout: float) -> Tuple[Optional[Any], Optional[BaseException], bool]:
    """在 daemon 线程里跑 fn，墙钟上限 timeout。

    返回 (result, error, timed_out)。超时后线程被放弃（daemon，自然结束），
    不阻塞 ReAct 循环。
    """
    box: Dict[str, Any] = {}

    def target() -> None:
        try:
            box["result"] = fn()
        except BaseException as exc:  # noqa: BLE001 — 跨线程必须全捕获
            box["error"] = exc

    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(timeout)
    if t.is_alive():
        return None, None, True
    err = box.get("error")
    if err is not None:
        return None, err, False
    return box.get("result"), None, False


# ---------------------------------------------------------------------------
# 1. run_detector — 指名跑单个成熟检测器
# ---------------------------------------------------------------------------
def _make_run_detector(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        url = str(args.get("url") or ctx.target_url or "").strip()
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        detector = str(args.get("detector") or "").strip().lower()
        if not detector:
            return _err(
                f"ERROR: run_detector requires 'detector'. Available: {DETECTOR_NAMES}. "
                f"Example: {{\"url\": \"http://t/login?u=1\", \"detector\": \"sqli\"}}")
        spec = DETECTOR_REGISTRY.get(detector)
        if spec is None:
            return _err(
                f"ERROR: unknown detector '{detector}'. Available: {DETECTOR_NAMES}.")

        host = _host_from_url(url)
        if not _in_scope(host, ctx):
            allowed = ", ".join(sorted(h for h in ctx.scope_hosts
                                       if h not in ("localhost", "127.0.0.1", "::1", "0.0.0.0")))
            return _err(f"ERROR: BLOCKED — host '{host}' is outside the authorized scope. Allowed: {allowed}.")

        kind, class_name, method_name = spec

        try:
            if kind == "ext":
                _, module_path, func_path = spec
                module = __import__(module_path, fromlist=[func_path.split(".")[0]])
                fn = module
                for part in func_path.split("."):
                    fn = getattr(fn, part)
                findings = fn(url, "")
            elif kind == "headers":
                # headers 特殊：两个检测器都只吃 resp.headers，无对应 class_name
                import url_scanner
                resp = _fetch_base(url)
                if resp is None:
                    return _err(f"ERROR: cannot fetch base page {url} (timeout/blocked).")
                hdrs = dict(resp.headers)
                findings = list(url_scanner.HeaderChecker.check(hdrs))
                findings += list(url_scanner.ExtendedHeaderChecker.check(hdrs))
            else:
                import url_scanner
                cls = getattr(url_scanner, class_name)
                m = getattr(cls, method_name)
                if kind == "url":
                    findings = m(url)
                elif kind == "resp":
                    resp = _fetch_base(url)
                    if resp is None:
                        return _err(f"ERROR: cannot fetch base page {url} (timeout/blocked). Try http_probe to confirm reachability first.")
                    findings = m(url, resp)
                elif kind == "content":
                    resp = _fetch_base(url)
                    if resp is None:
                        return _err(f"ERROR: cannot fetch base page {url} (timeout/blocked).")
                    findings = m(resp.text or "")
                elif kind == "content2":
                    resp = _fetch_base(url)
                    if resp is None:
                        return _err(f"ERROR: cannot fetch base page {url} (timeout/blocked).")
                    findings = m(resp.text or "", url)
                elif kind == "ssl":
                    if url.startswith("http://"):
                        return (_json_safe_dumps({
                            "detector": detector, "url": url, "findings": [],
                            "note": "plain http target — SSL check not applicable",
                        }, DETECTOR_MAX_CHARS), None)
                    info = m(url)
                    return (_json_safe_dumps({
                        "detector": detector, "url": url,
                        "ssl": info if isinstance(info, dict) else {"raw": str(info)[:800]},
                    }, DETECTOR_MAX_CHARS), None)
                else:  # pragma: no cover — 注册表约束下不可达
                    return _err(f"ERROR: unsupported detector kind '{kind}' for '{detector}'.")

            findings_list = _normalize_findings(findings)
            out = {
                "detector": detector,
                "url": url,
                "count": len(findings_list),
                "findings": findings_list,
            }
            if not findings_list:
                out["note"] = "no findings from this detector — either clean, or the detector needs specific inputs (e.g. sqli needs a query param)."
            return (_json_safe_dumps(out, DETECTOR_MAX_CHARS), None)
        except Exception as exc:
            return _err(f"ERROR: detector '{detector}' failed: {type(exc).__name__}: {str(exc)[:200]}")

    return _ToolDef(
        "run_detector",
        ("Run ONE mature vulnerability detector from hack_scanner's rule engine against a specific endpoint. "
         f"Available detectors: {DETECTOR_NAMES}. "
         "Prefer this over hand-crafted http_probe payloads when you want a specific vuln class "
         "(e.g. sqli/xss/lfi/xxe/csrf/auth_bypass/jwt/graphql) checked with the project's tuned logic."),
        {
            "url": "endpoint URL to test (must be within campaign scope; include query params when testing injection)",
            "detector": f"detector name, one of: {DETECTOR_NAMES}",
        },
        execute,
    )


# ---------------------------------------------------------------------------
# 2. scan_endpoint — URLScanner 全流程（重火力）
# ---------------------------------------------------------------------------
def _make_scan_endpoint(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        url = str(args.get("url") or ctx.target_url or "").strip()
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        host = _host_from_url(url)
        if not _in_scope(host, ctx):
            allowed = ", ".join(sorted(h for h in ctx.scope_hosts
                                       if h not in ("localhost", "127.0.0.1", "::1", "0.0.0.0")))
            return _err(f"ERROR: BLOCKED — host '{host}' is outside the authorized scope. Allowed: {allowed}.")

        def job():
            import url_scanner
            scanner = url_scanner.URLScanner()
            return scanner.scan(url)

        result, err, timed_out = _bounded_run(job, _SCAN_TIMEOUT)
        if timed_out:
            return _err(
                f"ERROR: full scan exceeded {_SCAN_TIMEOUT}s and was cut off. "
                "Switch to targeted checks: run_detector (one vuln class at a time) and dir_bust.")
        if err is not None:
            return _err(f"ERROR: scan_endpoint failed: {type(err).__name__}: {str(err)[:200]}")

        out = {
            "target": url,
            "finding_count": result.finding_count,
            "critical": result.critical_count,
            "high": result.high_count,
            "findings": _normalize_findings(result.findings),
            "technologies": (result.technologies or [])[:20],
            "subdomains": (result.subdomains or [])[:20],
            "dir_bust_results": (result.dir_bust_results or [])[:20],
            "notes": (result.notes or [])[:10],
            "failure_log": (result.failure_log or [])[:10],
        }
        return (_json_safe_dumps(out, SCAN_MAX_CHARS), None)

    return _ToolDef(
        "scan_endpoint",
        ("Run the FULL hack_scanner pipeline (all detectors: SSL/headers/CORS/SQLi/XSS/SSRF/LFI/XXE/"
         "upload/deserialization/dir-bust/…) against one endpoint. Heavy: takes up to "
         f"{_SCAN_TIMEOUT}s. Use for a final sweep of a promising endpoint, not as a first step."),
        {"url": "endpoint URL (must be within campaign scope)"},
        execute,
    )


# ---------------------------------------------------------------------------
# 3. dir_bust — 纯 Python 目录爆破
# ---------------------------------------------------------------------------
def _make_dir_bust(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        url = str(args.get("url") or ctx.target_url or "").strip()
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        host = _host_from_url(url)
        if not _in_scope(host, ctx):
            allowed = ", ".join(sorted(h for h in ctx.scope_hosts
                                       if h not in ("localhost", "127.0.0.1", "::1", "0.0.0.0")))
            return _err(f"ERROR: BLOCKED — host '{host}' is outside the authorized scope. Allowed: {allowed}.")

        def job():
            import url_scanner
            return url_scanner.DirBuster.bust(url)

        results, err, timed_out = _bounded_run(job, _DIRBUST_TIMEOUT)
        if timed_out:
            return _err(
                f"ERROR: dir_bust exceeded {_DIRBUST_TIMEOUT}s and was cut off. "
                "Instead, http_probe the most promising paths yourself (admin/.env/api/swagger/backup).")
        if err is not None:
            return _err(f"ERROR: dir_bust failed: {type(err).__name__}: {str(err)[:200]}")

        rows = [r for r in (results or []) if isinstance(r, dict)]
        out = {
            "target": url,
            "checked_paths": len(rows),
            "results": rows[:40],
        }
        return (_json_safe_dumps(out, DIRBUST_MAX_CHARS), None)

    return _ToolDef(
        "dir_bust",
        ("Enumerate likely paths/endpoints on a host with the built-in pure-Python wordlist "
         "(~90 paths: admin/.env/.git/api/swagger/actuator/backup/…). No external tool needed. "
         f"Up to {_DIRBUST_TIMEOUT}s."),
        {"url": "base URL of the host to bust paths on (must be within campaign scope)"},
        execute,
    )


# ---------------------------------------------------------------------------
# 4. ext_scan — 外部工具 wrapper
# ---------------------------------------------------------------------------
_EXT_TOOLS = {
    "dirsearch": "dirsearch (pip install dirsearch)",
    "gobuster": "gobuster (go install github.com/OWASP/gobuster)",
    "dirb": "dirb",
    "nikto": "nikto (cpan/apt/choco install)",
    "ffuf": "ffuf (go install github.com/ffuf/ffuf)",
    "hakrawler": "hakrawler (go install github.com/hakankeller/hakrawler)",
}


def _make_ext_scan(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        url = str(args.get("url") or ctx.target_url or "").strip()
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
        tool = str(args.get("tool") or "").strip().lower()
        if tool not in _EXT_TOOLS:
            return _err(
                f"ERROR: ext_scan 'tool' must be one of: {', '.join(sorted(_EXT_TOOLS))}. "
                "If the tool is not installed locally it will say so — use dir_bust (built-in) instead.")
        host = _host_from_url(url)
        if not _in_scope(host, ctx):
            allowed = ", ".join(sorted(h for h in ctx.scope_hosts
                                       if h not in ("localhost", "127.0.0.1", "::1", "0.0.0.0")))
            return _err(f"ERROR: BLOCKED — host '{host}' is outside the authorized scope. Allowed: {allowed}.")

        max_time = int(args.get("max_time") or 120)
        max_time = max(30, min(max_time, _EXT_MAX_TIME_CAP))
        wordlist = str(args.get("wordlist") or "")
        extensions = str(args.get("extensions") or "")

        def job():
            if tool == "nikto":
                from scanners.nikto_wrapper import nikto_web_scan
                return nikto_web_scan(url, threads=20, all_checks=False, max_time=max_time)
            if tool == "dirsearch":
                from scanners.dirsearch_wrapper import dirsearch_scan
                return dirsearch_scan(url, wordlist=wordlist, extensions=extensions, max_time=max_time)
            if tool == "dirb":
                from scanners.dirb_wrapper import dirb_scan
                return dirb_scan(url, wordlist=wordlist, threads=10, max_time=max_time)
            if tool == "gobuster":
                from scanners.gobuster_wrapper import gobuster_dir
                return gobuster_dir(url, wordlist=wordlist, threads=10,
                                    extensions=extensions, max_time=max_time)
            if tool == "ffuf":
                from scanners.web_fuzzer import fuzz_paths
                return fuzz_paths(url, wordlist=None, threads=40, max_time=max_time)
            if tool == "hakrawler":
                from scanners.hakrawler_wrapper import hakrawler_crawl
                return hakrawler_crawl(url, depth=1, max_time=max_time)
            raise ValueError(f"unhandled ext tool: {tool}")  # pragma: no cover

        result, err, timed_out = _bounded_run(job, max_time + 15)
        if err is not None:
            return _err(f"ERROR: {tool} failed: {type(err).__name__}: {str(err)[:200]}")
        if timed_out or not isinstance(result, dict):
            return _err(f"ERROR: {tool} timed out. Use dir_bust (built-in pure-Python) instead.")

        ok = bool(result.get("ok"))
        findings = result.get("findings") or []
        out = {
            "tool": tool,
            "target": url,
            "ok": ok,
            "findings_count": len(findings) if isinstance(findings, list) else 0,
            "findings": (findings[:60] if isinstance(findings, list) else findings),
        }
        if not ok:
            out["hint"] = (f"{tool} is not available on this machine "
                           f"({_EXT_TOOLS[tool]}). Use dir_bust or http_probe instead.")
        return (_json_safe_dumps(out, EXT_MAX_CHARS), None)

    return _ToolDef(
        "ext_scan",
        ("Run an EXTERNAL scanning tool (only if installed on this machine): "
         f"{', '.join(sorted(_EXT_TOOLS))}. "
         "Directory brute-force / spider / web-vuln CLI engines. If the tool is missing, "
         "the result says so — fall back to dir_bust (built-in)."),
        {
            "tool": f"one of: {', '.join(sorted(_EXT_TOOLS))}",
            "url": "target URL (must be within campaign scope)",
            "extensions": "optional file extensions, e.g. 'php,html,jsp'",
            "wordlist": "optional wordlist file path (default: tool built-in)",
            "max_time": "optional seconds, 30-180 (default 120)",
        },
        execute,
    )


# ---------------------------------------------------------------------------
# 5. consult_playbook — 把内置 playbook 的战略清单暴露给 LLM（纯读取，零执行）
# ---------------------------------------------------------------------------
PLAYBOOK_MAX_CHARS = 8192


def _make_consult_playbook(ctx: CampaignContext):
    def execute(args_string: str) -> tuple:
        args = _parse_args(args_string)
        action = str(args.get("action") or "list").strip().lower()
        if action not in ("list", "get"):
            return _err("ERROR: consult_playbook 'action' must be 'list' or 'get'. "
                        "list = show available playbooks; get = fetch one playbook's phase checklist.")

        try:
            from scanners.swarm_playbooks import get_all_playbooks, list_playbooks
        except Exception as exc:
            return _err(f"ERROR: playbook library unavailable: {type(exc).__name__}: {str(exc)[:200]}")

        if action == "list":
            try:
                items = list_playbooks()
            except Exception as exc:
                return _err(f"ERROR: list_playbooks failed: {type(exc).__name__}: {str(exc)[:200]}")
            out = {
                "playbooks": [
                    {"id": p.get("id"), "name": p.get("name"),
                     "description": str(p.get("description", ""))[:200],
                     "phases": p.get("phase_count"), "tags": p.get("tags", [])}
                    for p in items[:20]
                ],
                "hint": "call consult_playbook with {action:'get', name:'<id>'} to get a playbook's phase checklist, "
                        "then execute its steps with your own tools (http_probe / run_detector / exploit / dir_bust).",
            }
            return (_json_safe_dumps(out, PLAYBOOK_MAX_CHARS), None)

        name = str(args.get("name") or args.get("id") or "").strip()
        if not name:
            ids = [p.get("id") for p in list_playbooks()][:20]
            return _err(f"ERROR: consult_playbook get requires 'name' (playbook id). Available: {', '.join(i for i in ids if i)}")

        all_pb = get_all_playbooks()
        resolved_id = name
        pb = all_pb.get(name)
        if pb is None:
            # 模糊匹配：id 前缀 / id 包含 / 名称包含（小模型常记不全 id）
            cands = [k for k in all_pb if k.startswith(name) or name in k.lower()
                     or name.lower() in str(all_pb[k].get("name", "")).lower()]
            if len(cands) == 1:
                resolved_id, pb = cands[0], all_pb[cands[0]]
            elif cands:
                return _err(f"ERROR: ambiguous playbook '{name}'. Did you mean: {', '.join(cands)}")
            else:
                ids = list(all_pb.keys())[:20]
                return _err(f"ERROR: no playbook '{name}'. Available: {', '.join(ids)} "
                            "(or call with action:'list')")

        # 阶段清单：把 playbook 的战略分解成 LLM 可执行的任务序列
        phases_out = []
        for i, ph in enumerate(list(pb.get("phases", []))[:15], 1):
            tools = ph.get("tools") or []
            phases_out.append({
                "step": i,
                "phase": str(ph.get("name", f"phase-{i}")),
                "recommended_tools": [t.get("name") for t in tools if isinstance(t, dict)] or None,
                "goal": str(ph.get("post_analysis") or ph.get("description") or "")[:400],
            })
        out = {
            "id": resolved_id,
            "name": pb.get("name"),
            "description": str(pb.get("description", ""))[:300],
            "tags": pb.get("tags", []),
            "phase_checklist": phases_out,
            "note": "This is a STRATEGY checklist, not an executor. Pick the steps that fit the "
                    "campaign target and execute them with your available tools; skip steps that "
                    "need local infrastructure (internal network, CI access) unless it applies. "
                    "Depth-first: confirm or rule out each step's goal before moving on.",
        }
        return (_json_safe_dumps(out, PLAYBOOK_MAX_CHARS), None)

    return _ToolDef(
        "consult_playbook",
        ("Access the built-in attack-playbook library (OWASP Top 10 / Bug Bounty / API security / "
         "CTF / external ASM / internal network) as a STRATEGY checklist. "
         "Use 'list' to see what's available, then 'get' to fetch a playbook's phase-by-phase "
         "checklist to drive your attack plan. Read-only — it does not execute anything."),
        {
            "action": "'list' (default) or 'get'",
            "name": "playbook id for action='get' (see 'list')",
        },
        execute,
    )


# ---------------------------------------------------------------------------
# ToolDefinition 复用核心层的类（保持 orchestrator 契约一致）
# ---------------------------------------------------------------------------
from scanners.swarm_orchestrator import ToolDefinition as _ToolDef  # noqa: E402


# ---------------------------------------------------------------------------
# 总入口
# ---------------------------------------------------------------------------
def register_aux_tools(orchestrator, ctx: CampaignContext) -> int:
    """把辅助工具箱注册进 orchestrator。返回注册的工具数。"""
    tools = [
        _make_run_detector(ctx),
        _make_scan_endpoint(ctx),
        _make_dir_bust(ctx),
        _make_ext_scan(ctx),
        _make_consult_playbook(ctx),
    ]
    for t in tools:
        orchestrator.register_tool(t)
    logger.info(f"已注册 {len(tools)} 个辅助工具 | detectors={len(DETECTOR_REGISTRY)} | ext={len(_EXT_TOOLS)}")
    return len(tools)


if __name__ == "__main__":
    # 自测: 注册到空 orchestrator 并检查工具清单
    from scanners.swarm_orchestrator import SwarmOrchestrator
    from scanners.swarm_tool_binders import build_context
    orch = SwarmOrchestrator(llm_invoke=lambda **kw: None)
    c = build_context("http://localhost:8000", dry_run=True)
    n = register_aux_tools(orch, c)
    print("tools:", list(orch.tools.keys()))
    print("registered aux:", n)
