#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CVE Lookup — 通过 NVD (National Vulnerability Database) API 查询 CVE 详情。

NVD API 是公开的，无需 API key：https://nvd.nist.gov/developers/vulnerabilities

Usage:
    from scanners.cve_lookup import lookup_cve, check_package_vulns
    # 查单个 CVE
    result = lookup_cve("CVE-2024-1234")
    # 批量查某软件版本的漏洞
    result = check_package_vulns("apache", "httpd", "2.4.49")
"""

import json
import logging
import re
from typing import Dict, List, Optional
from urllib.request import urlopen, Request
from urllib.error import URLError

logger = logging.getLogger('cve_lookup')

NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"


def _nvd_api_request(params: dict) -> Optional[dict]:
    """请求 NVD API"""
    try:
        import urllib.request
        query_string = '&'.join(f"{k}={v}" for k, v in params.items())
        url = f"{NVD_API}?{query_string}"

        req = Request(url)
        # NVD API 限制：2s per request (free tier)
        req.add_header('User-Agent', 'HackScanner/1.0')
        req.add_header('Accept', 'application/json')

        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as e:
        logger.warning(f"NVD API 请求失败: {e}")
        return None


def lookup_cve(cve_id: str) -> dict:
    """查询单个 CVE 详情。

    Args:
        cve_id: CVE 编号，如 CVE-2024-1234

    Returns:
        {
            "ok": True,
            "cve_id": "...",
            "severity": "HIGH",
            "cvss_v3_score": 9.8,
            "description": "...",
            "references": ["...", ...],
            "affected_products": [{"vendor": "...", "product": "...", "versions": [...]}],
            "error": ""
        }
    """
    result = {
        "ok": False,
        "cve_id": cve_id,
        "severity": "",
        "cvss_v3_score": 0,
        "description": "",
        "references": [],
        "affected_products": [],
        "error": "",
    }

    data = _nvd_api_request({"cveId": cve_id})
    if not data or 'vuln' not in data:
        return {**result, "error": f"未找到 CVE: {cve_id} 或 API 不可达"}

    vuln = data['vuln']['cve']

    # Extract severity and CVSS
    for conf in vuln.get('configurations', []):
        if 'nodes' in conf:
            for node in conf['nodes']:
                if 'cpeMatch' in node:
                    for match in node['cpeMatch']:
                        result["affected_products"].append({
                            "vendor": match.get("criteria", ""),
                            "version": match.get("versionStartIncluding", ''),
                            "status": match.get('vulnerable', False),
                        })

    # Get metrics
    for metric_str in vuln.get('metrics', []):
        for key, val in metric_str.items():
            if isinstance(val, list):
                for m in val:
                    if 'cvssV3' in m:
                        cvss = m['cvssV3']
                        result["severity"] = cvss.get('baseSeverity', '')
                        result["cvss_v3_score"] = cvss.get('baseScore', 0)

    # Description
    for desc in vuln.get('descriptions', []):
        if desc.get('lang', '') == 'en':
            result["description"] = desc.get('value', '')
            break

    # References
    for ref in vuln.get('references', []):
        result["references"].append({
            "url": ref.get('url', ''),
            "source": ref.get('source', ''),
        })

    result["ok"] = True
    return result


def check_package_vulns(
    vendor: str,
    product: str,
    version: str,
) -> dict:
    """查询特定软件版本的 CVE（通过 CPE 匹配）。

    Args:
        vendor: 厂商名，如 apache
        product: 产品名，如 httpd
        version: 版本号，如 2.4.49

    Returns:
        {
            "ok": True,
            "cpe": "cpe:2.3:a:apache:httpd:2.4.49:*:*:*:*:*:*:*",
            "vulnerabilities": [
                {"cve_id": "CVE-2021-44228", "severity": "CRITICAL", "cvss": 10.0, ...}
            ],
            "total_vulns": N,
            "critical": N,
            "high": N,
            "error": ""
        }
    """
    cpe = f"cpe:2.3:{vendor}:{product}:{version}:*:*:*:*:*:*:*"

    result = {
        "ok": False,
        "cpe": cpe,
        "vulnerabilities": [],
        "total_vulns": 0,
        "critical": 0,
        "high": 0,
        "medium": 0,
        "low": 0,
        "error": "",
    }

    data = _nvd_api_request({
        "cpes": [cpe],
        "pageSize": 100,
    })

    if not data:
        return {**result, "error": "NVD API 不可达"}

    for vuln in data.get('vulnerabilities', []):
        cve = vuln.get('cve', {})
        severity = ''
        cvss = 0.0

        for metric_str in cve.get('metrics', []):
            for key, val in metric_str.items():
                if isinstance(val, list):
                    for m in val:
                        if 'cvssV3' in m:
                            severity = m['cvssV3'].get('baseSeverity', '')
                            cvss = m['cvssV3'].get('baseScore', 0)

        desc = ''
        for d in cve.get('descriptions', []):
            if d.get('lang') == 'en':
                desc = d.get('value', '')
                break

        refs = [r.get('url', '') for r in cve.get('references', [])]

        vuln_info = {
            "cve_id": cve.get('id', ''),
            "severity": severity,
            "cvss": cvss,
            "description": desc[:300],
            "references": refs[:5],
        }
        result["vulnerabilities"].append(vuln_info)

        # Count by severity
        if severity == 'CRITICAL':
            result["critical"] += 1
        elif severity == 'HIGH':
            result["high"] += 1
        elif severity == 'MEDIUM':
            result["medium"] += 1
        elif severity == 'LOW':
            result["low"] += 1

    result["total_vulns"] = len(result["vulnerabilities"])
    result["ok"] = True

    # Sort by CVSS descending
    result["vulnerabilities"].sort(key=lambda x: x.get("cvss", 0), reverse=True)

    return result


def parse_version_string(version_str: str) -> tuple:
    """提取版本号 (CVE ID or version number)"""
    cve_match = re.match(r'CVE-(\d+)-(\d+)', version_str)
    if cve_match:
        return ('cve', cve_match.group(0), None)

    ver_match = re.match(r'([\w\-]+)[-_](\d[\d\.]*)', version_str)
    if ver_match:
        return ('version', ver_match.group(1), ver_match.group(2))

    return (None, version_str, None)
