#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JS Rendering Scanner — 基于 Headless Browser 的深度页面分析

借鉴 Acunetix Chromium 引擎概念，使用 Selenium/Playwright 渲染 JavaScript-heavy 页面。
用于发现 SPA/Rails/Vue/Angular 应用中静态分析无法发现的端点和漏洞。

核心能力：
- 渲染 JS 生成内容（SPA 路由、动态 API 调用）
- 提取隐藏的 XHR/Fetch API 端点
- 识别前端框架和技术栈指纹
- 发现 React Router/Vue Router/Angular 路由定义
- 抓取 Console 日志中的敏感信息
- 检测 CSP/NSP 策略配置错误

Usage:
    from scanners.js_render_scanner import JSRenderScanner
    scanner = JSRenderScanner()
    result = scanner.render_and_analyze("https://example.com")
"""

import re
import json
import logging
from typing import Dict, List, Optional, Any, Set
from urllib.parse import urlparse, urljoin

# Selenium 依赖（按需动态使用）
try:
    from selenium.webdriver.common.by import By
except ImportError:
    By = None  # type: ignore

logger = logging.getLogger('js_render_scanner')


class JSRenderScanner:
    """基于 Headless Browser 的页面渲染和 API 端点发现"""

    # 前端框架指纹特征
    FRAMEWORK_FINGERPRINTS = {
        'React': [r'__reactglobal__', r'react-root', r'data-reactroot', r'/react\.js', r'sourceMappingURL=.+react'],
        'Vue.js': [r'vue\\.js', r'__vue__', r'data-v(?:ue)?-', r'[Vv]ue\.version'],
        'Angular': [r'ng-version', r'/angular.*\.js', r'__angular', r'ng\:app'],
        'Next.js': [r'__NEXT_DATA__', r'/next/', r'_next/static'],
        'Nuxt.js': [r'__NUXT__', r'nuxt\\.js', r'_nuxt/'],
        'Svelte': [r'svelte.*version', r'__svelte__'],
        'Gatsby': [r'___manifest', r'___sitemap', r'/public/'],
        'Remix': [r'__remix_Route', r'remix\.org'],
        'Ember.js': [r'__ember_', r'/ember\\.js'],
        'Backbone.js': [r'backbone.*\.js', r'__backbone__'],
        'jQuery': [r'jquery.*\.js', r'\$\.extend\(', r'jQuery.v'],
        'Express (SSR)': [r'express/', r'connect\.cookieParser'],
        'Node.js (SSR)': [r'setTimeout.*flushto\\.', r'node\.js'],
    }

    # SPA 路由模式
    ROUTE_PATTERNS = [
        r'(?:path|route)\s*:\s*[\'"]([^\'"/]+)',   # path: '/xxx'
        r'redirect\s*:\s*[\'"]([^\'"/]+)',         # redirect: '/xxx'
        r'loadChildren\s*[\'"](.+?)[\'"]',                   # loadChildren: '.../module#Module'
        r'component\s*:\s*(?:Type|class\s+(\w+))',                    # component: Class
        r'[\'"]/api/[a-z_]+[\'"]\s*[,)]',                             # '/api/...' endpoints
        r'fetch\s*\(\s*[\'"](/[^\'"]+)[\'"]',                        # fetch('/api/...')
        r'axios\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*[\'"]([^\'"]+)[\'"]',  # axios.get('/api/...')
        r'$.ajax\s*\(\s*{\s*url\s*:\s*[\'"]([^\'"]+)[\'"]',          # $.ajax({url: '/api/...'})
        r'url\s*:\s*[\'"](/[^\'"]+?\.json)[\'"]',                     # url: '/data.json'
    ]

    # 前端状态管理检测
    STATE_MANAGEMENT = {
        'Redux': [r'redux(?:_devtools)', r'createStore', r'reducer'],
        'Vuex': [r'new\s+Vuex\.Store', r'vuex.*store', r'mapState', r'mapActions'],
        'MobX': [r'@observable', r'@action', r'@computed'],
        'Recoil': [r'recoil_', r'useRecoilState'],
        'NgRx': [r'@ngrx/store', r'createStore', r'select'],
        'Pinia': [r'createPinia', r'useStore'],
        'Zustand': [r'create\s*(?:\()?\s*\[', r'zustand'],
    }

    def __init__(self, use_selenium: bool = True, timeout: int = 30):
        self.use_selenium = use_selenium
        self.timeout = timeout
        self._driver = None
        self._has_playwright = False
        self._has_selenium = False

        # 检查可用工具
        try:
            import selenium
            from selenium import webdriver
            self._has_selenium = True
        except ImportError:
            pass

        try:
            import playwright
            self._has_playwright = True
        except ImportError:
            pass

    def render_and_analyze(self, url: str) -> Dict[str, Any]:
        """渲染 JS 页面并分析内容。

        Args:
            url: 目标 URL

        Returns:
            {
                "ok": True/False,
                "target": "...",
                "rendered_content_length": N,
                "frameworks_detected": [...],
                "state_management": [...],
                "api_endpoints_found": [...],
                "spa_routes_found": [...],
                "xhr_endpoints_found": [...],
                "fetch_endpoints_found": [...],
                "console_messages": [...],
                "security_headers_after_render": {...},
                "hidden_elements_found": [...],
                "error": ""
            }
        """
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        result = {
            'ok': False,
            'target': url,
            'rendered_content_length': 0,
            'frameworks_detected': [],
            'state_management': [],
            'api_endpoints_found': [],
            'spa_routes_found': [],
            'xhr_endpoints_found': [],
            'fetch_endpoints_found': [],
            'console_messages': [],
            'security_headers_after_render': {},
            'hidden_elements_found': [],
            'error': '',
        }

        # 方法1: Selenium/Playwright
        if self._has_selenium or self._has_playwright:
            try:
                return self._render_with_browser(url, result)
            except Exception as e:
                logger.warning(f"浏览器渲染失败，回退到 HTTP + JS 源码分析: {e}")

        # 方法2: HTTP + JavaScript 源码分析（无依赖回退方案）
        try:
            return self._http_js_analysis(url, result)
        except Exception as e:
            result['error'] = str(e)
            return result

    def _render_with_browser(self, url: str, result: Dict) -> Dict:
        """使用 headless browser 渲染页面"""
        if self._has_playwright:
            driver = self._get_playwright_driver()
            if driver:
                return self._analyze_playwright(driver, url, result)

        if self._has_selenium:
            driver = self._get_selenium_driver()
            if driver:
                return self._analyze_selenium(driver, url, result)

        result['error'] = '未安装 selenium 或 playwright'
        result['ok'] = False
        return result

    def _get_selenium_driver(self):
        """创建 Selenium WebDriver"""
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options

            opts = Options()
            opts.add_argument('--headless')
            opts.add_argument('--no-sandbox')
            opts.add_argument('--disable-dev-shm-usage')
            opts.add_argument('--disable-gpu')
            opts.add_argument('--window-size=1920,1080')
            # 阻止图片加载加速（可选）
            prefs = {'permissions.default.image': 2, 'dom.webdriver.enabled': False}
            opts.add_experimental_option('prefs', prefs)
            opts.add_experimental_option('excludeSwitches', ['enable-automation'])

            self._driver = webdriver.Chrome(options=opts)
            return self._driver
        except Exception as e:
            logger.warning(f"Selenium Chrome 初始化失败: {e}")
            try:
                from selenium import webdriver
                from selenium.webdriver.firefox.options import Options
                opts = Options()
                opts.add_argument('--headless')
                self._driver = webdriver.Firefox(options=opts)
                return self._driver
            except Exception:
                return None

    def _get_playwright_driver(self):
        """创建 Playwright 浏览器实例。

        当在 asyncio event loop 中时，将 sync API 放在独立线程中执行，
        避免 "Sync API inside asyncio loop" 警告。
        """
        try:
            # 检测是否在 asyncio event loop 中
            import asyncio
            in_loop = False
            try:
                loop = asyncio.get_running_loop()
                if loop.is_running():
                    in_loop = True
            except RuntimeError:
                pass

            def _launch_sync():
                """在独立线程中启动 Playwright Sync API"""
                from playwright.sync_api import sync_playwright
                pw = sync_playwright().start()
                browser = pw.chromium.launch(headless=True)
                context = browser.new_context(
                    user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) HackScanner/Render/2.0'
                )
                page = context.new_page()
                return {'pw': pw, 'browser': browser, 'context': context, 'page': page}

            # _render_with_browser 和 render_and_analyze 都是同步方法，无法 await future，
            # 因此必须用独立线程（不是 run_in_executor）来隔离 event loop
            if in_loop:
                import threading
                result_holder = [None]
                error_holder = [None]

                def _thread_target():
                    try:
                        result_holder[0] = _launch_sync()
                    except Exception as e:
                        error_holder[0] = e

                t = threading.Thread(target=_thread_target, daemon=True)
                t.start()
                t.join(timeout=30)  # 最多等30秒

                if error_holder[0]:
                    raise error_holder[0]

                driver = result_holder[0]
            else:
                driver = _launch_sync()

            self._driver = driver
            return self._driver
        except Exception as e:
            logger.warning(f"Playwright 初始化失败: {e}")
            return None

    def _analyze_selenium(self, driver, url: str, result: Dict) -> Dict:
        """分析 Selenium 渲染结果"""
        try:
            driver.get(url)
            # 等待 JS 执行（等待网络空闲）
            import time
            time.sleep(3)

            content = driver.page_source
            result['rendered_content_length'] = len(content)

            # 提取所有 XHR/Fetch 请求 URL
            xhr_urls = driver.execute_script("""
                var urls = [];
                var origXHROpen = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function(method, url) {
                    if (url && url.indexOf('/api') > -1) {
                        urls.push({method: method, url: url});
                    }
                };
                return urls;
            """)

            # 获取 Console 消息
            console_msgs = driver.execute_script("""
                var msgs = [];
                // Capture via prototype override (already captured during load)
                return msgs;
            """)

            # 提取框架指纹
            js_content = content
            result['frameworks_detected'] = self._detect_frameworks(js_content)
            result['state_management'] = self._detect_state_mgmt(js_content)

            # 提取 API 端点
            api_eps = self._extract_api_endpoints(content, url)
            result['api_endpoints_found'] = list(set(api_eps))

            # 提取路由定义
            routes = self._extract_routes(content)
            result['spa_routes_found'] = list(set(routes))

            # 提取 XHR endpoints
            if xhr_urls:
                seen = set()
                for xhr in xhr_urls:
                    url_str = str(xhr.get('url', ''))
                    if url_str and url_str not in seen:
                        seen.add(url_str)
                        result['xhr_endpoints_found'].append({
                            'method': str(xhr.get('method', 'GET')),
                            'url': url_str,
                        })

            # 检查安全头 — Selenium 中 execute_script 无法获取 HTTP 响应头，改用 document.cookie 和 meta 标签提取
            try:
                cookies = driver.get_cookies()
                result['security_headers_after_render'] = {'_cookies_count': len(cookies)}
            except Exception:
                result['security_headers_after_render'] = {}

            # 从 DOM 中检查 CSP 等安全相关 meta 标签
            csp_meta = driver.execute_script("""
                var metas = document.querySelectorAll('meta[http-equiv], meta[name]');
                var headers = {};
                for (var i = 0; i < metas.length; i++) {
                    var h = metas[i].getAttribute('http-equiv') || metas[i].getAttribute('name');
                    var v = metas[i].getAttribute('content');
                    if (h && v) headers[h] = v;
                }
                return JSON.stringify(headers);
            """)
            try:
                meta_headers = json.loads(csp_meta)
                result['security_headers_after_render'].update(meta_headers)
            except (json.JSONDecodeError, TypeError):
                pass  # meta extraction failed, keep existing headers

            # 隐藏元素检测（可能包含 API key、调试信息等）
            hidden_inputs = driver.find_elements(By.CSS_SELECTOR,
                "input[type='hidden'][value*='key'], input[type='hidden'][value*='token'], "
                "input[type='hidden'][value*='secret'], input[data-key], input[data-token]"
            )
            for el in hidden_inputs:
                val = el.get_attribute('value')
                if val and len(val) > 10:
                    result['hidden_elements_found'].append({
                        'selector': el.get_attribute('selector', ''),
                        'name': el.get_attribute('name', ''),
                        'value_preview': val[:50],
                    })

            # 检测 CSP
            csp = driver.execute_script("return document.querySelector ? document.querySelector('meta[http-equiv=Content-Security-Policy]') : null")

            result['ok'] = True

        except Exception as e:
            logger.error(f"Selenium 分析失败: {e}")
            result['error'] = str(e)

        finally:
            if driver and hasattr(driver, 'quit'):
                driver.quit()

        return result

    def _analyze_playwright(self, driver_dict, url: str, result: Dict) -> Dict:
        """分析 Playwright 渲染结果"""
        try:
            page = driver_dict['page']
            page.goto(url, wait_until='load', timeout=self.timeout * 1000)

            content = page.content()
            result['rendered_content_length'] = len(content)

            # 等待 JS 执行完成
            import time
            time.sleep(2)

            # 提取框架指纹
            result['frameworks_detected'] = self._detect_frameworks(content)
            result['state_management'] = self._detect_state_mgmt(content)

            # 提取 API 端点
            api_eps = self._extract_api_endpoints(content, url)
            result['api_endpoints_found'] = list(set(api_eps))

            # 提取路由定义
            routes = self._extract_routes(content)
            result['spa_routes_found'] = list(set(routes))

            # 获取 console messages
            def handle_console(msg):
                result['console_messages'].append({
                    'type': msg.type,
                    'text': msg.text[:500],
                })
            page.on('console', handle_console)

            # 拦截 XHR/Fetch
            xhrs = []
            def intercept_fetch(route, request):
                url_path = request.url
                if '/api' in url_path or '/ajax' in url_path:
                    xhrs.append({'method': request.method, 'url': url_path})
                route.continue_()
            page.route('**/*', intercept_fetch)

            # 重新导航以捕获拦截
            page.goto(url, wait_until='load', timeout=self.timeout * 1000)
            result['xhr_endpoints_found'] = xhrs[:50]

            result['ok'] = True

        except Exception as e:
            logger.error(f"Playwright 分析失败: {e}")
            result['error'] = str(e)
        finally:
            if driver_dict and 'browser' in driver_dict:
                try:
                    driver_dict['browser'].close()
                except Exception:
                    pass

        return result

    def _http_js_analysis(self, url: str, result: Dict) -> Dict:
        """无浏览器时的回退方案：HTTP + JavaScript 源码分析"""
        import requests
        from rate_limiter import get_rate_limiter, check_safe_to_scan

        try:
            safe, reason, delay = check_safe_to_scan(url)
            if not safe:
                import time
                time.sleep(delay)

            resp = requests.get(url, timeout=self.timeout, allow_redirects=True)
            content = resp.text
            result['rendered_content_length'] = len(content)

            # === 1. 框架指纹识别 ===
            result['frameworks_detected'] = self._detect_frameworks(content)
            result['state_management'] = self._detect_state_mgmt(content)

            # === 2. API 端点提取（从 JS 源码中）===
            api_eps = self._extract_api_endpoints(content, url)
            result['api_endpoints_found'] = list(set(api_eps))

            # === 3. SPA 路由提取 ===
            routes = self._extract_routes(content)
            result['spa_routes_found'] = list(set(routes))

            # === 4. 提取所有 <script> 标签的 src ===
            script_srcs = re.findall(r'<script[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>', content, re.IGNORECASE)
            result['_script_sources'] = list(set(script_srcs))

            # === 5. inline JS 内容分析（大体积可能包含配置）===
            inline_js_patterns = [
                (r'API_BASE_URL\s*[=:]\s*[\'"]([^\'"]+)[\'"]', 'API Base URL'),
                (r'apiUrl\s*[=:]\s*[\'"]([^\'"]+)[\'"]', 'API URL'),
                (r'(?:backend|server)\.?\s*[=:]\s*[\'"]([^\'"]+)[\'"]', 'Backend Server'),
                (r'debug[=:]\s*(true|false)', 'Debug Mode'),
                (r'apiKey\s*[=:]\s*[\'"]([^\'"]+)[\'"]', 'API Key Reference'),
            ]

            for pattern, label in inline_js_patterns:
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    result.setdefault('_config_findings', []).append({
                        'label': label,
                        'values': list(set(matches)),
                    })

            # === 6. CSP 策略检测 ===
            csp_match = re.search(r'<meta[^>]*http-equiv=["\']Content-Security-Policy["\'][^>]*content=["\'](.+?)["\']', content, re.IGNORECASE)
            if csp_match:
                result['security_headers_after_render']['Content-Security-Policy'] = csp_match.group(1)

            # === 7. HTML5 data-* 属性中的敏感数据 ===
            data_attrs = re.findall(r'data-([a-z_-]+)=["\']([^"\']{10,})["\']', content, re.IGNORECASE)
            for attr_name, attr_val in data_attrs:
                if any(kw in attr_name.lower() for kw in ['key', 'token', 'secret', 'api', 'auth', 'id']):
                    result['hidden_elements_found'].append({
                        'data_attribute': attr_name,
                        'value_preview': attr_val[:50],
                    })

            # === 8. 隐藏的 meta 标签（常包含配置信息）===
            meta_tags = re.findall(r'<meta[^>]*name=["\']([^"\']+)["\'][^>]*content=["\']([^"\']+)["\']', content, re.IGNORECASE)
            for name, val in meta_tags:
                if any(kw in name.lower() for kw in ['config', 'api', 'app', 'env']):
                    result.setdefault('_meta_config', []).append({'name': name, 'value_preview': val[:80]})

            result['ok'] = True

        except Exception as e:
            logger.error(f"HTTP+JS 分析失败: {e}")
            result['error'] = str(e)

        return result

    def _detect_frameworks(self, content: str) -> List[str]:
        """检测前端框架"""
        detected = []
        for fw, patterns in self.FRAMEWORK_FINGERPRINTS.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    if fw not in detected:
                        detected.append(fw)
                    break
        return detected

    def _detect_state_mgmt(self, content: str) -> List[str]:
        """检测状态管理方案"""
        detected = []
        for sm, patterns in self.STATE_MANAGEMENT.items():
            for pattern in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    if sm not in detected:
                        detected.append(sm)
                    break
        return detected

    def _extract_api_endpoints(self, content: str, base_url: str) -> List[str]:
        """从 HTML/JS 内容中提取 API 端点"""
        endpoints = set()

        # pattern1: URL 字符串（常见于 JS）
        url_patterns = [
            r'[\'"](/api/[^\s\'"<>]+)[\'"]',       # '/api/xxx'
            r'[\'"](/[a-z_-]+/[^\s\'"<>]+)[\'"]',  # '/v1/users/xxx'
            r'[\'"](https?://[^/\s\'"<>]+\.[a-z]{2,}/api/[^\s\'"<>]+)[\'"]',  # full URL API
        ]

        for pattern in url_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            endpoints.update(matches)

        # pattern2: fetch/axios/jquery ajax calls
        fetch_patterns = [
            r'fetch\s*\(\s*[\'"]([^\'"]+)[\'"]',
            r'axios\.\w+\s*\(\s*[\'"]([^\'"]+)[\'"]',
            r'\$\s*\.\s*ajax\s*\(\s*{[^}]*url\s*:\s*[\'"]([^\'"]+)[\'"]',
        ]

        for pattern in fetch_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            endpoints.update(matches)

        # pattern3: script[src] 中的 JS 文件可能包含额外端点
        # 递归加载内联 JS 文件（如果有 base URL）
        for src in re.findall(r'<script[^>]+src=[\'"]([^\'"]+\.js)[\'"][^>]*>', content, re.IGNORECASE):
            if src.startswith('/'):
                parsed = urlparse(base_url)
                full_src = f"{parsed.scheme}://{parsed.netloc}{src}"
                endpoints.add(f"[embedded] {full_src}")

        return sorted(endpoints)

    def _extract_routes(self, content: str) -> List[str]:
        """从 JS 内容中提取 SPA 路由定义"""
        routes = set()

        for pattern in self.ROUTE_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for m in matches:
                if m.startswith('/') and len(m) > 3:
                    routes.add(m)

        return sorted(routes)


# 便捷函数
def render_js_page(url: str, use_selenium: bool = True, timeout: int = 30) -> Dict[str, Any]:
    """快速渲染并分析 JS 页面"""
    scanner = JSRenderScanner(use_selenium=use_selenium, timeout=timeout)
    return scanner.render_and_analyze(url)
