#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
有界并行攻击面探测（bounded parallel attack-surface probing）
=====================================================================

用途
----
从 recon 输出文本中抽取独立攻击面（host:port / 子域 / 端点），按"波次"并行做
**浅层**探测（每面请求数有硬上限），findings 经 scanners.swarm_dedup.dedup_findings
去重后合并回主 campaign。纯标准库（urllib + concurrent.futures），Python 3.14。

参照：vulnclaw/agent/parallel_agents.py（波次/预算/子代理 turn 上限模型）
---------------------------------------------------------------------------
其"surface-wave scheduler"思路被照搬并适配到无 LLM 子代理的 HTTP 浅探场景：

    vulnclaw parallel_agents.py                     →  本模块
    -------------------------------------------------  --------------------------------
    extract_attack_surfaces(session, limit)          →  extract_surfaces(recon_text, target_url)
    asyncio.Semaphore(max_concurrent) 波次门控        →  ThreadPoolExecutor(max_workers=max_concurrent)
    每子代理 worker_rounds / max_agents 预算          →  per_surface_requests / max_total 预算份额
    merge_session_state(parent, child) 收尾合并        →  merge_findings(results, existing)
                                                        （经 swarm_dedup.dedup_findings 去重）
    子代理失败 fail-loud（graph 记 FAILED）           →  单面失败 → SurfaceResult.status="failed"
                                                        （记入结果列表，不炸其它面、不抛异常）

有界语义（全部硬上限，防失控请求量）
------------------------------------
    max_concurrent        并发线程数（ThreadPoolExecutor worker 数，>=1）
    max_total             本波最多探测的面数；超出部分 status="skipped"（detail 注明截断）
    per_surface_requests  每面请求硬上限（浅层计划：GET / + OPTIONS / + 至多 2 个高价值路径）
    request_timeout       单请求超时（秒，作用于默认 urllib 实现）
    min_interval          全局最小请求间隔（秒，跨线程生效）

限速
----
全局 _RateLimiter：一把 threading.Lock + monotonic 时间戳，把所有请求（跨所有线程）
的"发起时刻"串行化到至少间隔 min_interval —— 与 swarm_tool_binders.http_probe 的
rate_limiter 语义一致，但本模块自包含、不依赖外部单例。

scope 门控
----------
只探测 scope 内 host，语义对齐 swarm_tool_binders._in_scope：
精确匹配 / 子域（h == s 或 h.endswith("." + s)）/ loopback（localhost、
127.0.0.1、::1、0.0.0.0 —— 对齐 build_context 的"loopback 永远允许"约定）。
scope_hosts=None 时默认 scope 从 target_url 推导（target host + loopback）。
extract_surfaces 在源头过滤 scope 外的面，波次调度只见到 scope 内的面。

测试零真实网络
--------------
probe_surface / probe_wave 接受 request_fn 注入点：
    request_fn: Callable[[str], tuple[int, dict, str]]  (status, headers, body)
默认实现为 _http_get（urllib，标准库）。冒烟/单测注入 fake request_fn 即可
全程零真实网络。注意：注入 request_fn 时模块只传 URL（契约签名），OPTIONS
语义步以"对根路径的第二次请求 + 只读 Allow 头"实现——fake 缺 Allow 头则自然无 finding。

脏输入不抛异常
--------------
单面探测失败（超时/连接拒绝/request_fn 返回畸形/请求 fn 抛任何异常）只把该面
标为 status="failed" 记入结果列表（failed 列表语义），不影响其它面；
本模块任何公开函数均不向外抛异常。

默认关
------
接线层应先读 load_parallel_config(config)["enabled"] —— 默认 False。
本模块只提供能力，不自动运行。
"""

from __future__ import annotations

import logging
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse

logger = logging.getLogger("parallel_probe")

# ---------------------------------------------------------------------------
# 项目根入 sys.path + swarm_dedup 依赖（双路径导入 + 本地兜底，保持自包含）
# ---------------------------------------------------------------------------
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _local_dedup_findings(findings_list: List[dict], key_field: str = "target") -> List[dict]:
    """兜底去重：与 swarm_dedup.dedup_findings 同语义（按 key_field 保首见）。"""
    seen: Set[str] = set()
    result: List[dict] = []
    for f in findings_list or []:
        if not isinstance(f, dict):
            continue
        key = str(f.get(key_field, ""))
        if key and key not in seen:
            seen.add(key)
            result.append(f)
    return result


try:
    from scanners.swarm_dedup import dedup_findings as _dedup_findings
except Exception:  # 直接运行本文件 / 非包路径场景
    try:
        from swarm_dedup import dedup_findings as _dedup_findings  # type: ignore
    except Exception:
        _dedup_findings = None

_DEDUP_FINDINGS = _dedup_findings if _dedup_findings is not None else _local_dedup_findings

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
_LOOPBACK_HOSTS = frozenset({"localhost", "127.0.0.1", "::1", "0.0.0.0"})
_USER_AGENT = "Mozilla/5.0 (compatible; hack-scanner-parallel-probe/1.0)"
_BODY_MAX = 8192  # 单响应读取上限（字节），浅探只取头部片段
_HIGH_VALUE_PATHS = ("/admin", "/api", "/robots.txt")  # 高价值路径（至多取前 2 个）
_SENSITIVE_METHODS = frozenset({"TRACE", "PUT", "DELETE"})
_SECURITY_HEADERS = (
    "strict-transport-security",
    "x-content-type-options",
    "x-frame-options",
    "content-security-policy",
)

_DEFAULTS: Dict[str, Any] = {
    "enabled": False,
    "max_concurrent": 3,
    "max_total": 10,
    "per_surface_requests": 4,
    "request_timeout": 10.0,
    "min_interval": 0.2,
    "max_endpoints_per_host": 5,
}

# 攻击面抽取正则
_URL_RE = re.compile(
    r"https?://[A-Za-z0-9.\-]+(?::\d{1,5})?(?:/[^\s\"'<>]+)?",
    re.IGNORECASE,
)
_BARE_HOST_RE = re.compile(
    r"\b(?:"
    r"((?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z][A-Za-z0-9\-]*"
    r"|(?:\d{1,3}\.){3}\d{1,3})"
    r")(?::(\d{1,5}))?\b"
)


# ---------------------------------------------------------------------------
# 数据类型（公开 API 契约）
# ---------------------------------------------------------------------------
@dataclass
class Surface:
    """一个独立攻击面：host:port + scheme + 端点路径。"""
    host: str
    port: int
    scheme: str          # "http" | "https"
    endpoint: str = ""   # 路径（可空 = 根）
    origin: str = ""     # "recon" | "target"


@dataclass
class SurfaceResult:
    """单个面的浅层探测结果。"""
    surface: Surface
    status: str          # "ok" | "failed" | "skipped"
    findings: List[dict] = field(default_factory=list)
    detail: str = ""
    requests_made: int = 0


# ---------------------------------------------------------------------------
# 全局限速（一把锁 + 时间戳，线程安全）
# ---------------------------------------------------------------------------
class _RateLimiter:
    """全局最小请求间隔：所有线程的请求发起时刻至少间隔 min_interval。"""

    def __init__(self, min_interval: float):
        try:
            self._min_interval = max(0.0, float(min_interval))
        except (TypeError, ValueError):
            self._min_interval = 0.0
        self._lock = threading.Lock()
        self._last_start = 0.0

    def wait(self) -> None:
        if self._min_interval <= 0.0:
            return
        with self._lock:
            now = time.monotonic()
            earliest = self._last_start + self._min_interval
            if earliest > now:
                delay = earliest - now
                self._last_start = earliest
            else:
                delay = 0.0
                self._last_start = now
        if delay > 0:
            time.sleep(delay)


# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------
def _normalize_headers(headers: Any) -> Dict[str, str]:
    """头字典规范化：键小写、值 str；输入非 dict/None 时返回 {}。"""
    out: Dict[str, str] = {}
    items: Any = None
    if isinstance(headers, dict):
        items = headers.items()
    elif headers is not None:
        try:
            items = list(headers)
        except Exception:
            items = None
    for k, v in items or []:
        try:
            out[str(k).lower()] = str(v)
        except Exception:
            continue
    return out


def _default_port(scheme: str) -> int:
    return 443 if scheme == "https" else 80


def _build_url(surface: Surface, path: str = "") -> str:
    """Surface(+path) → 请求 URL。默认端口省略，避免 :80/:443 冗余。"""
    scheme = "https" if str(getattr(surface, "scheme", "") or "").lower() == "https" else "http"
    try:
        port = int(getattr(surface, "port", 0) or 0)
    except (TypeError, ValueError):
        port = 0
    host = str(getattr(surface, "host", "") or "")
    if not (1 <= port <= 65535):
        port = _default_port(scheme)
    netloc = f"{host}:{port}" if port != _default_port(scheme) else host
    p = (path or "").strip()
    if p and not p.startswith("/"):
        p = "/" + p
    return f"{scheme}://{netloc}{p}"


def _describe(surface: Surface) -> str:
    """progress_cb 用的面描述（URL 形式）。"""
    try:
        return _build_url(surface, getattr(surface, "endpoint", "") or "")
    except Exception:
        return f"{getattr(surface, 'scheme', 'http')}://{getattr(surface, 'host', '')}"


def _target_surface(target_url: str) -> Optional[Surface]:
    """target_url → Surface(origin="target")；解析失败返回 None。"""
    u = (target_url or "").strip()
    if not u:
        return None
    if "://" not in u:
        u = "http://" + u
    try:
        p = urlparse(u)
    except Exception:
        return None
    host = (p.hostname or "").lower().strip(".")
    if not host:
        return None
    scheme = (p.scheme or "http").lower()
    if scheme not in ("http", "https"):
        scheme = "http"
    try:
        port = int(p.port)
    except (TypeError, ValueError):
        port = _default_port(scheme)
    if not (1 <= port <= 65535):
        port = _default_port(scheme)
    path = (p.path or "").split("?", 1)[0].split("#", 1)[0]
    return Surface(host=host, port=port, scheme=scheme, endpoint=path, origin="target")


def _derive_scope(target_url: str) -> Set[str]:
    """默认 scope（scope_hosts=None）：target host + loopback（对齐 build_context）。"""
    scope = set(_LOOPBACK_HOSTS)
    ts = _target_surface(target_url)
    if ts is not None and ts.host:
        scope.add(ts.host)
    return scope


def _in_scope(host: str, scope_hosts: Set[str]) -> bool:
    """scope 判定（对齐 swarm_tool_binders._in_scope）：精确 / 子域 / loopback。"""
    h = (host or "").lower().strip(".")
    if not h:
        return False
    for s in scope_hosts or ():
        s = (s or "").lower().strip(".")
        if not s:
            continue
        if h == s or h.endswith("." + s):
            return True
    return False


def _surface_from_url(url: str) -> Optional[Surface]:
    """recon 文本中的完整 URL → Surface(origin="recon")。"""
    try:
        p = urlparse(url)
    except Exception:
        return None
    host = (p.hostname or "").lower().strip(".")
    if not host:
        return None
    scheme = (p.scheme or "http").lower()
    if scheme not in ("http", "https"):
        scheme = "http"
    try:
        port = int(p.port)
    except (TypeError, ValueError):
        port = _default_port(scheme)
    if not (1 <= port <= 65535):
        port = _default_port(scheme)
    path = (p.path or "").split("?", 1)[0].split("#", 1)[0]
    return Surface(host=host, port=port, scheme=scheme, endpoint=path, origin="recon")


def _surface_from_bare(host: str, port_str: Optional[str]) -> Optional[Surface]:
    """recon 文本中的裸 host(:port) → Surface(origin="recon")。

    无端口默认 http/80；端口 443 视为 https（经验性约定）。
    """
    host = (host or "").lower().strip(".")
    if not host:
        return None
    if port_str:
        try:
            port = int(port_str)
        except (TypeError, ValueError):
            port = 80
        if not (1 <= port <= 65535):
            port = 80
    else:
        port = 80
    scheme = "https" if port == 443 else "http"
    return Surface(host=host, port=port, scheme=scheme, endpoint="", origin="recon")


# ---------------------------------------------------------------------------
# 1. 攻击面抽取（公开 API）
# ---------------------------------------------------------------------------
def extract_surfaces(recon_text: str, target_url: str,
                     scope_hosts: Optional[Set[str]] = None,
                     max_endpoints_per_host: int = 5) -> List[Surface]:
    """从 recon 输出文本抽 URL/host:port（正则）+ target 本身。

    流程：target 面（origin="target"，排最前）→ recon 文本中的 URL/裸 host(:port)
    → scope 过滤（精确/子域/loopback）→ (scheme,host,port,endpoint) 去重保首见
    → 每 host 保留前 N 个端点（N 可配，默认 5）。

    Args:
        recon_text: recon 工具输出文本（任意格式，正则抽取；None/"" → 仅 target）。
        target_url: campaign 目标 URL（自身也是攻击面）。
        scope_hosts: 规范化 host 集合（小写）；None → 由 target_url 推导（+loopback）。
        max_endpoints_per_host: 每 host 端点上限（<1 时回落默认 5）。
    """
    if scope_hosts is None:
        scope = _derive_scope(target_url)
    else:
        scope = {str(s).lower().strip(".") for s in (scope_hosts or set()) if str(s or "").strip()}

    try:
        cap = int(max_endpoints_per_host)
    except (TypeError, ValueError):
        cap = _DEFAULTS["max_endpoints_per_host"]
    cap = max(1, cap)

    candidates: List[Surface] = []
    ts = _target_surface(target_url)
    if ts is not None:
        candidates.append(ts)

    text = str(recon_text or "")
    for m in _URL_RE.finditer(text):
        s = _surface_from_url(m.group(0))
        if s is not None:
            candidates.append(s)
    for m in _BARE_HOST_RE.finditer(text):
        s = _surface_from_bare(m.group(1), m.group(2))
        if s is not None:
            candidates.append(s)

    out: List[Surface] = []
    seen_keys: Set[Tuple[str, str, int, str]] = set()
    per_host: Dict[str, int] = {}
    for s in candidates:
        if not _in_scope(s.host, scope):
            continue
        key = (s.scheme, s.host, s.port, s.endpoint)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        if per_host.get(s.host, 0) >= cap:
            continue
        per_host[s.host] = per_host.get(s.host, 0) + 1
        out.append(s)
    return out


# ---------------------------------------------------------------------------
# 2. 默认 HTTP 实现（urllib，标准库；注入 request_fn 时不使用）
# ---------------------------------------------------------------------------
def _http_get(url: str, method: str = "GET", timeout: float = 10.0) -> Tuple[int, Dict[str, str], str]:
    """默认 request_fn：urllib 单请求 → (status, headers[小写键], body 截断文本)。

    4xx/5xx 是"响应"不是错误（HTTPError 也正常返回）；
    URLError / socket.timeout / OSError 向上抛，由 probe_surface 捕获并标 failed。
    """
    try:
        timeout_f = float(timeout)
    except (TypeError, ValueError):
        timeout_f = 10.0
    req = urllib.request.Request(url, method=(method or "GET").upper(), headers={
        "User-Agent": _USER_AGENT,
        "Accept": "*/*",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout_f) as resp:
            status = int(getattr(resp, "status", 0) or resp.getcode())
            headers = _normalize_headers(getattr(resp, "headers", None))
            body = resp.read(_BODY_MAX).decode("utf-8", "replace")
            return (status, headers, body)
    except urllib.error.HTTPError as exc:
        status = int(getattr(exc, "code", 0) or 0)
        headers = _normalize_headers(getattr(exc, "headers", None))
        body = ""
        try:
            body = exc.read(4096).decode("utf-8", "replace")
        except Exception:
            pass
        return (status, headers, body)
    # 其余异常（URLError/timeout/OSError）继续向上抛 —— probe_surface 负责兜住


# ---------------------------------------------------------------------------
# 3. 浅层探测的 findings 分析器（全部产出 info/low 级线索，非深度利用）
# ---------------------------------------------------------------------------
def _analyze_root(status: int, headers: Dict[str, str], url: str) -> List[dict]:
    """GET / 的线索：Server / X-Powered-By 暴露、缺安全头。"""
    findings: List[dict] = []
    server = headers.get("server", "")
    if server:
        findings.append({
            "title": "Server 头泄露服务器软件/版本",
            "severity": "info",
            "evidence": f"GET {url} -> Server: {server}",
            "url": url,
            "vuln_type": "info_disclosure",
        })
    powered = headers.get("x-powered-by", "")
    if powered:
        findings.append({
            "title": "X-Powered-By 泄露后端框架",
            "severity": "low",
            "evidence": f"GET {url} -> X-Powered-By: {powered}",
            "url": url,
            "vuln_type": "info_disclosure",
        })
    if 200 <= status < 400:
        missing = [h for h in _SECURITY_HEADERS if h not in headers]
        if missing:
            findings.append({
                "title": "响应缺少安全头",
                "severity": "info",
                "evidence": f"GET {url} -> {status}; missing: {', '.join(missing)}",
                "url": url,
                "vuln_type": "misconfig",
            })
    return findings


def _analyze_options(headers: Dict[str, str], url: str) -> List[dict]:
    """OPTIONS 的线索：Allow 头暴露敏感方法（TRACE/PUT/DELETE）。"""
    allow = (headers.get("allow") or "").strip()
    if not allow:
        return []
    methods = [m.strip().upper() for m in allow.split(",") if m.strip()]
    sensitive = [m for m in methods if m in _SENSITIVE_METHODS]
    if not sensitive:
        return []
    return [{
        "title": "OPTIONS Allow 暴露敏感方法",
        "severity": "low",
        "evidence": f"OPTIONS {url} -> Allow: {allow}",
        "url": url,
        "vuln_type": "http_methods",
    }]


def _analyze_path(path: str, status: int, body: str, url: str) -> List[dict]:
    """高价值路径的线索：200 可直达（low）/ 401|403 存在受控端点（info）/
    robots.txt 200 暴露 disallow 路径（info）。404 无信号。"""
    if path == "/robots.txt":
        if status == 200:
            disallows: List[str] = []
            for line in (body or "").splitlines():
                if line.strip().lower().startswith("disallow") and len(disallows) < 5:
                    disallows.append(line.strip())
            evidence = f"GET {url} -> 200"
            if disallows:
                evidence += "; " + "; ".join(disallows)
            return [{
                "title": "robots.txt 暴露受限路径",
                "severity": "info",
                "evidence": evidence[:400],
                "url": url,
                "vuln_type": "info_disclosure",
            }]
        return []
    if status == 200:
        return [{
            "title": f"潜在敏感端点可直接访问: {path}",
            "severity": "low",
            "evidence": f"GET {url} -> 200",
            "url": url,
            "vuln_type": "exposure",
        }]
    if status in (401, 403):
        return [{
            "title": f"检测到受控端点（疑似需认证）: {path}",
            "severity": "info",
            "evidence": f"GET {url} -> {status}",
            "url": url,
            "vuln_type": "info_disclosure",
        }]
    return []


# ---------------------------------------------------------------------------
# 4. 单面浅层探测（公开 API）
# ---------------------------------------------------------------------------
def probe_surface(surface: Surface, per_surface_requests: int = 4,
                  request_timeout: float = 10.0,
                  request_fn: Optional[Callable[[str], Tuple[int, Dict[str, str], str]]] = None,
                  rate_limiter: Optional[_RateLimiter] = None) -> SurfaceResult:
    """对单个攻击面做浅层探测（请求数硬上限 per_surface_requests）。

    探测计划（按预算逐档放出）：
        budget >= 1 : GET /            （状态码/Server/X-Powered-By/缺安全头 → info/low）
        budget >= 2 : OPTIONS /        （Allow 头暴露敏感方法 → low）
        budget >= 3 : GET /admin       （高价值路径，至多再 1-2 个：/api、/robots.txt）

    request_fn: Callable[[str], (status, headers, body)] —— 注入点，默认 _http_get(urllib)。
        注入 request_fn 时只传 URL；模块把"对根路径的第二次请求"按 OPTIONS 语义
        解读（只读 Allow 头，无该头则无 finding）。
    rate_limiter: 可选全局限速器（probe_wave 注入）；None 时不限速。
    超时/连接错误/脏返回 → 首个请求失败 ⇒ status="failed"；后续请求失败 ⇒
        保留已有 findings、记 detail，status 仍 "ok"。任何情况均不抛异常。
    """
    if not isinstance(surface, Surface) or not str(getattr(surface, "host", "") or "").strip():
        return SurfaceResult(
            surface=surface, status="failed", findings=[],
            detail="invalid surface (empty host)", requests_made=0,
        )
    try:
        budget = int(per_surface_requests)
    except (TypeError, ValueError):
        budget = _DEFAULTS["per_surface_requests"]
    budget = max(1, budget)

    def _send(url: str, method: str) -> Tuple[str, Any]:
        """发一个请求：限速 → 调用 fn → 规范化返回；异常收敛为 ("error", exc)。"""
        if rate_limiter is not None:
            rate_limiter.wait()
        try:
            if request_fn is not None:
                resp = request_fn(url)
            else:
                resp = _http_get(url, method=method, timeout=request_timeout)
            try:
                status, headers, body = resp
            except (TypeError, ValueError):
                return ("error", ValueError("request_fn returned malformed (status, headers, body)"))
            return ("ok", (int(status), _normalize_headers(headers), str(body or "")))
        except Exception as exc:  # timeout / 连接错误 / 自定义 fn 任意异常
            return ("error", exc)

    root_url = _build_url(surface, "")
    findings: List[dict] = []
    detail_parts: List[str] = []
    requests_made = 0

    steps: List[Tuple[str, str]] = []
    if budget >= 1:
        steps.append(("", "GET"))
    if budget >= 2:
        steps.append(("", "OPTIONS"))
    if budget >= 3:
        steps.extend((p, "GET") for p in _HIGH_VALUE_PATHS[: max(0, min(2, budget - 2))])

    for path, method in steps:
        url = _build_url(surface, path)
        kind, payload = _send(url, method)
        requests_made += 1
        if kind == "error":
            msg = f"{method} {path or '/'} failed: {type(payload).__name__}: {str(payload)[:160]}"
            if not detail_parts:
                # 首个请求（GET /）都连不上 → 整个面 failed
                return SurfaceResult(
                    surface=surface, status="failed", findings=findings,
                    detail=msg, requests_made=requests_made,
                )
            detail_parts.append(msg)
            continue
        status, headers, body = payload
        if method == "OPTIONS":
            findings.extend(_analyze_options(headers, url))
        elif path == "":
            findings.extend(_analyze_root(status, headers, url))
        else:
            findings.extend(_analyze_path(path, status, body, url))
        detail_parts.append(f"{method} {path or '/'} -> {status}")

    return SurfaceResult(
        surface=surface, status="ok", findings=findings,
        detail="; ".join(detail_parts)[:500], requests_made=requests_made,
    )


# ---------------------------------------------------------------------------
# 5. 波次并行调度（公开 API）
# ---------------------------------------------------------------------------
def probe_wave(surfaces: List[Surface], max_concurrent: int = 3,
               max_total: int = 10, per_surface_requests: int = 4,
               request_timeout: float = 10.0, min_interval: float = 0.2,
               request_fn: Optional[Callable[[str], Tuple[int, Dict[str, str], str]]] = None,
               progress_cb: Optional[Callable[[int, int, str], None]] = None) -> List[SurfaceResult]:
    """波次并行探测（ThreadPoolExecutor），全部上限为硬约束。

    - max_total 截断：前 max_total 个面进入波次；其余按输入顺序返回
      status="skipped"（detail 注明 max_total 截断）。
    - max_concurrent：worker 数（>=1，且不超过实际入波面数）。
    - min_interval：全局限速（跨线程，_RateLimiter 一把锁 + 时间戳）。
    - progress_cb(done, total, surface_desc)：每个面完成时回调一次；异常被吞。
    - 返回顺序 = 输入顺序（前 max_total 个 + 后续 skipped）。
    """
    try:
        all_surfaces = list(surfaces or [])
    except TypeError:
        all_surfaces = []

    try:
        max_total_i = max(0, int(max_total))
    except (TypeError, ValueError):
        max_total_i = int(_DEFAULTS["max_total"])
    try:
        max_conc = max(1, int(max_concurrent))
    except (TypeError, ValueError):
        max_conc = int(_DEFAULTS["max_concurrent"])

    to_probe = all_surfaces[:max_total_i]
    limiter = _RateLimiter(min_interval)
    total = len(to_probe)
    results: List[SurfaceResult] = []

    def _work(s: Surface) -> SurfaceResult:
        try:
            return probe_surface(
                s,
                per_surface_requests=per_surface_requests,
                request_timeout=request_timeout,
                request_fn=request_fn,
                rate_limiter=limiter,
            )
        except Exception as exc:  # 双保险：probe_surface 本就不应抛
            return SurfaceResult(
                surface=s, status="failed", findings=[],
                detail=f"probe crashed: {type(exc).__name__}: {str(exc)[:160]}",
                requests_made=0,
            )

    if total:
        workers = min(max_conc, total)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [(s, pool.submit(_work, s)) for s in to_probe]
            for i, (s, fut) in enumerate(futures, start=1):
                try:
                    r = fut.result()
                except Exception as exc:
                    r = SurfaceResult(
                        surface=s, status="failed", findings=[],
                        detail=str(exc)[:200], requests_made=0,
                    )
                results.append(r)
                if progress_cb is not None:
                    try:
                        progress_cb(i, total, _describe(s))
                    except Exception:
                        pass  # 回调异常不影响探测

    for s in all_surfaces[max_total_i:]:
        results.append(SurfaceResult(
            surface=s, status="skipped", findings=[],
            detail=f"exceeded max_total={max_total_i} budget, not probed this wave",
            requests_made=0,
        ))
    return results


# ---------------------------------------------------------------------------
# 6. findings 合并回主 campaign（公开 API）
# ---------------------------------------------------------------------------
def merge_findings(results: List[SurfaceResult], existing: Optional[List[dict]] = None) -> List[dict]:
    """汇总 SurfaceResult.findings + existing，经 swarm_dedup.dedup_findings 去重。

    归一化：dedup_findings 按 key_field（默认 "target"）判重且会丢弃空键项，
    因此先给每条 finding 补 "target"（优先既有 target → url → host；三者皆无
    时用唯一占位键保留该条，避免静默丢失）。返回的是含 "target" 键的 dict 副本，
    不改动调用方传入的原始 dict。
    """
    merged: List[dict] = []
    for r in results or []:
        for f in (getattr(r, "findings", None) or []):
            if isinstance(f, dict):
                merged.append(f)
    for f in existing or []:
        if isinstance(f, dict):
            merged.append(f)
    if not merged:
        return []

    normalized: List[dict] = []
    for i, f in enumerate(merged):
        nf = dict(f)
        key = nf.get("target") or nf.get("url") or nf.get("host")
        if not key:
            key = f"unscoped::{i}"
        nf["target"] = str(key)
        normalized.append(nf)

    try:
        return _DEDUP_FINDINGS(normalized, key_field="target")
    except Exception:
        return _local_dedup_findings(normalized, "target")


# ---------------------------------------------------------------------------
# 7. 配置加载（公开 API）—— 默认关
# ---------------------------------------------------------------------------
def load_parallel_config(config: Optional[dict]) -> Dict[str, Any]:
    """config["parallel_probe"] → 规范化配置 dict（缺省/脏值回落默认）。

    默认（enabled=False）：
        enabled=False, max_concurrent=3, max_total=10, per_surface_requests=4,
        request_timeout=10.0, min_interval=0.2, max_endpoints_per_host=5
    夹紧：max_concurrent>=1, max_total>=0, per_surface_requests>=1,
        max_endpoints_per_host>=1, request_timeout>=0.1, min_interval>=0.0。
    """
    cfg: Dict[str, Any] = dict(_DEFAULTS)
    if isinstance(config, dict):
        raw = config.get("parallel_probe")
        src = raw if isinstance(raw, dict) else {}
        for key in _DEFAULTS:
            if key not in src or src[key] is None:
                continue
            value = src[key]
            if key == "enabled":
                cfg[key] = bool(value)
            elif isinstance(value, bool):
                continue  # 数值字段不接受 bool
            elif isinstance(_DEFAULTS[key], int):
                try:
                    cfg[key] = int(value)
                except (TypeError, ValueError):
                    pass
            else:
                try:
                    cfg[key] = float(value)
                except (TypeError, ValueError):
                    pass
    cfg["max_concurrent"] = max(1, int(cfg["max_concurrent"]))
    cfg["max_total"] = max(0, int(cfg["max_total"]))
    cfg["per_surface_requests"] = max(1, int(cfg["per_surface_requests"]))
    cfg["max_endpoints_per_host"] = max(1, int(cfg["max_endpoints_per_host"]))
    cfg["request_timeout"] = max(0.1, float(cfg["request_timeout"]))
    cfg["min_interval"] = max(0.0, float(cfg["min_interval"]))
    return cfg


# ---------------------------------------------------------------------------
# 自测（离线，零真实网络）：python scanners/parallel_probe.py
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    def _fake(url: str) -> Tuple[int, Dict[str, str], str]:
        return (200, {"Server": "nginx/1.25", "X-Powered-By": "PHP/8.2"}, "<html>ok</html>")

    _surfs = extract_surfaces(
        "found http://a.example.com:8080/admin and https://b.example.com/api",
        "http://a.example.com:8080/",
        scope_hosts={"a.example.com", "b.example.com"},
    )
    print(f"surfaces: {len(_surfs)} -> {[f'{s.scheme}://{s.host}:{s.port}{s.endpoint}({s.origin})' for s in _surfs]}")
    _res = probe_surface(_surfs[0], request_fn=_fake)
    print(f"probe: status={_res.status} requests={_res.requests_made} findings={len(_res.findings)}")
    _wave = probe_wave(_surfs, max_concurrent=2, max_total=2, per_surface_requests=2,
                       min_interval=0.0, request_fn=_fake)
    print(f"wave: {[r.status for r in _wave]}")
    _merged = merge_findings(_wave)
    print(f"merged findings: {len(_merged)}")
    print(f"config: {load_parallel_config({})}")
