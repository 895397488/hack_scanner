# from-source-of: Pentest-Swarm-AI (internal/agent/report/evidence/)
# 证据收集模块 — 自动提取漏洞发现的验证证据
"""
证据收集器。
核心算法源自 Pentest-Swarm-AI 的 evidence/evidence.go：
  - HTTP request 文件生成 (.http)
  - 屏幕截图 (gowitness integration)
  - 证据类型分类: screenshot, http_request, response_header, proof_text

纯 Python 实现，不依赖外部工具。
"""

import base64
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# 数据类型定义 (对应 pipeline.Evidence)
# ---------------------------------------------------------------------------

@dataclass
class EvidenceItem:
    """单条证据"""
    type: str = ""              # screenshot | http_request | response_header | proof_text | network_capture
    content: str = ""           # 证据内容
    timestamp: str = ""         # ISO 8601 时间戳
    description: str = ""       # 描述
    file_path: str = ""         # 关联的文件路径
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# 证据收集器 (对应 evidence.go Capture)
# ---------------------------------------------------------------------------

class EvidenceCollector:
    """
    为渗透测试发现自动收集和整理证据。

    支持证据类型：
        - http_request:   原始 HTTP 请求（可导入 Burp Repeater）
        - response_header: HTTP 响应头信息
        - proof_text:     漏洞证明文本/输出片段
        - screenshot:     屏幕截图描述（集成 gowitness 时自动生成）
        - network_capture: 网络抓包数据
    """

    def __init__(self, output_dir: str = ""):
        self.output_dir = output_dir

    def collect_finding_evidence(self, finding: Dict[str, Any]) -> List[EvidenceItem]:
        """
        从一条发现中收集所有可用的证据。

        对应 Go evidence.go Capture():
          - .http files: raw HTTP request for Burp import
          - screenshots: gowitness integration (if available)
          - response headers, proof text, etc.

        Args:
            finding: 包含以下字段的发现字典：
                - title:      发现标题
                - description: 描述
                - evidence:   已有证据列表
                - http_request: 原始 HTTP 请求
                - target:     目标 URL/host
                - response_headers: 响应头
                - matched_output: 匹配的输出文本

        Returns:
            EvidenceItem 列表
        """
        evidence_list = []
        now_ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

        # Layer 1: HTTP request 证据（对应 writeHTTPFile）
        http_req = finding.get("http_request", "")
        if http_req:
            evidence_list.append(EvidenceItem(
                type="http_request",
                content=http_req,
                timestamp=now_ts,
                description="原始 HTTP 请求（可用于 Burp Repeater 导入）",
                file_path=self._write_http_file(http_req, finding.get("title", "")),
            ))

        # Layer 2: Response header 证据
        headers = finding.get("response_headers", {})
        if isinstance(headers, dict) and headers:
            evidence_list.append(EvidenceItem(
                type="response_header",
                content=self._format_headers(headers),
                timestamp=now_ts,
                description="HTTP 响应头（包含技术栈和服务信息）",
            ))

        # Layer 3: Proof text 证据
        proof = finding.get("matched_output", "") or finding.get("description", "")
        if proof and not proof.startswith("{"):
            evidence_list.append(EvidenceItem(
                type="proof_text",
                content=proof[:2000],  # 限制长度
                timestamp=now_ts,
                description="漏洞匹配输出（证明该漏洞存在）",
            ))

        # Layer 4: Screenshot (如果 gowitness 可用)
        target = finding.get("target", "")
        if target and self._has_gowitness():
            shot_path = self._capture_screenshot(target, now_ts)
            if shot_path:
                evidence_list.append(EvidenceItem(
                    type="screenshot",
                    content="",  # 截图路径在 file_path 中
                    timestamp=now_ts,
                    description=f"漏洞页面截图 ({shot_path})",
                    file_path=shot_path,
                ))

        # Layer 5: HTTP response body proof (JSON/XML 格式提取)
        response_body = finding.get("response_body", "")
        if response_body and len(response_body.strip()) < 50000:
            # 尝试从响应体中提取关键信息
            extracted = self._extract_proof_from_response(response_body)
            if extracted:
                evidence_list.append(EvidenceItem(
                    type="proof_text",
                    content=extracted,
                    timestamp=now_ts,
                    description="从 HTTP 响应体提取的漏洞证据",
                ))

        # Layer 6: Network capture (如果有抓包数据)
        pcap_data = finding.get("pcap_data", "") or finding.get("network_capture", "")
        if pcap_data:
            evidence_list.append(EvidenceItem(
                type="network_capture",
                content=base64.b64encode(pcap_data.encode()).decode()[:10000],  # base64 编码
                timestamp=now_ts,
                description="网络捕获数据（原始数据包）",
            ))

        return evidence_list

    def collect_multi_finding_evidence(self, findings: List[Dict[str, Any]]) -> Dict[str, List[EvidenceItem]]:
        """
        批量收集多条发现的证据。

        Args:
            findings: 发现字典列表

        Returns:
            {finding_id: [evidence_items]} 映射
        """
        result = {}

        for f in findings:
            fid = f.get("id", f"{f.get('title', 'unknown')}_{hash(f.get('target', ''))}")
            evidence_list = self.collect_finding_evidence(f)
            result[fid] = evidence_list

        return result

    # ---------------------------------------------------------------
    # 内部辅助方法
    # ---------------------------------------------------------------

    def _write_http_file(self, http_request: str, title: str) -> str:
        """
        将原始 HTTP 请求写入 .http 文件。
        对应 Go writeHTTPFile(): Burp/VS Code REST Client/JetBrains HTTP Client 兼容格式。
        """
        if not self.output_dir:
            return ""

        slug = self._slug(title, 40)
        filename = f"{slug}.http"
        path = f"{self.output_dir}/{filename}"

        # CRLF 转换（Burp 需要）
        content = http_request.replace('\n', '\r\n')

        try:
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(content)
            return path
        except (IOError, OSError):
            return ""

    def _format_headers(self, headers: Dict[str, str]) -> str:
        """格式化响应头"""
        lines = []
        for key, value in headers.items():
            lines.append(f"{key}: {value}")
        return '\r\n'.join(lines)

    def _extract_proof_from_response(self, body: str) -> Optional[str]:
        """从 HTTP 响应体中提取关键漏洞证据"""
        # 尝试提取 JSON 中的敏感数据
        try:
            data = json.loads(body)
            # 提取可能的凭证/密钥/调试信息
            keywords = ['password', 'token', 'secret', 'api_key', 'apikey', 'key',
                        'credential', 'auth', 'debug', 'stacktrace', 'error']

            for key, value in data.items():
                key_lower = key.lower()
                if any(kw in key_lower for kw in keywords) and isinstance(value, str):
                    return f"Found sensitive field '{key}': {value[:200]}"
        except (json.JSONDecodeError, ValueError):
            pass

        # 尝试提取 XML 中的敏感信息
        xml_keywords = ['password', 'token', 'secret', 'username', 'credential']
        for kw in xml_keywords:
            pattern = rf'<{kw}[^>]*>(.*?)</{kw}>'
            match = re.search(pattern, body, re.IGNORECASE | re.DOTALL)
            if match and len(match.group(1).strip()) > 0:
                return f"Found XML field '{kw}': {match.group(1)[:200]}"

        # 尝试提取 HTML 中的敏感注释
        comment_matches = re.findall(r'<!--\s*(.*?)\s*-->', body, re.DOTALL)
        for comment in comment_matches:
            if any(kw in comment.lower() for kw in ['todo', 'fixme', 'password', 'secret', 'debug']):
                return f"Found HTML comment containing '{kw}': {comment[:200]}"

        return None

    @staticmethod
    def _has_gowitness() -> bool:
        """检查 gowitness 是否可用（静默跳过，非硬性要求）"""
        import subprocess
        try:
            result = subprocess.run(['which', 'gowitness'], capture_output=True, timeout=5)
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return False

    def _capture_screenshot(self, target_url: str, timestamp: str) -> str:
        """使用 gowitness 截图。若不可用则静默跳过"""
        import subprocess
        import os
        import time

        if not self.output_dir or not self._has_gowitness():
            return ""

        shot_dir = f"{self.output_dir}/screenshots"
        try:
            os.makedirs(shot_dir, exist_ok=True)
        except (IOError, OSError):
            return ""

        try:
            cmd = ['gowitness', 'single', '--url', target_url, '--screenshot-path', shot_dir]
            proc = subprocess.run(cmd, capture_output=True, timeout=30)
            if proc.returncode != 0:
                return ""
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            return ""

        # 返回截图目录中最晚的文件
        try:
            entries = os.listdir(shot_dir)
            png_files = [f for f in entries if f.endswith('.png')]
            if png_files:
                latest = max(png_files, key=lambda f: os.path.getmtime(f"{shot_dir}/{f}"))
                return f"{shot_dir}/{latest}"
        except (IOError, OSError):
            pass

        return ""

    @staticmethod
    def _slug(text: str, max_len: int) -> str:
        """生成文件名安全的 slug"""
        out = []
        for ch in text.lower():
            if 'a' <= ch <= 'z' or '0' <= ch <= '9':
                out.append(ch)
            elif ch in (' ', '-', '_'):
                out.append('-')
        result = ''.join(out).strip('-')
        if len(result) > max_len:
            result = result[:max_len]
        return result or "finding"

    def save_evidence_bundle(self, evidence_map: Dict[str, List[EvidenceItem]],
                             output_file: str = "") -> str:
        """将所有证据保存为 JSON bundle（用于报告引用）"""
        bundle = {}
        for fid, items in evidence_map.items():
            bundle[fid] = []
            for item in items:
                entry = {
                    "type": item.type,
                    "timestamp": item.timestamp,
                    "description": item.description,
                }
                if item.file_path:
                    entry["file_path"] = item.file_path
                # 对文本类证据，截断过长内容
                if item.content and len(item.content) > 5000:
                    entry["content"] = item.content[:5000] + "\n... (truncated)"
                else:
                    entry["content"] = item.content
                bundle[fid].append(entry)

        path = output_file or f"{self.output_dir}/evidence_bundle.json" if self.output_dir else "evidence_bundle.json"

        try:
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump(bundle, fh, indent=2, ensure_ascii=False)
            return path
        except (IOError, OSError):
            return ""
