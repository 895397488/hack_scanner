#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
扫描器风格报告渲染 — 自适应 campaign 的富报告（HTML 主报告 + Markdown 副报告）
=====================================================================

背景（2026-09-14 用户反馈）: LLM generate_report 只传 title/severity/description/evidence，
swarm_report_generator 的老模板把它们原样排出去 → 报告"好敷衍"：无风险评级、无修复建议、
无扫描元信息、无 tech/subdomain 面。

本模块对齐 url_scanner.ReportGenerator 的视觉语言（深色卡片/风险评级/修复建议盒），
数据来源全部确定性（不依赖 LLM 自觉传字段）:
    - 发现元数据: classify 工具结果（confidence/cve/attack_category，按标题匹配回并）
    - 修复建议/CWE: 关键词规则表自动补全（LLM 传了 remediation 则优先用 LLM 的）
    - 扫描面: tool_log 里最后一次成功的 reconnaissance（tech/subdomains/endpoints）
    - 扫描健康: tool_log 中的工具异常
    - 元信息: model/dry_run/工具调用数/用时

orchestrator / 老模板零改动：swarm_report_generator 保留给其他消费方。
"""

import html as _html
import json
import os
import re
import time
from typing import Any, Dict, List, Optional

SEV_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}

# 与 url_scanner 同款风险评级（critical×25 + high×15 + medium×5 + low×1）
def risk_rating(c: Dict[str, int]) -> Dict[str, Any]:
    score = (c.get("critical", 0) * 25 + c.get("high", 0) * 15
             + c.get("medium", 0) * 5 + c.get("low", 0) * 1)
    if score < 20:
        label, color = "🟢 SAFE", "#22c55e"
    elif score < 60:
        label, color = "🟡 MODERATE", "#eab308"
    elif score < 100:
        label, color = "🔴 HIGH RISK", "#f97316"
    else:
        label, color = "☠️ CRITICAL", "#ef4444"
    return {"score": score, "label": label, "color": color}


# ---------------------------------------------------------------------------
# 修复建议 / CWE 自动补全（关键词规则，按序取第一个命中）
# ---------------------------------------------------------------------------
RECOMMENDATION_RULES: List[tuple] = [
    (r"x-frame-options|clickjacking",
     "添加 X-Frame-Options: DENY（或 SAMEORIGIN）/ CSP frame-ancestors，防止 iframe 嵌入点击劫持", "CWE-1021"),
    (r"content-security-policy|\bcsp\b",
     "配置 Content-Security-Policy（default-src 'self' 起步），作为 XSS/注入的纵深防御", "CWE-1052"),
    (r"strict-transport-security|hsts|ssl-?stripping",
     "添加 Strict-Transport-Security: max-age=31536000; includeSubDomains，防 SSL 剥离/降级", "CWE-319"),
    (r"referrer-policy",
     "设置 Referrer-Policy: strict-origin-when-cross-origin，避免带敏感参数的完整 URL 泄露给第三方", "CWE-200"),
    (r"x-xss-protection",
     "旧浏览器兼容加 X-XSS-Protection: 1; mode=block；现代浏览器以 CSP 为主防线", "CWE-79"),
    (r"server\s*header|technology\s*stack|version\s*disclos|stack\s*disclos|fingerprint",
     "在 CDN/网关层抑制或泛化 Server/X-Powered-By 等指纹头，缩小攻击面测绘", "CWE-200"),
    (r"swagger|openapi|api[\s_-]?doc|api[\s_-]?spec",
     "限制 /api-docs、/swagger、/v1/openapi.json 等 API 文档为内网/鉴权访问，勿公开暴露", "CWE-200"),
    (r"path[\s_-]?traversal|directory[\s_-]?traversal|\blfi\b|\brfi\b",
     "路径规范化 + 白名单根目录；拒绝 .. 与绝对路径；最小权限运行", "CWE-22"),
    (r"directory\s*listing|autoindex|dir(?:ectory)?[\s_-]?bust",
     "关闭目录自动索引（autoindex off）；敏感目录加鉴权或 WAF 拦截", "CWE-548"),
    (r"sql[\s_-]?inject",
     "全面改用参数化查询/预编译；数据库账号最小权限；禁止字符串拼接 SQL", "CWE-89"),
    (r"cross[\s_-]?site\s*scripting|\bxss\b",
     "输出编码 + CSP + 输入校验；禁止把不可信输入原样渲染进 HTML/JS", "CWE-79"),
    (r"\bssrf\b|server[\s_-]?side\s*request",
     "URL 白名单；禁止访问内网/元数据地址（169.254.169.254、10/8、172.16/12、192.168/16）；禁用跟随重定向", "CWE-918"),
    (r"\bidor\b|\bbola\b|broken[\s_-]?object|horizontal[\s_-]?privilege|access[\s_-]?control|authorization",
     "每个资源请求做属主级授权校验（服务端会话绑定资源 ID，勿信客户端传入 ID）", "CWE-639"),
    (r"\bjwt\b|token\s*forge|auth[\s_-]?bypass|insecure[\s_-]?deserialization|alg(?:orithm)?\s*confusion",
     "校验签名与 alg（禁 none/算法混淆）、强制 exp/nbf、密钥入 KMS 并定期轮换", "CWE-347"),
    (r"credential|password\s*in|hardcod|secret|api[\s_-]?key\s*expos|exposed\s*(?:key|token)",
     "立即轮换已泄露凭据；迁移到密钥管理服务；审计访问日志排查横向利用", "CWE-798"),
    (r"\bcors\b|cross[\s_-]?origin",
     "Origin 白名单校验；禁止反射任意 Origin 且带 Access-Control-Allow-Credentials", "CWE-942"),
    (r"cleartext|insecure\s*transport|http\s*without\s*tls|plain\s*text",
     "全站强制 TLS + HSTS，下线明文端点", "CWE-319"),
    (r"debug|test\s*endpoint|admin\s*endpoint|backdoor|\.env\b|\.git\b|backup\s*file|sensitive\s*file",
     "移除调试/备份/测试入口与 VCS 元数据；补 WAF 规则 + 外网访问告警", "CWE-497"),
    (r"rate[\s_-]?limit|brute[\s_-]?force",
     "加速率限制 + 失败锁定 + 重要接口 MFA", "CWE-307"),
    (r"unauth|missing\s*auth|no\s*auth",
     "补认证并做逐路由授权；默认拒绝未认证访问", "CWE-306"),
]

_FALLBACK_REMEDIATION = {
    "critical": "立即修复并回归验证：确认利用路径、消除暴露面，加回归用例",
    "high": "本迭代内修复：补丁/配置加固，纳入定期回归扫描",
    "medium": "30 天内修复：修复后复测，加监控告警",
    "low": "低优先级加固：可随下个版本批量修复",
    "info": "信息级提示：按需加固，无需紧急处理",
}


def _match_rule(text: str) -> Optional[tuple]:
    low = (text or "").lower()
    for pattern, rec, cwe in RECOMMENDATION_RULES:
        if re.search(pattern, low):
            return rec, cwe
    return None


def enrich_finding(raw: dict, classified: Optional[dict]) -> dict:
    """把 LLM 传的最小字段补全成扫描器报告条目。

    classified: 按标题匹配到的 classify 结果（confidence/cve/category），可为 None。
    """
    title = str(raw.get("title") or raw.get("detail") or "未命名发现")
    sev = str(raw.get("severity") or (classified or {}).get("severity") or "medium").lower()
    if sev not in SEV_ORDER:
        sev = "medium"
    text = f"{title} {raw.get('description', '')} {raw.get('detail', '')} " \
           f"{(classified or {}).get('attack_category', '')}"
    rule = _match_rule(text)
    rec = str(raw.get("remediation") or (classified or {}).get("remediation") or "")
    cwe = str(raw.get("cwe") or "")
    if rule:
        rec = rec or rule[0]
        cwe = cwe or rule[1]
    if not rec:
        rec = _FALLBACK_REMEDIATION.get(sev, _FALLBACK_REMEDIATION["info"])
    return {
        "title": title,
        "severity": sev,
        "cvss": float(raw.get("cvss_score") or (classified or {}).get("cvss_score") or 0.0),
        "cvss_vector": str(raw.get("cvss_vector") or (classified or {}).get("cvss_vector") or ""),
        "description": str(raw.get("description") or raw.get("detail") or ""),
        "evidence": raw.get("evidence") or "",
        "target": str(raw.get("target") or raw.get("url") or (classified or {}).get("target") or ""),
        "cwe": cwe,
        "confidence": str((classified or {}).get("confidence") or ""),
        "cve_ids": list((classified or {}).get("cve_ids") or []),
        "category": str((classified or {}).get("attack_category") or ""),
        "remediation": rec,
    }


def _norm_title(t: str) -> str:
    return re.sub(r"\s+", " ", str(t or "").strip().lower())


def _core_title(t: str) -> str:
    """更激进的归一化：只留字母数字——'…(Clickjacking)' vs '…(Clickjacking Risk)' 这类
    括号措辞差异仍能按包含关系命中。"""
    return re.sub(r"[^a-z0-9]", "", str(t or "").lower())


def match_classified(raw_findings: List[dict], tool_log: Optional[list]) -> List[Optional[dict]]:
    """按标题（归一化后相等或包含）把 classify 结果回并到 LLM 的 findings。"""
    classified: List[dict] = []
    for r in reversed(tool_log or []):
        if r.get("tool") != "classify" or r.get("error"):
            continue
        try:
            data = json.loads(r.get("result") or "")
            classified = [f for f in (data.get("findings") or []) if isinstance(f, dict)]
        except (json.JSONDecodeError, TypeError, ValueError):
            pass
        break

    out: List[Optional[dict]] = []
    for raw in raw_findings:
        t = _norm_title(raw.get("title") or raw.get("detail"))
        tc = _core_title(t)
        hit = None
        if t:
            for c in classified:
                ct = _norm_title(c.get("title"))
                if not ct:
                    continue
                if t == ct or (len(t) >= 8 and len(ct) >= 8 and (t in ct or ct in t)):
                    hit = c
                    break
                # 括号措辞差异兜底：'(clickjacking)' vs '(clickjacking risk)'
                cc = _core_title(ct)
                if len(tc) >= 8 and len(cc) >= 8 and (tc in cc or cc in tc):
                    hit = c
                    break
        out.append(hit)
    return out


def extract_recon_info(tool_log: Optional[list]) -> Dict[str, Any]:
    """tool_log 里最后一次成功 reconnaissance 的 tech/subdomains/endpoints。"""
    info = {"tech": [], "subdomains": [], "endpoints": []}
    for r in reversed(tool_log or []):
        if r.get("tool") != "reconnaissance" or r.get("error"):
            continue
        try:
            data = json.loads(r.get("result") or "")
        except (json.JSONDecodeError, TypeError, ValueError):
            continue
        tech = data.get("tech") or {}
        if isinstance(tech, dict):
            info["tech"] = [f"{k}: {v}" if v else k for k, v in list(tech.items())[:20]]
        elif isinstance(tech, list):
            info["tech"] = [str(t) for t in tech[:20]]
        info["subdomains"] = [str(s) for s in (data.get("subdomains") or [])[:50]]
        info["endpoints"] = [str(u) for u in (data.get("endpoints") or [])[:50]]
        return info
    return info


def extract_tool_errors(tool_log: Optional[list]) -> List[str]:
    errs = [f"{r.get('tool')}: {str(r.get('error'))[:160]}" for r in (tool_log or [])
            if r.get("error")]
    return errs[:10]


def build_report_data(target: str, objective: str, findings_raw: List[dict],
                      tool_log: Optional[list] = None, model_info: str = "",
                      dry_run: bool = True, elapsed: float = 0.0,
                      generated_at: str = "") -> Dict[str, Any]:
    """聚合所有确定性数据源 → 单一 data dict（md/html 两个渲染器共用）。"""
    raws = [f for f in (findings_raw or []) if isinstance(f, dict)][:50]
    classifieds = match_classified(raws, tool_log)
    findings = [enrich_finding(raw, cls) for raw, cls in zip(raws, classifieds)]
    findings.sort(key=lambda f: (SEV_ORDER[f["severity"]], -f["cvss"]))

    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in findings:
        counts[f["severity"]] += 1

    recon = extract_recon_info(tool_log)
    tool_seq = [str(r.get("tool")) for r in (tool_log or []) if r.get("tool")]

    return {
        "target": target,
        "objective": objective,
        "generated_at": generated_at or time.strftime("%Y-%m-%d %H:%M:%S"),
        "model_info": model_info,
        "dry_run": dry_run,
        "elapsed": round(elapsed, 1),
        "counts": counts,
        "total": len(findings),
        "risk": risk_rating(counts),
        "findings": findings,
        "tech": recon["tech"],
        "subdomains": recon["subdomains"],
        "endpoints": recon["endpoints"],
        "tool_seq": tool_seq,
        "tool_errors": extract_tool_errors(tool_log),
    }


# ---------------------------------------------------------------------------
# Markdown 渲染（副报告：元信息 + 风险评级 + 补全后的发现）
# ---------------------------------------------------------------------------
def render_markdown(d: Dict[str, Any]) -> str:
    L: List[str] = []
    L.append("# AI 自适应渗透测试报告\n")
    L.append(f"**目标:** {d['target']}  ")
    L.append(f"**测试目标:** {d['objective']}  ")
    L.append(f"**生成时间:** {d['generated_at']}  ")
    L.append(f"**执行模式:** {'dry-run（未真实执行利用）' if d['dry_run'] else '⚠️ LIVE'}  ")
    if d.get("model_info"):
        L.append(f"**LLM:** {d['model_info']}  ")
    L.append("---\n")

    L.append("## 风险评级\n")
    r = d["risk"]
    L.append(f"**{r['label']}**（综合评分: {r['score']}）\n")
    L.append("| 严重级 | 数量 |")
    L.append("|---|---|")
    for sev, label in (("critical", "严重 Critical"), ("high", "高危 High"),
                       ("medium", "中危 Medium"), ("low", "低危 Low"), ("info", "信息 Info")):
        L.append(f"| {label} | {d['counts'][sev]} |")
    L.append("")

    L.append("## 扫描信息\n")
    L.append("| 项目 | 值 |")
    L.append("|---|---|")
    L.append(f"| 工具调用 | {len(d['tool_seq'])} 次 |")
    if d["tool_seq"]:
        L.append(f"| 工具序列 | {' → '.join(d['tool_seq'])} |")
    if d["elapsed"]:
        L.append(f"| 用时 | {d['elapsed']}s |")
    L.append("")

    if d["tech"]:
        L.append(f"## 技术栈 ({len(d['tech'])})\n")
        for t in d["tech"]:
            L.append(f"- `{t}`")
        L.append("")

    L.append(f"## 漏洞清单 ({d['total']})\n")
    if not d["findings"]:
        L.append("✅ 未检测到明显漏洞\n")
    for i, f in enumerate(d["findings"], 1):
        L.append(f"### {i}. [{f['severity'].upper()}] {f['title']}")
        meta = f"CVSS: {f['cvss']:.1f}"
        if f["cwe"]:
            meta += f" | {f['cwe']}"
        if f["confidence"]:
            meta += f" | 置信度: {f['confidence']}"
        if f["cve_ids"]:
            meta += f" | {', '.join(f['cve_ids'])}"
        L.append(f"\n_{meta}_\n")
        if f["description"]:
            L.append(f["description"] + "\n")
        if f["target"]:
            L.append(f"🔗 `{f['target']}`\n")
        ev = f["evidence"]
        if isinstance(ev, list):
            ev = "\n".join(str(e) for e in ev[:10])
        if ev:
            L.append("**证据:**\n")
            L.append(f"```\n{str(ev)[:800]}\n```\n")
        L.append(f"**💡 修复建议:** {f['remediation']}\n")
        L.append("---\n")

    if d["subdomains"]:
        L.append(f"## 子域名 ({len(d['subdomains'])})\n")
        for s in d["subdomains"]:
            L.append(f"- {s}")
        L.append("")
    if d["endpoints"]:
        L.append(f"## 发现的端点 ({len(d['endpoints'])})\n")
        for u in d["endpoints"]:
            L.append(f"- {u}")
        L.append("")
    if d["tool_errors"]:
        L.append("## 扫描健康（工具异常）\n")
        for e in d["tool_errors"]:
            L.append(f"- ⚠️ {e}")
        L.append("")

    L.append("---\n")
    L.append("*Hack Scanner v8.0 · AI 自适应 | 本报告仅供授权安全测试使用，请遵守相关法律法规*\n")
    return "\n".join(L)


# ---------------------------------------------------------------------------
# HTML 渲染（主报告：对齐 url_scanner.ReportGenerator 视觉语言）
# ---------------------------------------------------------------------------
def _evd_text(ev: Any) -> str:
    """evidence 兼容 str / list 两种形态 → 单行文本。"""
    if isinstance(ev, list):
        return "\n".join(str(x) for x in ev[:10])
    return str(ev or "")


def render_html(d: Dict[str, Any]) -> str:
    e = _html.escape
    r = d["risk"]
    total = d["total"]

    head = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 AI 自适应渗透测试报告 - {e(d['target'])}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', system-ui, sans-serif; background: #0d1117; color: #c9d1d9; line-height: 1.6; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 2rem; }}
        header {{ text-align: center; padding: 3rem 0; border-bottom: 1px solid #21262d; margin-bottom: 2rem; }}
        h1 {{ font-size: 2.5rem; background: linear-gradient(135deg, #58a6ff, #f78166); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }}
        .target {{ color: #8b949e; font-size: 1.2rem; margin-top: 0.5rem; word-break: break-all; }}
        .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 2rem 0; }}
        .card {{ background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 1.5rem; text-align: center; }}
        .card .num {{ font-size: 2.5rem; font-weight: bold; }}
        .card .label {{ color: #8b949e; margin-top: 0.5rem; }}
        .risk {{ text-align: center; padding: 1.5rem; border-radius: 12px; font-size: 1.3rem; font-weight: bold; margin: 2rem 0; }}
        .finding {{ background: #161b22; border-left: 4px solid; border-radius: 8px; padding: 1.2rem; margin: 0.8rem 0; }}
        .critical {{ border-color: #dc3545; }} .critical .sev {{ color: #dc3545; }}
        .high {{ border-color: #fd7e14; }} .high .sev {{ color: #fd7e14; }}
        .medium {{ border-color: #ffc107; }} .medium .sev {{ color: #ffc107; }}
        .low {{ border-color: #17a2b8; }} .low .sev {{ color: #17a2b8; }}
        .info {{ border-color: #6c757d; }} .info .sev {{ color: #6c757d; }}
        .sev {{ font-weight: bold; text-transform: uppercase; font-size: 0.85rem; }}
        .finding h3 {{ margin: 0.5rem 0; color: #e6edf3; }}
        .finding .url {{ word-break: break-all; color: #58a6ff; font-size: 0.9rem; margin: 0.3rem 0; }}
        .finding .meta {{ color: #8b949e; font-size: 0.85rem; }}
        .finding .rec {{ background: #1c2333; padding: 0.8rem; border-radius: 6px; margin-top: 0.8rem; font-size: 0.9rem; color: #7ee787; }}
        .finding .evd {{ background: #1c2333; padding: 0.8rem; border-radius: 6px; margin-top: 0.5rem; font-family: monospace; font-size: 0.85rem; color: #ffa657; white-space: pre-wrap; word-break: break-all; }}
        .section-title {{ font-size: 1.5rem; margin: 2rem 0 1rem; color: #e6edf3; border-bottom: 2px solid #30363d; padding-bottom: 0.5rem; }}
        footer {{ text-align: center; padding: 2rem 0; color: #484f58; font-size: 0.9rem; margin-top: 3rem; border-top: 1px solid #21262d; }}
        .tech-list {{ display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 1rem 0; }}
        .tag {{ background: #21262d; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.85rem; color: #79c0ff; }}
        table {{ width: 100%; border-collapse: collapse; margin: 1rem 0; }}
        th, td {{ padding: 0.6rem; text-align: left; border-bottom: 1px solid #21262d; word-break: break-all; }}
        th {{ color: #8b949e; font-size: 0.9rem; }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🤖 AI 自适应渗透测试报告</h1>
            <p class="target">{e(d['target'])}</p>
            <p style="color:#484f58; margin-top:0.5rem;">生成时间: {e(d['generated_at'])}</p>
        </header>

        <div class="summary">
            <div class="card"><div class="num">{total}</div><div class="label">总发现数</div></div>
            <div class="card" style="border-color: #dc3545;"><div class="num" style="color:#dc3545;">{d['counts']['critical']}</div><div class="label">严重 (Critical)</div></div>
            <div class="card" style="border-color: #fd7e14;"><div class="num" style="color:#fd7e14;">{d['counts']['high']}</div><div class="label">高危 (High)</div></div>
            <div class="card"><div class="num">{d['counts']['medium']}</div><div class="label">中危 (Medium)</div></div>
        </div>

        <div class="risk" style="background: #161b22; border: 1px solid {r['color']};">
            风险评级: {r['label']} (综合评分: {r['score']})
        </div>

        <h2 class="section-title">📋 扫描信息</h2>
        <table>
            <tr><th>测试目标</th><td>{e(d['objective'])}</td></tr>
            <tr><th>执行模式</th><td>{'dry-run（未真实执行利用）' if d['dry_run'] else '⚠️ LIVE'}</td></tr>
            {'<tr><th>LLM 模型</th><td>' + e(d['model_info']) + '</td></tr>' if d.get('model_info') else ''}
            <tr><th>工具调用</th><td>{len(d['tool_seq'])} 次{' ｜ ' + e(' → '.join(d['tool_seq'])) if d['tool_seq'] else ''}</td></tr>
            {'<tr><th>用时</th><td>' + e(str(d["elapsed"])) + 's</td></tr>' if d["elapsed"] else ''}
        </table>
"""

    out = [head]

    # 漏洞清单（核心内容优先，紧随风险评级）
    if d["findings"]:
        parts = [f'<h2 class="section-title">🐛 漏洞清单 ({d["total"]})</h2>']
        for f in d["findings"]:
            sev = str(f["severity"]).lower()
            if sev not in ("critical", "high", "medium", "low", "info"):
                sev = "medium"
            meta = f'CVSS {f["cvss"]:.1f}'
            if f.get("cwe"):
                meta += f' · {e(f["cwe"])}'
            if f.get("confidence"):
                meta += f' · 置信度 {e(f["confidence"])}'
            if f.get("cve_ids"):
                meta += ' · ' + e(", ".join(f["cve_ids"]))
            card = (
                f'<div class="finding {sev}">'
                f'<div class="sev">{sev}</div>'
                f'<h3>{e(f["title"])}</h3>'
                f'<div class="meta">{meta}</div>'
            )
            if f.get("target"):
                card += f'<div class="url">🔗 {e(f["target"])}</div>'
            if f.get("description"):
                card += f'<p>{e(f["description"])}</p>'
            ev = _evd_text(f.get("evidence"))
            if ev:
                card += f'<div class="evd">{e(ev[:1200])}</div>'
            card += f'<div class="rec">💡 修复建议: {e(f["remediation"])}</div></div>'
            parts.append(card)
        out.append("\n".join(parts))
    else:
        out.append('<h2 class="section-title">🐛 漏洞清单 (0)</h2>'
                   '<p style="color:#22c55e">✅ 未检测到明显漏洞</p>')

    if d["tech"]:
        out.append(f'<h2 class="section-title">📦 技术栈 ({len(d["tech"])})</h2><div class="tech-list">'
                   + ''.join(f'<span class="tag">{e(t)}</span>' for t in d["tech"])
                   + '</div>')
    if d["subdomains"]:
        out.append(f'<h2 class="section-title">🌳 子域名 ({len(d["subdomains"])})</h2>'
                   '<table><tr><th>子域名</th></tr>'
                   + ''.join(f'<tr><td style="color:#79c0ff">{e(s)}</td></tr>' for s in d["subdomains"])
                   + '</table>')
    if d["endpoints"]:
        out.append(f'<h2 class="section-title">🔗 发现的端点 ({len(d["endpoints"])})</h2>'
                   '<table><tr><th>端点</th></tr>'
                   + ''.join(f'<tr><td style="word-break:break-all">{e(u)}</td></tr>' for u in d["endpoints"])
                   + '</table>')

    if d["tool_errors"]:
        out.append('<h2 class="section-title">🩺 扫描健康（工具异常）</h2>'
                   + ''.join(
                       f'<div style="background:#161b22;border:1px solid #30363d;border-radius:8px;'
                       f'padding:0.8rem;margin:0.4rem 0;color:#ffa657">⚠️ {e(t)}</div>'
                       for t in d["tool_errors"]))

    out.append('<footer>Hack Scanner v8.0 · AI 自适应 | 本报告仅供授权安全测试使用，请遵守相关法律法规</footer>')
    out.append('</div>\n</body>\n</html>')
    return "\n".join(out)
