#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI 自动漏洞分析模块 v2.0 — 多 AI 代理
======================================
支持所有已知大模型厂商的 API，自动适配不同协议：
- OpenAI 兼容 (qwen/glm/moonshot/deepseek/siliconflow/gemini/openai/vllm/lmdeploy)
- Anthropic Claude 原生协议
- Ollama 本地流式 JSONL

用法:
    python hack_scanner.py --url URL --ai
    python ai_analyzer.py https://target.com       # 独立运行
"""

import os
import sys
import json
import re
import time
import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger('ai_analyzer')

# ==================== Tool Call Limiter (借鉴 PentAGI) ====================
MAX_GENERAL_CALLS = 50
MAX_LIMITED_CALLS = 20

class CallLimiter:
    """追踪 AI 调用次数，防止死循环。借鉴 PentAGI tool call limits。"""
    def __init__(self, mode: str = 'general'):
        self.mode = mode
        self.call_count = 0
        self.limit = MAX_LIMITED_CALLS if mode == 'limited' else MAX_GENERAL_CALLS
        self.exhausted = False
    def check(self) -> bool:
        """返回 True=可以继续调用, False=已用完"""
        if self.exhausted:
            return False
        self.call_count += 1
        if self.call_count > self.limit:
            self.exhausted = True
            logger.warning(f"⚠️ AI 工具调用已达上限 ({self.limit})，停止进一步分析")
            return False
        return True
    def status(self) -> dict:
        return {'mode': self.mode, 'call_count': self.call_count,
                'limit': self.limit, 'remaining': max(0, self.limit - self.call_count),
                'exhausted': self.exhausted}

# ========== 当前目录的配置文件 ==========
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_CONFIG_PATH = os.path.join(_SCRIPT_DIR, 'config.json')
with open(_CONFIG_PATH, 'r', encoding='utf-8') as f:
    CONFIG = json.load(f)

# ========== Ollama 实时模型识别（防止自动拉取未安装模型）==========
def _model_size_mb(name: str) -> float:
    """解析模型 tag 中的参数量（'qwen3:35b' → 35）；无法解析返回 -1"""
    try:
        tag = str(name).rsplit(':', 1)[-1].lower()
        m = re.match(r'^(\d+(?:\.\d+)?)b?$', tag)
        if m:
            return float(m.group(1))
    except Exception:
        pass
    return -1.0


def _model_family(name: str) -> str:
    """提取家族名（名称部分的前导字母）: 'qwen3.6:35b' → 'qwen'"""
    try:
        m = re.match(r'^[a-z]+', str(name).lower().split(':', 1)[0])
        return m.group(0) if m else ''
    except Exception:
        return ''


def pick_ollama_model(installed: List[str], preferred: Optional[str] = None) -> Optional[str]:
    """从已安装列表挑选一个本地可用模型。

    规则: preferred 精确命中 → 同家族（如 qwen*）中参数最大 → 全局最大 → 第一个。
    列表为空返回 None。
    """
    if not installed:
        return None
    names = [str(n) for n in installed if n]
    if not names:
        return None
    if preferred and preferred in names:
        return preferred
    if preferred:
        fam = _model_family(preferred)
        cands = [n for n in names if fam and _model_family(n) == fam]
        if cands:
            return sorted(cands, key=_model_size_mb, reverse=True)[0]
    return sorted(names, key=_model_size_mb, reverse=True)[0]


# ========== AI 提供商矩阵（内置）==========
PROVIDER_DB = {
  "providers": {
    "qwen": {"name":"通义千问 Qwen","display_name":"Qwen","category":"国产商业","api_type":"openai_compatible","default_base_url":"https://dashscope.aliyuncs.com/compatible-mode/v1","env_api_key":"DASHSCOPE_API_KEY","default_model":"qwen-plus","models":["qwen-turbo","qwen-plus","qwen-max","qwen-max-latest","qwen-vl-plus","qwen-vl-max"],"api_path":"/v1/chat/completions"},
    "glm": {"name":"智谱 GLM","display_name":"GLM","category":"国产商业","api_type":"openai_compatible","default_base_url":"https://open.bigmodel.cn/api/paas/v4/chat/completions","env_api_key":"ZHIPUAI_API_KEY","default_model":"glm-4-flash","models":["glm-4","glm-4-plus","glm-4-airx","glm-4-air","glm-4-flash","glm-5"],"api_path":"/api/paas/v4/chat/completions"},
    "moonshot": {"name":"月之暗面 Kimi","display_name":"Kimi","category":"国产商业","api_type":"openai_compatible","default_base_url":"https://api.moonshot.cn/v1/chat/completions","env_api_key":"MOONSHOT_API_KEY","default_model":"moonshot-v1-8k","models":["moonshot-v1-8k","moonshot-v1-32k","moonshot-v1-128k"],"api_path":"/v1/chat/completions"},
    "deepseek": {"name":"深度求索 DeepSeek","display_name":"DeepSeek","category":"国产商业","api_type":"openai_compatible","default_base_url":"https://api.deepseek.com/v1/chat/completions","env_api_key":"DEEPSEEK_API_KEY","default_model":"deepseek-chat","models":["deepseek-chat","deepseek-coder","deepseek-reasoner"],"api_path":"/v1/chat/completions"},
    "siliconflow": {"name":"硅基流动 SiliconFlow","display_name":"SiliconFlow","category":"国产商业","api_type":"openai_compatible","default_base_url":"https://api.siliconflow.cn/v1/chat/completions","env_api_key":"SILICONFLOW_API_KEY","default_model":"Qwen/Qwen2.5-7B-Instruct","models":["Qwen/Qwen2.5-72B-Instruct","meta-llama/Llama-3.3-70B-Instruct"],"api_path":"/v1/chat/completions"},
    "gemini": {"name":"Google Gemini","display_name":"Gemini","category":"国际商业","api_type":"openai_compatible","default_base_url":"https://generativelanguage.googleapis.com/v1beta/openai/chat/completions","env_api_key":"GEMINI_API_KEY","default_model":"gemini-2.0-flash","models":["gemini-2.5-pro-preview-05-06","gemini-2.0-flash","gemini-2.0-flash-lite","gemini-1.5-flash"],"api_path":"/v1beta/openai/chat/completions"},
    "openai": {"name":"OpenAI GPT","display_name":"OpenAI","category":"国际商业","api_type":"openai_compatible","default_base_url":"https://api.openai.com/v1/chat/completions","env_api_key":"OPENAI_API_KEY","default_model":"gpt-4.1-mini","models":["gpt-4.1","gpt-4.1-mini","gpt-4o-mini","gpt-4o","gpt-4-turbo"],"api_path":"/v1/chat/completions"},
    "claude": {"name":"Anthropic Claude","display_name":"Claude","category":"国际商业","api_type":"anthropic","default_base_url":"https://api.anthropic.com/v1/messages","env_api_key":"ANTHROPIC_API_KEY","default_model":"claude-sonnet-4-20250514","models":["claude-opus-4-1","claude-sonnet-4-20250514","claude-haiku-4-20250514"],"api_path":"/v1/messages"},
    "ollama": {"name":"Ollama 本地开源","display_name":"Ollama","category":"本地开源","api_type":"ollama","default_base_url":"http://127.0.0.1:11434","env_api_key":None,"default_model":"","models":["qwen3.6:35b","qwen3:8b","gemma4:31b"],"api_path":"/api/chat"},
    "vllm": {"name":"vLLM 本地推理","display_name":"vLLM","category":"本地开源","api_type":"openai_compatible","default_base_url":"http://127.0.0.1:8000/v1/chat/completions","env_api_key":None,"default_model":"Qwen/Qwen2.5-7B-Instruct","models":["Qwen/Qwen2.5-7B-Instruct","meta-llama/Llama-3.3-70B-Instruct"],"api_path":"/v1/chat/completions"},
    "lmdeploy": {"name":"LMDeploy 本地推理","display_name":"LMDeploy","category":"本地开源","api_type":"openai_compatible","default_base_url":"http://127.0.0.1:23333/v1/chat/completions","env_api_key":None,"default_model":"Qwen/Qwen2.5-7B-Instruct","models":["Qwen/Qwen2.5-7B-Instruct"],"api_path":"/v1/chat/completions"}
  },
  "list_all_models": {"ollama":["qwen3.6:35b","qwen3:8b","gemma4:31b"],"vllm":["Qwen/Qwen2.5-7B-Instruct"],"lmdeploy":["Qwen/Qwen2.5-7B-Instruct"]}
}


class AIAnalyzer:
    """多 AI 代理分析器 — 统一接口，自动适配底层协议"""

    def __init__(self):
        ai_conf = CONFIG.get('ai', {})
        self.enabled = ai_conf.get('enabled', False)
        if not self.enabled:
            return

        # 解析 provider 配置
        self.provider_key = ai_conf.get('provider', 'ollama')
        self.model = ai_conf.get('model', '')
        self.base_url = ai_conf.get('base_url', '')
        self.api_key = ai_conf.get('api_key', '')
        self.temperature = ai_conf.get('temperature', 0.2)
        self.max_tokens = ai_conf.get('max_tokens', 8192)

        # 从 providers 矩阵获取 provider 元信息
        provider_info = PROVIDER_DB.get('providers', {}).get(self.provider_key, {})
        self.api_type = provider_info.get('api_type', 'openai_compatible') if provider_info else 'ollama'
        self.display_name = provider_info.get('display_name', self.provider_key) if provider_info else self.provider_key
        self.category = provider_info.get('category', '') if provider_info else ''

        # 自动填充默认值（Ollama 默认"无模型"状态：不预置模型名，调用时自动识别本机已装模型）
        if not self.model:
            if self.api_type == 'ollama':
                logger.info("🔍 Ollama: 未指定模型，处于'无模型'状态，调用时将自动识别本机已安装模型")
            else:
                self.model = provider_info.get('default_model', '') if provider_info else ''
        if not self.base_url:
            self.base_url = provider_info.get('default_base_url', 'http://127.0.0.1:11434') if provider_info else 'http://127.0.0.1:11434'

        # 自动设置 API Key（防御 None）
        env_key = provider_info.get('env_api_key') if provider_info else None
        if not self.api_key and env_key:
            self.api_key = os.environ.get(env_key, '')

        logger.info(f"✅ AI 代理已启用: [{self.category}] {self.display_name} | "
                    f"模型={self.model or '(自动识别本机)'} | API协议={self.api_type}")

    def _get_env_key(self) -> str:
        """获取对应 provider 的环境变量 Key"""
        info = PROVIDER_DB.get('providers', {}).get(self.provider_key, {})
        return info.get('env_api_key') if info else None

    # ==================== 核心方法 ====================

    def analyze(self, scan_result: Dict[str, Any]) -> Dict[str, Any]:
        """分析扫描结果，返回 AI 解读报告"""
        if not self.enabled:
            return {'error': 'AI 未启用。在 config.json 中设置 ai.enabled=true'}

        findings = scan_result.get('url_findings', []) + scan_result.get('file_findings', [])
        summary = scan_result.get('summary', {})

        # Context Summarizer：当 findings 过多时自动压缩（借鉴 PentAGI csum）
        if len(findings) > 100:
            found = self.summarize_findings(findings, max_keep=100)
            findings_list = found['findings']
            compression_info = f" [已压缩: {found['original_count']}→{found['kept_count']}条]"
        else:
            findings_list = findings
            compression_info = ""

        # 目标信息（URL 或文件路径）
        target = summary.get('url_target') or summary.get('file_path', 'N/A')
        scan_type = 'URL' if summary.get('url_target') else ('文件' if summary.get('file_path') else '未知')
        technologies = summary.get('url_technologies', [])
        subdomains_list = summary.get('url_subdomains', [])

        system_prompt = '''你是一个专业的网络安全分析师（Penetration Tester / SRC 研究员），输出格式**严格遵循高质量 SRC 报告标准**。

## 你必须遵守的输出规范：

### 1. 风险评估摘要
- 总体安全状况评价（一句话）
- 关键发现清单（列出所有 Critical/High 漏洞的名称+CVSS）
- **数据量级评估**（如果有 ImpactEvaluator 结果，标注影响的用户数级）

### 2. 高危漏洞详情 — 逐条按 SRC 标准格式输出

每条高危/严重漏洞必须包含以下6个部分：

#### 🔴【漏洞信息】
```
标题: [类型] - [目标模块] - [核心危害]
影响URL: <完整URL>
漏洞类型: CWE-XXX / OWASP分类
严重程度: Critical | High | Medium
CVSS评分: X.X
```

#### 📝【复现步骤】
用编号列出，确保**任何人按步骤能100%复现**：
```
前置条件: 需要普通用户账号 / 无需认证
Step 1: GET https://target.com/api/user?id=1
Step 2: 将 id 改为 XX，发送请求...
预期结果: 应返回 403 或仅自己的数据
实际结果: 返回了其他用户的手机号、身份证等
```

#### 💻【PoC / HTTP 原文】
提供**可直接 curl / Burp Repeater 使用的原始请求**，用 ```http 代码块包裹：
```http
GET /api/user?id=2 HTTP/1.1
Host: target.com
User-Agent: Mozilla/5.0...
```

#### 💥【影响证明】（关键！必须证明实际危害）
- **不要写**："理论上可能导致..." — 这种话没有价值
- **要写**：成功读取了什么、导出了多少数据、涉及什么敏感字段
- 示例：`"通过修改 id=1→2，成功获取到用户A的真实手机号 138****5678、邮箱 user@example.com"`
- 如果有 ImpactEvaluator 评估结果：标注 `影响范围: [XX条记录] / [敏感字段级别]`

#### 🛠【修复建议】（具体到代码/配置级别）
- **不要写**："请修复" — 泛泛而谈无意义
- **要写**具体技术方向，例如：
  ```
  IDOR: 服务端校验 resource.owner_id == current_user.id
  SQLi: 使用 PreparedStatement / 参数化查询
  CSRF: 添加 SameSite=Strict + 请求级 CSRF Token
  弱口令: 强制最少8位含大小写+数字，连续失败5次锁定账户
  CRLF: 过滤 %0d%0a，对Header输入做白名单校验
  JWT: 服务端强制验证alg白名单，拒绝none-alg攻击
  GraphQL: production禁用introspection + query depth limit
  Subdomain Takeover: 检查DNS CNAME指向的服务是否仍在使用
  HPP: 后端应只取第一个参数值或明确定义合并行为
  ```

#### 🧪【验证方法】
如何确认漏洞已修复（给测试人员的验收标准）：
```
修改 id 为其他值后，应返回 {"error": "Unauthorized"} 或仅返回自己的数据
```

### 3. 低危 / 建议项
批量列出 Low/Info 级别发现及修复建议。

### 4. 🎯【下一步扫描策略】（如有深层风险）
如果发现了可能相关的深层漏洞，建议追加的扫描策略：
- 具体命令/工具（subfinder/nuclei/httpx/Burp等）
- 重点关注的模块或参数

## 特别注意以下新增检测类型（Pentest-Swarm-AI 借鉴）：

### CRLF Injection (CWE-93)
- 检测HTTP响应头拆分攻击，可能导致cookie注入、XSS、缓存投毒
- 高危场景: Set-Cookie覆盖、Location重定向劫持
- CVSS通常 >= 7.4

### JWT Token Vulnerabilities (CWE-327/CWE-798)
- none-alg绕过: 最严重，直接导致认证 bypass → **Critical**
- 弱密钥(HMAC): 攻击者可伪造任意用户token → **Critical**
- JWT在URL中暴露: 信息泄露风险 → **Medium**
- Payload含敏感字段(密码/银行卡等): 非加密存储 → **Medium**

### GraphQL Security (CWE-829)
- Introspection暴露: 枚举完整schema发现隐藏接口 → **High**
- Batching攻击: 单个请求触发多次查询 DoS → **High**
- 修复: production禁用introspection, query depth limit, alias限制

### Subdomain Takeover (CWE-441)
- DNS CNAME指向已注销的第三方服务（GitHub Pages, AWS S3, Heroku等）
- 攻击者可注册对应服务并接管子域名 → **Critical/High**

### HTTP Parameter Pollution (CWE-76)
- 同名参数多次发送，后端处理方式不一致
- 可能导致绕过过滤、权限提升、Cache poisoning → **Medium**
'''

        # 为每条高危/严重发现附加 ImpactEvaluator 数据
        impact_map = {}
        for f in findings_list:
            fid = f.get('id', '')
            if 'impact' in str(f).lower() or 'volume' in str(f).lower():
                continue
            impact_map[fid] = None

        user_prompt = f"""Please analyze the following security scan report and output in SRC standard format.

**Target Type**: {scan_type}
**Scan Target**: {target}
**Risk Level**: {summary.get('risk_level', 'N/A')} (Score: {summary.get('risk_score', 0)})
**Total Findings**: {len(findings_list)}{f' (original {len(findings)} items)' if len(findings) > 100 else ''}
**Tech Stack**: {', '.join(technologies[:10]) if technologies else 'Unknown'}
**Subdomains**: {', '.join(subdomains_list[:5]) if subdomains_list else 'None'}

---
Vulnerability Findings (analyze each in SRC standard format):
```json
{json.dumps({'findings': findings_list, 'technologies': technologies,
              'subdomains': subdomains_list}, ensure_ascii=False, indent=2)}
```

**Output Requirements:**
1. Only output severity >= medium vulnerabilities in SRC 6-part format (all parts required)
2. Low/Info items grouped under "Low-risk / Recommendations" with batched fixes
3. PoC must include **raw HTTP request usable by curl/Burp** (with Host, User-Agent headers)
4. Impact proof must show actual data obtained (phone numbers, emails, order IDs), NOT theoretical possibilities
5. Fix recommendations must be specific to code/config level, not generic advice"""

        response = self._call_llm(system_prompt, user_prompt)
        
        return {
            'provider': self.provider_key,
            'display_name': self.display_name,
            'model': self.model,
            'raw_response': response,
            'analyzed': True,
        }

    def _get_api_path(self) -> str:
        """从 providers 矩阵获取 API 端点路径"""
        info = PROVIDER_DB.get('providers', {}).get(self.provider_key, {})
        return info.get('api_path', '') if info else ''

    def _ensure_ollama_model(self, req) -> Optional[str]:
        """Ollama 实时模型识别（每实例一次）。

        - 默认"无模型"状态（model 为空）：自动从本机已装模型中挑选一个，不判断任何预设模型
        - 配置了模型时：校验其确实已安装在本地；未安装时自动改用本地可用模型并明确告警
        - 连不上 Ollama / 无任何已装模型时返回错误信息（调用方不应再发请求）

        背景: Ollama 收到请求中不存在的模型名会默认自动从 registry 拉取，
        唯一可靠的防拉取方式就是永不请求未安装的模型。

        Returns:
            None = 通过（self.model 可能已被改写为本地可用模型）；否则为错误信息字符串
        """
        if getattr(self, '_ollama_model_checked', False):
            return None
        self._ollama_model_checked = True
        base = self.base_url.rstrip('/')
        try:
            resp = req.get(f"{base}/api/tags", timeout=5)
        except Exception as e:
            return f"无法连接 Ollama ({base}): {e}"
        if resp.status_code != 200:
            logger.warning(f"⚠️ Ollama /api/tags 返回 {resp.status_code}，跳过模型检查（沿用配置模型 {self.model}）")
            return None
        try:
            installed = [m.get('name') for m in resp.json().get('models', []) if m.get('name')]
        except Exception:
            installed = []
        if not installed:
            return (f"Ollama 已运行但未安装任何模型（为防止自动拉取，不请求任何模型）；"
                    f"请先执行 `ollama pull <model>`")
        if not self.model:
            # 默认"无模型"状态：自动选用本机已装模型（参数量最大者优先）
            picked = pick_ollama_model(installed)
            logger.info(f"🔍 Ollama 自动识别: 选用本机已装模型 {picked}（本机: {', '.join(installed)}）")
            self.model = picked
        elif self.model not in installed:
            picked = pick_ollama_model(installed, self.model)
            logger.warning(f"⚠️ 配置模型 {self.model} 不在本机已装列表，已改用 {picked}（本机: {', '.join(installed)}）")
            self.model = picked
        else:
            logger.info(f"✅ Ollama 模型校验通过: {self.model}（本机: {', '.join(installed)}）")
        return None

    def _call_llm(self, system: str, user: str) -> str:
        """Unified LLM caller - auto-adapts to different API protocols"""
        import requests as req

        # Ollama 实时模型识别：确认配置模型已安装（防止 Ollama 自动拉取未装模型）
        if self.api_type == 'ollama':
            err = self._ensure_ollama_model(req)
            if err:
                return f"AI API 错误 (Ollama 模型检查): {err}"

        # ---------- OpenAI 兼容协议 (qwen/glm/moonshot/deepseek/siliconflow/gemini/openai/vllm/lmdeploy) ----------
        if self.api_type == 'openai_compatible':
            headers = {'Content-Type': 'application/json'}
            if self.api_key:
                headers['Authorization'] = f'Bearer {self.api_key}'
            payload = {
                'model': self.model,
                'messages': [
                    {'role': 'system', 'content': system},
                    {'role': 'user', 'content': user},
                ],
                'temperature': self.temperature,
                'max_tokens': self.max_tokens,
            }

        # ---------- Anthropic Claude 原生协议 ----------
        elif self.api_type == 'anthropic':
            headers = {
                'Content-Type': 'application/json',
                'x-api-key': self.api_key or '',
                'anthropic-version': '2023-06-01',
            }
            payload = {
                'model': self.model,
                'messages': [
                    {'role': 'user', 'content': user},
                ],
                'system': system,
                'temperature': self.temperature,
                'max_tokens': self.max_tokens,
            }

        # ---------- Ollama 本地流式协议 ----------
        elif self.api_type == 'ollama':
            headers = {'Content-Type': 'application/json'}
            payload = {
                'model': self.model,
                'messages': [
                    {'role': 'system', 'content': system},
                    {'role': 'user', 'content': user},
                ],
                'stream': True,  # Ollama 默认流式
            }

        else:
            return f"不支持的 API 类型: {self.api_type}"

        # 构建最终 URL
        url = self.base_url.rstrip('/')
        api_path = self._get_api_path() or (
            '/v1/chat/completions' if self.api_type == 'openai_compatible' else
            '/api/chat' if self.api_type == 'ollama' else
            '/v1/messages' if self.api_type == 'anthropic' else ''
        )
        if url.endswith(api_path):
            pass  # already has the path
        elif '/' in url.lstrip('/') and not url.endswith('/api') and not url.endswith('/v1'):
            url += api_path
        else:
            url += api_path

        logger.info(f"🤖 正在调用 AI ({self.display_name}/{self.model}) [{self.api_type}]...")
        start = time.time()

        try:
            # ── Ollama v0.32+ 兼容性修复 ──
            # requests.post() → HTTP/2 → Ollama /api/chat 返回 404 (empty body)
            # 改用 urllib3.PoolManager.request(HTTP/1.1) 绕过此问题
            if self.api_type == 'ollama':
                import urllib3
                http = urllib3.PoolManager()
                resp_body = json.dumps(payload).encode('utf-8')
                resp_raw = http.request('POST', url, body=resp_body, headers=headers, timeout=120)
                resp_text = resp_raw.data.decode('utf-8', errors='replace')
                status_code = resp_raw.status

            else:
                resp = req.post(url, json=payload, headers=headers, timeout=120)
                resp.encoding = 'utf-8'
                status_code = resp.status_code
                resp_text = resp.text
            elapsed = time.time() - start

            if status_code == 200:
                # ---------- Ollama 流式 JSONL 格式 ──
                if self.api_type == 'ollama':
                    content_parts = []
                    for line in resp_text.strip().split('\n'):
                        if not line.strip():
                            continue
                        try:
                            chunk = json.loads(line)
                            msg = chunk.get('message', {})
                            text = msg.get('content', '')
                            if text:
                                content_parts.append(text)
                        except json.JSONDecodeError:
                            continue
                    content = ''.join(content_parts)

                # ---------- Anthropic Claude 格式 ──
                elif self.api_type == 'anthropic':
                    data = resp.json()
                    content_list = data.get('content', [])
                    content_parts = [c.get('text', '') for c in content_list if isinstance(c, dict) and c.get('type') == 'text']
                    content = ''.join(content_parts)

                # ---------- OpenAI 兼容格式 (GPT/Gemini/Qwen/GLM/Kimi/DeepSeek/SiliconFlow/vLLM/LMDeploy) ──
                else:
                    data = resp.json()
                    content = data.get('choices', [{}])[0].get('message', {}).get('content', '')

                logger.info(f"✅ AI 分析完成 ({elapsed:.1f}s, {len(content)} chars)")
                return content
            else:
                if self.api_type == 'ollama':
                    error_detail = resp_text[:500]
                else:
                    error_detail = resp.text[:500]
                logger.error(f"❌ AI API 调用失败 [{self.display_name}]: HTTP {status_code}")
                return f"AI API 错误 (HTTP {status_code}): {error_detail}"

        except req.exceptions.ConnectionError as e:
            logger.error(f"❌ AI API 连接失败 ({url}): {e}")
            return f"无法连接到 AI API ({url})，请检查网络或配置。"
        except req.exceptions.Timeout:
            logger.error(f"❌ AI API 请求超时")
            return "AI 请求超时，请重试或增加 timeout。"
        except json.JSONDecodeError as e:
            if self.api_type == 'ollama':
                logger.error(f"❌ AI API JSON 解析错误: {e}")
                return f"AI 响应格式异常 (JSONL): {resp_text[:200]}"
            else:
                logger.error(f"❌ AI API JSON 解析错误: {e}")
                return f"AI 响应格式异常: {resp.text[:200]}"
        except Exception as e:
            logger.error(f"❌ AI 调用异常: {type(e).__name__}: {e}")
            return f"AI 调用异常 ({type(e).__name__}): {e}"


# ==================== Markdown -> HTML ====================

def _md_to_html(text):
    """Convert Markdown to HTML (supports headings/bold/lists/code blocks/nested items/tables)"""
    lines = text.split('\n')
    h = ''
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]

        # --- code blocks (``` ... ```) ---
        if line.strip().startswith('```'):
            lang = line.strip()[3:].strip()
            code_lines = []
            i += 1
            while i < n and not lines[i].strip().startswith('```'):
                code_lines.append(lines[i])
                i += 1
            # close code block (skip the closing ```
            if i < n:
                i += 1
            escaped = '\n'.join(code_lines).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
            lang_attr = f' class="{lang}"' if lang else ''
            h += f'<pre style="background:#161b22;padding:1rem;border-radius:8px;color:#e6edf3;font-size:.9rem;overflow-x:auto;margin:.5rem 0">' + escaped + '</pre>\n'
            continue

        # --- horizontal rules (---) ---
        if re.match(r'^-{3,}\s*$', line):
            h += '<hr style="border:none;border-top:1px solid #21262d;margin:1rem 0;">\n'
            i += 1
            continue

        # --- markdown table detection (lines starting with |) ---
        if line.strip().startswith('|'):
            table_rows = []
            while i < n and lines[i].strip().startswith('|'):
                table_rows.append(lines[i])
                i += 1
            h += _render_table(table_rows)
            continue

        # --- ## headers ---
        m = re.match(r'^## (.+)$', line)
        if m:
            h += '<h3 style="color:#e6edf3;margin-top:2rem;border-bottom:2px solid #30363d;padding-bottom:.5rem;">\U0001f4cb ' + _esc(m.group(1)) + '</h3>\n'
            i += 1
            continue

        # --- ### headers ---
        m = re.match(r'^### (.+)$', line)
        if m:
            h += '<h4 style="color:#79c0ff;margin-top:1.2rem;font-weight:normal;">' + _esc(m.group(1)) + '</h4>\n'
            i += 1
            continue

        # --- blockquotes (>) ---
        m = re.match(r'^> (.+)$', line)
        if m:
            h += '<div style="margin:.5rem 0;padding:.8rem 1rem;border-left:3px solid #484f58;color:#8b949e;font-style:italic;">' + _inline(m.group(1)) + '</div>\n'
            i += 1
            continue

        # --- numbered list (1. text) ---
        m = re.match(r'^(\s*)(\d+)\. (.+)$', line)
        if m:
            h += '<div style="margin:.3rem 0;padding:.5rem .8rem;background:#161b22;border-left:3px solid #f78166;">' + m.group(2) + '. ' + _inline(m.group(3)) + '</div>\n'
            i += 1
            continue

        # --- nested bullet list (  - text) ---
        m = re.match(r'^( {2,})- (.+)$', line)
        if m:
            h += '<div style="margin:.3rem 0;padding:.5rem .8rem .5rem 1.2rem;background:#161b22;border-left:3px solid #79c0ff;font-size:.9em;">' + _inline(m.group(2)) + '</div>\n'
            i += 1
            continue

        # --- bullet list (- text) ---
        m = re.match(r'^- (.+)$', line)
        if m:
            h += '<div style="margin:.3rem 0;padding:.5rem .8rem;background:#161b22;border-left:3px solid #f78166;">' + _inline(m.group(1)) + '</div>\n'
            i += 1
            continue

        # --- bold inline (**text**) (must process inside paragraph content) ---
        # --- collect paragraph lines until blank or block element ---
        para_lines = []
        while i < n:
            pl = lines[i]
            if pl.strip() == '':
                break
            # Stop if we hit a block element (header, code block, table, hr, quote, list)
            if re.match(r'^## ', pl) or re.match(r'^### ', pl):
                break
            if pl.strip().startswith('```'):
                break
            if pl.strip().startswith('|') and i > 0 and lines[i-1].strip() != '':
                break
            if re.match(r'^-{3,}\s*$', pl):
                break
            if re.match(r'^> |^\s*\d+\. |^( {2,})- |^- ', pl):
                break
            para_lines.append(pl)
            i += 1

        if para_lines:
            para = ' '.join(para_lines)
            h += '<div style="margin:.5rem 0;line-height:1.8;">' + _inline(para) + '</div>\n'
        elif not para_lines and i < n and lines[i].strip() == '':
            # blank line between blocks, just skip
            i += 1
            continue
        else:
            # fallback: treat as plain paragraph text
            if line.strip():
                h += '<div style="margin:.5rem 0;line-height:1.8;">' + _inline(line) + '</div>\n'
            i += 1

    return h


def _esc(s):
    """Escape HTML in text."""
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _inline(line):
    """Process inline format: escape first, then insert tags"""
    e = _esc(line)
    e = re.sub(r'`([^`]+)`', r'<code style="background:#21262d;padding:0.15rem 0.4rem;border-radius:4px;color:#79c0ff;font-size:.85rem;">\1</code>', e)
    e = re.sub(r'\*\*(.+?)\*\*', r'<strong style="color:#e6edf3;">\1</strong>', e)
    return e


def _render_table(table_rows):
    """Render a markdown table as an HTML table."""
    if not table_rows:
        return ''

    def split_row(row):
        # Split by | but handle content between pipes carefully
        parts = row.strip().strip('|').split('|')
        return [p.strip() for p in parts]

    rows = [split_row(r) for r in table_rows]
    if not rows:
        return ''

    # Find column count
    max_cols = max(len(r) for r in rows)
    # Normalize all rows to same number of columns
    for r in rows:
        while len(r) < max_cols:
            r.append('')

    cols = max_cols
    NL = chr(10)
    result = '<table style="width:100%;border-collapse:collapse;margin:.5rem 0;">' + NL
    result += '<tr style="background:#161b22;">' + NL
    # Header row
    for cell in rows[0]:
        result += f'<th style="padding:.6rem;border-bottom:2px solid #30363d;color:#e6edf3;text-align:left;">{_inline(cell)}</th>\n'
    result += '</tr>\n'

    # Separator row is at index 1, skip it
    # Markdown table separator lines have cells like ':---' or '---' (dash-based)
    is_separator = lambda r: len(r) > 0 and all(
        c.strip().startswith(':') or c.strip().startswith('-') for c in r if c.strip()
    ) and any('-' in c for c in r)
    data_start = 2 if len(rows) > 1 and is_separator(rows[1]) else 1

    # Data rows
    for r in rows[data_start:]:
        result += '<tr style="border-bottom:1px solid #21262d;">' + NL
        for cell in r:
            result += f'<td style="padding:.5rem .6rem;color:#c9d1d9;">{_inline(cell)}</td>\n'
        result += '</tr>\n'

    result += '</table>'
    return result


# ==================== 便捷函数 ====================

def ai_analyze_url(url: str, output_dir: str = None) -> Dict[str, Any]:
    """End-to-end: scan + AI analysis + HTML injection"""
    from url_scanner import URLScanner, ReportGenerator

    print("\U0001f916 启动 AI 自动分析流程...")
    
    # 1. 执行扫描
    scanner = URLScanner(output_dir=output_dir)
    result = scanner.scan(url)
    
    os.makedirs(output_dir or '.', exist_ok=True)
    html_path = os.path.join(output_dir or '.', 'report.html')
    json_path = os.path.join(output_dir or '.', 'report.json')

    ReportGenerator.generate(result, html_path)

    report_data = {
        'scan_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'summary': {
            'url_target': result.target_url,
            'url_findings_count': result.finding_count,
            'url_critical': result.critical_count,
            'url_high': result.high_count,
            'url_technologies': result.technologies,
            'url_subdomains': result.subdomains[:20],
            'risk_level': ('\u2620\ufe0f CRITICAL' if result.critical_count > 0 else
                           '\U0001f534 HIGH RISK' if result.high_count > 0 else
                           '\U0001f7e1 MODERATE' if sum(1 for f in result.findings if f.severity.value == 'medium') > 0 else
                           '\U0001f7e2 LOW RISK'),
            'risk_score': result.critical_count * 25 + result.high_count * 15 +
                          sum(1 for f in result.findings if f.severity.value == 'medium') * 5 +
                          sum(1 for f in result.findings if f.severity.value == 'low'),
            'total_findings': result.finding_count,
            'severity_breakdown': {
                'critical': result.critical_count,
                'high': result.high_count,
                'medium': sum(1 for f in result.findings if f.severity.value == 'medium'),
                'low': sum(1 for f in result.findings if f.severity.value == 'low'),
                'info': sum(1 for f in result.findings if f.severity.value == 'info'),
            },
        },
        'url_findings': [f.to_dict() for f in result.findings],
        'file_findings': [],
    }

    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(report_data, f, ensure_ascii=False, indent=2)
    
    with open(json_path, 'r', encoding='utf-8') as f:
        report_data = json.load(f)

    print(f"\U0001f4ca 扫描完成 ({result.finding_count} 个发现)")
    
    # 2. AI分析
    analyzer = AIAnalyzer()
    ai_result = analyzer.analyze(report_data)
    
    if ai_result.get('analyzed'):
        print(f"\U0001f916 AI {analyzer.display_name}/{analyzer.model} 分析完成")
        ai_text = ai_result['raw_response']
        
        # 保存AI JSON
        ai_json_path = os.path.join(os.path.dirname(json_path), 'ai_report.json')
        with open(ai_json_path, 'w', encoding='utf-8') as f:
            json.dump(ai_result, f, ensure_ascii=False, indent=2)
        print(f"\U0001f4c4 AI JSON 已保存: {ai_json_path}")
        
        # 独立HTML + iframe嵌入（避免嵌套div冲突）
        ai_html_path = os.path.join(os.path.dirname(json_path), 'ai_report.html')
        ai_html = _md_to_html(ai_text)
        full_ai_html = (
            '<!DOCTYPE html><html lang="zh"><head>'
            '<meta charset="UTF-8"><style>'
            '*{margin:0;padding:0;box-sizing:border-box}body{font-family:"Segoe UI",system-ui,sans-serif;background:#0d1117;color:#c9d1d9;padding:1.5rem;line-height:1.8;font-size:.95rem}'
            'pre{background:#161b22;padding:1rem;border-radius:8px;color:#e6edf3;font-size:.9rem;overflow-x:auto;margin:.5rem 0}'
            'code{background:#21262d;padding:.15rem .4rem;border-radius:4px;color:#79c0ff;font-size:.85rem}'
            'h3{color:#e6edf3;margin-top:1.5rem;border-bottom:2px solid #30363d;padding-bottom:.5rem}.ai-title{color:#f78166!important;margin:0!important;border:none!important}hr{border:none;border-top:1px solid #21262d;margin:1rem 0}'
            'div{margin:.3rem 0;padding:.5rem .8rem;background:#161b22;border-left:3px solid #f78166}h4{color:#79c0ff;font-weight:normal}.blockquote{border-left:3px solid #484f58;color:#8b949e;font-style:italic;padding:.8rem 1rem;margin:.5rem 0}'
            '</style></head><body>'
            '<h2 class="ai-title">\U0001f916 AI 自动分析报告 (' + analyzer.display_name + '/' + analyzer.model + ')</h2>' + ai_html + '</body></html>'
        )
        with open(ai_html_path, 'w', encoding='utf-8') as f:
            f.write(full_ai_html)
        print(f"\U0001f4c5 AI HTML 报告已保存: {ai_html_path}")
        
        iframe_html = (
            '<div style="margin:1.5rem 0;border-radius:12px;overflow:hidden;border:1px solid #30363d;">'
            '<h3 style="color:#f78166;padding:.8rem 1.2rem;margin:0;background:#161b22;font-size:1.1rem;">\U0001f916 AI 自动分析报告 (' + analyzer.display_name + '/' + analyzer.model + ')</h3>'
            '<iframe src="ai_report.html" style="width:100%;height:800px;border:none;background:#0d1117;"></iframe>'
            '</div>'
        )
        
        with open(html_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        
        marker = '</div>\n        <footer>'
        if marker in html_content:
            html_content = html_content.replace(marker, iframe_html + '\n' + marker)
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            print(f"\U0001f4be report.html 已更新（含iframe嵌入AI报告）")
        else:
            print("⚠️ 未在 report.html 中找到插入位置")
    else:
        print(f"\u26a0\ufe0f {ai_result.get('error', 'AI分析未执行')}")

    return {'scan_result': result, 'ai_result': ai_result}


if __name__ == '__main__':
    if len(sys.argv) > 1:
        target = sys.argv[1]
        ai_analyze_url(target)
    else:
        print("用法: python ai_analyzer.py https://target.com")
