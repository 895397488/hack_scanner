# War Stories — hack_scanner 实战经验库

这里存放真实渗透测试 / CTF 解题战报与项目自身 campaign 复盘。

每份战报记录完整攻击链：从侦察到确认，包括走了哪些弯路、关键突破口在哪里。
首轮经验注入（`scanners/experience.build_experience_injection`）与 `consult_kb(query, kind="story")`
全文检索（BM25，`scanners/kb_search.py`）都从这里取素材。

## 文件命名规则

```
YYYY-MM-DD_题目类型_关键词.md
```

例如：`2026-04-19_php-deserialization_regex-bypass.md`

## 战报模板

每份战报应包含 6 个区块：

| 区块 | 内容 |
|------|------|
| **元信息** | 日期、目标、类型、关键词、轮数、工具链 |
| **攻击链** | 每一步做了什么、发现了什么 |
| **关键突破** | 哪一步是决定性的，为什么 |
| **走的弯路** | 哪些尝试失败了，原因是什么 |
| **Payload** | 最终可复现的利用代码 |
| **经验总结** | 可迁移到同类题目的方法论 |

## 战报索引

| 日期 | 题目 | 类型 | 轮数 | 链接 |
|------|------|------|------|------|
| 2026-04-19 | NSSCTF PHP 正则绕过 + call_user_func 数组回调 | Web / PHP / 正则绕过 | 12 | [→](./2026-04-19_php-deserialization_regex-bypass.md) |
| 2026-04-19 | NSSCTF PHP 弱比较 + 双写 + MD5 碰撞 | Web / PHP / 弱比较 | 61 | [→](./2026-04-19_php-weak-comparison_double-write-md5-bypass.md) |
| 2026-06-28 | IDOR/BOLA + JWT 算法混淆 | API / 逻辑漏洞 / JWT | 4-6/链 | [→](./2026-06-28_idor-jwt-attack-chain_api-top10.md) |
| 2026-08-25 | SSRF + OOB 验证纪律 | Web / SSRF / OOB | 4-8 | [→](./2026-08-25_ssrf-oob_verification-discipline.md) |
| 2026-09-14 | 20 轮浅探测教训（深度优先） | 流程复盘 / 策略注入 | 20 | [→](./2026-09-14_shallow-probe-lesson_depth-first.md) |
| 2026-09-15 | 预算收敛三件套（M7/M11/M14） | 流程复盘 / 预算纪律 | — | [→](./2026-09-15_budget-convergence_lifecycle-discipline.md) |

> 前 2 篇改编自 VulnClaw 战报库（来源已标注于各篇头部）；其余为 hack_scanner 项目自身经验提炼。

## 如何新增战报

1. 按 6 区块模板写 Markdown，文件名遵循命名规则
2. 在上方索引表追加一行
3. 自动生效：`kb_search.KnowledgeBase` 扫描本目录 `*.md` 建立 BM25 索引
   （"经验总结"段参与首轮注入摘要，全文可被 `consult_kb` 检索）
