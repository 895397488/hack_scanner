# War Story — NSSCTF PHP 正则绕过 + call_user_func 数组回调

> 来源：改编自 VulnClaw 战报库 #001（vulnclaw/warstories/2026-04-19_php-deserialization_regex-bypass.md）

## 元信息

| 字段 | 值 |
|------|------|
| **日期** | 2026-04-19 |
| **目标** | `http://node5.anna.nssctf.cn:23284/` |
| **题目类型** | Web — PHP 正则绕过 + call_user_func 数组回调 |
| **关键词** | PHP、正则绕过、call_user_func、数组绕过、大小写绕过 |
| **轮数** | 12 |
| **工具链** | HTTP 探测 / 源码阅读 / Base64 解码 |

---

## 攻击链（完整真实流程）

| 步骤 | 操作 | 发现 |
|------|------|------|
| 1 | GET 请求首页 | Apache/2.4.54 + PHP/7.4.30，发现 `js/1.js` 与 `css/1.css` |
| 2 | 查看 `js/1.js` | JS 注释中发现 Base64 字符串 `NSSCTF{TnNTY1RmLnBocA==}` |
| 3 | Base64 解码 | 得到 `NsScTf.php` — 隐藏的 PHP 文件 |
| 4 | GET 请求 `NsScTf.php` | 获取源码：`preg_match("/n\|c/m", $_GET['p'])` + `call_user_func($_GET['p'])` |
| 5 | 分析正则 | 无 `i` 修饰符 → 大小写可绕过 |
| 6 | 尝试 `p=Nss::ctf` | 返回 "no" — 需找正确类名 |
| 7 | 访问 `hint2.php` | 提示："有没有一种可能，类是nss2" |
| 8 | 尝试 `p=Nss2::Ctf` | 返回 "no" — 大小写绕过不稳定 |
| 9 | 分析 `call_user_func` 语义 | 支持数组回调 `['类名', '方法名']` |
| 10 | 构造数组绕过 payload | `p[]=nss2&p[]=ctf` → 数组使 `preg_match` 返回 `false` |
| 11 | 发送 `GET /NsScTf.php?p[]=nss2&p[]=ctf` | ✅ 响应包含 flag |
| 12 | Flag 验证 | `NSSCTF{7d67ec46-4d71-4dc4-904b-151b8a923e53}` ✅ |

---

## 关键突破

第 10 步：**数组绕过正则过滤**。`preg_match("/n|c/m", array)` 第二个参数需要字符串，传入数组返回 `false` → 过滤形同虚设；而 `call_user_func(['nss2', 'ctf'])` 数组回调等价于 `nss2::ctf()`，直接包含 `flag.php` 输出。

## 走的弯路

| 弯路 | 原因 | 教训 |
|------|------|------|
| 先死磕反序列化路径（`NSSCTF.__destruct` + `stripos`/`preg_match_all`） | 该路径条件组合极难触发 | 源码里有多条可利用路径时，先挑过滤最弱的一条 |
| 大小写绕过 `Nss2::Ctf` 失败 | `call_user_func` 对字符串类名的解析方式与数组回调不同 | 大小写绕过"理论上可行"不等于实战可行，要验证 |
| 首轮幻觉：编造了工具返回的 flag | LLM 推导后编造结果 | 任何 flag/证据必须来自真实响应，禁止脑补 |

## Payload（可复现）

```
GET /NsScTf.php?p[]=nss2&p[]=ctf
```

原理：
1. `?p[]=nss2&p[]=ctf` 使 `$_GET['p']` 变成数组 `['nss2', 'ctf']`
2. `preg_match` 收到数组返回 `false` → **绕过正则**
3. `call_user_func(['nss2','ctf'])` → 数组回调 → `nss2::ctf()` → 输出 flag

## 经验总结

1. **先分析正则修饰符**：有无 `i`（忽略大小写）、`m`（多行）、`s`（点匹配换行）直接决定绕过方式
2. **大小写绕过是最常见的正则绕过**：正则无 `i` 时，PHP 函数名/类名大小写不敏感
3. **数组绕过是 `preg_match` 类过滤的万能绕过**：传入数组返回 `false`
4. **`call_user_func` 支持数组回调**：`['类名','方法名']` 等价于 `类名::方法名()`
5. **不要死磕一条路**：反序列化路径难绕 → 换 `call_user_func` 路径 → 数组绕过，12 轮收敛
6. **证据纪律**：flag/漏洞确认必须来自真实 HTTP 响应，禁止编造工具返回
