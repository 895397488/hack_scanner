# War Story — 预算收敛三件套：弱提示失效 → 强警告 → salvage 兜底

> 来源：hack_scanner 项目自身机制演进复盘（M7 / M11 / M14，2026-09）

## 元信息

| 字段 | 值 |
|------|------|
| **日期** | 2026-09-15（机制定稿） |
| **目标** | adaptive campaign 预算与生命周期治理 |
| **类型** | 机制复盘 — LLM 预算纪律问题演进史 |
| **关键词** | 预算警告、生命周期、salvage、兜底报告、独立消息 |
| **轮数** | 贯穿多次 campaign |
| **工具链** | run_adaptive.py 入口层包装器 |

---

## 攻击链（问题演进链）

| 阶段 | 做法 | 结果 |
|------|------|------|
| M7 | 预算纪律写在 objective 长文本末尾（"reserve final iterations…"） | ❌ 27b 模型直接无视，把全部迭代烧在探测上，report/finish 从未调用 |
| M11 | 剩余额度 ≤3 时**每轮追加一条独立 user 消息**（⚠️ BUDGET WARNING） | ✅ 生命周期收敛：模型执行 classify → generate_report → finish_scan |
| M14 | 收尾两层兜底：① classify 从未被调用 → 一次预算外 LLM salvage 提取；② 有发现无报告 → 入口层补生成富报告 | ✅ 极端情况下仍有发现 + 报告产出 |

## 关键突破

**独立醒目消息 > 长文本里的提示**。
M11 的 BUDGET WARNING 是独立 user 消息、含明确三步指令，27b 级模型能执行；同样内容埋在 objective 里则完全无效。
这一机制后来被 M12 策略注入、经验块注入、反思块注入全部复用（"独立消息"是本项目对 LLM 行为控制的核心杠杆）。

## 走的弯路

| 弯路 | 原因 | 教训 |
|------|------|------|
| M7 弱提示无效 | 提示埋在长 objective 里，注意力被稀释 | 关键指令必须独立消息 + 短句 + 明确步骤编号 |
| salvage 触发过激 | 早期 classify 被调过但 0 条也触发 salvage | classify 0 条 = 分类器裁决（FP 过滤/真干净），**尊重裁决不 salvage**；只有 not_called 才 salvage |
| 兜底报告命名混乱 | 兜底报告与 LLM 报告文件名冲突 | 兜底走同一 generate_report binder 代码路径，命名/聚合逻辑零分叉 |

## Payload（可复现 — 预算警告原文）

```
⚠️ BUDGET WARNING: only {N} iteration(s) remain (including this one).
STOP starting new probes/detectors/exploits. Immediately finish the lifecycle:
1) call classify with your candidate findings;
2) call generate_report;
3) call finish_scan.
```

## 经验总结

1. **对小模型：位置 > 内容** — 同样的话，独立消息能执行，长文里被无视
2. **预算警告要"每轮重发"** — 每轮追加到 messages 副本（不污染 orchestrator 历史），直到预算耗尽
3. **salvage 是兜底不是替代** — 只处理"生命周期完全没走到"的极端情况，且只花 1 次预算外调用
4. **尊重分类器裁决** — 0 条发现可能是"真干净"，盲目重提取会引入垃圾
5. **兜底必须走同一代码路径** — 入口层补生成复用 binder，避免两套报告逻辑漂移
