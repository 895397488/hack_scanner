# War Story — IDOR/BOLA + JWT 算法混淆：API Top10 两条经典链

> 来源：hack_scanner 项目攻击场景库提炼（scanners/swarm_prompt_examples.py，源自 Pentest-Swarm-AI 场景集）+ jwt_detector 实战经验

## 元信息

| 字段 | 值 |
|------|------|
| **日期** | 2026-06-28 |
| **目标** | 典型 API/Web 目标（场景化提炼，非单次 engagement） |
| **类型** | 攻击链模板 — IDOR/BOLA + JWT algorithm confusion |
| **关键词** | IDOR、BOLA、JWT、RS256、alg 头、差分探测、OWASP API Top10 |
| **轮数** | 每条链 4-6 轮（假设驱动） |
| **工具链** | http_probe / 解码 / 差分对照 |

---

## 攻击链 A：IDOR / BOLA（OWASP API #1）

| 步骤 | 操作 | 判定信号 |
|------|------|----------|
| 1 | RECON：`/api/orders/{id}` 返回 PII（地址/卡号末 4），ID 连续 | 敏感数据 + 连续 ID = 经典 IDOR 面 |
| 2 | 假设：端点信任 URL 里的 ID，不校验是否属于当前用户 | BOLA：缺少对象级授权 |
| 3 | 差分探测：用自己会话请求 `id-1` / `id+1` / 相邻 ID | 响应是有效数据（非 403/404/空）= **确认 IDOR** |
| 4 | 边界确认：越权读 vs 越权写（PUT/DELETE 相邻 ID） | 写成功 = 高危升级 |

**判定纪律**：差分对照是核心——同参数仅 ID 不同，响应差异即证据；单条 200 不构成证据。

## 攻击链 B：JWT 算法混淆

| 步骤 | 操作 | 判定信号 |
|------|------|----------|
| 1 | RECON：登录返回 RS256 JWT；`/.well-known/jwks.json` 暴露公钥 | 公钥暴露是**正常的**（非漏洞），风险在验证逻辑 |
| 2 | 假设：验证代码把 token 的 `alg` 头直接透传给验证函数 | 算法混淆面 |
| 3 | 取合法 JWT → 改 payload（`sub` 提权 / `exp` 延长） | 保持其余结构 |
| 4 | 尝试 `alg: none` 或 RS256→HS256（用公钥当 HMAC 密钥签名） | 用 jwks 的公钥做 HS256 密钥 |
| 5 | 伪造 token 打受保护端点 | 200 + 越权数据 = **确认** |

**注意**：`alg:none` 多数现代库已默认拒绝；HS256 混淆需要拿到公钥（jwks）当 HMAC key — 这是"公钥暴露"从正常变成可利用的关键一步。

## 关键突破

两条链的共同杠杆是**差分探测 + 结构假设**：
- IDOR 的差分在 **ID 维度**（相邻 ID 对照）
- JWT 的差分在 **alg 维度**（同 payload 不同算法对照）

## 走的弯路

| 弯路 | 原因 | 教训 |
|------|------|------|
| 把 jwks 暴露直接报成漏洞 | 公钥本就该公开 | 区分"暴露"与"可利用"，报告要写清利用条件 |
| IDOR 单条 200 就报 | 可能是公开数据 | 必须差分对照（非本人 ID 返回本人级数据才算） |
| JWT 只试 alg:none | 现代库默认禁用 | 优先级：HS256 混淆 > none；两者都试 |

## Payload（可复现 — 模板）

```
# IDOR 差分
GET /api/orders/12345   (本人会话, 有效) 
GET /api/orders/12346   (本人会话, 有效?) → 有效 = IDOR

# JWT HS256 混淆
1. 取合法 RS256 token 的 payload
2. 用 jwks.json 公钥作为 HMAC key，以 HS256 重新签名（改 sub/exp）
3. 带新 token 请求受保护端点
```

## 经验总结

1. **连续 ID + 敏感数据 = IDOR 优先假设**，比盲扫注入面性价比高
2. **差分探测是逻辑漏洞的唯一硬证据**
3. **JWT 验证漏洞的根因永远是"alg 头被信任"**，攻击点在客户端可控制的头
4. **OWASP API Top10 #1(BOLA) 是 API 目标的第一假设**，先于注入类
5. **报告写清"可利用条件"**：jwks 暴露本身不是漏洞，混淆成功才是
