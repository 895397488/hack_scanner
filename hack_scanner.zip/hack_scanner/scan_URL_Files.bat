@echo off
rd /s /q %cd%\hack_report
rd /s /q %cd%\__pycache__
rd /s /q %cd%\scanners\__pycache__
chcp 65001 >nul
pushd %~dp0
if not exist hack_report mkdir hack_report
python launcher.py
pause
