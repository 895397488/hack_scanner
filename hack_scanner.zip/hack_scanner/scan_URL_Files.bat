@echo off
rd /s /q %cd%\hack_report
rd /s /q %cd%\__pycache__
rd /s /q %cd%\scanners\__pycache__
chcp 65001 >nul
pushd %~dp0
if not exist hack_report mkdir hack_report
rem interpreter probe: the FULL dep set lives on Python314; this box's
rem miniconda is PARTIAL - it has semgrep/sherlock but LACKS checkov
rem (import fails), so running on it breaks the checkov/IaC module.
rem A bare-python-first probe would pick miniconda (first on PATH, passes
rem the core-import test) and silently drop checkov. FIX: prefer Python314
rem when it imports the full set; adding checkov to the test is what keeps
rem the partial miniconda from passing. Bare 'python' = fresh-machine fallback.
set "PYPY=python"
if exist "C:\Users\Administrator\AppData\Local\Programs\Python\Python314\python.exe" (
  "C:\Users\Administrator\AppData\Local\Programs\Python\Python314\python.exe" -c "import requests,bs4,lxml,yaml,jinja2,dns,tldextract,semgrep,sherlock_project,checkov" >nul 2>&1 && set "PYPY=C:\Users\Administrator\AppData\Local\Programs\Python\Python314\python.exe"
)
:py_ok
"%PYPY%" launcher.py
pause
