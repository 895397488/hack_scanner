---
name: ci-security-scanning
description: 把安全扫描接入 CI/CD（GitHub Actions/GitLab CI/任意流水线）作为 PR 合并门禁——只扫 diff、失败即阻塞、SARIF 上传 code scanning，且"不允许 fail-open"（未完成必须判失败）。适用场景：CI 安全门禁、PR 安全审查、流水线接入。use when: ci, cd, github, gitlab, pipeline, pr, 门禁
tags: [ci, cd, github, gitlab, pipeline, pr, 门禁, 流水线]
---

# CI/CD 安全门禁

把安全扫描作为 PR 合并门禁。两个核心原则：**只扫 diff（快）**、**不允许 fail-open（未完成必须判失败）**。

## 不允许 fail-open（最重要的一条）

扫描被预算/超时截断时，很多工具仍会"0 漏洞"正常退出——**门禁必须显式检查完成状态**：

```yaml
# 概念示例（GitHub Actions）
- name: 扫描
  run: python hack_scanner.py -u ${{ vars.TARGET }} --ai
  # 产物含完成度声明 complete: true/false

- name: 未完成即失败（防止截断扫描漏网）
  run: |
    if ! grep -q '"complete": true' hack_report/coverage.json; then
      echo "扫描未完成（可能预算/超时被截断）——门禁不通过" >&2
      exit 1
    fi
```

> 注意：`complete: false` 只能挡住"硬截断"。贴着上限跑完（被警告后收尾）仍可能标 completed 但覆盖不全——所以**预算要给足余量**，并把"消耗贴近上限"视为可疑。

## 门禁步骤模板

1. `checkout` 带 `fetch-depth: 0`（diff 解析需要完整历史）
2. 安装依赖（`pip install -r requirements.txt`）
3. 跑扫描（diff 聚焦 + 合理预算）
4. **校验完成度**（上面那步）
5. 有 confirmed 漏洞 → 非零退出，阻塞合并
6. 上传 SARIF 到 code scanning（见 `③ SARIF 导出` 改进项）

## 预算与时长

- PR 门禁用"快模式"：diff 聚焦 + 短预算，目标是分钟级
- 深度全量扫描走**定时任务**（夜间/周末），不进 PR 门禁
- 两类扫描共用同一套技能与报告格式，结论可对齐

## 安全

- 扫描目标与 LLM Key 放 CI secrets，**不硬编码**
- 门禁只对**自有仓库/授权目标**生效
- SARIF 上传前确认不含内网拓扑等敏感上下文
