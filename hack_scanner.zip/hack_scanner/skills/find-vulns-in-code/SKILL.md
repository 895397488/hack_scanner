---
name: find-vulns-in-code
description: 白盒代码安全审查——读源码建立路由/汇聚点/授权模型认知，再对发现的注入、XSS、SSRF、越权/IDOR、不安全反序列化、代码中密钥、不安全依赖、业务逻辑缺陷给出可工作的 PoC，而不是模式匹配的噪声告警。适用场景：代码安全审查、仓库审计、PR 安全扫描。use when: 代码审查, 源码, whitebox, repo, 文件分析
tags: [code, source, whitebox, repo, file, 代码, 源码, 白盒]
---

# 代码安全漏洞查找（白盒）

读源码建立路由/汇聚点(sink)/授权检查的模型，再尝试真实利用。产出是**短的"已证明问题"清单**，而不是模式匹配扫描器那种几百条"潜在"告警。

## 审查方法

1. **先建模型，再找洞**：路由表 → 每路由的鉴权中间件 → 数据从入参到 sink 的流
2. **圈定高危子树**：monorepo 不要全量刷，指向相关服务；大仓库全量审是浪费
3. **把推断不出来的信息说给审查者**：租户模型（tenant id 从哪来）、信任边界、哪些输入是攻击者可控的——这些 AI 无法可靠推断
4. **授权类重点**：多租户应用里，任何"按对象 id 过滤但没同时按 tenant 过滤"的查询都上报
5. **密钥/凭据**：硬编码密钥、连接串、云 AK/SK 直接上报并建议轮换

## 验证分级（必须区分）

| 级别 | 含义 | 报告写法 |
|---|---|---|
| **已确认** | 有可运行 PoC / 能给出触发请求 | 正常上报，附 PoC |
| **静态观察** | 代码看起来不安全，但没跑起来证明 | **显式标"未确认 (unconfirmed)"**，与已确认分开列 |

"这个看起来不安全" ≠ 已确认漏洞。没有运行实例时，所有静态结论降级为 unconfirmed。

## hack_scanner 运行方式

```bash
# 文件/目录白盒扫描
python hack_scanner.py -f ./project --ai

# 指定可疑子树（更聚焦）
python hack_scanner.py -f ./services/api --ai

# 只看将执行什么（dry-run）
python hack_scanner.py -f ./project --dry-run
```

file_analyzer + git_secret_scanner 负责模式层，AI 分析阶段按本技能做数据流推理与分级。

## 与黑盒互补

白盒审查不是穷举清单：已知 CVE 依赖交给 SCA（trivy/semgrep），已提交凭据交给 secret scanning（trufflehog）；本技能负责**那些工具结构性发现不了的**逻辑、授权与注入缺陷。

修复与复核走 **fix-vulnerabilities** 技能。
