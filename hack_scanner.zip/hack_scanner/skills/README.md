# 技能库（Skill System）

借鉴 Strix (`usestrix/strix`) 的 skills 设计，为 hack_scanner 的 AI 分析/编排层提供**测试方法论技能**。

## 是什么

每个技能 = 一个 `SKILL.md`：
- **frontmatter**：`name`（路由标识）、`description`（触发条件，路由依据）、`tags`（关键词）
- **正文**：方法论 + 诚实纪律（明确标注"什么可测、什么不可测"，禁止 AI 谎报"已测试通过"）

与 `scanners/playbooks.py`（选哪些 check）和 `swarm_prompts.py`（agent 提示词）的分工：
**技能 = 教 AI "怎么测、怎么诚实地报告"的方法论文档**，在 AI 分析阶段注入 system prompt。

## 当前技能（8 个）

| 技能 | 用途 |
|---|---|
| `owasp-top-10-testing` | OWASP Top 10:2025 覆盖矩阵 + 三态报告纪律 |
| `api-security-testing` | OWASP API Top 10:2023，BOLA/IDOR 证明纪律 |
| `web-app-pentest` | 运行中 Web 应用黑盒测试 |
| `application-security-testing` | 资产盘点 → 选测试 → 排序修复计划 |
| `find-vulns-in-code` | 白盒代码审查 + 已确认/未确认分级 |
| `pentest-workflow` | 五阶段总纪律 + "假干净"判定 |
| `ci-security-scanning` | CI 门禁 + 不允许 fail-open |
| `fix-vulnerabilities` | 修根因 + 重扫验证 |

## 编程接口

```python
from scanners.skill_loader import list_skills, load_skill, route_skills, build_prompt_block

skills = route_skills("OWASP Top 10 Web 应用安全评估")   # 按场景路由
block  = build_prompt_block(skills)                       # 注入 system prompt 的 markdown
```

## 命令行自测

```bash
python scanners/skill_loader.py "API 越权 IDOR 测试"
python scanners/skill_loader.py "代码安全审查 repo"
```

## 新增技能

在 `skills/<skill-name>/SKILL.md` 建文件即可，格式参照现有技能。
`description` 和 `tags` 决定路由命中率——把用户会说的触发词（中英文都放）写进去。
