---
name: api-security-testing
description: 对 REST/GraphQL/gRPC API 做安全测试——按 OWASP API Security Top 10 (2023) 逐类验证 BOLA/IDOR、对象属性级授权（mass assignment/数据过度暴露）、函数级授权、资源消耗、SSRF、注入、认证缺陷，每个结论附可复现请求。适用场景：API 安全测试、后端服务审计、接口越权。use when: api, rest, graphql, idor, bola, 越权, 接口
tags: [api, rest, graphql, idor, bola, authorization, 越权, 接口, token]
---

# API 安全测试

API 和 Web UI 的失败模式不同：**没有渲染面可爬、漏洞多为"授权形状"而非"注入形状"、同一端点随 Token 表现不同**。测试必须对准这三个特性。覆盖清单用 [OWASP API Security Top 10 (2023)](https://owasp.org/API-Security/editions/2023/en/0x11-t10/)。

## 1. 先收集（API 盲测几乎不可能，先问再打）

| 输入 | 为什么重要 |
|---|---|
| **Schema** — OpenAPI/Swagger、Postman 集合、GraphQL introspection、gRPC `.proto` | 把猜端点变成完整枚举，是覆盖率的单点最大提升 |
| **两套凭据/Token**，最好分属不同租户 | BOLA/IDOR（API1:2023，API 第一大风险）只有"用租户 B 的 Token 访问租户 A 的对象"**能证明**才算数 |
| **低权限 + 高权限 Token** | 证明函数级授权失效（API5:2023——普通 user 调 admin 路由）必需 |
| **示例对象 ID** | 让 ID 篡改测试立刻可执行，不用先找有效标识符 |
| **排除路由** | 支付、批量通知、破坏性管理端点 |
| **限速 / WAF 情况** | 避免把预算烧在节流请求上，并让测试策略适配 |

缺什么问用户要——**不要伪造 Token，不要测不属于自己的 API**。

## 2. 测试重点（按 API Top 10:2023 排序）

1. **API1 BOLA/IDOR** — 逐对象 ID 换身份重放，核对响应里是否真的含对方租户数据（而不是空 200）
2. **API3 对象属性级授权** — PATCH/PUT 试 mass assignment（多带 role/tenant_id/is_admin 字段）；列表响应看是否过度暴露字段
3. **API5 函数级授权** — 用低权 Token 遍历管理路由
4. **API4 资源消耗** — 无分页/无深度限制的查询、batching 滥用
5. **API6/7/8 注入、资产管理、安全日志** — 注入按常规手法；API7/8 多数外部不可测，如实标注
6. **认证** — JWT 算法混淆(none-alg)、弱 HMAC 密钥、Token 放 URL、刷新令牌固定

## 3. 验证纪律

- 每条结论必须附**可直接 curl/Burp Repeater 重放的原始 HTTP 请求**
- 授权类结论必须核对响应体确含他方数据，**空 200 不算证明**
- 复现步骤写明前置条件（哪套 Token、哪个对象 ID）

## hack_scanner 运行方式

```bash
# API 站点黑盒扫描 + AI 解读
python hack_scanner.py -u https://api.staging.example.com --deep --ai

# GraphQL 端点专项
python hack_scanner.py -u https://api.example.com/graphql --ai
# （graphql_detector 负责 introspection/batching，JWT 用 jwt_detector）
```

报告输出时按"测试重点"顺序排列 API 类发现，并标注每条属于 API Top 10 的哪一项。
