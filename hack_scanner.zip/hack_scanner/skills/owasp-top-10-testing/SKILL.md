---
name: owasp-top-10-testing
description: 按 OWASP Top 10:2025 对 Web 应用做分类安全评估，输出逐条覆盖矩阵（哪些类别已验证、哪些部分覆盖、哪些从外部不可测），只报告能证明的漏洞。适用场景：OWASP 合规评估、安全审查、按 OWASP 分类的报告。use when: owasp, top10, 合规, 评估, assessment, compliance
tags: [owasp, top10, compliance, assessment, web, 合规, 评估]
---

# OWASP Top 10:2025 分类评估

OWASP Top 10 是**风险分类法，不是测试套件**——"OWASP Top 10 测试"意味着对真实应用逐条验证每个类别，只报告实际可复现的漏洞。

**使用当前版本：OWASP Top 10:2025**（第 8 版，取代 2021）。与 2021 的关键差异：
- **SSRF 并入 A01** Broken Access Control
- **A03 变为 Software Supply Chain Failures**（软件供应链失败），取代旧的"脆弱与过时组件"
- **A10 Mishandling of Exceptional Conditions**（异常条件处理不当）是新增类别
- A02 Security Misconfiguration 从第 5 位升到第 2 位

对 API 目标，改用 **OWASP API Security Top 10 (2023)**（见 `api-security-testing` 技能）。

## 覆盖矩阵（必须诚实地照此报告）

对每个类别如实标注验证深度——**声称十项全过是误导**：

| 类别 (2025) | 覆盖深度 | 说明 |
|---|---|---|
| A01 Broken Access Control (含 SSRF) | **强** | 跨用户/跨租户访问、越权、IDOR、SSRF（含 OOB 回调式盲 SSRF）均可实弹验证。需两个账号+一个高权账号才能证明授权半边 |
| A02 Security Misconfiguration | **强** | 调试端点、冗长报错、CORS 过宽、默认凭据、暴露的管理入口 |
| A03 Software Supply Chain Failures | **部分** | 可做版本指纹与依赖审查（有源码时更准）；构建系统/发布基础设施层属运行扫描范围外，需 SCA 补充 |
| A04 Cryptographic Failures | **部分** | 传输层配置、响应中泄露的密钥/Token 可测；静态数据加密与密钥管理需源码/基础设施审查 |
| A05 Injection | **强** | SQL/NoSQL/命令/模板注入、XSS 均可实弹验证 |
| A06 Insecure Design | **部分** | 业务逻辑滥用（价格/数量篡改、流程跳过、竞态）可达时能发现；设计意图需人工威胁建模 |
| A07 Authentication Failures | **强** | 认证绕过、弱会话/Token 处理、密码重置与 MFA 缺陷 |
| A08 Software or Data Integrity Failures | **部分** | 不安全反序列化、无签名更新路径可达时能测；CI/CD 信任边界不可运行态测试 |
| A09 Security Logging & Alerting Failures | **外部不可测** | 需审查日志与告警管道——**必须如实声明，禁止报"已通过"** |
| A10 Mishandling of Exceptional Conditions | **部分** | 畸形输入、强制报错、竞态/超时条件可主动探测，报告控制泄露与 fail-open 绕过；内部错误路径穷举需源码审查 |

## 报告纪律

1. 每个类别必须落三态之一：**已验证有漏洞 / 已验证无漏洞（附证据）/ 未覆盖或不可测**
2. "零发现"必须附带"测了哪些端点、哪些参数、用什么手法"——否则等同没测
3. 部分覆盖类别（上表"部分"）在报告中显式标注 partial，不得并入"已通过"
4. 扫描被预算/轮次上限中断时，报告头部必须标 `complete: false` 或"不完整"

## hack_scanner 运行方式

```bash
# URL 黑盒 + AI 解读（AI 分析阶段会按本技能输出覆盖矩阵）
python hack_scanner.py -u https://staging.example.com --deep --ai

# 文件/目录白盒 + AI 解读
python hack_scanner.py -f ./project --ai
```

报告中的"OWASP 分类"一列对照上表标注覆盖深度；`A09` 固定输出"外部不可测，需内部审计"。
