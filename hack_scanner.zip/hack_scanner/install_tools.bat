@echo off
setlocal EnableExtensions
title hack_scanner tool installer

rem ============================================================
rem  hack_scanner - one-shot external tool installer
rem  * idempotent: tools already on PATH are skipped
rem  * ASCII-only text: no GBK/UTF-8 mojibake in cmd
rem  * verifies the END STATE (where <tool>), not exit codes
rem  * re-safe: safe to run again anytime
rem  * bootstraps winget/chocolatey if missing (needs internet;
rem    choco install recommended with admin rights)
rem ============================================================

set "BINDIR=%LOCALAPPDATA%\hack_scanner\bin"
set "TMPD=%TEMP%\hack_scanner_dl"
set "FAILED="
set "OKLIST="

if not exist "%BINDIR%" mkdir "%BINDIR%"
if not exist "%TMPD%" mkdir "%TMPD%"
rem session PATH so installs made in THIS run are immediately findable
set "PATH=%PATH%;%BINDIR%;%USERPROFILE%\go\bin;%LOCALAPPDATA%\Microsoft\WinGet\Links;C:\Program Files\nmap;C:\Program Files (x86)\Nmap"

echo ============================================================
echo  hack_scanner external tools installer
echo  bin dir : %BINDIR%
echo ============================================================
echo.

rem ------------------------------------------------------------
rem [0/21] bootstrap package managers if missing (winget/choco)
rem ------------------------------------------------------------
echo === [0/21] bootstrap package managers ===
where winget >nul 2>&1 || call :bootstrap_winget
where choco  >nul 2>&1 || call :bootstrap_choco
echo.

rem ------------------------------------------------------------
rem [1/21] nmap          - winget
rem ------------------------------------------------------------
echo === [1/21] nmap (winget) ===
where nmap >nul 2>&1 && (echo   [skip] already on PATH) || (
  winget install -e --silent --accept-source-agreements --accept-package-agreements Insecure.Nmap >nul 2>&1
  where nmap >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] winget Insecure.Nmap & set "FAILED=%FAILED% nmap")
)
echo.

rem ------------------------------------------------------------
rem [2/21] ffuf          - winget
rem ------------------------------------------------------------
echo === [2/21] ffuf (winget) ===
where ffuf >nul 2>&1 && (echo   [skip] already on PATH) || (
  winget install -e --silent --accept-source-agreements --accept-package-agreements ffuf.ffuf >nul 2>&1
  where ffuf >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] winget ffuf.ffuf & set "FAILED=%FAILED% ffuf")
)
echo.

rem ------------------------------------------------------------
rem [3/21] feroxbuster   - winget
rem ------------------------------------------------------------
echo === [3/21] feroxbuster (winget) ===
where feroxbuster >nul 2>&1 && (echo   [skip] already on PATH) || (
  winget install -e --silent --accept-source-agreements --accept-package-agreements epi052.feroxbuster >nul 2>&1
  where feroxbuster >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] winget epi052.feroxbuster & set "FAILED=%FAILED% feroxbuster")
)
echo.

rem ------------------------------------------------------------
rem [4/21] amass         - winget
rem ------------------------------------------------------------
echo === [4/21] amass (winget) ===
where amass >nul 2>&1 && (echo   [skip] already on PATH) || (
  winget install -e --silent --accept-source-agreements --accept-package-agreements OWASP.Amass >nul 2>&1
  where amass >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] winget OWASP.Amass & set "FAILED=%FAILED% amass")
)
echo.

rem ------------------------------------------------------------
rem [5/21] trivy         - winget
rem ------------------------------------------------------------
echo === [5/21] trivy (winget) ===
where trivy >nul 2>&1 && (echo   [skip] already on PATH) || (
  winget install -e --silent --accept-source-agreements --accept-package-agreements AquaSecurity.Trivy >nul 2>&1
  where trivy >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] winget AquaSecurity.Trivy & set "FAILED=%FAILED% trivy")
)
echo.

rem ------------------------------------------------------------
rem [6/21] hashcat       - choco
rem ------------------------------------------------------------
echo === [6/21] hashcat (choco) ===
where hashcat >nul 2>&1 && (echo   [skip] already on PATH) || (
  choco install -y hashcat >nul 2>&1
  where hashcat >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] choco hashcat & set "FAILED=%FAILED% hashcat")
)
echo.

rem ------------------------------------------------------------
rem [7/21] exiftool      - choco
rem ------------------------------------------------------------
echo === [7/21] exiftool (choco) ===
where exiftool >nul 2>&1 && (echo   [skip] already on PATH) || (
  choco install -y exiftool >nul 2>&1
  where exiftool >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] choco exiftool & set "FAILED=%FAILED% exiftool")
)
echo.

rem ------------------------------------------------------------
rem [8/21] trufflehog    - choco
rem ------------------------------------------------------------
echo === [8/21] trufflehog (choco) ===
where trufflehog >nul 2>&1 && (echo   [skip] already on PATH) || (
  choco install -y trufflehog >nul 2>&1
  where trufflehog >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] choco trufflehog & set "FAILED=%FAILED% trufflehog")
)
echo.

rem ------------------------------------------------------------
rem [8b/21] yara          - choco (YARA rules engine: webshell/backdoor
rem                        detection, offense+defense in one)
rem  winget alt: winget install -e VirusTotal.YARA
rem ------------------------------------------------------------
echo === [8b/21] yara (choco) ===
where yara >nul 2>&1 && (echo   [skip] already on PATH) || (
  choco install -y yara >nul 2>&1
  rem the choco package ships yara64.exe/yarac64.exe only (no plain 'yara'
  rem shim) - expose the standard name in BINDIR so `where yara` passes
  if exist "C:\ProgramData\chocolatey\lib\yara\tools\yara64.exe" copy /y "C:\ProgramData\chocolatey\lib\yara\tools\yara64.exe" "%BINDIR%\yara.exe" >nul 2>&1
  if not exist "%BINDIR%\yara.exe" if exist "C:\ProgramData\chocolatey\bin\yara64.exe" copy /y "C:\ProgramData\chocolatey\bin\yara64.exe" "%BINDIR%\yara.exe" >nul 2>&1
  where yara >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] choco yara & set "FAILED=%FAILED% yara")
)
echo.

rem ------------------------------------------------------------
rem [9/21] sqlmap        - pip
rem ------------------------------------------------------------
echo === [9/21] sqlmap (pip) ===
where sqlmap >nul 2>&1 && (echo   [skip] already on PATH) || (
  call pip install --disable-pip-version-check --no-warn-conflicts sqlmap >nul 2>&1
  where sqlmap >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] pip sqlmap & set "FAILED=%FAILED% sqlmap")
)
echo.

rem ------------------------------------------------------------
rem [10/21] dirsearch    - pip
rem ------------------------------------------------------------
echo === [10/21] dirsearch (pip) ===
where dirsearch >nul 2>&1 && (echo   [skip] already on PATH) || (
  call pip install --disable-pip-version-check --no-warn-conflicts dirsearch >nul 2>&1
  where dirsearch >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] pip dirsearch & set "FAILED=%FAILED% dirsearch")
)
echo.

rem ------------------------------------------------------------
rem [11/21] nikto        - github source + perl (Strawberry)
rem ------------------------------------------------------------
echo === [11/21] nikto (github + strawberry perl) ===
where nikto >nul 2>&1 && (echo   [skip] already on PATH) || call :install_nikto
echo.

rem ------------------------------------------------------------
rem [12/21] nuclei       - github release exe
rem ------------------------------------------------------------
echo === [12/21] nuclei (github release) ===
where nuclei >nul 2>&1 && (echo   [skip] already on PATH) || call :install_nuclei
echo.

rem ------------------------------------------------------------
rem [13/21] john         - openwall jumbo-1 win64 (github release,
rem                        fallback openwall.com - very slow from CN)
rem ------------------------------------------------------------
echo === [13/21] john (openwall jumbo-1 win64) ===
where john >nul 2>&1 && (echo   [skip] already on PATH) || call :install_john
echo.

rem ------------------------------------------------------------
rem [14/21] wpscan       - ruby gem (runtime prereqs: gem stack,
rem                        public_suffix<6.1 pin, libcurl.dll next
rem                        to ruby.exe, loadable yajl-ruby [stub for the
rem                        default-gem quirk, or a fresh build] - see
rem                        :install_wpscan)
rem ------------------------------------------------------------
echo === [14/21] wpscan (gem) ===
call :install_wpscan
echo.

rem ------------------------------------------------------------
rem [15/21] hakrawler    - go install (goproxy.cn)
rem ------------------------------------------------------------
echo === [15/21] hakrawler (go install) ===
where hakrawler >nul 2>&1 && (echo   [skip] already on PATH) || (
  where go >nul 2>&1 || echo   [warn] go not found on PATH - install go first
  set "GOPROXY=https://goproxy.cn,direct"
  go install github.com/hakluke/hakrawler@latest >nul 2>&1
  if exist "%USERPROFILE%\go\bin\hakrawler.exe" copy /y "%USERPROFILE%\go\bin\hakrawler.exe" "%BINDIR%\" >nul 2>&1
  where hakrawler >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] go install hakrawler & set "FAILED=%FAILED% hakrawler")
)
echo.

rem ------------------------------------------------------------
rem [16/21] gobuster    - github release exe
rem ------------------------------------------------------------
echo === [16/21] gobuster (github release) ===
where gobuster >nul 2>&1 && (echo   [skip] already on PATH) || call :install_gobuster
echo.

rem ------------------------------------------------------------
rem [17/21] subfinder   - github release exe (ProjectDiscovery)
rem ------------------------------------------------------------
echo === [17/21] subfinder (github release) ===
where subfinder >nul 2>&1 && (echo   [skip] already on PATH) || call :install_subfinder
echo.

rem ------------------------------------------------------------
rem [18/21] katana      - github release exe (ProjectDiscovery)
rem ------------------------------------------------------------
echo === [18/21] katana (github release) ===
where katana >nul 2>&1 && (echo   [skip] already on PATH) || call :install_katana
echo.

rem ------------------------------------------------------------
rem [19/21] gau         - github release exe
rem ------------------------------------------------------------
echo === [19/21] gau (github release) ===
where gau >nul 2>&1 && (echo   [skip] already on PATH) || call :install_gau
echo.

rem ------------------------------------------------------------
rem [20/21] httpx       - github release exe (ProjectDiscovery).
rem                        NOTE: the python 'httpx' library also ships a
rem                        Scripts\httpx.exe CLI that sits AHEAD of
rem                        %BINDIR% on PATH and would shadow ours -
rem                        :install_httpx renames it to httpx-py.exe
rem                        (the library import is untouched).
rem                        Skip check is "our exe present", not `where`,
rem                        so a stale python shim does not false-skip us.
rem ------------------------------------------------------------
echo === [20/21] httpx (github release) ===
if exist "%BINDIR%\httpx.exe" (echo   [skip] already installed) || call :install_httpx
echo.

rem ------------------------------------------------------------
rem [21/21] hydra       - thc-hydra-windows v9.1 prebuilt (embedded
rem                        Cygwin DLLs; must stay in its own folder,
rem                        launched via the hydra.bat shim - john pattern)
rem ------------------------------------------------------------
echo === [21/21] hydra (thc-hydra-windows) ===
where hydra >nul 2>&1 && (echo   [skip] already on PATH) || call :install_hydra
echo.

rem ------------------------------------------------------------
rem binwalk (P0 #13) - intentionally NOT auto-installed (2026-08-30):
rem the only PyPI release (2.1.0) is incomplete - it lacks the
rem binwalk/core subpackage, so `import binwalk` crashes and the
rem console script is unusable; the official github repo is also
rem unreachable from some CN networks. file_meta.py degrades
rem gracefully without binwalk (try/except around the CLI call).
rem Install manually when you have access to the official repo:
rem   python -m pip install git+https://github.com/binwalk/binwalk.git
rem ------------------------------------------------------------
echo === binwalk (skipped - broken PyPI package) ===
echo   [skip] binwalk - PyPI 2.1.0 is incomplete (missing binwalk/core); install from the official repo manually
echo.

rem ------------------------------------------------------------
rem persist BINDIR into the USER PATH (new shells only)
rem ------------------------------------------------------------
powershell -NoProfile -Command "$p=[Environment]::GetEnvironmentVariable('PATH','User'); if ($p -notlike '*\hack_scanner\bin*') { [Environment]::SetEnvironmentVariable('PATH', $p+';%BINDIR%', 'User'); echo   [path] %BINDIR% added to user PATH (new shells only) } else { echo   [path] already present in user PATH }" 2>nul

echo.
echo ============================================================
echo  SELF-CHECK (this session PATH)
echo ============================================================
for %%t in (nikto nmap nuclei sqlmap john hashcat ffuf feroxbuster dirsearch wpscan amass hakrawler exiftool trufflehog trivy yara gobuster subfinder katana gau httpx hydra) do (
  where %%t >nul 2>&1 && echo   [OK]   %%t || echo   [MISS] %%t
)
echo  functional (wpscan actually starts; the gem/DLL stack is the usual break point):
where wpscan >nul 2>&1 && call wpscan --version >nul 2>&1 && echo   [OK]   wpscan (runs) || echo   [MISS] wpscan (runs)
echo.
if defined FAILED (
  echo  [!] FAILED / missing:%FAILED%
  echo      Possible offline sources: openwall.com / github.com / rubygems.org
  echo      Retry this script later, or set the matching tools/*_path in config.json
) else (
  echo  [all 21 tools on PATH]
)
echo.
rem ------------------------------------------------------------
rem python requirements (same dir as this script)
rem pypi.org is slow/unreliable on CN networks - pin the aliyun
rem mirror first (idempotent; reversible: pip config unset)
rem INTERPRETER (2026-08-30): this box has TWO pythons -
rem   * miniconda 3.13 : PARTIAL env - has core deps + semgrep/sherlock,
rem                      but LACKS checkov (import fails) + sqlmap/dirsearch
rem   * Python314      : FULL env - all requirements incl. checkov 3.3.13,
rem                      sqlmap 1.10.8, dirsearch 0.5.0
rem A bare 'pip'/'python' follows PATH and silently picked miniconda (it is
rem first on PATH) - which then lacks checkov, breaking the checkov/IaC
rem module. So the probe below PREFERS Python314 (the full env) and adds
rem checkov to the import test so the partial miniconda does not pass; bare
rem 'python' stays the fallback for fresh machines where Python314 is absent.
rem BATCHED on purpose: one all-or-nothing `pip install -r` meant a
rem single broken dep could sink EVERYTHING (checkov 3.2.x pins
rem rustworkx 0.13.x - no py3.13 win wheel - source build needs Rust);
rem batches keep failures local and each prints progress, so a slow
rem install is visible instead of looking frozen.
rem KNOWN-BENIGN DEPENDENCY CONFLICT (suppressed via --no-warn-conflicts):
rem   sslyze 6.3.1 pins cryptography<47, BUT mitmproxy 12.x -> aioquic ->
rem   service-identity pins cryptography>=47. No single cryptography version
rem   satisfies both - this is an upstream packaging conflict, not a script bug.
rem   We keep cryptography at the HIGHER bound (>=47) because service-identity
rem   has a real runtime need for it; sslyze's <47 pin is conservative and
rem   sslyze still runs fine on 48 (verified: `python -m sslyze` and
rem   `import mitmproxy.tools.main` both succeed on crypto 48.0.1).
rem   So pip's "ERROR: ... dependency conflicts" lines are WARNINGS, not
rem   failures - the install succeeds and both tools work. --no-warn-conflicts
rem   only stops that scary text printing. `pip check` still shows the sslyze
rem   line if you want the conflict visible.
rem ------------------------------------------------------------
echo === python requirements (pip, batched) ===
set "PYPY=python"
rem Prefer the FULL env (Python314). checkov in the test keeps the partial
rem miniconda from passing (see INTERPRETER note above). Bare python = fallback.
if exist "C:\Users\Administrator\AppData\Local\Programs\Python\Python314\python.exe" (
  "C:\Users\Administrator\AppData\Local\Programs\Python\Python314\python.exe" -c "import requests,bs4,lxml,yaml,jinja2,dns,tldextract,semgrep,sherlock_project,checkov" >nul 2>&1 && set "PYPY=C:\Users\Administrator\AppData\Local\Programs\Python\Python314\python.exe"
)
:py_pin_ok
echo   [python] using: %PYPY%
"%PYPY%" -m pip config set global.index-url https://mirrors.aliyun.com/pypi/simple/ >nul 2>&1 && echo   [pip] mirror -> aliyun (pypi.org is slow from CN)

rem batch 1 - core (scanners import these directly; all ship win wheels)
"%PYPY%" -m pip install --disable-pip-version-check --no-warn-conflicts requests urllib3 beautifulsoup4 lxml pyyaml jinja2 dnspython tldextract cryptography certifi && echo   [ok] core batch || (echo   [FAIL] core batch & set "FAILED=%FAILED% python-core")

rem batch 2 - AI + security optional (each has an in-scanner fallback)
"%PYPY%" -m pip install --disable-pip-version-check --no-warn-conflicts mcp nltk wafw00f shodan sslyze exifread whois rapidfuzz zaproxy && echo   [ok] security batch || (echo   [FAIL] security batch & set "FAILED=%FAILED% python-sec")

rem batch 3 - browser / doc / cloud / network
"%PYPY%" -m pip install --disable-pip-version-check --no-warn-conflicts selenium playwright nest_asyncio pdfkit weasyprint boto3 bcrypt aiohttp mitmproxy psutil && echo   [ok] web batch || (echo   [FAIL] web batch & set "FAILED=%FAILED% python-web")

rem batch 3b - gevent alone (C extension; if no wheel it source-builds and
rem            needs a C compiler - must not sink batch 3)
"%PYPY%" -m pip install --disable-pip-version-check --no-warn-conflicts gevent && echo   [ok] gevent || (echo   [FAIL] gevent & set "FAILED=%FAILED% gevent")

rem batch 4 - SAST. semgrep is wheel-only. checkov ONLY when rustc is on
rem            PATH - checkov 3.2.x pins rustworkx 0.13.x which has no
rem            py3.13/3.14 win wheel, so without Rust the source build
rem            fails and sinks the batch. (If a newer checkov is already
rem            installed - e.g. 3.3.13 on Python314 - pip just skips it
rem            and none of this matters.)
set "HAS_RUST="
where rustc >nul 2>&1 && set "HAS_RUST=1"
set "SAST=semgrep sherlock-project webdriver-manager"
if defined HAS_RUST set "SAST=semgrep checkov sherlock-project webdriver-manager"
"%PYPY%" -m pip install --disable-pip-version-check --no-warn-conflicts %SAST% && echo   [ok] sast batch || (echo   [FAIL] sast batch & set "FAILED=%FAILED% python-sast")
if not defined HAS_RUST (
  echo   [skip] checkov - no rustc on PATH. checkov 3.2.x pins rustworkx 0.13.x
  echo          which has no py3.13/3.14 win wheel, so pip would source-build
  echo          it and fail. If a newer checkov is already installed this
  echo          skip is a no-op. To add/upgrade later:  winget install -e
  echo          Rustlang.Rustup, then rustup default stable, then re-run.
)
echo.
echo  Tip: config.json tools.*_path still empty? Leave it - wrappers
echo       fall back to PATH automatically.
echo.
pause
endlocal
exit /b 0

rem ============================================================
:install_nikto
rem pick a perl that can load XML::Writer; prefer Strawberry (winget)
set "NIKTO_PERL="
perl -MXML::Writer -e 1 >nul 2>&1 && set "NIKTO_PERL=perl"
if not defined NIKTO_PERL (
  echo   no suitable perl - installing Strawberry Perl via winget ...
  winget install -e --silent --accept-source-agreements --accept-package-agreements StrawberryPerl.StrawberryPerl >nul 2>&1
)
if exist "C:\Strawberry\perl\bin\perl.exe" (
  set "NIKTO_PERL=C:\Strawberry\perl\bin\perl.exe"
  rem Strawberry may lack XML::Writer - patch it in (pure perl, single file)
  "%NIKTO_PERL%" -MXML::Writer -e 1 >nul 2>&1 || call :patch_xmlwriter
)
if not defined NIKTO_PERL (echo   [FAIL] no working perl with XML::Writer & set "FAILED=%FAILED% nikto" & exit /b 1)
"%NIKTO_PERL%" -MXML::Writer -e 1 >nul 2>&1
if errorlevel 1 (echo   [FAIL] no working perl with XML::Writer & set "FAILED=%FAILED% nikto" & exit /b 1)
rem download source (2.6.1)
curl -sL --retry 3 --max-time 120 -o "%TMPD%\nikto.tgz" "https://codeload.github.com/sullo/nikto/tar.gz/refs/tags/2.6.1"
if not exist "%TMPD%\nikto.tgz" (echo   [FAIL] download nikto source & set "FAILED=%FAILED% nikto" & exit /b 1)
if not exist "%BINDIR%\nikto" (
  tar -xzf "%TMPD%\nikto.tgz" -C "%TMPD%" >nul 2>&1
  xcopy /e /i /y /q "%TMPD%\nikto-2.6.1" "%BINDIR%\nikto" >nul 2>&1
)
if not exist "%BINDIR%\nikto\program\nikto.pl" (echo   [FAIL] extract nikto & set "FAILED=%FAILED% nikto" & exit /b 1)
rem shim
> "%BINDIR%\nikto.bat" (
  echo @echo off
  echo "%NIKTO_PERL%" "%BINDIR%\nikto\program\nikto.pl" %%*
)
where nikto >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] nikto shim & set "FAILED=%FAILED% nikto")
exit /b 0

rem ============================================================
:install_nuclei
curl -sL --retry 3 --max-time 600 -o "%TMPD%\nuclei.zip" "https://github.com/projectdiscovery/nuclei/releases/download/v3.11.1/nuclei_3.11.1_windows_amd64.zip"
if not exist "%TMPD%\nuclei.zip" (echo   [FAIL] download nuclei & set "FAILED=%FAILED% nuclei" & exit /b 1)
tar -xf "%TMPD%\nuclei.zip" -C "%TMPD%" >nul 2>&1
if not exist "%TMPD%\nuclei.exe" (echo   [FAIL] extract nuclei & set "FAILED=%FAILED% nuclei" & exit /b 1)
copy /y "%TMPD%\nuclei.exe" "%BINDIR%\nuclei.exe" >nul 2>&1
where nuclei >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] nuclei exe & set "FAILED=%FAILED% nuclei")
exit /b 0

rem ============================================================
:install_john
rem layout (both sources): run\john.exe + *.chr + john.conf + DLLs
rem (john 1.9.0-jumbo-1 win64 needs no john.ini - verified)
set "JOHN_EXE=%BINDIR%\john\run\john.exe"
if not exist "%JOHN_EXE%" set "JOHN_EXE=%BINDIR%\john\john.exe"
if not exist "%JOHN_EXE%" (
  set "JOHN_ZIP=%TMPD%\john.zip"
  set "TAR=%SystemRoot%\System32\tar.exe"
  call :john_dl "https://github.com/openwall/john-packages/releases/download/1.9.0-jumbo-1/x64_win.zip"
  if errorlevel 1 call :john_dl "https://www.openwall.com/john/k/john-1.9.0-jumbo-1-win64.zip"
  if errorlevel 1 (echo   [FAIL] download john - github and openwall both failed & set "FAILED=%FAILED% john" & exit /b 1)
  if not exist "%BINDIR%\john" (
    if exist "%TMPD%\john_x" rmdir /s /q "%TMPD%\john_x"
    mkdir "%TMPD%\john_x"
    "%TAR%" -xf "%JOHN_ZIP%" -C "%TMPD%\john_x" >nul 2>&1
    rem github zip is flat; openwall.com zip has a top folder
    if exist "%TMPD%\john_x\john-1.9.0-jumbo-1-win64" (
      move /y "%TMPD%\john_x\john-1.9.0-jumbo-1-win64" "%BINDIR%\john" >nul 2>&1
    ) else (
      xcopy /e /i /y /q "%TMPD%\john_x\*" "%BINDIR%\john\" >nul 2>&1
    )
  )
  set "JOHN_EXE=%BINDIR%\john\run\john.exe"
  if not exist "%JOHN_EXE%" set "JOHN_EXE=%BINDIR%\john\john.exe"
  if not exist "%JOHN_EXE%" (echo   [FAIL] extract john & set "FAILED=%FAILED% john" & exit /b 1)
)
rem shim (john.exe must run from its own dir to find john.conf/*.chr)
for %%F in ("%JOHN_EXE%") do set "JOHN_DIR=%%~dpF"
> "%BINDIR%\john.bat" (
  echo @echo off
  echo cd /d "%JOHN_DIR%"
  echo "%JOHN_EXE%" %%*
)
where john >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] john shim & set "FAILED=%FAILED% john")
exit /b 0

rem ============================================================
:john_dl
rem one bounded, resumable, validated download attempt (%~1 = URL).
rem If a VALID john.zip already exists, reuse it - so an interrupted run
rem re-started later does NOT re-fetch the ~66MB. A partial/invalid zip is
rem discarded first, so we never resume a download across a different source.
call :john_zip_ok && (echo   [reuse] valid john.zip present - skipping download & exit /b 0)
echo   downloading john win64 (~66MB) - slow links take ~10 min ...
del /q "%JOHN_ZIP%" >nul 2>&1
curl -L -C - --connect-timeout 15 --retry 3 --retry-delay 2 --max-time 900 -o "%JOHN_ZIP%" %~1 >nul 2>&1
call :john_zip_ok

rem ============================================================
:john_zip_ok
rem returns 0 if %JOHN_ZIP% exists, is big enough, and is a readable zip
if not exist "%JOHN_ZIP%" exit /b 1
for %%F in ("%JOHN_ZIP%") do set "JSZ=%%~zF"
rem real package is 65-66MB; reject partial downloads / HTML error pages
if %JSZ% LSS 50000000 exit /b 1
rem zip must be readable end-to-end (bsdtar)
"%TAR%" -tf "%JOHN_ZIP%" >nul 2>&1 || exit /b 1
exit /b 0

rem ============================================================
:patch_xmlwriter
rem XML-Writer 0.900 is a single pure-perl file (Writer.pm, packages
rem XML::Writer + XML::Writer::Namespaces) - drop it into Strawberry's
rem site lib instead of running a full cpanm build (needs make).
set "SITE=C:\Strawberry\perl\site\lib"
if not exist "%SITE%\XML" mkdir "%SITE%\XML"
if not exist "%TMPD%\xmlwriter.tar.gz" curl -sL --retry 3 --max-time 60 -o "%TMPD%\xmlwriter.tar.gz" "https://cpan.metacpan.org/authors/id/J/JO/JOSEPHW/XML-Writer-0.900.tar.gz"
if not exist "%TMPD%\xmlw" mkdir "%TMPD%\xmlw"
tar -xzf "%TMPD%\xmlwriter.tar.gz" -C "%TMPD%\xmlw" >nul 2>&1
for /d %%D in ("%TMPD%\xmlw\XML-Writer-*") do set "XWDIST=%%D"
if defined XWDIST copy /y "%XWDIST%\Writer.pm" "%SITE%\XML\Writer.pm" >nul 2>&1
"%NIKTO_PERL%" -MXML::Writer -e 1 >nul 2>&1 && exit /b 0
exit /b 1

rem ============================================================
:install_wpscan
rem wpscan needs FOUR runtime prerequisites that `gem install` alone
rem does not provide (all discovered by actually running wpscan):
rem  (1) gem stack: wpscan/cms_scanner/ethon/ffi
rem  (2) public_suffix in range - cms_scanner 0.15 pins ">= 4.0.3, < 6.1"
rem      but a fresh resolve installs 6.1+/7.x -> Gem::LoadError at startup.
rem      Fix: ensure 6.0.1 is present (with it installed, RubyGems activates
rem      it over the 6.1+/7.x copies; verified, so no uninstall is needed).
rem  (3) libcurl.dll findable by FFI. FFI 1.17 uses the Windows SAFE
rem      DLL search (app dir + system dirs, NOT PATH), so the dll must
rem      sit NEXT TO ruby.exe. Sources: choco curl pkg (libcurl-x64.dll,
rem      renamed), fallback official curl win64-mingw release.
rem  (4) a LOADABLE yajl-ruby. Two ways it is broken:
rem      a) built, but as a "default gem" whose lib dir never reaches
rem         $LOAD_PATH (rubygems add_self_to_load_path does
rem         `return if default_gem?` and the dir is absent from the
rem         startup load path) -> LoadError yajl/json_gem.
rem         Fix: a load-path shim in ruby's always-loaded lib dir,
rem         generated by :write_yajl_shim (no external file).
rem      b) not built at all (fresh ruby) -> gem install yajl-ruby
rem         (native C extension; needs gcc + mingw32-make on PATH).
rem Every step is idempotent; the final gate is a FUNCTIONAL smoke test,
rem so a "present but broken" wpscan is repaired on re-run, not skipped.
rem CMD-PARSING RULE (learned the hard way): ruby code passed on a cmd
rem command line must avoid unquoted & | < > ( ) ^ % ; and a DOUBLE-QUOTED
rem for /f over a FILE on this cmd build returns the literal path, not the
rem file's lines (the single-quoted COMMAND form is fine). So anything that
rem needs ruby metachars is done in a pre-authored file or a generated shim.
rem THIRD RULE (this is what killed step 14): a command that resolves to a
rem .bat/.cmd (wpscan -> wpscan.bat, gem -> gem.cmd) must be invoked with
rem CALL. A bare .bat invocation does NOT return to this script when it
rem finishes - it takes over the execution context and the installer's
rem remaining lines are dropped; an "exit /b" on the same line then kills
rem the WHOLE process instead of returning from this label. Verified 2026-08-29
rem with minimal repros: bare child .bat aborts the parent, "call child.bat"
rem returns correctly.

rem locate ruby (may live in a non-standard dir not on PATH)
where ruby >nul 2>&1 || for %%D in ("C:\tools\ruby34\bin" "C:\Ruby34-x64\bin" "C:\ruby34-x64\bin" "C:\tools\Ruby34\bin" "%USERPROFILE%\.rbenv\shims" "%LOCALAPPDATA%\Programs\RubyGems") do @if exist "%%~D\ruby.exe" set "PATH=%PATH%;%%~D"
set "RUBYEXE="
for %%F in (ruby.exe) do if exist "%%~$PATH:F" set "RUBYEXE=%%~$PATH:F"
if not defined RUBYEXE (
  echo   ruby not found - installing Ruby 3.4 via winget ...
  winget install -e --silent --accept-source-agreements --accept-package-agreements RubyInstallerTeam.Ruby.3.4 >nul 2>&1
  rem winget PATH changes do not reach this session - probe the standard dirs
  for %%D in ("C:\Ruby34-x64\bin" "C:\tools\ruby34\bin" "%LOCALAPPDATA%\Programs\Ruby34-x64\bin") do @if exist "%%~D\ruby.exe" set "PATH=%PATH%;%%~D"
  for %%F in (ruby.exe) do if exist "%%~$PATH:F" set "RUBYEXE=%%~$PATH:F"
)
if not defined RUBYEXE (echo   [FAIL] ruby not found - install via winget RubyInstallerTeam.Ruby.3.4 & set "FAILED=%FAILED% wpscan" & exit /b 1)
for %%F in ("%RUBYEXE%") do set "RUBYDIR=%%~dpF"

rem already WORKING? (functional check, not just "on PATH")
where wpscan >nul 2>&1 && call wpscan --version >nul 2>&1 && (echo   [ok] wpscan already works - nothing to do & exit /b 0)

rem (1) gem stack
where wpscan >nul 2>&1 || call gem install wpscan --no-document >nul 2>&1

rem (2) public_suffix: cms_scanner pins ">= 4.0.3, < 6.1". A fresh install
rem     pulls in 6.1+/7.x and wpscan then dies at startup with Gem::LoadError
rem     (no compliant version to activate). Fix: just ENSURE 6.0.1 is present.
rem     With 6.0.1 installed, RubyGems activates it for cms_scanner even if
rem     7.x is also there (verified: wpscan runs with 6.0.1 + 7.0.0 coexisting),
rem     so dropping the 6.1+/7.x copies is unnecessary. Idempotent (gem skips
rem     if 6.0.1 is already installed) and keeps no ruby metachar on the cmd
rem     line, so no external helper is needed for this step.
call gem install public_suffix -v 6.0.1 --no-document >nul 2>&1

rem (3) libcurl.dll next to ruby.exe (FFI safe-DLL-search needs it there)
if not exist "%RUBYDIR%\libcurl.dll" (
  if not exist "C:\ProgramData\chocolatey\lib\curl\tools" choco install -y curl >nul 2>&1
  for /d %%D in ("C:\ProgramData\chocolatey\lib\curl\tools\*") do (
    if exist "%%~D\bin\libcurl.dll" copy /y "%%~D\bin\libcurl.dll" "%RUBYDIR%\libcurl.dll" >nul 2>&1
    if exist "%%~D\bin\libcurl-x64.dll" copy /y "%%~D\bin\libcurl-x64.dll" "%RUBYDIR%\libcurl.dll" >nul 2>&1
  )
)
if not exist "%RUBYDIR%\libcurl.dll" (
  rem official curl release (win64-mingw) ships lib\libcurl.dll
  if not exist "%TMPD%\curl_off.tgz" curl -sL --retry 3 --max-time 300 -o "%TMPD%\curl_off.tgz" "https://github.com/curl/curl/releases/download/curl-8_12_1/curl-8.12.1-win64-mingw.tar.xz"
  if exist "%TMPD%\curl_off.tgz" (
    if not exist "%TMPD%\curl_off" mkdir "%TMPD%\curl_off"
    tar -xf "%TMPD%\curl_off.tgz" -C "%TMPD%\curl_off" >nul 2>&1
    for /r "%TMPD%\curl_off" %%F in (libcurl.dll) do copy /y "%%~F" "%RUBYDIR%\libcurl.dll" >nul 2>&1
  )
)
if exist "%RUBYDIR%\libcurl.dll" copy /y "%RUBYDIR%\libcurl.dll" "%BINDIR%\libcurl.dll" >nul 2>&1

rem (4) yajl-ruby loadability. This RubyInstaller build ships yajl-ruby as a
rem     "default gem" whose lib dir is NOT on the startup $LOAD_PATH, so
rem     `require "yajl/json_gem"` fails (LoadError) even though the gem and
rem     its compiled yajl.so are present. Fix:
rem     (4a) build yajl-ruby if nothing usable is built (fresh ruby) - needs
rem          a C toolchain: gcc + mingw32-make (Git for Windows ships both
rem          under C:\mingw64\bin).
rem     (4b) drop a tiny load-path shim into ruby's always-loaded lib dir
rem          (<rubylibdir>\yajl\json_gem.rb). It is GENERATED here by
rem          :write_yajl_shim (no external file needed); the shim finds the
rem          built yajl-ruby gem dir at runtime and puts its lib/ on
rem          $LOAD_PATH before loading the real json_gem.rb.
rem     State detection is done via require itself (a bare for-in wildcard
rem     here would match files only, not dirs, on recent Win11 builds).
set "RUBYLIBDIR="
for /f "delims=" %%L in ('ruby -e 'puts RbConfig::CONFIG["rubylibdir"]' 2^>nul') do set "RUBYLIBDIR=%%L"
if not defined RUBYLIBDIR set "RUBYLIBDIR=C:\tools\ruby34\lib\ruby\3.4.0"
ruby -e 'require "yajl/json_gem"' >nul 2>&1 || (
  rem not loadable - make it loadable
  rem 4a: ensure a BUILT yajl-ruby exists (the shim needs a compiled yajl.so).
  rem     If it is already built this is a cheap no-op (gem: already installed).
  where gcc >nul 2>&1 || echo   [warn] gcc not on PATH - a C toolchain is required, e.g. C:\mingw64\bin from Git for Windows
  where mingw32-make >nul 2>&1 || echo   [warn] mingw32-make not on PATH - a C toolchain is required, e.g. Git for Windows or choco mingw
  rem put a known C toolchain on PATH even if the user's PATH lacks one
  rem (Git for Windows -> C:\mingw64\bin, Strawberry -> C:\Strawberry\c\bin).
  rem Absent dirs are harmless.
  set "PATH=C:\mingw64\bin;C:\Strawberry\c\bin;%PATH%"
  rem build under plain cmd (not Git Bash/MSYS) so Ruby emits C:/ paths the
  rem native mingw32-make can resolve - a /C/... Makefile is the classic
  rem "No rule to make target '/C/tools/.../ruby.h'" failure.
  call gem install yajl-ruby --no-document >nul 2>&1
  where wpscan >nul 2>&1 || call gem install wpscan --no-document >nul 2>&1
  rem 4b: (re)write the load-path shim - cheap and idempotent
  if not exist "%RUBYLIBDIR%\yajl" mkdir "%RUBYLIBDIR%\yajl"
  call :write_yajl_shim "%RUBYLIBDIR%\yajl\json_gem.rb"
  echo   [fix] yajl/json_gem load shim -^> %RUBYLIBDIR%\yajl\json_gem.rb
)
rem (4c) verify the end state, not the steps
ruby -e 'require "yajl/json_gem"' >nul 2>&1 || (echo   [FAIL] yajl/json_gem still not loadable - wpscan will not start & set "FAILED=%FAILED% wpscan")

rem (5) functional gate
where wpscan >nul 2>&1 || set "PATH=%PATH%;%RUBYDIR%"
call wpscan --version >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] wpscan - check steps (1)-(4); re-run this script & set "FAILED=%FAILED% wpscan")
exit /b 0

rem ============================================================
:write_yajl_shim
rem Generate the yajl load-path shim at %~1. Each line is a separate
rem > / >> statement (NOT a paren block), so the ruby ( ) in the content are
rem just echoed text, not block delimiters. The shim is written without any
rem | < > & so nothing needs ^-escaping. It mirrors the old yajl_stub.rb:
rem locate the yajl-ruby gem dir that has a compiled yajl.so, put its lib/
rem on $LOAD_PATH, then load the real json_gem.rb from there.
>    "%~1" echo require "rbconfig"
>>   "%~1" echo base = File.expand_path("../..", __dir__)
>>   "%~1" echo cands = Dir.glob(File.join(base, "gems", "*", "gems", "yajl-ruby-*"))
>>   "%~1" echo dir = nil
>>   "%~1" echo for d in cands
>>   "%~1" echo   l = File.join(d, "lib")
>>   "%~1" echo   if File.exist?(File.join(l, "yajl", "yajl.so"))
>>   "%~1" echo     dir = l
>>   "%~1" echo   end
>>   "%~1" echo end
>>   "%~1" echo if dir
>>   "%~1" echo   $LOAD_PATH.unshift(dir) unless $LOAD_PATH.include?(dir)
>>   "%~1" echo   require "yajl/json_gem"
>>   "%~1" echo else
>>   "%~1" echo   raise LoadError, "cannot load such file -- yajl/json_gem"
>>   "%~1" echo end
exit /b 0

rem ============================================================
:install_gobuster
curl -sL --retry 3 --max-time 300 -o "%TMPD%\gobuster.zip" "https://github.com/OJ/gobuster/releases/download/v3.8.2/gobuster_Windows_x86_64.zip"
if not exist "%TMPD%\gobuster.zip" (echo   [FAIL] download gobuster & set "FAILED=%FAILED% gobuster" & exit /b 1)
tar -xf "%TMPD%\gobuster.zip" -C "%TMPD%" >nul 2>&1
if not exist "%TMPD%\gobuster.exe" (echo   [FAIL] extract gobuster & set "FAILED=%FAILED% gobuster" & exit /b 1)
copy /y "%TMPD%\gobuster.exe" "%BINDIR%\" >nul 2>&1
where gobuster >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] gobuster exe & set "FAILED=%FAILED% gobuster")
exit /b 0

rem ============================================================
:install_subfinder
curl -sL --retry 3 --max-time 300 -o "%TMPD%\subfinder.zip" "https://github.com/projectdiscovery/subfinder/releases/download/v2.16.0/subfinder_2.16.0_windows_amd64.zip"
if not exist "%TMPD%\subfinder.zip" (echo   [FAIL] download subfinder & set "FAILED=%FAILED% subfinder" & exit /b 1)
tar -xf "%TMPD%\subfinder.zip" -C "%TMPD%" >nul 2>&1
if not exist "%TMPD%\subfinder.exe" (echo   [FAIL] extract subfinder & set "FAILED=%FAILED% subfinder" & exit /b 1)
copy /y "%TMPD%\subfinder.exe" "%BINDIR%\" >nul 2>&1
where subfinder >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] subfinder exe & set "FAILED=%FAILED% subfinder")
exit /b 0

rem ============================================================
:install_katana
curl -sL --retry 3 --max-time 300 -o "%TMPD%\katana.zip" "https://github.com/projectdiscovery/katana/releases/download/v1.7.0/katana_1.7.0_windows_amd64.zip"
if not exist "%TMPD%\katana.zip" (echo   [FAIL] download katana & set "FAILED=%FAILED% katana" & exit /b 1)
tar -xf "%TMPD%\katana.zip" -C "%TMPD%" >nul 2>&1
if not exist "%TMPD%\katana.exe" (echo   [FAIL] extract katana & set "FAILED=%FAILED% katana" & exit /b 1)
copy /y "%TMPD%\katana.exe" "%BINDIR%\" >nul 2>&1
where katana >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] katana exe & set "FAILED=%FAILED% katana")
exit /b 0

rem ============================================================
:install_gau
curl -sL --retry 3 --max-time 300 -o "%TMPD%\gau.zip" "https://github.com/lc/gau/releases/download/v2.2.4/gau_2.2.4_windows_amd64.zip"
if not exist "%TMPD%\gau.zip" (echo   [FAIL] download gau & set "FAILED=%FAILED% gau" & exit /b 1)
tar -xf "%TMPD%\gau.zip" -C "%TMPD%" >nul 2>&1
if not exist "%TMPD%\gau.exe" (echo   [FAIL] extract gau & set "FAILED=%FAILED% gau" & exit /b 1)
copy /y "%TMPD%\gau.exe" "%BINDIR%\" >nul 2>&1
where gau >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] gau exe & set "FAILED=%FAILED% gau")
exit /b 0

rem ============================================================
:install_httpx
curl -sL --retry 3 --max-time 300 -o "%TMPD%\httpx.zip" "https://github.com/projectdiscovery/httpx/releases/download/v1.10.0/httpx_1.10.0_windows_amd64.zip"
if not exist "%TMPD%\httpx.zip" (echo   [FAIL] download httpx & set "FAILED=%FAILED% httpx" & exit /b 1)
tar -xf "%TMPD%\httpx.zip" -C "%TMPD%" >nul 2>&1
if not exist "%TMPD%\httpx.exe" (echo   [FAIL] extract httpx & set "FAILED=%FAILED% httpx" & exit /b 1)
copy /y "%TMPD%\httpx.exe" "%BINDIR%\" >nul 2>&1
rem the python 'httpx' library ships its own CLI shim (Scripts\httpx.exe)
rem that sits AHEAD of %BINDIR% on PATH and would shadow ours. Rename any
rem non-BINDIR httpx.exe to httpx-py.exe (the library import is unaffected -
rem only the CLI launcher moves; hack_scanner does not import httpx).
for /f "delims=" %%P in ('where httpx.exe 2^>nul') do if /i not "%%~P"=="%BINDIR%\httpx.exe" ren "%%~P" httpx-py.exe >nul 2>&1
where httpx >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] httpx exe & set "FAILED=%FAILED% httpx")
exit /b 0

rem ============================================================
:install_hydra
rem thc-hydra-windows v9.1: prebuilt x64 with EMBEDDED Cygwin DLLs -
rem hydra.exe only runs when its CWD is the folder holding the DLLs,
rem so the whole tree stays in %BINDIR%\hydra and a shim launches it
rem (same pattern as john.bat; a bare .bat child must be CALLed).
if not exist "%BINDIR%\hydra\hydra.exe" (
  curl -sL --retry 3 --max-time 600 -o "%TMPD%\hydra-win.zip" "https://github.com/maaaaz/thc-hydra-windows/releases/download/v9.1/thc-hydra-windows-v9.1.zip"
  if not exist "%TMPD%\hydra-win.zip" (echo   [FAIL] download hydra & set "FAILED=%FAILED% hydra" & exit /b 1)
  if not exist "%TMPD%\hydra_x" mkdir "%TMPD%\hydra_x"
  tar -xf "%TMPD%\hydra-win.zip" -C "%TMPD%\hydra_x" >nul 2>&1
  xcopy /e /i /y /q "%TMPD%\hydra_x\*" "%BINDIR%\hydra\" >nul 2>&1
)
if not exist "%BINDIR%\hydra\hydra.exe" (echo   [FAIL] extract hydra & set "FAILED=%FAILED% hydra" & exit /b 1)
> "%BINDIR%\hydra.bat" (
  echo @echo off
  echo cd /d "%BINDIR%\hydra"
  echo "%BINDIR%\hydra\hydra.exe" %%*
)
where hydra >nul 2>&1 && echo   [ok] installed || (echo   [FAIL] hydra shim & set "FAILED=%FAILED% hydra")
exit /b 0

rem ============================================================
:bootstrap_winget
rem winget missing -> (1) re-register App Installer if the MSIX is
rem already on disk, (2) otherwise download it via the official
rem aka.ms links (order: VCLibs, UI.Xaml, bundle - per winget-cli
rem issue #2434, Microsoft staff canonical no-Store install)
echo   winget missing - installing App Installer ...
if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\winget.exe" (
  set "PATH=%PATH%;%LOCALAPPDATA%\Microsoft\WindowsApps"
  where winget >nul 2>&1 && (echo   [ok] winget found on disk & exit /b 0)
)
powershell -NoProfile -Command "Add-AppxPackage -RegisterByFamilyName -MainPackage Microsoft.DesktopAppInstaller_8wekyb3d8bbwe" >nul 2>&1
where winget >nul 2>&1 && (echo   [ok] winget re-registered & exit /b 0)
set "WD=%TMPD%\winget"
if not exist "%WD%" mkdir "%WD%"
curl -sL --retry 3 --max-time 300 -o "%WD%\vclibs.appx" "https://aka.ms/Microsoft.VCLibs.x64.14.00.Desktop.appx"
curl -sL --retry 3 --max-time 300 -o "%WD%\uixaml.appx" "https://github.com/microsoft/microsoft-ui-xaml/releases/download/v2.8.6/Microsoft.UI.Xaml.2.8.x64.appx"
curl -sL --retry 3 --max-time 600 -o "%WD%\winget_bundle.msixbundle" "https://aka.ms/getwinget"
if not exist "%WD%\winget_bundle.msixbundle" (echo   [FAIL] download App Installer & exit /b 1)
powershell -NoProfile -Command "Add-AppxPackage '%WD%\vclibs.appx'; Add-AppxPackage '%WD%\uixaml.appx'; Add-AppxPackage '%WD%\winget_bundle.msixbundle'" >nul 2>&1
set "PATH=%PATH%;%LOCALAPPDATA%\Microsoft\WindowsApps"
where winget >nul 2>&1 && echo   [ok] winget installed || echo   [warn] winget still missing - its tools will show [FAIL]
exit /b 0

rem ============================================================
:bootstrap_choco
echo   chocolatey missing - installing via chocolatey.org/install.ps1 ...
if exist "C:\ProgramData\chocolatey\bin\choco.exe" (
  set "PATH=%PATH%;C:\ProgramData\chocolatey\bin"
  where choco >nul 2>&1 && (echo   [ok] choco found on disk & exit /b 0)
)
net session >nul 2>&1 || echo   [note] not elevated - choco install may fail; re-run this script as admin if so
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex (New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1')" >nul 2>&1
set "PATH=%PATH%;C:\ProgramData\chocolatey\bin;%USERPROFILE%\chocolatey\bin"
where choco >nul 2>&1 && echo   [ok] choco installed || echo   [warn] choco still missing - its tools will show [FAIL]
exit /b 0
