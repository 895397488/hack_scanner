# Project Context for DeepSec Scanning

> This file is auto-injected into deepsec matcher scanning.
> It provides project-specific signal that reduces false positives
> and adds custom detection patterns.
> Target: 30-60 lines total. Verbose context dilutes signal.

## What this codebase does

<one paragraph: what the app does, stack, users served>

## Auth primitives (by name)

List the main auth/security helpers used in this project.
The scanner will flag routes/endpoints that bypass these.

- `exampleAuthMiddleware`
- `<add your auth helpers here>`

## Threat model

<2-3 sentences: what an attacker wants, ranked by impact>

## Project-specific patterns to flag

<3-5 patterns unique to this codebase, with example lines>
Use deepsec:pattern() to add custom regex rules:

```
//deepsec:pattern("my-custom-check", "your-regex-pattern-here")
```

## Known false positives

<paths/patterns that look risky but are intentional>

- `test/fixtures/mock-secret.txt` — test fixture with dummy keys
- `src/dev/legacy-api.ts` — deprecated endpoint, will be removed
