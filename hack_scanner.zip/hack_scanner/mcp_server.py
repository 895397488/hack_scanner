#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hack Scanner MCP Server
暴露 hack_scanner 的所有扫描能力给 Claude Code / Cursor / Windsurf 等 agent。

启动方式:
    python -m hack_scanner.mcp_server          # Stdio transport (推荐)
    mcp install hack_scanner/mcp_server.py      # Claude Code auto-install
"""

import json
import os
import sys
import logging
from typing import Any

# ── 路径修正：确保 hack_scanner 目录在 sys.path 最前 ──
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

# ── 加载 config ──
CONFIG_PATH = os.path.join(_HERE, "config.json")
with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    CONFIG = json.load(f)

# ── 屏蔽第三方库日志 ──
logging.getLogger().setLevel(logging.WARNING)

# ── MCP SDK ──
try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print(
        "ERROR: MCP server requires the modelcontextprotocol package.\n"
        "Install with: pip install modelcontextprotocol",
        file=sys.stderr,
    )
    sys.exit(1)

# ── 导入现有扫描模块（复用，不修改原代码）──
from url_scanner import URLScanner
from file_analyzer import analyze_file_or_dir, FileAnalyzer
from scanners.subdomain_takeover import SubdomainTakeoverDetector, CloudBucketEnumerator

# ── P0/P1 新集成模块 ──
try:
    from scanners.waf_detector import detect_waf
    HAS_WAF = True
except (ImportError, Exception):
    HAS_WAF = False

from scanners.sql_exploit import exploit_sqli
from scanners.web_fuzzer import fuzz_paths, fuzz_params
from scanners.osint_recon import osint_recon
from scanners.ssl_deep_scan import ssl_deep_scan
from scanners.network_scan import network_scan, port_scan, host_discovery
from scanners.file_meta import file_metadata, check_steganography
from scanners.domain_similarity import find_typosquats, check_domain_similarity
from scanners.dns_zone_transfer import dns_recon
from scanners.cve_lookup import lookup_cve, check_package_vulns
from scanners.webshell_detector import detect_webshells
from scanners.domain_cert_monitor import cert_monitor, subdomains_from_cert
from scanners.zap_scanner import zap_scan as _zap_scan, zap_active_scan, zap_spider
from scanners.git_secret_scanner import scan_git_repo, scan_git_remote
from scanners.nuclei_scanner import nuclei_scan as _nuclei_scan, nuclei_template_search
from scanners.gobuster_wrapper import gobuster_dir, gobuster_vhost, gobuster_dns
from scanners.hydra_wrapper import hydra_http_post, hydra_ssh
from scanners.google_dorker import google_dork as _google_dork, get_owasp_ghdb, dork_by_keyword

# ── 扫描去重：防止同一URL在10秒内被重复触发 ──
import time as _time
_import_lock = __import__('threading').Lock()
_last_scan: dict = {}  # url -> start_time


# ====================================================================
# 工具实现
# ====================================================================

def _result(findings: list[dict], summary: dict) -> dict:
    """统一返回格式"""
    return {"findings": findings, "summary": summary, "ok": True}


def _url_scan(url: str, depth: str = "standard", output_dir: str = ".") -> dict:
    """执行 URL 扫描，返回结构化结果（含去重保护）"""
    now = _time.time()
    with _import_lock:
        prev = _last_scan.get(url)
        if prev is not None and now - prev < 10:
            return {"ok": False, "error": f"重复扫描：{url} 在10秒内已被扫描，已跳过", "findings": [], "summary": {}}
        _last_scan[url] = now
    try:
        scanner = URLScanner(output_dir)
        result = scanner.scan(url)

        findings = []
        for f in result.findings:
            finding = {
                "severity": f.severity.value if hasattr(f.severity, 'value') else str(f.severity),
                "category": f.category,
                "title": getattr(f, "title", ""),
                "description": getattr(f, "description", ""),
                "evidence": (getattr(f, "evidence", "") or "")[:500],
                "recommendation": getattr(f, "recommendation", ""),
                "url": getattr(f, "url", url),
            }
            if hasattr(f, "cwe") and f.cwe:
                finding["cwe"] = f.cwe
            findings.append(finding)

        summary = {
            "target_url": result.target_url,
            "hostname": result.hostname,
            "total_findings": len(findings),
            "critical": result.critical_count if hasattr(result, 'critical_count') else 0,
            "high": result.high_count if hasattr(result, 'high_count') else 0,
            "medium": sum(1 for f in findings if f["severity"] == "medium"),
        }

        return _result(findings, summary)

    except Exception as e:
        return {"ok": False, "error": str(e), "findings": [], "summary": {}}


def _file_analyze(path: str) -> dict:
    """执行文件/目录分析，返回结构化结果"""
    try:
        if not os.path.exists(path):
            return {"ok": False, "error": f"路径不存在: {path}", "findings": [], "summary": {}}

        is_dir = os.path.isdir(path)

        # FileAnalyzer 是内部类，用 analyze_file_or_dir 便捷函数
        findings_list = analyze_file_or_dir(path)
        if not isinstance(findings_list, list):
            findings_list = getattr(findings_list, "findings", [])

        findings = []
        for f in findings_list:
            if hasattr(f, "to_dict"):
                d = f.to_dict()
            elif isinstance(f, dict):
                d = f
            else:
                continue
            # 截断 evedence 防止过大
            if "evidence" in d:
                d["evidence"] = str(d["evidence"])[:500]
            findings.append(d)

        summary = {
            "scanned_path": path,
            "is_directory": is_dir,
            "total_findings": len(findings),
            "critical": sum(1 for f in findings if f.get("severity") == "critical"),
            "high": sum(1 for f in findings if f.get("severity") == "high"),
        }

        return _result(findings, summary)

    except Exception as e:
        return {"ok": False, "error": str(e), "findings": [], "summary": {}}


def _subdomain_takeover_check(domain: str, subdomains: list[str] | None = None) -> dict:
    """子域名接管检测"""
    try:
        if not subdomains:
            # 如果没提供子域名列表，提示用户需要先枚举子域名
            return {
                "ok": False,
                "error": f"需要提供子域名列表。可以先用 URL Scanner 的目录爆破功能发现子域名，或自行准备 subdomains.json",
                "findings": [],
                "summary": {"domain": domain},
            }

        findings = SubdomainTakeoverDetector.detect(subdomains)

        # 转换为 MCP 格式
        mcp_findings = []
        for f in findings:
            mcp_findings.append({
                "id": f.get("id", "SUBDOMAIN_TAKEOVER"),
                "severity": f.get("severity", "high"),
                "title": f.get("title", ""),
                "description": f.get("description", ""),
                "evidence": f.get("evidence", "")[:500],
                "recommendation": f.get("recommendation", ""),
                "cvss": f.get("cvss", 0),
                "cwe": f.get("cwe", "CWE-441"),
            })

        summary = {
            "domain": domain,
            "subdomains_checked": len(subdomains),
            "total_findings": len(mcp_findings),
            "critical": sum(1 for f in mcp_findings if f["severity"] == "critical"),
            "high": sum(1 for f in mcp_findings if f["severity"] == "high"),
        }

        return _result(mcp_findings, summary)

    except Exception as e:
        return {"ok": False, "error": str(e), "findings": [], "summary": {}}


def _cloud_bucket_enum(domain: str, subdomains: list[str] | None = None) -> dict:
    """云存储桶枚举"""
    try:
        if not subdomains:
            from urllib.parse import urlparse
            parsed = urlparse(domain)
            base = parsed.hostname or domain
            # 默认只检查根域名
            subdomains = [base]

        findings = CloudBucketEnumerator.detect(domain, subdomains)

        mcp_findings = []
        for f in findings:
            mcp_findings.append({
                "id": f.get("id", "CLOUD_BUCKET"),
                "severity": f.get("severity", "high"),
                "title": f.get("title", ""),
                "description": f.get("description", "")[:500],
                "evidence": f.get("evidence", "")[:500],
                "recommendation": f.get("recommendation", ""),
            })

        summary = {
            "domain": domain,
            "buckets_checked": len(subdomains) * 3,  # S3 + GCS + Azure patterns
            "total_findings": len(mcp_findings),
        }

        return _result(mcp_findings, summary)

    except Exception as e:
        return {"ok": False, "error": str(e), "findings": [], "summary": {}}


# ====================================================================
# MCP Server 注册
# ====================================================================

mcp = FastMCP(
    name="hack_scanner",
    instructions="自动化渗透测试扫描器：23个MCP工具 — URL/SAST/WAF/SQLi/Fuzz/子域名/云桶/OSINT/SSL/网络/元数据/域名混淆/DNS/CVE/Webshell/证书/ZAP/GitSecrets/Nuclei/GoBuster/Hydra/GoogleDork",
)


@mcp.tool()
def url_scan(
    url: str = ...,
    depth: str = "standard",
    output_dir: str = ".",
) -> str:
    """扫描一个 URL，返回 OWASP Top 10 漏洞检测结果。

    Args:
        url: 要扫描的目标 URL（如 https://example.com/path?param=value）
        depth: 扫描深度 — "quick" (仅基础检测) / "standard" (标准全套) / "deep" (含深度启发式)
        output_dir: 报告输出目录，默认当前工作目录。报告会生成 report.html 和 report.json
    """
    return json.dumps(_url_scan(url, depth, output_dir), ensure_ascii=False, indent=2)


@mcp.tool()
def file_analyze(path: str) -> str:
    """分析文件或代码目录的安全问题（SAST）。

    检测敏感信息泄露、硬编码密钥、SQL注入风险、XSS 风险等。

    Args:
        path: 要扫描的文件路径或目录路径
    """
    return json.dumps(_file_analyze(path), ensure_ascii=False, indent=2)


@mcp.tool()
def subdomain_takeover_check(
    domain: str = ...,
    subdomains: list[str] | None = None,
) -> str:
    """检测子域名接管风险（Dangling CNAME）。

    适用于 CloudFlare Workers、Vercel、Netlify、GitHub Pages 等托管服务的子域名。

    Args:
        domain: 根域名，如 example.com
        subdomains: 子域名列表，如 ["app.example.com", "dev.example.com"]。如果不提供需先自行枚举
    """
    return json.dumps(_subdomain_takeover_check(domain, subdomains), ensure_ascii=False, indent=2)


@mcp.tool()
def cloud_bucket_enum(
    domain: str = ...,
    subdomains: list[str] | None = None,
) -> str:
    """枚举 S3 / Google Cloud Storage / Azure Blob 公开存储桶。

    Args:
        domain: 根域名，如 example.com
        subdomains: 子域名列表（作为存储桶名称候选）
    """
    return json.dumps(_cloud_bucket_enum(domain, subdomains), ensure_ascii=False, indent=2)


# ====================================================================
# P0/P1 新集成工具
# ====================================================================

def _waf_detect(url: str) -> dict:
    """检测目标是否部署了 WAF/IPS"""
    if not HAS_WAF:
        return {
            "ok": False, "error": "wafw00f 未安装，请运行 pip install wafw00f",
            "target_url": url, "wafs_detected": [],
        }
    result = detect_waf(url)
    return {
        "ok": True,
        "target_url": result.get("target", url),
        "wafs_detected": result.get("wafs_detected", []),
        "generic_detection": result.get("generic_detection", False),
    }


def _sql_exploit(
    url: str,
    param: str = "id",
) -> dict:
    """对可疑参数运行 sqlmap 进行 SQLi 自动化利用"""
    result = exploit_sqli(url=url, param=param, risk=1, level=3)
    return {
        "ok": result.get("ok", False),
        "target_url": url,
        "param": param,
        "injection_detected": result.get("injection_detected", False),
        "db_type": result.get("db_type"),
        "databases": result.get("databases", []),
        "tables": result.get("tables", {}),
        "dumped_data": result.get("dumped_data", []),
        "error": result.get("error", ""),
    }


def _web_fuzz(
    target: str,
    fuzz_type: str = "paths",
    wordlist_path: str = "",
    depth: int = 3,
) -> dict:
    """URL 路径或参数模糊测试"""
    try:
        if fuzz_type == "paths":
            result = fuzz_paths(target, wordlist=wordlist_path if wordlist_path else None, depth=depth)
            return {
                "ok": result.get("ok", False),
                "target": target,
                "fuzz_type": "paths",
                "method": result.get("method", ""),
                "findings_count": result.get("summary_count", 0),
                "findings": (result.get("findings") or [])[:100],  # 截断防止过大
                "error": result.get("error", ""),
            }
        elif fuzz_type == "params":
            # wordlist_path 作为逗号分隔的词表
            words = [w.strip() for w in (wordlist_path or "").split(",") if w.strip()]
            if not words:
                return {"ok": False, "error": "fuzz_type=params 需要 wordlist 参数（逗号分隔的词表）", "target": target}
            result = fuzz_params(target, words)
            return {
                "ok": result.get("ok", False),
                "target": target,
                "fuzz_type": "params",
                "findings_count": result.get("summary_count", 0),
                "findings": (result.get("findings") or [])[:50],
                "error": result.get("error", ""),
            }
        else:
            return {"ok": False, "error": f"未知 fuzz_type: {fuzz_type}，支持 paths/params", "target": target}
    except Exception as e:
        return {"ok": False, "error": str(e), "target": target}


@mcp.tool()
def waf_detect(url: str = ...) -> str:
    """检测目标是否部署了 WAF/IPS 防火墙。

    自动识别 Cloudflare、WAF、ModSecurity、Imperva 等 100+ WAF 产品。
    扫描前先调用此工具，如果检测到 WAF 则后续测试需调整 payload 或降低频率。

    Args:
        url: 目标 URL（会发送探测请求）
    """
    return json.dumps(_waf_detect(url), ensure_ascii=False, indent=2)


@mcp.tool()
def sql_exploit(
    url: str = ...,
    param: str = "id",
) -> str:
    """对 SQL 注入可疑参数进行自动化利用（使用 sqlmap）。

    如果发现 SQLi 漏洞，会自动探测数据库类型、列出所有数据库名/表名。
    需要 sqlmap 已安装: pip install sqlmap 或 git clone https://github.com/sqlmapproject/sqlmap

    Args:
        url: 目标 URL（必须包含可疑参数，如 https://example.com/page?id=1）
        param: 要测试的参数名，默认 "id"
    """
    return json.dumps(_sql_exploit(url, param), ensure_ascii=False, indent=2)


@mcp.tool()
def web_fuzz(
    target: str = ...,
    fuzz_type: str = "paths",
    wordlist_path: str = "",
    depth: int = 3,
) -> str:
    """对 URL 进行路径或参数模糊测试（使用 ffuf）。

    paths — 发现隐藏目录/文件/端点，探测响应码过滤。
    params — fuzz 单个参数的值（用于绕过 WAF 的输入测试）。
    需要 ffuf 已安装: go install github.com/ffuf/ffuf/v2@latest 或 apt/brew install ffuf

    Args:
        target: 目标 URL（paths 模式加 /，params 模式用 {FUZZ} 占位符）
        fuzz_type: "paths" (目录爆破) 或 "params" (参数值 fuzz)
        wordlist_path: 词表路径；words_mode 时传入逗号分隔词表
        depth: paths 模式的爆破深度（1-3），默认 3
    """
    return json.dumps(_web_fuzz(target, fuzz_type, wordlist_path, depth), ensure_ascii=False, indent=2)


# ====================================================================
# P2 新集成工具
# ====================================================================

def _osint_recon(
    domain: str = ...,
    shodan_key: str = "",
) -> str:
    """OSINT 开源情报侦察：IP/WHOIS/Shodan/API 信息聚合。"""
    result = osint_recon(domain, shodan_key=shodan_key)
    return json.dumps(result, ensure_ascii=False, indent=2)


def _ssl_deep(
    url: str = ...,
) -> str:
    """深度 SSL/TLS 证书和协议分析（sslyze）。"""
    result = ssl_deep_scan(url)
    return json.dumps(result, ensure_ascii=False, indent=2)


def _network_scan_tool(
    target: str = ...,
    scan_type: str = "full",
) -> str:
    """网络层扫描：masscan 快速端口发现 + nmap 深度分析。"""
    result = network_scan(target, scan_type=scan_type)
    return json.dumps(result, ensure_ascii=False, indent=2)


def _file_meta_tool(
    path: str = ...,
    stego: bool = False,
) -> str:
    """文件元数据 + 隐写检测（EXIF/文档属性/steganography）。"""
    if stego:
        result = check_steganography(path)
    else:
        result = file_metadata(path)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def osint_recon_tool(
    domain: str = ...,
    shodan_key: str = "",
) -> str:
    """OSINT 开源情报侦察：IP 地址、WHOIS 注册信息、Shodan API 服务指纹。

    综合信息包括：
    - IP 解析 / 反向 DNS
    - WHOIS（注册商/创建日期/过期日期）
    - Shodan 开放端口 + 服务识别 + CVE（需 shodan_key）

    Args:
        domain: 目标域名，如 example.com
        shodan_key: Shodan API Key（可选，免费注册于 https://account.shodan.io/account）
    """
    return _osint_recon(domain, shodan_key)


@mcp.tool()
def ssl_deep_scan_tool(
    url: str = ...,
) -> str:
    """深度 SSL/TLS 证书和协议分析（sslyze）。

    比基础检查更全面：TLS版本、密码套件列表+弱加密告警、证书信任链、
    Heartbleed/POODLE/BEAST 等已知漏洞、HSTS 支持、OCSP stapling。

    Args:
        url: 目标 URL（如 https://example.com）
    """
    return _ssl_deep(url)


@mcp.tool()
def network_scan_tool(
    target: str = ...,
    scan_type: str = "full",
) -> str:
    """网络层扫描：masscan 快速端口发现 + nmap 深度服务分析。

    - masscan：百万级 IP/秒的极速端口扫描（Phase 1）
    - nmap：服务版本识别、OS 指纹、已知漏洞（Phase 2）
    - host_discovery：局域网 ARP/ICMP 主机发现

    Args:
        target: IP、域名或网段（如 192.168.1.0/24）
        scan_type: "quick" (仅 masscan) / "full" (masscan + nmap) / "nmap" (仅 nmap)

    Notes:
        - masscan 需单独安装：https://github.com/robertdavidgraham/masscan
        - nmap 通常系统自带（apt install nmap）
    """
    return _network_scan_tool(target, scan_type)


@mcp.tool()
def file_meta_tool(
    path: str = ...,
    stego: bool = False,
) -> str:
    """文件元数据分析 + 隐写检测（图片 EXIF / Office/PDF 属性）。

    - 图片：EXIF 信息（相机/时间/GPS坐标）、隐写可疑指标
    - Office/PDF：文档属性（作者/创建者/软件）
    - stego=True：运行 binwalk/stegdetect 深度隐写检测

    Args:
        path: 文件路径（图片/Office/PDF 均可）
        stego: 是否进行深度隐写检测（推荐对可疑图片启用）
    """
    return _file_meta_tool(path, stego)


# ====================================================================
# P3 新集成工具（域名/证书/CVE/Webshell）
# ====================================================================

@mcp.tool()
def domain_typosquat(
    domain: str = ...,
    similarity_threshold: float = 80.0,
) -> str:
    """发现与目标域名相似的潜在钓鱼域名（typosquatting/homograph 检测）。

    生成可能的混淆变体：重复字符、删除字符、键盘相邻键替换、TLD 替换、
    IDN Homograph（Cyrillic）、子域名前缀等。

    Args:
        domain: 目标域名，如 google.com
        similarity_threshold: 相似度阈值 (60-95)，越高越精确
    """
    return json.dumps(find_typosquats(domain, similarity_threshold), ensure_ascii=False, indent=2)


@mcp.tool()
def dns_recon_tool(
    domain: str = ...,
) -> str:
    """DNS 深度侦察：区域转移 (AXFR) + 所有记录类型查询。

    - 尝试 DNS 区域转移（如果配置不当可直接获取整张 DNS 表）
    - A / AAAA / CNAME / MX / NS / TXT / SRV / CAA / SPF / SOA 等全部记录
    - DMARC / SPF 策略检查

    Args:
        domain: 目标域名
    """
    return json.dumps(dns_recon(domain), ensure_ascii=False, indent=2)


@mcp.tool()
def cve_lookup(
    query_type: str = "cve",
    cve_id: str = "",
    vendor: str = "",
    product: str = "",
    version: str = "",
) -> str:
    """CVE 漏洞查询（NVD API，无需 key）。

    query_type=cve — 查询单个 CVE（如 CVE-2024-1234）
    query_type=package — 查询特定软件版本的 CVE（如 apache httpd 2.4.49）

    Args:
        query_type: "cve" 或 "package"
        cve_id: CVE 编号，如 CVE-2024-1234
        vendor: 厂商名（package 模式用）
        product: 产品名（package 模式用）
        version: 版本号（package 模式用）
    """
    if query_type == "cve":
        return json.dumps(lookup_cve(cve_id), ensure_ascii=False, indent=2)
    elif query_type == "package":
        return json.dumps(check_package_vulns(vendor, product, version), ensure_ascii=False, indent=2)
    return json.dumps({"ok": False, "error": "query_type 必须是 'cve' 或 'package'"})


@mcp.tool()
def webshell_detect(
    path: str = ...,
) -> str:
    """Webshell（后门文件）检测。

    递归扫描 PHP/ASP/ASPX/JSP/Python/Perl 文件的 webshell 特征：
    - eval/assert + $_POST (PHP)
    - System.Diagnostics.Process (ASPX)
    - Runtime.exec (JSP)
    - os.system (Python)
    - 可疑文件名模式（r57, c99, wso, cmd.php 等）

    Args:
        path: 要扫描的文件或目录路径
    """
    return json.dumps(detect_webshells(path), ensure_ascii=False, indent=2)


@mcp.tool()
def cert_monitor_tool(
    domain: str = ...,
) -> str:
    """SSL/TLS 证书透明度监控（crt.sh）。

    通过 Certificate Transparency logs：
    - 发现域名的所有 SSL 证书
    - 被动子域名枚举（证书中必然包含子域名）
    - 过期/异常证书告警
    - Wildcard 证书数量统计

    Args:
        domain: 目标域名
    """
    return json.dumps(cert_monitor(domain), ensure_ascii=False, indent=2)


# ====================================================================
# P5 新集成工具（ZAP/GitSecrets/Nuclei/GoBuster/Hydra）
# ====================================================================

@mcp.tool()
def zap_scan_tool(
    url: str = ...,
    max_duration: int = 300,
) -> str:
    """OWASP ZAP 自动化漏洞扫描（推荐对 Web 应用使用）。

    ZAP 是业界最主流的免费 Web 安全测试工具，提供 Spider（爬取）+ Active Scan（主动扫描）。

    ⚠️ 需要先启动 ZAP Daemon：docker run -d --name zap -p 8090:8090 ghcr.io/zaproxy/zaproxy:stable

    Args:
        url: 目标 URL
        max_duration: 总扫描时间（秒），Spider + Active Scan 合计
    """
    return json.dumps(_zap_scan(url, max_duration=max_duration), ensure_ascii=False, indent=2)


@mcp.tool()
def git_secret_scan(
    repo_path: str = ...,
    branch: str = "",
) -> str:
    """Git 仓库密钥泄露检测（Gitleaks）。

    扫描本地或远程 Git 仓库中的敏感信息（AWS/Azure/GCP/SSH/私钥/JWT等100+种pattern）。
    支持扫描远程仓库（自动 clone → scan → cleanup）。

    Args:
        repo_path: 本地 Git 仓库路径或远程 URL（如 https://github.com/user/repo.git）
        branch: 要扫描的分支（默认 HEAD）
    """
    result = scan_git_repo(repo_path, branch=branch)
    if not result.get("ok") and "gitleaks 未找到" in result.get("error", ""):
        return json.dumps({
            "ok": False,
            "repo_path": repo_path,
            "error": "gitleaks 未安装，请运行: go install github.com/zricethezav/gitleaks/v2@latest",
        }, ensure_ascii=False, indent=2)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def nuclei_scan_tool(
    target: str = ...,
    tags: str = "",
) -> str:
    """Nuclei 模板驱动漏洞扫描（6000+ 社区模板覆盖所有常见漏洞）。

    - CRLF/SSRF/RCE/XSS/SQLi/信息泄露/配置错误等全部可用
    - 比自建规则更全面、更新更快
    - 支持按 tags 过滤（如 "crlf,ssrf,xss"）

    Args:
        target: 目标 URL 或网段（如 https://example.com 或 10.0.0.0/24）
        tags: 逗号分隔的模板标签，空=全部模板扫描
    """
    result = _nuclei_scan(target, tags=[t.strip() for t in tags.split(",") if t.strip()] if tags else None)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def gobuster_tool(
    target: str = ...,
    mode: str = "dir",
) -> str:
    """GoBuster 多模式爆破（目录/VHost/DNS）。

    - dir: 目录/文件爆破（类似 ffuf）
    - vhost: Virtual Host 虚拟主机发现（CDN环境必备）
    - dns: DNS 子域名字典枚举

    Args:
        target: 目标 URL（dir/vhost）或域名（dns）
        mode: "dir" / "vhost" / "dns"
    """
    if mode == "dir":
        return json.dumps(gobuster_dir(target), ensure_ascii=False, indent=2)
    elif mode == "vhost":
        return json.dumps(gobuster_vhost(target), ensure_ascii=False, indent=2)
    elif mode == "dns":
        return json.dumps(gobuster_dns(target), ensure_ascii=False, indent=2)
    return json.dumps({"ok": False, "error": f"未知模式: {mode}"}, ensure_ascii=False, indent=2)


@mcp.tool()
def hydra_scan_tool(
    target: str = ...,
    service: str = "ssh",
) -> str:
    """密码暴力破解测试（CTF/授权渗透）。

    支持 SSH / FTP / HTTP POST / RDP 等 50+ 协议。

    ⚠️ 仅限授权环境使用，默认禁用生产环境。

    Args:
        target: 目标主机
        service: "ssh" / "ftp" / "http-post-form"
    """
    if service == "ssh":
        return json.dumps(hydra_ssh(target), ensure_ascii=False, indent=2)
    elif service == "ftp":
        return json.dumps(hydra_ftp(target), ensure_ascii=False, indent=2)
    elif service == "http-post-form":
        return json.dumps(hydra_http_post(target), ensure_ascii=False, indent=2)
    return json.dumps({"ok": False, "error": f"未知服务: {service}，支持 ssh/ftp/http-post-form"}, ensure_ascii=False, indent=2)


# ====================================================================
# P6 新集成工具（Google Dorking）
# ====================================================================

@mcp.tool()
def google_dork(
    domain: str = ...,
    tags: str = "",
    api_key: str = "",
    cx: str = "",
    max_per_query: int = 10,
) -> str:
    """Google Dorking（Google Hacking）侦察。

    利用 OWASP GHDB（Google Hacking Database）中的 70+ 条 dorks，
    通过 Google 搜索发现目标暴露的敏感信息、配置文件、API 端点等。

    支持两种查询模式：
    - 有 Google API Key + CX → 使用 Custom Search API（更稳定）
    - 无 API Key → fallback 到公开搜索（100 QPS/天限制）

    Args:
        domain: 目标域名，如 example.com
        tags: 逗号分隔的 dork 分类标签：
            sensitive_files (敏感文件) | api_endpoints (API 暴露) | auth_bypass (认证页面)
            sql_injection (SQLi 点) | crlf (CRLF 注入) | xss (XSS) | ssrf (SSRF)
            subdomains (子域名) | exposed_data (暴露数据) | sensitive_dirs (敏感目录)
        api_key: Google API Key（可选，https://console.cloud.google.com/apis/credentials）
        cx: Google CX ID（与 api_key 配合，https://programmablesearchengine.google.com/）
        max_per_query: 每个 dork 最多返回结果数
    """
    result = _google_dork(
        domain,
        tags=[t.strip() for t in tags.split(",") if t.strip()] if tags else None,
        api_key=api_key,
        cx=cx,
        max_per_query=max_per_query,
    )
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def list_ghdb() -> str:
    """列出所有可用的 OWASP GHDB（Google Hacking Database）dork 分类。

    返回每个分类的描述和 dork 数量，方便选择要搜索的标签。
    """
    return json.dumps(get_owasp_ghdb(), ensure_ascii=False, indent=2)


# ====================================================================
# CLI entry point
# ====================================================================

def main():
    mcp.run()


if __name__ == "__main__":
    main()
