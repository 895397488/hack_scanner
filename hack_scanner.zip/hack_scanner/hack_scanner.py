#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hack Scanner - 自动化漏洞扫描器
============================================================
只需提供文件路径或URL，即可自动执行安全检测。

用法:
    python hack_scanner.py --url https://example.com/path?param=value
    python hack_scanner.py --file ./path/to/files
    python hack_scanner.py --both -u URL -f DIRECTORY

输出:
    report.html     可视化HTML报告
    report.json     JSON格式报告数据
"""

import os
import sys
import json
import time
import logging
import argparse
from typing import List, Any, Dict, Optional
from datetime import datetime
from urllib.parse import urlparse

# 设置UTF-8输出编码
if sys.stdout.encoding and 'gbk' in sys.stdout.encoding.lower():
    sys.stdout.reconfigure(encoding='utf-8')
if sys.stderr.encoding and 'gbk' in sys.stderr.encoding.lower():
    sys.stderr.reconfigure(encoding='utf-8')
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 先导入全局 CONFIG（URLScanner 依赖）
_config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
with open(_config_path, 'r', encoding='utf-8') as f:
    CONFIG = json.load(f)

# ==================== 全局包裹 requests（防止 DoS）====================
import importlib
_real_req = __import__('requests')
class _GlobalRequestsWrapper:
    def __init__(self, real): self._real = real
    def _rl(self, url):
        if not url: return
        try:
            from rate_limiter import get_rate_limiter
            limiter = get_rate_limiter()
            rl_cfg = CONFIG.get('scanner',{}).get('rate_limit',{})
            interval = None
            if rl_cfg and rl_cfg.get('enabled'): interval = rl_cfg.get('per_domain_sec', 2.0)
            limiter.wait(url, interval)
        except Exception: pass
    def get(self, url=None, *a, **kw): self._rl(url); return self._real.get(url, *a, **kw)
    def post(self, url=None, *a, **kw): self._rl(url); return self._real.post(url, *a, **kw)
    def put(self, url=None, *a, **kw): self._rl(url); return self._real.put(url, *a, **kw)
    def delete(self, url=None, *a, **kw): self._rl(url); return self._real.delete(url, *a, **kw)
    def head(self, url=None, *a, **kw): self._rl(url); return self._real.head(url, *a, **kw)
    def patch(self, url=None, *a, **kw): self._rl(url); return self._real.patch(url, *a, **kw)
    def request(self, method, url=None, *a, **kw): self._rl(url); return self._real.request(method, url, *a, **kw)
    def session(self):
        s = self._real.session()
        orig_get, orig_post, orig_req = s.get, s.post, s.request
        def _wg(url=None, *a, **kw): self._rl(url); return orig_get(url, *a, **kw)
        def _wp(url=None, *a, **kw): self._rl(url); return orig_post(url, *a, **kw)
        def _wr(method, url=None, *a, **kw): self._rl(url); return orig_req(method, url, *a, **kw)
        s.get, s.post, s.request = _wg, _wp, _wr
        return s
    def __getattr__(self, n): return getattr(self._real, n)

# 替换全局 requests 引用
_requests_wrapped = _GlobalRequestsWrapper(_real_req)
import sys as _sys
_sys.modules['requests'] = _requests_wrapped
import requests as _requests_tmp  # pick up wrapped version
del _real_req, _requests_wrapped  # clean up temp

# 导入模块（现在所有 import requests 都得到包裹版本）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from url_scanner import URLScanner, ScanResult, ReportGenerator, Severity, print_banner
from file_analyzer import FileAnalyzer, analyze_file_or_dir

# AI 自动分析模块（可选）
try:
    from ai_analyzer import AIAnalyzer, ai_analyze_url
    HAS_AI = True
except ImportError:
    HAS_AI = False

# Shannon白盒增强（可选，无依赖也能运行）
try:
    from shannon_context import ContextAnalyzer, DataFlowTracer
    HAS_SHANNON = True
except ImportError:
    HAS_SHANNON = False


class HackScanner:
    """综合安全扫描器 - 统一入口"""

    def __init__(self, output_dir: str = None, proxy: Dict[str, str] = None):
        self.output_dir = output_dir or os.path.join(os.getcwd(), 'hack_report')
        self.proxy = proxy or {}
        self.all_findings: List[Any] = []
        self.results = {
            'url_scan': None,
            'file_scan': None,
            'combined_summary': {},
            'shannon_context': None,  # Shannon白盒分析上下文
        }
        # Shannon上下文分析器（如果可用）
        self.shannon_ctx: Optional['ContextAnalyzer'] = None
        if HAS_SHANNON:
            self.shannon_ctx = ContextAnalyzer()

    def scan_url(self, url: str) -> ScanResult:
        """扫描URL"""
        print(f"\n🎯 {'='*50}")
        print(f"  URL安全扫描: {url}")
        print(f"{'='*50}\n")

        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        # 将代理配置注入全局 CONFIG（URLScanner 从 config.json 读取）
        if self.proxy:
            CONFIG.setdefault('scanner', {})['proxy'] = self.proxy
            print(f"\U0001f578  HackScanner 已设置代理: {self.proxy}")

        scanner = URLScanner(output_dir=self.output_dir)
        result = scanner.scan(url)

        self.results['url_scan'] = result
        for f in result.findings:
            self.all_findings.append({
                'type': 'URL扫描',
                'finding': f.to_dict() if hasattr(f, 'to_dict') else f,
            })

        return result

    def scan_files(self, file_path: str) -> List[Any]:
        """扫描文件/目录"""
        print(f"\n📁 {'='*50}")
        print(f"  文件安全分析: {file_path}")
        print(f"{'='*50}\n")

        findings = analyze_file_or_dir(file_path)
        self.results['file_scan'] = findings

        for f in findings:
            self.all_findings.append({
                'type': '文件分析',
                'finding': f.to_dict() if hasattr(f, 'to_dict') else f,
            })

        return findings

    def generate_reports(self):
        """生成最终报告 — HTML+JSON，HTML内嵌完整JSON数据"""
        os.makedirs(self.output_dir, exist_ok=True)

        html_path = os.path.join(self.output_dir, 'report.html')
        json_path = os.path.join(self.output_dir, 'report.json')

        # ---- 构建综合报告数据（结构统一） ----
        combined_data = {
            'scan_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'summary': {},
            'url_findings': [],
            'file_findings': [],
        }

        # URL扫描结果
        if self.results['url_scan']:
            us = self.results['url_scan']
            combined_data['summary']['url_target'] = us.target_url
            combined_data['summary']['url_findings_count'] = us.finding_count
            combined_data['summary']['url_critical'] = us.critical_count
            combined_data['summary']['url_high'] = us.high_count
            combined_data['summary']['url_technologies'] = us.technologies
            combined_data['summary']['url_subdomains'] = us.subdomains[:20]
            combined_data['url_findings'] = [f.to_dict() for f in us.findings]

        # 文件扫描结果
        if self.results['file_scan']:
            file_path_display = 'N/A'
            if hasattr(self.results['file_scan'], '__iter__') and len(self.results['file_scan']) > 0:
                first = self.results['file_scan'][0]
                file_path_display = getattr(first, 'file_path', str(first))
            combined_data['summary']['file_path'] = file_path_display
            combined_data['summary']['file_findings_count'] = len(self.results['file_scan'])
            combined_data['file_findings'] = [
                f.to_dict() if hasattr(f, 'to_dict') else f for f in self.results['file_scan']
            ]
            # 语言统计
            stats = {}  
            if hasattr(self, '_file_stats'):
                stats = getattr(self, '_file_stats', {}).get('languages', {})
            combined_data['summary']['languages'] = stats

        # 综合统计
        total_sev = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for item in self.all_findings:
            finding = item['finding']
            sev = finding.get('severity', 'info') if isinstance(finding, dict) else getattr(finding, 'severity', 'info')
            if isinstance(sev, Severity):
                sev = sev.value
            total_sev[sev] = total_sev.get(sev, 0) + 1

        risk_score = (total_sev['critical'] * 25 + total_sev['high'] * 15 +
                      total_sev['medium'] * 5 + total_sev['low'] * 1)
        combined_data['summary']['risk_level'] = (
            '☠️ CRITICAL' if total_sev['critical'] > 0 else
            '🔴 HIGH RISK' if total_sev['high'] > 0 else
            '🟡 MODERATE' if total_sev['medium'] > 0 else
            '🟢 LOW RISK'
        )
        combined_data['summary']['risk_score'] = risk_score
        combined_data['summary']['total_findings'] = len(self.all_findings)
        combined_data['summary']['severity_breakdown'] = total_sev

        # ---- 写入JSON ----
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(combined_data, f, ensure_ascii=False, indent=2)

        # ---- 写入HTML（内嵌完整JSON数据） ----
        ReportGenerator.generate_from_combined(combined_data, html_path)

        print(f"\n📊 综合统计:")
        print(f"  总漏洞数: {len(self.all_findings)}")
        for sev in ['critical', 'high', 'medium', 'low', 'info']:
            if total_sev.get(sev, 0) > 0:
                icon = {'critical': '☠️ ', 'high': '⚠️ ', 'medium': '🟡 ', 'low': '🔵 ', 'info': 'ℹ️ '}.get(sev, '')
                print(f"  {icon}{sev.upper()}: {total_sev[sev]}")

        print(f"\n📄 报告已保存到:")
        print(f"  HTML: {html_path}  (内含完整JSON数据，点击展开)")
        print(f"  JSON: {json_path}")
        print(f"\n{'='*60}\n")

    def _ai_scan(self, url: str = None, file_path: str = None) -> Dict:
        """AI快速模式：根据目标类型执行扫描并返回统一报告数据结构"""
        report_data = {
            'scan_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'summary': {},
            'url_findings': [],
            'file_findings': [],
        }
        
        # === 类型判断：URL vs 文件路径 ===
        is_url = url and (url.startswith(('http://', 'https://')))
        
        if is_url:
            target = url
            print(f"\U0001f3e2 AI 快速模式 — URL扫描: {target}")
            scanner = URLScanner(output_dir=self.output_dir)
            result = scanner.scan(target)
            
            report_data['summary']['url_target'] = target
            report_data['summary']['url_findings_count'] = result.finding_count
            report_data['summary']['url_critical'] = result.critical_count
            report_data['summary']['url_high'] = result.high_count
            report_data['summary']['url_technologies'] = result.technologies
            report_data['summary']['url_subdomains'] = result.subdomains[:20]
            report_data['url_findings'] = [f.to_dict() for f in result.findings]
            
        elif file_path:
            print(f"\U0001f4c1 AI 快速模式 — 文件扫描: {file_path}")
            findings = self.scan_files(file_path)
            
            report_data['summary']['file_path'] = file_path
            report_data['summary']['file_findings_count'] = len(findings)
            report_data['file_findings'] = [
                f.to_dict() if hasattr(f, 'to_dict') else f for f in findings
            ]
        
        # 统一风险评分
        total_sev = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        all_findings = report_data['url_findings'] + report_data['file_findings']
        for f in all_findings:
            sev = f.get('severity', 'info') if isinstance(f, dict) else getattr(f, 'severity', 'info')
            if isinstance(sev, Severity):
                sev = sev.value
            total_sev[sev] = total_sev.get(sev, 0) + 1
        
        risk_score = (total_sev['critical'] * 25 + total_sev['high'] * 15 +
                      total_sev['medium'] * 5 + total_sev['low'] * 1)
        report_data['summary']['risk_level'] = (
            '☠️ CRITICAL' if total_sev['critical'] > 0 else
            '🔴 HIGH RISK' if total_sev['high'] > 0 else
            '🟡 MODERATE' if total_sev['medium'] > 0 else
            '🟢 LOW RISK'
        )
        report_data['summary']['risk_score'] = risk_score
        report_data['summary']['total_findings'] = len(all_findings)
        report_data['summary']['severity_breakdown'] = total_sev
        
        # 写入报告
        html_path = os.path.join(self.output_dir, 'report.html')
        json_path = os.path.join(self.output_dir, 'report.json')
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        ReportGenerator.generate_from_combined(report_data, html_path)
        
        print(f"\U0001f4ca 扫描完成 ({len(all_findings)} 个发现)")
        return report_data

    def run(self, url: str = None, file_path: str = None, use_ai: bool = False) -> Any:
        """运行扫描"""
        print_banner()

        if not url and not file_path:
            print("❌ 请至少提供一个参数: --url 或 --file")
            sys.exit(1)

        # AI 快速模式（扫描+AI分析一体化）
        if use_ai and HAS_AI:
            ai_conf = CONFIG.get('ai', {})
            if not ai_conf.get('enabled'):
                print("⚠️ AI 未启用。在 config.json 中设置 ai.enabled=true")
                return
            
            print("\U0001f916 启动 AI 自动分析模式...")
            # 根据目标类型分别处理
            report_data = self._ai_scan(url, file_path)
            
            # 将报告数据传给 AI 分析器
            from ai_analyzer import AIAnalyzer
            analyzer = AIAnalyzer()
            if not analyzer.enabled:
                print("⚠️ AI 未启用。在 config.json 中设置 ai.enabled=true")
                return
            
            ai_result = analyzer.analyze(report_data)
            
            # 输出结果
            if ai_result.get('analyzed'):
                print(f"\U0001f916 AI {analyzer.display_name}/{analyzer.model} 分析完成")
                
                # --- 生成 ai_report.html 并 iframe 嵌入 report.html ---
                from ai_analyzer import _md_to_html
                ai_text = ai_result['raw_response']
                
                # 保存 AI JSON
                ai_json_path = os.path.join(self.output_dir, 'ai_report.json')
                with open(ai_json_path, 'w', encoding='utf-8') as f:
                    json.dump(ai_result, f, ensure_ascii=False, indent=2)
                print(f"\U0001f4c4 AI JSON 已保存: {ai_json_path}")
                
                # Markdown → HTML
                ai_html_content = _md_to_html(ai_text)
                
                full_ai_html = (
                    '<!DOCTYPE html><html lang="zh"><head>'
                    '<meta charset="UTF-8"><style>'
                    '*{margin:0;padding:0;box-sizing:border-box}body{font-family:"Segoe UI",system-ui,sans-serif;background:#0d1117;color:#c9d1d9;padding:1.5rem;line-height:1.8;font-size:.95rem}'
                    'pre{background:#161b22;padding:1rem;border-radius:8px;color:#e6edf3;font-size:.9rem;overflow-x:auto;margin:.5rem 0}'
                    'code{background:#21262d;padding:.15rem .4rem;border-radius:4px;color:#79c0ff;font-size:.85rem}'
                    'h3{color:#e6edf3;margin-top:1.5rem;border-bottom:2px solid #30363d;padding-bottom:.5rem}.ai-title{color:#f78166!important;margin:0!important;border:none!important}hr{border:none;border-top:1px solid #21262d;margin:1rem 0}'
                    'div{margin:.3rem 0;padding:.5rem .8rem;background:#161b22;border-left:3px solid #f78166}h4{color:#79c0ff;font-weight:normal}.blockquote{border-left:3px solid #484f58;color:#8b949e;font-style:italic;padding:.8rem 1rem;margin:.5rem 0}'
                    '</style></head><body>'
                    '<h2 class="ai-title">\U0001f916 AI 自动分析报告 (' + analyzer.display_name + '/' + analyzer.model + ')</h2>' + ai_html_content + '</body></html>'
                )
                ai_html_path = os.path.join(self.output_dir, 'ai_report.html')
                with open(ai_html_path, 'w', encoding='utf-8') as f:
                    f.write(full_ai_html)
                print(f"\U0001f4c5 AI HTML 报告已保存: {ai_html_path}")
                
                # iframe 嵌入 report.html
                iframe_html = (
                    '<div style="margin:1.5rem 0;border-radius:12px;overflow:hidden;border:1px solid #30363d;">'
                    '<h3 style="color:#f78166;padding:.8rem 1.2rem;margin:0;background:#161b22;font-size:1.1rem;">\U0001f916 AI 自动分析报告 (' + analyzer.display_name + '/' + analyzer.model + ')</h3>'
                    '<iframe src="ai_report.html" style="width:100%;height:800px;border:none;background:#0d1117;"></iframe>'
                    '</div>'
                )
                
                html_path = os.path.join(self.output_dir, 'report.html')
                if os.path.exists(html_path):
                    with open(html_path, 'r', encoding='utf-8') as f:
                        html_content = f.read()
                    
                    marker = '</div>\n        <footer>'
                    # 兼容不同缩进的 footer 前
                    if marker not in html_content:
                        marker = '</div>\n    <footer>'
                    if marker not in html_content:
                        marker = '<footer>'
                    
                    if marker in html_content:
                        html_content = html_content.replace(marker, iframe_html + '\n' + marker)
                        with open(html_path, 'w', encoding='utf-8') as f:
                            f.write(html_content)
                        print(f"\U0001f4be report.html 已更新（含iframe嵌入AI报告）")
                    else:
                        print("⚠️ 未在 report.html 中找到插入位置，AI报告已单独保存为 ai_report.html")
                
            else:
                print(f"⚠️ {ai_result.get('error', 'AI分析未执行')}")
            
            return report_data

        if url:
            self.scan_url(url)

        if file_path:
            self.scan_files(file_path)

        # 生成报告
        self.generate_reports()


# ==================== 安全检查模块 ====================
_DANGEROUS_MODES = {
    'webshell_upload': ('Webshell 上传测试', '上传 PHP/ASPX 后门并执行命令'),
    'brute_force_password': ('密码暴力破解', '向登录接口发送暴力尝试请求'),
    'payment_tampering': ('支付篡改测试', '修改金额进行负值/零值购买'),
    'sql_sleep_dos': ('SQL Sleep DoS 攻击', '注入 SLEEP() 导致数据库延迟'),
    'ssrf_internal_probes': ('SSRF 内网探测', '通过 gopher/dict/ldap 协议探测内网服务'),
    'http_delete_put': ('HTTP DELETE/PUT 方法探测', '发送破坏性 HTTP 方法请求'),
    'password_reset_trigger': ('密码重置触发', '向任意邮箱发送重置邮件'),
    'dns_nuke': ('DNS Nuke 枚举', '大量 DNS 查询爆破子域名'),
}

_OOB_MODES = {
    'check_oob_blind_xss': ('盲 XSS (OOB)', '注入 JS payload 外连回调服务器'),
    'check_oob_blind_ssrf': ('盲 SSRF (OOB)', '触发服务器向 OOB 域发起请求'),
    'check_oob_blind_rce': ('盲 RCE (OOB)', '注入命令执行 payload 通过 DNS/HTTP 外泄'),
}


def _show_safety_warnings(url: str, dry_run: bool = False):
    """交互式安全确认：危险模式 + OOB 模式选择菜单"""
    from urllib.parse import urlparse

    domain = urlparse(url).netloc or url
    safety_cfg = CONFIG.get('safety', {})

    # 仅非本地域名才提示
    confirm_external = safety_cfg.get('confirm_external_scan', True)
    if not domain.startswith(('localhost', '127.0.0.1', '::1')) and confirm_external:
        print(f"\n{'='*60}")
        print(f"⚠️  目标域名: {domain} (外部网站)")
        print(f"{'='*60}")

        # === 交互式菜单（仅非 dry-run） / 状态展示（dry-run） ===
        all_modes = []
        for key, (name, desc) in _DANGEROUS_MODES.items():
            on = CONFIG.get('safety', {}).get('dangerous_modes', {}).get(key, False)
            status = '☠️ 已启用' if on else '⬜ 已禁用'
            all_modes.append((f'D{len(all_modes)+1}', key, name, desc, 'dangerous', on))

        for key, (name, desc) in _OOB_MODES.items():
            on = CONFIG.get('urls', {}).get(key, False)
            status = '📡 已启用' if on else '⬜ 已禁用'
            all_modes.append((f'P{len(all_modes)-len(_DANGEROUS_MODES)+1}', key, name, desc, 'oob', on))

        # 显示菜单（分危险/OOB两组）
        print("\n🔴 危险测试模式（默认关闭）：")
        for label, key, name, desc, typ, on in all_modes:
            if typ != 'dangerous':
                continue
            status = '☠️ 已启用' if on else '⬜ 已禁用'
            print(f"  [{label}] {status} — {name}: {desc}")

        print("\n📡 OOB/盲注入测试（默认启用）：")
        for label, key, name, desc, typ, on in all_modes:
            if typ != 'oob':
                continue
            status = '📡 已启用' if on else '⬜ 已禁用'
            print(f"  [{label}] {status} — {name}: {desc}")

        enabled_count = sum(1 for _, _, _, _, _, on in all_modes if on)
        print(f"\n📊 当前: {enabled_count}/{len(all_modes)} 项启用")

        if not dry_run:
            print("\n输入编号逗号分隔切换 (如 D1,P3)，回车确认。")
            try:
                choice = input("  选择: ").strip()
                if choice:
                    for item in choice.split(','):
                        item = item.strip().upper()
                        for label, key, name, desc, typ, on in all_modes:
                            if label == item:
                                new_val = not on
                                if typ == 'dangerous':
                                    CONFIG.setdefault('safety', {}).setdefault('dangerous_modes', {})[key] = new_val
                                else:
                                    CONFIG.setdefault('urls', {})[key] = new_val
            except (EOFError, KeyboardInterrupt):
                print("\n⚠️  中断输入，保持默认配置。")

        # === 限速状态 ===
        rl_cfg = CONFIG.get('scanner', {}).get('rate_limit', {})
        if rl_cfg and rl_cfg.get('enabled'):
            interval = rl_cfg.get('per_domain_sec', 'N/A')
            print(f"\n✅ 限速器已启用: 每域名至少 {interval}s 间隔")
        else:
            print(f"\n⚠️  限速器未启用！可能导致目标服务过载。")

        # === 最终状态确认 ===
        danger_modes_cfg = CONFIG.get('safety', {}).get('dangerous_modes', {})
        urls_cfg = CONFIG.get('urls', {})
        final_dangerous = [name for k, (name, _) in _DANGEROUS_MODES.items() if danger_modes_cfg.get(k, False)]
        final_oob = [name for k, (name, _) in _OOB_MODES.items() if urls_cfg.get(k, False)]

        if final_dangerous or final_oob:
            print(f"\n🔴 即将启用的危险测试：")
            for name in final_dangerous + final_oob:
                print(f"  ☠️  {name}")
        else:
            print(f"\n✅ 所有危险测试已禁用（仅执行安全扫描）")

        if not dry_run:
            safe_to_continue = input("\n是否继续扫描？(y/N): ").strip().lower()
            if safe_to_continue != 'y':
                print("❌ 扫描已取消。")
                sys.exit(0)


def _print_dry_run_summary(url: str):
    """打印 dry-run 预览信息"""
    from urllib.parse import urlparse
    domain = urlparse(url).netloc or url
    url_cfg = CONFIG.get('urls', {})

    print(f"\n{'='*60}")
    print(f"🔍 DRY-RUN: 目标 {domain}")
    print(f"{'='*60}\n")

    scanner_names = {
        'check_ssl': 'SSL/TLS 检查',
        'check_headers': 'HTTP 安全头检测',
        'check_cors': 'CORS 配置检测',
        'check_sqli': 'SQL 注入检测',
        'check_xss': 'XSS 检测',
        'check_ssrf': 'SSRF 检测',
        'check_rce': 'RCE 检测',
        'check_lfi': 'LFI 检测',
        'check_xxe': 'XXE 检测',
        'check_file_upload': '文件上传检测',
        'check_deserialization': '反序列化检测',
        'check_http_methods': 'HTTP 方法检测',
        'check_dvcs_leak': 'VCS 泄露检测',
        'check_openapi': 'OpenAPI 发现',
        'check_cms_fingerprint': 'CMS 指纹识别',
        'check_sqli_blind': '盲注 SQLi 检测',
        'check_ssrf_redirect': 'URL 重定向 SSRF',
        'check_extended_headers': '扩展安全头检测',
        'check_sensitive_data': '敏感信息泄露检测',
        'check_unauthorized_access': '未授权访问检测',
        'check_authorization_bypass': '越权访问检测',
        'check_csrf': 'CSRF 检测',
        'check_password_reset': '密码重置漏洞检测',
        'check_weak_password': '弱密码检测',
        'check_business_logic': '业务逻辑漏洞检测',
        'check_impact_eval': '影响评估',
        'check_crlf_injection': 'CRLF 注入检测',
        'check_jwt_vulnerability': 'JWT 漏洞检测',
        'check_subdomain_takeover': '子域名接管检测',
        'check_graphql_security': 'GraphQL 安全检测',
        'check_http_param_pollution': 'HTTP 参数污染检测',
        'check_oob_blind_xss': '盲 XSS (OOB)',
        'check_oob_blind_ssrf': '盲 SSRF (OOB)',
        'check_oob_blind_rce': '盲 RCE (OOB)',
        'enum_subdomains': '子域名枚举',
        'dir_busting.enabled': '目录爆破',
    }

    enabled_count = 0
    disabled_count = 0
    for key, name in scanner_names.items():
        # 处理嵌套 key (如 dir_busting.enabled)
        if '.' in key:
            parts = key.split('.')
            val = CONFIG
            for p in parts:
                val = val.get(p, {})
            enabled = bool(val)
        else:
            enabled = url_cfg.get(key, False)

        prefix = '+' if enabled else '-'
        marker = '[DANGEROUS]' if key in _DANGEROUS_MODES or key in _OOB_MODES else ''
        print(f"  {prefix} {name} {marker}")
        if enabled:
            enabled_count += 1
        else:
            disabled_count += 1

    # 限速状态
    rl_cfg = CONFIG.get('scanner', {}).get('rate_limit', {})
    rl_enabled = rl_cfg.get('enabled', False) if rl_cfg else False
    interval = rl_cfg.get('per_domain_sec', 'N/A') if rl_cfg else 'N/A'

    print(f"\n{'='*60}")
    print(f"  即将执行: {enabled_count} 项扫描 | 禁用: {disabled_count} 项")
    print(f"  限速器: {'✅ 已启用 (每域名间隔 %.1fs)' % interval if rl_enabled else '❌ 未启用'}")
    dangerous_mode = [k for k, v in CONFIG.get('safety', {}).get('dangerous_modes', {}).items() if v]
    if dangerous_mode:
        print(f"  危险模式: {'☠️  已启用 (' + ', '.join(dangerous_mode) + ')'}")
    print(f"\n  不会发送任何请求。扫描器将在无 --dry-run 时正常工作。")


def main():
    parser = argparse.ArgumentParser(
        description='🔐 Hack Scanner - 自动化漏洞扫描器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s --url https://example.com/path?id=1
  %(prog)s --file ./source-code/
  %(prog)s --both -u URL -f DIR

输出报告:
  report.html      HTML格式可视化报告（浏览器打开）
  report.json      JSON格式数据（供CI/CD集成）

支持检测:
  • OWASP TOP10 (SQL注入/XSS/SSRF/LFI/RCE等)
  • w3af 整合: XXE/文件上传/反序列化/CMS指纹
  • w3af 整合: Blind Timing SQLi / URL重定向SSRF
  • w3af 整合: VCS泄露(.git/.svn)/OpenAPI发现
  • w3af 整合: HTTP方法安全(TRACE/PUT/DELETE)
  • SSL/TLS证书检查
  • HTTP安全头 + 扩展安全头缺失检测
  • CORS错误配置
  • **未授权访问** (匿名敏感路径/API端点探测)
  • **越权访问(IDOR)** (ID参数替换/水平&垂直权限提升)
  • **CSRF** (Token缺失/SameCookie/跨域凭证)
  • **密码重置漏洞** (Token强度/枚举性/CSRF保护)
  • **CRLF注入 & HTTP响应拆分** (借鉴 Pentest-Swarm-AI crlfuzz)
  • **JWT Token 漏洞** (none-alg/弱密钥/kid注入, 借鉴 jwt_tool)
  • **GraphQL 安全测试** (introspection暴露/batching攻击, Phase 5.5)
  • **HTTP 参数污染 (HPP)** (参数重复注入, 借鉴 arjun)
  • **子域名接管** (40+ DNS CNAME dangling服务探测, Phase 5.6.1)
  • **云存储桶暴露** (S3/GCS/Azure bucket enumeration, Phase 5.6.2)
  • **盲注检测** (Blind XSS/SSRF/RCE via OOB, 借鉴 interact.sh)
  • **业务逻辑漏洞** (支付/积分/促销逻辑错误)
  • 敏感信息泄露检测
  • 子域名枚举 + **Playbook 扫描工作流** (OWASP/BugBounty/Internal等)
  • 目录爆破 (含SPA/CDN路径)
  • 代码静态分析 (Python/JS/PHP/Java/YAML等)
  • 依赖漏洞检测
  • **假阳性缓存** (FP False Positive Cache, Phase 4.3.4)
        """
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-u', '--url', help='要扫描的URL地址')
    group.add_argument('-f', '--file', help='要分析的文件或目录路径')

    parser.add_argument('--both', action='store_true', help='同时扫描URL和文件(需要-u和-f配合)')
    parser.add_argument('--dry-run', action='store_true', help='只预览将要执行的测试，不实际发送请求')
    parser.add_argument('--unsafe', action='store_true', help='命令行启用危险模式（覆盖 config.json 中的 safety.dangerous_modes）')
    parser.add_argument('--disable-oob', action='store_true', help='禁用所有 OOB/盲注入外部回调测试')
    parser.add_argument('-o', '--output', default=os.path.join(os.getcwd(), 'hack_report'), help='报告输出目录 (默认: ./hack_report)')
    parser.add_argument('--deep', action='store_true', help='深度扫描模式（更慢但更全面）')
    parser.add_argument('--proxy', type=str, default='', help='代理地址，例如: http://127.0.0.1:7890 或 socks5://127.0.0.1:1080')
    parser.add_argument('--ai', action='store_true', help='启用 AI 自动分析（需要 config.json 中 ai.enabled=true）')

    args = parser.parse_args()

    # 处理 --both
    url_target = args.url if hasattr(args, 'url') and args.url else None
    file_target = args.file if hasattr(args, 'file') and args.file else None

    # ==================== 安全检查 ====================

    # CLI 标志覆盖 config.json
    if url_target:
        # --unsafe：预设为开启状态，用户在交互菜单中可切换关闭
        if args.unsafe:
            for key in _DANGEROUS_MODES:
                CONFIG.setdefault('safety', {}).setdefault('dangerous_modes', {})[key] = True
            print("\n⚠️  [CLI] 危险模式已预设启用 — 交互式菜单中可切换关闭")
        if args.disable_oob:
            for key in _OOB_MODES:
                if key in CONFIG['urls']:
                    CONFIG['urls'][key] = False
            print("\n⚠️  [CLI] OOB/盲注入测试已通过 --disable-oob 禁用")

    if url_target:
        _show_safety_warnings(url_target, args.dry_run)

    if args.dry_run and url_target:
        print("\n🔍 DRY-RUN 模式：仅预览将要执行的测试，不会发送任何请求。")
        _print_dry_run_summary(url_target)
        sys.exit(0)

    # 同步安全配置到 url_scanner（交互菜单修改了本进程 CONFIG，但 url_scanner 有独立副本）
    import url_scanner
    url_scanner.CONFIG = CONFIG

    # ==================== 代理配置 ====================
    # 合并命令行 proxy + config.json proxy
    cli_proxy = {'enabled': False}
    if args.proxy:
        # 自动转换协议前缀
        if not args.proxy.startswith(('http://', 'https://', 'socks5://')):
            args.proxy = 'http://' + args.proxy
        cli_proxy = {'enabled': True, 'http': args.proxy, 'https': args.proxy}
    elif CONFIG.get('scanner', {}).get('proxy', {}).get('enabled'):
        cli_proxy = CONFIG['scanner']['proxy']

    scanner = HackScanner(output_dir=args.output, proxy=cli_proxy)
    scanner.run(url=url_target, file_path=file_target, use_ai=args.ai)


if __name__ == '__main__':
    main()
